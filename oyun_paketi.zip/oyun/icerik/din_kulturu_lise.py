# -*- coding: utf-8 -*-
"""
Din Kültürü ve Ahlak Bilgisi: lise (9-12) görevleri.

`din_kulturu.py` zekât hesabı, ahlaki değerler ve dinler bilgisini taşıyor.
Bu dosya MEB konu haritasında BOŞ kalan lise konularını doldurur: bilginin
kaynakları, inanç esasları, Allah'ın varlığına ilişkin deliller, isim ve
sıfatlar, ahiret, peygamberin görevleri, sünnet, din-bilim ilişkisi, din
istismarı, toplumsal ahlak.

ÜSLUP KURALLARI (üreticilerin hepsi için)
* Ders kitabı düzeyi, MEB terimleri; hiçbir mezhebin ya da yorumun
  üstünlüğü savunulmaz. Mezhepler arası tartışmalı fıkhî hükümlerde kesin
  cevap isteyen soru YOKTUR.
* Metin bir inancı savunmaz ya da eleştirmez; "ders kitabında şöyle öğretilir"
  düzeyinde aktarır. Kanıt kartları tanımı OKUTUR: soru ezber değil, kartı
  duruma uygulamayı ölçer.
* Şıklar "Kavram, çünkü gerekçe" biçimindedir ve ÜÇ yüzeysel okuma da
  gerekçesini taşır; doğru şık ne en uzun ne en kısadır, hiçbir şıkta
  noktalı virgül yoktur (şık sızıntısı tavanı: testler/test_sizinti.py).
* Her adımın sınıfı havuz öğesine özeldir; `sec` listesinin İLK öğesi doğrudur.
* Konu adları (`konu=`) MEB haritasındaki satırlara `oyun/veri/ek_karsilik.csv`
  üzerinden bağlanır; gerekçeleri orada yazılıdır.
"""
from __future__ import annotations

import random
from typing import Sequence, Tuple

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import PERSONEL, ad_sec, model_adimi, secim_adimi, yorum_adimi

# Bir havuz öğesindeki seçenek: (ad, gerekçe, teşhis). İlki doğrudur; teşhis
# yalnız yanlışlar için okunur (o şıkkı seçen öğrenciye söylenir).
Sec = Tuple[str, str, str]


def _sik(ad: str, gerekce: str) -> str:
    return "{}, çünkü {}".format(ad, gerekce)


def _siniflama(soru: str, sec: Sequence[Sec], rastgele: random.Random,
               aciklama: str, ipuclari: Sequence[str] = (), puan: int = 14,
               yorum: bool = False):
    """Havuz öğesinin `sec` listesinden gerekçeli şıklı adım kurar."""
    dogru = _sik(sec[0][0], sec[0][1])
    yanlislar = {_sik(ad, ger): teshis for ad, ger, teshis in sec[1:]}
    adim = yorum_adimi if yorum else secim_adimi
    return adim(soru=soru, dogru=dogru, yanlislar=yanlislar, rastgele=rastgele,
                aciklama=aciklama, ipuclari=list(ipuclari), puan=puan)


# ==========================================================================
# 1. BİLGİNİN KAYNAKLARI: duyular, akıl, haber ve kanaat
# ==========================================================================

# Her öğe: kayıt metni, doğru kaynak, açıklama, sec (ad, gerekçe, teşhis).
_BILGI_KAYNAKLARI = [
    {
        "kayit": ("Ölçümcü Nehir, dere kıyısına çaktığı çubuğu kendi gözüyle "
                  "okudu ve deftere \"su bu sabah iki karış yükseldi\" yazdı."),
        "kaynak": "Duyular",
        "aciklama": ("Nehir yükselmeyi kendisi gördü ve ölçtü: bilgi gözlemden "
                     "geliyor. Gözlem de yanılabilir; bu yüzden ölçü aleti ve "
                     "saat kaydedilir."),
        "sec": [
            ("Duyular", "bilgiyi yazan kişi suyun yükseldiğini kendi gözüyle "
                        "görüp ölçtü",
             ""),
            ("Akıl", "yükselme, iki ölçümün karşılaştırılmasıyla bulunan bir "
                     "sonuçtur",
             "Karşılaştırma yapıldı ama sonuç çıkarım değil, doğrudan okuma: "
             "çubuk yeni seviyeyi gösteriyor. Akılda sonuç, bilinenlerden "
             "mantıkla türetilir."),
            ("Haber", "bilgi yazıya dökülüp deftere işlendi ve başkalarına "
                      "ulaşacak",
             "Yazıya geçmesi kaynağını değiştirmez. Haberde bilgiyi aktaran "
             "kendi görmediğini bildirir; Nehir ise suyu kendisi okudu."),
            ("Kanaat", "kayıt bir kişinin kendi yargısını bildiriyor ve "
                       "dayanak göstermiyor",
             "Kaydın dayanağı var: ölçülmüş bir çubuk. Kanaat, dayanağı "
             "gösterilmeyen kişisel kanıdır."),
        ],
    },
    {
        "kayit": ("Telsizci Reyhan, kuzeyden gelen iki konvoyun da gecikmesinden "
                  "yola çıkarak deftere \"kuzey yolu kapanmış olmalı\" yazdı. "
                  "Yolu hiç kimse görmedi."),
        "kaynak": "Akıl",
        "aciklama": ("Yolun kapalı olduğunu kimse görmedi; bilinen iki olgudan "
                     "(iki gecikme) bir sonuç çıkarıldı. Bu, aklın yaptığı iştir "
                     "ve sonuç ancak öncüller kadar sağlamdır."),
        "sec": [
            ("Akıl", "sonuç, bilinen iki gecikmeden mantık yürütülerek "
                     "çıkarıldı",
             ""),
            ("Duyular", "gecikmeler gözlendi ve yolla ilgili bilgi gözleme "
                        "dayanıyor",
             "Gözlenen şey gecikmeydi; yolun kapalı oluşunu kimse görmedi. O "
             "bilgi gözlemden değil, gözlenenlerden çıkarılan sonuçtan geliyor."),
            ("Haber", "Reyhan bilgiyi telsizle aldı ve deftere işledi",
             "Telsiz yalnız gecikmeleri taşıdı. Yolun kapalı olduğu cümlesi "
             "kimsenin bildirdiği bir haber değil, Reyhan'ın çıkardığı sonuç."),
            ("Kanaat", "kimse yolu görmediği için kayıt bir tahminden öteye "
                       "geçmiyor",
             "Tahmin ile çıkarım ayrıdır: burada dayanak (iki gecikme) açıkça "
             "verilmiş. Dayanaksız tahmin kanaattir."),
        ],
    },
    {
        "kayit": ("Telsizci Reyhan, kuzey kulesindeki Gözcü Tarık'ın \"sınırda "
                  "sis var\" dediğini deftere geçirdi. Tarık yıllardır doğru "
                  "bildirimleriyle tanınıyor; Reyhan sisi kendisi görmedi."),
        "kaynak": "Haber",
        "aciklama": ("Reyhan sisi görmedi, güvenilir birinden öğrendi: bu haberdir. "
                     "Haberin değeri, bildiren kişinin doğruluğuna ve aktarımın "
                     "bozulmamasına bağlıdır."),
        "sec": [
            ("Haber", "Reyhan bilgiyi kendisi görmedi, güvenilir bir kişiden "
                      "aktarılan olarak öğrendi",
             ""),
            ("Duyular", "sisin varlığı sonuçta görülerek öğrenilmiş bir "
                        "bilgidir",
             "Sisi gören Tarık'tır. Reyhan'ın defterindeki bilgi ise Tarık'tan "
             "aktarılmış: kayıt tutanın kendi duyusu yok."),
            ("Akıl", "Tarık'ın sözü doğru çıkmıştır ve bu bir çıkarımla "
                     "doğrulanmıştır",
             "Kayıtta bir çıkarım yok; Reyhan hiçbir sonuç türetmedi, duyduğunu "
             "aktardı."),
            ("Kanaat", "söz sınırdaki durumu bildiriyor ama doğrulayan bir ölçü "
                       "göstermiyor",
             "Tarık'ın sözü dayanaksız bir kanı değil: kendi gözlemini "
             "bildiriyor ve güvenilir biri. Kanaatte ise dayanak yoktur."),
        ],
    },
    {
        "kayit": ("Depocu Kerem deftere \"Bence yarın hava bozar, içimde bir his "
                  "var\" yazdı. Hiçbir ölçüme, gözleme ya da habere "
                  "dayandırmadı."),
        "kaynak": "Kanaat",
        "aciklama": ("Kerem'in notunun dayanağı yok: ne bir ölçüm, ne bir çıkarım, "
                     "ne güvenilir bir haber. Böyle bir söz bilgi kaynağı "
                     "sayılmaz; ancak bir görüş olarak kaydedilir."),
        "sec": [
            ("Kanaat", "söz, dayanağı gösterilmemiş kişisel bir kanıdan "
                       "ibaret",
             ""),
            ("Akıl", "Kerem bir sonuca ulaştı ve bunu açık bir cümleyle "
                     "yazdı",
             "Akılda sonuç, öncüllerden türetilir. Kerem hiçbir öncül "
             "göstermedi; yalnız hissini yazdı."),
            ("Duyular", "\"his\" bedende duyulan bir şey olduğu için duyuya "
                        "dayanır",
             "Duyular dış dünyadan gelen bilgiyi (gözlem, ölçüm) verir. "
             "\"İçimde bir his var\" dışarıdaki bir şeyin gözlemi değildir."),
            ("Haber", "Kerem bunu başkalarından duymuş olabilir ve "
                      "aktarıyor",
             "Kayıtta kimden duyulduğu yok; aktarım değil, Kerem'in kendi "
             "kanısı söz konusu. Haberde bildiren bellidir."),
        ],
    },
    {
        "kayit": ("Arşivdeki eski bir risalede, yazarı bilinen bir kâtip kuraklık "
                  "yıllarını ve hangi ambarların boşaldığını kaynaklarıyla "
                  "birlikte sıralıyor. Kâtip olayların hiçbirini görmemiş."),
        "kaynak": "Haber",
        "aciklama": ("Risale, olayları görmeyen ama kaynaklarını gösteren bir "
                     "yazardan geliyor: yazılı haber. Yazarın bilinmesi ve "
                     "kaynak göstermesi onun güvenirliğini sınanabilir yapar."),
        "sec": [
            ("Haber", "kâtip olayları görmeden, kaynaklarını göstererek "
                      "başkalarından aktarıyor",
             ""),
            ("Duyular", "risale bir belgedir ve bir belge okuyan kişi "
                        "bilgiyi gözüyle görür",
             "Okurken görmek ile bilginin nasıl edinildiği ayrı şeylerdir. "
             "Kâtip olayları görmemiş; bilgi ona aktarılarak gelmiş."),
            ("Akıl", "kâtip kuraklık yıllarını sıralarken bir düzen "
                     "kurmuş, yani mantık yürütmüş",
             "Sıralamak bir düzenleme işidir; yeni sonuç türetmek değil. "
             "Kayıttaki bilgilerin hepsi kaynaklardan aktarılmış."),
            ("Kanaat", "risale eskidir ve yazılanları bugün kimse "
                       "doğrulayamaz",
             "Kaynakların gösterilmesi dayanak demektir. Eski olması, bir "
             "kaydı kanaat yapmaz; yalnız dayanaksız söz kanaattir."),
        ],
    },
]

_BILGI_YONTEMI = [
    ("Bilginin edinildiği yola bakılarak",
     "gözlem, çıkarım ve aktarım birbirinden farklı türde kaynaklardır",
     ""),
    ("Bilgiyi yazan kişinin makamına bakılarak",
     "üst görevli birinin yazdığı kayıt her zaman kesin bilgidir",
     "Makam, bilginin kaynağını göstermez: üst görevli de görmediğini "
     "aktarabilir ya da kanaatini yazabilir. Kaynağı belirleyen, bilgiye "
     "ulaşılan yoldur."),
    ("Bilginin kaç kişice tekrarlandığına bakılarak",
     "çok kişinin söylediği şeyin kaynağı da kesinleşmiş olur",
     "Tekrar kaynağı değiştirmez: yüz kişi aynı haberi aktarıyorsa hâlâ "
     "tek bir haberdir. Kaynak, bilginin nasıl edinildiğidir."),
    ("Bilginin ne kadar kesin söylendiğine bakılarak",
     "kendinden emin yazılan söz dayanağı olan sözdür",
     "Emin bir üslup dayanak sayılmaz; kanaat de kesin cümlelerle yazılabilir. "
     "Kaynağı belirleyen, bilgiye ulaşılan yoldur."),
]


@bulmaca(ders="din_kulturu", konu="bilgi_kaynaklari", kademeler=(9, 10),
         agirlik=1.2)
def bilgi_kaynaklari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir kaydın bilgisinin kaynağı (duyular, akıl, haber) ya da kaynaksız
    kanaat olduğu ayrılır; kaynaksız iddiayı doğrulamadan yaymanın sorumluluğu.

    MEB satırları: bilginin kaynakları (akıl, haber, duyular), doğru bilgiye
    ulaşma yolları, İsrâ 36 ve Mülk 23 (bilgi ve sorumluluk).
    """
    durum = rastgele.choice(_BILGI_KAYNAKLARI)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="din-bilgi-kaynaklari",
        ders="din_kulturu",
        baslik="Bilgi Defteri",
        kademe=kademe,
        konu="bilgi_kaynaklari",
        kazanim="Bilginin kaynakları (duyular, akıl, haber); bilgi ile kişisel "
                "kanaati ayırma; bilgi ve sorumluluk.",
        dikkat=6,
        brifing=(
            "Üssün Bilgi Defteri'ne her gün yeni kayıtlar giriyor. {} bunların "
            "kaynağını fişe yazacak: bilgi nereden geliyor?\n\n"
            "Bugünkü kayıt şu:\n\n  \"{}\"\n\n"
            "Kaynağı doğru yazmak önemli; çünkü üssün kararları bu defterden "
            "okunacak."
        ).format(kisi, durum["kayit"]),
        kanitlar=[
            Kanit("Bugünkü kayıt", durum["kayit"], bedel=1, kritik=True),
            Kanit("Kaynak kartları",
                  "DUYULAR: Görme, işitme gibi duyularla ve ölçü aletleriyle "
                  "doğrudan edinilen bilgi.\n"
                  "AKIL: Bilinenlerden mantık yürüterek bulunan sonuç.\n"
                  "HABER: Kendimizin görmediği bir şeyi, güvenilir bir "
                  "kaynaktan aktarılanla öğrenmek.\n"
                  "KANAAT: Dayanağı gösterilmemiş kişisel kanı; bilgi kaynağı "
                  "sayılmaz.",
                  bedel=2, kritik=True),
            Kanit("Defterin işleyiş notu",
                  "\"Fişe, bilgiyi yazanın ne düşündüğü değil, bilgiye hangi "
                  "yoldan ulaştığı yazılır.\"", bedel=1, kritik=True),
            Kanit("Ayet notu (anlam özeti)",
                  "İsrâ 36: İnsana, bilmediği bir şeyin ardına düşmemesi "
                  "öğütlenir; kulak, göz ve gönül bunlardan sorumludur.\n"
                  "Mülk 23: İnsana duyma, görme ve düşünme yetilerinin "
                  "verildiği hatırlatılır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir bilginin kaynağı neye bakılarak belirlenir?",
                dogru=_sik(_BILGI_YONTEMI[0][0], _BILGI_YONTEMI[0][1]),
                yanlislar={_sik(a, g): t for a, g, t in _BILGI_YONTEMI[1:]},
                rastgele=rastgele,
                aciklama=(
                    "Kaynağı, kimin söylediği ya da ne kadar emin söylediği değil, "
                    "bilgiye hangi yoldan ulaşıldığı belirler: doğrudan gözlem "
                    "(duyular), bilinenlerden sonuç çıkarma (akıl) ya da "
                    "güvenilir birinden öğrenme (haber)."
                ),
                ipuclari=[
                    "Hava durumunu üç yoldan öğrenebilirsin: pencereden bakarak, "
                    "bulutlara bakıp tahmin yürüterek ya da radyodan dinleyerek. "
                    "Hangisi hangi yol?",
                    "Fişteki ölçüt cümlesi bilginin ne söylediğini değil, "
                    "nereden geldiğini soruyor.",
                ],
                puan=16,
                cozum=("1) Kayıtta bilginin nasıl edinildiğini bul (gördü mü, "
                       "çıkardı mı, duydu mu, hiçbiri mi?).\n"
                       "2) Kaynak kartlarındaki dört tanımdan hangisi bu yolu "
                       "anlatıyor?\n\n"
                       "Ölçüt: bilgiye ulaşılan yol."),
            ),
            _siniflama(
                soru="Bugünkü kaydın bilgisi hangi kaynaktan gelmektedir?",
                sec=durum["sec"], rastgele=rastgele,
                aciklama=durum["aciklama"],
                ipuclari=["Kayıttaki kişi bilgiyi kendisi mi edindi, çıkardı mı, "
                          "başkasından mı aldı, yoksa hiçbir dayanak yok mu?"],
                puan=16),
            yorum_adimi(
                soru="Kaynağı doğrulanmamış bir iddia için defter ne yapmalı?",
                dogru=_sik("İddiaya \"doğrulanmadı\" notunu düşmeli",
                           "kesin bilgiymiş gibi yaymak sorumluluk doğurur"),
                yanlislar={
                    _sik("İddiayı hemen üsse duyurmalı",
                         "doğru çıkarsa zaman kazanılmış olur"):
                        "Doğrulanmamış iddiayı kesin bilgi gibi yaymak, hata "
                        "çıkarsa herkesi yanlış karara sürükler. Ayet de "
                        "bilmediğimiz şeyin ardına düşmemeyi öğütler.",
                    _sik("İddiayı deftere hiç yazmamalı",
                         "defter yalnız ölçülmüş bilgiyi tutabilir"):
                        "Defter haberi ve çıkarımı da kaydeder; yeter ki "
                        "kaynağını yazsın. İddiayı yok saymak da bilgiyi "
                        "kaybettirir.",
                    _sik("İddiayı yalnız üst görevli söylemişse yazmalı",
                         "makam sahibinin sözü her zaman doğrudur"):
                        "Makam kaynağı belirlemez: üst görevli de görmediğini "
                        "aktarabilir ya da kanaatini söyleyebilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İsrâ 36'nın öğüdü bilgi için bir sorumluluk koyar: bilmediğin "
                    "şeyi bilirmiş gibi yayma. Doğrulanmamış iddia silinmez ama "
                    "\"doğrulanmadı\" etiketiyle tutulur; böylece defteri "
                    "okuyanlar neye ne kadar güveneceğini bilir."
                ),
                ipuclari=["Defteri okuyan biri, bu kayda ne kadar güveneceğini "
                          "nasıl anlayacak?"],
                puan=14,
            ),
        ],
        kapanis="{} kaynağı fişe yazdı; kayıt defterdeki yerini aldı.".format(kisi),
        odul={"itibar": 6, "erzak": 2},
    )
