# -*- coding: utf-8 -*-
"""
Üretim zinciri: ham taş -> maden -> külçe -> alaşım. (GOREVLER B28.9-B28.12)

Tablolar `madenler.py`'de; bu dosya SAYILARI ve işlemleri tutar. Her stok
GRAM cinsinden tam sayıdır (B28.3 önerisi; ekranda kg).

§0 / §3: zincir bir ÖDÜLDÜR, KAPI DEĞİL. Hiçbir ders içeriği buradaki bir
stoğa bağlı değildir; üretimle uğraşmayan öğrenci hiçbir şey kaybetmez.
Külçe ve alaşım "üretimi artıran yükseltme" satın ALMAZ (B28.13, kullanıcı
kararı 11 Eylül): yalnızca materyal üretiminde (B28.14) kullanılacaktır.
Bu yüzden burada harcama yoktur; stok yalnızca zincirin içinde dolaşır.

Stoklar `Durum.madenler / kulceler / alasimlar` alanlarında durur. Alanlar
boş sözlükle başlar; eski kayıtlar bozulmadan açılır (B47).
"""
from __future__ import annotations

from typing import Dict, List, Optional

from . import madenler as M

# 1 "cevher" biriminin ham taş olarak ağırlığı.
TAS_GRAMI = 500

# İşleme: ham taşın kaçta kaçı maden çıkarır (tenör). İşleme zorluğu (1-5)
# arttıkça düşer: kömür/kireç taşı neredeyse saf, titanyum/nadir toprak
# taşın beşte biri.
TENOR = {1: 0.80, 2: 0.50, 3: 0.40, 4: 0.30, 5: 0.20}

# Ergitme: madenin kaçta kaçı külçe olur (verim); zor metalde kayıp artar.
ERGITME_VERIMI = {1: 0.95, 2: 0.90, 3: 0.80, 4: 0.70, 5: 0.60}

# Külçe katkıları: 1 g maden başına gram. Yalnızca neyin gerektiği
# madenler.KULCE_KATKILARI'nda; miktar burada (testle eşleşir).
KATKI_ORANLARI: Dict[str, Dict[str, float]] = {
    "demir": {"komur": 0.30, "kirec_tasi": 0.15},
}

ASAMALAR = ("isleme", "ergitme", "alasim")


# ----------------------------------------------------------------- stoklar
def _alan(tur: str) -> str:
    return {"maden": "madenler", "kulce": "kulceler", "alasim": "alasimlar"}[tur]


def stok(durum, tur: str) -> Dict[str, int]:
    """Durumdaki stok sözlüğü; yoksa/bozuksa kurar. tur: maden|kulce|alasim."""
    ad = _alan(tur)
    s = getattr(durum, ad, None)
    if not isinstance(s, dict):
        s = {}
        setattr(durum, ad, s)
    return s


def miktar(durum, tur: str, kod: str) -> int:
    try:
        return max(0, int(stok(durum, tur).get(kod, 0)))
    except (TypeError, ValueError):
        return 0


def _ekle(durum, tur: str, kod: str, gram: int) -> None:
    stok(durum, tur)[kod] = miktar(durum, tur, kod) + int(gram)


def _dus(durum, tur: str, kod: str, gram: int) -> None:
    stok(durum, tur)[kod] = max(0, miktar(durum, tur, kod) - int(gram))


def kademe(durum) -> int:
    return max(1, int(round(durum.ortalama_kademe)))


def kg_metni(gram: int) -> str:
    """1500 -> '1,5 kg'; 250 -> '250 g'."""
    gram = int(gram)
    if gram < 1000:
        return "{} g".format(gram)
    kg = gram / 1000.0
    return (("{:.3f}".format(kg)).rstrip("0").rstrip(".")).replace(".", ",") + " kg"


def tenor(kod: str) -> float:
    return TENOR[M.maden(kod).isleme]


def ergitme_verimi(kod: str) -> float:
    return ERGITME_VERIMI[M.maden(kod).isleme]


def _ret(neden: str) -> Dict:
    return {"ok": False, "neden": neden}


# ----------------------------------------------------------------- işleme
def isleme_cikti(kod: str, birim: int) -> int:
    """`birim` cevher (ham taş) kaç gram `kod` madeni verir."""
    return int(birim * TAS_GRAMI * tenor(kod))


def isle(durum, kod: str, birim: int) -> Dict:
    """Ham taş harcar, maden çıkarır (B28.10 uygulama kipi)."""
    m = M.maden(kod)
    birim = int(birim)
    if m is None:
        return _ret("Böyle bir maden yok.")
    if m.acilis_kademesi > kademe(durum):
        return _ret("{} henüz açılmadı.".format(m.ad))
    if birim <= 0:
        return _ret("Miktar sıfırdan büyük olmalı.")
    if durum.kaynaklar.get("cevher", 0) < birim:
        return _ret("Yeterli cevher (ham taş) yok.")
    gram = isleme_cikti(kod, birim)
    if gram <= 0:
        return _ret("Bu miktar maden çıkarmaya yetmez.")
    durum.kaynaklar["cevher"] -= birim
    _ekle(durum, "maden", kod, gram)
    return {"ok": True, "gram": gram, "harcanan": birim,
            "tas_gram": birim * TAS_GRAMI, "tenor": tenor(kod)}


# ---------------------------------------------------------------- ergitme
def katki_gerekli(kod: str, gram: int) -> Dict[str, int]:
    return {k: int(round(gram * o)) for k, o in KATKI_ORANLARI.get(kod, {}).items()}


def ergit_cikti(kod: str, gram: int) -> int:
    return int(gram * ergitme_verimi(kod))


def ergit(durum, kod: str, gram: int) -> Dict:
    """Madenden külçe (B28.11). Demirde kömür + kireç taşı katkısı gerekir."""
    gram = int(gram)
    m = M.maden(kod)
    if m is None or not M.kulceye_donusur(kod):
        return _ret("Yalnızca metaller külçe olur.")
    if m.acilis_kademesi > kademe(durum):
        return _ret("{} henüz açılmadı.".format(m.ad))
    if gram <= 0:
        return _ret("Miktar sıfırdan büyük olmalı.")
    if miktar(durum, "maden", kod) < gram:
        return _ret("Yeterli {} madeni yok.".format(m.ad.lower()))
    katki = katki_gerekli(kod, gram)
    eksik = {k: g - miktar(durum, "maden", k) for k, g in katki.items()
             if miktar(durum, "maden", k) < g}
    if eksik:
        return {"ok": False, "eksik": eksik, "neden": "Katkı eksik: " + ", ".join(
            "{} {}".format(M.maden(k).ad.lower(), kg_metni(g))
            for k, g in eksik.items())}
    cikti = ergit_cikti(kod, gram)
    if cikti <= 0:
        return _ret("Bu miktar külçe vermez.")
    _dus(durum, "maden", kod, gram)
    for k, g in katki.items():
        _dus(durum, "maden", k, g)
    _ekle(durum, "kulce", kod, cikti)
    return {"ok": True, "gram": cikti, "harcanan": gram, "katki": katki,
            "verim": ergitme_verimi(kod)}


# ----------------------------------------------------------------- alaşım
# Sonuç aralıkları (GOREVLER B28.10 kararındaki yuvarlak değerler). UYARI:
# genel metalurji bilgisinden; fen/kimya öğretmenine ya da kaynağa karşı
# doğrulanmalı. (anahtar bileşen, [(üst sınır, ad, geçerli mi)]) -- oran
# "<= üst" ise o satır; son satırın sınırı sonsuz.
_S = 1e-6
ARALIKLAR = {
    "celik": ("komur", [
        (0.003 - _S, "yumuşak çelik (karbon az; sertleşmez)", False),
        (0.02 + _S, "çelik (sertleşir)", True),
        (9.0, "dökme demir (dökülür ama gevrek)", False)]),
    "pirinc": ("cinko", [
        (0.05 - _S, "bakıra yakın; pirinç özelliği yok", False),
        (0.35 + _S, "pirinç (soğukta işlenir)", True),
        (0.45 + _S, "sert pirinç (sıcakta işlenir)", True),
        (9.0, "gevrek; işlenmez", False)]),
    "tunc": ("kalay", [
        (0.08 - _S, "yumuşak; tunç sertliğine ulaşmıyor", False),
        (0.15 + _S, "tunç", True),
        (0.20 - _S, "sert ve gevrek", False),
        (9.0, "çan bronzu (sert, gevrek, çınlar)", False)]),
    "duralumin": ("bakir", [
        (0.03 - _S, "alüminyuma yakın; sertleşmiyor", False),
        (0.06 + _S, "duralümin", True),
        (9.0, "gevrek bir ara faz oluşur; alaşım zayıflar", False)]),
    "paslanmaz_celik": ("krom", [
        (0.105 - _S, "paslanmaz DEĞİL (krom %10,5'ten az; koruyucu katman olmaz)", False),
        (9.0, "paslanmaz çelik", True)]),
}


def alasim_dene(kod: str, oranlar: Optional[Dict[str, float]] = None) -> Dict:
    """Oranlara bakıp ne çıkacağını söyler; HİÇBİR ŞEYİ HARCAMAZ.

    Meraklı oyuncu değerleri küçük küçük değiştirip bakar (B28.10).
    """
    a = M.alasim(kod)
    if a is None:
        return {"ok": False, "neden": "Böyle bir alaşım yok."}
    oranlar = dict(oranlar) if oranlar else dict(a.bilesim)
    if set(oranlar) != set(a.bilesim):
        return {"ok": False, "neden": "Bileşenler: " + ", ".join(sorted(a.bilesim))}
    if any(float(v) < 0 for v in oranlar.values()):
        return {"ok": False, "neden": "Oran eksi olamaz."}
    toplam = sum(float(v) for v in oranlar.values())
    if abs(toplam - 1.0) > 1e-6:
        return {"ok": False, "neden": "Oranların toplamı %100 olmalı (şimdi %{:.1f}).".format(
            toplam * 100).replace(".", ",")}
    anahtar, aralik = ARALIKLAR[kod]
    deger = float(oranlar[anahtar])
    for ust, metin, gecerli in aralik:
        if deger <= ust:
            return {"ok": True, "sonuc": metin, "gecerli": gecerli,
                    "anahtar": anahtar, "oran": deger, "oranlar": oranlar}
    return {"ok": False, "neden": "Aralık bulunamadı."}


def _paylar(oranlar: Dict[str, float], gram: int) -> Dict[str, int]:
    """Toplamı TAM `gram` eden bölüşüm (en büyük kalan yöntemi)."""
    ham = {k: gram * v for k, v in oranlar.items()}
    pay = {k: int(x + 1e-9) for k, x in ham.items()}
    kalan = gram - sum(pay.values())
    for k in sorted(ham, key=lambda k: (-(ham[k] - pay[k]), k))[:max(0, kalan)]:
        pay[k] += 1
    return pay


def alasim_girdileri(kod: str, gram: int,
                     oranlar: Optional[Dict[str, float]] = None) -> Dict[str, int]:
    a = M.alasim(kod)
    return _paylar(oranlar or a.bilesim, int(gram))


def _bilesen_turu(kod: str) -> str:
    """Metal külçeden, metal olmayan (kömür) maden stoğundan gelir."""
    return "kulce" if M.kulceye_donusur(kod) else "maden"


def alasim_yap(durum, kod: str, gram: int,
               oranlar: Optional[Dict[str, float]] = None) -> Dict:
    """Külçelerden alaşım (B28.12). Geçersiz oranda HİÇBİR ŞEY harcanmaz."""
    a = M.alasim(kod)
    gram = int(gram)
    if a is None:
        return _ret("Böyle bir alaşım yok.")
    if a.acilis_kademesi > kademe(durum):
        return _ret("{} henüz açılmadı.".format(a.ad))
    if gram <= 0:
        return _ret("Miktar sıfırdan büyük olmalı.")
    deneme = alasim_dene(kod, oranlar)
    if not deneme["ok"]:
        return _ret(deneme["neden"])
    if not deneme["gecerli"]:
        return {"ok": False, "neden": "Bu oranla {} olmaz: {}.".format(
            a.ad.lower(), deneme["sonuc"]), "sonuc": deneme["sonuc"]}
    girdi = _paylar(deneme["oranlar"], gram)
    eksik = {k: g - miktar(durum, _bilesen_turu(k), k) for k, g in girdi.items()
             if miktar(durum, _bilesen_turu(k), k) < g}
    if eksik:
        return {"ok": False, "eksik": eksik, "neden": "Eksik: " + ", ".join(
            "{} {}".format(M.maden(k).ad.lower(), kg_metni(g))
            for k, g in eksik.items())}
    for k, g in girdi.items():
        _dus(durum, _bilesen_turu(k), k, g)
    _ekle(durum, "alasim", kod, gram)
    return {"ok": True, "gram": gram, "girdi": girdi, "sonuc": deneme["sonuc"]}


# ----------------------------------------------------------- zincir özeti
def _satir(asama, kod, ad, girdiler, cikti_ad, uretilebilir, sinirlayan, acik):
    return {"asama": asama, "kod": kod, "ad": ad, "girdi": girdiler,
            "cikti": cikti_ad, "uretilebilir": int(uretilebilir),
            "sinirlayan": sinirlayan, "acik": acik}


def zincir_satirlari(durum) -> List[Dict]:
    """Her adım için eldeki stokla NE KADAR üretilebileceği ve neyin sınırladığı."""
    k = kademe(durum)
    cevher = int(durum.kaynaklar.get("cevher", 0))
    satirlar = []
    for m in M.MADENLER:
        satirlar.append(_satir(
            "isleme", m.kod, m.ad, {"cevher": cevher * TAS_GRAMI}, m.ad,
            isleme_cikti(m.kod, cevher), None if cevher else "cevher",
            m.acilis_kademesi <= k))
    for m in M.MADENLER:
        if not M.kulceye_donusur(m.kod):
            continue
        stoktaki = miktar(durum, "maden", m.kod)
        sinir, sinirlayan = stoktaki, (None if stoktaki else m.kod)
        girdi = {m.kod: stoktaki}
        for kat, o in KATKI_ORANLARI.get(m.kod, {}).items():
            eldeki = miktar(durum, "maden", kat)
            girdi[kat] = eldeki
            olur = int(eldeki / o)
            if olur < sinir or (olur == 0 and sinirlayan is None):
                sinir, sinirlayan = olur, kat
        satirlar.append(_satir(
            "ergitme", m.kod, m.ad + " külçesi", girdi, m.ad + " külçesi",
            ergit_cikti(m.kod, sinir), sinirlayan if sinir == 0 else None,
            m.acilis_kademesi <= k))
    for a in M.ALASIMLAR:
        sinir, sinirlayan, girdi = None, None, {}
        for bk, o in a.bilesim.items():
            eldeki = miktar(durum, _bilesen_turu(bk), bk)
            girdi[bk] = eldeki
            olur = int(eldeki / o)
            if sinir is None or olur < sinir:
                sinir, sinirlayan = olur, bk
        satirlar.append(_satir("alasim", a.kod, a.ad, girdi, a.ad, sinir or 0,
                               sinirlayan if not sinir else None,
                               a.acilis_kademesi <= k))
    return satirlar


def darbogaz(durum, satirlar: Optional[List[Dict]] = None) -> Optional[Dict]:
    """Zincirin en yakın tıkanıklığı.

    Açık bir adım, girdilerinden en az biri VAR ama biri YOK diye
    üretemiyorsa o adım darboğazdır ("demir var, kömür yok"). Hiç stok yoksa
    darboğaz zincirin başıdır: cevher. Aksi hâlde None (akış tıkanmamış).
    """
    satirlar = satirlar if satirlar is not None else zincir_satirlari(durum)
    for s in satirlar:
        if s["asama"] == "isleme" or not s["acik"] or s["uretilebilir"] > 0:
            continue
        if any(v > 0 for v in s["girdi"].values()):
            m = M.maden(s["sinirlayan"])
            return {"asama": s["asama"], "kod": s["kod"], "ad": s["ad"],
                    "girdi": s["sinirlayan"],
                    "neden": "{} üretilemiyor: {} yok.".format(
                        s["ad"], m.ad.lower() if m else s["sinirlayan"])}
    toplam = sum(sum(stok(durum, t).values()) for t in ("maden", "kulce", "alasim"))
    if toplam == 0 and int(durum.kaynaklar.get("cevher", 0)) == 0:
        return {"asama": "isleme", "kod": None, "ad": "Ham taş", "girdi": "cevher",
                "neden": "Zincirin başı boş: işlenecek cevher (ham taş) yok."}
    return None


def zincir_ozeti(durum) -> Dict:
    """Tesisler ekranı ve Meridyen OS için düz veri: stoklar, zincir, darboğaz."""
    satirlar = zincir_satirlari(durum)
    return {
        "stoklar": {
            "cevher": int(durum.kaynaklar.get("cevher", 0)),
            "ham_tas_gram": int(durum.kaynaklar.get("cevher", 0)) * TAS_GRAMI,
            "madenler": dict(stok(durum, "maden")),
            "kulceler": dict(stok(durum, "kulce")),
            "alasimlar": dict(stok(durum, "alasim")),
        },
        "zincir": satirlar,
        "darbogaz": darbogaz(durum, satirlar),
    }
