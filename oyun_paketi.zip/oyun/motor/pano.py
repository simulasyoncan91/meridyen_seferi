# -*- coding: utf-8 -*-
"""
Sınıf panosu: yalnızca ÖNÜNDEKİLER.

Kullanıcı rütbenin "sağlam rekabet ve hırs" yaratmasını istedi ve bunun
kıskançlık ile soğumaya da yol açabileceğini bilerek kabul etti: "biz
eğitimi ceza olarak gören kişilere sesleniyoruz, ve bu kişiler ders
işlemekten çok oyunda yükselmek isteyen kişilerdir."

Rekabet §0 ile şu kurallarla bir arada durur (hepsi teste bağlı):

1. SIRA NUMARASI HİÇ HESAPLANMAZ. Öğrenci kaçıncı olduğunu hiçbir yerden
   öğrenemez, çünkü o sayı üretilmez. §2'nin "ilk beşi göster" kuralından
   güçlü: altı kişilik bir şubede ilk beş, listenin tamamıdır.
2. YALNIZCA ÜST KOMŞU GÖRÜNÜR. Sonuncu olan da birebir aynı ekranı görür
   -- önünde biri vardır. Hırs korunur, "aşağı" diye bir yön yoktur.
3. ÖLÇÜ KATILIMDIR. `oynanan_gorev`: anlatım izlemek de birlikte çözmek de
   sayılır, doğruluk hiç girmez, hiçbir olayla azalmaz. Rütbe de aynı
   sayıya bağlı; pano rütbenin ince taneli hâlidir.
4. PANODAN ÇIKIŞ SESSİZDİR. Çıkan öğrenci listede yoktur ve "N kişi
   görünmüyor" diye bir satır da yoktur -- o cümle çıkanı gösterir.
5. TAKMA ADI OLMAYAN GÖRÜNMEZ. Gerçek ad panoya asla düşmez.

TELEFONDA PANO YOKTUR. Veri kayıt klasöründen okunur; her telefonun kaydı
kendi tarayıcısında durur ve başkasınınkini göremez. Pano yalnızca ortak
klasörlü (bilgisayar laboratuvarı) kurulumda dolar. Telefonda öğrencinin
rakibi bir sonraki rütbe eşiğidir -- o tamamen yerel çalışır.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Tuple

from . import durum as durum_modulu
from .durum import RUTBELER

GOSTERILEN = 2


def rutbe_adi(gorev: int) -> str:
    ad = RUTBELER[0][1]
    for esik, isim in RUTBELER:
        if gorev >= esik:
            ad = isim
    return ad


def onumdekiler(benim_gorev: int, digerleri: Iterable[Tuple[str, int]],
                adet: int = GOSTERILEN) -> List[Dict[str, Any]]:
    """Benden KESİN olarak öndekiler, en yakından başlayarak.

    Eşit olan önde sayılmaz. Arkadaki hiçbir koşulda dönmez. Sıra numarası
    dönmez; yalnızca takma ad, fark ve rütbe.
    """
    onde = sorted(((int(gorev), takma) for takma, gorev in digerleri
                   if takma and int(gorev) > benim_gorev),
                  key=lambda ikili: (ikili[0], ikili[1].lower()))
    return [{"takma": takma, "fark": gorev - benim_gorev,
             "rutbe": rutbe_adi(gorev)} for gorev, takma in onde[:adet]]


def sinif_verisi(durum) -> List[Tuple[str, int]]:
    """Aynı sınıf kodundaki DİĞER öğrenciler: (takma ad, görev sayısı)."""
    kod = (durum.sinif_kodu or "").strip().upper()
    if not kod:
        return []
    kendi = durum.kimlik() + ".json"
    veri = []
    for ozet in durum_modulu.kayitlari_listele():
        if ozet.get("dosya") == kendi:
            continue
        if (ozet.get("sinif_kodu") or "").strip().upper() != kod:
            continue
        if not ozet.get("panoda", True):
            continue
        veri.append((ozet.get("takma") or "", int(ozet.get("gorev") or 0)))
    return veri


def sinif_panosu(durum, adet: int = GOSTERILEN) -> List[Dict[str, Any]]:
    """Ekrana gidecek hâli. Okuma patlarsa boş liste: pano yüzünden oyun
    durmaz."""
    try:
        return onumdekiler(durum.oynanan_gorev, sinif_verisi(durum), adet)
    except Exception:  # noqa: BLE001
        return []
