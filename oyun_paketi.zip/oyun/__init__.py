# -*- coding: utf-8 -*-
"""Meridyen Seferi - egitim oyunu paketi."""

__version__ = "0.9.0"
