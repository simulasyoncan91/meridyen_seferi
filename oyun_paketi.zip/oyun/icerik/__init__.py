# -*- coding: utf-8 -*-
"""Ders icerikleri. Her modul kendi bulmaca ureticilerini kaydeder."""
