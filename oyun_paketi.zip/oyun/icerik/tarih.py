# -*- coding: utf-8 -*-
"""
Tarih görevleri.

Çerçeve: KRONOGRAF. Üsse geçmişten kayıt parçaları geliyor - bir çarşı
gürültüsü, bir tablet, bir alet, bir mektup. Kronograf hangi çağdan geldiğini
söylemez.

Bu yüzden bu derste öğrenciye "Malazgirt kaç yılındaydı?" diye sorulmaz.
Öğrenciye bir kayıt verilir; içindeki teknoloji, malzeme, unvan ve alışkanlık
izlerinden dönemi kendisi çıkarır. Tarih burada ezberlenecek bir liste değil,
kanıttan sonuca giden bir akıl yürütmedir.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, coklu_siklar, model_adimi, sayi_adimi, secim_adimi,
    sirala_adimi, yorum_adimi,
)


# ==========================================================================
# KRONOGRAF KAYITLARI - kanıttan dönem çıkarma
# ==========================================================================

# Her kaydın belirleyici izi, o dönemi diğerlerinden ayıran teknolojik eşiktir.
_DONEMLER = [
    {
        "ad": "Neolitik Çağ (ilk tarım köyleri)",
        "aralik": "yaklaşık MÖ 8000",
        "sahne": (
            "Alçak, yan yana yapışık kerpiç evler. Damlardan girilip "
            "çıkılıyor. Bir kadın taş bir tekneye arpa döküp başka bir taşla "
            "eziyor. Avluda birkaç koyun bağlı duruyor; kimse onları avlamıyor, "
            "besliyor."
        ),
        "izler": [
            ("Alet incelemesi",
             "Aletlerin hepsi taştan ve kemikten. Hiçbirinde metal yok.", True),
            ("Yazı araması",
             "Duvarlarda boya ile yapılmış resimler var; ama hiçbir yerde yazı, "
             "işaret dizisi ya da kayıt levhası yok.", True),
            ("Tarım izi",
             "Ekilmiş tahıl tarlaları ve besiye alınmış hayvanlar görülüyor. "
             "Topluluk yerleşik.", True),
            ("Kap kacak",
             "Pişmiş topraktan çanak çömlek kullanılıyor.", False),
        ],
        "belirleyici": "Yazının hiç bulunmaması ve metal aletin olmaması",
        "belirleyici_aciklama": (
            "Yazının olmaması bu kaydı doğrudan tarih öncesine yerleştirir; "
            "metalin hiç bulunmaması ise Maden çağlarından da önce olduğunu "
            "gösterir. Yerleşik tarım ise Neolitik'in tanımıdır."
        ),
        "secim_teshis": (
            "Neolitik'i seçtin. Bu çağın imzası hiç metal ve hiç yazı "
            "bulunmamasıdır; kayıttaki izlerde metal bir alet ya da bir "
            "işaret dizisi geçiyor mu, bir daha bak."
        ),
        "gerekce_teshis": (
            "Bu gerekçe, kayıtta ne yazı ne de metal gördüğünü söyler. "
            "Gerekçe hatırladığın çağdan değil, önündeki izlerden çıkar; "
            "kayıtta bunların ikisi de yok mu?"
        ),
    },
    {
        "ad": "Tunç Çağı Anadolu (Hitit dönemi)",
        "aralik": "yaklaşık MÖ 1300",
        "sahne": (
            "Taş temelli büyük bir yapı. Bir kâtip, ıslak kil bir levhaya "
            "ucu üçgen bir kamışla işaretler basıyor. Avluda iki atın çektiği "
            "hafif bir savaş arabası duruyor. Askerlerin baltaları sarımtırak "
            "bir metalden."
        ),
        "izler": [
            ("Kâtip levhası",
             "Islak kile kamışla basılan üçgen uçlu işaretler: çivi yazısı. "
             "Levhada bir antlaşma metni var.", True),
            ("Metal incelemesi",
             "Aletler ve silahlar tunç (bakır-kalay alaşımı). Demir silah yok.",
             True),
            ("Ulaşım",
             "İki atın çektiği iki tekerlekli hafif savaş arabası kullanılıyor.",
             False),
            ("Yapı düzeni",
             "Taş temelli anıtsal yapılar, arşiv odası, mühürler.", False),
        ],
        "belirleyici": "Çivi yazılı kil tablet ile tunç silahların birlikte bulunması",
        "belirleyici_aciklama": (
            "Yazının varlığı kaydı tarihî çağlara taşır. Silahların demir değil "
            "tunç olması ise Demir Çağı'ndan önce olduğunu gösterir. İkisi "
            "birlikte dönemi oldukça dar bir aralığa sıkıştırır."
        ),
        "secim_teshis": (
            "Tunç Çağı'nı seçtin. Bu çağın imzası çivi yazılı kil tablet ile "
            "tunç -demir değil- silahların BİRLİKTE bulunmasıdır; kayıtta bu "
            "ikisini de görüyor musun?"
        ),
        "gerekce_teshis": (
            "Bu gerekçe, kayıtta hem çivi yazılı tablet hem tunç silah "
            "gördüğünü söyler. Gerekçe kanıta bağlıdır: kayıtta böyle bir "
            "tablet ya da tunç alet geçiyor mu?"
        ),
    },
    {
        "ad": "Roma dönemi Akdeniz kenti",
        "aralik": "yaklaşık MS 100",
        "sahne": (
            "Taş döşeli geniş bir cadde. Kemerli bir su yolu şehre su "
            "taşıyor. Bir tüccar, üzerinde imparator başı basılı madenî "
            "paralarla ödeme alıyor. Katip papirüs tomarına hesap yazıyor."
        ),
        "izler": [
            ("Ödeme aracı",
             "Alışverişte takas yok; üzerinde bir hükümdar portresi basılı "
             "madenî sikkeler kullanılıyor.", True),
            ("Su yapısı",
             "Kemerli su kemerleri (su yolları) şehre kilometrelerce uzaktan "
             "su getiriyor.", True),
            ("Yazı malzemesi",
             "Kayıtlar papirüs tomarlarına ve mumlu tabletlere tutuluyor. "
             "Kâğıt ya da matbaa izi yok.", True),
            ("Yapı tekniği",
             "Yuvarlak kemer ve beton kullanımı yaygın.", False),
        ],
        "belirleyici": "Basılı sikke ve kemerli su yolu birlikteliği",
        "belirleyici_aciklama": (
            "Madenî para, örgütlü bir devlet ve gelişmiş ticaret demektir. "
            "Kemerli su yolları ise büyük ölçekli mühendislik gerektirir. "
            "Kâğıdın ve matbaanın yokluğu üst sınırı belirler."
        ),
        "secim_teshis": (
            "Roma dönemini seçtin. Bu dönemin ayırt edici izleri hükümdar "
            "portresi basılı madenî sikke ile kemerli su yoludur; kayıtta "
            "bunlar geçiyor mu?"
        ),
        "gerekce_teshis": (
            "Bu gerekçe, kayıtta basılı sikke ve kemerli su yolu gördüğünü "
            "söyler. Kayıtta bunlar yoksa gerekçen elindeki kaydı değil, "
            "aklındaki başka bir sahneyi anlatıyor demektir."
        ),
    },
    {
        "ad": "Sanayi Devrimi dönemi",
        "aralik": "yaklaşık 1850",
        "sahne": (
            "Bacalarından duman çıkan uzun bir yapı. İçeride onlarca tezgâh "
            "aynı anda dönüyor; hepsi tavandaki tek bir milden güç alıyor. "
            "Dışarıda demir raylar üzerinde buhar püskürten bir makine "
            "vagonları çekiyor. Duvarda büyük bir saat asılı; işçiler ona "
            "göre giriyor çıkıyor."
        ),
        "izler": [
            ("Güç kaynağı",
             "Tezgâhlar insan ya da hayvan gücüyle değil, buhar makinesiyle "
             "çalışıyor.", True),
            ("Ulaşım",
             "Demir raylar üzerinde buharlı lokomotif; yükler kara yolundan "
             "çok daha hızlı taşınıyor.", True),
            ("Çalışma düzeni",
             "İş, güneşe göre değil duvardaki saate göre bölünmüş. Vardiya "
             "kavramı var.", False),
            ("Haberleşme",
             "Şehirler arasında tel üzerinden işaret gönderen bir düzenek "
             "(telgraf) kullanılıyor.", False),
        ],
        "belirleyici": "Buhar gücüyle çalışan makineler ve demiryolu",
        "belirleyici_aciklama": (
            "Buhar makinesinin üretime ve ulaşıma girmesi Sanayi Devrimi'nin "
            "tanımlayıcı eşiğidir. Bundan önce üretim insan, hayvan, su ve "
            "rüzgâr gücüne dayanıyordu."
        ),
        "secim_teshis": (
            "Sanayi Devrimi'ni seçtin. Bu dönemin eşiği buhar gücünün "
            "üretime ve ulaşıma girmesidir; kayıtta buharla çalışan bir "
            "makine ya da demir ray geçiyor mu?"
        ),
        "gerekce_teshis": (
            "Bu gerekçe, kayıtta buhar makinesi ve demiryolu gördüğünü "
            "söyler. Kayıtta buhar ya da ray yoksa bu gerekçe senin "
            "gözlemine değil, bir başka kayda aittir."
        ),
    },
]


@bulmaca(ders="tarih", konu="donem_tespiti", kademeler=(4, 12), agirlik=1.6)
def kronograf_kaydi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kronograf bir sahne getirdi; hangi çağdan olduğu kanıtlardan çıkarılacak."""
    donem = rastgele.choice(_DONEMLER)
    digerleri = [d for d in _DONEMLER if d["ad"] != donem["ad"]]
    rastgele.shuffle(digerleri)

    kanitlar = [Kanit(etiket, icerik, bedel=2 if kritik else 1, kritik=kritik)
                for etiket, icerik, kritik in donem["izler"]]
    kanitlar.append(Kanit(
        "Kronograf çıktısı",
        "KAYIT ALINDI.\nSüre: 3 dakika 20 saniye.\nDÖNEM: (aygıt bu alanı "
        "boş bırakıyor)", bedel=1))

    return Bulmaca(
        kod="tar-kronograf-kaydi",
        ders="tarih",
        baslik="Kronograf Kaydı",
        kademe=kademe,
        konu="donem_tespiti",
        kazanim="Maddi kalıntılardan dönem çıkarımı; teknolojik eşiklerle tarihlendirme.",
        dikkat=7,
        brifing=(
            "Kronograf yine bir kayıt getirdi. Aygıt hangi çağdan olduğunu "
            "söylemiyor; yalnızca gördüğünü aktarıyor:\n\n"
            "\"{}\"\n\n"
            "Komutan kaydın hangi döneme ait olduğunu arşive yazmamızı "
            "istiyor. \"Tahmin yazma\" diyor, \"neye dayandığını da yaz.\""
        ).format(donem["sahne"]),
        kanitlar=kanitlar,
        adimlar=[
            model_adimi(
                soru="Bir kaydı tarihlendirirken hangi tür iz en güvenilirdir?",
                dogru="Bir teknolojinin VARLIĞI ya da YOKLUĞU; zaman aralığını iki uçtan daraltır.",
                yanlislar={
                    "İnsanların giyimi; kıyafet her dönemde benzerdir.":
                        "Giyimi ölçüt aldın. Kıyafetin kesin bir başlangıç "
                        "tarihi yoktur; benzer bir kumaş yüzyıllar boyunca "
                        "dokunabilir. Bir alet ise ancak icat edildikten "
                        "sonra sahneye girebilir.",
                    "Sahnedeki insan sayısı; kalabalık dönemler daha yenidir, nüfus hep artar.":
                        "Kalabalığı takvim yerine koydun. Bir pazar yeri her "
                        "çağda kalabalık, bir dağ köyü her çağda tenhadır; "
                        "kişi sayısı hiçbir dönemi dışarıda bırakmaz.",
                    "Yapıların büyüklüğü; büyük yapılar her zaman daha yenidir, teknik hep ilerler.":
                        "Büyüklüğü yenilik saydın. Piramitler ve tapınaklar "
                        "çok eski oldukları hâlde devasadır; boyut, yapının "
                        "hangi tarihten sonra mümkün olduğunu söylemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarihlendirmenin mantığı şu: bir nesne ancak icat edildikten "
                    "sonra kullanılabilir. Yazılı tabletin bulunması kaydı yazının "
                    "icadından SONRAYA taşır; demir silahın hiç bulunmaması ise "
                    "Demir Çağı'ndan ÖNCEYE. İki iz birleşince aralık daralır. "
                    "Yapı büyüklüğü ya da kalabalık böyle kesin bir sınır vermez."
                ),
                ipuclari=[
                    "Bir nesne icat edilmeden kullanılabilir mi? Bu sana ne söyler?",
                    "Bir şeyin YOK olması da bilgi verir: henüz bilinmiyor olabilir.",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="Bu kayıt hangi döneme aittir?",
                dogru="{} ({})".format(donem["ad"], donem["aralik"]),
                yanlislar={"{} ({})".format(d["ad"], d["aralik"]):
                           d["secim_teshis"] for d in digerleri},
                rastgele=rastgele,
                aciklama="Belirleyici iz: {}. {}".format(
                    donem["belirleyici"], donem["belirleyici_aciklama"]),
                ipuclari=[
                    "Kayıtta hangi teknoloji VAR, hangisi YOK? İkisini birlikte düşün.",
                    "En eski ve en yeni ihtimali ele, ortada kalanı karşılaştır.",
                ],
                puan=18,
            ),
            secim_adimi(
                soru="Arşive yazacağın gerekçe hangisi olmalı?",
                dogru=donem["belirleyici"],
                yanlislar={
                    d["belirleyici"]: d["gerekce_teshis"] for d in digerleri
                },
                rastgele=rastgele,
                aciklama=donem["belirleyici_aciklama"],
                ipuclari=["Kararını hangi tek gözlem olmadan veremezdin?"],
                puan=14,
            ),
            yorum_adimi(
                soru="Kayıtta hiç yazı görülmemesi ne anlama gelir?",
                dogru="Ya yazıdan öncedir ya da o toplulukta yazı yoktur; kesin tarih değil, sınır verir.",
                yanlislar={
                    "Kesinlikle yazının icadından öncedir; yazı bir kez bulununca her topluluk onu kullanır.":
                        "Sınırı kesinliğe çevirdin. Yazı görülmemesi güçlü bir "
                        "işarettir ama tek başına kanıt değildir: yazının "
                        "bilindiği çağlarda da onu kullanmayan topluluklar vardı.",
                    "Hiçbir şey ifade etmez; yazı her dönemde ender bulunur, yokluğu kanıt sayılmaz.":
                        "Bu sefer izi tümden attın. Bir şeyin bulunmaması da "
                        "bilgidir; kaydı yazının icadından öncesine doğru çeker.",
                    "Kaydın sahte olduğunu gösterir.":
                        "Eksik kanıtı sahtelik saydın. Bir izin görülmemesi "
                        "aygıtı yalancı çıkarmaz; yalnızca kaydın hangi çağdan "
                        "gelebileceğini daraltır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kanıtın yokluğu, yokluğun kanıtı değildir. Yazı görülmemesi "
                    "kaydı tarih öncesine YAKLAŞTIRIR, ama aynı dönemde yazıyı "
                    "kullanmayan topluluklar da vardı. İyi bir tarihçi bunu "
                    "'kesin' değil 'kuvvetle muhtemel' diye yazar."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Arşiv fişine yazıldı: {} ({}). Gerekçe hanesi de dolduruldu; "
            "Kronograf'ın söylemediğini biz yazdık."
        ).format(donem["ad"], donem["aralik"]),
        odul={"itibar": 8, "enerji": 4},
    )


@bulmaca(ders="tarih", konu="anakronizm", kademeler=(5, 12))
def anakronizm_avi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kronograf transkripti bozulmuş; başka çağlardan cümleler karışmış."""
    donemine_uygun = [
        "Tüccar, tunçtan dövülmüş baltayı tezgâhın üstüne koydu.",
        "Kâtip ıslak kil tablete çivi yazısıyla borcu işledi.",
        "Eşeğin heybesinde arpa ve mercimek vardı.",
        "Rahip, tapınağın önünde tören için hazırlık yapıyordu.",
        "Bir kadın koyun yününü elinde eğirip iplik yapıyordu.",
    ]
    anakronizmler = [
        "Adam cebinden çıkardığı saate bakıp geç kaldığını anladı.",
        "Çocuklar meydanın kenarında patates közlüyordu.",
        "Bir kadın matbaadan yeni çıkmış duyuru kâğıdını yüksek sesle okudu.",
        "Kervancı, gelen haberi telgrafla merkeze bildirdi.",
    ]
    secilen_uygun = rastgele.sample(donemine_uygun, 4)
    secilen_yanlis = rastgele.sample(anakronizmler, 3)
    secenekler, dogru_indeksler = coklu_siklar(rastgele, secilen_yanlis, secilen_uygun)

    return Bulmaca(
        kod="tar-anakronizm",
        ders="tarih",
        baslik="Bozuk Transkript",
        kademe=kademe,
        konu="anakronizm",
        kazanim="Anakronizmi fark etme; nesnelerin tarihsel sırasını kavrama.",
        dikkat=6,
        brifing=(
            "Kronograf bu sefer bir ses kaydı getirdi ve aygıt onu kendiliğinden "
            "yazıya döktü. Kayıt, Tunç Çağı'nda bir Anadolu kasabasının pazar "
            "yerinden (yaklaşık MÖ 1800).\n\n"
            "Ama transkriptte bir tuhaflık var: aygıt başka kayıtlardan "
            "cümleler karıştırmış. Bazı cümleler o çağda geçmesi mümkün olmayan "
            "şeyler anlatıyor.\n\n"
            "Arşive temiz bir metin bırakmadan önce yabancı cümleleri ayıklaman "
            "gerekiyor."
        ),
        kanitlar=[
            Kanit("Teknoloji tarihi çizelgesi",
                  "Kâğıt: MS 100'ler (Çin)\n"
                  "Matbaa (Avrupa): 1450'ler\n"
                  "Taşınabilir mekanik saat: 1500'ler\n"
                  "Telgraf: 1800'ler",
                  bedel=2, kritik=True),
            Kanit("Tarım tarihi notu",
                  "Patates, domates, mısır ve kakao Amerika kıtasına özgüdür; "
                  "Avrupa ve Asya'ya 1492'den sonra ulaşmıştır.",
                  bedel=2, kritik=True),
            Kanit("Tunç Çağı el kitabı",
                  "Bu dönemde: tunç aletler, çivi yazılı kil tablet, dokuma, "
                  "arpa-buğday-mercimek tarımı, koyun-keçi besisi yaygındır.",
                  bedel=1, kritik=True),
            Kanit("Aygıt arıza kaydı",
                  "Kronograf son bakımdan beri farklı kayıtları birbirine "
                  "karıştırıyor. Karışan cümle sayısı her seferinde değişiyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir cümlenin döneme ait olmadığını nasıl anlarız?",
                dogru="Cümledeki nesne ya da uygulama o tarihte var mıydı, ona bakarız.",
                yanlislar={
                    "Cümlenin diline bakarız, çünkü eski dönemde insanlar kısa cümle kurardı.":
                        "Üslubu ölçüt aldın. Transkripti bugünkü dile döken "
                        "aygıttır; cümlenin uzunluğu konuşana değil, çeviriye "
                        "aittir. Dönemi ele veren şey cümledeki nesnedir.",
                    "Cümlede geçen kişi sayısına bakarız; eski pazarlar daha tenhaydı.":
                        "Kişi sayısını takvim yerine koydun. Bir pazar yerinde "
                        "her çağda kalabalık olabilir; bu sayı hiçbir tarihi "
                        "dışarıda bırakmaz.",
                    "Şaşırtıcı cümle anakronizmdir; sıradan olan dönemine uyar.":
                        "Şaşırtıcılığı ölçüt saydın. \"Adam saatine baktı\" "
                        "cümlesi hiç şaşırtıcı değildir ama MÖ 1800'de "
                        "imkânsızdır; sıradan görünmek döneme uygunluk demek "
                        "değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Anakronizm, bir şeyin kendi zamanından önce görünmesidir. "
                    "Tespit yöntemi tek bir soruya iner: bu nesne o tarihte var "
                    "mıydı? Cümlenin üslubu ya da inandırıcılığı ölçüt değildir; "
                    "çok doğal görünen bir cümle de anakronizm taşıyabilir."
                ),
                ipuclari=[
                    "Her cümledeki NESNEYİ tek tek çıkar: saat, patates, kâğıt...",
                    "Çizelgeye bakıp o nesnenin tarihini MÖ 1800 ile karşılaştır.",
                ],
                puan=18,
            ),
            coklu_adimi(
                soru=("Aşağıdaki cümlelerden hangileri MÖ 1800'e ait OLAMAZ? "
                      "(numaralarını yaz)"),
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Ayıklananlar ve gerekçeleri:\n"
                    "- Cep saati: taşınabilir mekanik saat 1500'lerden sonra.\n"
                    "- Patates: Amerika kıtasına özgü, Eski Dünya'ya 1492'den sonra.\n"
                    "- Matbaa kâğıdı: Avrupa'da matbaa 1450'ler.\n"
                    "- Telgraf: 1800'ler.\n"
                    "Kalan cümlelerdeki tunç, çivi yazısı, arpa, yün eğirme ise "
                    "Tunç Çağı Anadolu'suyla tam uyumludur."
                ),
                ipuclari=[
                    "Dört cümlede de dönemine uymayan tek bir nesne var; onu bul.",
                    "Amerika kıtasından gelen bitkileri unutma.",
                ],
                puan=20,
            ),
            yorum_adimi(
                soru="Patatesli cümle neden anakronizmdir?",
                dogru="Patates Amerika kökenlidir; Anadolu'ya 1492'den sonra ulaşmıştır.",
                yanlislar={
                    "Patates o dönemde vardı ama yalnızca zenginler yerdi.":
                        "Sorunu bulunabilirlik sandın. Patates o tarihte "
                        "Anadolu'da pahalı değildi; mesele kimin yediği değil, "
                        "bitkinin bu kıtaya henüz hiç ulaşmamış olması.",
                    "Patates pişirmek için gerekli kap kacak henüz yoktu; o çağda tencere bilinmiyordu.":
                        "Engeli mutfakta aradın. Tunç Çağı'nda pişirme kabı "
                        "vardı; eksik olan kap değil, bitkinin kendisi.",
                    "Anakronizm değildir; patates Anadolu'nun yerli bitkisidir, köylerde hep ekilir.":
                        "Bitkinin anavatanını karıştırdın. Tarım tarihi notu "
                        "patatesin Amerika kıtasına özgü olduğunu ve Eski "
                        "Dünya'ya sonradan geldiğini söylüyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bugün mutfağımızın doğal parçası saydığımız pek çok ürün "
                    "(patates, domates, mısır, biber, kakao) Amerika kıtasından "
                    "gelmiştir. Kıtalar arası bu bitki alışverişi, Coğrafi "
                    "Keşifler'in en kalıcı sonuçlarından biridir."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Transkript temizlendi ve arşive kondu. Kronograf'ın bakımı için "
            "de talep açıldı."
        ),
        odul={"itibar": 7, "enerji": 3},
    )


# ==========================================================================
# TARİH ARİTMETİĞİ
# ==========================================================================

@bulmaca(ders="tarih", konu="tarih_aritmetigi", kademeler=(4, 9))
def yuzyil_hesabi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yıldan yüzyıla geçiş; 'yüzyıl, yılın ilk iki hanesi değildir' tuzağı."""
    yil = rastgele.choice([1071, 1176, 1453, 1492, 1789, 1839, 1923, 1200, 1600])
    yuzyil = (yil - 1) // 100 + 1
    yanlis_yuzyil = yil // 100
    olay = {
        1071: "Malazgirt Savaşı", 1176: "Miryokefalon Savaşı",
        1453: "İstanbul'un fethi", 1492: "Amerika kıtasına ulaşılması",
        1789: "Fransız İhtilali", 1839: "Tanzimat Fermanı",
        1923: "Cumhuriyet'in ilanı", 1200: "bir vakıf kaydının yazılması",
        1600: "bir ticaret antlaşmasının imzalanması",
    }[yil]

    return Bulmaca(
        kod="tar-yuzyil-hesabi",
        ders="tarih",
        baslik="Arşiv Fişi",
        kademe=kademe,
        konu="tarih_aritmetigi",
        kazanim="Yıl-yüzyıl dönüşümü; yüzyılların 1'den başlayarak sayılması.",
        dikkat=5,
        brifing=(
            "Arşivdeki fişler yüzyıla göre dizilecek. Elindeki fişte yalnızca "
            "yıl yazıyor: {} ({}).\n\n"
            "Yardımcı memur fişi \"{}. yüzyıl\" rafına koymuş; \"yılın ilk iki "
            "rakamı, bakması bile kolay\" diyor.\n\n"
            "Ama arşiv sorumlusu bu yerleştirmeden emin değil. Doğrusunu "
            "belirlemen gerekiyor."
        ).format(yil, olay, yanlis_yuzyil),
        kanitlar=[
            Kanit("Arşiv yönergesi",
                  "\"Yüzyıllar 1. yüzyıldan başlar. 1. yüzyıl 1-100 yıllarını, "
                  "2. yüzyıl 101-200 yıllarını kapsar ve böyle devam eder.\"",
                  bedel=2, kritik=True),
            Kanit("Örnek fiş - 100",
                  "100 yılı: 1. yüzyıl (çünkü 1-100 aralığındadır)",
                  bedel=1, kritik=True),
            Kanit("Örnek fiş - 101",
                  "101 yılı: 2. yüzyıl (çünkü 101-200 aralığındadır)",
                  bedel=1, kritik=True),
            Kanit("Yardımcı memurun notu",
                  "\"Yılın ilk iki rakamı yüzyılı verir. {} yılı {}. yüzyıl "
                  "olur.\"".format(yil, yanlis_yuzyil), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir yılın hangi yüzyıla ait olduğunu ne belirler?",
                dogru="Yılın düştüğü yüz yıllık aralık; aralıklar 1-100, 101-200 diye gider.",
                yanlislar={
                    "Yılın ilk iki rakamı doğrudan yüzyılı verir; 1453 yılı 14. yüzyıldır.":
                        "Memurun ezberini kural yerine koydun. Bu yol yılın "
                        "YAZILIŞINA bakıyor; yönerge ise yılın hangi yüz "
                        "yıllık aralığa düştüğünü soruyor. İkisi aynı şey değil.",
                    "Yıl 100'e bölünür, çıkan tam sayı yüzyıldır; 250 yılı 2. yüzyıldır.":
                        "Bölmenin sonucunu doğrudan yüzyıl saydın. O bölme sana "
                        "kaç tam yüzlüğün geride kaldığını söyler; yıl ise "
                        "içinde bulunduğu aralığa göre adlandırılır.",
                    "Yıl 100'e bölünüp sonuç aşağı yuvarlanır.":
                        "Aşağı yuvarlama, bir aralığın ilk yılını hâlâ bir "
                        "önceki yüzyılda sayar: yönergeye göre 101 yılı 2. "
                        "yüzyılın ilk yılıdır, bu kural onu 1. yüzyılda bırakır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sayım 0'dan değil 1'den başladığı için ilk yüzyıl 1-100 "
                    "yıllarını kapsar. Bu yüzden 100 yılı hâlâ 1. yüzyıldadır, "
                    "101 ise 2. yüzyıla geçer. 'İlk iki rakam' kuralı yalnızca "
                    "tam yüzlük yıllarda tutar; öteki yıllarda bir eksik verir."
                ),
                ipuclari=[
                    "1. yüzyıl hangi yıllarla başlar ve biter?",
                    "100 yılı 1. yüzyılda mı 2. yüzyılda mı? Yönergeye bak.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="{} yılı kaçıncı yüzyıldadır? (yalnızca sayı yaz)".format(yil),
                cevap=yuzyil,
                birim="",
                aciklama=(
                    "{} yılı, {}-{} aralığına düşer; bu da {}. yüzyıldır. "
                    "Yardımcı memurun bulduğu {} {}."
                ).format(yil, (yuzyil - 1) * 100 + 1, yuzyil * 100, yuzyil, yanlis_yuzyil,
                         "yanlıştır" if yanlis_yuzyil != yuzyil else
                         "bu kez tesadüfen tutuyor, çünkü yıl tam yüzlük"),
                ipuclari=[
                    "Yıldan 1 çıkar, 100'e böl, tam kısmı al, 1 ekle.",
                    "Ya da: yıl hangi yüzlük aralığa düşüyor diye bak.",
                ],
                puan=14,
            ),
            secim_adimi(
                soru="Memurun kuralı hangi yıllarda yanlış sonuç verir?",
                dogru="Tam yüzlük olmayan her yılda; 1453 için 14 der.",
                yanlislar={
                    "Bütün yıllarda yanlış sonuç verir.":
                        "Kuralı tümden yanlış saydın. Tam yüzlük yıllarda "
                        "tutar: 1500 gerçekten 15. yüzyılın son yılıdır.",
                    "Yalnızca 100'ün tam katı olan yıllarda.":
                        "Tersini söyledin. Tam yüzlük yıllar kuralın tuttuğu "
                        "tek yerdir; 1453 gibi öteki yıllarda bir eksik verir.",
                    "Hiçbir zaman yanlış sonuç vermez; kural doğrudur.":
                        "Kuralı sınamadan kabul ettin. 1453 yılı 1401-1500 "
                        "aralığındadır, yani 15. yüzyıldır; ilk iki rakam 14 der.",
                },
                rastgele=rastgele,
                aciklama=(
                    "1453 için memurun kuralı 14 der, doğrusu 15'tir - yani kural "
                    "aslında hemen her yılda bir eksik verir. Tam yüzlük yıllarda "
                    "ise (1500 gibi) tesadüfen doğru sonucu verir: 1500 gerçekten "
                    "15. yüzyıldadır. Kural tersine dönmüş bir ezberdir."
                ),
                ipuclari=["Kuralı 1500 ve 1501 yıllarında ayrı ayrı dene."],
                puan=12,
            ),
        ],
        kapanis="Fiş {}. yüzyıl rafına kaldırıldı; yönerge de panoya asıldı.".format(yuzyil),
        odul={"itibar": 5},
    )


@bulmaca(ders="tarih", konu="tarih_aritmetigi", kademeler=(6, 12))
def mo_ms_araligi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """MÖ-MÖ farkı çıkarma; MÖ-MS farkı toplama ve bir eksiği (sıfır yılı yok).

    11 Eylül 2026 DÜZELTMESİ: kanıt "takvimde sıfır yılı yoktur" diyor,
    model adımı eksi sayı yaklaşımının "çağ geçişlerinde bir yıl fazla"
    saydıracağını söylüyordu -- ama cevap anahtarı düz `kuruluş + yıkılış`
    idi, yani tam o bir yıl fazlayı doğru sayıyordu. Artık MÖ 1 -> MS 1 bir
    yıldır ve cevap `kuruluş + yıkılış - 1`. Eski cevap teşhisli bir yanlış
    olarak kaldı (ChatGPT incelemesi; GOREVLER B36). Tarih öğretmenine
    onaylatılacak: ders kitabının kullandığı kural bu olmalı.
    """
    mo_kurulus = rastgele.choice([700, 650, 600, 550, 500])
    mo_olay = mo_kurulus - rastgele.choice([120, 150, 200, 250])
    ms_yikilis = rastgele.choice([100, 200, 250, 300])
    mo_fark = mo_kurulus - mo_olay
    # Sıfır yılı yok: MÖ 1'den MS 1'e bir yıl geçer, iki değil.
    toplam_omur = mo_kurulus + ms_yikilis - 1

    return Bulmaca(
        kod="tar-mo-ms",
        ders="tarih",
        baslik="Sıfırsız Takvim",
        kademe=kademe,
        konu="tarih_aritmetigi",
        kazanim="MÖ-MS zaman aralığı hesabı; takvimin sıfır noktasının anlamı.",
        dikkat=6,
        brifing=(
            "Kronograf'ın getirdiği kayıtlar arşivde bir zaman şeridine "
            "dizilecek. Elimizde bir kent devletinin üç tarihi var:\n\n"
            "  Kuruluş: MÖ {}\n"
            "  Surların yapımı: MÖ {}\n"
            "  Yıkılış: MS {}\n\n"
            "Yardımcı memur \"hepsi sayı, çıkarırız olur biter\" deyip kuruluş "
            "ile yıkılış arasını {} yıl yazmış. Sorumlu bu sayıya itiraz ediyor."
        ).format(mo_kurulus, mo_olay, ms_yikilis, mo_kurulus - ms_yikilis),
        kanitlar=[
            Kanit("Takvim yönergesi",
                  "\"Takvimde sıfır yılı yoktur: MÖ 1'den hemen sonra MS 1 "
                  "gelir. Sayım başlangıç noktasından geriye (MÖ) ve ileriye "
                  "(MS) doğru ayrı ayrı ilerler. MÖ yıllarında sayı BÜYÜDÜKÇE "
                  "tarih ESKİLEŞİR.\"",
                  bedel=2, kritik=True),
            Kanit("Zaman şeridi çizimi",
                  "MÖ 700 ---- MÖ 500 ---- MÖ 100 ---- | ---- MS 100 ---- MS 300\n"
                  "Ok, soldan sağa doğru zamanın akışını gösteriyor.",
                  bedel=2, kritik=True),
            Kanit("Arşiv fişi",
                  "Kuruluş MÖ {}, surlar MÖ {}, yıkılış MS {}.".format(
                      mo_kurulus, mo_olay, ms_yikilis),
                  bedel=1, kritik=True),
            Kanit("Memurun hesabı",
                  "\"MÖ {} eksi MS {} eşittir {}.\"".format(
                      mo_kurulus, ms_yikilis, mo_kurulus - ms_yikilis), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İki tarih arasındaki süreyi hesaplarken hangi kural geçerlidir?",
                dogru=("Aynı çağda ÇIKARILIR; çağ değişiyorsa TOPLANIR, sıfır yılı "
                       "olmadığından 1 çıkarılır."),
                yanlislar={
                    "Her durumda büyük sayıdan küçük sayı çıkarılır; süre hep bir farktır.":
                        "Tek bir kuralla her durumu çözmeye çalıştın. MÖ "
                        "tarihlerinde büyük sayı DAHA ESKİdir; çıkarma yönü "
                        "çağa göre değişir.",
                    "Her durumda iki sayı toplanır.":
                        "Toplama yalnızca çağ değiştiren hesaplarda anlamlı. "
                        "Aynı çağdaki iki tarihte toplama, olmayan bir süre "
                        "üretir.",
                    "MÖ tarihleri eksi işaretli sayılır ve normal çıkarma yapılır; takvim bir sayı doğrusudur.":
                        "İyi bir fikir ama bir tuzağı var: takvimde sıfır yılı "
                        "yok. Eksi sayı gibi işlem yaparsan çağ geçişlerinde "
                        "bir yıl fazla sayarsın.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zaman şeridinde MÖ tarihleri başlangıç noktasının solunda, MS "
                    "tarihleri sağındadır. İki nokta aynı taraftaysa aralarındaki "
                    "mesafe farktır. Ayrı taraflardaysa iki mesafe toplanır; ama "
                    "takvimde sıfır yılı olmadığı için MÖ 1'den MS 1'e yalnızca bir "
                    "yıl geçer, bu yüzden toplamdan 1 çıkarılır. Çıkarma yapmak ise "
                    "süreyi olduğundan çok kısa gösterir."
                ),
                ipuclari=[
                    "Zaman şeridini gözünde canlandır: iki tarih başlangıcın aynı "
                    "tarafında mı, ayrı taraflarında mı?",
                    "Sıfır yılı yok: MÖ 1'den MS 1'e kaç yıl geçer?",
                ],
                puan=20,
            ),
            sayi_adimi(
                soru="Kuruluştan sur yapımına kadar kaç yıl geçmiş?",
                cevap=mo_fark,
                birim="yıl",
                aciklama=(
                    "İkisi de MÖ olduğu için çıkarma yapılır: {} − {} = {} yıl. "
                    "MÖ {} tarihi, MÖ {} tarihinden daha yenidir; çünkü MÖ'de sayı küçüldükçe "
                    "tarih yaklaşır."
                ).format(mo_kurulus, mo_olay, mo_fark, mo_olay, mo_kurulus),
                ipuclari=["İki tarih de aynı çağda. Hangi işlem gerekir?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Kent devleti toplam kaç yıl ayakta kalmış?",
                cevap=toplam_omur,
                birim="yıl",
                aciklama=(
                    "Kuruluş MÖ {}, yıkılış MS {}. Farklı çağlarda oldukları için "
                    "toplanır ve sıfır yılı olmadığı için 1 çıkarılır: "
                    "{} + {} − 1 = {} yıl. Memurun bulduğu {} sayısı, şeridin bir "
                    "yarısını hiç saymadığı için yanlıştır."
                ).format(mo_kurulus, ms_yikilis, mo_kurulus, ms_yikilis,
                         toplam_omur, mo_kurulus - ms_yikilis),
                ipuclari=[
                    "Tarihler başlangıç noktasının iki ayrı yanında.",
                    "Başlangıca kadar geçen süre + başlangıçtan sonraki süre; "
                    "sonra sıfır yılı olmadığını hatırla.",
                ],
                yaygin_yanlislar={
                    mo_kurulus + ms_yikilis:
                        "Toplama doğru, ama takvimde sıfır yılı yok: MÖ 1'den "
                        "MS 1'e iki değil bir yıl geçer. Bir yıl fazla saydın.",
                    mo_kurulus - ms_yikilis:
                        "Memurun hatası: farklı çağdaki iki tarih çıkarılmaz, "
                        "şeridin iki yanı ayrı ayrı sayılır.",
                },
                puan=16,
            ),
            yorum_adimi(
                soru="MÖ 300 ile MÖ 100 tarihlerinden hangisi daha eskidir?",
                dogru="MÖ 300; MÖ'de sayı büyüdükçe tarih eskiye gider.",
                yanlislar={
                    "MÖ 100; her zaman büyük sayı daha yenidir, 300 yılı 100'den sonradır.":
                        "MS tarihlerindeki alışkanlığı MÖ'ye taşıdın. MÖ "
                        "sayıları geriye doğru sayar: sayı büyüdükçe tarih "
                        "ESKİLEŞİR.",
                    "İkisi aynı yaştadır, yalnızca yazımları farklıdır.":
                        "İki farklı yılı aynı saydın. MÖ 300 ile MÖ 100 "
                        "arasında iki yüz yıl var.",
                    "Belirlenemez; MÖ tarihleri karşılaştırılamaz.":
                        "MÖ tarihleri pekâlâ karşılaştırılır; yalnızca "
                        "sıralama yönü terstir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "MÖ, 'başlangıçtan kaç yıl önce' demektir. 300 yıl önce, 100 yıl "
                    "önceden daha eskidir. MS tarihlerinde ise tam tersi işler. "
                    "Bu ters yön, MÖ hesaplarında yapılan hataların çoğunun kaynağıdır."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Zaman şeridi düzeltildi: kent devleti {} yıl ayakta kalmış. Memurun "
            "hesabı da örnek olarak panoya asıldı - yanlışıyla birlikte."
        ).format(toplam_omur),
        odul={"itibar": 6, "enerji": 3},
    )


# ==========================================================================
# KRONOLOJİ, NEDEN-SONUÇ, KAYNAK
# ==========================================================================

@bulmaca(ders="tarih", konu="kronoloji", kademeler=(5, 12))
def kronolojik_siralama(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kronograf kayıtları karışık geldi; zaman sırasına dizilecek."""
    havuz = [
        ("Sümerlerde çivi yazısının kullanılmaya başlanması", -3200),
        ("Anadolu'da Hitit Devleti'nin kurulması", -1650),
        ("Lidyalıların madenî parayı kullanmaya başlaması", -600),
        ("Kâğıdın Çin'de üretilmesi", 105),
        ("Malazgirt Savaşı", 1071),
        ("İstanbul'un fethi", 1453),
        ("Fransız İhtilali", 1789),
        ("Türkiye Cumhuriyeti'nin ilanı", 1923),
    ]
    adet = 4 if kademe <= 6 else 5
    secilen = rastgele.sample(havuz, adet)
    rastgele.shuffle(secilen)
    secenekler = [ad for ad, _ in secilen]
    sirali = sorted(range(len(secilen)), key=lambda i: secilen[i][1])

    def yil_metni(yil):
        return "MÖ {}".format(-yil) if yil < 0 else "MS {}".format(yil)

    dogru_liste = "; ".join(
        "{} ({})".format(secilen[i][0], yil_metni(secilen[i][1])) for i in sirali)

    return Bulmaca(
        kod="tar-kronoloji",
        ders="tarih",
        baslik="Karışan Kayıtlar",
        kademe=kademe,
        konu="kronoloji",
        kazanim="Olayları kronolojik sıraya koyma; MÖ-MS sıralamasını doğru kurma.",
        dikkat=6,
        brifing=(
            "Kronograf gece boyunca çalışmış ve {} ayrı kayıt getirmiş. Ama "
            "kayıtlar sırasız: aygıt hangisini önce aldığını not etmemiş.\n\n"
            "Arşivde kayıtlar zaman sırasına göre dizilir; sırasız kayıt hiçbir "
            "işe yaramaz, çünkü hangisinin hangisine sebep olduğunu göremeyiz.\n\n"
            "Kayıtları eskiden yeniye doğru sıraya dizmen gerekiyor."
        ).format(adet),
        kanitlar=[
            Kanit("Arşiv yönergesi",
                  "\"Sıralama eskiden yeniye yapılır. MÖ tarihleri MS "
                  "tarihlerinden önce gelir; MÖ içinde sayı büyük olan daha "
                  "eskidir.\"", bedel=1, kritik=True),
            Kanit("Dönem çizelgesi",
                  "İlk Çağ: yazının bulunuşundan (MÖ 3200) Roma'nın "
                  "ikiye ayrılmasına (MS 395)\n"
                  "Orta Çağ: 395 - 1453\n"
                  "Yeni Çağ: 1453 - 1789\n"
                  "Yakın Çağ: 1789 - günümüz",
                  bedel=2, kritik=True),
            Kanit("Kronograf günlüğü",
                  "Kayıtların hepsi alınmış ve okunabiliyor; yalnızca sıraları "
                  "kayıp.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kayıtları sıralarken neye göre karar vereceksin?",
                dogru="Çağına ve yılına; MÖ kayıtları önce, MÖ içinde büyük sayı önce gelir.",
                yanlislar={
                    "Kayıtların uzunluğuna; kısa kayıtlar daha eskidir.":
                        "Metin uzunluğunu tarih ölçüsü saydın. Bir olayın kaç "
                        "cümleyle anlatıldığının ne zaman olduğuyla ilgisi yok.",
                    "Kayıtların önem sırasına; büyük olaylar önce yazılır.":
                        "Önemi zamanla karıştırdın. Sıralama olayların "
                        "büyüklüğüne göre değil, gerçekleştikleri ana göre "
                        "yapılır.",
                    "Sayısal büyüklüğe; küçük sayıdan büyüğe dizilir, sayılar zamanla büyür.":
                        "Sayıları düz sıraladın. MÖ tarihlerinde büyük sayı "
                        "daha eskidir; bu yüzden tek başına sayı sırası "
                        "yanıltır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kronoloji tek bir eksene dayanır: zaman. MÖ tarafında sayı "
                    "büyüdükçe geriye gidildiği için sıralama orada tersine döner. "
                    "Doğrudan 'küçükten büyüğe' dizmek MÖ kayıtlarını ters çevirir."
                ),
                ipuclari=[
                    "MÖ 3200 mü daha eski, MÖ 600 mü?",
                    "Önce her kaydın yılını yaz, sonra sırala.",
                ],
                puan=18,
            ),
            sirala_adimi(
                soru="Kayıtları en eskiden en yeniye doğru sırala (numaralarını sırayla yaz):",
                secenekler=secenekler,
                dogru_sira=sirali,
                aciklama="Doğru sıra: " + dogru_liste,
                ipuclari=[
                    "Önce MÖ olanları ayır; onlar mutlaka başta.",
                    "MÖ olanları kendi içinde büyükten küçüğe diz.",
                ],
                puan=22,
            ),
            secim_adimi(
                soru="Bu sıralamadaki en eski kayıt hangi çağa aittir?",
                dogru=(
                    "Tarih öncesi (yazıdan önce)"
                    if secilen[sirali[0]][1] < -3200 else
                    ("İlk Çağ (Antik Çağ)" if secilen[sirali[0]][1] < 395 else
                     ("Orta Çağ" if secilen[sirali[0]][1] < 1453 else
                      ("Yeni Çağ" if secilen[sirali[0]][1] < 1789 else "Yakın Çağ")))
                ),
                yanlislar={
                    "Tarih öncesi (yazıdan önce)":
                        "Tarih öncesi, yazının bulunmasından ÖNCEsidir. "
                        "Elindeki kayıt yazılı olduğuna göre bu çağın dışında.",
                    "İlk Çağ (Antik Çağ)":
                        "Çizelgedeki İlk Çağ aralığına bak; bu tarih o "
                        "aralığın içine düşmüyor.",
                    "Orta Çağ":
                        "Çizelgedeki Orta Çağ aralığına bak; bu tarih o "
                        "aralığın içine düşmüyor.",
                    "Yeni Çağ":
                        "Çizelgedeki Yeni Çağ aralığına bak; bu tarih o "
                        "aralığın içine düşmüyor.",
                    "Yakın Çağ":
                        "Yakın Çağ çizelgenin en son dilimi. En ESKİ kayıt "
                        "sorulmuştu; en yeni çağa bakıyorsun.",
                },
                rastgele=rastgele,
                aciklama=(
                    "En eski kayıt: {} ({}). Dönem çizelgesine göre bu tarih ilgili "
                    "çağın sınırları içindedir. Çağlar, tarihçilerin sonradan koyduğu "
                    "sınırlardır; o çağda yaşayanlar kendilerini öyle adlandırmıyordu."
                ).format(secilen[sirali[0]][0], yil_metni(secilen[sirali[0]][1])),
                ipuclari=["Dönem çizelgesindeki tarih aralıklarına bak."],
                puan=12,
            ),
        ],
        kapanis="Kayıtlar sıraya dizildi ve arşive kaldırıldı.",
        odul={"itibar": 6, "enerji": 4},
    )


@bulmaca(ders="tarih", konu="neden_sonuc", kademeler=(7, 13))
def neden_mi_sonuc_mu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir olayın nedenleri ile sonuçları karışmış."""
    nedenler = [
        "Pusula ve gemicilik bilgisinin gelişmesi",
        "İpek ve Baharat yollarının Avrupalılar için güvenli olmaktan çıkması",
        "Doğu ülkelerinin zenginliğine dair anlatıların yayılması",
        "Cesur gemicilerin ve onları destekleyen krallıkların ortaya çıkması",
    ]
    sonuclar = [
        "Atlas Okyanusu limanlarının önem kazanması, Akdeniz limanlarının gerilemesi",
        "Avrupa'ya değerli maden ve yeni bitkilerin (patates, mısır) akması",
        "Sömürge imparatorluklarının kurulması",
        "Kilise ve din adamlarının otoritesinin sarsılması",
    ]
    secilen_neden = rastgele.sample(nedenler, 3)
    secilen_sonuc = rastgele.sample(sonuclar, 3)
    secenekler, dogru_indeksler = coklu_siklar(rastgele, secilen_neden, secilen_sonuc)

    return Bulmaca(
        kod="tar-neden-sonuc",
        ders="tarih",
        baslik="Sebep Defteri",
        kademe=kademe,
        konu="neden_sonuc",
        kazanim="Tarihsel olaylarda neden ile sonucu ayırt etme.",
        dikkat=6,
        brifing=(
            "Arşivde Coğrafi Keşifler için hazırlanmış bir defter var. Defterin "
            "sol sayfasına \"nedenler\", sağ sayfasına \"sonuçlar\" yazılacakmış.\n\n"
            "Ama defteri tutan kişi acele etmiş: maddeleri alt alta tek bir "
            "listeye yazmış, hangisinin neden hangisinin sonuç olduğunu "
            "belirtmemiş.\n\n"
            "Komutan bu defteri merkeze gönderecek. Ayırmamız gerekiyor."
        ),
        kanitlar=[
            Kanit("Arşiv notu",
                  "\"Neden, olaydan ÖNCE var olan ve olayı hazırlayan durumdur. "
                  "Sonuç, olaydan SONRA ortaya çıkan değişikliktir.\"",
                  bedel=2, kritik=True),
            Kanit("Zaman kontrolü",
                  "\"Bir maddenin neden mi sonuç mu olduğunu anlamak için sor: "
                  "bu durum keşifler başlamadan önce de var mıydı, yoksa "
                  "keşifler yüzünden mi ortaya çıktı?\"",
                  bedel=2, kritik=True),
            Kanit("Defter sayfası",
                  "Sol sayfa: NEDENLER (boş)\nSağ sayfa: SONUÇLAR (boş)\n"
                  "Maddeler arka sayfaya karışık yazılmış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir maddenin neden mi sonuç mu olduğunu ne belirler?",
                dogru="Olaya göre zamanı: önceki durum neden, sonraki değişiklik sonuçtur.",
                yanlislar={
                    "Maddenin önemi: büyük etkiler sonuç, küçükler nedendir.":
                        "Büyüklüğü ölçüt saydın. Küçük bir gelişme de büyük "
                        "bir olayı başlatabilir; belirleyici olan ZAMAN "
                        "sırası, boyut değil.",
                    "Maddenin olumlu ya da olumsuz olması: olumsuzlar nedendir, sorunlar olayı başlatır.":
                        "İyi-kötü ayrımını neden-sonuç ayrımı yerine koydun. "
                        "Olumlu bir gelişme de bir olayın nedeni olabilir.",
                    "Maddenin uzunluğu ve ayrıntı düzeyi.":
                        "Metnin biçimine baktın. Bir maddenin neden mi sonuç "
                        "mu olduğu, olayın öncesinde mi sonrasında mı "
                        "gerçekleştiğine bağlıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Neden-sonuç ilişkisinin belirleyicisi zaman yönüdür. Aynı "
                    "cümle bir olayın sonucu, başka bir olayın nedeni olabilir; "
                    "bu yüzden 'hangi olaya göre' diye sormak gerekir. Önem, "
                    "büyüklük ya da olumluluk bu ayrımı kurmaz."
                ),
                ipuclari=[
                    "Kendine sor: bu durum keşifler BAŞLAMADAN önce de var mıydı?",
                    "Bir şey olayı hazırlıyorsa nedendir; olay onu doğurmuşsa sonuçtur.",
                ],
                puan=18,
            ),
            coklu_adimi(
                soru="Aşağıdakilerden hangileri Coğrafi Keşifler'in NEDENLERİDİR?",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Nedenler keşiflerden önce vardı: gemicilik ve pusula bilgisi, "
                    "ticaret yollarının kapanması, doğunun zenginliğine dair "
                    "anlatılar, girişimi destekleyen krallıklar. Sonuçlar ise "
                    "keşiflerden sonra ortaya çıktı: yeni ticaret merkezleri, "
                    "Avrupa'ya akan maden ve bitkiler, sömürgecilik, otoritenin "
                    "sarsılması."
                ),
                ipuclari=[
                    "Her maddeyi 'önce mi vardı, sonra mı oldu' diye sına.",
                    "Patates ve mısırın Avrupa'ya gelmesi hangi tarafta olabilir?",
                ],
                puan=20,
            ),
            yorum_adimi(
                soru="\"Sömürge imparatorluklarının kurulması\" neden bir sonuçtur?",
                dogru="Keşiflerle ulaşılan yeni topraklarda kurulduğu için; öncesinde yoktu.",
                yanlislar={
                    "Çünkü olumsuz bir gelişmedir; olumsuzlar sonuç sayılır.":
                        "Olumsuzluğu ölçüt saydın. Bir gelişmenin sonuç "
                        "olması, iyi ya da kötü olmasına değil, olaydan SONRA "
                        "gelmesine bağlıdır.",
                    "Çünkü çok uzun sürmüştür; uzun süreli olaylar sonuçtur.":
                        "Süreyi ölçüt saydın. Kısa süren bir gelişme de sonuç "
                        "olabilir; belirleyici olan sıradaki yeri.",
                    "Aslında nedendir; sömürge arayışı keşifleri başlatmıştır, önce istek gelir.":
                        "Bu iyi bir itiraz ama zamanlamayı kaçırıyor: arayış "
                        "nedendi, İMPARATORLUKLARIN KURULMASI ise keşiflerden "
                        "sonra gelen sonuç.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Keşiflerden önce Avrupa devletlerinin okyanus ötesinde "
                    "sömürgesi yoktu; bu yapı ancak yeni kıtalara ulaşıldıktan "
                    "sonra kuruldu. Zenginlik arayışı nedendir, kurulan sömürge "
                    "düzeni ise onun sonucudur - istek ile sonuç karıştırılmamalı."
                ),
                puan=12,
            ),
        ],
        kapanis="Defter iki sayfaya ayrıldı ve merkeze temiz hâliyle gönderildi.",
        odul={"itibar": 7, "enerji": 3},
    )


@bulmaca(ders="tarih", konu="kaynak_elestirisi", kademeler=(8, 13))
def kaynak_elestirisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki çelişen anlatı; hangisi daha güvenilir ve neden."""
    yil_fark = rastgele.choice([150, 180, 200, 240])

    return Bulmaca(
        kod="tar-kaynak-elestirisi",
        ders="tarih",
        baslik="İki Anlatı",
        kademe=kademe,
        konu="kaynak_elestirisi",
        kazanim="Birincil ve ikincil kaynak ayrımı; kaynağın güvenilirliğini değerlendirme.",
        dikkat=7,
        brifing=(
            "Kronograf aynı olay için iki ayrı metin getirdi: bir kalenin "
            "kuşatma sırasında nasıl düştüğü anlatılıyor. İki metin birbirini "
            "tutmuyor.\n\n"
            "Birinci metin kuşatmayı bizzat gören bir kâtibin günlüğü. İkincisi "
            "aradan {} yıl geçtikten sonra, kaleyi alan hükümdarın torununun "
            "sarayında yazılmış bir övgü kitabı.\n\n"
            "Arşive tek bir anlatı geçecek. Hangisini temel alacağımıza karar "
            "vermemiz ve gerekçesini yazmamız gerekiyor."
        ).format(yil_fark),
        kanitlar=[
            Kanit("Metin 1 - kâtip günlüğü",
                  "Olayla aynı yıl yazılmış. Yazar kuşatma sırasında kalede "
                  "bulunmuş. Kayıpları, açlığı ve surda açılan gediği ayrıntılı "
                  "anlatıyor; kendi tarafının hatalarını da yazmış.",
                  bedel=2, kritik=True),
            Kanit("Metin 2 - saray övgü kitabı",
                  "Olaydan {} yıl sonra yazılmış. Yazar olayı görmemiş; "
                  "\"büyüklerimizden dinlediğime göre\" diye başlıyor. Kitap, "
                  "kaleyi alan hükümdarın torunu için ve onun himayesinde "
                  "yazılmış. Hiçbir hata ya da kayıp anlatılmıyor.".format(yil_fark),
                  bedel=2, kritik=True),
            Kanit("Kaynak tanımları",
                  "Birincil kaynak: olayı yaşayan ya da gören kişinin bıraktığı "
                  "kayıt.\nİkincil kaynak: olayı sonradan, başka kaynaklara "
                  "dayanarak anlatan çalışma.", bedel=2, kritik=True),
            Kanit("Arkeoloji raporu",
                  "Kale surlarında, günlükte tarif edilen yerde gedik izi "
                  "bulundu. Övgü kitabındaki \"surlara hiç dokunulmadan teslim "
                  "alındı\" ifadesiyle uyuşmuyor.", bedel=2, kritik=True),
            Kanit("Arşiv sorumlusunun notu",
                  "\"Uzun ve süslü yazılmış olması bir metni güvenilir yapmaz.\"",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir tarihî metnin güvenilirliğini asıl olarak ne belirler?",
                dogru=("Yazarın olaya yakınlığı ve tarafsızlığı: olayı görmüş mü, "
                       "anlatısında çıkarı var mı?"),
                yanlislar={
                    "Metnin uzunluğu ve dilinin güzelliği.":
                        "Biçimi güvenilirlik ölçüsü saydın. Güzel yazılmış bir "
                        "metin de yanlış olabilir; belirleyici olan yazarın "
                        "olaya ne kadar yakın olduğu.",
                    "Metnin ne kadar sonra yazıldığı önemli değildir; önemli olan "
                    "yazarın ünlü olmasıdır.":
                        "Ünü tanıklığın yerine koydun. Olaya uzak bir tanık, "
                        "ne kadar ünlü olursa olsun ikinci elden aktarır.",
                    "Metnin bugün bilinen anlatıya ne kadar uyduğu.":
                        "Ölçütü tersine çevirdin. Bugünkü anlatı zaten "
                        "kaynaklardan kuruluyor; kaynağı ona uydurmak, "
                        "kanıtı sonuca göre seçmek olur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki ölçüt öne çıkar: YAKINLIK (olayı gördü mü, ne kadar sonra "
                    "yazdı) ve TARAFSIZLIK (anlatının belli bir yönde çıkması "
                    "yazarın işine yarıyor mu). Süslü dil ve uzunluk, güvenilirlik "
                    "değil ustalık göstergesidir. \"Bugün bildiğimize uyuyor mu\" "
                    "ölçütü ise döngüseldir: bugün bildiğimiz de bu kaynaklardan gelir."
                ),
                ipuclari=[
                    "Yazarlardan biri olayı gördü, diğeri duydu. Bu neyi değiştirir?",
                    "İkinci metin kimin himayesinde yazılmış? Yazarın çıkarı var mı?",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="Hangi metin arşive temel alınmalı?",
                dogru="Kâtip günlüğü; birincil kaynaktır ve arkeolojik bulguyla uyuşur.",
                yanlislar={
                    "Saray övgü kitabı; daha kapsamlı ve düzenli yazılmıştır, resmî kayıttır.":
                        "Düzeni güvenilirlik saydın. Övgü için yazılmış bir "
                        "metnin amacı bilgi vermek değil; kapsamlı olması bunu "
                        "değiştirmez.",
                    "İkisi de eşit ağırlıkta alınmalı; ortalaması yazılmalı.":
                        "Tarihte ortalama alınmaz. İki kaynak çelişiyorsa "
                        "hangisinin olaya daha yakın ve daha az çıkarı olduğu "
                        "sorulur.",
                    "Hiçbiri; çelişen kaynaklar kullanılamaz.":
                        "Çelişkiyi çıkmaz saydın. Çelişki tarihçinin işini "
                        "bitirmez, başlatır: hangisinin neden farklı "
                        "söylediğini araştırır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Günlük birincil kaynaktır: yazar olaydaydı, olayla aynı yıl "
                    "yazdı ve kendi tarafının hatalarını da kaydetti - bu, çıkarına "
                    "aykırı bilgi vermesi demektir ve güvenilirliği artırır. Üstelik "
                    "surdaki gedik izi anlatısını bağımsız olarak doğruluyor."
                ),
                ipuclari=[
                    "Hangi metin bağımsız bir kanıtla (arkeoloji) destekleniyor?",
                    "Kendi tarafının hatasını yazan bir yazar neden daha güvenilirdir?",
                ],
                puan=16,
            ),
            yorum_adimi(
                soru="Övgü kitabı tamamen çöpe mi atılmalı?",
                dogru="Hayır; olay için zayıf ama hanedanın kendini nasıl göstermek istediğini anlatır.",
                yanlislar={
                    "Evet; güvenilir olmayan kaynak hiçbir işe yaramaz, taraflı olan yalan söyler.":
                        "Taraflı kaynağı işe yaramaz saydın. Övgü kitabı "
                        "olayları çarpıtsa bile o dönemin nasıl görünmek "
                        "istediğini gösterir; bu da bir bilgidir.",
                    "Evet; ikincil kaynaklar tarihte kullanılmaz.":
                        "Böyle bir kural yok. İkincil kaynaklar dikkatle "
                        "kullanılır; atılmaz.",
                    "Hayır; aslında daha güvenilirdir, çünkü daha çok kaynağa ve saray arşivine dayanır.":
                        "Kaynak sayısını güvenilirlik saydın. Hepsi aynı "
                        "amaca hizmet ediyorsa çokluk yanlılığı azaltmaz, "
                        "çoğaltır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir kaynağın hangi soruya cevap verdiği önemlidir. Övgü kitabı "
                    "\"kuşatma nasıl geçti\" sorusuna kötü bir kaynaktır; ama "
                    "\"{} yıl sonra saray bu olayı nasıl anlatmak istiyordu\" "
                    "sorusuna birinci elden cevap verir. Tarihçi kaynağı atmaz, "
                    "hangi soru için kullanacağını seçer."
                ).format(yil_fark),
                puan=14,
            ),
        ],
        kapanis=(
            "Arşive kâtip günlüğü temel alınarak yazıldı; övgü kitabı da "
            "\"dönemin bakışı\" notuyla yanına kondu."
        ),
        odul={"itibar": 9, "enerji": 4},
    )


@bulmaca(ders="tarih", konu="donem_esikleri", kademeler=(9, 13))
def donem_esikleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir buluşun kendisi değil, TOPLUMSAL SONUCU sorulur."""
    esikler = [
        {
            "ad": "Yazının bulunması (Sümerler, yaklaşık MÖ 3200)",
            "sonuc": "Bilginin kayıtla aktarılması; tarih öncesi çağların kapanması",
            "yanlislar": [
                "İnsanların ilk kez yerleşik hayata geçmesi ve köylerin kurulması",
                "Ateşin kullanılmaya başlanması",
                "Tekerleğin icat edilmesi; taşımacılığın hızlanması",
            ],
            "neden": ("Tarihî çağlar yazının bulunmasıyla başlatılır; çünkü "
                      "yazılı kayıt, geçmişi tanıkların ömrüyle sınırlı olmaktan "
                      "çıkarır."),
        },
        {
            "ad": "Tarıma geçiş (Neolitik, yaklaşık MÖ 8000)",
            "sonuc": "Besin üretimiyle yerleşik hayata geçilmesi ve ilk köyler",
            "yanlislar": [
                "Yazının icat edilmesi",
                "Madenlerin işlenmeye başlanması; tunç ve demir aletlerin yayılması",
                "Deniz ticaretinin doğması; limanlar arası mal alışverişi",
            ],
            "neden": ("İnsan besinini üretmeye başlayınca sürekli yer değiştirmesi "
                      "gerekmedi; yerleşiklik, artı ürün, iş bölümü ve nüfus artışı "
                      "bunun ardından geldi."),
        },
        {
            "ad": "Matbaanın Avrupa'da yaygınlaşması (1450'ler)",
            "sonuc": "Kitabın ucuzlayıp çoğalması; okuryazarlığın hızla yayılması",
            "yanlislar": [
                "Kâğıdın ilk kez üretilmesi; yazı malzemesinin herkese ulaşması",
                "Üniversitelerin ilk kez kurulması ve bilimin kurumlaşması",
                "Alfabenin icat edilmesi",
            ],
            "neden": ("Matbaadan önce kitaplar tek tek elle çoğaltılıyordu; bu "
                      "onları pahalı ve ender kılıyordu. Basım, aynı metnin binlerce "
                      "kopyasını mümkün kıldı ve düşüncelerin yayılma hızını değiştirdi."),
        },
        {
            "ad": "Buhar makinesinin üretime girmesi (18. yüzyıl sonu)",
            "sonuc": "Üretimin fabrikalara taşınması; kentlere göç ve işçi sınıfı",
            "yanlislar": [
                "Elektriğin evlere girmesi; geceleri de çalışılabilmesi",
                "Otomobilin icat edilmesi; ulaşımın bireyselleşmesi ve hızlanması",
                "Tarımın ilk kez başlaması",
            ],
            "neden": ("Buhar gücü, üretimi akarsu kenarına ve kas gücüne bağlı "
                      "olmaktan kurtardı. Makinenin kurulabildiği her yere fabrika "
                      "kurulabildi; bu da kentleşmeyi ve yeni bir toplumsal düzeni getirdi."),
        },
    ]
    esik = rastgele.choice(esikler)

    return Bulmaca(
        kod="tar-donem-esikleri",
        ders="tarih",
        baslik="Eşik",
        kademe=kademe,
        konu="donem_esikleri",
        kazanim="Tarihsel dönüm noktalarının toplumsal sonuçlarını değerlendirme.",
        dikkat=5,
        brifing=(
            "Komutan, arşivdeki kayıtları \"dönüm noktaları\" başlığı altında "
            "toplamak istiyor. Ama tek bir şart koyuyor:\n\n"
            "\"Bana buluşun adını yazmayın; onu zaten biliyorum. Bana bu buluşun "
            "insanların yaşayışında NEYİ değiştirdiğini yazın. Değiştirmediyse "
            "dönüm noktası değildir.\"\n\n"
            "Elindeki fişte şu yazıyor: {}"
        ).format(esik["ad"]),
        kanitlar=[
            Kanit("Arşiv ölçütü",
                  "\"Bir gelişme, ancak insanların yaşama biçimini kalıcı olarak "
                  "değiştirdiyse dönüm noktası sayılır. Tek başına teknik bir "
                  "yenilik yeterli değildir.\"", bedel=2, kritik=True),
            Kanit("Karşılaştırma notu",
                  "\"Bir eşiğin etkisini görmek için sor: bu gelişmeden ÖNCE "
                  "insanlar nasıl yaşıyordu, SONRA nasıl yaşamaya başladı?\"",
                  bedel=2, kritik=True),
            Kanit("Fiş", esik["ad"], bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir gelişmeyi \"dönüm noktası\" yapan şey nedir?",
                dogru="Yaşama, üretme ya da bilgi aktarma biçimini kalıcı olarak değiştirmesi.",
                yanlislar={
                    "Çok sayıda insanın o gelişmeyi duymuş olması; ünlü olay çağ açar.":
                        "Duyulmayı etki saydın. Bir gelişme yaygın olarak "
                        "bilinmeden de hayatı kökten değiştirebilir.",
                    "Gelişmenin teknik olarak karmaşık olması; basit bir buluş çağ değiştirmez.":
                        "Karmaşıklığı ölçüt saydın. Çok basit bir buluş da "
                        "dönüm noktası olabilir; belirleyici olan SONRASINI ne "
                        "kadar değiştirdiği.",
                    "Gelişmenin bir savaşla aynı yıla denk gelmesi.":
                        "Aynı yıla düşmek bir bağ kurmaz. Dönüm noktasını "
                        "yapan şey rastlantı değil, yol açtığı değişim.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarihte çağ değiştiren şeyler, kendinden sonra insanların "
                    "gündelik hayatını başka türlü kuran gelişmelerdir. Teknik "
                    "karmaşıklık ya da ün, bu ölçütün yerini tutmaz: çok basit bir "
                    "buluş (mesela tohumu ekmek) çağ açabilirken, karmaşık bir alet "
                    "iz bırakmadan kaybolabilir."
                ),
                ipuclari=[
                    "Bu gelişmeden önce ve sonra insanların günü nasıl geçiyordu?",
                    "Değişen şey bir alet mi, yoksa bir yaşama biçimi mi?",
                ],
                puan=18,
            ),
            secim_adimi(
                soru="Bu eşiğin asıl sonucu hangisidir?",
                dogru=esik["sonuc"],
                yanlislar=esik["yanlislar"],
                rastgele=rastgele,
                aciklama=esik["neden"],
                ipuclari=[
                    "Şıklardan bazıları BAŞKA bir eşiğin sonucudur; onları ele.",
                    "Fişteki gelişmeyle doğrudan bağı olan değişikliği ara.",
                ],
                puan=16,
            ),
            yorum_adimi(
                soru="Aynı buluş her toplumda aynı sonucu doğurur mu?",
                dogru="Hayır; sonucu buluş kadar toplumun ekonomik ve toplumsal koşulları belirler.",
                yanlislar={
                    "Evet; teknik bir buluşun etkisi her yerde aynıdır, makine makinedir.":
                        "Buluşu tek başına etken saydın. Aynı araç, farklı "
                        "toplumsal düzenlerde farklı sonuç doğurur.",
                    "Evet; yeter ki buluş aynı yılda ulaşsın.":
                        "Zamanlamayı tek koşul saydın. Aynı yıl ulaşsa bile "
                        "toplumun yapısı sonucu değiştirir.",
                    "Hayır; çünkü buluşlar yalnızca bulundukları ülkede kullanılır, başkasına geçmez.":
                        "Doğru sonuca yanlış gerekçeyle vardın. Buluşlar "
                        "yayılır; farklı sonuç doğurmalarının sebebi "
                        "yayılmamaları değil, karşılaştıkları koşullar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı teknoloji farklı toplumlarda farklı sonuçlar verebilir. "
                    "Kâğıt Çin'de yüzyıllarca kullanıldı; Avrupa'da matbaayla "
                    "birleşince bambaşka bir etki yarattı. Tarihte 'teknoloji "
                    "belirler' demek eksik kalır; teknolojinin düştüğü zemin de belirler."
                ),
                puan=14,
            ),
        ],
        kapanis="Fiş, sonucu yazılmış hâliyle \"dönüm noktaları\" dosyasına kondu.",
        odul={"itibar": 8, "enerji": 4},
    )


# ==========================================================================
# İLKOKUL
# ==========================================================================

@bulmaca(ders="tarih", konu="kronoloji", kademeler=(1, 5))
def sandiktaki_fotograflar(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Dört fotoğraf, tarihleri yok; sıra fotoğrafların İÇİNDEKİ ipuçlarından çıkar.

    İlkokulda tarih öğretmenin en doğru yolu budur: çocuk henüz tarih
    ezberlemez ama "hangisi önce oldu" sorusunu kanıtla yanıtlayabilir.
    """
    fotograflar = [
        ("Boş bir arazi; yalnızca bir çadır ve birkaç sandık var.", 1),
        ("Aynı arazide taş temeller atılmış, duvarlar yarım.", 2),
        ("Bina bitmiş, önünde yeni dikilmiş ince bir fidan var.", 3),
        ("Aynı bina; kapısının önündeki ağaç kalınlaşmış, gölge yapıyor.", 4),
    ]
    karisik = list(fotograflar)
    rastgele.shuffle(karisik)
    secenekler = [metin for metin, _ in karisik]
    dogru_sira = [karisik.index(f) for f in sorted(fotograflar, key=lambda x: x[1])]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-fotograflar",
        ders="tarih",
        baslik="Sandıktaki Fotoğraflar",
        kademe=kademe,
        konu="kronoloji",
        kazanim="Kanıta dayalı sıralama; öncelik-sonralık ilişkisi kurma.",
        dikkat=5,
        brifing=(
            "Arşivde eski bir sandık bulundu. İçinde üssün kuruluşundan kalma "
            "dört fotoğraf var.\n\n"
            "Fotoğrafların arkasına tarih yazılmamış. {} \"karışık atmışlar, "
            "artık hangisi önce belli olmaz\" diyor.\n\n"
            "Ama fotoğraflara dikkatli bakınca hangisinin önce çekildiği "
            "anlaşılıyor. Sıraya dizip albüme yapıştırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Fotoğrafların arkası",
                  "Dördünde de tarih yok. Yalnızca \"Meridyen Üssü\" yazıyor.",
                  bedel=1),
            Kanit("Arşivcinin notu",
                  "\"Tarih yazmıyorsa fotoğrafın İÇİNE bakılır: bir bina yapılıyor "
                  "mu, bitmiş mi? Ağaç ince mi, kalın mı? Bunlar zamanı gösterir.\"",
                  bedel=2, kritik=True),
            Kanit("Bahçıvan defteri",
                  "\"Ağaçlar yıllar geçtikçe kalınlaşır ve büyür; incelmez.\"",
                  bedel=1, kritik=True),
            Kanit("İnşaat kaydı",
                  "\"Bir bina önce temelden başlar, sonra duvarları örülür, en "
                  "son biter. Tersi olmaz.\"", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Tarihi yazmayan fotoğrafları nasıl sıraya dizeriz?",
                dogru="Fotoğraftaki değişimlere bakarak: bina ilerler, ağaç büyür.",
                yanlislar={
                    "Fotoğrafların büyüklüğüne bakarak.":
                        "Baskı boyutunu tarih ölçüsü saydın. Boyut fotoğrafın "
                        "ne zaman çekildiğiyle ilgili değil.",
                    "Fotoğrafların renginin soluk olup olmamasına bakarak; eski olan solar.":
                        "Solmayı takvim saydın. Solma saklama koşullarına "
                        "bağlıdır; kötü saklanan yeni bir fotoğraf da solar.",
                    "Sandıkta hangisi üstteyse o en yenisidir.":
                        "Sandıktaki sırayı kanıt saydın. Kim ne zaman koydu "
                        "bilmiyoruz; fotoğrafların İÇİNDEKİ değişimlere bakmak "
                        "gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bazı şeyler zamanla hep aynı yönde değişir: bina yapılır ama "
                    "kendiliğinden yıkılıp temele dönmez; ağaç kalınlaşır ama "
                    "incelmez. Bu tek yönlü değişimler bize sırayı söyler. "
                    "Tarihçiler de kalıntılara tam olarak böyle bakar."
                ),
                ipuclari=[
                    "Bir bina önce mi biter, önce mi temel atılır?",
                    "Ağaç zamanla incelir mi, kalınlaşır mı?",
                ],
            ),
            sirala_adimi(
                soru="Fotoğrafları en eskiden en yeniye sırala (numaraları sırayla yaz):",
                secenekler=secenekler,
                dogru_sira=dogru_sira,
                aciklama=(
                    "Doğru sıra: önce boş arazi ve çadır, sonra yarım duvarlar, "
                    "sonra biten bina ve yeni fidan, en son kalınlaşmış ağaç. "
                    "Her adımda bir şey ilerlemiş: önce yapı, sonra ağaç."
                ),
                ipuclari=[
                    "Önce hangi fotoğrafta hiç bina yok? O en eskisi.",
                    "Bina bittikten sonra hangisinde ağaç daha büyük?",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="Ağacın kalınlığı bize ne söylüyor?",
                dogru="Aradan zaman geçtiğini; kalın ağacın olduğu fotoğraf daha yenidir.",
                yanlislar={
                    "Fotoğrafın daha eski olduğunu; yaşlı ağaçlar zamanla kuruyup incelir.":
                        "Yönü ters aldın. Ağaçlar yıllar geçtikçe kalınlaşır; "
                        "kalın gövde daha YENİ bir fotoğrafa işaret eder.",
                    "Hiçbir şey söylemez; ağaçlar her yıl aynı kalır.":
                        "Ağacı değişmez saydın. Her yıl bir halka eklenir ve "
                        "gövde kalınlaşır; bu, fotoğrafları sıralamak için "
                        "kullanılabilecek bir iz.",
                    "Fotoğrafın kışın çekildiğini.":
                        "Mevsim ipucu arıyorsun ama gövde kalınlığı mevsimle "
                        "değil, geçen YILLARLA ilgili.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ağaç her yıl biraz daha kalınlaşır. Bu yüzden aynı ağacın iki "
                    "fotoğrafından kalın olanı daha sonra çekilmiştir. Ağaçların "
                    "gövdesindeki halkaların sayılmasıyla yaş bulunması da aynı fikre dayanır."
                ),
                ipuclari=["Bir ağaç yıllar içinde büyür mü, küçülür mü?"],
                puan=12,
            ),
        ],
        kapanis="Fotoğraflar sıraya dizilip albüme yapıştırıldı; altlarına sıra "
                "numarası yazıldı.",
        odul={"itibar": 4, "enerji": 2},
    )


# ==========================================================================
# ÜÇÜNCÜ KAYIT — iki kaynak da belirleyici değilse (kademe 9-13)
# ==========================================================================
#
# `kaynak_elestirisi` üreticisi zaten var ve iyi: görgü tanığı ile sonraki
# övgü kitabını karşılaştırıyor, cevap bir kural ("birincil kaynak daha
# güvenilir"). Bu görev ONU TEKRAR ETMİYOR; bir sonraki adımı öğretiyor.
#
# ÖĞRETİLEN ŞEY: birincil kaynak OTOMATİK olarak doğru değildir.
# Olayı gören biri de yanlış yazabilir -- eksik görmüştür, ya da doğruyu
# yazmakta çıkarı yoktur. İki kaynak da taraflıysa doğru cevap "hangisi"
# değil, "hangisi de değil; şuna bakmalı" olur.
#
# ASIL DERS: en güvenilir kayıt çoğu zaman KİMSEYİ İKNA ETMEK İÇİN
# YAZILMAMIŞ olandır. Erzak defteri kimseyi övmez, kimseyi suçlamaz;
# yalnızca kaç kişiye ekmek çıktığını yazar. Tarihçiler bu yüzden
# anlatıya değil idari kayda güvenir.
#
# YAPI: "eksik veri teşhisi" (bkz. GOREVLER B34.9, 3. yapı) -- nakliyedeki
# `eksik_cizelge` ile aynı iskelet, tarihe taşınmış hâli. Doğru cevap bir
# bilgi değil, hangi bilginin aranacağı.

# (kayıt sahibi, sayı yönü, neden taraflı)
TARAFLI_KAYITLAR = [
    ("kale komutanının merkeze raporu", "fazla",
     "Komutan takviye istiyordu; garnizonu az göstermek işine gelmezdi... "
     "ama çok göstermek de yardımı geciktirirdi."),
    ("kuşatmayı yapan ordunun zafer yazıtı", "fazla",
     "Kalabalık bir garnizonu yenmek daha büyük bir zaferdir."),
    ("kaleyi teslim eden subayın savunma dilekçesi", "az",
     "Az kişiyle direndiğini söylemek teslimi mazur gösterir."),
    ("şehir vakayinamesini yazan kâtibin notu", "az",
     "Kâtip kaleye hiç girmedi; sayıyı kapıdan gelip geçenlere sordu."),
]


@bulmaca(ders="tarih", konu="kaynak_elestirisi", kademeler=(9, 13),
         agirlik=1.1)
def ucuncu_kayit(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki kayıt da taraflı. Doğru cevap üçüncü bir kaynağı aramak.

    Yükselen tek eksen: sorunun kendisi. Sayılar kolay, zincir kısa; zor
    olan tek şey "ikisi de olmaz" diyebilmek. (ICERIK_EKLEME.md §2c)
    """
    # BİRİ FAZLA, BİRİ AZ göstermeli. İlk yazımda ikisi de aynı havuzdan
    # çekiliyordu; ikisi de aynı yöne sapınca ve sapmalar çakışınca
    # kayıtlar AYNI sayıyı gösteriyordu -- oysa brifing "tutmuyorlar"
    # diyor. Görevin öncülü çöküyordu. (9 Eylül 2026)
    #
    # Ayrıca zıt yönler "ortalamasını al" şıkkını da anlamlı kılıyor:
    # iki taraflı sayının ortası tarafsız bir sayı vermez ve öğrencinin
    # bunu görmesi gerekiyor.
    fazla_gosterenler = [k for k in TARAFLI_KAYITLAR if k[1] == "fazla"]
    az_gosterenler = [k for k in TARAFLI_KAYITLAR if k[1] == "az"]
    birinci = rastgele.choice(fazla_gosterenler)
    ikinci = rastgele.choice(az_gosterenler)
    if rastgele.random() < 0.5:            # sıra da değişsin
        birinci, ikinci = ikinci, birinci
    gercek = rastgele.randrange(280, 700, 20)
    # SAPMALAR EŞİT OLMAMALI. Eşit olurlarsa iki sayının ortalaması tam
    # gerçeğe denk geliyor ve "ikisinin ortalamasını al" ÇELDİRİCİSİ
    # doğru cevap hâline geliyordu -- ölçümde vakaların %10'unda oluyordu.
    # Bir çeldirici hiçbir zaman doğru olmamalı; olursa öğrenci doğru
    # düşünüp yanlış sayılır.
    sapma_bir = rastgele.randrange(80, 200, 10)
    sapma_iki = rastgele.choice([s for s in range(80, 200, 10)
                                 if s != sapma_bir])
    sayi_bir = gercek + (sapma_bir if birinci[1] == "fazla" else -sapma_bir)
    sayi_iki = gercek + (sapma_iki if ikinci[1] == "fazla" else -sapma_iki)
    gunluk_ekmek = rastgele.choice([1, 2])
    yil = rastgele.randrange(1180, 1460, 10)

    return Bulmaca(
        kod="tar-ucuncu-kayit",
        ders="tarih",
        baslik="Üçüncü Kayıt",
        kademe=kademe,
        konu="kaynak_elestirisi",
        kazanim=("Birincil kaynağın da taraflı olabileceğini görme; "
                 "idari kaydın anlatıdan neden daha güvenilir olduğunu "
                 "açıklama."),
        dikkat=7,
        brifing=(
            "Kronograf {} yılına ait bir kuşatmadan iki kayıt getirdi. "
            "İkisi de garnizonun kaç kişi olduğunu yazıyor ve tutmuyorlar:"
            "\n\n"
            "  • {}: {} kişi\n"
            "  • {}: {} kişi\n\n"
            "Arşive tek bir sayı geçecek. Hangisini yazacağımıza karar "
            "vermemiz gerekiyor."
        ).format(yil, birinci[0].capitalize(), sayi_bir,
                 ikinci[0].capitalize(), sayi_iki),
        kanitlar=[
            Kanit("Birinci kaydın arka planı", birinci[2], bedel=1,
                  kritik=True),
            Kanit("İkinci kaydın arka planı", ikinci[2], bedel=1,
                  kritik=True),
            Kanit("Arşivcinin notu",
                  "\"Kuşatma dönemine ait kale fırınının un çıkış defteri "
                  "de elimizde. Günlük kaç somun çıktığı yazılı; kişi "
                  "başına {} somun veriliyormuş.\"".format(gunluk_ekmek),
                  bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="İki kayıttan hangisi arşive geçmeli?",
                dogru="Hiçbiri; ikisinin de sayıyı eğmek için sebebi var.",
                yanlislar=[
                    "Birincisi; olaya daha yakın olan kayıt.",
                    "İkincisi; sonradan yazılan kayıt daha soğukkanlıdır.",
                    "İkisinin ortalaması; gerçek ortada olur.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Birincil kaynak olmak tek başına güvenilirlik "
                    "getirmez. Olayı gören biri de yanlış yazabilir: "
                    "eksik görmüştür ya da doğruyu yazmakta çıkarı yoktur. "
                    "Burada İKİSİNİN de sayıyı eğmek için sebebi var."
                ),
                cozum=(
                    "Kaynak eleştirisinde ilk soru \"kim yazdı\" değil, "
                    "\"yazarken ne kazanıyordu\" olmalı.\n\n"
                    "{} -> {}\n"
                    "{} -> {}\n\n"
                    "İkisi de tarafsız değil. Ortalama almak da işe yaramaz: "
                    "iki taraflı sayının ortası tarafsız bir sayı vermez, "
                    "yalnızca hatayı gizler."
                ).format(birinci[0].capitalize(), birinci[2],
                         ikinci[0].capitalize(), ikinci[2]),
            ),
            secim_adimi(
                soru="Sayıyı belirlemek için hangi kayda bakmalı?",
                dogru="Kale fırınının un çıkış defterine.",
                yanlislar=[
                    "Kuşatmayı anlatan halk türkülerine.",
                    "Kaleyi alan hükümdarın fermanına.",
                    "Aynı dönemde yazılmış başka bir zafer yazıtına.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Fırın defteri kimseyi ikna etmek için yazılmadı. "
                    "Kâtip un çıkışını yazarken garnizonun büyük ya da "
                    "küçük görünmesinden çıkarı yoktu; yalnızca hesabı "
                    "tutuyordu."
                ),
                cozum=(
                    "En güvenilir kayıt çoğu zaman KİMSEYİ İKNA ETMEK İÇİN "
                    "YAZILMAMIŞ olandır.\n\n"
                    "Zafer yazıtı övmek için, dilekçe savunmak için, rapor "
                    "yardım istemek için yazıldı. Fırın defteri hiçbiri "
                    "için yazılmadı -- yalnızca kaç somun çıktığını tutuyor.\n\n"
                    "Tarihçiler bu yüzden anlatıya değil idari kayda güvenir: "
                    "vergi defterleri, tapu kayıtları, erzak çizelgeleri."
                ),
            ),
            sayi_adimi(
                soru=("Fırın defterinde günde {} somun çıktığı yazıyorsa "
                      "garnizon kaç kişidir?").format(gercek * gunluk_ekmek),
                cevap=gercek,
                birim="kişi",
                aciklama="{} ÷ {} = {}".format(
                    gercek * gunluk_ekmek, gunluk_ekmek, gercek),
                cozum=(
                    "Kişi başına {} somun veriliyor.\n"
                    "{} ÷ {} = {} kişi.\n\n"
                    "Bu sayı iki kaydın da söylediğinden farklı ({} ve {}) "
                    "-- ikisinin ortalaması da değil. Tarafsız kayıt, "
                    "taraflı kayıtların arasında bir yerde durmak zorunda "
                    "değildir."
                ).format(gunluk_ekmek, gercek * gunluk_ekmek, gunluk_ekmek,
                         gercek, sayi_bir, sayi_iki),
            ),
            yorum_adimi(
                soru="Fırın defteri de yanıltabilir mi?",
                dogru="Evet; hasta, esir ya da sivil de beslendiyse somun sayısı garnizonu aşar.",
                yanlislar=[
                    "Hayır; sayı defterde yazılıysa kesindir, kâtip gördüğünü yazar.",
                    "Hayır; idari kayıtlarda hata olmaz, çünkü hesabı denetlenir ve mühürlenir.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "İdari kayıt daha güvenilirdir ama kusursuz değildir. "
                    "Güvenilir olmasının sebebi tarafsızlığı; her şeyi "
                    "doğru yazması değil. Kaleyi savunanlar dışında ekmek "
                    "yiyen varsa sayı şişer."
                ),
            ),
        ],
        kapanis=(
            "Arşive {} kişi yazıldı ve yanına şu not düşüldü: \"Fırın "
            "defterinden; iki anlatı da taraflı bulundu.\""
        ).format(gercek),
        odul={"itibar": 9, "cevher": 3},
    )


# ==========================================================================
# KONUYA ÖZEL TARİH GÖREVLERİ (B37.10)
#
# Buraya kadarki tarih görevleri BECERİ soruyordu: kronoloji, neden-sonuç,
# anakronizm, kaynak eleştirisi. Konu haritası (13 Eylül 2026) 161 satır
# getirdi ve ölçüm şunu gösterdi: satırların %85'i "hazır" görünüyordu ama
# hepsini 7 genel beceri konusu karşılıyordu. Yani "tımar sistemi" işleyen
# bir öğretmen konu seçtiğinde öğrenciye tımardan değil, genel bir
# neden-sonuç sorusu geliyordu.
#
# Buradaki görevler o boşluğu kapatmaya başlıyor. Üçünün de yaygın yanlışı
# haritanın `yaygin_yanlis` alanından, bağlamı `gunluk_baglam` alanından
# geliyor.
#
# TARİHSEL DOĞRULUK KURALI: ölçü, oran ve fiyatlar döneme ve yere göre
# değişiyordu; bu yüzden hiçbir görev "şu oran her yerde şuydu" demiyor.
# Kural KANITTA veriliyor, öğrenci verilen kuralı uyguluyor. Ezber değil
# muhakeme ölçülüyor ve uydurma bir kesinlik iddia edilmiyor.
# ==========================================================================

@bulmaca(ders="tarih", konu="timar_sistemi", kademeler=(9, 12), agirlik=1.3)
def dirlik_defteri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tımarın askerî, ekonomik ve toplumsal işlevi bir defter üzerinden."""
    # Sayilar ozellikle boyle: kilic hakki basamak tutarindan BUYUK olmali,
    # yoksa "kilic hakkini dusmeyi atlamak" hatasi dogru cevabin kendisini
    # veriyor ve soru o ayrimi hic olcmuyordu. Denetleyici bunu 12. kademede
    # yakaladi (13 Eylul 2026). Tutarlar donem ve sancaga gore degisiyordu;
    # buradaki degerler bu defterin kendi kurali olarak veriliyor.
    kilic = rastgele.choice([6000, 8000])
    basamak = rastgele.choice([2000, 3000])
    cebelu = rastgele.choice([2, 3, 4])
    gelir = kilic + basamak * cebelu
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-dirlik-defteri",
        ders="tarih",
        baslik="Dirlik Defteri",
        kademe=kademe,
        konu="timar_sistemi",
        kazanim="Tımarın askerî, ekonomik ve toplumsal işlevlerini ilişkilendirme.",
        dikkat=7,
        brifing=(
            "Üssün arşivinde eski bir sancak defterinin kopyası duruyor. "
            "Defterde bir sipahinin dirliği yazılı: yıllık geliri {} akçe.\n\n"
            "{} defteri merkeze özetleyecek ama bir yerde takılmış: defter "
            "sipahinin kaç adamla sefere çıkacağını YAZMIYOR. Yalnız geliri "
            "yazıyor.\n\n"
            "Kâtip, \"bu gelirle kaç asker beslenir, onu kendimiz "
            "çıkarabilirmiyiz\" diye soruyor. Defterin arkasında sancağın "
            "kanunnâmesinden bir sayfa var."
        ).format(gelir, kisi),
        kanitlar=[
            Kanit("Dirlik kaydı",
                  "Sipahinin dirliğinin yıllık geliri: {} akçe. Toprağın "
                  "kendisi devletin (mîrî); sipahiye VERGİ GELİRİ tahsis "
                  "edilmiş.".format(gelir), bedel=2, kritik=True),
            Kanit("Kanunnâme sayfası",
                  "\"Sipahi geçimi için {} akçeyi kendine alır (kılıç hakkı). "
                  "Kalan gelirin her {} akçesi için bir cebelü (silahlı adam) "
                  "besleyip sefere getirir.\"".format(kilic, basamak),
                  bedel=2, kritik=True),
            Kanit("Sefer yoklaması",
                  "Yoklamada sipahi kendi atı ve silahıyla bizzat bulunur; "
                  "getirdiği cebelüler ayrı yazılır.", bedel=2, kritik=True),
            Kanit("Maliye notu",
                  "\"Merkez hazinesinden bu askerler için nakit ödeme "
                  "yapılmamış; kayıtta yalnız gelir tahsisi var.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Defterdeki gelirle asker sayısı arasındaki bağ nasıl kurulur?",
                dogru=("Önce kılıç hakkı ({} akçe) düşülür; kalanın her {} akçesi "
                       "bir cebelü".format(kilic, basamak)),
                yanlislar={
                    "Gelirin tamamı {} akçeye bölünür; kılıç hakkı da gelirin bir parçasıdır".format(basamak):
                        "Kılıç hakkını düşmeyi atladın. Sipahinin kendi geçimi "
                        "de bu gelirden karşılanıyor; askerin payı ancak "
                        "ondan sonrası.",
                    "Gelir doğrudan asker sayısıyla çarpılır":
                        "Çarpma, geliri büyütür. Burada gelir PAYLAŞILIYOR: "
                        "bir kısmı sipahinin geçimi, kalanı asker beslemek.",
                    "Toprağın büyüklüğü asker sayısını verir; gelir önemsizdir":
                        "Defterde ölçü dönüm değil AKÇE. Aynı büyüklükte iki "
                        "toprağın geliri farklı olabilir; yükümlülük gelire bağlı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tımar bir maaş değil, bir GELİR TAHSİSİDİR: devlet vergiyi "
                    "merkeze taşıyıp sonra asker için geri dağıtmak yerine, "
                    "geliri yerinde bırakır ve karşılığında hizmet ister. Bu "
                    "yüzden hesap 'gelir eksi geçim, kalanı asker' diye "
                    "kurulur.\n\n"
                    "Kılıç hakkı ve basamak tutarları döneme ve sancağa göre "
                    "değişirdi; buradaki sayılar bu defterin kendi kuralıdır, "
                    "her yerde geçerli bir oran değil."
                ),
                ipuclari=[
                    "Gelirin tamamı askere mi gidiyor? Kanunnâme ne diyor?",
                    "Önce sipahinin kendi payını ayır, sonra bölmeye geç.",
                ],
            ),
            sayi_adimi(
                soru="Bu sipahi sefere kaç cebelü getirmek zorunda?",
                cevap=cebelu,
                birim="cebelü",
                aciklama="({} - {}) ÷ {} = {}.".format(
                    gelir, kilic, basamak, cebelu),
                yaygin_yanlislar={
                    gelir // basamak:
                        "Kılıç hakkını düşmeden böldün; sipahinin geçim payını "
                        "askere saydın.",
                    cebelu + 1:
                        "Sipahinin kendisini de cebelü saydın. Yoklamada sipahi "
                        "ayrı yazılıyor; cebelü onun GETİRDİĞİ adamlar.",
                },
                ipuclari=["Kalan geliri basamak tutarına böl."],
                puan=14,
            ),
            sayi_adimi(
                soru="Bu dirlikten sefere toplam kaç silahlı kişi çıkar?",
                cevap=cebelu + 1,
                birim="kişi",
                aciklama=("{} cebelü + sipahinin kendisi = {}. Sipahi bizzat "
                          "katılıyor; defter onu cebelülerden ayrı yazıyor.").format(
                              cebelu, cebelu + 1),
                yaygin_yanlislar={
                    cebelu:
                        "Sipahiyi saymadın. Yoklama kaydı onun atı ve silahıyla "
                        "bizzat bulunduğunu yazıyor.",
                },
                ipuclari=["Yoklamada kim var? Kanıtı bir daha oku."],
                puan=10,
            ),
            yorum_adimi(
                soru="Kâtip \"öyleyse bu toprak sipahinin malı olmuş\" diyor. Neden yanlış?",
                dogru="Toprağın mülkiyeti devlettedir, sipahi hizmet karşılığı vergi gelirini toplar.",
                yanlislar={
                    "Doğru sayılır: geliri o topladığına göre toprak da onundur, mülk sahibi gibidir.":
                        "Geliri toplamak mülkiyet değildir. Kayıt toprağın mîrî "
                        "olduğunu ayrıca yazıyor; hizmet biterse tahsis de biter.",
                    "Yanlış, çünkü sipahi toprakta hiç oturmaz ve hiçbir "
                    "yetkisi yoktur.":
                        "Aşırıya kaçtın: sipahinin yerinde gerçek yetkileri "
                        "vardı. Olmayan şey MÜLKİYET.",
                    "Yanlış, çünkü tımar yalnız savaş zamanı verilir.":
                        "Tahsis sürekliydi; yükümlülük de sürekliydi. Ayrım "
                        "zamanla değil mülkiyetle ilgili.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Haritadaki en sık yanlış tam bu: tımarı toprak mülkiyeti "
                    "sanmak. Sistem üç şeyi birbirine bağlıyor -- vergi geliri, "
                    "askerî hizmet ve toprağın işlenmeye devam etmesi. Üçü "
                    "birden düşünülmezse ne asker ne vergi anlaşılır."
                ),
                puan=12,
            ),
        ],
        kapanis="Defter özeti merkeze gitti: {} akçe dirlik, {} silahlı kişi.".format(
            gelir, cebelu + 1),
        odul={"itibar": 5, "erzak": 2},
    )


@bulmaca(ders="tarih", konu="lonca_teskilati", kademeler=(9, 12), agirlik=1.2)
def gedik_anlasmazligi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Lonca ile vakfı ayırmak: ikisi de şehirde ama işleri farklı."""
    usta = rastgele.choice([9, 12, 14])
    aidat = rastgele.choice([20, 25, 30])
    yardim = rastgele.choice([900, 1200, 1500])
    ay = -(-yardim // (usta * aidat))          # yukarı yuvarlama
    kalfa = ad_sec(rastgele, PERSONEL, 1)[0]
    # Teşhis anahtarları doğru cevaba EŞİT OLMAMALI. Bölme tam çıkarsa
    # "aşağı yuvarladın" hatası cevabın kendisi oluyordu; denetleyici bunu
    # 12 tohumda yakaladı (13 Eylül 2026). O yüzden koşullu kuruluyor.
    yanlis_aylar = {
        yardim // aidat:
            "Tek ustanın aidatına böldün; sandığa {} usta birlikte "
            "ödüyor.".format(usta),
    }
    if yardim % (usta * aidat):
        yanlis_aylar[yardim // (usta * aidat)] = (
            "Aşağı yuvarladın. O ay sonunda para henüz yetmez; yardım bir ay "
            "daha bekler.")
    else:
        yanlis_aylar[ay + 1] = (
            "Bir ay fazla saydın; toplanan para tam o ay sonunda yetiyor.")

    return Bulmaca(
        kod="tar-gedik-anlasmazligi",
        ders="tarih",
        baslik="Gedik Anlaşmazlığı",
        kademe=kademe,
        konu="lonca_teskilati",
        kazanim="Lonca ile vakfın işlevlerini ayırt etme; meslek eğitimi ve denetim.",
        dikkat=7,
        brifing=(
            "Atölye arşivinde bir şehir kaydı çıktı. Kayıtta iki şikâyet var.\n\n"
            "Birincisi: {} adında bir kalfa kendi dükkânını açmak istiyor, "
            "ama esnaf \"gedik yok\" diyerek izin vermiyor.\n\n"
            "İkincisi: bir dükkânın malı belirlenen fiyatın üstünde satılmış.\n\n"
            "Kâtip ikisini de \"yardım işi\" sayıp vakıf defterine yazmış. "
            "Baş kâtip bunun yanlış olduğunu söylüyor ama nedenini "
            "açıklamamış."
        ).format(kalfa),
        kanitlar=[
            Kanit("Lonca nizamı",
                  "\"Çırak kalfa olur, kalfa ustalık onayı ve BOŞ BİR GEDİK "
                  "(dükkân hakkı) bulursa usta olur. Gedik sayısı loncanın "
                  "kaydıyla sınırlıdır.\"", bedel=2, kritik=True),
            Kanit("Narh defteri",
                  "\"Malın azami satış fiyatı kadı huzurunda belirlenir; "
                  "üstünde satan esnaf loncaya ve kadıya hesap verir.\"",
                  bedel=2, kritik=True),
            Kanit("Orta sandığı kaydı",
                  "\"Sandığa {} usta aylık {} akçe verir. Hastalanan ya da "
                  "dükkânı yanan ÜYEYE buradan yardım edilir.\"".format(usta, aidat),
                  bedel=2, kritik=True),
            Kanit("Vakıf defteri (karşılaştırma)",
                  "\"Vakfın geliri kirası ve arazisinden gelir; harcaması "
                  "vakfiyede yazan hizmete gider: imaret, medrese, su yolu. "
                  "Yararlanan kişi üye olmak zorunda değildir.\"",
                  bedel=2, kritik=True),
            Kanit("Baş kâtibin notu",
                  "\"İki defter karıştırılmış. Hangi iş hangi kurumun, onu "
                  "ayırın.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu iki şikâyet hangi kuruma ve neye göre aittir?",
                dogru="Loncaya: gedik ve ustalık onun nizamı, fiyat da kadı huzurunda denetlenir",
                yanlislar={
                    "Vakfa: ikisi de şehirdeki insanlara yardım işidir; lonca da vakıf da hayır kurumudur":
                        "Loncayla vakfı aynı saydın. Vakıf GELİRİNİ vakfiyede "
                        "yazan hizmete harcar; loncanın işi üretim, meslek "
                        "eğitimi ve denetimdir.",
                    "Doğrudan merkeze: her ikisi de ancak padişah fermanıyla "
                    "çözülür, esnaf işi devlet işidir":
                        "Her anlaşmazlık merkeze gitmez. Kayıtta çözüm yolu "
                        "yazıyor: loncanın nizamı ve kadının narhı.",
                    "Kimseye: fiyat da dükkân açmak da serbesttir, şikâyet "
                    "konusu olamaz":
                        "Serbest değildi. Narh defteri ve gedik kaydı tam bu "
                        "işleri düzenlemek için tutuluyordu.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Lonca ile vakıf aynı şehirde, bazen aynı sokakta durur ama "
                    "işleri farklıdır. Loncanın konusu ÜRETİM ve MESLEK: kimin "
                    "usta olacağı, malın kalitesi ve fiyatı. Vakfın konusu "
                    "HİZMET: vakfiyede yazan amaca gelir aktarmak.\n\n"
                    "Ayrımı en iyi gösteren soru şu: yardımı kim alıyor? Orta "
                    "sandığı ÜYESİNE yardım eder, vakıf ise vakfiyede yazan "
                    "yararlanıcıya -- üyelik şartı yok."
                ),
                ipuclari=[
                    "İki defterin GELİRİ nereden geliyor? Aynı yerden mi?",
                    "Yardımı alan kişi üye olmak zorunda mı?",
                ],
            ),
            coklu_adimi(
                soru="Hangileri loncanın işi? (birden çok seçilebilir)",
                secenekler=[
                    "Kalfayı ustalığa geçirmek ve gedik vermek",
                    "Malın kalitesini ve ölçüsünü denetlemek",
                    "Üyesi hastalanınca sandıktan yardım etmek",
                    "İmarette yemek dağıtmak",
                    "Medresede müderrisin ücretini ödemek",
                    "Su yolunu onarmak",
                ],
                dogru_indeksler=[0, 1, 2],
                aciklama=("İlk üçü loncanın kendi üyesine ve kendi üretimine "
                          "dönük işler. Son üçü vakfiyede yazan hizmetler: "
                          "yararlanan kişinin esnaf olması gerekmez."),
                ipuclari=["Her maddede sor: bu iş ÜYEYE mi, herkese mi?"],
                puan=16,
            ),
            sayi_adimi(
                soru=("Sandıkta hiç para yoksa, {} akçelik bir yardımı "
                      "karşılamak kaç ay sürer?").format(yardim),
                cevap=ay,
                birim="ay",
                aciklama=("Aylık toplanan: {} × {} = {} akçe. {} ÷ {} = {} ay "
                          "(tam ay olarak yukarı yuvarlanır).").format(
                              usta, aidat, usta * aidat, yardim,
                              usta * aidat, ay),
                yaygin_yanlislar=yanlis_aylar,
                ipuclari=["Önce bir ayda toplanan parayı bul."],
                puan=12,
            ),
            yorum_adimi(
                soru="Gedik sayısını sınırlamak ne işe yarıyordu?",
                dogru="Dükkân sayısını sabit tutup kalite, fiyat ve hammaddeyi denetlenebilir kılıyordu.",
                yanlislar={
                    "Malları pahalılaştırmak için konmuştu; az dükkân yüksek kâr demekti.":
                        "Fiyat serbest değil, narhla sınırlıydı; sınırın amacı "
                        "fiyatı yükseltmek olarak açıklanamaz.",
                    "Çırakların meslek öğrenmesini engellemek için konmuştu, çünkü eski ustalar rakip istemezdi.":
                        "Tersine, meslek eğitimi loncanın kendi işiydi. Sınır "
                        "ustalığa GEÇİŞİN zamanını belirliyordu, öğrenmeyi değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sınırın bir bedeli de vardı: yetenekli bir kalfa gedik "
                    "açılmadıkça bekliyordu. Bir düzenlemenin hem işe yarayan "
                    "yanını hem bedelini birlikte görmek, tarihte 'iyi/kötü' "
                    "demekten daha kullanışlıdır."
                ),
                puan=12,
            ),
        ],
        kapanis="Kayıt düzeltildi: iki şikâyet de lonca defterine geçti.",
        odul={"itibar": 5, "cevher": 1},
    )


@bulmaca(ders="tarih", konu="vakiflar", kademeler=(9, 12))
def vakfiye_sarti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Vakfiyede yazan şart gelirin nereye gideceğini belirler."""
    # Gelir gideri HER birlesimde asmali: "ne kadar fazla?" sorusunun eksi
    # cevabi olmaz. Eski araliklarda 8 dukkan x 150 + 800 = 2400'un altina
    # dusup fark -100 cikiyordu; testi yazinca goruldu (13 Eylul 2026).
    # En kucuk gelir 8*200+800 = 2400, en buyuk gider 1100+700+500 = 2300.
    dukkan = rastgele.choice([8, 10, 12])
    kira = rastgele.choice([200, 250, 300])
    degirmen = rastgele.choice([800, 1000, 1200])
    imaret = rastgele.choice([900, 1100])
    muderris = rastgele.choice([600, 700])
    su_yolu = rastgele.choice([400, 500])
    gelir = dukkan * kira + degirmen
    gider = imaret + muderris + su_yolu
    fark = gelir - gider
    # Gelir giderin tam iki kati oldugunda "gideri yazdin" hatasi farkin
    # kendisine esit oluyor; o zaman teshis listeye girmez.
    yanlis_fark = {
        gelir - imaret:
            "Yalnız imareti düştün; üç hizmetin hepsi vakfiyede yazılı.",
    }
    if gider != fark:
        yanlis_fark[gider] = "Gideri yazdın. Soru FARKI istiyor."

    return Bulmaca(
        kod="tar-vakfiye-sarti",
        ders="tarih",
        baslik="Vakfiye Şartı",
        kademe=kademe,
        konu="vakiflar",
        kazanim="Vakfiyede hizmet, gelir ve yararlanıcı ilişkisini çıkarma.",
        dikkat=7,
        brifing=(
            "Arşivde bir vakfın yıllık hesabı var. Vakfın geliri {} dükkânın "
            "kirası ve bir değirmenden geliyor; harcaması vakfiyede yazan üç "
            "hizmete gidiyor: imaret, medrese müderrisinin ücreti ve su "
            "yolunun bakımı.\n\n"
            "Bu yıl mütevelli bir soru yazmış: \"Su yolu bu yıl bozulmadı. O "
            "paraya imarette daha çok yemek çıkarsak olur mu?\"\n\n"
            "Cevap hesapta değil, vakfiyede."
        ).format(dukkan),
        kanitlar=[
            Kanit("Gelir kaydı",
                  "{} dükkân × {} akçe kira = {} akçe. Değirmen: {} akçe.".format(
                      dukkan, kira, dukkan * kira, degirmen),
                  bedel=2, kritik=True),
            Kanit("Gider kaydı",
                  "İmaret {} akçe, müderris ücreti {} akçe, su yolu bakımı "
                  "{} akçe.".format(imaret, muderris, su_yolu),
                  bedel=2, kritik=True),
            Kanit("Vakfiyeden satır",
                  "\"Gelirden her yıl su yolunun bakımına ayrılan pay, başka "
                  "bir hizmete harcanmaz. Şart-ı vâkıfa aykırı tasarruf "
                  "geçersizdir.\"", bedel=2, kritik=True),
            Kanit("Mütevelli notu",
                  "\"Su yolu bu yıl bozulmadı; ayrılan pay elde kaldı.\"",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Vakfın gelirinin nereye harcanacağını ne belirler?",
                dogru=("Vakfiyede yazan şart: vâkıfın koyduğu koşul, mütevelliyi "
                       "de bağlar"),
                yanlislar={
                    "Mütevellinin o yılki kararı; yönetim kimdeyse o belirler":
                        "Mütevelli vakfı YÖNETİR ama şartı değiştiremez. "
                        "Vakfiyeden okuduğun satır bunu açıkça yazıyor.",
                    "O yılın en acil ihtiyacı; ihtiyaç neredeyse para oraya gider":
                        "İhtiyaç ölçüt olsaydı vakfın süreklilik vaadi kalmazdı: "
                        "müderris ücretini her yıl başka bir acil iş yiyebilirdi.",
                    "Gelirin geldiği yer: dükkân kirası esnafa, değirmen geliri "
                    "çiftçiye harcanır":
                        "Gelirin kaynağı harcamanın yerini belirlemez. Vakıf "
                        "gelirleri ortak havuzdur, dağıtımı vakfiye yazar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Vakfın ayırt edici yanı süreklilik: bir kez şart konur, "
                    "gelir o şarta bağlanır ve yönetici bile bunu "
                    "değiştiremez. Bu yüzden vakıf yüzyıllar boyunca aynı "
                    "hizmeti sürdürebiliyordu -- ve bu yüzden ihtiyaç değişince "
                    "hantal kalabiliyordu. İkisi aynı kuralın iki yüzü."
                ),
                ipuclari=[
                    "Mütevelli neyi yapabilir, neyi yapamaz? Vakfiye satırına bak.",
                    "Bu kural olmasa vakıf gelecek yıl aynı hizmeti verir miydi?",
                ],
            ),
            sayi_adimi(
                soru="Vakfın bu yıl geliri ne kadar?",
                cevap=gelir,
                birim="akçe",
                aciklama="{} × {} + {} = {}.".format(dukkan, kira, degirmen, gelir),
                yaygin_yanlislar={
                    dukkan * kira:
                        "Değirmeni saymadın; vakfın iki gelir kaynağı var.",
                    kira + degirmen:
                        "Kirayı bir dükkân saydın; kayıtta {} dükkân "
                        "var.".format(dukkan),
                },
                ipuclari=["İki kalemi ayrı hesapla, sonra topla."],
                puan=12,
            ),
            sayi_adimi(
                soru="Gelir giderden ne kadar fazla?",
                cevap=fark,
                birim="akçe",
                aciklama="{} - ({} + {} + {}) = {}.".format(
                    gelir, imaret, muderris, su_yolu, fark),
                yaygin_yanlislar=yanlis_fark,
                ipuclari=["Önce üç hizmetin toplamını bul."],
                puan=12,
            ),
            yorum_adimi(
                soru="Mütevellinin sorusuna cevap ne olmalı?",
                dogru="Olmaz: su yolunun payı vakfiyeyle bağlı; kullanılmasa da başka işe aktarılamaz.",
                yanlislar={
                    "Olur: para elde kaldığına göre en yararlı işe harcanır; boş duran para israftır.":
                        "Yararlılık ölçütü vakfiyenin şartını geçersiz kılmaz. "
                        "Aksi hâlde her yıl başka bir gerekçeyle şart aşılırdı.",
                    "Olur, ama yalnız mütevelli ile esnafın birlikte karar "
                    "vermesi şartıyla.":
                        "Şartı değiştirmek kimsenin ortak kararıyla olmaz; "
                        "bağlayan şey vâkıfın koyduğu koşuldur.",
                    "Olmaz, çünkü vakıf yemek dağıtamaz; yemek loncanın işidir.":
                        "İmaret zaten bu vakfın hizmeti. Lonca ile vakfı "
                        "karıştırdın: loncanın işi üretim ve meslek denetimi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bu görevin konusu aslında tek bir ayrım: vakıf GELİRİNİ "
                    "şarta bağlar, lonca ÜYESİNİ ve üretimi düzenler. İkisi de "
                    "şehri ayakta tutar ama biri diğerinin yerine geçemez."
                ),
                puan=12,
            ),
        ],
        kapanis="Hesap kapandı: su yolu payı kendi kaleminde bekletildi.",
        odul={"itibar": 5, "erzak": 2},
    )


# ==========================================================================
# TARIM DEVRİMİ: TARIM HER YERDE AYNI ANDA BAŞLAMADI (B37.15)
#
# `tarim_devrimi` (2026: 9) ile `yazi_oncesi_yasam` ve `ilk_cag_cografya_uretim`
# (2023: 9) aynı yaygın yanlışı ve aynı bağlamı paylaşıyor: "Eski depo
# kalıntılarından yerleşme ve üretim ilişkisini çıkarma". `yaygin_yanlis`:
#
#   "Tarımın her yerde aynı anda başladığını sanmak."
#
# DÜZENEK: farklı bölgelerden depo kalıntısı kayıtları. Her kayıtta en eski
# tarım izinin yaklaşık tarihi ve depodaki türlerin yabani atalarının bölgede
# yetişip yetişmediği yazıyor. Yabani atası bölgede yetişen tür orada
# evcilleştirilmiştir (bağımsız merkez); yetişmeyen tür başka yerden gelmiştir
# (yayılma). Tarihler yuvarlak ve yaklaşıktır.
#
# YANILGININ SAYISAL KARŞILIĞI: en eski ve en yeni tarım izi arasındaki farkı
# 0 yıl saymak.
# ==========================================================================

# (bölge, yaklaşık MÖ yıl, depodaki türler, yabani ataları bölgede yetişiyor mu)
_TARIM_DEPOLARI = (
    ("Güneydoğu Anadolu", 9000, "siyez buğdayı, arpa, mercimek; koyun ve keçi kemikleri", True),
    ("Meksika yaylaları", 8000, "kabak çekirdekleri", True),
    ("Çin (Yangzi havzası)", 7000, "pirinç taneleri", True),
    ("And Dağları", 6000, "patates ve kinoa kalıntıları", True),
    ("Sudan (Sahel kuşağı)", 3000, "sorgum taneleri", True),
    ("Doğu Kuzey Amerika", 2500, "ayçiçeği ve yerli kabak tohumları", True),
    ("Yunanistan (Tesalya)", 6500, "gernik buğdayı, mercimek; koyun ve keçi kemikleri", False),
    ("Orta Avrupa (Tuna havzası)", 5500, "gernik buğdayı, bezelye; koyun kemikleri", False),
    ("Mısır (Nil vadisi)", 5000, "gernik buğdayı; koyun ve keçi kemikleri", False),
    ("Britanya", 4000, "gernik buğdayı, arpa; koyun kemikleri", False),
)


@bulmaca(ders="tarih", konu="tarim_devrimi", kademeler=(9, 12), agirlik=1.3)
def depo_kalintilari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tarım birkaç merkezde farklı zamanlarda başladı; başka yerlere yayılarak ulaştı."""
    anadolu = _TARIM_DEPOLARI[0]
    merkezler = [d for d in _TARIM_DEPOLARI[1:] if d[3]]
    yayilma = [d for d in _TARIM_DEPOLARI if not d[3]]
    kac_merkez = rastgele.choice((1, 2))
    depolar = ([anadolu] + rastgele.sample(merkezler, kac_merkez)
               + rastgele.sample(yayilma, 4 - kac_merkez))
    rastgele.shuffle(depolar)
    adlar = [d[0] for d in depolar]
    bagimsiz = [n for n, d in enumerate(depolar) if d[3]]
    en_eski = max(d[1] for d in depolar)
    en_yeni = min(d[1] for d in depolar)
    fark = en_eski - en_yeni
    dogru_sira = [depolar.index(d) for d in sorted(depolar, key=lambda d: -d[1])]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-depo-kalintilari",
        ders="tarih",
        baslik="Depo Kalıntıları",
        kademe=kademe,
        konu="tarim_devrimi",
        kazanim="Arkeolojik depo kalıntılarından yerleşme ile üretim arasındaki ilişkiyi "
                "çıkarma; tarımın birkaç merkezde birbirinden bağımsız ve farklı "
                "zamanlarda başladığını, başka bölgelere yayılarak ulaştığını "
                "kanıtla gösterme.",
        dikkat=7,
        brifing=(
            "Arkeoloji ekibi beş farklı bölgedeki eski depo kalıntılarının kayıtlarını "
            "üsse gönderdi.\n\n"
            "{} kayıtları okuyunca şunu söyledi: \"Tarım insanlık tarihinde her yerde "
            "aynı anda başladı. Bu depoların hepsi aynı dönemden; en eskisiyle en yenisi "
            "arasında fark yok.\"\n\n"
            "Rapor yazılmadan önce kayıtları tarihleri ve türleriyle karşılaştırmamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Depo kayıtları",
                  "\n".join("{}: en eski tarım izi yaklaşık MÖ {}. Depoda {}. Bu türlerin "
                            "yabani ataları bölgede {}.".format(
                                d[0], d[1], d[2], "yetişiyor" if d[3] else "yetişmiyor")
                            for d in depolar),
                  bedel=1, kritik=True),
            Kanit("Botanik notu",
                  "Bir bitki ya da hayvan, yabani atasının yaşadığı yerde evcilleştirilir. "
                  "Yabani atası bölgede bulunmayan bir tür oraya başka bir yerden "
                  "getirilmiştir.",
                  bedel=1, kritik=True),
            Kanit("Kazı notu",
                  "Depoların yanında kerpiç ev temelleri, tahıl ambarları ve öğütme "
                  "taşları bulundu.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Depo kayıtlarına göre tarım nasıl başladı?",
                dogru="Birkaç merkezde bağımsız ve farklı zamanlarda başlayıp yayıldı",
                yanlislar={
                    "Her yerde aynı anda başladı":
                        "Tarımın her yerde aynı anda başladığını sandın. Kayıtlardaki "
                        "tarihler binlerce yıl farklı.",
                    "Tek bir merkezde başlayıp bütün dünyaya oradan yayıldı; buluş bir kez yapılır":
                        "Pirinç, kabak ve patatesin yabani ataları Anadolu'da yetişmez; "
                        "bu türler kendi bölgelerinde evcilleştirildi.",
                    "Önce iklimi en soğuk bölgelerde başladı; kıtlık insanı ekmeye zorladı":
                        "En eski izler soğuk bölgelerde değil, ılıman vadilerde.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarım, yabani ataları bölgede yetişen türlerle birkaç merkezde ayrı "
                    "ayrı başladı: Güneydoğu Anadolu, Çin, Meksika, And Dağları gibi. "
                    "Avrupa ve Nil vadisi gibi bölgelere ise yüzyıllar, hatta binlerce yıl "
                    "içinde yayılarak geldi."
                ),
                ipuclari=[
                    "Depo kayıtlarındaki tarihler birbirine eşit mi?",
                    "Botanik notuna göre bir tür nerede evcilleştirilir?",
                ],
                cozum="Yabani atası bölgede: bağımsız merkez\nYabani atası bölgede değil: yayılma",
            ),
            sayi_adimi(
                soru="Bu beş depodaki en eski ve en yeni tarım izi arasında kaç yıl var?",
                cevap=fark,
                birim="yıl",
                aciklama="MÖ {} ile MÖ {} arası: {} − {} = {} yıl.".format(en_eski, en_yeni, en_eski, en_yeni, fark),
                yaygin_yanlislar={
                    0:
                        "Tarımın her yerde aynı anda başladığını sandın; tarihler "
                        "arasında binlerce yıl var.",
                },
                ipuclari=["MÖ tarihlerde büyük sayı daha eskidir; ikisini birbirinden çıkar."],
                puan=12,
            ),
            sirala_adimi(
                soru="Bölgeleri tarımın başladığı zamana göre eskiden yeniye sırala.",
                secenekler=adlar,
                dogru_sira=dogru_sira,
                aciklama="Sıra: {}.".format(", ".join(
                    "{} (MÖ {})".format(d[0], d[1]) for d in sorted(depolar, key=lambda d: -d[1]))),
                ipuclari=["MÖ tarihlerde sayı büyüdükçe olay daha eskidir."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi bölgeler tarımın bağımsız başladığı merkezlerdendir? "
                     "(numaraları virgülle yaz)",
                secenekler=adlar,
                dogru_indeksler=bagimsiz,
                aciklama=("Depodaki türlerin yabani ataları bölgede yetişiyorsa tarım orada "
                          "başlamıştır; yetişmiyorsa tarım oraya yayılarak gelmiştir."),
                ipuclari=["Her kayıtta yabani ataların bölgede yetişip yetişmediğine bak."],
                puan=14,
            ),
            yorum_adimi(
                soru="Kazı notundaki ambarlar ve kerpiç evler neyi gösterir?",
                dogru="Ürün fazlasının saklandığını ve yerleşik hayata geçildiğini",
                yanlislar={
                    "Toplulukların hâlâ yalnız avlanarak göçebe yaşadığını":
                        "Ambar ve kalıcı ev, yerleşik üretimin izidir.",
                    "Bütün bölgelerde aynı yıl ambar yapılmaya başlandığını":
                        "Tarımın her yerde aynı anda başladığını sandın; ambarlar da "
                        "tarımla birlikte, farklı zamanlarda ortaya çıktı.",
                    "Tahılın başka bölgelerden satın alındığını; ambar bir ticaret deposudur":
                        "Öğütme taşları ve tarlalar tahılın yerinde üretildiğini gösteriyor.",
                },
                rastgele=rastgele,
                aciklama=("Tarım ürün fazlası sağladı; fazlayı saklamak için ambarlar, "
                          "tarlaların yanında kalmak için kalıcı evler yapıldı."),
                ipuclari=["Ambar neden gerekir? Göçebe bir topluluk ambar taşıyabilir mi?"],
                puan=10,
            ),
        ],
        kapanis=("Rapor düzeltildi: bu beş depoda tarım izleri arasında {} yıl var. "
                 "Tarım birkaç merkezde ayrı ayrı başladı, başka bölgelere yayılarak ulaştı."
                 ).format(fark),
        odul={"itibar": 5, "erzak": 2, "cevher": 1},
    )


# ==========================================================================
# OSMANLI KÜLTÜRÜ 1453-1683: BİR ESER BÜTÜN DÖNEMİ ANLATMAZ (B37.15)
#
# `osmanli_kultur_urunu` (2026: 10) ile `osmanli_erken_kultur` (2023: 10),
# `osmanli_ilim_irfan` (2026: 10), `osmanli_ortak_miras_urunu` (2026: 11) aynı
# yaygın yanlışı ve aynı bağlamı paylaşıyor: "Tarihî atölye ve eğitim kurumu
# belgelerini dönemleriyle eşleme". `yaygin_yanlis`:
#
#   "Bir eserden bütün dönemin aynı özellikte olduğu sonucunu çıkarmak."
#
# DÜZENEK: sergi vitrini için eser kartları. Bir personel tek bir eserden
# bütün dönem için genelleme yapıyor: Süleymaniye'yi görüp "bütün yapılar
# büyük kubbeli camiydi", bir el yazmasını görüp "İstanbul'da hiç basılı
# kitap yoktu" diyor. Kartlar köprü, saray, çarşı; Yahudi, Ermeni ve Rum
# matbaalarının basılı kitaplarını da gösteriyor.
#
# YANILGININ SAYISAL KARŞILIĞI: dönem kartlarının hepsini o özellikte saymak.
# ==========================================================================

# (eser, yıl, açıklama, özellik taşıyor mu)
_DONEM_ESERLERI = {
    "mimari": {
        "ozellik": "büyük merkezî kubbeli camidir",
        "iddia": ("{} büyük merkezî kubbeli bir cami; demek ki bu dönemde yapılan "
                  "bütün eserler büyük kubbeli camilerdi."),
        "dogru_cumle": ("Bu dönemde kubbeli camilerin yanında köprü, saray, çarşı gibi "
                        "farklı yapılar da yapıldı"),
        "genelleme": ("Bu dönemde yapılan bütün eserler büyük kubbeli camilerdi; dönemin "
                      "en ünlü eserleri bunlardır"),
        "karsi_uc": "Bu dönemde hiç büyük kubbeli cami yapılmadı",
        "donem": (
            ("Süleymaniye Camii", 1557, "İstanbul; Mimar Sinan. Büyük merkezî kubbeli cami.", True),
            ("Selimiye Camii", 1575, "Edirne; Mimar Sinan. Büyük merkezî kubbeli cami.", True),
            ("Sultanahmet Camii", 1616, "İstanbul; Sedefkâr Mehmed Ağa. Büyük merkezî kubbeli cami.", True),
            ("Cevahir Bedesteni", 1461, "İstanbul; Kapalıçarşı'nın çekirdeği olan taş çarşı binası.", False),
            ("Topkapı Sarayı'nın ilk yapıları", 1478, "İstanbul; avlular ve köşklerden oluşan saray.", False),
            ("Mostar Köprüsü", 1566, "Hersek; Mimar Hayreddin. Tek kemerli taş köprü.", False),
            ("Büyükçekmece Köprüsü", 1567, "İstanbul; Mimar Sinan. Dört bölümlü uzun taş köprü.", False),
            ("Bağdat Köşkü", 1639, "Topkapı Sarayı; Bağdat seferinin anısına yapılan köşk.", False),
        ),
        "disari": (
            ("Bursa Ulu Camii", 1400, "Bursa; yirmi kubbeli cami."),
            ("Nuruosmaniye Camii", 1755, "İstanbul; Batı etkili süslemeleriyle cami."),
        ),
    },
    "kitap": {
        "ozellik": "el yazmasıdır",
        "iddia": ("{} bir el yazması; demek ki bu dönemde bütün kitaplar elle "
                  "yazılıyordu, İstanbul'da hiç basılı kitap yoktu."),
        "dogru_cumle": ("Müslümanlar çoğunlukla el yazması kullanıyordu; Yahudi, Ermeni "
                        "ve Rum matbaaları ise kitap basıyordu"),
        "genelleme": ("Bu dönemde bütün kitaplar elle yazılıyordu; İstanbul'da hiç basılı "
                      "kitap yoktu, matbaa 1727'de geldi"),
        "karsi_uc": ("Bu dönemde bütün kitaplar matbaada basılıyordu; matbaa Avrupa'da "
                     "1450'lerde yayılmıştı"),
        "donem": (
            ("Kitab-ı Bahriye", 1521, "Piri Reis; denizcilik kitabı. El yazması.", True),
            ("Beyân-ı Menâzil", 1537, "Matrakçı Nasuh; şehir resimli sefer kitabı. El yazması.", True),
            ("Hünername", 1584, "Seyyid Lokman; minyatürlü tarih kitabı. El yazması.", True),
            ("Cihannüma", 1648, "Kâtip Çelebi; coğrafya kitabı. El yazması.", True),
            ("Arbaa Turim", 1493, "İstanbul'daki Yahudi matbaasında basılan hukuk kitabı. Basılı.", False),
            ("Abgar Tıbir'in Ermenice kitapları", 1567, "İstanbul'daki Ermeni matbaası. Basılı.", False),
            ("Metaksas matbaasının Yunanca kitapları", 1627, "İstanbul'daki Rum matbaası. Basılı.", False),
        ),
        "disari": (
            ("İskendername", 1390, "Ahmedî; manzum hikâye. El yazması."),
            ("Vankulu Lügati", 1729, "İbrahim Müteferrika'nın matbaasında basılan sözlük."),
        ),
    },
}


@bulmaca(ders="tarih", konu="osmanli_kultur_urunu", kademeler=(10, 12), agirlik=1.3)
def donem_vitrini(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tek bir eserden 1453-1683 döneminin tamamı için genelleme yapılamaz."""
    tema = _DONEM_ESERLERI[rastgele.choice(sorted(_DONEM_ESERLERI))]
    var = [k for k in tema["donem"] if k[3]]
    yok = [k for k in tema["donem"] if not k[3]]
    ornek = rastgele.choice(var)
    kac_var = rastgele.choice((2, 3))
    donem_kartlari = ([ornek] + rastgele.sample([k for k in var if k != ornek], kac_var - 1)
                      + rastgele.sample(yok, 5 - kac_var))
    disari = rastgele.choice(tema["disari"])
    kartlar = [(k[0], k[1], k[2]) for k in donem_kartlari] + [disari]
    rastgele.shuffle(kartlar)
    secenekler = ["{} ({})".format(k[0], k[1]) for k in kartlar]
    donem_ici = [n for n, k in enumerate(kartlar) if 1453 <= k[1] <= 1683]
    tasiyan = sum(1 for k in donem_kartlari if k[3])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    ornek_ad = "{} ({})".format(ornek[0], ornek[1])

    return Bulmaca(
        kod="tar-donem-vitrini",
        ders="tarih",
        baslik="Dönem Vitrini",
        kademe=kademe,
        konu="osmanli_kultur_urunu",
        kazanim="1453-1683 Osmanlı bilim, eğitim, kültür ve sanat eserlerini dönemleriyle "
                "eşleme; tek bir eserden bütün dönem için genelleme yapmama; farklı "
                "türden çok sayıda kanıtla dönem hakkında dengeli bir sergi metni yazma.",
        dikkat=7,
        brifing=(
            "Sefer arşivinde 1453-1683 dönemi için bir sergi vitrini hazırlanıyor.\n\n"
            "{} ilk kartı eline alınca şunu yazdı: \"{}\"\n\n"
            "Vitrin açılmadan önce kartları dönemleriyle eşleyip bu genellemeyi "
            "sınamamız gerekiyor."
        ).format(kisi, tema["iddia"].format(ornek_ad)),
        kanitlar=[
            Kanit("Eser kartları",
                  "\n".join("{} ({}): {}".format(k[0], k[1], k[2]) for k in kartlar),
                  bedel=1, kritik=True),
            Kanit("Küratör notu",
                  "Bir eser, yapıldığı yer, zaman ve çevre hakkında kanıttır. Bir dönem "
                  "için genelleme yapmak için farklı yerlerden, farklı türlerden ve "
                  "farklı yıllardan çok sayıda esere bakmak gerekir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Tek bir eserden dönem hakkında ne söylenebilir?",
                dogru="Kendi yeri, zamanı ve çevresi için bilgi verir; genelleme farklı türden çok eser ister",
                yanlislar={
                    "Dönemin bütün eserlerinin aynı özellikte olduğu söylenebilir; her eser dönemin aynasıdır":
                        "Bir eserden bütün dönemin aynı özellikte olduğu sonucunu çıkardın.",
                    "En ünlü eser dönemin tamamını temsil eder":
                        "Ünlü olmak temsil etmek demek değildir; bir eserden bütün dönemin "
                        "aynı özellikte olduğu sonucunu çıkardın.",
                    "Hiçbir şey söylenemez; eserler tarih için kanıt değildir, kanıt yazılı belgedir":
                        "Eser kanıttır; ama yalnız kendi yeri ve zamanı için.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir eser, onu yapan kişi ve çevre hakkında güçlü bir kanıttır. Bir "
                    "dönemin tamamı hakkında konuşmak için farklı şehirlerden, farklı "
                    "türlerden ve farklı yıllardan esere bakılır."
                ),
                ipuclari=[
                    "Küratör notunda genelleme için ne isteniyor?",
                    "Kartlarda yalnız bir tür eser mi var?",
                ],
                cozum="1) Kartları döneme göre ayır.\n2) Dönem kartlarında özelliği taşıyanları say.",
            ),
            coklu_adimi(
                soru="Hangi kartlar 1453-1683 dönemine aittir? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=donem_ici,
                aciklama="{} bu dönemin dışında kalıyor.".format("{} ({})".format(disari[0], disari[1])),
                ipuclari=["Her kartın yılını 1453 ve 1683 ile karşılaştır."],
                puan=12,
            ),
            sayi_adimi(
                soru="Dönemin 5 kartından kaç tanesi {}?".format(tema["ozellik"]),
                cevap=tasiyan,
                aciklama="Özelliği taşıyan: {}.".format(", ".join(k[0] for k in donem_kartlari if k[3])),
                yaygin_yanlislar={
                    5:
                        "Bir eserden bütün dönemin aynı özellikte olduğu sonucunu çıkardın; "
                        "kartların bir kısmı bu özelliği taşımıyor.",
                },
                ipuclari=["Her dönem kartının açıklamasını oku."],
                puan=12,
            ),
            yorum_adimi(
                soru="Vitrin metni için hangi cümle kanıtlara uygundur?",
                dogru=tema["dogru_cumle"],
                yanlislar={
                    tema["genelleme"]:
                        "Bir eserden bütün dönemin aynı özellikte olduğu sonucunu çıkardın.",
                    tema["karsi_uc"]:
                        "Ters yönde genelleme yaptın; kartlarda bu özelliği taşıyan eserler de var.",
                },
                rastgele=rastgele,
                aciklama="Dengeli metin, kartlardaki farklı türden eserlerin hepsini hesaba katar.",
                ipuclari=["Cümle bütün dönem kartlarıyla uyumlu mu?"],
                puan=12,
            ),
        ],
        kapanis=("Vitrin düzeltildi: dönemin 5 kartından {} tanesi bu özelliği taşıyor. "
                 "Metin tek esere değil, bütün kartlara dayanıyor.").format(tasiyan),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# VERASET: OSMANLI'DA TAHTA GEÇME KURALI DEĞİŞTİ (B37.15)
#
# `osmanli_merkezi_otorite` tek satırlıktı (2023: 10). Bağlam: "Arşivde sarayın
# eğitim ve yönetim işlevlerini belgeyle ilişkilendirme". `yaygin_yanlis`:
#
#   "Veraset düzeninin bütün Osmanlı tarihi boyunca değişmediğini sanmak."
#
# DÜZENEK: saray arşivindeki tahta çıkış kayıtları ve dört kural notu: ülke
# hanedanın ortak malı (Osman, Orhan) -> padişah ve oğullarının malı (I. Murad)
# -> Kanunnâme ile kardeş katli, şehzadeler sancakta (Fatih) -> ekberiyet ve
# sarayda yetişme (I. Ahmed; ilk uygulama 1617). Ekberiyet döneminde tahta
# çoğu kez padişahın kardeşi geçti; "hep büyük oğul" kuralı hiç olmadı.
#
# YANILGININ SAYISAL KARŞILIĞI: kayıtlardaki farklı kural sayısını 1 saymak.
# ==========================================================================

_VERASET_KURALLARI = {
    "ortak": ("Ülke hanedanın ortak malıdır; hanedanın her erkek üyesi tahtta hak "
              "iddia edebilir (Osman ve Orhan Bey dönemleri)."),
    "ogullar": ("Ülke padişah ve oğullarının malıdır; taht hakkı yalnız padişahın "
                "oğullarına geçer (I. Murad döneminde getirildi)."),
    "kanunname": ("Kanunnâme-i Âl-i Osman: tahta geçen şehzade nizam-ı âlem için "
                  "kardeşlerini öldürtebilir (Fatih döneminde yazıya geçirildi). Bu "
                  "dönemde şehzadeler sancaklarda yönetim deneyimi kazanır."),
    "ekberiyet": ("Ekberiyet: hanedanın en yaşlı erkek üyesi tahta geçer; şehzadeler "
                  "sancağa çıkmaz, sarayda yetişir (I. Ahmed döneminde başladı, ilk "
                  "uygulama 1617)."),
}
_VERASET_SIRASI = ("ortak", "ogullar", "kanunname", "ekberiyet")
_VERASET_ADLARI = {
    "ortak": "hanedanın ortak malı", "ogullar": "padişah ve oğulları",
    "kanunname": "Kanunnâme", "ekberiyet": "ekberiyet",
}

# (yıl, kayıt, o tahta çıkışta geçerli kural)
_TAHT_KAYITLARI = (
    (1324, "Orhan Bey, babası Osman Bey'in yerine geçti.", "ortak"),
    (1389, "Yıldırım Bayezid, Kosova'da babası I. Murad'ın ölümü üzerine tahta geçti.", "ogullar"),
    (1413, "Çelebi Mehmed, kardeşleriyle on bir yıl süren mücadeleden sonra tek başına tahta geçti.", "ogullar"),
    (1451, "II. Mehmed, babası II. Murad'ın ölümüyle ikinci kez tahta geçti.", "ogullar"),
    (1481, "II. Bayezid, babası Fatih'in ölümünden sonra kardeşi Cem Sultan'la taht mücadelesine girdi.", "kanunname"),
    (1520, "Kanuni Sultan Süleyman, babası Yavuz Selim'in yerine geçti; önce Manisa sancağını yönetmişti.", "kanunname"),
    (1595, "III. Mehmed, babası III. Murad'ın yerine geçti; önce Manisa sancağını yönetmişti.", "kanunname"),
    (1617, "I. Mustafa, kardeşi I. Ahmed'in ölümü üzerine tahta geçti.", "ekberiyet"),
    (1640, "Sultan İbrahim, kardeşi IV. Murad'ın ölümü üzerine tahta geçti.", "ekberiyet"),
    (1687, "II. Süleyman, kardeşi IV. Mehmed tahttan indirilince tahta geçti.", "ekberiyet"),
    (1691, "II. Ahmed, kardeşi II. Süleyman'ın ölümü üzerine tahta geçti.", "ekberiyet"),
)


@bulmaca(ders="tarih", konu="osmanli_merkezi_otorite", kademeler=(10, 12), agirlik=1.3)
def taht_kayitlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Osmanlı veraset düzeni kuruluştan 17. yüzyıla birkaç kez değişti."""
    ekber = [k for k in _TAHT_KAYITLARI if k[2] == "ekberiyet"]
    odak = rastgele.choice(ekber)
    kalan = [k for k in _TAHT_KAYITLARI if k != odak]
    kayitlar = sorted([odak] + rastgele.sample(kalan, 4), key=lambda k: k[0])
    farkli = len({k[2] for k in kayitlar})
    kural_adlari = list(_VERASET_SIRASI)
    rastgele.shuffle(kural_adlari)
    kural_metinleri = [_VERASET_KURALLARI[a] for a in kural_adlari]
    dogru_sira = [kural_adlari.index(a) for a in _VERASET_SIRASI]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-taht-kayitlari",
        ders="tarih",
        baslik="Taht Kayıtları",
        kademe=kademe,
        konu="osmanli_merkezi_otorite",
        kazanim="Osmanlı veraset düzeninin kuruluştan 17. yüzyıla nasıl değiştiğini "
                "belgelerle açıklama; kardeş katlinin kanunlaşmasını ve ekberiyet "
                "usulünü merkezî otoriteyle ilişkilendirme.",
        dikkat=7,
        brifing=(
            "Saray arşivinden tahta çıkış kayıtları üsse ulaştı.\n\n"
            "{} kayıtlara şu notu düştü: \"Osmanlı'da tahta geçme kuralı kuruluştan "
            "yıkılışa hiç değişmedi: her seferinde padişahın en büyük oğlu tahta "
            "geçti. Bu kayıtların hepsi aynı kurala göre.\"\n\n"
            "Not arşive girmeden önce kayıtları kural notlarıyla karşılaştırmamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Tahta çıkış kayıtları",
                  "\n".join("{}: {}".format(y, m) for y, m, _ in kayitlar),
                  bedel=1, kritik=True),
            Kanit("Kural notları", "\n".join(kural_metinleri), bedel=1, kritik=True),
            Kanit("Padişah sırası",
                  "Osman Bey, Orhan Bey, I. Murad, Yıldırım Bayezid, (Fetret Devri), "
                  "Çelebi Mehmed, II. Murad, II. Mehmed (Fatih), II. Bayezid, Yavuz "
                  "Selim, Kanuni Süleyman, ... III. Murad, III. Mehmed, I. Ahmed, "
                  "I. Mustafa, ...",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Osmanlı veraset düzeni için hangisi doğrudur?",
                dogru="Kural zamanla değişti; değişiklikler taht kavgalarını azaltmayı amaçladı",
                yanlislar={
                    "Kuruluştan yıkılışa hiç değişmedi":
                        "Veraset düzeninin bütün Osmanlı tarihi boyunca değişmediğini "
                        "sandın. Kural notlarında dört ayrı düzen var.",
                    "Her zaman padişahın en büyük oğlu tahta geçti; Avrupa hanedanlarında da böyleydi":
                        "Osmanlı'da büyük oğul kuralı hiç olmadı; ekberiyet döneminde "
                        "tahta çoğu kez padişahın kardeşi geçti.",
                    "Padişahı her zaman Divan seçimle belirledi; devlet işleri Divan'da görüşülürdü":
                        "Taht hanedan içinde kalırdı; Divan padişah seçmezdi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kuruluşta ülke hanedanın ortak malı sayılıyordu; bu, taht kavgalarına "
                    "yol açtı. I. Murad hakkı padişahın oğullarıyla sınırladı, Fatih kardeş "
                    "katlini kanunlaştırdı, I. Ahmed'den sonra ekberiyet ve şehzadelerin "
                    "sarayda yetişmesi usulü geldi."
                ),
                ipuclari=[
                    "Kural notlarında kaç farklı düzen var?",
                    "Ekberiyet döneminde tahta kim geçiyor?",
                ],
                cozum="Hanedanın ortak malı -> padişah ve oğulları -> Kanunnâme -> ekberiyet",
            ),
            sirala_adimi(
                soru="Kural notlarını eskiden yeniye sırala.",
                secenekler=kural_metinleri,
                dogru_sira=dogru_sira,
                aciklama="Osman-Orhan, I. Murad, Fatih, I. Ahmed sırasıyla.",
                ipuclari=["Her notun sonundaki padişahı padişah sırasında bul."],
                puan=12,
            ),
            sayi_adimi(
                soru="Arşivdeki beş tahta çıkışta kaç farklı veraset kuralı uygulanmış?",
                cevap=farkli,
                aciklama="Kayıtlar: {}.".format("; ".join(
                    "{} {}".format(y, _VERASET_ADLARI[k]) for y, _, k in kayitlar)),
                yaygin_yanlislar={
                    1:
                        "Veraset düzeninin bütün Osmanlı tarihi boyunca değişmediğini "
                        "sandın; kayıtlar farklı dönemlerden.",
                },
                ipuclari=["Her kaydın yılını kural notlarının dönemiyle eşle; farklı olanları say."],
                puan=12,
            ),
            secim_adimi(
                soru="\"{}: {}\" kaydı hangi kuralla açıklanır?".format(odak[0], odak[1]),
                dogru=_VERASET_KURALLARI["ekberiyet"].split(";")[0],
                yanlislar={
                    "Padişahın en büyük oğlu tahta geçer":
                        "Veraset düzeninin hiç değişmediğini ve hep büyük oğulun geçtiğini "
                        "sandın; burada tahta padişahın kardeşi geçti.",
                    "Ülke hanedanın ortak malıdır":
                        "Bu kural kuruluş dönemine aitti; 17. yüzyılda uygulanmıyordu.",
                    "Kanunnâme: tahta geçen şehzade kardeşlerini öldürtebilir":
                        "Kanunnâme döneminde şehzadeler sancakta yetişir, taht padişahın "
                        "oğluna geçerdi.",
                },
                rastgele=rastgele,
                aciklama=("{} yılında hanedanın en yaşlı erkek üyesi tahta geçti: "
                          "ekberiyet.").format(odak[0]),
                ipuclari=["Tahta geçen kişi önceki padişahın oğlu mu, kardeşi mi?"],
                puan=10,
            ),
            yorum_adimi(
                soru="Kardeş katlinin Kanunnâme ile meşrulaştırılmasının amacı neydi?",
                dogru="Taht kavgasını ve bölünmeyi önleyip merkezî otoriteyi korumak",
                yanlislar={
                    "Ülkeyi şehzadeler arasında paylaştırmak; eski Türk devletlerinde böyleydi":
                        "Amaç tam tersi: ülkenin bölünmesini önlemek.",
                    "Hiçbir amacı yoktu; kural zaten hiç değişmedi":
                        "Veraset düzeninin bütün Osmanlı tarihi boyunca değişmediğini sandın.",
                    "Şehzadelere sancakta yönetim deneyimi kazandırmak":
                        "Sancağa çıkma ayrı bir usuldü; kardeş katlinin amacı taht "
                        "kavgasını önlemekti.",
                },
                rastgele=rastgele,
                aciklama=("Fetret Devri gibi taht kavgaları devleti bölünme tehlikesine "
                          "sokmuştu; Kanunnâme merkezî otoriteyi korumak için bu kuralı "
                          "yazıya geçirdi."),
                ipuclari=["Padişah sırasındaki Fetret Devri'ni düşün: şehzadeler arasında ne olmuştu?"],
                puan=10,
            ),
        ],
        kapanis=("Not düzeltildi: beş kayıtta {} farklı veraset kuralı uygulanmış. "
                 "Osmanlı'da tahta geçme düzeni merkezî otoriteyi korumak için birkaç kez "
                 "değişti.").format(farkli),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# TOPKAPI SARAYI: SARAY YALNIZ KONUT DEĞİLDİ (B37.15)
#
# `topkapi_enderun_divan` tek satırlıktı (2023: 10). Bağlam: "Arşivde sarayın
# eğitim ve yönetim işlevlerini belgeyle ilişkilendirme". `yaygin_yanlis`:
#
#   "Sarayın yalnız konut olduğunu sanmak."
#
# DÜZENEK: saray arşivinden belgeler. Divan-ı Hümayun, Arz Odası ve Dış
# Hazine yönetim; Enderun odaları ve Has Oda eğitim; Harem ve Matbah-ı Âmire
# yaşam (konut) işlevini gösterir.
#
# YANILGININ SAYISAL KARŞILIĞI: belgelerin hepsini konutla ilgili saymak.
# ==========================================================================

# (bölüm, belge metni, işlev)
_SARAY_BELGELERI = (
    ("Kubbealtı", "Vezîriâzam ve vezirler Divan-ı Hümayun'da haftada dört gün toplanıp "
                  "davaları ve devlet işlerini görüştü.", "yönetim"),
    ("Arz Odası", "Divan üyeleri görüşmelerin sonucunu padişaha burada sundu; yabancı "
                  "elçiler burada kabul edildi.", "yönetim"),
    ("Dış Hazine", "Divan'ın yanındaki hazinede devletin vergi gelirleri saklandı; "
                   "askerlerin maaşı buradan ödendi.", "yönetim"),
    ("Enderun odaları", "Devşirmeyle alınan yetenekli gençler okuma yazma, Arapça, Farsça, "
                        "hat, musiki ve silah eğitimi aldı.", "eğitim"),
    ("Has Oda", "Enderun'un en üst odasında yetişen gençler buradan sancakbeyi, beylerbeyi, "
                "hatta vezir olarak atandı.", "eğitim"),
    ("Harem", "Padişah, annesi valide sultan ve ailesi burada yaşadı.", "yaşam"),
    ("Matbah-ı Âmire", "Saray mutfaklarında her gün binlerce kişiye yemek pişirildi.", "yaşam"),
)


@bulmaca(ders="tarih", konu="topkapi_enderun_divan", kademeler=(10, 12), agirlik=1.3)
def saray_belgeleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Topkapı Sarayı konut, yönetim merkezi ve devlet adamı yetiştiren okuldu."""
    yonetim = [b for b in _SARAY_BELGELERI if b[2] == "yönetim"]
    egitim = [b for b in _SARAY_BELGELERI if b[2] == "eğitim"]
    yasam = [b for b in _SARAY_BELGELERI if b[2] == "yaşam"]
    kac_egitim = rastgele.choice((1, 2))
    belgeler = (rastgele.sample(yonetim, 2) + rastgele.sample(egitim, kac_egitim)
                + rastgele.sample(yasam, 3 - kac_egitim))
    rastgele.shuffle(belgeler)
    secenekler = ["{}: {}".format(b[0], b[1]) for b in belgeler]
    yonetim_ind = [n for n, b in enumerate(belgeler) if b[2] == "yönetim"]
    yasam_sayisi = sum(1 for b in belgeler if b[2] == "yaşam")
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-saray-belgeleri",
        ders="tarih",
        baslik="Saray Belgeleri",
        kademe=kademe,
        konu="topkapi_enderun_divan",
        kazanim="Topkapı Sarayı'nın konut, yönetim ve eğitim işlevlerini belgelerle "
                "açıklama; Divan-ı Hümayun'un ve Enderun'un devlet yönetimindeki yerini "
                "ilişkilendirme.",
        dikkat=7,
        brifing=(
            "Saray arşivinden beş belge üsse ulaştı; sergi için sınıflanacak.\n\n"
            "{} belgelere bakmadan etiketi yazdı: \"Topkapı Sarayı padişahın evidir; "
            "burada yalnız yaşanır, başka iş görülmez. Bu beş belgenin hepsi saraydaki "
            "ev hayatıyla ilgili.\"\n\n"
            "Etiket asılmadan önce belgeleri işlevlerine göre ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Saray belgeleri", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Saray planı notu",
                  "Birun (dış bölüm): Divan-ı Hümayun, Dış Hazine, mutfaklar. Enderun (iç "
                  "bölüm): Arz Odası, eğitim odaları, Has Oda. Harem: padişahın ailesinin "
                  "yaşadığı bölüm. Enderun'da yetişenler \"çıkma\" ile saraydan devlet "
                  "görevlerine atanırdı.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Topkapı Sarayı için hangisi doğrudur?",
                dogru="Konut olmanın yanında yönetim merkezi ve devlet adamı yetiştiren bir okuldu",
                yanlislar={
                    "Yalnız padişahın ve ailesinin eviydi; saray, hükümdarın konutu demektir":
                        "Sarayın yalnız konut olduğunu sandın. Divan ve Enderun belgeleri "
                        "yönetim ve eğitimi gösteriyor.",
                    "Yalnız bir okuldu; padişah başka yerde yaşardı, Enderun hep öğrenciyle doluydu":
                        "Harem belgesi padişahın ailesiyle burada yaşadığını gösteriyor.",
                    "Yalnız bir askerî kışlaydı":
                        "Belgelerde Divan toplantıları, eğitim ve aile hayatı var.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Topkapı Sarayı üç işi bir arada yürütüyordu: Harem'de padişahın ailesi "
                    "yaşıyordu; Kubbealtı'nda Divan-ı Hümayun devlet işlerini görüşüyordu; "
                    "Enderun'da devşirme gençler devlet adamı olarak yetişiyordu."
                ),
                ipuclari=[
                    "Belgelerde yalnız ev hayatı mı anlatılıyor?",
                    "Saray planı notunda hangi bölümler var?",
                ],
                cozum="Yaşam: Harem, mutfak\nYönetim: Divan, Arz Odası, Dış Hazine\nEğitim: Enderun, Has Oda",
            ),
            coklu_adimi(
                soru="Hangi belgeler sarayın yönetim işleviyle ilgilidir? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=yonetim_ind,
                aciklama="Divan toplantıları, padişaha arz ve devlet hazinesi yönetim işleridir.",
                ipuclari=["Devlet işlerinin görüşüldüğü, sunulduğu ya da parasının tutulduğu yerleri seç."],
                puan=12,
            ),
            sayi_adimi(
                soru="Beş belgeden kaç tanesi saraydaki ev hayatıyla (konut işleviyle) ilgilidir?",
                cevap=yasam_sayisi,
                aciklama="Konutla ilgili: {}.".format(", ".join(b[0] for b in belgeler if b[2] == "yaşam")),
                yaygin_yanlislar={
                    5:
                        "Sarayın yalnız konut olduğunu sandın; belgelerin çoğu yönetim ve "
                        "eğitimle ilgili.",
                },
                ipuclari=["Harem ve mutfak gibi yaşamla ilgili belgeleri say."],
                puan=10,
            ),
            secim_adimi(
                soru="Enderun'da yetişen gençlerin saraydan sonraki görevi neydi?",
                dogru="Sancakbeyi, beylerbeyi, vezir olarak devlet yönetimine atandılar",
                yanlislar={
                    "Saray yalnız konut olduğu için ömür boyu hizmetçi olarak kaldılar":
                        "Sarayın yalnız konut olduğunu sandın; Enderun devlet adamı "
                        "yetiştiren bir okuldu.",
                    "Tüccar olarak çarşıya gönderildiler; okuma yazma ticarette işe yarardı":
                        "Enderun'un amacı ticaret değil, devlet yönetimiydi.",
                    "Hepsi okul bitince memleketlerine döndü":
                        "Saray planı notuna göre \"çıkma\" ile devlet görevlerine atandılar.",
                },
                rastgele=rastgele,
                aciklama=("Enderun, devşirme gençleri sarayda eğitip devlet kademelerine "
                          "gönderen bir okuldu; merkezî yönetimin kadrosu burada yetişti."),
                ipuclari=["Saray planı notunun Enderun kısmına bak."],
                puan=10,
            ),
        ],
        kapanis=("Etiket düzeltildi: beş belgeden yalnız {} tanesi konutla ilgili; saray "
                 "aynı zamanda devletin yönetim merkezi ve okuluydu.").format(yasam_sayisi),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# İLMİYE, KALEMİYE, SEYFİYE: GÖREVLER KARIŞTIRILMAZ (B37.15)
#
# `ilmiye_kalemiye_seyfiye` tek satırlıktı (2023: 10). Bağlam: "Tarihî atölye
# ve eğitim kurumu belgelerini dönemleriyle eşleme". `yaygin_yanlis`:
#
#   "İlmiye, kalemiye ve seyfiyenin görevlerini karıştırmak."
#
# DÜZENEK: Divan ve taşra görevlilerinin görev kartları. Personel unvanlara
# bakıp hepsini seyfiye sayıyor: "kazaskerin adında asker geçiyor, nişancı
# nişan alan komutandır". Kazasker ilmiyedendir (yargı, kadı ve müderris
# atamaları); nişancı kalemiyedendir (tuğra, arazi kayıtları).
#
# YANILGININ SAYISAL KARŞILIĞI: seyfiye sayısını bütün kartlar saymak.
# ==========================================================================

# (unvan, görev, sınıf)
_DIVAN_GOREVLILERI = (
    ("Kazasker", "Divan'da davalara bakar; kadı ve müderrislerin atamasını yapar.", "ilmiye"),
    ("Nişancı", "Fermanlara padişahın tuğrasını çeker; devlet arazisinin kayıtlarını tutar.", "kalemiye"),
    ("Vezîriâzam", "Padişahın mutlak vekilidir; Divan'a başkanlık eder, seferde orduyu yönetir.", "seyfiye"),
    ("Beylerbeyi", "Eyaletin askerî ve idari yöneticisidir.", "seyfiye"),
    ("Kaptan-ı derya", "Donanmanın komutanıdır.", "seyfiye"),
    ("Defterdar", "Devletin gelir ve giderlerini yönetir.", "kalemiye"),
    ("Reisülküttap", "Divan kâtiplerinin başıdır; yabancı devletlerle yazışmaları yürütür.", "kalemiye"),
    ("Kadı", "Kazada yargılama yapar; çarşı fiyatlarına ve belediye işlerine bakar.", "ilmiye"),
    ("Şeyhülislam", "Fetva verir; ilmiye sınıfının başıdır.", "ilmiye"),
    ("Müderris", "Medresede ders verir.", "ilmiye"),
)


@bulmaca(ders="tarih", konu="ilmiye_kalemiye_seyfiye", kademeler=(10, 12), agirlik=1.3)
def divan_kadrosu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Seyfiye kılıç, ilmiye ilim, kalemiye kalem ehlidir; unvandan değil görevden ayrılır."""
    # Kazasker ve nişancı her zaman; en az bir seyfiye kartı.
    sabit = list(_DIVAN_GOREVLILERI[:2])
    asker = rastgele.choice([k for k in _DIVAN_GOREVLILERI if k[2] == "seyfiye"])
    kalan = [k for k in _DIVAN_GOREVLILERI[2:] if k != asker]
    kartlar = sabit + [asker] + rastgele.sample(kalan, 3)
    rastgele.shuffle(kartlar)
    secenekler = ["{}: {}".format(k[0], k[1]) for k in kartlar]
    ilmiye = [n for n, k in enumerate(kartlar) if k[2] == "ilmiye"]
    seyfiye_sayisi = sum(1 for k in kartlar if k[2] == "seyfiye")
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-divan-kadrosu",
        ders="tarih",
        baslik="Divan Kadrosu",
        kademe=kademe,
        konu="ilmiye_kalemiye_seyfiye",
        kazanim="Osmanlı yönetiminde seyfiye, ilmiye ve kalemiye sınıflarının görevlerini "
                "ayırt etme; görevlileri unvanlarına değil yaptıkları işe göre sınıflama; "
                "Divan-ı Hümayun'da üç sınıfın birlikte çalıştığını açıklama.",
        dikkat=7,
        brifing=(
            "Arşivdeki altı görev kartı, yönetim sergisi için sınıflanacak.\n\n"
            "{} kartları tek rafa dizdi ve şunu yazdı: \"Bunların hepsi seyfiyedendir, "
            "yani askerdir. Kazaskerin adında zaten 'asker' geçiyor; nişancı da nişan "
            "alan bir komutan olmalı.\"\n\n"
            "Raf etiketlenmeden önce kartları görevlerine göre sınıflamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Görev kartları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Sınıf notu",
                  "Seyfiye (kılıç ehli): askerî ve idari yönetim. İlmiye (ilim ehli): "
                  "medreseden yetişir; yargı, eğitim ve din işleri. Kalemiye (kalem ehli): "
                  "yazışma, kayıt ve maliye işleri. Divan-ı Hümayun'da üçü birlikte "
                  "çalışırdı.",
                  bedel=1, kritik=True),
            Kanit("Sözlük notu",
                  "Kazasker: \"kadıasker\"; başlangıçta ordunun kadısı. Nişancı: \"nişan\" "
                  "burada padişahın tuğrası demektir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Seyfiye, ilmiye ve kalemiyeyi birbirinden ayıran nedir?",
                dogru="Yaptıkları iş: seyfiye ordu-yönetim, ilmiye yargı-eğitim, kalemiye kayıt-maliye",
                yanlislar={
                    "Unvanları: adında 'asker' geçen herkes seyfiyedendir; Kazasker de bu yüzden ordudandır":
                        "İlmiye, kalemiye ve seyfiyenin görevlerini karıştırdın; sınıf "
                        "unvandan değil görevden anlaşılır.",
                    "Hiçbir şey: üçü de aynı işi yapardı":
                        "İlmiye, kalemiye ve seyfiyenin görevlerini karıştırdın; her "
                        "birinin ayrı bir alanı vardı.",
                    "Divan'a katılıp katılmamaları; Divan'dakiler hep seyfiyedendir":
                        "Divan'da üç sınıftan da görevli bulunurdu.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Osmanlı yönetiminde kılıç, ilim ve kalem ehli ayrı yollardan yetişir "
                    "ve ayrı işler görürdü; Divan-ı Hümayun'da ise vezirler (seyfiye), "
                    "kazaskerler (ilmiye), nişancı ve defterdarlar (kalemiye) birlikte "
                    "çalışırdı."
                ),
                ipuclari=[
                    "Sınıf notunda her sınıfın işi nedir?",
                    "Sözlük notunda kazasker ve nişancı ne anlama geliyor?",
                ],
                cozum="Görevi oku -> askerî/idari: seyfiye; yargı/eğitim/din: ilmiye; yazı/kayıt/maliye: kalemiye",
            ),
            coklu_adimi(
                soru="Hangi görevliler ilmiye sınıfındandır? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=ilmiye,
                aciklama="Yargı, eğitim ve din işlerini yürütenler ilmiyedendir.",
                ipuclari=["Dava, fetva, ders ve kadı ataması gibi işleri seç."],
                puan=12,
            ),
            sayi_adimi(
                soru="Altı karttan kaç tanesi seyfiye sınıfındandır?",
                cevap=seyfiye_sayisi,
                aciklama="Seyfiye: {}.".format(", ".join(k[0] for k in kartlar if k[2] == "seyfiye")),
                yaygin_yanlislar={
                    6:
                        "İlmiye, kalemiye ve seyfiyenin görevlerini karıştırdın; kartların "
                        "hepsi asker değil.",
                },
                ipuclari=["Yalnız askerî ve idari yönetimle ilgili görevleri say."],
                puan=10,
            ),
            secim_adimi(
                soru="Kazasker hangi sınıftandır?",
                dogru="İlmiye: Divan'da davalara bakar, kadı ve müderris atar",
                yanlislar={
                    "Seyfiye: adında 'asker' geçtiği için ordu komutanıdır":
                        "İlmiye, kalemiye ve seyfiyenin görevlerini karıştırdın; kazasker "
                        "\"kadıasker\"dir, yani bir yargıçtır.",
                    "Kalemiye: fermanlara tuğra çeker; Divan'daki bütün yazılar ondan geçer":
                        "Bu nişancının görevidir.",
                    "Seyfiye: donanmayı yönetir":
                        "Donanma kaptan-ı deryanın işidir.",
                },
                rastgele=rastgele,
                aciklama="Kazasker medreseden yetişen bir ilmiye mensubudur; yargı işlerine bakar.",
                ipuclari=["Sözlük notunda kazasker nasıl açıklanıyor?"],
                puan=10,
            ),
            secim_adimi(
                soru="Nişancı hangi sınıftandır?",
                dogru="Kalemiye: fermanlara tuğra çeker, arazi kayıtlarını tutar",
                yanlislar={
                    "Seyfiye: okçu birliklerinin komutanıdır; nişan almak okçunun işidir":
                        "İlmiye, kalemiye ve seyfiyenin görevlerini karıştırdın; \"nişan\" "
                        "burada tuğra demektir.",
                    "İlmiye: fetva verir":
                        "Fetva şeyhülislamın işidir.",
                    "Seyfiye: eyaleti yönetir":
                        "Eyaleti beylerbeyi yönetir.",
                },
                rastgele=rastgele,
                aciklama="Nişancı, Divan'ın yazı ve kayıt işlerini yürüten kalemiyenin başlıca üyesidir.",
                ipuclari=["Sözlük notunda \"nişan\" ne demek?"],
                puan=10,
            ),
        ],
        kapanis=("Raf düzeltildi: altı kartta {} seyfiye, {} ilmiye, {} kalemiye görevlisi "
                 "var. Kazasker ilmiye, nişancı kalemiye rafına kondu.").format(
                     seyfiye_sayisi, len(ilmiye), 6 - seyfiye_sayisi - len(ilmiye)),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# LALE DEVRİ: YALNIZ EĞLENCE DÖNEMİ DEĞİLDİ (B37.15)
#
# `lale_devri` tek satırlıktı (2026: 11). Bağlam: "Arşivde matbaa, elçilik ve
# kent hayatı kayıtlarını karşılaştırma". `yaygin_yanlis`:
#
#   "Dönemi yalnız eğlence hayatına indirgemek."
#
# DÜZENEK: 1718-1730 arşiv kayıtları. Sadabad, lale fiyatları ve bahçe
# sohbetleri eğlence hayatına; Paris elçiliği, matbaa, Tulumbacı Ocağı,
# tercüme heyeti ve çini atölyesi devlet ve toplum hayatındaki yeniliklere ait.
#
# YANILGININ SAYISAL KARŞILIĞI: kayıtların hepsini eğlence kaydı saymak.
# ==========================================================================

# (tarih, kayıt, eğlence mi)
_LALE_KAYITLARI = (
    ("1720", "Yirmisekiz Çelebi Mehmed Efendi elçi olarak Paris'e gönderildi; dönüşünde "
             "gördüklerini Sefaretname'de anlattı.", False),
    ("1727", "İbrahim Müteferrika'ya matbaa kurma izni verildi; ilk kitap olan Vankulu "
             "Lügati adlı sözlük 1729'da basıldı.", False),
    ("1720", "İstanbul'da yangınlara karşı Tulumbacı Ocağı kuruldu.", False),
    ("1719", "Tekfur Sarayı'nda çini atölyesi açıldı.", False),
    ("1720'ler", "Doğu ve Batı dillerindeki eserleri Türkçeye çevirmek için bir tercüme "
                 "heyeti kuruldu.", False),
    ("1722", "Kâğıthane'de Sadabad Kasrı yapıldı; çevresinde saray eğlenceleri düzenlendi.", True),
    ("1726", "Değerli lale soğanlarının satış fiyatı fermanla belirlendi.", True),
    ("1720'ler", "Saray bahçelerinde lale ve helva sohbetleri düzenlendi.", True),
)


@bulmaca(ders="tarih", konu="lale_devri", kademeler=(11, 13), agirlik=1.3)
def lale_arsivi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Lale Devri'nde eğlence hayatının yanında matbaa, elçilik ve kent yenilikleri vardı."""
    sabit = list(_LALE_KAYITLARI[:2])               # elçilik ve matbaa her zaman
    yenilik = [k for k in _LALE_KAYITLARI[2:] if not k[2]]
    eglence = [k for k in _LALE_KAYITLARI if k[2]]
    kac_eglence = rastgele.choice((2, 3))
    kayitlar = sabit + rastgele.sample(yenilik, 4 - kac_eglence) + rastgele.sample(eglence, kac_eglence)
    rastgele.shuffle(kayitlar)
    secenekler = ["{}: {}".format(t, m) for t, m, _ in kayitlar]
    yenilikler = [n for n, k in enumerate(kayitlar) if not k[2]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-lale-arsivi",
        ders="tarih",
        baslik="Lale Arşivi",
        kademe=kademe,
        konu="lale_devri",
        kazanim="Lale Devri'nin (1718-1730) devlet ve toplum hayatına etkilerini matbaa, "
                "elçilik ve kent hayatı kayıtlarıyla açıklama; dönemi yalnız eğlence "
                "hayatına indirgememe.",
        dikkat=7,
        brifing=(
            "Arşivin 1718-1730 klasöründen altı kayıt çıktı; sergi için "
            "karşılaştırılacak.\n\n"
            "{} klasörün kapağına şunu yazdı: \"Lale Devri: saray eğlenceleri ve lale "
            "merakı. Bu dönemde eğlenceden başka bir şey olmadı; altı kaydın hepsi "
            "eğlence hayatıyla ilgili.\"\n\n"
            "Kapak basılmadan önce kayıtları karşılaştırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Arşiv kayıtları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Dönem notu",
                  "Lale Devri, 1718 Pasarofça Antlaşması'yla başlar ve 1730 Patrona Halil "
                  "İsyanı'yla sona erer. Sadrazam Nevşehirli Damat İbrahim Paşa'nın "
                  "dönemidir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Lale Devri için hangisi doğrudur?",
                dogru="Eğlencenin yanında matbaa, elçilik, tercüme gibi yeniliklerin de yapıldığı bir dönemdi",
                yanlislar={
                    "Yalnız saray eğlenceleri ve lale merakıyla geçen bir dönemdi; adı da oradan gelir":
                        "Dönemi yalnız eğlence hayatına indirgedin. Kayıtlarda matbaa ve "
                        "elçilik de var.",
                    "Yalnız yeniliklerle geçti, eğlence hayatı hiç yoktu":
                        "Sadabad ve lale kayıtları eğlence hayatının da olduğunu gösteriyor.",
                    "Osmanlı'nın Avrupa'yla bütün bağlarını kestiği bir dönemdi; yenilgiler onu içe kapatmıştı":
                        "Tersine: Paris'e elçi gönderildi, Avrupa yakından izlendi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Lale Devri'nde saray çevresinde gösterişli bir eğlence hayatı vardı; "
                    "ama aynı yıllarda Avrupa'ya geçici elçiler gönderildi, matbaa kuruldu, "
                    "tercüme heyeti ve itfaiye örgütü oluşturuldu."
                ),
                ipuclari=[
                    "Kayıtların hepsi eğlenceyle mi ilgili?",
                    "Elçilik ve matbaa kayıtları neyi gösteriyor?",
                ],
                cozum="Eğlence: Sadabad, lale, bahçe sohbetleri\nYenilik: elçilik, matbaa, itfaiye, tercüme, atölye",
            ),
            coklu_adimi(
                soru="Hangi kayıtlar devlet ve toplum hayatındaki yeniliklerle ilgilidir? "
                     "(numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=yenilikler,
                aciklama="Elçilik, matbaa, itfaiye, tercüme ve atölye kayıtları yeniliklerle ilgilidir.",
                ipuclari=["Kent hayatını, bilgiyi ya da dış ilişkileri değiştiren kayıtları seç."],
                puan=12,
            ),
            sayi_adimi(
                soru="Altı kayıttan kaç tanesi eğlence hayatıyla ilgilidir?",
                cevap=kac_eglence,
                aciklama="{} kayıt eğlenceyle, {} kayıt yeniliklerle ilgili.".format(
                    kac_eglence, 6 - kac_eglence),
                yaygin_yanlislar={
                    6:
                        "Dönemi yalnız eğlence hayatına indirgedin; matbaa ve elçilik "
                        "kayıtları yeniliklerle ilgili.",
                },
                ipuclari=["Sadabad, lale ve bahçe sohbeti kayıtlarını say."],
                puan=10,
            ),
            secim_adimi(
                soru="Yirmisekiz Çelebi Mehmed Efendi'nin Paris elçiliği neyi gösterir?",
                dogru="Osmanlı'nın Avrupa'yı yakından tanımaya çalıştığını",
                yanlislar={
                    "Saray eğlencelerine yeni fikirler bulmak için yapılan bir gezi olduğunu":
                        "Dönemi yalnız eğlence hayatına indirgedin; Sefaretname Fransa'nın "
                        "kurumlarını ve kent hayatını anlatır.",
                    "Fransa'ya savaş ilan edildiğini":
                        "Elçilik bir barış ve tanışma göreviydi.",
                    "Osmanlı'nın Avrupa'yla ilişkilerini kestiğini":
                        "Elçi göndermek ilişki kurmaktır, kesmek değil.",
                },
                rastgele=rastgele,
                aciklama=("Avrupa'ya gönderilen geçici elçiler, Batı'daki gelişmeleri "
                          "yerinde görmek içindi; Sefaretname bu gözlemleri aktardı."),
                ipuclari=["Elçi dönüşünde ne yazdı?"],
                puan=10,
            ),
            yorum_adimi(
                soru="Matbaanın 1727'de kurulması dönem hakkında ne söyler?",
                dogru="Bilgiyi çoğaltıp yaymak için kalıcı bir yenilik yapıldığını",
                yanlislar={
                    "Matbaanın da yalnız eğlence için kullanıldığını":
                        "Dönemi yalnız eğlence hayatına indirgedin; ilk kitap bir sözlüktü.",
                    "Hiçbir etkisi olmadığını; çünkü dönem 1730'da bitti, yenilikler de onunla bitti":
                        "Matbaa dönemin sonundan sonra da kitap basmayı sürdürdü.",
                },
                rastgele=rastgele,
                aciklama=("Müteferrika matbaası sözlük, tarih ve coğrafya kitapları bastı; "
                          "dönemin sonrasına kalan bir yenilikti."),
                ipuclari=["İlk basılan kitap bir eğlence kitabı mı?"],
                puan=10,
            ),
        ],
        kapanis=("Kapak düzeltildi: altı kayıttan yalnız {} tanesi eğlenceyle ilgili; Lale "
                 "Devri matbaa, elçilik ve kent yenilikleriyle de anılır.").format(kac_eglence),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# OSMANLI SANAYİLEŞMESİ: ALTERNATİF, DÖNEMİN OLANAKLARIYLA YAZILIR (B37.15)
#
# `osmanli_sanayilesme_alternatif` tek satırlıktı (2026: 11). Bağlam: "Atölye ve
# ticaret arşivinden hareketle dönemin kaynaklarıyla uygulanabilecek bir
# sanayileşme önerisi yazma". `yaygin_yanlis`:
#
#   "Bugünün teknolojisini geçmişte kullanılabilir saymak; önerilen alternatifi
#    gerçekleşmiş olay gibi aktarmak."
#
# DÜZENEK: 1840'larda bir dokuma fabrikası için öneri taslağı. Maddelerin bir
# kısmı dönemin teknolojisiyle (buhar makinesi, buharlı gemi, dökümhane)
# uygulanabilir, bir kısmı anakronik (elektrik santrali, kamyon, bilgisayar,
# plastik). Gümrük tarifesi arşivin kuralı olarak veriliyor: ithal kumaştan
# yüzde 5; ucuz ithal kumaş yerli üretimin başlıca engellerinden biri.
#
# YANILGILARIN SAYISAL KARŞILIĞI: anakronik madde sayısını 0 saymak; raporda
# öneriyi olmuş bir olay gibi yazmak.
# ==========================================================================

# (madde, 1840'larda uygulanabilir mi)
_SANAYI_MADDELERI = (
    ("Dokuma tezgâhlarını kömürle çalışan buhar makinesiyle döndürmek", True),
    ("Avrupa'dan usta getirip yerli işçileri fabrikada yetiştirmek", True),
    ("Pamuğu buharlı gemiyle limana, oradan at arabasıyla fabrikaya taşımak", True),
    ("Makine parçaları için kömürle çalışan bir dökümhane kurmak", True),
    ("Ordunun kumaş siparişini yerli fabrikaya vermek", True),
    ("Makineleri elektrik santralinden gelen akımla çalıştırmak", False),
    ("Pamuğu kamyonlarla fabrikaya taşımak", False),
    ("Siparişleri bilgisayarla takip etmek", False),
    ("Kumaş toplarını plastik ambalajla korumak", False),
)


@bulmaca(ders="tarih", konu="osmanli_sanayilesme_alternatif", kademeler=(11, 13), agirlik=1.3)
def sanayi_onerisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tarihsel alternatif, dönemin teknolojisiyle kurulur ve öneri olarak yazılır."""
    uygun = [m for m in _SANAYI_MADDELERI if m[1]]
    anakronik = [m for m in _SANAYI_MADDELERI if not m[1]]
    kac_anakronik = rastgele.choice((1, 2))
    maddeler = rastgele.sample(uygun, 3) + rastgele.sample(anakronik, kac_anakronik)
    rastgele.shuffle(maddeler)
    secenekler = [m for m, _ in maddeler]
    uygulanabilir = [n for n, (_, u) in enumerate(maddeler) if u]
    fiyat = rastgele.choice((80, 100, 120))           # kuruş, fabrika çıkış fiyatı
    gumruklu = fiyat * 105 // 100
    yerli = gumruklu + rastgele.choice((10, 15))      # yerli atölyenin maliyeti
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-sanayi-onerisi",
        ders="tarih",
        baslik="Sanayi Önerisi",
        kademe=kademe,
        konu="osmanli_sanayilesme_alternatif",
        kazanim="Osmanlı sanayileşmesinin engellerini (ucuz ithal mal, sermaye ve usta "
                "eksikliği) arşiv kayıtlarıyla inceleme; dönemin teknolojisiyle "
                "uygulanabilecek bir alternatif öneri yazma; öneriyi gerçekleşmiş olay "
                "gibi aktarmama.",
        dikkat=8,
        brifing=(
            "Atölye ve ticaret arşivine dayanarak 1840'larda İstanbul'da kurulabilecek "
            "bir dokuma fabrikası için öneri yazılacak.\n\n"
            "{} taslağı hazırladı ve rapora şu cümleyi ekledi: \"1845'te elektrikli "
            "makinelerle fabrikamız kuruldu; kamyonlarla pamuk taşındı ve Osmanlı "
            "kumaşı İngiliz kumaşını piyasadan sildi.\"\n\n"
            "Rapor gönderilmeden önce taslağı dönemin olanaklarıyla sınamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Öneri taslağı", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Teknoloji notu",
                  "Buhar makinesi 18. yüzyıl sonunda yaygınlaştı; buharlı gemiler 19. yüzyıl "
                  "başından beri çalışıyor. Elektrik santralleri 1880'lerde kuruldu "
                  "(Osmanlı'da ilki 1902). Kamyon 1890'lardan sonra, plastik 20. yüzyıl "
                  "başında, bilgisayar 20. yüzyıl ortasında ortaya çıktı.",
                  bedel=1, kritik=True),
            Kanit("Gümrük ve maliyet kaydı",
                  "Arşivdeki tarife (1838 ticaret antlaşması sonrası): ithal kumaştan yüzde 5 "
                  "gümrük alınır. İngiliz kumaşının fabrika fiyatı {} kuruş. Yerli el "
                  "tezgâhında aynı kumaşın maliyeti {} kuruş.".format(fiyat, yerli),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Tarihsel bir alternatif öneri nasıl yazılır?",
                dogru="Dönemin olanaklarıyla uygulanabilir olmalı ve gerçekleşmemiş olduğu belirtilmeli",
                yanlislar={
                    "Bugünün teknolojisi de kullanılabilir; önemli olan sonucun iyi olması":
                        "Bugünün teknolojisini geçmişte kullanılabilir saydın; öneri o "
                        "günün olanaklarıyla kurulur.",
                    "Öneri, olmuş bir olay gibi geçmiş zamanla anlatılmalı; böylesi daha inandırıcıdır":
                        "Önerilen alternatifi gerçekleşmiş olay gibi aktardın; öneri "
                        "\"kurulabilirdi\" diye yazılır.",
                    "Dönemin engelleri dikkate alınmaz":
                        "Öneri, arşivdeki engellere (ucuz ithal mal, usta eksikliği) yanıt "
                        "vermelidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarihsel alternatif, o günün insanlarının gerçekten yapabileceği bir "
                    "yol arar: o günün makineleri, ulaşımı ve parasıyla. Ayrıca öneri "
                    "olduğu açıkça belli olmalıdır; aksi hâlde uydurma bir tarih yazılmış "
                    "olur."
                ),
                ipuclari=[
                    "Teknoloji notuna göre 1840'larda hangi makineler vardı?",
                    "Rapordaki cümle olmuş bir şeyi mi anlatıyor, bir öneriyi mi?",
                ],
                cozum="1) Her maddeyi teknoloji notuyla karşılaştır.\n2) Öneriyi \"-ebilirdi\" kipiyle yaz.",
            ),
            coklu_adimi(
                soru="Taslaktaki maddelerden hangileri 1840'ların olanaklarıyla uygulanabilir? "
                     "(numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=uygulanabilir,
                aciklama="Buhar gücü, buharlı gemi, dökümhane, usta getirme ve devlet siparişi o dönemde mümkündü.",
                ipuclari=["Her maddedeki teknolojinin ne zaman ortaya çıktığına bak."],
                puan=12,
            ),
            sayi_adimi(
                soru="Taslakta kaç madde 1840'larda henüz olmayan bir teknolojiye dayanıyor?",
                cevap=kac_anakronik,
                aciklama="Anakronik: {}.".format("; ".join(m for m, u in maddeler if not u)),
                yaygin_yanlislar={
                    0:
                        "Bugünün teknolojisini geçmişte kullanılabilir saydın.",
                },
                ipuclari=["Elektrik, kamyon, bilgisayar ve plastik ne zaman ortaya çıktı?"],
                puan=10,
            ),
            sayi_adimi(
                soru="Gümrük eklenince İngiliz kumaşı İstanbul'a kaç kuruşa gelir?",
                cevap=gumruklu,
                birim="kuruş",
                aciklama=("{} + {} × 5 ÷ 100 = {} kuruş. Yerli el tezgâhının maliyeti {} "
                          "kuruş: ithal kumaş daha ucuz.").format(fiyat, fiyat, gumruklu, yerli),
                ipuclari=["Fabrika fiyatına yüzde 5 gümrüğü ekle."],
                puan=10,
            ),
            yorum_adimi(
                soru="Rapordaki cümle nasıl düzeltilmeli?",
                dogru=("Önerimiz: buhar makineli bir dokuma fabrikası kurulabilir, ithal kumaşla "
                       "rekabet kolaylaşabilirdi"),
                yanlislar={
                    "1845'te buhar makineli fabrikamız kuruldu ve İngiliz kumaşı piyasadan silindi; rapor kesin dille yazılır":
                        "Önerilen alternatifi gerçekleşmiş olay gibi aktardın.",
                    "Önerimiz: elektrik motorlu makinelerle bir fabrika kurulabilirdi; en verimli makine budur":
                        "Bugünün teknolojisini geçmişte kullanılabilir saydın; Osmanlı'da "
                        "ilk elektrik santrali 1902'de kuruldu.",
                    "Önerimiz: fabrikaya gerek yoktu, çünkü el tezgâhları ithal kumaştan ucuzdu":
                        "Maliyet kaydına göre ithal kumaş yerli el tezgâhından ucuz.",
                },
                rastgele=rastgele,
                aciklama=("Doğru cümle dönemin teknolojisini kullanır ve \"-ebilirdi\" "
                          "kipiyle bir öneri olduğunu açıkça söyler."),
                ipuclari=["Cümle olmuş bir olayı mı anlatıyor? Teknolojisi 1840'larda var mıydı?"],
                puan=12,
            ),
        ],
        kapanis=("Rapor düzeltildi: {} anakronik madde çıkarıldı; ithal kumaş gümrükle {} "
                 "kuruşa, yerli el tezgâhı {} kuruşa. Öneri dönemin olanaklarıyla ve "
                 "\"-ebilirdi\" kipiyle yazıldı.").format(kac_anakronik, gumruklu, yerli),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# ANADOLU'NUN TÜRKLEŞMESİ: YALNIZ FETİHLE AÇIKLANMAZ (B37.15)
#
# `turk_islam_kultur_anadolu` tek satırlıktı (2026: 10). Bağlam: "Medrese,
# mimari eser ve düşünür kayıtlarının yerleşme-kültür ilişkisini açıklama".
# `yaygin_yanlis`:
#
#   "Anadolu'nun kültürel dönüşümünü yalnız askerî fetihlerle açıklamak."
#
# `anadolu_sufi_alimler` (2023: 10) aynı konuyu (sûfî ve âlimlerin
# İslamlaşmadaki etkisi) işliyor; ek karşılıkla bu göreve bağlanıyor.
#
# DÜZENEK: 11-14. yüzyıl Anadolu kayıtları. Savaşlar kapıyı açtı; kalıcı
# dönüşümü medreseler, darüşşifalar, kervansaraylar, Ahilik, Mevlânâ, Hacı
# Bektaş-ı Velî, Yunus Emre ve Türkçe fermanı sağladı.
#
# YANILGININ SAYISAL KARŞILIĞI: kayıtların hepsini askerî olay saymak.
# ==========================================================================

# (tarih, kayıt, tür) - tür: "askeri", "kurum" ya da "sufi"
_ANADOLU_KAYITLARI = (
    ("1071", "Malazgirt Savaşı kazanıldı; Anadolu'nun kapıları Türklere açıldı.", "askeri"),
    ("1176", "Miryokefalon Savaşı kazanıldı; Bizans Anadolu'yu geri alma umudunu yitirdi.", "askeri"),
    ("1243", "Kösedağ Savaşı'nda Moğollara yenilindi.", "askeri"),
    ("1206", "Kayseri'de Gevher Nesibe Darüşşifası ve tıp medresesi açıldı.", "kurum"),
    ("1229", "Aksaray yolunda Sultan Hanı kervansarayı yapıldı; kervan ticareti güvenceye alındı.", "kurum"),
    ("1251", "Konya'da Karatay Medresesi açıldı.", "kurum"),
    ("1229", "Divriği Ulu Camii ve Darüşşifası yapıldı.", "kurum"),
    ("1277", "Karamanoğlu Mehmet Bey divanda, dergâhta ve mecliste Türkçe konuşulmasını buyurdu.", "kurum"),
    ("13. yüzyıl", "Ahi Evran, Kırşehir'de esnafı Ahilik teşkilatında örgütledi.", "sufi"),
    ("13. yüzyıl", "Mevlânâ, Konya'da Mesnevî'yi yazdı; dergâhı farklı kesimlerden insanları "
                   "bir araya getirdi.", "sufi"),
    ("13. yüzyıl", "Hacı Bektaş-ı Velî'nin zaviyesi Türkmen yerleşimlerinin kültür merkezi oldu.", "sufi"),
    ("13-14. yüzyıl", "Yunus Emre, tasavvufi şiirlerini halkın konuştuğu Türkçeyle yazdı.", "sufi"),
)


@bulmaca(ders="tarih", konu="turk_islam_kultur_anadolu", kademeler=(10, 12), agirlik=1.3)
def anadolu_kayitlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Fetih kapıyı açtı; kalıcı dönüşümü kurumlar, sûfîler ve âlimler sağladı."""
    askeri = [k for k in _ANADOLU_KAYITLARI if k[2] == "askeri"]
    sufi = [k for k in _ANADOLU_KAYITLARI if k[2] == "sufi"]
    kurum = [k for k in _ANADOLU_KAYITLARI if k[2] == "kurum"]
    kac_askeri = rastgele.choice((1, 2))
    kac_sufi = rastgele.choice((1, 2))
    kayitlar = (rastgele.sample(askeri, kac_askeri) + rastgele.sample(sufi, kac_sufi)
                + rastgele.sample(kurum, 6 - kac_askeri - kac_sufi))
    rastgele.shuffle(kayitlar)
    secenekler = ["{}: {}".format(t, m) for t, m, _ in kayitlar]
    kulturel = [n for n, k in enumerate(kayitlar) if k[2] != "askeri"]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-anadolu-kayitlari",
        ders="tarih",
        baslik="Anadolu Kayıtları",
        kademe=kademe,
        konu="turk_islam_kultur_anadolu",
        kazanim="Anadolu'nun Türkleşme ve İslamlaşmasını askerî fetihlerin yanında "
                "medrese, darüşşifa, kervansaray, Ahilik ve sûfî-âlimlerin etkisiyle "
                "açıklama; yerleşme ile kültür arasındaki ilişkiyi kayıtlarla gösterme.",
        dikkat=7,
        brifing=(
            "Sefer arşivinden 11-14. yüzyıl Anadolu'suna ait altı kayıt çıktı.\n\n"
            "{} sergi başlığını şöyle yazdı: \"Anadolu yalnız kılıçla Türkleşti ve "
            "İslamlaştı. Bu altı kaydın hepsi savaş ve fetih kaydı.\"\n\n"
            "Başlık asılmadan önce kayıtları türlerine göre ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Anadolu kayıtları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Tarihçi notu",
                  "Savaşlar bir bölgeyi yönetime açar; halkın dilini, inancını ve gündelik "
                  "hayatını ise yerleşme, eğitim kurumları, ticaret, esnaf teşkilatları, "
                  "tekke ve zaviyeler yüzyıllar içinde dönüştürür.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Anadolu'nun Türkleşmesi ve İslamlaşması nasıl açıklanır?",
                dogru="Savaşlar kapıyı açtı; dönüşümü göç, yerleşme, medrese, Ahilik ve zaviyeler sağladı",
                yanlislar={
                    "Yalnız savaşlar ve fetihlerle; toprağı alan kültürü de değiştirir":
                        "Anadolu'nun kültürel dönüşümünü yalnız askerî fetihlerle açıkladın. "
                        "Kayıtların çoğu medrese, kervansaray ve dergâhlarla ilgili.",
                    "Yalnız ticaretle; savaşların hiçbir etkisi olmadı, kervanlar kültürü taşıdı":
                        "Malazgirt gibi savaşlar bölgeyi yerleşmeye açtı; etkisini yok sayamayız.",
                    "Malazgirt'ten hemen sonra bir anda tamamlandı; zafer kapıyı açınca Anadolu Türkleşti":
                        "Kayıtlar dönüşümün 11. yüzyıldan 14. yüzyıla uzandığını gösteriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Fetih bir yönetim değişikliğidir; kültürel dönüşüm ise yüzyıllar sürer. "
                    "Türkmen göçleriyle kurulan köy ve kasabalarda medreseler, darüşşifalar, "
                    "kervansaraylar, ahi teşkilatları ve dergâhlar yeni bir ortak hayat kurdu."
                ),
                ipuclari=[
                    "Kayıtların kaçı savaşla ilgili?",
                    "Tarihçi notuna göre halkın hayatını ne dönüştürür?",
                ],
                cozum="Askerî: Malazgirt, Miryokefalon, Kösedağ\nKültürel: medrese, darüşşifa, kervansaray, Ahilik, dergâh, Türkçe",
            ),
            coklu_adimi(
                soru="Hangi kayıtlar askerî olay değil, kültürel dönüşümün izidir? "
                     "(numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=kulturel,
                aciklama="Medrese, darüşşifa, kervansaray, Ahilik, dergâh ve Türkçe kayıtları kültüreldir.",
                ipuclari=["Savaş adı geçmeyen kayıtları incele."],
                puan=12,
            ),
            sayi_adimi(
                soru="Altı kayıttan kaç tanesi askerî olaydır?",
                cevap=kac_askeri,
                aciklama="Askerî kayıt: {}.".format(", ".join(t for t, _, k in kayitlar if k == "askeri")),
                yaygin_yanlislar={
                    6:
                        "Anadolu'nun kültürel dönüşümünü yalnız askerî fetihlerle açıkladın; "
                        "kayıtların çoğu savaş kaydı değil.",
                },
                ipuclari=["Yalnız savaş kayıtlarını say."],
                puan=10,
            ),
            secim_adimi(
                soru="Mevlânâ, Hacı Bektaş-ı Velî, Yunus Emre ve Ahi Evran gibi sûfî ve "
                     "âlimlerin Anadolu'daki rolü neydi?",
                dogru=("Dergâh, zaviye ve esnaf teşkilatlarıyla anlaşılır bir dille farklı "
                       "kesimleri buluşturdular"),
                yanlislar={
                    "Ordu komutanıydılar ve fetihleri yönettiler":
                        "Anadolu'nun kültürel dönüşümünü yalnız askerî fetihlerle açıkladın; "
                        "bu kişiler komutan değil, düşünür ve öğreticiydi.",
                    "Yalnız saray için eser yazdılar; halkla ilişkileri yoktu":
                        "Yunus Emre halkın Türkçesiyle yazdı; zaviyeler köylerin içindeydi.",
                    "Anadolu'ya geldikleri sırada dönüşüm zaten tamamlanmıştı; onlar yalnız hazır düzene katıldılar":
                        "13. yüzyılda dönüşüm sürüyordu; bu kişiler onu hızlandırdı.",
                },
                rastgele=rastgele,
                aciklama=("Sûfîler ve âlimler dergâh, zaviye, medrese ve ahi teşkilatlarıyla "
                          "İslam'ı ve Türkçeyi gündelik hayata taşıdı."),
                ipuclari=["Sûfî kayıtlarında bu kişilerin ne yaptığını oku."],
                puan=10,
            ),
            yorum_adimi(
                soru="Kervansaray ve medreselerin yerleşmeyle ilişkisi nedir?",
                dogru="Ticareti ve şehirleri canlandırıp yerleşik hayatı güçlendirdiler",
                yanlislar={
                    "Yalnız askerlerin konaklaması için yapıldılar; duvarları kale gibi kalındı":
                        "Anadolu'nun kültürel dönüşümünü yalnız askerî fetihlerle açıkladın; "
                        "kervansaraylar kervan ticareti içindi.",
                    "Yerleşmeyle hiçbir ilişkileri yoktu":
                        "Medreseler ve kervansaraylar şehirlerin ve yolların çevresinde "
                        "hayatı canlandırdı.",
                },
                rastgele=rastgele,
                aciklama=("Güvenli yollar ticareti, ticaret şehirleri büyüttü; medrese ve "
                          "darüşşifalar şehirleri eğitim ve sağlık merkezine dönüştürdü."),
                ipuclari=["Tarihçi notunda ticaret ve eğitim kurumlarının rolü ne?"],
                puan=10,
            ),
        ],
        kapanis=("Başlık düzeltildi: altı kayıttan yalnız {} tanesi askerî. Anadolu'yu "
                 "savaşlar açtı; medreseler, kervansaraylar, ahiler ve dergâhlar "
                 "dönüştürdü.").format(kac_askeri),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# ORTA ÇAĞ MEDENİYETLERİ: DEĞİŞİMLER AYNI HIZDA OLMAZ (B37.15)
#
# `ortacag_medeniyet_urunu` tek satırlıktı (2026: 9). Bağlam: "Sefer arşivi için
# farklı medeniyetlerin bilim ve sanat katkılarını kaynaklı sergiye
# dönüştürme". `yaygin_yanlis`:
#
#   "Dinî, siyasi ve kültürel değişimleri aynı hızda gerçekleşmiş saymak."
#
# DÜZENEK: dört medeniyetten biri için üç tarihli kart: siyasi değişim
# (devletin kuruluşu), dinî değişim (yeni dinin kabulü), kültürel eser.
# Karahanlılar 840 / 960 / 1070; Tuna Bulgarları 681 / 864 / 893;
# Kiev Rus 882 / 988 / 1113; İlhanlılar 1256 / 1295 / 1307.
#
# YANILGININ SAYISAL KARŞILIĞI: aradaki süreleri 0 yıl saymak.
# ==========================================================================

_ORTACAG_DEGISIMLERI = (
    {
        "ad": "Karahanlılar",
        "siyasi": (840, "Karahanlı Devleti kuruldu."),
        "dini": (960, "İki yüz bin çadırlık Türk topluluğu İslamiyet'i kabul etti."),
        "kulturel": (1070, "Yusuf Has Hacib, Kutadgu Bilig'i Türkçe yazdı."),
        "katki": "Türkçenin İslam dünyasında yazı ve bilgelik dili olması",
    },
    {
        "ad": "Tuna Bulgarları",
        "siyasi": (681, "Tuna Bulgar Devleti kuruldu."),
        "dini": (864, "Han Boris Hristiyanlığı kabul etti."),
        "kulturel": (893, "Preslav'da Kiril alfabesiyle yazan edebiyat okulu kuruldu."),
        "katki": "Slav dillerinde Kiril yazısı ve edebiyatın gelişmesi",
    },
    {
        "ad": "Kiev Rus",
        "siyasi": (882, "Oleg, Kiev'i başkent yaparak Kiev Rus Devleti'ni kurdu."),
        "dini": (988, "Knez Vladimir Hristiyanlığı kabul etti."),
        "kulturel": (1113, "Kiev'de Geçmiş Yılların Anlatısı adlı tarih yıllığı derlendi."),
        "katki": "Doğu Slav tarihinin ilk büyük yazılı kaynağının oluşması",
    },
    {
        "ad": "İlhanlılar",
        "siyasi": (1256, "Hülagü İlhanlı Devleti'ni kurdu."),
        "dini": (1295, "Gazan Han İslamiyet'i kabul etti."),
        "kulturel": (1307, "Reşidüddin, Câmiu't-Tevârîh adlı dünya tarihini tamamladı."),
        "katki": "Farklı halkları bir arada anlatan ilk büyük dünya tarihi",
    },
)


@bulmaca(ders="tarih", konu="ortacag_medeniyet_urunu", kademeler=(9, 12), agirlik=1.3)
def degisim_hizlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Siyasi, dinî ve kültürel değişimler farklı zamanlarda ve hızlarda gerçekleşir."""
    m = rastgele.choice(_ORTACAG_DEGISIMLERI)
    kartlar = [("Siyasi", m["siyasi"]), ("Dinî", m["dini"]), ("Kültürel", m["kulturel"])]
    rastgele.shuffle(kartlar)
    siyasi_dini = m["dini"][0] - m["siyasi"][0]
    dini_kulturel = m["kulturel"][0] - m["dini"][0]
    diger_katkilar = [d["katki"] for d in _ORTACAG_DEGISIMLERI if d is not m]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-degisim-hizlari",
        ders="tarih",
        baslik="Değişim Hızları",
        kademe=kademe,
        konu="ortacag_medeniyet_urunu",
        kazanim="Orta Çağ'da bir medeniyetin siyasi, dinî ve kültürel değişimlerini tarihli "
                "kanıtlarla karşılaştırma; bu değişimlerin farklı hızlarda gerçekleştiğini "
                "gösterme; medeniyetin bilim ve sanat katkısını kaynaklı sergiye taşıma.",
        dikkat=7,
        brifing=(
            "Sefer arşivinin Orta Çağ sergisinde {} için bir pano hazırlanıyor.\n\n"
            "{} panoya şunu yazdı: \"Devlet kurulunca din de kültür de hemen değişti; "
            "üç değişim aynı hızda, neredeyse aynı yıl gerçekleşti.\"\n\n"
            "Pano asılmadan önce kartlardaki tarihleri karşılaştırmamız gerekiyor."
        ).format(m["ad"], kisi),
        kanitlar=[
            Kanit("Pano kartları",
                  "\n".join("{} ({}): {}".format(tur, yil, olay) for tur, (yil, olay) in kartlar),
                  bedel=1, kritik=True),
            Kanit("Tarihçi notu",
                  "Bir devlet bir savaşla ya da bir kararla kurulabilir. Halkın inancının "
                  "ve kültürünün değişmesi ise çoğu zaman nesiller sürer; bu yüzden "
                  "değişimler farklı hızlarda ilerler.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Siyasi, dinî ve kültürel değişimler için hangisi doğrudur?",
                dogru="Farklı hızlarda; siyaset hızlı değişebilir, din ve kültür çoğu zaman nesiller sürer",
                yanlislar={
                    "Üçü aynı anda ve aynı hızda gerçekleşir":
                        "Dinî, siyasi ve kültürel değişimleri aynı hızda gerçekleşmiş saydın. "
                        "Kartlardaki tarihler arasında onlarca yıl var.",
                    "Kültürel değişim her zaman devletin kuruluşundan önce tamamlanır; devleti kültür kurar":
                        "Kartlarda kültürel eser devletin kuruluşundan sonra geliyor.",
                    "Dinî değişim bir günde bütün halkı kapsar; hükümdar kabul edince halk da eder":
                        "Hükümdar yeni dini bir günde kabul edebilir; halkın tamamının "
                        "değişmesi nesiller sürer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Devletin kuruluşu belirli bir tarihe bağlanabilir; yeni bir dinin "
                    "kabulü ve o dinin kültürüyle yeni eserlerin ortaya çıkması ise "
                    "zaman alır. Her medeniyette bu süreler farklıdır."
                ),
                ipuclari=[
                    "Kartlardaki üç tarih aynı mı?",
                    "Tarihçi notuna göre hangi değişim nesiller sürer?",
                ],
                cozum="Süre = sonraki tarih − önceki tarih",
            ),
            sayi_adimi(
                soru="Siyasi değişim ile dinî değişim arasında kaç yıl var?",
                cevap=siyasi_dini,
                birim="yıl",
                aciklama="{} − {} = {} yıl.".format(m["dini"][0], m["siyasi"][0], siyasi_dini),
                yaygin_yanlislar={
                    0:
                        "Dinî, siyasi ve kültürel değişimleri aynı hızda gerçekleşmiş saydın.",
                },
                ipuclari=["Dinî kartın yılından siyasi kartın yılını çıkar."],
                puan=10,
            ),
            sayi_adimi(
                soru="Dinî değişim ile kültürel eser arasında kaç yıl var?",
                cevap=dini_kulturel,
                birim="yıl",
                aciklama="{} − {} = {} yıl.".format(m["kulturel"][0], m["dini"][0], dini_kulturel),
                yaygin_yanlislar={
                    0:
                        "Dinî, siyasi ve kültürel değişimleri aynı hızda gerçekleşmiş saydın.",
                },
                ipuclari=["Kültürel kartın yılından dinî kartın yılını çıkar."],
                puan=10,
            ),
            secim_adimi(
                soru="{} panosundaki kültürel eser hangi katkıyı gösterir?".format(m["ad"]),
                dogru=m["katki"],
                yanlislar=diger_katkilar,
                rastgele=rastgele,
                aciklama="Kültürel kart: {} Katkısı: {}.".format(m["kulturel"][1], m["katki"]),
                ipuclari=["Kültürel kartta hangi eser ya da kurum var?"],
                puan=10,
            ),
            yorum_adimi(
                soru="Pano için hangi cümle kanıtlara uygundur?",
                dogru="{} tarihinde üç değişim farklı zamanlarda ve hızlarda gerçekleşti".format(m["ad"]),
                yanlislar={
                    "Din ve kültür, devletle aynı yıl değişti; halk hükümdara uyar":
                        "Dinî, siyasi ve kültürel değişimleri aynı hızda gerçekleşmiş saydın.",
                    "Kültürel değişim devlet kurulmadan önce tamamlanmış, devlet hazır kültürün üstüne kurulmuştu":
                        "Kültürel eser devletin kuruluşundan {} yıl sonra.".format(
                            m["kulturel"][0] - m["siyasi"][0]),
                },
                rastgele=rastgele,
                aciklama="Kartlar üç değişim arasında {} ve {} yıllık aralıklar gösteriyor.".format(
                    siyasi_dini, dini_kulturel),
                ipuclari=["Bulduğun iki süreyi hatırla."],
                puan=10,
            ),
        ],
        kapanis=("Pano düzeltildi: {} için siyasi değişimden dinî değişime {} yıl, dinî "
                 "değişimden kültürel esere {} yıl geçti.").format(m["ad"], siyasi_dini, dini_kulturel),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# TARİH ÖĞRENMENİN FAYDASI: EZBER DEĞİL, ORTAK HAFIZA VE KARAR (B37.15)
#
# `tarih_ogrenmenin_faydalari` iki satırdı (2023: 9, 2026: 9). Bağlam: "Sefer
# ekibinin arşiv tutmasının ortak hafıza ve karar vermeye katkısını
# açıklama". `yaygin_yanlis`:
#
#   "Tarih öğrenmeyi yalnız tarih ve kişi adı ezberlemek sanmak."
#
# DÜZENEK: kış yaklaşıyor; ekip kuzey ya da güney geçidini seçecek. Geçit
# günlüğünde son üç kışın kapalı gün sayıları, nedenleri ve işe yarayan
# önlemler yazıyor. Bir personel günlüğü "yalnız tarih ve isim listesi"
# olarak kısaltmak istiyor; o zaman kararı sağlayan bilgi kaybolur.
# ==========================================================================

_GECIT_GUNLUGU = {
    "Kuzey geçidi": ("çığ", "Çığ tehlikesinde geçit kapatıldı; kar küreyici işe yaramadı."),
    "Güney geçidi": ("tipi", "Tipide zincirli kızaklarla geçiş sürdürüldü."),
}


def _uc_kis(rastgele: random.Random, ortalamalar, farklar):
    ort = rastgele.choice(ortalamalar)
    fark = rastgele.choice(farklar)
    degerler = [ort - fark, ort, ort + fark]
    rastgele.shuffle(degerler)
    return ort, degerler


@bulmaca(ders="tarih", konu="tarih_ogrenmenin_faydalari", kademeler=(9, 12), agirlik=1.2)
def gecit_gunlugu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Arşiv, geçmişin nedenlerini ve sonuçlarını saklayarak bugünkü kararı besler."""
    kuzey_ort, kuzey = _uc_kis(rastgele, (9, 10, 12), (2, 3))
    guney_ort, guney = _uc_kis(rastgele, (2, 3), (1,))
    yillar = (2023, 2024, 2025)
    kisi, yazar1, yazar2 = ad_sec(rastgele, PERSONEL, 3)
    gunluk = []
    for yil, k, g in zip(yillar, kuzey, guney):
        gunluk.append("{} kışı: Kuzey geçidi {} gün kapalı kaldı (çığ). Güney geçidi {} gün "
                      "kapalı kaldı (tipi).".format(yil, k, g))
    liste = ["{} Ocak {}: {} kuzey geçidinden döndü.".format(rastgele.choice((8, 14, 21)), yil, yazar1)
             for yil in yillar[:2]] + ["3 Şubat {}: {} güney geçidinden geçti.".format(yillar[2], yazar2)]
    faydali = ["Geçidin kaç gün kapalı kaldığı", "Kapanmanın nedeni",
               "Hangi önlemin işe yaradığı"]
    faydasiz = ["Kaydı yazan personelin adı", "Kaydın arşivdeki sıra numarası"]
    secenekler = faydali + faydasiz
    rastgele.shuffle(secenekler)
    dogrular = [n for n, s in enumerate(secenekler) if s in faydali]

    return Bulmaca(
        kod="tar-gecit-gunlugu",
        ders="tarih",
        baslik="Geçit Günlüğü",
        kademe=kademe,
        konu="tarih_ogrenmenin_faydalari",
        kazanim="Tarih öğrenmenin ve arşiv tutmanın ortak hafızayı korumaya ve bugünkü "
                "kararları vermeye katkısını açıklama; tarihi yalnız tarih ve kişi adı "
                "ezberi olarak görmeme.",
        dikkat=6,
        brifing=(
            "Kış yaklaşıyor; ikmal kafilesi kuzey ya da güney geçidinden gidecek.\n\n"
            "{} arşivi toplarken şunu söyledi: \"Tarih dediğin tarih ve isim ezberidir. "
            "Geçit günlüğünü kısaltalım; kim hangi gün nereden geçti, o kadarı yeter.\"\n\n"
            "Günlük kısaltılmadan önce kararın hangi bilgilere dayandığını görmemiz "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Geçit günlüğü", "\n".join(gunluk), bedel=1, kritik=True),
            Kanit("Önlem notları",
                  "\n".join("{}: {}".format(g, n) for g, (_, n) in _GECIT_GUNLUGU.items()),
                  bedel=1, kritik=True),
            Kanit("Kısaltılmış liste önerisi", "\n".join(liste), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Tarih öğrenmenin ve arşiv tutmanın faydası nedir?",
                dogru="Neden ve sonuçları saklayıp ortak hafızayı korumak, daha iyi karar vermek",
                yanlislar={
                    "Tarihleri ve kişi adlarını ezberlemek":
                        "Tarih öğrenmeyi yalnız tarih ve kişi adı ezberlemek sandın. "
                        "Kısaltılmış liste geçit kararına hiçbir bilgi vermiyor.",
                    "Geçmişte olanları aynen tekrarlamak; bir kez işe yarayan yine yarar":
                        "Geçmiş, aynen tekrarlanmak için değil, ondan ders çıkarmak için öğrenilir.",
                    "Hiçbir faydası yoktur; geçmiş bugünü etkilemez, her durum kendine özgüdür":
                        "Geçen kışların kayıtları bu kışın kararını doğrudan etkiliyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarih, ne olduğunu olduğu kadar neden olduğunu ve sonucunu da kaydeder. "
                    "Bir ekip ya da toplum bu kayıtlarla ortak bir hafıza kurar; aynı "
                    "hataları tekrarlamamak ve daha iyi karar vermek için ona başvurur."
                ),
                ipuclari=[
                    "Kısaltılmış liste hangi geçidin daha güvenli olduğunu söylüyor mu?",
                    "Geçit günlüğünde hangi bilgiler var?",
                ],
                cozum="Ortalama kapalı gün = üç kışın toplamı ÷ 3; daha az kapalı kalan geçit seçilir.",
            ),
            sayi_adimi(
                soru="Son üç kışta kuzey geçidi ortalama kaç gün kapalı kaldı?",
                cevap=kuzey_ort,
                birim="gün",
                aciklama="({}) ÷ 3 = {} gün.".format(" + ".join(str(k) for k in kuzey), kuzey_ort),
                yaygin_yanlislar={
                    sum(kuzey): "Toplamı bulup üçe bölmeyi unuttun.",
                },
                ipuclari=["Üç kışın gün sayılarını topla, üçe böl."],
                puan=10,
            ),
            sayi_adimi(
                soru="Son üç kışta güney geçidi ortalama kaç gün kapalı kaldı?",
                cevap=guney_ort,
                birim="gün",
                aciklama="({}) ÷ 3 = {} gün.".format(" + ".join(str(g) for g in guney), guney_ort),
                yaygin_yanlislar={
                    sum(guney): "Toplamı bulup üçe bölmeyi unuttun.",
                },
                ipuclari=["Üç kışın gün sayılarını topla, üçe böl."],
                puan=8,
            ),
            coklu_adimi(
                soru="Geçit kararı için günlükteki hangi bilgiler işe yarar? "
                     "(numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogrular,
                aciklama="Süre, neden ve işe yarayan önlem kararı besler; yazarın adı ve sıra numarası beslemez.",
                ipuclari=["Hangi bilgi bu kış ne olacağını tahmin etmeye yardım eder?"],
                puan=12,
            ),
            yorum_adimi(
                soru="Günlük yalnız tarih ve isim listesine indirilirse ne olur?",
                dogru="Neden ve ne kadar kapandığı unutulur; ekip aynı tehlikeye yeniden girebilir",
                yanlislar={
                    "Hiçbir şey kaybedilmez; tarih zaten tarih ve isimlerden ibarettir":
                        "Tarih öğrenmeyi yalnız tarih ve kişi adı ezberlemek sandın.",
                    "Karar daha kolay olur; daha az bilgi daha iyidir":
                        "Kısaltılmış liste hangi geçidin daha az kapandığını söylemiyor.",
                    "Günlüğü yazanlar ekipten ayrılsa da bilgi onların hafızasında kalır, sorulunca anlatırlar":
                        "Ortak hafıza kişilerde değil, arşivde korunur; kişiler ayrılınca "
                        "bilgi de gider.",
                },
                rastgele=rastgele,
                aciklama=("Günlük, ekibin ortak hafızasıdır: kuzey geçidi ortalama {} gün, "
                          "güney geçidi {} gün kapalı kaldı; bu bilgi olmadan karar tahmine "
                          "kalır.").format(kuzey_ort, guney_ort),
                ipuclari=["Kısaltılmış listeye bakarak geçit seçebilir misin?"],
                puan=10,
            ),
        ],
        kapanis=("Günlük kısaltılmadı: kuzey geçidi ortalama {} gün, güney geçidi {} gün "
                 "kapalı kalmış. Kafile güney geçidinden, zincirli kızaklarla gidecek."
                 ).format(kuzey_ort, guney_ort),
        odul={"itibar": 4, "erzak": 2},
    )
