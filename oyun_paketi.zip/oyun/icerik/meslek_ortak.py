# -*- coding: utf-8 -*-
"""
Birden çok meslek dalında geçerli görevler.

Buradaki üreticiler ÜST ÜSTE İKİ @bulmaca ile iki dala birden kaydedilir;
içerik bir kez yazılır, iki bölümde birden çıkar. Meslek içeriğinin 50 bölüme
ayrı ayrı yazılmadan büyümesini sağlayan yol budur.

`elektrikli_motor` aynı zamanda ittifak mekaniğinin ders kitabı örneğidir:
elektrikçi ile makineci aynı nesneyi iki farklı dilden ölçer ve hiçbiri tek
başına tabloyu tamamlayamaz. Ayrıntı: TASARIM_NOTLARI.md

Kademe ölçeği: 1-4 ilkokul, 5-8 ortaokul, 9-12 lise, 13 üniversite.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, model_adimi, sayi_adimi, sirala_adimi,
    sy, yorum_adimi,
)

GERILIM = 220
DEVIR = 955
KATSAYI = 9550

# (akım A, elektriksel güç kW, verim, mil gücü kW, moment Nm)
# Dördü de tam çıksın diye hazır seçilmiş beşliler. DEVIR = 955 olduğu için
# moment daima mil gücünün on katıdır.
MOTOR_OLCUMLERI = [
    (20, 4.4, 0.75, 3.3, 33),
    (25, 5.5, 0.80, 4.4, 44),
    (40, 8.8, 0.75, 6.6, 66),
    (50, 11.0, 0.80, 8.8, 88),
]


# ==========================================================================
# İKİ DİLDEN TEK MOTOR
# ==========================================================================

@bulmaca(ders="elektrik", konu="elektrikli_motor", kademeler=(10, 13),
         etiketler=("guc_verim",), agirlik=1.3)
@bulmaca(ders="makine", konu="elektrikli_motor", kademeler=(10, 13),
         etiketler=("guc_verim",), agirlik=1.3)
def elektrikli_motor(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Bir elektrikli motor tek nesnedir ama iki dilden ölçülür.

    Elektrikçi gerilim ve akımı görür; makineci moment ve devri görür. İki
    ölçüm aynı büyüklüğe -güce- bakar ve tutmaz: aradaki fark kayıptır, oranı
    verimdir. İki dalın birbirine gerçekten ihtiyaç duyduğu yer burasıdır.
    """
    akim, elk_kw, verim, mil_kw, moment = rastgele.choice(MOTOR_OLCUMLERI)
    kayip_kw = round(elk_kw - mil_kw, 4)
    elektrikci, makineci = ad_sec(rastgele, PERSONEL, 2)

    return Bulmaca(
        kod="ort-elektrikli-motor",
        ders="elektrik",
        baslik="İki Defter",
        kademe=kademe,
        konu="elektrikli_motor",
        kazanim="Elektriksel güç (V × I) ile mil gücü (M × n ÷ 9550) "
                "arasındaki bağ; verim ve kayıp.",
        dikkat=7,
        brifing=(
            "Değirmenin motoru için iki ayrı defter tutulmuş ve iki defter "
            "aynı şeyi söylemiyor.\n\n"
            "{} panodan ölçmüş: hat {} V, motor {} A çekiyor. {} ise mil "
            "tarafından ölçmüş: {} Nm moment, dakikada {} devir.\n\n"
            "İkisi de kendi sayısının doğru olduğunu söylüyor. Komutan "
            "hangisinin haklı olduğunu değil, iki defterin nasıl olup da "
            "aynı motoru anlattığını soruyor."
        ).format(elektrikci, GERILIM, akim, makineci, moment, DEVIR),
        kanitlar=[
            Kanit("Pano defteri ({})".format(elektrikci),
                  "Gerilim: {} V. Akım: {} A.".format(GERILIM, akim),
                  bedel=1, kritik=True),
            Kanit("Mil defteri ({})".format(makineci),
                  "Moment: {} Nm. Devir: {} dev/dak.".format(moment, DEVIR),
                  bedel=1, kritik=True),
            Kanit("El kitabı - iki bağıntı",
                  "\"Elektriksel güç: P = V × I (watt).\n"
                  "Mil gücü: P = M × n ÷ 9550 (kilovat).\n"
                  "İkisi de GÜÇ verir; birimleri eşitlemek yeter.\"",
                  bedel=2, kritik=True),
            Kanit("Ustanın notu",
                  "\"Bir motoru iki taraftan ölçersen iki farklı sayı "
                  "bulursun. Bu, birinin yanlış ölçtüğü anlamına gelmez.\"",
                  bedel=2, kritik=True),
            Kanit("Bakım kaydı",
                  "Motor geçen yıl sarıldı, rulmanları yeni.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İki defter aynı motoru nasıl anlatıyor olabilir?",
                dogru=("İkisi de gücü ölçüyor ama farklı yerden: biri motora "
                       "GİREN elektriksel gücü, öteki milden ÇIKAN gücü. "
                       "Aradaki fark kayıptır."),
                yanlislar={
                    "Biri yanlış ölçmüş; doğru olan tek bir sayı vardır.":
                        "İki ölçüm de doğru olabilir. Motorun girişi ile "
                        "çıkışı aynı sayı değildir; arada kayıp vardır.",
                    "İki sayı toplanırsa motorun gerçek gücü bulunur.":
                        "Toplamak iki ölçümü üst üste koymak olur. Oysa aynı "
                        "gücün iki ucundan söz ediyoruz; toplanmaz, "
                        "karşılaştırılır.",
                    "İkisi farklı büyüklükler; karşılaştırılamazlar.":
                        "İkisi de güçtür. Biri watt, öteki kilovat cinsinden "
                        "çıkıyor; birimleri eşitlediğinde aynı ölçekte "
                        "olurlar.",
                    "Devir ölçümü yanlış; mil gücü hesaplanamaz.":
                        "Devir ölçümü geçerli ve mil gücü için gerekli. "
                        "Moment tek başına güç vermez, devirle birlikte verir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Elektriksel güç {} × {} = {} W = {} kW; mil gücü "
                    "{} × {} ÷ 9550 = {} kW. Fark {} kW motorda ısıya "
                    "dönüşüyor. Elektrikçinin defteri girişi, makinecininki "
                    "çıkışı yazmış.".format(
                        GERILIM, akim, GERILIM * akim, sy(elk_kw),
                        moment, DEVIR, sy(mil_kw), sy(kayip_kw))),
                ipuclari=[
                    "Elektrik motora hangi taraftan giriyor, iş hangi "
                    "taraftan çıkıyor?",
                    "İki bağıntı da aynı birimi veriyor. Sayılar neden "
                    "tutmuyor olabilir?",
                ],
                cozum=(
                    "1) Elektriksel güç = {} × {} = {} W = {} kW\n"
                    "2) Mil gücü = {} × {} ÷ 9550 = {} kW\n"
                    "3) Fark = {} - {} = {} kW (kayıp)".format(
                        GERILIM, akim, GERILIM * akim, sy(elk_kw),
                        moment, DEVIR, sy(mil_kw),
                        sy(elk_kw), sy(mil_kw), sy(kayip_kw))),
            ),
            sayi_adimi(
                soru="Milden çıkan güç kaç kW?",
                cevap=mil_kw,
                birim="kW",
                aciklama="{} × {} ÷ 9550 = {} kW".format(
                    moment, DEVIR, sy(mil_kw)),
                yaygin_yanlislar={
                    elk_kw:
                        "Elektriksel gücü yazdın. O motora GİREN güç; "
                        "sorulan milden çıkan.",
                    moment * DEVIR:
                        "9550'ye bölmeyi atladın; sonuç kilovat değil.",
                    round(moment / float(DEVIR), 4):
                        "Momenti devire böldün. Güç için ikisini çarpman "
                        "gerekiyor.",
                },
                ipuclari=["Mil tarafı için makine bağıntısını kullan."],
                puan=14,
            ),
            sayi_adimi(
                soru="Motorun verimi yüzde kaç?",
                cevap=round(verim * 100),
                birim="%",
                aciklama="{} ÷ {} = {} → %{}".format(
                    sy(mil_kw), sy(elk_kw), sy(verim),
                    int(round(verim * 100))),
                yaygin_yanlislar={
                    round(elk_kw / mil_kw * 100):
                        "Bölmeyi ters kurdun; %100'ü aşan bir verim çıktı. "
                        "Motor aldığından fazlasını veremez.",
                    round(kayip_kw / elk_kw * 100):
                        "Bu, kaybın oranı. Verim ise işe dönüşen kısmın "
                        "oranıdır; ikisi birbirini yüze tamamlar.",
                },
                ipuclari=["Çıkan gücü girene böl."],
                puan=14,
            ),
            yorum_adimi(
                soru="Elektrikçi tek başına bu tabloyu tamamlayabilir miydi?",
                dogru=("Hayır; mil ölçümü olmadan çıkan gücü, dolayısıyla "
                       "verimi bilemezdi."),
                yanlislar={
                    "Evet; gerilim ve akım motorun her şeyini söyler.":
                        "Gerilim ve akım yalnızca motora GİRENİ söyler. "
                        "Çıkanı bilmeden verim hesaplanamaz.",
                    "Evet; verim motor plakasında zaten yazar.":
                        "Plaka değeri motorun yeni hâlindeki değerdir; "
                        "sahadaki gerçek verim ölçümle bulunur.",
                    "Hayır; ama makineci tek başına tamamlayabilirdi.":
                        "Makineci de yalnızca çıkanı ölçüyor. Gireni bilmeden "
                        "o da verimi bulamaz; iki ölçüm birbirini gerektiriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Verim bir ORANdır ve oranın iki ucu iki farklı daldan "
                    "geliyor. Bu görev tek kişilik değil; iki defterin "
                    "birleştiği yerde tamamlanıyor."),
            ),
        ],
        kapanis=("İki defter yan yana konup tek sayfaya geçirildi. Altına "
                 "\"giren {} kW, çıkan {} kW, kayıp {} kW\" yazıldı - iki "
                 "imzayla.".format(sy(elk_kw), sy(mil_kw), sy(kayip_kw))),
        odul={"enerji": 3, "cevher": 2, "itibar": 3},
    )


# ==========================================================================
# ARIZA ARAMA SIRASI
# ==========================================================================

@bulmaca(ders="elektrik", konu="bakim_sirasi", kademeler=(9, 12),
         etiketler=("sira_prosedur",))
@bulmaca(ders="makine", konu="bakim_sirasi", kademeler=(9, 12),
         etiketler=("sira_prosedur",))
def bakim_sirasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Arıza arama bir algoritmadır ve ilk adımı hesap değil güvenliktir.

    İki kural üst üste biner: önce enerjiyi kes (güvenlik), sonra ucuz ve sık
    olandan pahalı ve nadir olana git (maliyet). İkisini karıştıran öğrenci ya
    çarpılır ya da boşuna motor söker.
    """
    adimlar_dogru = [
        "Tezgâhın enerjisini kes ve panoyu kilitle",
        "Gözle bak: kablo kopuk mu, kayış gevşek mi",
        "Sigortayı ve termik röleyi kontrol et",
        "Motoru sök, yataklara ve sargıya bak",
        "Yapılanları bakım defterine yaz",
    ]
    karisik = list(adimlar_dogru)
    rastgele.shuffle(karisik)
    sirali = [karisik.index(a) for a in adimlar_dogru]
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="ort-bakim-sirasi",
        ders="elektrik",
        baslik="Duran Tezgâh",
        kademe=kademe,
        konu="bakim_sirasi",
        kazanim="Arıza aramada işlem sırası; güvenliğin önceliği; ucuzdan "
                "pahalıya eleme.",
        dikkat=5,
        brifing=(
            "{} atölyesindeki tezgâh sabah çalışmadı. Düğmeye basılıyor, ses "
            "yok, gösterge sönük.\n\n"
            "Ustabaşı \"motoru sökün\" diyor; motor sökmek yarım gün ve iki "
            "kişi demek. Yanındaki çırak panoya bakmayı öneriyor.\n\n"
            "Elinde beş iş var ama hangisinin önce geleceği yazılı değil. "
            "Yanlış sıra ya yarım günü ya da birinin canını yakar."
        ).format(mevki),
        kanitlar=[
            Kanit("Atölye güvenlik levhası",
                  "\"Elektrikli bir makinede hiçbir işe, enerjisi kesilip "
                  "pano kilitlenmeden başlanmaz.\"",
                  bedel=1, kritik=True),
            Kanit("Bakım el kitabı",
                  "\"Güvenlik sağlandıktan sonra: önce ucuz, hızlı ve sık "
                  "rastlanan sebebi ele; pahalı ve nadir olanı sona bırak.\"",
                  bedel=2, kritik=True),
            Kanit("Geçen yılın kaydı",
                  "Sekiz duruşun beşi sigorta ya da termikten, ikisi gevşek "
                  "kayıştan, biri motordandı.", bedel=2, kritik=True),
            Kanit("Defter kuralı",
                  "Bakım defteri, arıza bulunsa da bulunmasa da en sonda "
                  "doldurulur; yapılan her adım yazılır.", bedel=1),
            Kanit("Vardiya notu",
                  "Dün akşam tezgâh sorunsuz kapatılmış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu beş işin sırasını ne belirler?",
                dogru=("Önce güvenlik; sonra ucuz, hızlı ve sık rastlanan "
                       "sebepten pahalı ve nadir olana doğru gitmek."),
                yanlislar={
                    "Yalnızca maliyet: en ucuz işten en pahalıya doğru.":
                        "Maliyet sıralaması doğru ama tek başına yeterli "
                        "değil. Enerjisi kesilmemiş bir tezgâhta en ucuz iş "
                        "bile canını yakabilir; güvenlik maliyetin önüne "
                        "geçer.",
                    "Ustabaşının dediği yapılır; tecrübe hesaptan üstündür.":
                        "Tecrübe yararlıdır ama kayıt, arızaların çoğunun "
                        "motordan gelmediğini gösteriyor. Yöntem kişiye göre "
                        "değişirse sonuç da değişir.",
                    "İşler listede yazıldıkları sırayla uygulanır.":
                        "Liste sırası bir yöntem değil, yalnızca yazım "
                        "sırasıdır. Sıralamayı güvenlik ve olasılık "
                        "belirlemeli.",
                    "En pahalı ihtimal önce elenir, gerisi hızlı geçilir.":
                        "Pahalıyı önce elemek çoğu zaman boşuna yarım gün "
                        "demek. Kayda göre arızaların çoğu motorda değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki kural üst üste biner. Birincisi mutlaktır: enerji "
                    "kesilmeden hiçbir işe başlanmaz. İkincisi ekonomiktir: "
                    "her adım bir ihtimali eler, en çok ihtimali en az "
                    "maliyetle eleyen adım öne gelir."),
                ipuclari=[
                    "Hangi adım yapılmadan diğerlerine başlamak tehlikeli?",
                    "Geçen yılın kaydı arızaların çoğunun nereden geldiğini "
                    "söylüyor.",
                ],
            ),
            sirala_adimi(
                soru="İşleri uygulanacakları sıraya diz (numaraları sırayla "
                     "yaz):",
                secenekler=karisik,
                dogru_sira=sirali,
                aciklama=(
                    "Doğru sıra: enerjiyi kes ve kilitle → gözle bak → "
                    "sigorta ve termik → motoru sök → deftere yaz. İlk adım "
                    "güvenlik, son adım kayıt; aradakiler ucuzdan pahalıya."),
                ipuclari=[
                    "Güvenlik adımı her zaman başta durur.",
                    "Motor sökmek yarım gün; kaydın söylediğine göre en son "
                    "bakılacak yer.",
                ],
                puan=20,
            ),
            yorum_adimi(
                soru="Enerjiyi kesmek neden gözle bakmaktan da önce geliyor?",
                dogru=("Gözle bakmak bile makinenin içine uzanmayı gerektirir; "
                       "enerjili makinede en küçük temas tehlikelidir."),
                yanlislar={
                    "Gelmiyor; gözle bakmak zararsızdır, önce o yapılabilir.":
                        "Gözle bakmak için kapak açılır, el uzatılır. "
                        "Enerjili bir makinede bu adım da risklidir.",
                    "Enerji kesilirse arıza görünmez olur, o yüzden aslında "
                    "sonra yapılmalı.":
                        "Aranan şey kopuk kablo, gevşek kayış, atmış sigorta "
                        "gibi izler; bunlar enerjisiz de görülür.",
                    "Çünkü enerjiyi kesmek en ucuz iştir.":
                        "Doğru sebep maliyet değil. Enerji kesme sıraya "
                        "ucuzluğundan değil, güvenlik olduğundan giriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Güvenlik adımları maliyet sıralamasına girmez; onun "
                    "üstündedir. Bir adım \"ucuz\" diye değil, \"zorunlu\" "
                    "diye başa konur."),
            ),
        ],
        kapanis=("Termik röle atmıştı. Pano kilidi açıldığında tezgâh ilk "
                 "denemede çalıştı; motor hiç sökülmedi."),
        odul={"itibar": 3, "erzak": 2},
    )
