# -*- coding: utf-8 -*-
"""
Yerel sunucular icin ortak ag denetimleri.

NEDEN
-----
`araclar/sunucu.py` kimlik dogrulamasi olmayan bir yerel sunucudur. Tek
koruma agin kendisi; bu yuzden uc denetim gerekir:

* Istemci agi  : yalniz yerel ve ozel ag adresleri (loopback, 10/8,
                 172.16/12, 192.168/16, Tailscale 100.64/10). Hamachi
                 (25.0.0.0/8) ve genel internet reddedilir.
* Host basligi : DNS rebinding'e karsi. Kotu bir site kendi adini
                 127.0.0.1'e cozdurup tarayicidan sunucuya erisebilir;
                 Host basligi o zaman bilmedigimiz bir ad olur.
* Origin       : tarayicidan baska bir sayfanin POST gondermesine (CSRF)
                 karsi. Origin yoksa istek tarayicidan degildir; varsa
                 Host ile ayni olmak zorunda.

Bunlar kimlik dogrulama DEGILDIR. Ayni agdaki herkes yine de erisebilir
(`--lan` ile acildiysa).
"""
from __future__ import annotations

import ipaddress
import socket
from typing import Iterable, Optional, Set
from urllib.parse import urlsplit

IZINLI_AGLAR = tuple(ipaddress.ip_network(a) for a in (
    "127.0.0.0/8", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
    "100.64.0.0/10"))

YEREL_ADLAR = frozenset({"localhost", "127.0.0.1", "::1"})


def istemci_izinli_mi(adres: str) -> bool:
    """Istemci IP'si izinli aglardan birinde mi?"""
    try:
        ip = ipaddress.ip_address((adres or "").split("%")[0])
    except ValueError:
        return False
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
        ip = ip.ipv4_mapped
    if ip.is_loopback:
        return True
    return any(ip in ag for ag in IZINLI_AGLAR if ag.version == ip.version)


def _host_adi(baslik: str) -> str:
    """'Host' basligindan port'u atip adi kucuk harfle dondurur."""
    baslik = (baslik or "").strip().lower()
    if baslik.startswith("["):                 # [::1]:8756
        return baslik[1:baslik.find("]")] if "]" in baslik else ""
    if baslik.count(":") == 1:
        return baslik.split(":", 1)[0]
    return baslik


def makinenin_adlari() -> Set[str]:
    """Bu makinenin kendi IP'leri ve adi (LAN kipinde Host olarak kabul edilir)."""
    adlar = set()
    try:
        ad = socket.gethostname()
        adlar.update({ad.lower(), socket.getfqdn().lower()})
        for bilgi in socket.getaddrinfo(ad, None, socket.AF_INET):
            adlar.add(bilgi[4][0])
    except Exception:                          # noqa: BLE001
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("10.255.255.255", 1))   # paket GITMEZ, yalnizca yol secilir
            adlar.add(s.getsockname()[0])
        finally:
            s.close()
    except Exception:                          # noqa: BLE001
        pass
    adlar.discard("")
    return adlar


def izinli_adlar(lan: bool, ek: Iterable[str] = ()) -> Set[str]:
    adlar = set(YEREL_ADLAR)
    if lan:
        adlar |= makinenin_adlari()
    adlar.update(a.lower() for a in ek)
    return adlar


def host_izinli_mi(host_basligi: Optional[str], adlar: Iterable[str]) -> bool:
    ad = _host_adi(host_basligi or "")
    return bool(ad) and ad in set(adlar)


def origin_uyumlu_mu(origin: Optional[str], host_basligi: Optional[str]) -> bool:
    """Origin yoksa kabul; varsa Host ile ayni olmali (durum degistiren istekler)."""
    if not origin:
        return True
    return (urlsplit(origin).netloc.lower() == (host_basligi or "").strip().lower()
            and bool(host_basligi))
