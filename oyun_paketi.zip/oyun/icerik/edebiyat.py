# -*- coding: utf-8 -*-
"""
Söz ve anlatım görevleri.

Bu görevlerin çoğu tanıma sorusudur: bir dize verilir, hangi söz
sanatı; bir paragraf verilir, hangi anlatım biçimi; bir şiirin özellikleri
verilir, hangi nazım biçimi. Yani zaten "özellikten türe git" biçiminde
kurulmuştur - oyunun keşif adımına birebir oturur.

Bu modülde şiir ve metin örnekleri oyun için yazılmıştır; gerçek bir şaire
ait değildir. Ölçülen şey metnin kime ait olduğu değil, taşıdığı özelliktir.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi, secim_adimi, sirala_adimi,
    yorum_adimi,
)


# ==========================================================================
# SÖZ SANATLARI
# ==========================================================================

_SANATLAR = [
    {
        "dize": "Rüzgâr bütün gece pencereyi dövdü, sabaha kadar susmadı.",
        "sanat": "Kişileştirme (teşhis)",
        "olcut": "İnsana ait bir davranış (dövmek, susmak) insan dışı bir varlığa verilmiş.",
    },
    {
        "dize": "Yüzü, karanlıkta görünen bir fener gibi aydınlıktı.",
        "sanat": "Benzetme (teşbih)",
        "olcut": ("İki varlık \"gibi\" edatıyla, ortak bir yön (aydınlık olma) "
                  "üzerinden birbirine benzetilmiş."),
    },
    {
        "dize": "Sevincinden yerinde duramıyor, dünyayı sığdıramıyordu içine.",
        "sanat": "Abartma (mübalağa)",
        "olcut": "Bir duygu, gerçekte olamayacak ölçüde büyütülerek anlatılmış.",
    },
    {
        "dize": "Ağlarım, hatıra geldikçe gülüştüklerimiz.",
        "sanat": "Karşıtlık (tezat)",
        "olcut": "Birbirinin karşıtı iki durum (ağlamak - gülmek) bir arada verilmiş.",
    },
    {
        "dize": "Bütün üs, komutanın haberini bekliyordu.",
        "sanat": "Ad aktarması (mecaz-ı mürsel)",
        "olcut": ("\"Üs\" sözcüğü binayı değil içindeki insanları anlatıyor: "
                  "parça-bütün ilişkisiyle bir ad başka bir şeyin yerine kullanılmış."),
    },
]


@bulmaca(ders="edebiyat", konu="soz_sanatlari", kademeler=(10, 13), agirlik=1.4)
def soz_sanatlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Dizeden söz sanatını tanıma."""
    sanat = rastgele.choice(_SANATLAR)
    digerleri = [s["sanat"] for s in _SANATLAR if s["sanat"] != sanat["sanat"]]
    rastgele.shuffle(digerleri)

    return Bulmaca(
        kod="ede-soz-sanatlari",
        ders="edebiyat",
        baslik="Defterdeki Dize",
        kademe=kademe,
        konu="soz_sanatlari",
        kazanim="Söz sanatlarını dizedeki özelliklerinden tanıma.",
        dikkat=5,
        # B46.3 (pilot dersi edebiyat): giriş alçaltıldı. Dize brifingde ikinci
        # kez yazılmıyor (kanıtta var); benzetme/ad aktarması notu ilk ekrandan
        # çıktı, yalnız onu soran 3. adımda geliyor. İlk ipucu günlük konuşma
        # benzetmesi. Şıklar ve doğru cevaplar aynı
        # (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "Arşivdeki eski bir defterden tek bir dize çıktı; şairi belli değil. "
            "Fişe dizedeki söz sanatını yazacağız. Bunun için dizenin kendisi "
            "yeter."
        ),
        kanitlar=[
            Kanit("Dize", sanat["dize"], bedel=1, kritik=True),
            Kanit("Söz sanatları kılavuzu",
                  "BENZETME (teşbih): İki varlık ortak bir yön üzerinden "
                  "birbirine benzetilir. Genellikle \"gibi, kadar, sanki\" bulunur.\n\n"
                  "KİŞİLEŞTİRME (teşhis): İnsana ait özellik ya da davranış, "
                  "insan dışı bir varlığa verilir.\n\n"
                  "ABARTMA (mübalağa): Bir durum gerçekte olamayacak ölçüde "
                  "büyütülür ya da küçültülür.\n\n"
                  "KARŞITLIK (tezat): Birbirine karşıt kavramlar bir arada kullanılır.\n\n"
                  "AD AKTARMASI (mecaz-ı mürsel): Bir sözcük, benzetme amacı "
                  "OLMADAN başka bir şeyin yerine kullanılır (parça-bütün, "
                  "iç-dış, yer-insan ilişkisiyle).",
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir dizedeki söz sanatını tanımak için neye bakılır?",
                dogru="Sözcükler arasındaki ilişkiye: benzerlik, karşıtlık ya da aktarma.",
                yanlislar={
                    "Dizenin kaç heceli olduğuna.":
                        "Hece sayısına baktın. Hece ölçüsü nazımla ilgilidir; "
                        "söz sanatını belirleyen şey sözcükler arasında "
                        "kurulan İLİŞKİ.",
                    "Dizenin hangi şaire ait olduğuna.":
                        "Şaire baktın. Aynı şair farklı sanatlar kullanır; "
                        "sanat dizenin kendisinden okunur.",
                    "Dizede kaç sözcük bulunduğuna; her sanat belli sayıda sözcükle kurulur.":
                        "Sözcük saydın. Sanat sözcük sayısıyla değil, "
                        "aralarındaki anlam bağıyla belirlenir.",
                    "Dizenin duygusal olup olmadığına; duygusuz dizede sanat bulunmaz.":
                        "Duyguyu ölçüt saydın. Duygusuz bir dizede de söz "
                        "sanatı bulunabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Söz sanatları, sözcükler arasında kurulan ilişkiye göre "
                    "adlandırılır. Benzerlik varsa teşbih, insana ait özellik "
                    "aktarılmışsa teşhis, karşıtlık varsa tezat, benzerlik olmadan "
                    "bir ad başkasının yerine geçmişse mecaz-ı mürseldir. Hece sayısı "
                    "ve şair adı nazım bilgisiyle ilgilidir, söz sanatıyla değil."
                ),
                ipuclari=[
                    "Günlük konuşmada da söz sanatı kullanırız: \"buz gibi su\" "
                    "deriz, \"sınıf çok sessiz\" deriz. İkisinde de sanatı, "
                    "sözcüklerin birbirine nasıl bağlandığı belirler.",
                    "Dizede iki şey birbirine benzetiliyor mu?",
                    "İnsana ait bir davranış, insan olmayan bir şeye mi verilmiş?",
                ],
                puan=18,
                cozum=(
                    "1) Dizedeki sözcükler arasında kurulan ilişkiyi belirle.\n"
                    "2) Kılavuzdaki beş tanımla karşılaştır:\n"
                    "   - \"gibi/kadar/sanki\" ve ortak yön -> Benzetme\n"
                    "   - insana ait davranış, insan dışı varlıkta -> Kişileştirme\n"
                    "   - gerçekte olamayacak büyütme -> Abartma\n"
                    "   - karşıt kavramlar bir arada -> Karşıtlık\n"
                    "   - benzerliksiz yer değiştirme -> Ad aktarması\n"
                    "3) Bu dizedeki ölçüt: {}\n\n"
                    "Sonuç: {}"
                ).format(sanat["olcut"], sanat["sanat"]),
            ),
            secim_adimi(
                soru="Bu dizede hangi söz sanatı vardır?",
                dogru=sanat["sanat"],
                yanlislar=digerleri[:4],
                rastgele=rastgele,
                aciklama="{} Bu ölçüt {} sanatını tanımlar.".format(
                    sanat["olcut"], sanat["sanat"]),
                ipuclari=["Kılavuzdaki beş tanımı dizeyle tek tek karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru=("Ayırt etme notu: \"Benzetme ile ad aktarmasını karıştırma: "
                      "benzetmede iki varlık arasında BENZERLİK kurulur, ad "
                      "aktarmasında benzerlik yoktur, ilgi vardır (parça-bütün, "
                      "yer-insan gibi).\"\n\nBenzetme ile ad aktarması arasındaki "
                      "temel fark nedir?"),
                dogru="Benzetme benzerliğe, ad aktarması benzerlik dışı bir ilgiye dayanır.",
                yanlislar={
                    "Benzetme şiirde, ad aktarması düzyazıda kullanılır; düzyazı benzetme kullanmaz.":
                        "Ayrımı türe bağladın. İkisi de hem şiirde hem "
                        "düzyazıda geçer; fark KURULAN İLİŞKİDE.",
                    "Benzetme eski, ad aktarması yeni bir sanattır.":
                        "Ayrımı tarihe bağladın. İkisi de çok eski "
                        "sanatlardır.",
                    "Benzetmede iki sözcük, ad aktarmasında üç sözcük bulunur.":
                        "Ayrımı sözcük sayısına indirdin. Belirleyici olan "
                        "sayı değil, sözcükler arasındaki bağın benzerlik mi "
                        "yoksa yakınlık/parça-bütün ilişkisi mi olduğu.",
                    "Aralarında anlamlı bir fark yoktur.":
                        "Farkı yok saydın. Benzetmede iki ayrı şey benzerlik "
                        "kurar; ad aktarmasında bir şey, kendisiyle ilgili "
                        "başka bir şeyin yerine geçer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Aslan gibi adam\" benzetmedir: adamla aslan arasında cesaret "
                    "benzerliği kurulur. \"Sobayı yaktık\" ad aktarmasıdır: soba ile "
                    "odun arasında benzerlik yok, kap-içindeki ilişkisi var. Bu "
                    "ayrım, metnin nasıl kurulduğunu anlamanın anahtarıdır."
                ),
                ipuclari=["\"Aslan gibi adam\" ile \"Sobayı yaktık\" sözlerini "
                          "karşılaştır: hangisinde benzerlik var?"],
                puan=12,
            ),
        ],
        kapanis="Dize fişlendi ve arşivin şiir bölümüne kondu.",
        odul={"itibar": 7},
    )


# ==========================================================================
# ANLATIM BİÇİMLERİ
# ==========================================================================

_ANLATIMLAR = [
    {
        "metin": ("Kapıdan girince dar bir koridor karşılıyordu insanı. Duvarlar "
                  "soluk yeşile boyanmıştı, boya yer yer kabarmıştı. Sağdaki "
                  "pencereden giren ışık, yerdeki tozu görünür kılıyordu."),
        "bicim": "Betimleyici anlatım",
        "olcut": ("Görüntü ayrıntılarıyla resmediliyor; olay yok, zaman akmıyor. "
                  "Okuyanın gözünde bir görüntü canıyor."),
    },
    {
        "metin": ("Kapıyı açtı, koridora çıktı. Merdivenleri ikişer ikişer indi. "
                  "Aşağıda kimse yoktu; dışarı fırladı ve arabaya atlayıp yola koyuldu."),
        "bicim": "Öyküleyici anlatım",
        "olcut": ("Olaylar zaman sırasına göre birbirini izliyor; kişi, eylem ve "
                  "akış var."),
    },
    {
        "metin": ("Yükseltinin artmasıyla sıcaklık düzenli olarak azalır. Bunun "
                  "sebebi, havanın yeryüzünden yansıyan ısıyla ısınmasıdır. "
                  "Yerden uzaklaştıkça bu ısı kaynağından da uzaklaşılmış olur."),
        "bicim": "Açıklayıcı anlatım",
        "olcut": ("Bir konu hakkında bilgi veriliyor, sebebi öğretiliyor; "
                  "tartışma ya da savunma yok."),
    },
    {
        "metin": ("Kimileri okumanın artık gereksizleştiğini, her bilginin bir "
                  "tıkla bulunabildiğini söylüyor. Oysa bilgiye ulaşmakla onu "
                  "anlamak aynı şey değildir. Bu görüşü savunanlar, aradaki farkı "
                  "gözden kaçırıyor."),
        "bicim": "Tartışmacı anlatım",
        "olcut": ("Bir görüş aktarılıp çürütülüyor ve karşısına yazarın görüşü "
                  "konuyor."),
    },
]


@bulmaca(ders="edebiyat", konu="anlatim_bicimleri", kademeler=(9, 13))
def anlatim_bicimleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Paragraftan anlatım biçimini tanıma."""
    anlatim = rastgele.choice(_ANLATIMLAR)
    digerleri = [a["bicim"] for a in _ANLATIMLAR if a["bicim"] != anlatim["bicim"]]

    return Bulmaca(
        kod="ede-anlatim-bicimi",
        ders="edebiyat",
        baslik="Rapordaki Paragraf",
        kademe=kademe,
        konu="anlatim_bicimleri",
        kazanim="Anlatım biçimlerini metnin özelliklerinden ayırt etme.",
        dikkat=5,
        # B46.3 (pilot dersi edebiyat): giriş alçaltıldı. Paragraf brifingde
        # ikinci kez yazılmıyor (kanıtta var); açıklayıcı/tartışmacı notu ilk
        # ekrandan çıktı, sınıflandırmanın yapıldığı 2. adımda geliyor. İlk
        # ipucu maç benzetmesi. Şıklar ve doğru cevaplar aynı
        # (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "Arşivdeki bir raporun paragrafları sınıflandırılıyor. Elindeki "
            "paragrafın konusunu değil, nasıl anlatıldığını bulacağız."
        ),
        kanitlar=[
            Kanit("Paragraf", anlatim["metin"], bedel=1, kritik=True),
            Kanit("Anlatım biçimleri kılavuzu",
                  "ÖYKÜLEYİCİ: Olaylar zaman sırasıyla anlatılır; kişi, eylem, "
                  "akış vardır. \"Sonra, ardından\" gibi bağlantılar bulunur.\n\n"
                  "BETİMLEYİCİ: Görüntü ayrıntılarıyla resmedilir; zaman akmaz, "
                  "olay yoktur. Sıfatlar yoğundur.\n\n"
                  "AÇIKLAYICI: Bilgi verilir, öğretilir. Yazar tarafsızdır, "
                  "kendi görüşünü savunmaz.\n\n"
                  "TARTIŞMACI: Bir görüş çürütülür ve yazarın görüşü savunulur. "
                  "\"Oysa, ancak, ne var ki\" gibi karşıtlık bağlaçları bulunur.",
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Anlatım biçimini belirlerken hangi soru sorulur?",
                dogru="Metnin amacı: anlatmak, betimlemek, bilgi vermek ya da görüş savunmak.",
                yanlislar={
                    "Metin hangi konuda yazılmış.":
                        "Konuya baktın. Aynı konu betimlemeyle de "
                        "tartışmayla da yazılabilir; belirleyici olan metnin "
                        "NE YAPTIĞI.",
                    "Metin kaç cümleden oluşuyor.":
                        "Uzunluğa baktın. Anlatım biçimi cümle sayısıyla "
                        "belirlenmez.",
                    "Metinde hangi zaman kipi kullanılmış; geçmiş zaman hep öyküleme demektir.":
                        "Kip iyi bir ipucudur ama tek başına yetmez; öyküleyici "
                        "olmayan metinler de geçmiş zaman kullanabilir.",
                    "Metin kim tarafından yazılmış.":
                        "Yazara baktın. Aynı yazar farklı anlatım biçimleri "
                        "kullanır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Anlatım biçimi konuyla ilgili değildir: aynı konu (örneğin bir "
                    "koridor) betimlenebilir, öykülenebilir ya da açıklanabilir. "
                    "Belirleyici olan metnin OKUYUCUYA NE YAPTIĞIDIR - gösteriyor mu, "
                    "anlatıyor mu, öğretiyor mu, ikna etmeye mi çalışıyor."
                ),
                ipuclari=[
                    "Bir maçı düşün: maçı sırasıyla anlatmak, stadı tarif etmek, "
                    "ofsayt kuralını açıklamak, hakemin kararına itiraz etmek. Her "
                    "birinde metin okura başka bir şey yapıyor.",
                    "Metinde zaman akıyor mu, yoksa bir an mı duruyor?",
                    "Yazar bir karşı görüşle hesaplaşıyor mu?",
                ],
                puan=18,
                cozum=(
                    "1) Metinde olay ve zaman akışı var mı? Varsa ÖYKÜLEYİCİ.\n"
                    "2) Zaman durmuş, görüntü ayrıntılanıyorsa BETİMLEYİCİ.\n"
                    "3) Bilgi veriliyor, sebep öğretiliyorsa AÇIKLAYICI.\n"
                    "4) Bir görüş çürütülüp karşısına yazarın görüşü konuyorsa "
                    "TARTIŞMACI.\n\n"
                    "Bu paragrafta: {}\n\nSonuç: {}"
                ).format(anlatim["olcut"], anlatim["bicim"]),
            ),
            secim_adimi(
                soru=("Ayırt etme notu: \"Açıklayıcı ile tartışmacıyı karıştırma: "
                      "ikisi de bilgi verebilir, ama tartışmacıda bir KARŞI GÖRÜŞ "
                      "vardır ve yazar onunla hesaplaşır.\"\n\nBu paragraf hangi "
                      "anlatım biçimiyle yazılmıştır?"),
                dogru=anlatim["bicim"],
                yanlislar=digerleri + ["Söyleşmeye bağlı anlatım"],
                rastgele=rastgele,
                aciklama=anlatim["olcut"],
                ipuclari=["Kılavuzdaki dört tanımı paragrafla karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Aynı konu farklı anlatım biçimleriyle yazılabilir mi?",
                dogru="Evet; biçimi konu değil, yazarın amacı belirler.",
                yanlislar={
                    "Hayır; her konunun tek bir uygun anlatım biçimi vardır.":
                        "Konuyu biçime kilitledin. Bir savaş hem "
                        "öyküleyerek hem açıklayarak hem tartışarak "
                        "anlatılabilir.",
                    "Hayır; anlatım biçimi metnin uzunluğuna göre belirlenir.":
                        "Uzunluğu belirleyici saydın. Kısa bir metin de "
                        "tartışmacı olabilir.",
                    "Evet ama yalnızca edebî metinlerde.":
                        "Doğru fikri tek türe hapsettin. Bilgilendirici "
                        "metinlerde de aynı konu farklı biçimlerde yazılır.",
                    "Evet; çünkü anlatım biçimleri arasında fark yoktur.":
                        "Doğru sonuca yanlış gerekçeyle vardın. Biçimler "
                        "arasında fark VAR; aynı konunun farklı biçimlerle "
                        "yazılabilmesi bu farkı ortadan kaldırmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir deprem betimlenebilir (yıkılan duvarlar, toz), öykülenebilir "
                    "(o gece neler oldu), açıklanabilir (fay hattı nasıl kırılır) ya "
                    "da tartışılabilir (yapı denetimi yeterli mi). Konu aynı, amaç "
                    "farklıdır. Bu yüzden soruda konuya bakmak yanıltır."
                ),
                ipuclari=["Bir depremi hem tarif edip hem de nasıl olduğunu "
                          "açıklayabilir misin?"],
                puan=12,
            ),
        ],
        kapanis="Paragraf sınıflandırıldı ve rapor dosyasına eklendi.",
        odul={"itibar": 7},
    )


# ==========================================================================
# NAZIM BİÇİMLERİ
# ==========================================================================

_NAZIMLAR = [
    {
        "ad": "Koşma",
        "ozellikler": (
            "- Nazım birimi: dörtlük\n"
            "- Dörtlük sayısı: 3-5\n"
            "- Ölçü: hece ölçüsü, 11'li (6+5 ya da 4+4+3)\n"
            "- Kafiye düzeni: abab / cccb / dddb\n"
            "- Son dörtlükte şairin adı (mahlas) geçiyor\n"
            "- Konu: sevgi, doğa, ayrılık"
        ),
        "olcut": ("Dörtlük + 11'li hece ölçüsü + son dörtlükte mahlas: bu üçlü "
                  "yalnızca koşmada bir arada bulunur."),
    },
    {
        "ad": "Mani",
        "ozellikler": (
            "- Nazım birimi: tek dörtlük\n"
            "- Ölçü: hece ölçüsü, 7'li\n"
            "- Kafiye düzeni: aaxa (üçüncü dize serbest)\n"
            "- İlk iki dize doldurma, asıl anlam son iki dizede\n"
            "- Söyleyeni belli değil (anonim)"
        ),
        "olcut": ("Tek dörtlük + 7'li hece + aaxa düzeni + anonim olması "
                  "maniyi tanımlar."),
    },
    {
        "ad": "Gazel",
        "ozellikler": (
            "- Nazım birimi: beyit\n"
            "- Beyit sayısı: 5-15\n"
            "- Ölçü: aruz ölçüsü\n"
            "- Kafiye düzeni: aa / ba / ca / da\n"
            "- Son beyitte şairin mahlası bulunur\n"
            "- Konu: aşk, güzellik, şarap"
        ),
        "olcut": ("Beyit birimi + aruz ölçüsü + aa/ba/ca kafiye düzeni gazeli "
                  "tanımlar; dörtlük ve hece ölçüsü kullanılmaz."),
    },
]


@bulmaca(ders="edebiyat", konu="nazim_bicimleri", kademeler=(10, 13))
def nazim_bicimleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Verilen özelliklerden nazım biçimini tanıma."""
    nazim = rastgele.choice(_NAZIMLAR)
    digerleri = [n["ad"] for n in _NAZIMLAR if n["ad"] != nazim["ad"]]

    return Bulmaca(
        kod="ede-nazim-bicimi",
        ders="edebiyat",
        baslik="İnceleme Fişi",
        kademe=kademe,
        konu="nazim_bicimleri",
        kazanim="Nazım biçimlerini yapı özelliklerinden ayırt etme.",
        dikkat=5,
        # B46.3 (pilot dersi edebiyat): giriş alçaltıldı. Fiş artık brifingde
        # ikinci kez yazılmıyor (kanıtta zaten var); ilk ipucu bina benzetmesi,
        # her adımda ipucu var. Şıklar ve doğru cevaplar aynı
        # (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "Arşivdeki bir şiirin inceleme fişinde \"nazım biçimi\" hanesi boş "
            "kalmış. Şiir kayıp, elimizde yalnız fiş var. Fişteki özellikler bir "
            "arada tek bir biçime uyar; o biçimi bulalım."
        ),
        kanitlar=[
            Kanit("İnceleme fişi", nazim["ozellikler"], bedel=1, kritik=True),
            Kanit("Nazım biçimleri çizelgesi",
                  "KOŞMA (Halk edebiyatı): dörtlük, 11'li hece, abab-cccb-dddb, "
                  "son dörtlükte mahlas.\n\n"
                  "MANİ (Halk edebiyatı, anonim): tek dörtlük, 7'li hece, aaxa.\n\n"
                  "GAZEL (Divan edebiyatı): beyit, aruz ölçüsü, aa-ba-ca-da, "
                  "son beyitte mahlas.\n\n"
                  "SEMAİ (Halk edebiyatı): dörtlük, 8'li hece.",
                  bedel=2, kritik=True),
            Kanit("Ayırt etme notu",
                  "\"İlk bakılacak yer NAZIM BİRİMİDİR: dörtlük mü beyit mi? "
                  "Beyitse Divan edebiyatındasın, dörtlükse Halk edebiyatında. "
                  "Sonra ölçüye bak: hece mi aruz mu?\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Nazım biçimini belirlemeye nereden başlanır?",
                dogru="Nazım biriminden: önce dörtlük mü beyit mi, sonra ölçü.",
                yanlislar={
                    "Şiirin konusundan; her biçimin kendine ait bir konusu vardır.":
                        "Konudan başladın. Aynı konu farklı nazım biçimleriyle "
                        "yazılır; ilk bakılacak şey birim ve UYAK DÜZENİ.",
                    "Şiirin uzunluğundan.":
                        "Uzunluktan başladın. Uzunluk ipucu verir ama "
                        "belirleyici olan dizelerin nasıl kümelendiği.",
                    "Şairin yaşadığı yüzyıldan; aynı yüzyılın şairleri aynı biçimi kullanır.":
                        "Tarihten başladın. Yüzyıl olasılıkları daraltır ama "
                        "biçimi şiirin kendi yapısı söyler.",
                    "Şiirde geçen sözcüklerin sayısından.":
                        "Sözcük saydın. Nazım biçimini belirleyen şey sözcük "
                        "değil, dize ve uyak düzeni.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Nazım birimi tek başına havuzu ikiye böler: beyit kullanan "
                    "biçimler Divan edebiyatına (gazel, kaside), dörtlük kullananlar "
                    "Halk edebiyatına (koşma, mani, semai) aittir. Ölçü ikinci "
                    "eleyicidir: aruz Divan'a, hece Halk'a işaret eder. Konu ise en "
                    "zayıf ölçüttür; aşk her iki gelenekte de işlenir."
                ),
                ipuclari=[
                    "Bir binanın ev mi okul mu olduğunu içindeki eşyadan değil "
                    "planından anlarız. Şiirde de plan, dizelerin nasıl "
                    "kümelendiğidir: dörtlük mü, beyit mi?",
                    "Fişte \"nazım birimi\" satırına bak.",
                    "Dörtlükse hangi gelenek, beyitse hangi gelenek?",
                ],
                puan=18,
                cozum=(
                    "1) Nazım birimi: dörtlük -> Halk edebiyatı, beyit -> Divan.\n"
                    "2) Ölçü: hece -> Halk, aruz -> Divan (birinci adımı doğrular).\n"
                    "3) Hece sayısı ve kafiye düzeniyle daralt:\n"
                    "   - 11'li + abab/cccb + mahlas -> Koşma\n"
                    "   - 7'li + aaxa + anonim + tek dörtlük -> Mani\n"
                    "   - aruz + aa/ba/ca + mahlas -> Gazel\n"
                    "4) Bu fişte: {}\n\n"
                    "Sonuç: {}"
                ).format(nazim["olcut"], nazim["ad"]),
            ),
            secim_adimi(
                soru="Bu fiş hangi nazım biçimine aittir?",
                dogru=nazim["ad"],
                yanlislar=digerleri + ["Semai", "Kaside"],
                rastgele=rastgele,
                aciklama=nazim["olcut"],
                ipuclari=["Çizelgedeki satırları fişle tek tek karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Şiirin konusu neden nazım biçimini belirlemekte zayıf bir ölçüttür?",
                dogru="Aynı konu farklı biçimlerde işlenebildiği için.",
                yanlislar={
                    "Şiirlerin konusu genellikle belirsiz olduğu için.":
                        "Konuyu belirsiz saydın. Çoğu şiirin konusu bellidir; "
                        "sorun konunun birden çok biçimde işlenebilmesi.",
                    "Konu her zaman son dörtlükte açıklandığı için.":
                        "Böyle bir kural yok ve olsa bile nazım biçimini "
                        "belirlemezdi.",
                    "Nazım biçimlerinin konusu yoktur.":
                        "Çok ileri gittin. Bazı biçimler belirli konularla "
                        "anılır; zayıflığı budur ki bu bir zorunluluk değil.",
                    "Konu yalnızca Divan edebiyatında önemlidir.":
                        "Ayrımı edebiyat dönemine bağladın. Konu her dönemde "
                        "vardır; her dönemde de tek başına biçimi belirlemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aşk hem koşmanın hem gazelin konusudur; bu yüzden \"aşk "
                    "anlatılıyorsa gazeldir\" gibi bir kestirme yol yanıltır. Yapı "
                    "özellikleri (birim, ölçü, kafiye düzeni) ise biçimden biçime "
                    "değişir ve kesin ayrım sağlar."
                ),
                ipuclari=["Aşk konusu yalnız tek bir biçimde mi yazılır? Koşmayı "
                          "ve gazeli düşün."],
                puan=12,
            ),
        ],
        kapanis="Fişin boş hanesi dolduruldu: {}.".format(nazim["ad"]),
        odul={"itibar": 7},
    )


# ==========================================================================
# KONUŞMA PROVASI: METNİ OKUMAK ETKİLİ KONUŞMANIN TAMAMI DEĞİLDİR (B37.17)
#
# 2026 programının dört tema konuşma satırı (9-12. sınıf, 16 satır) aynı
# yaygın yanlışı paylaşıyor:
#
#   "Metni okumayı etkili konuşmanın tamamı saymak; muhatap ve süreyi
#    gözetmemek."
#
# DÜZENEK: üs forumunda, podcastte ya da kurulda sınırlı süreli bir konuşma.
# Personel yazdığı metnin tamamını okumayı planlıyor. Üssün kuralı olarak
# konuşma hızı dakikada 120 kelime veriliyor; metin süreye sığmıyor. Muhataba
# göre de düzenleme gerekiyor.
#
# YANILGININ SAYISAL KARŞILIĞI: çıkarılacak kelime sayısını 0 saymak.
# ==========================================================================

_KONUSMA_HIZI = 120   # kelime/dakika (üs kuralı)
# (muhatap, uygun düzenleme, ortam)
_KONUSMA_MUHATAPLARI = (
    ("üsse yeni katılan personel",
     "Teknik terimleri kısa açıklamalar ve somut örneklerle vermek",
     "Üs radyosunun podcast kuşağında"),
    ("karar verecek sefer kurulu",
     "Karar için gereken verileri ve gerekçeleri öne çıkarmak",
     "Sefer kurulunda"),
    ("üs okulundaki küçük öğrenciler",
     "Kısa cümleler kurmak ve anlatımı bir olay üzerinden somutlaştırmak",
     "Üs okulunun forum saatinde"),
)


@bulmaca(ders="edebiyat", konu="tema_1_konusma", kademeler=(9, 13), agirlik=1.3)
def konusma_provasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Etkili konuşma: süreye ve muhataba göre içerik seçmek, metni okumakla yetinmemek."""
    kelime = rastgele.choice((720, 840, 960))
    sure = rastgele.choice((3, 4, 5))
    okuma = kelime // _KONUSMA_HIZI
    sigan = sure * _KONUSMA_HIZI
    cikacak = kelime - sigan
    muhatap, uygun, ortam = rastgele.choice(_KONUSMA_MUHATAPLARI)
    diger = [u for m, u, _ in _KONUSMA_MUHATAPLARI if m != muhatap]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-konusma-provasi",
        ders="edebiyat",
        baslik="Konuşma Provası",
        kademe=kademe,
        konu="tema_1_konusma",
        kazanim="Konuşmayı muhataba ve verilen süreye göre planlama; konuşma süresini "
                "hesaplayıp metni kısaltma; yazılı metni okumayı etkili konuşmanın "
                "tamamı saymama.",
        dikkat=6,
        brifing=(
            "{} {} dakikalık bir konuşma yapılacak; dinleyiciler {}.\n\n"
            "{} {} kelimelik metnini gösterdi: \"Hazırım. Yazdığımı baştan sona "
            "okuyacağım; iyi bir metni okumak iyi bir konuşmadır. Kim dinlerse "
            "dinlesin, aynı metin.\"\n\n"
            "Konuşmadan önce provayı süre ve muhatap açısından yapmamız gerekiyor."
        ).format(ortam, sure, muhatap, kisi, kelime),
        kanitlar=[
            Kanit("Konuşma kuralı",
                  "Üs konuşmalarında anlaşılır hız dakikada {} kelimedir. Ayrılan süre "
                  "{} dakika.".format(_KONUSMA_HIZI, sure),
                  bedel=1, kritik=True),
            Kanit("Metin bilgisi", "Hazırlanan metin {} kelime.".format(kelime), bedel=1, kritik=True),
            Kanit("Dinleyici notu", "Dinleyiciler: {}.".format(muhatap), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Etkili konuşma için hangisi doğrudur?",
                dogru="Metni okumak yetmez; içerik muhataba ve süreye göre seçilip prova edilir",
                yanlislar={
                    "Yazılı metni baştan sona okumak etkili konuşmanın tamamıdır":
                        "Metni okumayı etkili konuşmanın tamamı saydın; süre ve muhatap "
                        "gözetilmeli.",
                    "Süre önemli değildir; söylenecek her şey söylenmeli":
                        "Muhatap ve süreyi gözetmedin; süreyi aşan konuşma dinleyiciyi kaybeder.",
                    "Her dinleyiciye aynı dille konuşulur; doğru bilgi herkese aynı biçimde ulaşır":
                        "Muhatabı gözetmedin; yeni gelen personelle kurul aynı dili beklemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Konuşma, dinleyene ulaşmak içindir. Süre, ne kadar içeriğin "
                    "anlatılabileceğini; muhatap, hangi dilin ve örneğin seçileceğini "
                    "belirler. Metin bir hazırlıktır, konuşmanın kendisi değildir."
                ),
                ipuclari=[
                    "Metin ayrılan süreye sığıyor mu?",
                    "Dinleyiciler kim?",
                ],
                cozum="Süre = kelime ÷ {}; sığan kelime = dakika × {}".format(_KONUSMA_HIZI, _KONUSMA_HIZI),
            ),
            sayi_adimi(
                soru="Metnin tamamını okumak kaç dakika sürer?",
                cevap=okuma,
                birim="dk",
                aciklama="{} ÷ {} = {} dakika; ayrılan süre {} dakika.".format(
                    kelime, _KONUSMA_HIZI, okuma, sure),
                ipuclari=["Kelime sayısını dakikadaki kelime sayısına böl."],
                puan=8,
            ),
            sayi_adimi(
                soru="Süreye sığmak için metinden en az kaç kelime çıkarılmalı?",
                cevap=cikacak,
                birim="kelime",
                aciklama="Sığan: {} × {} = {} kelime; çıkarılacak: {} − {} = {}.".format(
                    sure, _KONUSMA_HIZI, sigan, kelime, sigan, cikacak),
                yaygin_yanlislar={
                    0:
                        "Metni okumayı etkili konuşmanın tamamı saydın; metin süreye sığmıyor.",
                },
                ipuclari=["Önce süreye sığan kelime sayısını bul."],
                puan=12,
            ),
            secim_adimi(
                soru="Dinleyiciler {}. Hangi düzenleme en uygundur?".format(muhatap),
                dogru=uygun,
                yanlislar={
                    diger[0]: "Bu düzenleme başka bir dinleyici grubuna daha uygun; muhatabı gözet.",
                    diger[1]: "Bu düzenleme başka bir dinleyici grubuna daha uygun; muhatabı gözet.",
                    "Hiçbir düzenleme gerekmez; metin herkese aynı okunur":
                        "Muhatap ve süreyi gözetmedin.",
                },
                rastgele=rastgele,
                aciklama="Dinleyiciler {}: {}.".format(muhatap, uygun.lower()),
                ipuclari=["Bu dinleyiciler neyi bilir, neye ihtiyaç duyar?"],
                puan=10,
            ),
            yorum_adimi(
                soru="Prova için hangisi doğrudur?",
                dogru="Süre tutarak prova edip metni kısaltmak, not kartlarıyla konuşmak",
                yanlislar={
                    "Kâğıttan okumak yeterlidir; iyi yazılmış metin prova istemez":
                        "Metni okumayı etkili konuşmanın tamamı saydın.",
                    "Süreye sığmak için daha hızlı okumak, böylece hiçbir bilgi atılmaz":
                        "Hız dakikada {} kelimeyi aşarsa anlaşılırlık düşer; kısaltmak "
                        "gerekir.".format(_KONUSMA_HIZI),
                },
                rastgele=rastgele,
                aciklama="Prova süreyi ölçer; not kartları metne bağlı kalmadan konuşmayı sağlar.",
                ipuclari=["Hızlı okumak mı, kısaltmak mı?"],
                puan=10,
            ),
        ],
        kapanis=("Prova düzeltildi: {} kelimelik metin {} dakika sürüyordu; {} kelime "
                 "çıkarıldı ve konuşma {} için yeniden düzenlendi.").format(
                     kelime, okuma, cikacak, muhatap),
        odul={"itibar": 4, "cevher": 1, "enerji": 1},
    )


# ==========================================================================
# DİNLEME ÖZETİ: KENDİ BİLGİNİ KONUŞMACININ SÖZÜ GİBİ AKTARMA (B37.17)
#
# 2026 programının dört tema dinleme satırı (9-12. sınıf, 16 satır) aynı
# yaygın yanlışı paylaşıyor:
#
#   "Dinlenen içeriğe kendi bilgisini ekleyip bunu konuşmacının sözü gibi
#    aktarmak."
#
# DÜZENEK: bir kaydın (rota belgeseli, arşiv podcasti, kurul toplantısı)
# dökümü ve personelin özeti. Özetteki her cümle "konuşmacı söyledi" diye
# başlıyor; ama bir kısmı kayıtta yok, personelin kendi bilgisi ya da yorumu.
#
# YANILGININ SAYISAL KARŞILIĞI: eklenen bilgi sayısını 0 saymak.
# ==========================================================================

_DINLEME_KAYITLARI = (
    {
        "ad": "rota belgeseli",
        "konusmaci": "belgeselin anlatıcısı",
        "soylenen": (
            "Kervan yolu vadiyi iki gün boyunca izliyor.",
            "Geçitte rüzgâr öğleden sonra sertleşiyor.",
            "Yol boyunca üç kuyu var; ikisi yazın kuruyor.",
            "Köylüler kışın bu yolu kullanmıyor.",
        ),
        "eklenen": (
            "Kervansaraylar bir günlük yol arayla yapılırdı.",
            "Bu yol eskiden İpek Yolu'nun bir koluydu.",
            "Kuyuların suyu içmeye uygun değil.",
        ),
    },
    {
        "ad": "arşiv podcasti",
        "konusmaci": "podcastin konuğu",
        "soylenen": (
            "Şair ilk şiirlerini sefer günlüğüne yazdı.",
            "Şairin kitabı yalnız üç yüz adet basıldı.",
            "Şiirlerinde en çok deniz imgesini kullandı.",
            "Son yıllarını bir kıyı kasabasında geçirdi.",
        ),
        "eklenen": (
            "Şair döneminin en önemli şairiydi.",
            "Kitabı bir süre yasaklandı.",
            "Deniz imgesi özgürlüğü simgeler.",
        ),
    },
    {
        "ad": "kurul toplantısı kaydı",
        "konusmaci": "arıtma sorumlusu",
        "soylenen": (
            "Atık su arıtma denemesi dört hafta sürdü.",
            "Suyun bulanıklığı yarıya indi.",
            "Filtre haftada bir temizlendi.",
            "Deneme kış gelmeden bitirilecek.",
        ),
        "eklenen": (
            "Arıtılmış su artık içmeye uygun.",
            "Aynı yöntem başka üslerde de başarılı oldu.",
            "Filtre çok pahalı.",
        ),
    },
)


@bulmaca(ders="edebiyat", konu="tema_1_dinleme", kademeler=(9, 13), agirlik=1.3)
def dinleme_ozeti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Dinlediğini aktarırken konuşmacının sözünü kendi bilginden ayırmak."""
    k = rastgele.choice(_DINLEME_KAYITLARI)
    kac_ek = rastgele.choice((1, 2))
    ozet_cumleleri = ([(c, True) for c in rastgele.sample(k["soylenen"], 4 - kac_ek)]
                      + [(c, False) for c in rastgele.sample(k["eklenen"], kac_ek)])
    rastgele.shuffle(ozet_cumleleri)
    secenekler = ["Konuşmacı: \"{}\"".format(c) for c, _ in ozet_cumleleri]
    soylenen_ind = [n for n, (_, s) in enumerate(ozet_cumleleri) if s]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-dinleme-ozeti",
        ders="edebiyat",
        baslik="Dinleme Özeti",
        kademe=kademe,
        konu="tema_1_dinleme",
        kazanim="Dinlenen bir metni kayda sadık kalarak özetleme; konuşmacının sözü ile "
                "dinleyicinin kendi bilgisini ve yorumunu ayırt etme; eklemeyi kaynağını "
                "belirterek yazma.",
        dikkat=6,
        # B46.3 (pilot dersi edebiyat): giriş alçaltıldı. Brifing kısaldı, ilk
        # ipucu arkadaşın sözünü aktarma benzetmesi. Şıklar ve doğru cevaplar
        # aynı (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "{} {} için özet yazdı: \"Bildiklerimi de konuşmacının ağzından "
            "ekledim, özet daha dolu oldu.\"\n\nÖzeti kayıtla karşılaştıralım."
        ).format(kisi, k["ad"]),
        kanitlar=[
            Kanit("Kayıt dökümü", "\n".join(k["soylenen"]), bedel=1, kritik=True),
            Kanit("Personelin özeti", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Arşiv kuralı",
                  "Özette konuşmacının sözü ile özeti yazanın eklemesi ayrı gösterilir; "
                  "ekleme varsa kaynağıyla birlikte \"ekleyen\" adıyla yazılır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Dinlediğini aktarmanın doğru yolu hangisidir?",
                dogru="Konuşmacının sözünü, kendi bilgi ve yorumundan ayırarak aktarmak",
                yanlislar={
                    "Kendi bildiklerini de konuşmacı söylemiş gibi eklemek; özet böylece daha eksiksiz olur":
                        "Dinlenen içeriğe kendi bilgini ekleyip konuşmacının sözü gibi "
                        "aktardın.",
                    "Hiçbir şey eklememek; ayrı gösterilse bile her yorum konuşmayı çarpıtır":
                        "Yorum ve ekleme yapılabilir; yeter ki konuşmacının sözünden ayrı "
                        "gösterilsin.",
                    "Konuşmacının cümlelerini daha etkili olsun diye değiştirmek":
                        "Aktarım konuşmacının söylediğine sadık kalmalı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Özet, dinleyene kaydın ne söylediğini güvenle bildirir. Eklenen "
                    "bilgi doğru bile olsa konuşmacının ağzından yazılırsa, konuşmacıya "
                    "söylemediği bir söz yüklenmiş olur."
                ),
                ipuclari=[
                    "Bir arkadaşının sözünü başkasına aktarırken kendi fikrini onun "
                    "sözüymüş gibi katarsan, ona söylemediği bir şeyi söyletmiş olursun.",
                    "Özetteki her cümle kayıt dökümünde var mı?",
                    "Arşiv kuralı eklemeler için ne diyor?",
                ],
                cozum="Özet cümlesi dökümde varsa: konuşmacının sözü. Yoksa: ekleme.",
            ),
            coklu_adimi(
                soru="Özetteki cümlelerden hangilerini konuşmacı gerçekten söyledi? "
                     "(numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=soylenen_ind,
                aciklama="Yalnız kayıt dökümünde geçen cümleler konuşmacıya aittir.",
                ipuclari=["Her özet cümlesini dökümle karşılaştır."],
                puan=12,
            ),
            sayi_adimi(
                soru="Özette konuşmacıya ait gösterilen ama kayıtta olmayan kaç bilgi var?",
                cevap=kac_ek,
                aciklama="Kayıtta olmayan: {}".format(
                    " / ".join(c for c, s in ozet_cumleleri if not s)),
                yaygin_yanlislar={
                    0:
                        "Dinlenen içeriğe kendi bilgini ekleyip konuşmacının sözü gibi "
                        "aktardın; özetin bir kısmı dökümde yok.",
                },
                ipuclari=["Dökümde bulamadığın özet cümlelerini say."],
                puan=10,
            ),
            secim_adimi(
                soru="Eklenen bilgi özette nasıl yazılmalı?",
                dogru="Konuşmacının sözünden ayrı; ekleyenin adıyla ve kaynağıyla",
                yanlislar={
                    "Konuşmacı söylemiş gibi; konu aynıysa kimin söylediği fark etmez":
                        "Dinlenen içeriğe kendi bilgini ekleyip konuşmacının sözü gibi "
                        "aktardın.",
                    "Hiç yazılmamalı; dinleyicinin bilgisi özete bir şey katmaz":
                        "Ekleme değerli olabilir; yalnız ayrı gösterilmeli.",
                },
                rastgele=rastgele,
                aciklama="Arşiv kuralına göre ekleme \"ekleyen\" adıyla ve kaynağıyla ayrıca yazılır.",
                ipuclari=["Arşiv kuralını oku."],
                puan=10,
            ),
        ],
        kapanis=("Özet düzeltildi: konuşmacıya yüklenen {} ekleme ayrı bir \"ekleyen notu\" "
                 "bölümüne taşındı.").format(kac_ek),
        odul={"itibar": 4, "cevher": 1, "enerji": 1},
    )


# ==========================================================================
# TÜR DÖNÜŞÜMÜ: BİÇİM DEĞİŞİR, ANLAM KORUNUR (B37.17)
#
# 2026 programının dört tema yazma satırı (9-12. sınıf, 16 satır) aynı yaygın
# yanlışı paylaşıyor:
#
#   "Tür dönüşümünde anlamı bozmak; taslağı gözden geçirmeden tamamlanmış
#    saymak."
#
# DÜZENEK: bir kaynak metin (sefer günlüğü, rota belgeseli, arşiv öyküsü) yeni
# bir türe (üs duyurusu, bilgi görseli, sahne afişi) dönüştürülmüş. Taslakta
# bir iki olgu bozulmuş (sayı, neden, zaman, kişi); personel gözden geçirmeden
# "bitti" diyor.
#
# YANILGININ SAYISAL KARŞILIĞI: bozulan bilgi sayısını 0 saymak.
# ==========================================================================

_TUR_DONUSUMLERI = (
    {
        "kaynak_tur": "sefer günlüğü", "hedef_tur": "üs duyurusu",
        "kaynak": ("12 Mart. Kuzey deposunda 40 çuval un saydık. Nem yüzünden 6 çuval "
                   "bozulmuş. Dağıtımı cuma günü yapacağız; herkes kendi kabını getirmeli."),
        # (doğru hedef ifadesi, bozuk hedef ifadesi)
        "olgular": (
            ("Depoda 40 çuval un var.", "Depoda 60 çuval un var."),
            ("Nem yüzünden 6 çuval bozuldu.", "Fareler yüzünden 6 çuval bozuldu."),
            ("Dağıtım cuma günü.", "Dağıtım pazartesi günü."),
            ("Kabınızı getirin.", "Kaplar depoda verilecek."),
        ),
        "mesru": "Günlükteki uzun cümleleri duyuruda kısa maddelere çevirmek",
    },
    {
        "kaynak_tur": "rota belgeseli", "hedef_tur": "bilgi görseli",
        "kaynak": ("Rota üç günde 120 kilometre sürüyor. En yüksek geçit 2400 metrede. Yol "
                   "boyunca iki su kaynağı var ve geçit kışın kapanıyor."),
        "olgular": (
            ("Süre: 3 gün, 120 km.", "Süre: 3 gün, 210 km."),
            ("En yüksek geçit: 2400 m.", "En yüksek geçit: 4200 m."),
            ("Su kaynağı: 2.", "Su kaynağı: yok."),
            ("Geçit kışın kapalı.", "Geçit yazın kapalı."),
        ),
        "mesru": "Anlatıcının uzun cümlelerini simgeli kısa etiketlere dönüştürmek",
    },
    {
        "kaynak_tur": "arşiv öyküsü", "hedef_tur": "sahne afişi",
        "kaynak": ("Fırtınalı bir gecede nöbetçi Elif bozulan telsizi onardı. Kafile, "
                   "Elif'in verdiği işaretle kaybolduğu yolu buldu ve sabaha karşı üsse döndü."),
        "olgular": (
            ("Fırtınalı bir gece...", "Güneşli bir öğle vakti..."),
            ("Telsizi onaran: nöbetçi Elif", "Telsizi onaran: kafile başı"),
            ("Kafile yolunu buluyor.", "Kafile yolunu kaybediyor ve dönemiyor."),
            ("Sabaha karşı dönüş", "Akşamüstü dönüş"),
        ),
        "mesru": "Olayı afişte tek bir çarpıcı sahne ve kısa bir sloganla anlatmak",
    },
)


@bulmaca(ders="edebiyat", konu="tema_1_yazma", kademeler=(9, 13), agirlik=1.3)
def tur_donusumu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tür dönüşümünde biçim değişir, olgular korunur; taslak kaynakla gözden geçirilir."""
    d = rastgele.choice(_TUR_DONUSUMLERI)
    kac_bozuk = rastgele.choice((1, 2))
    bozuk_sira = set(rastgele.sample(range(len(d["olgular"])), kac_bozuk))
    taslak = [o[1] if n in bozuk_sira else o[0] for n, o in enumerate(d["olgular"])]
    bozuk_ind = sorted(bozuk_sira)
    adimlar_sirasi = [
        "Kaynaktaki olguları tek tek listelemek",
        "Taslağı bu listeyle satır satır karşılaştırmak",
        "Bozulan bilgileri düzeltmek",
        "Yeni türün biçim ve dil kurallarını denetleyip yayımlamak",
    ]
    karisik = list(adimlar_sirasi)
    rastgele.shuffle(karisik)
    dogru_sira = [karisik.index(a) for a in adimlar_sirasi]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-tur-donusumu",
        ders="edebiyat",
        baslik="Tür Dönüşümü",
        kademe=kademe,
        konu="tema_1_yazma",
        kazanim="Bir metni başka bir türe dönüştürürken biçimi ve dili yeni türe "
                "uyarlayıp olguları ve anlamı koruma; taslağı kaynakla karşılaştırarak "
                "gözden geçirme.",
        dikkat=6,
        brifing=(
            "Bir {} {} olarak yeniden yazıldı.\n\n"
            "{} taslağı teslim etti: \"Bitti. Yeni türe göre yazdım, okumama gerek yok; "
            "bir iki ayrıntı değişse de fark etmez.\"\n\n"
            "Taslak yayımlanmadan önce kaynakla karşılaştırmamız gerekiyor."
        ).format(d["kaynak_tur"], d["hedef_tur"], kisi),
        kanitlar=[
            Kanit("Kaynak metin ({})".format(d["kaynak_tur"]), d["kaynak"], bedel=1, kritik=True),
            Kanit("Taslak ({})".format(d["hedef_tur"]), "\n".join(taslak), bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Tür dönüşümünde hangisi doğrudur?",
                dogru="Biçim ve dil yeni türe uyar; olgular korunur, taslak kaynakla sınanır",
                yanlislar={
                    "Yeni türe uysun diye olgular da değiştirilebilir; yeni tür yeni içerik de ister":
                        "Tür dönüşümünde anlamı bozdun; tür değişir, olgu değişmez.",
                    "Taslak yazılınca iş biter; türe uygun yazıldıysa gözden geçirmek gerekmez":
                        "Taslağı gözden geçirmeden tamamlanmış saydın.",
                    "Kaynak metin olduğu gibi kopyalanır; her değişiklik anlamı bozar":
                        "Yeni tür yeni bir biçim ve dil ister; kopyalamak dönüşüm değildir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Günlükten duyuruya, belgeselden görsele geçerken cümleler kısalır, "
                    "düzen değişir; ama sayılar, nedenler, zaman ve kişiler aynı kalır. "
                    "Bunu garanti eden, taslağı kaynakla karşılaştırmaktır."
                ),
                ipuclari=[
                    "Taslaktaki sayılar ve zamanlar kaynaktakilerle aynı mı?",
                    "Personel taslağı okudu mu?",
                ],
                cozum="Her taslak satırını kaynakla eşle; farklı olgu = bozulma.",
            ),
            coklu_adimi(
                soru="Taslaktaki hangi bilgiler kaynağın anlamını bozuyor? "
                     "(numaraları virgülle yaz)",
                secenekler=taslak,
                dogru_indeksler=bozuk_ind,
                aciklama="Kaynakla çelişen satırlar anlamı bozar; kısaltılmış ama doğru satırlar bozmaz.",
                ipuclari=["Her satırı kaynak metinde ara."],
                puan=12,
            ),
            sayi_adimi(
                soru="Taslakta kaç bilgi bozulmuş?",
                cevap=kac_bozuk,
                aciklama="Bozulan: {}".format(" / ".join(taslak[n] for n in bozuk_ind)),
                yaygin_yanlislar={
                    0:
                        "Taslağı gözden geçirmeden tamamlanmış saydın; kaynakla çelişen "
                        "bilgi var.",
                },
                ipuclari=["Kaynakla çelişen satırları say."],
                puan=10,
            ),
            sirala_adimi(
                soru="Gözden geçirme adımlarını sıraya koy.",
                secenekler=karisik,
                dogru_sira=dogru_sira,
                aciklama="Önce kaynak olgular, sonra karşılaştırma, düzeltme ve en son biçim denetimi.",
                ipuclari=["Neyi karşılaştıracağını bilmeden karşılaştıramazsın."],
                puan=10,
            ),
            secim_adimi(
                soru="Hangisi bu tür dönüşümünde meşru bir değişikliktir?",
                dogru=d["mesru"],
                yanlislar={
                    "Sayıları büyütmek; yeni türde etkileyici görünmek olgudan önemlidir":
                        "Tür dönüşümünde anlamı bozdun; sayılar olgudur.",
                    "Olayın nedenini daha ilgi çekici bir nedenle değiştirmek":
                        "Tür dönüşümünde anlamı bozdun; neden olgudur.",
                    "Zamanı yeni türe daha uygun bir zamanla değiştirmek":
                        "Tür dönüşümünde anlamı bozdun; zaman olgudur.",
                },
                rastgele=rastgele,
                aciklama="Biçim ve dil değişir; sayı, neden, zaman ve kişi değişmez.",
                ipuclari=["Değişiklik bir olguyu mu, yoksa yalnız anlatımı mı etkiliyor?"],
                puan=10,
            ),
        ],
        kapanis=("Taslak düzeltildi: {} bozuk bilgi kaynağa göre onarıldı; {} yayımlandı."
                 ).format(kac_bozuk, d["hedef_tur"]),
        odul={"itibar": 4, "cevher": 1, "enerji": 1},
    )


# ==========================================================================
# ÖZGÜN METİN: ÖRNEĞİ KOPYALAMAK ÜRETİM DEĞİLDİR (B37.17)
#
# 2018 programının "üretim" satırları (9-12. sınıf; hikâye, roman, tiyatro,
# şiir, gezi, anı, haber, mektup, deneme... 23 kod, 34 satır) aynı yaygın
# yanlışı paylaşıyor:
#
#   "Örnek metni kopyalamayı özgün üretim; yazım düzeltmeyi bütün yazma
#    becerisi saymak."
#
# DÜZENEK: arşivde bir örnek metin (öykü, gezi yazısı ya da haber). Personel
# "kendi metnini" yazmış: cümlelerin çoğu örneğin yalnız adları ve yerleri
# değiştirilmiş hâli; yazım ve noktalama ise kusursuz düzeltilmiş.
#
# YANILGILARIN SAYISAL KARŞILIĞI: kopya cümle sayısını 0 saymak; yazım
# denetimini yazma sürecinin tamamı sanmak.
# ==========================================================================

_OZGUN_ORNEKLERI = (
    {
        "tur": "öykü",
        "ornek": (
            "Sabah sisi vadiye çökmüştü; Kerem çadırından çıktığında kampın sessizliğine şaştı.",
            "Ateşin başında kimse yoktu, yalnızca sönmüş közler duman salıyordu.",
            "Kerem telsize koştu ama cihaz hışırtıdan başka ses vermiyordu.",
            "O an uzaktan bir çan sesi duydu ve sesin geldiği yöne yürüdü.",
            "Tepeyi aştığında ekibin kaybolan keçileri toplamak için şafakta yola çıktığını anladı.",
        ),
        "kopya": (
            "Sabah sisi ovaya çökmüştü; Aylin çadırından çıktığında kampın sessizliğine şaştı.",
            "Ocağın başında kimse yoktu, yalnızca sönmüş közler duman salıyordu.",
            "Aylin telsize koştu ama cihaz hışırtıdan başka ses vermiyordu.",
            "O an uzaktan bir düdük sesi duydu ve sesin geldiği yöne yürüdü.",
            "Tepeyi aştığında ekibin kaybolan atları toplamak için şafakta yola çıktığını anladı.",
        ),
        "ozgun": (
            "Bizim kampta sabahları ilk uyanan hep aşçımızdır; o gün de ocağı o yakmıştı.",
            "Ben nöbetten dönerken kar yağmaya başlamıştı ve çizmelerim ıslanmıştı.",
            "Çadırda annemin gönderdiği mektubu üçüncü kez okudum.",
            "Öğleye doğru rüzgâr dindi, gökyüzü birden masmavi oldu.",
            "O akşam herkes aynı şeyi konuştu: yarın geçidi aşabilecek miyiz?",
        ),
    },
    {
        "tur": "gezi yazısı",
        "ornek": (
            "Kasabaya öğle sıcağında vardık; taş evlerin gölgesi sokakları serinletiyordu.",
            "Çarşıda bakırcıların çekiç sesleri birbirine karışıyordu.",
            "Yaşlı bir usta bize kalaylı bir tas gösterip dedesinden kaldığını anlattı.",
            "Akşamüstü tepedeki kaleye çıktık; ovanın bütün tarlaları ayaklarımızın altındaydı.",
            "Dönerken kasabanın sesinin ardımızda yavaş yavaş söndüğünü fark ettik.",
        ),
        "kopya": (
            "Köye öğle sıcağında vardık; taş evlerin gölgesi sokakları serinletiyordu.",
            "Çarşıda demircilerin çekiç sesleri birbirine karışıyordu.",
            "Yaşlı bir usta bize dövme bir bıçak gösterip dedesinden kaldığını anlattı.",
            "Akşamüstü tepedeki kuleye çıktık; ovanın bütün tarlaları ayaklarımızın altındaydı.",
            "Dönerken köyün sesinin ardımızda yavaş yavaş söndüğünü fark ettik.",
        ),
        "ozgun": (
            "Bizim durakta sokaklar geniş ve tozluydu; gölge yalnız çınarın altındaydı.",
            "Pazarda kadınlar tuzlu peynirlerini tahta kasalarda satıyordu.",
            "Bir çocuk bize köyün tek çeşmesini gösterdi; suyu buz gibiydi.",
            "Gece kamyonların motor gürültüsü rüzgârın uğultusuna karıştı.",
            "Sabah ayrılırken yol kenarındaki kuyuların sayısını haritaya işledim.",
        ),
    },
    {
        "tur": "haber",
        "ornek": (
            "Kuzey deposunda dün akşam çıkan yangın, nöbetçilerin müdahalesiyle yarım saatte söndürüldü.",
            "Yangında yaralanan olmadı.",
            "Depo sorumlusu, yangının bir ısıtıcıdan çıktığını açıkladı.",
            "Hasar gören malzemenin listesi bugün çıkarılacak.",
            "Üs yönetimi, ısıtıcıların gece kapatılması kuralını yeniden duyurdu.",
        ),
        "kopya": (
            "Güney deposunda dün akşam çıkan yangın, nöbetçilerin müdahalesiyle yarım saatte söndürüldü.",
            "Yangında yaralanan kimse olmadı.",
            "Depo görevlisi, yangının bir ısıtıcıdan çıktığını açıkladı.",
            "Hasar gören malzemenin listesi yarın çıkarılacak.",
            "Üs yönetimi, ısıtıcıların gece kapatılması kuralını bir kez daha duyurdu.",
        ),
        "ozgun": (
            "Nakliye kafilesi dün iki saat gecikmeyle üsse ulaştı.",
            "Gecikmenin nedeni geçitteki buzlanmaydı.",
            "Kafile başı, zincirli tekerleklerin işe yaradığını söyledi.",
            "Getirilen yakıt deposu dolu olarak teslim edildi.",
            "Bir sonraki kafile için yol durumu sabah yeniden denetlenecek.",
        ),
    },
)
_YAZMA_SURECI = (
    "Amacı ve okuru belirlemek",
    "Kendi gözlem ve deneyimlerinden malzeme toplamak",
    "Plan yapıp taslağı yazmak",
    "Anlamı ve düzeni gözden geçirmek",
    "Yazım ve noktalamayı denetlemek",
)


@bulmaca(ders="edebiyat", konu="hikaye_cozumleme_uretim", kademeler=(9, 13), agirlik=1.3)
def ozgun_metin(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Örnekten yararlanmak ile kopyalamak; yazım denetimi yazma sürecinin son adımıdır."""
    t = rastgele.choice(_OZGUN_ORNEKLERI)
    kac_kopya = rastgele.choice((3, 4))
    kopya_sira = set(rastgele.sample(range(5), kac_kopya))
    taslak = [t["kopya"][n] if n in kopya_sira else t["ozgun"][n] for n in range(5)]
    ozgun_ind = [n for n in range(5) if n not in kopya_sira]
    karisik = list(_YAZMA_SURECI)
    rastgele.shuffle(karisik)
    dogru_sira = [karisik.index(a) for a in _YAZMA_SURECI]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-ozgun-metin",
        ders="edebiyat",
        baslik="Özgün Metin",
        kademe=kademe,
        konu="hikaye_cozumleme_uretim",
        kazanim="Örnek bir metinden yararlanarak kendi amacına, okuruna ve gözlemine "
                "dayalı özgün bir metin üretme; kopyayı özgün üretimden ayırma; yazım "
                "denetimini yazma sürecinin son adımı olarak konumlandırma.",
        dikkat=6,
        # B46.3 (pilot dersi edebiyat): giriş alçaltıldı. Brifing kısaldı;
        # "Düzeltme kaydı" kanıtı ilk ekrandan çıktı, aynı bilgi yalnız onu
        # soran 4. adımda geliyor. İlk ipucu yemek tarifi benzetmesi. Şıklar
        # ve doğru cevaplar aynı (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "Üs dergisine {} {} taslağını getirdi: \"Kendi metnimi yazdım, yazım "
            "hatası da yok.\"\n\nTaslağı arşivdeki örnek metinle karşılaştıralım."
        ).format(kisi, t["tur"]),
        kanitlar=[
            Kanit("Örnek metin", "\n".join(t["ornek"]), bedel=1, kritik=True),
            Kanit("Personelin taslağı", "\n".join(taslak), bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Özgün bir metin üretmek ne demektir?",
                dogru="Örneğin yapısından yararlanıp kendi gözlemiyle yeni içerik kurmak",
                yanlislar={
                    "Örnek metnin adlarını ve yerlerini değiştirip kopyalamak; ad değişince metin yeni olur":
                        "Örnek metni kopyalamayı özgün üretim saydın.",
                    "Yazım hatalarını düzeltmek yazma becerisinin tamamıdır":
                        "Yazım düzeltmeyi bütün yazma becerisi saydın; içerik, plan ve "
                        "özgünlük de gerekir.",
                    "Örnek metinden hiç yararlanmamak; örneğe bakan onu taklit etmiş olur":
                        "Örnek, yapı ve teknik için yol gösterebilir; kopyalanmadıkça "
                        "yararlanmak doğrudur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Örnek metin bir yol haritasıdır: nasıl başlandığını, nasıl "
                    "betimlendiğini gösterir. Özgün metin ise yazanın kendi gözleminden, "
                    "amacından ve okurundan doğar. Kusursuz yazım, iyi bir metnin son "
                    "cilasıdır; metnin kendisi değildir."
                ),
                ipuclari=[
                    "Yemek tarifini düşün: tariften yararlanıp kendi yemeğini yapmak "
                    "başka, başkasının tabağını alıp üstüne kendi adını yazmak başka. "
                    "Örnek metin de bir tariftir.",
                    "Taslaktaki cümleleri örnek metinle yan yana koy.",
                    "Yazım düzeltmesi yazma sürecinin hangi aşaması?",
                ],
                cozum="Kopya = örnek cümle + ad/yer değişikliği. Özgün = örnekte karşılığı olmayan içerik.",
            ),
            sayi_adimi(
                soru="Taslaktaki 5 cümleden kaçı örnek metnin yalnız ad ya da yer "
                     "değiştirilmiş kopyasıdır?",
                cevap=kac_kopya,
                aciklama="{} cümle örnekle aynı; yalnız birkaç sözcüğü değişmiş.".format(kac_kopya),
                yaygin_yanlislar={
                    0:
                        "Örnek metni kopyalamayı özgün üretim saydın; cümlelerin çoğu "
                        "örnekle aynı.",
                },
                ipuclari=["Her taslak cümlesini örnekteki aynı sıradaki cümleyle karşılaştır."],
                puan=12,
            ),
            coklu_adimi(
                soru="Taslaktaki hangi cümleler gerçekten özgündür (örnekte karşılığı yok)? "
                     "(numaraları virgülle yaz)",
                secenekler=taslak,
                dogru_indeksler=ozgun_ind,
                aciklama="Özgün cümleler yazanın kendi gözlemini ve deneyimini anlatır.",
                ipuclari=["Örnek metinde benzeri olmayan cümleleri seç."],
                puan=12,
            ),
            secim_adimi(
                soru=("Düzeltme kaydına göre taslakta yazım hatası kalmadı, noktalama "
                      "da düzeltildi. Bu, metnin hazır olduğunu gösterir mi?"),
                dogru="Hayır; önce içeriğin özgünlüğü, plan ve anlam denetlenmeli",
                yanlislar={
                    "Evet; yazım hatası yoksa metin tamamdır":
                        "Yazım düzeltmeyi bütün yazma becerisi saydın.",
                    "Evet; örnek metne benzemesi metni güvenli kılar, örnek zaten onaylanmış bir metindir":
                        "Örnek metni kopyalamayı özgün üretim saydın.",
                },
                rastgele=rastgele,
                aciklama="Kusursuz yazılmış bir kopya yine kopyadır.",
                ipuclari=["Yazma sürecinde yazım denetimi kaçıncı adım?"],
                puan=10,
            ),
            sirala_adimi(
                soru="Yazma sürecinin adımlarını sıraya koy.",
                secenekler=karisik,
                dogru_sira=dogru_sira,
                aciklama="Amaç ve okur, malzeme, plan ve taslak, anlamı gözden geçirme, en son yazım denetimi.",
                ipuclari=["Yazım denetimi en sona kalır."],
                puan=10,
            ),
        ],
        kapanis=("Taslak geri verildi: {} kopya cümle, personelin kendi gözlemleriyle "
                 "yeniden yazılacak; yazım denetimi en sona bırakıldı.").format(kac_kopya),
        odul={"itibar": 4, "cevher": 1, "enerji": 1},
    )


# ==========================================================================
# ŞİİRDE AHENK: REDİF UYAK DEĞİLDİR, BİÇİM TÜR DEĞİLDİR (B37.17)
#
# `siir_ahenk_bicim` (2018: 9-12, dört satır). Bağlam: "Sefer arşivindeki
# şiirlerin ses, biçim ve duygu düzenini inceleme". `yaygin_yanlis`:
#
#   "Redifi uyakla, nazım biçimini türle karıştırmak."
#
# DÜZENEK: arşivdeki iki dizenin sonları kök ve eklerine ayrılmış olarak
# veriliyor. Redif: görevi ve anlamı aynı olan eklerin tekrarı; uyak: rediften
# önceki ses benzerliği (tek ses yarım, iki ses tam, üç ve daha çok ses zengin).
# Dizeler arşiv için yazılmış özgün örneklerdir.
#
# YANILGININ SAYISAL KARŞILIĞI: uyağın ses sayısına redifi de katmak.
# ==========================================================================

# (dize 1, dize 2, kök 1, kök 2, redif, uyak, uyak türü)
_AHENK_DIZELERI = (
    ("Kervanlar yürür yollarda", "Rüzgâr uğuldar dallarda", "yol", "dal", "larda", "l", "yarım"),
    ("Güneş vurur taşlarına", "Ay konmuş kaşlarına", "taş", "kaş", "larına", "aş", "tam"),
    ("Ocak sönmüş, gönül yanar", "Yaralı yürek de kanar", "yan", "kan", "ar", "an", "tam"),
    ("Haber geldi bahardan", "Su içtik bu pınardan", "bahar", "pınar", "dan", "ar", "tam"),
    ("Gökte yürür bulutlar", "Gönülde yeşerir umutlar", "bulut", "umut", "lar", "ut", "tam"),
    ("Elimde kırık kalemler", "Gönlümde eski elemler", "kalem", "elem", "ler", "lem", "zengin"),
)
# (nazım biçimi, biçimin özelliği, bu biçimde yazılan türler)
_BICIM_TURLERI = (
    ("koşma", "dörtlüklerle ve 11'li hece ölçüsüyle yazılır",
     ("güzelleme", "koçaklama", "taşlama", "ağıt")),
    ("kaside", "beyitlerle ve aruz ölçüsüyle yazılır",
     ("tevhid", "münacat", "naat")),
)


@bulmaca(ders="edebiyat", konu="siir_ahenk_bicim", kademeler=(9, 13), agirlik=1.2)
def siir_ahengi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Redif ile uyağı, nazım biçimi ile türü ayırmak."""
    d1, d2, kok1, kok2, redif, uyak, uyak_turu = rastgele.choice(_AHENK_DIZELERI)
    bicim, ozellik, turler = rastgele.choice(_BICIM_TURLERI)
    tur = rastgele.choice(turler)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    son1 = d1.split()[-1]
    son2 = d2.split()[-1]

    return Bulmaca(
        kod="ede-siir-ahengi",
        ders="edebiyat",
        baslik="Şiir Ahengi",
        kademe=kademe,
        konu="siir_ahenk_bicim",
        kazanim="Dize sonlarında redif ile uyağı ayırma; uyağı ses sayısına göre "
                "adlandırma; nazım biçimi ile konuya göre şiir türünü karıştırmama.",
        dikkat=6,
        # B46.3 (30 Eylül 2026, pilot dersi edebiyat): giriş alçaltıldı. İlk
        # ekranda artık yalnız iki dize, fişteki redif/uyak iddiası ve şarkı
        # sözü benzetmesi var; biçim-tür notu (koşma, kaside, on bir tür adı)
        # yalnız son adımda, o soruyla birlikte gelir. Dize sonları "=" ve
        # "+" yerine sözle ayrıldı. Şıklar ve doğru cevaplar aynı
        # (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "Sefer arşivindeki bir şiirin inceleme fişi dolduruluyor.\n\n"
            "  {}\n  {}\n\n"
            "{} fişe şunu yazdı: \"Dize sonundaki -{}{} seslerinin hepsi uyaktır; "
            "redif yok.\"\n\n"
            "Şarkı sözlerinden tanırız: dize sonları birbirini tutar, kulağa hoş "
            "gelir. Ama sondaki her ortak ses aynı şey değildir. Fiş arşive "
            "girmeden önce bu sesleri doğru ayıralım."
        ).format(d1, d2, kisi, uyak, redif),
        kanitlar=[
            Kanit("Dize sonları",
                  "{}: kök \"{}\", ek \"-{}\"\n{}: kök \"{}\", ek \"-{}\"".format(
                      son1, kok1, redif, son2, kok2, redif),
                  bedel=1, kritik=True),
            Kanit("Ahenk notu",
                  "Redif: dize sonlarında görevi ve anlamı aynı olan ek, sözcük ya da "
                  "sözcük gruplarının tekrarı. Uyak (kafiye): rediften önce gelen ses "
                  "benzerliği. Tek ses yarım, iki ses tam, üç ve daha çok ses zengin uyaktır.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru=("{} ortak seslerin hepsine uyak demiş. Fişi düzeltmek için "
                      "redifi uyaktan neye göre ayırırız?").format(kisi),
                dogru="Redif, anlamı ve görevi aynı ek ya da sözcüktür; uyak ondan önceki ses benzerliğidir",
                yanlislar={
                    "Fark yoktur; dize sonundaki bütün ortak sesler uyaktır":
                        "Redifi uyakla karıştırdın; aynı görevdeki ekler redif sayılır.",
                    "Redif yalnız sözcük, uyak yalnız ek olabilir; tekrar eden sözcüğe redif, eke uyak denir":
                        "Redif ek de olabilir; uyak çoğu zaman sözcüğün kökündedir.",
                    "Uyak dize başındaki ses benzerliğidir; kulak önce dizenin başını duyar":
                        "Uyak ve redif dize sonlarında aranır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Dize sonunu sondan başa doğru çöz: önce görevi aynı olan ekleri "
                    "ayır, bunlar rediftir; geriye kalan kökteki ortak sesler uyaktır."
                ),
                ipuclari=[
                    "Şarkı sözü gibi sondan başa oku: iki dizede aynı görevdeki ek "
                    "tekrar ediyorsa o ayrı sayılır; ses benzerliği ondan önce aranır.",
                    "Dize sonları notunda kök ve ek nasıl ayrılmış?",
                    "-{} eki iki dizede de aynı görevde mi?".format(redif),
                ],
                cozum="{} / {} -> redif: -{}; uyak: {}".format(son1, son2, redif, uyak),
            ),
            secim_adimi(
                soru="Bu dizelerde redif hangisidir?",
                dogru="-{}".format(redif),
                yanlislar={
                    "-{}{}".format(uyak, redif):
                        "Redifi uyakla karıştırdın; kökteki ortak ses uyaktır.",
                    "{}".format(uyak):
                        "Bu uyaktır; redif ondan sonra gelen ortak eklerdir.",
                    "Redif yok":
                        "Redifi uyakla karıştırdın; -{} iki dizede de aynı görevde.".format(redif),
                },
                rastgele=rastgele,
                aciklama="-{} iki dizede de aynı görevdeki eklerdir: redif.".format(redif),
                ipuclari=["Aynı görevdeki ekleri bul."],
                puan=10,
            ),
            sayi_adimi(
                soru="Bu dizelerdeki uyak kaç sesten oluşur?",
                cevap=len(uyak),
                aciklama="{} ile {} köklerinin sonundaki ortak ses(ler): {} ({} ses).".format(
                    kok1, kok2, uyak, len(uyak)),
                yaygin_yanlislar={
                    len(uyak) + len(redif):
                        "Redifi uyakla karıştırdın; -{} redif, uyağa katılmaz.".format(redif),
                },
                ipuclari=["Yalnız köklerin sonundaki ortak sesleri say."],
                puan=12,
            ),
            secim_adimi(
                soru="Bu uyağın türü nedir?",
                dogru="{} uyak".format(uyak_turu[:1].upper() + uyak_turu[1:]),
                yanlislar=[t for t in ("Yarım uyak", "Tam uyak", "Zengin uyak")
                           if t.lower() != "{} uyak".format(uyak_turu)],
                rastgele=rastgele,
                aciklama="{} ses: {} uyak.".format(len(uyak), uyak_turu),
                ipuclari=["Ahenk notunda ses sayısına göre adlar var."],
                puan=8,
            ),
            secim_adimi(
                soru=("Son iş fişin tür satırında. {} şunu da yazmış: \"Türü: {}. {} "
                      "ile {} aynı şeyin iki adıdır.\"\n\nBiçim ve tür notu: nazım "
                      "biçimi şiirin dış yapısıdır (birim, ölçü, uyak düzeni); {} {}. "
                      "Tür ise konuya göre adlandırmadır; {} biçiminde {} gibi türler "
                      "yazılır.\n\n{} ile {} arasındaki ilişki nedir?").format(
                    kisi, bicim, bicim[:1].upper() + bicim[1:], tur,
                    bicim, ozellik, bicim, ", ".join(turler),
                    bicim[:1].upper() + bicim[1:], tur),
                dogru="{} bir nazım biçimidir; {} ise konusuna göre adlandırılan türdür".format(
                    bicim[:1].upper() + bicim[1:], tur),
                yanlislar={
                    "İkisi de türdür; aynı şeyi anlatır":
                        "Nazım biçimini türle karıştırdın; biçim dış yapıdır, tür konudur.",
                    "{} bir türdür; {} ise nazım biçimidir; tür dış yapıyı, biçim konuyu gösterir".format(
                        bicim[:1].upper() + bicim[1:], tur):
                        "Tersine: biçim birim ve ölçüdür, tür konuya göre addır.",
                },
                rastgele=rastgele,
                aciklama="Biçim: {}. Tür: konuya göre ad ({}).".format(ozellik, ", ".join(turler)),
                ipuclari=["Biçim ve tür notunu oku."],
                puan=10,
            ),
        ],
        kapanis=("Fiş düzeltildi: redif -{}, uyak {} ({} uyak); {} nazım biçimi, {} ise "
                 "konusuna göre tür olarak yazıldı.").format(redif, uyak, uyak_turu, bicim, tur),
        odul={"itibar": 4, "cevher": 2},
    )


# ==========================================================================
# ŞİİRDE İMGE VE SÖYLEYİCİ (B37.17)
#
# `siir_anlam_imge` (2018: 9-12, dört satır). Bağlam: "Sefer arşivindeki
# şiirlerin ses, biçim ve duygu düzenini inceleme". `yaygin_yanlis`:
#
#   "İmgeyi yalnız bir söz sanatı adına indirgemek; söyleyiciyi şair sanmak."
#
# DÜZENEK: üs şiir seçkisinden bir şiir (arşiv için yazılmış özgün dizeler).
# Şiirde konuşan bir deniz feneri, bir çınar ya da göçmen bir kuş; şairin
# kendisi başka biri. Personel söyleyiciyi şair sanıyor ve imgeyi yalnız
# sanatın adıyla geçiştiriyor.
# ==========================================================================

_IMGE_SIIRLERI = (
    {
        "soyleyici": "yüz yıllık bir deniz feneri",
        "sair": "üssün 58 yaşındaki arşivcisi Nehir; kentte yaşıyor",
        "dizeler": (
            "Yüz yıldır bu kayanın üstünde nöbetteyim,",
            "Gece boyu tek gözümle karanlığı tararım;",
            "Dalgalar ayaklarıma tuzlu bir türkü söyler,",
            "Sabaha karşı son gemiyi limana ararım.",
        ),
        "imge": "Dalgalar ayaklarıma tuzlu bir türkü söyler",
        "duyular": ("işitme", "tat", "dokunma"),
        "sanat": "kişileştirme",
        "katki": "Denizle kurulan dostluk, fenerin yalnızlığını bir sesle yumuşatır",
    },
    {
        "soyleyici": "dört yüz yaşındaki bir çınar",
        "sair": "üs okulunda okuyan 17 yaşındaki Sarp",
        "dizeler": (
            "Köyün ortasında dört yüz yaşındayım,",
            "Gölgemde çocuklar serin bir masal dinler;",
            "Kışın dallarımda kar, yazın arı uğultusu,",
            "Köklerim toprağın altında eski adları saklar.",
        ),
        "imge": "Gölgemde çocuklar serin bir masal dinler",
        "duyular": ("dokunma", "işitme"),
        "sanat": "duyular arası aktarım",
        "katki": "Kuşakların aynı gölgede buluştuğu huzurlu bir sürekliliği hissettirir",
    },
    {
        "soyleyici": "göç yolundaki bir kuş",
        "sair": "üssün 40 yaşındaki ölçümcüsü Bora; hiç göç etmedi",
        "dizeler": (
            "Kanatlarımda üç ülkenin tozunu taşırım,",
            "Rüzgâr kulağıma yolun adını fısıldar;",
            "Göl kıyısında acı bir su içerim,",
            "Her güz yüreğimde bir pusula uyanır.",
        ),
        "imge": "Kanatlarımda üç ülkenin tozunu taşırım",
        "duyular": ("görme", "dokunma"),
        "sanat": "konuşturma (intak)",
        "katki": "Uzun yolculuğun yorgunluğunu ve sınır tanımayan hayatı gözümüzün önüne getirir",
    },
)
_DUYULAR = ("görme", "işitme", "dokunma", "tat", "koku")


@bulmaca(ders="edebiyat", konu="siir_anlam_imge", kademeler=(9, 13), agirlik=1.2)
def siir_sesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İmge duyulara seslenen bir görüntüdür; şiirde konuşan şairin kendisi olmak zorunda değildir."""
    s = rastgele.choice(_IMGE_SIIRLERI)
    duyu_ind = [n for n, d in enumerate(_DUYULAR) if d in s["duyular"]]
    diger_katki = [x["katki"] for x in _IMGE_SIIRLERI if x is not s]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-siir-sesi",
        ders="edebiyat",
        baslik="Şiirin Sesi",
        kademe=kademe,
        konu="siir_anlam_imge",
        kazanim="Şiirde söyleyici ile şairi ayırt etme; imgenin hangi duyulara "
                "seslendiğini ve şiirin duygu ve anlamına katkısını açıklama; imgeyi "
                "yalnız söz sanatının adına indirgememe.",
        dikkat=6,
        brifing=(
            "Üs şiir seçkisine girecek bir şiirin inceleme fişi dolduruluyor:\n\n"
            "{}\n\n"
            "{} fişe şunu yazdı: \"Şiirde konuşan şairin kendisidir; demek ki şair de "
            "böyle yaşıyor. '{}' dizesindeki imge: {}. Bu kadar.\"\n\n"
            "Fiş seçkiye girmeden önce söyleyiciyi ve imgeyi doğru incelememiz gerekiyor."
        ).format("\n".join("  " + d for d in s["dizeler"]), kisi, s["imge"], s["sanat"]),
        kanitlar=[
            Kanit("Şiir", "\n".join(s["dizeler"]), bedel=1, kritik=True),
            Kanit("Şair bilgisi", "Şiiri yazan: {}.".format(s["sair"]), bedel=1, kritik=True),
            Kanit("İnceleme notu",
                  "Söyleyici, şiirde konuşan sestir; şairle aynı olmak zorunda değildir. "
                  "İmge, okurun zihninde duyulara seslenen bir görüntü uyandırır; hangi "
                  "söz sanatıyla kurulduğu, imgenin yalnız bir yönüdür.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Şiirdeki imge için hangisi doğrudur?",
                dogru="Duyulara seslenen bir görüntüdür; şiirin duygu ve anlamına katkı yapar",
                yanlislar={
                    "İmge bir söz sanatının adıdır; hangi sanat olduğunu bulmak incelemeyi bitirir":
                        "İmgeyi yalnız bir söz sanatı adına indirgedin.",
                    "İmge yalnız görme duyusuna seslenir; adı da görüntüden gelir":
                        "İmge işitme, dokunma, tat ve koku duyularına da seslenebilir.",
                    "İmge şiirin ölçüsü ve uyak düzenidir; şiirin sesini o kurar":
                        "Ölçü ve uyak ahenk ögeleridir; imge anlamla ilgilidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İmge, sözcüklerle kurulan bir duyu deneyimidir: okur onu görür, "
                    "duyar, dokunur. Kişileştirme ya da abartma gibi sanatlar imgeyi "
                    "kurmanın yollarıdır; imgenin kendisi ise şiire duygu ve anlam katar."
                ),
                ipuclari=[
                    "Dizeyi okuyunca zihninde ne canlanıyor?",
                    "İnceleme notu imgeyi nasıl tanımlıyor?",
                ],
                cozum="İmge = duyu + görüntü + şiire katkı; sanatın adı bunlardan yalnız biri.",
            ),
            secim_adimi(
                soru="Bu şiirde konuşan (söyleyici) kimdir?",
                dogru=s["soyleyici"][:1].upper() + s["soyleyici"][1:],
                yanlislar={
                    "Şairin kendisi":
                        "Söyleyiciyi şair sandın; şair bilgisi ile şiirdeki ses farklı.",
                    "Okur; şiir onun ağzından okunur":
                        "Şiirdeki \"ben\" okura değil, şiirdeki sese aittir.",
                },
                rastgele=rastgele,
                aciklama="Şiirdeki \"ben\": {}. Şair: {}.".format(s["soyleyici"], s["sair"]),
                ipuclari=["Dizelerde \"ben\" diye konuşan hangi özelliklere sahip?"],
                puan=10,
            ),
            coklu_adimi(
                soru="\"{}\" imgesi hangi duyulara sesleniyor? (numaraları virgülle yaz)".format(s["imge"]),
                secenekler=list(_DUYULAR),
                dogru_indeksler=duyu_ind,
                aciklama="Bu imge {} duyularına sesleniyor.".format(", ".join(s["duyular"])),
                ipuclari=["Dizede sesi, dokunuşu, tadı ya da görüntüyü anlatan sözcükleri bul."],
                puan=12,
            ),
            secim_adimi(
                soru="Personel imge için fişe yalnız \"{}\" yazdı. Fiş tamam mı?".format(s["sanat"]),
                dogru="Hayır; imgenin seslendiği duyular ve şiire katkısı da yazılmalı",
                yanlislar={
                    "Evet; imgeyi sanatın adı açıklar":
                        "İmgeyi yalnız bir söz sanatı adına indirgedin.",
                    "Evet; imgenin şiire katkısı şairin hayatından anlaşılır, fişe yazılmaz":
                        "Söyleyiciyi şair sandın; katkı şiirin içinden okunur.",
                },
                rastgele=rastgele,
                aciklama="Sanatın adı imgeyi kurma yoludur; imgenin kendisi duyu ve anlamdır.",
                ipuclari=["İnceleme notunun son cümlesini oku."],
                puan=10,
            ),
            yorum_adimi(
                soru="Bu imgenin şiire katkısı nedir?",
                dogru=s["katki"],
                yanlislar={
                    diger_katki[0]: "Bu katkı başka bir şiire ait; dizedeki imgeye bak.",
                    "Hiçbir katkısı yoktur; yalnızca bir {} örneğidir, sanatın adı yeter".format(s["sanat"]):
                        "İmgeyi yalnız bir söz sanatı adına indirgedin.",
                },
                rastgele=rastgele,
                aciklama="İmge söyleyicinin durumunu okura duyularla yaşatır.",
                ipuclari=["İmge söyleyicinin hangi duygusunu görünür kılıyor?"],
                puan=10,
            ),
        ],
        kapanis=("Fiş düzeltildi: söyleyici {}, şair ise başka biri. İmge {} duyularına "
                 "seslenerek şiire anlam katıyor.").format(s["soyleyici"], ", ".join(s["duyular"])),
        odul={"itibar": 4, "cevher": 2},
    )


# ==========================================================================
# KELİME TÜRÜ GÖREVDEN BELİRLENİR (B37.17)
#
# 2018 programının 9. sınıf `sifatlar`, `isimler` ve `zarflar` satırları aynı
# yanılgının üç yüzü:
#
#   sifatlar: "Sıfatı aynı kelimenin zarf veya zamir kullanımından ayıramamak."
#   isimler:  "Bir kelimenin türünü cümledeki görevinden bağımsız belirlemek."
#   zarflar:  "İsmi niteleyen sıfatı zarf saymak."
#
# DÜZENEK: rota raporundan aynı kelimenin geçtiği iki üç cümle. Personel
# kelimenin türünü sözlükten bir kez bakıp bütün cümlelere aynen yazıyor.
#
# YANILGININ SAYISAL KARŞILIĞI: farklı tür sayısını 1 saymak.
# ==========================================================================

# kelime: ((cümle, tür, gerekçe), ...)
_KELIME_GOREVLERI = {
    "güzel": (
        ("Güzel bir sabah başladı.", "sıfat", "\"sabah\" ismini niteliyor"),
        ("Nehir kurulda güzel konuştu.", "zarf", "\"konuştu\" fiilini niteliyor"),
        ("Güzeli çirkinden ayırmak zordur.", "isim", "adlaşmış; bir varlığı karşılıyor, ek alıyor"),
    ),
    "iyi": (
        ("İyi bir telsiz kafileyi kurtarır.", "sıfat", "\"telsiz\" ismini niteliyor"),
        ("Yeni telsiz iyi çalışıyor.", "zarf", "\"çalışıyor\" fiilini niteliyor"),
        ("İyiler her zaman kazanmaz.", "isim", "adlaşmış; çokluk eki almış"),
    ),
    "hızlı": (
        ("Hızlı kafile önde gidiyor.", "sıfat", "\"kafile\" ismini niteliyor"),
        ("Kafile geçitte hızlı ilerledi.", "zarf", "\"ilerledi\" fiilini niteliyor"),
    ),
    "bu": (
        ("Bu kutuyu depoya taşı.", "sıfat", "\"kutu\" ismini gösteriyor"),
        ("Bu, depodaki son kutu.", "zamir", "tek başına kutunun yerini tutuyor"),
    ),
    "yarın": (
        ("Kafile yarın gelecek.", "zarf", "\"gelecek\" fiilinin zamanını bildiriyor"),
        ("Yarının planını bugün yaptık.", "isim", "ek almış; bir zamanı karşılıyor"),
    ),
}
_KELIME_TURLERI = ("isim", "sıfat", "zarf", "zamir")


@bulmaca(ders="edebiyat", konu="sifatlar", kademeler=(9, 12), agirlik=1.2)
def kelime_gorevi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı kelime cümledeki görevine göre isim, sıfat, zarf ya da zamir olabilir."""
    kelime = rastgele.choice(sorted(_KELIME_GOREVLERI))
    kullanimlar = list(_KELIME_GOREVLERI[kelime])
    rastgele.shuffle(kullanimlar)
    cumleler = [c for c, _, _ in kullanimlar]
    farkli = len({t for _, t, _ in kullanimlar})
    sifat_ind = [n for n, (_, t, _) in enumerate(kullanimlar) if t == "sıfat"]
    odak = rastgele.choice([k for k in kullanimlar if k[1] != "sıfat"])
    tanim = {
        "sıfat": "ismi nitelemesi ya da göstermesi",
        "zarf": "fiili, sıfatı ya da zarfı nitelemesi",
        "isim": "adlaşıp bir varlığı karşılaması",
        "zamir": "ismin yerini tutması",
    }
    odak_yanlis = {
        t: ("Kelimenin türünü cümledeki görevinden bağımsız belirledin: sözlükte sıfat "
            "diye geçmesi burada sıfat olduğunu göstermez." if t == "sıfat" else
            "{} olması için {} gerekirdi; burada {}.".format(
                t[:1].replace("i", "İ").upper() + t[1:], tanim[t], odak[2]))
        for t in _KELIME_TURLERI if t != odak[1]
    }
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-kelime-gorevi",
        ders="edebiyat",
        baslik="Kelime Görevi",
        kademe=kademe,
        konu="sifatlar",
        kazanim="Aynı kelimenin cümledeki görevine göre isim, sıfat, zarf ya da zamir "
                "olabileceğini gösterme; sıfatı zarf ve zamir kullanımından ayırma.",
        dikkat=6,
        brifing=(
            "Rota raporundaki sözcükler dil bilgisi etiketiyle arşivlenecek.\n\n"
            "{} \"{}\" kelimesini sözlükte bir kez aradı ve rapordaki bütün cümlelere aynı "
            "etiketi yapıştırdı: \"Sözlükte ne yazıyorsa türü odur; her cümlede aynıdır.\"\n\n"
            "Etiketler basılmadan önce kelimenin her cümledeki görevine bakmamız gerekiyor."
        ).format(kisi, kelime),
        kanitlar=[
            Kanit("Rapor cümleleri", "\n".join(cumleler), bedel=1, kritik=True),
            Kanit("Dil bilgisi notu",
                  "İsmi niteleyen ya da gösteren kelime sıfattır. Fiili, sıfatı ya da zarfı "
                  "niteleyen kelime zarftır. İsmin yerini tutan kelime zamirdir. Bir "
                  "varlığı ya da kavramı karşılayan, ek alabilen kelime isimdir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir kelimenin türü nasıl belirlenir?",
                dogru="Cümledeki görevine bakılarak: niteleme mi, yerini tutma mı",
                yanlislar={
                    "Sözlükteki türüne bakılarak; bir kelimenin türü hep aynıdır":
                        "Kelimenin türünü cümledeki görevinden bağımsız belirledin.",
                    "Kelimenin cümlenin başında olup olmamasına bakılarak":
                        "Yer değil görev belirler.",
                    "Kelimenin kaç heceli olduğuna bakılarak":
                        "Hece sayısı türü belirlemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Güzel sabah\"ta güzel bir ismi niteler: sıfat. \"Güzel konuştu\"da "
                    "fiili niteler: zarf. \"Güzeli seçtik\"te adlaşır: isim. Kelime aynı, "
                    "görev farklı."
                ),
                ipuclari=[
                    "Kelimeden sonra gelen sözcük isim mi, fiil mi?",
                    "Kelime tek başına bir şeyin yerini mi tutuyor?",
                ],
                cozum="İsmi niteliyor: sıfat | fiili niteliyor: zarf | ismin yerini tutuyor: zamir | adlaşmış: isim",
            ),
            sayi_adimi(
                soru="\"{}\" kelimesi bu {} cümlede kaç farklı türde kullanılmış?".format(
                    kelime, len(cumleler)),
                cevap=farkli,
                aciklama="; ".join("{} -> {} ({})".format(c, t, g) for c, t, g in kullanimlar),
                yaygin_yanlislar={
                    1:
                        "Kelimenin türünü cümledeki görevinden bağımsız belirledin; her "
                        "cümlede görevi farklı.",
                },
                ipuclari=["Her cümlede kelimenin neyi nitelediğine bak."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi cümlelerde \"{}\" sıfat olarak kullanılmıştır? "
                     "(numaraları virgülle yaz)".format(kelime),
                secenekler=cumleler,
                dogru_indeksler=sifat_ind,
                aciklama="Sıfat, ismi niteler ya da gösterir.",
                ipuclari=["Kelimeden hemen sonra onun nitelediği bir isim var mı?"],
                puan=10,
            ),
            secim_adimi(
                soru="\"{}\" cümlesinde \"{}\" hangi türdedir?".format(odak[0], kelime),
                dogru=odak[1],
                yanlislar=odak_yanlis,
                rastgele=rastgele,
                aciklama="{}: {}.".format(odak[1][:1].replace("i", "İ").upper() + odak[1][1:], odak[2]),
                ipuclari=["Dil bilgisi notundaki tanımlarla karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("Etiketler düzeltildi: \"{}\" bu cümlelerde {} farklı türde kullanılmış; her "
                 "etiket cümledeki göreve göre yazıldı.").format(kelime, farkli),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# ZAMİRİN GÖNDERİMİ BAĞLAMDAN BULUNUR (B37.17)
#
# `zamirler` tek satırlıktı (2018: 9). Bağlam: "Sefer raporundaki o/onlar
# ifadelerinin kime gönderdiğini bulma". `yaygin_yanlis`:
#
#   "Zamirin gönderdiği kişiyi yanlış belirlemek."
#
# DÜZENEK: sefer raporundan dört cümle; her birinde bir zamir. Gönderilen
# varlık en yakın isim değil, cümlenin anlamından bulunuyor. Personel bütün
# zamirleri raporun baş kişisine bağlıyor.
#
# YANILGININ SAYISAL KARŞILIĞI: farklı gönderim sayısını 1 saymak.
# ==========================================================================

# ((cümle, zamir, gönderdiği, yanlış aday), ...)
_ZAMIR_RAPORLARI = (
    (
        ("Aylin, Mert'e un çuvallarının sayısını sordu; o da kırk diye yanıtladı.",
         "o", "Mert", "Aylin"),
        ("Mert çuvalları saydı ve onları depoya dizdi.", "onları", "çuvallar", "Mert"),
        ("Aylin telsizle Kerem'i aradı; ona kafilenin gecikeceğini söyledi.",
         "ona", "Kerem", "Aylin"),
        ("Kerem bu habere üzüldü, çünkü kendisi kafileyi bekliyordu.",
         "kendisi", "Kerem", "kafile"),
    ),
    (
        ("Elif haritayı Sarp'a uzattı; o da haritayı katlayıp çantasına koydu.",
         "o", "Sarp", "Elif"),
        ("Sarp yolda iki çoban gördü ve onlara geçidi sordu.", "onlara", "çobanlar", "Sarp"),
        ("Çobanlardan biri geçidin açık olduğunu söyledi; ama kendisi oraya hiç gitmemişti.",
         "kendisi", "çobanlardan biri", "geçit"),
        ("Elif akşam Sarp'ı dinledi ve onun bulduğu yolu haritaya işledi.",
         "onun", "Sarp", "Elif"),
    ),
    (
        ("Usta çırağa çekici uzattı; o da çiviyi tek vuruşta çaktı.", "o", "çırak", "usta"),
        ("Çırak tahtaları taşıdı ve onları tezgâha dizdi.", "onları", "tahtalar", "çırak"),
        ("Usta akşam çırağı yanına çağırdı ve ona yeni bir görev verdi.",
         "ona", "çırak", "usta"),
        ("Çırak buna sevindi, çünkü kendisi uzun zamandır bu görevi bekliyordu.",
         "kendisi", "çırak", "görev"),
    ),
)


@bulmaca(ders="edebiyat", konu="zamirler", kademeler=(9, 12), agirlik=1.1)
def zamir_izleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Zamirin gönderdiği varlık en yakın isimden değil, cümlenin anlamından bulunur."""
    rapor = rastgele.choice(_ZAMIR_RAPORLARI)
    farkli = len({g for _, _, g, _ in rapor})
    bas_kisi = rapor[0][0].split(",")[0].split()[0]
    odak = rastgele.choice(rapor)
    hedef = rastgele.choice(sorted({g for _, _, g, _ in rapor}))
    hedefe = [n for n, r in enumerate(rapor) if r[2] == hedef]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-zamir-izleri",
        ders="edebiyat",
        baslik="Zamir İzleri",
        kademe=kademe,
        konu="zamirler",
        kazanim="Metindeki kişi zamirlerinin ve dönüşlülük zamirinin gönderdiği varlığı "
                "bağlamdan belirleme; en yakın ismi otomatik olarak gönderilen saymama.",
        dikkat=6,
        brifing=(
            "Sefer raporunun özeti çıkarılacak; zamirlerin yerine adlar yazılacak.\n\n"
            "{} bütün zamirlerin yerine aynı adı yazdı: \"Raporun baş kişisi {}; o, onlar, "
            "kendisi... hepsi ona gider.\"\n\n"
            "Özet yazılmadan önce her zamirin kime gönderdiğini bulmamız gerekiyor."
        ).format(kisi, bas_kisi),
        kanitlar=[
            Kanit("Rapor", "\n".join(c for c, _, _, _ in rapor), bedel=1, kritik=True),
            Kanit("Dil bilgisi notu",
                  "Zamir, bir ismin yerini tutar. Hangi ismin yerini tuttuğu cümlenin "
                  "anlamından anlaşılır: kim ne yapıyor, kime ne söyleniyor? En yakın isim "
                  "her zaman gönderilen varlık değildir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir zamirin gönderdiği varlık nasıl bulunur?",
                dogru="Cümlenin anlamına bakılarak: kimin ne yaptığı ve kime ne söylendiği",
                yanlislar={
                    "Zamir her zaman metnin baş kişisine gönderir; metin onun hakkında yazılmıştır":
                        "Zamirin gönderdiği kişiyi yanlış belirledin; her zamir aynı "
                        "kişiye gitmez.",
                    "Zamir her zaman kendisinden önceki en yakın isme gönderir":
                        "Zamirin gönderdiği kişiyi yanlış belirledin; yakınlık değil anlam "
                        "belirler.",
                    "Zamirin gönderimi bulunamaz; tahmin edilir":
                        "Bağlam gönderimi açıkça gösterir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Aylin, Mert'e sordu; o da yanıtladı\" cümlesinde yanıtlayan, soru "
                    "sorulan kişidir: o = Mert. Anlam kurulmadan zamir çözülemez."
                ),
                ipuclari=[
                    "Zamirin olduğu yan cümlede eylemi kim yapıyor?",
                    "Soru soran mı yanıtlar, sorulan mı?",
                ],
                cozum="Her zamir için: eylemi kim yapıyor / kime yöneliyor? -> gönderilen isim",
            ),
            sayi_adimi(
                soru="Rapordaki dört zamir kaç farklı varlığa gönderiyor?",
                cevap=farkli,
                aciklama="; ".join("{} = {}".format(z, g) for _, z, g, _ in rapor),
                yaygin_yanlislar={
                    1:
                        "Zamirin gönderdiği kişiyi yanlış belirledin; bütün zamirler baş "
                        "kişiye gitmiyor.",
                },
                ipuclari=["Her zamiri çöz, sonra farklı olanları say."],
                puan=12,
            ),
            secim_adimi(
                soru="\"{}\" cümlesinde \"{}\" kime ya da neye gönderiyor?".format(odak[0], odak[1]),
                dogru=odak[2],
                yanlislar={
                    odak[3]:
                        "Zamirin gönderdiği kişiyi yanlış belirledin; cümlenin anlamına bak.",
                    "Okura; rapor okuyana seslenir":
                        "Rapordaki zamirler rapordaki varlıklara gönderir.",
                },
                rastgele=rastgele,
                aciklama="{} = {}.".format(odak[1], odak[2]),
                ipuclari=["Zamirli yan cümledeki eylemi kim yapıyor ya da kime yöneliyor?"],
                puan=10,
            ),
            coklu_adimi(
                soru="Hangi cümlelerdeki zamirin gönderdiği varlık \"{}\"? (numaraları virgülle yaz)".format(hedef),
                secenekler=[c for c, _, _, _ in rapor],
                dogru_indeksler=hedefe,
                aciklama="Gönderdiği varlık \"{}\" olan zamirler: {}.".format(
                    hedef, ", ".join(rapor[n][1] for n in hedefe)),
                ipuclari=["Her cümlenin zamirini tek tek çöz."],
                puan=10,
            ),
        ],
        kapanis=("Özet düzeltildi: dört zamir {} farklı varlığa gönderiyor; her zamirin "
                 "yerine doğru ad yazıldı.").format(farkli),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# CÜMLENİN ÖGELERİ: SÖZCÜK GRUBU TEK ÖGEDİR (B37.17)
#
# `cumlenin_ogeleri` tek satırlıktı (2018: 11). Bağlam: "Nakliye raporunun uzun
# cümlelerinde özne-yüklem ilişkisini çözme". `yaygin_yanlis`:
#
#   "Sözcük grubunu parçalayıp her kelimeyi ayrı öge saymak."
#
# DÜZENEK: nakliye raporundan uzun bir cümle; ögeleri "|" ile ayrılmış çözüm
# arşivde. Personel her kelimeyi ayrı öge sayıyor.
#
# YANILGININ SAYISAL KARŞILIĞI: öge sayısı yerine kelime sayısını yazmak.
# ==========================================================================

# ((sözcük grubu, öge), ...) - sıra cümledeki sıradır
_OGE_CUMLELERI = (
    (("Kafilenin yorgun sürücüleri", "özne"), ("dün gece", "zarf tümleci"),
     ("geçidin eteğindeki eski hana", "dolaylı tümleç"), ("vardılar", "yüklem")),
    (("Depo sorumlusu Aylin", "özne"), ("sabah erkenden", "zarf tümleci"),
     ("un çuvallarının sayısını", "nesne"), ("kurula", "dolaylı tümleç"),
     ("bildirdi", "yüklem")),
    (("Yeni gelen telsizci", "özne"), ("bozuk anteni", "nesne"),
     ("iki saat içinde", "zarf tümleci"), ("onardı", "yüklem")),
    (("Nakliye ekibinin en deneyimli şoförü", "özne"), ("karlı yolda", "dolaylı tümleç"),
     ("kamyonu", "nesne"), ("çok dikkatli", "zarf tümleci"), ("sürdü", "yüklem")),
)
_OGE_ADLARI = ("özne", "yüklem", "nesne", "dolaylı tümleç", "zarf tümleci")


@bulmaca(ders="edebiyat", konu="cumlenin_ogeleri", kademeler=(9, 13), agirlik=1.1)
def cumle_ogeleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sözcük grupları cümlede tek öge olarak görev yapar."""
    gruplar = rastgele.choice(_OGE_CUMLELERI)
    cumle = " ".join(g for g, _ in gruplar) + "."
    kelime_sayisi = len(cumle.rstrip(".").split())
    oge_sayisi = len(gruplar)
    ozne = gruplar[0][0]
    ozne_son = ozne.split()[-1]
    odak = rastgele.choice([g for g in gruplar[1:-1] if len(g[0].split()) > 1] or list(gruplar[1:-1]))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-cumle-ogeleri",
        ders="edebiyat",
        baslik="Cümle Ögeleri",
        kademe=kademe,
        konu="cumlenin_ogeleri",
        kazanim="Uzun cümlelerde sözcük gruplarını tek öge olarak belirleme; özne-yüklem "
                "ilişkisini kurma; öge sayısını kelime sayısından ayırma.",
        dikkat=6,
        brifing=(
            "Nakliye raporundaki bir cümlenin ögeleri çözümlenecek:\n\n  {}\n\n"
            "{} her kelimenin altına bir öge adı yazdı ve şunu söyledi: \"{} kelime var, "
            "demek ki {} öge var. Özne de '{}'.\"\n\n"
            "Çözümleme arşive girmeden önce sözcük gruplarını doğru ayırmamız gerekiyor."
        ).format(cumle, kisi, kelime_sayisi, kelime_sayisi, ozne_son),
        kanitlar=[
            Kanit("Rapor cümlesi", cumle, bedel=1, kritik=True),
            Kanit("Dil bilgisi notu",
                  "Öge, cümlede bir görevi üstlenen kelime ya da sözcük grubudur. Bir "
                  "tamlama ya da sıfat grubu bölünmez; bütünüyle tek öge olur. Önce yüklem "
                  "bulunur; sonra ona sorulan sorularla (kim, neyi, nereye, ne zaman, "
                  "nasıl) öteki ögeler bulunur.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Cümlenin ögeleri için hangisi doğrudur?",
                dogru="Sözcük grubu bütünüyle tek öge olur; ögeler yükleme sorularla bulunur",
                yanlislar={
                    "Her kelime ayrı bir ögedir; öge sayısı kelime sayısına eşittir":
                        "Sözcük grubunu parçalayıp her kelimeyi ayrı öge saydın.",
                    "Öznenin yalnız son kelimesi öznedir; öncekiler ayrı ögedir":
                        "Sözcük grubunu parçaladın; tamlamanın tamamı öznedir.",
                    "Öge sayısı her cümlede aynıdır; her cümlede özne, nesne ve yüklem bulunur":
                        "Cümleler farklı sayıda ögeden oluşabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Kafilenin yorgun sürücüleri\" üç kelimedir ama cümlede tek bir görev "
                    "üstlenir: kim vardı? sorusunun cevabıdır, yani öznedir."
                ),
                ipuclari=[
                    "Önce yüklemi bul, sonra ona \"kim?\" diye sor.",
                    "Cevap tek kelime mi, bir grup mu?",
                ],
                cozum=" | ".join("{} ({})".format(g, o) for g, o in gruplar),
            ),
            sayi_adimi(
                soru="Bu cümle kaç ögeden oluşuyor?",
                cevap=oge_sayisi,
                aciklama=" | ".join("{} ({})".format(g, o) for g, o in gruplar),
                yaygin_yanlislar={
                    kelime_sayisi:
                        "Sözcük grubunu parçalayıp her kelimeyi ayrı öge saydın.",
                },
                ipuclari=["Yükleme sorulan her sorunun cevabı bir ögedir; cevap grup olabilir."],
                puan=12,
            ),
            secim_adimi(
                soru="Cümlenin öznesi hangisidir?",
                dogru=ozne,
                yanlislar={
                    ozne_son:
                        "Sözcük grubunu parçaladın; tamlamanın tamamı öznedir.",
                    "{} {}".format(ozne, gruplar[1][0]):
                        "Özne grubunu aştın; \"{}\" yükleme sorulan başka bir sorunun "
                        "cevabı.".format(gruplar[1][0]),
                    odak[0]:
                        "Bu grup öznenin değil, başka bir ögenin cevabı.",
                },
                rastgele=rastgele,
                aciklama="Yükleme \"kim?\" sorusunun cevabı: {}.".format(ozne),
                ipuclari=["\"{}\" yüklemine \"kim?\" diye sor.".format(gruplar[-1][0])],
                puan=10,
            ),
            secim_adimi(
                soru="\"{}\" sözcük grubu cümlede hangi ögedir?".format(odak[0]),
                dogru=odak[1],
                yanlislar=sorted((o for o in _OGE_ADLARI if o != odak[1]), key=len, reverse=True)[:3],
                rastgele=rastgele,
                aciklama="\"{}\": {}.".format(odak[0], odak[1]),
                ipuclari=["Yükleme neyi, nereye, ne zaman, nasıl diye sor."],
                puan=10,
            ),
        ],
        kapanis=("Çözümleme düzeltildi: {} kelimelik cümle {} ögeden oluşuyor; özne "
                 "\"{}\".").format(kelime_sayisi, oge_sayisi, ozne),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# TAMLAMALAR: KELİME SAYISI DEĞİL İLİŞKİ BELİRLER (B37.17)
#
# `tamlamalar` tek satırlıktı (2018: 10). Bağlam: "Harita yer adları ve
# betimlemelerde tamlama ilişkisini çözme". `yaygin_yanlis`:
#
#   "İsim ve sıfat tamlamasını yalnız kelime sayısına göre ayırmak."
#
# DÜZENEK: harita etiketlerindeki tamlamalar. Personel "iki kelimelik
# tamlamalar sıfat, üç ve daha çok kelimelik tamlamalar isim tamlamasıdır"
# kuralını uyguluyor. Oysa isim tamlaması iki ismin ilgisidir (geçidin eteği,
# kervan yolu, taş köprü); sıfat tamlaması sıfatın ismi nitelemesidir (dik
# geçit, eski kervan yolu).
#
# YANILGININ SAYISAL KARŞILIĞI: isim tamlaması sayısını üç ve daha çok
# kelimelik tamlamaların sayısı sanmak.
# ==========================================================================

# (tamlama, tür, gerekçe)
_TAMLAMA_ISIM_IKI = (
    ("geçidin eteği", "isim", "\"geçidin\" ilgi eki, \"eteği\" iyelik eki almış"),
    ("kervan yolu", "isim", "belirtisiz, tamlayan ek almamış, tamlanan iyelik eki almış"),
    ("taş köprü", "isim", "takısız, köprünün neyden yapıldığını bildiriyor"),
)
_TAMLAMA_SIFAT_IKI = (
    ("dik geçit", "sıfat", "\"dik\" sıfatı \"geçit\" ismini niteliyor"),
    ("üç kuyu", "sıfat", "\"üç\" sayı sıfatı \"kuyu\" ismini belirtiyor"),
    ("sarp kayalık", "sıfat", "\"sarp\" sıfatı \"kayalık\" ismini niteliyor"),
)
_TAMLAMA_SIFAT_UZUN = (
    ("eski kervan yolu", "sıfat", "\"eski\" sıfatı \"kervan yolu\" grubunu niteliyor"),
    ("uzun ve dar vadi", "sıfat", "\"uzun ve dar\" sıfat grubu \"vadi\" ismini niteliyor"),
)


@bulmaca(ders="edebiyat", konu="tamlamalar", kademeler=(9, 13), agirlik=1.1)
def harita_tamlamalari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İsim tamlaması iki ismin ilgisi, sıfat tamlaması sıfatın ismi nitelemesidir."""
    kac_isim = rastgele.choice((2, 3))
    uzun = rastgele.choice(_TAMLAMA_SIFAT_UZUN)
    etiketler = (rastgele.sample(_TAMLAMA_ISIM_IKI, kac_isim) + [uzun]
                 + rastgele.sample(_TAMLAMA_SIFAT_IKI, 4 - kac_isim))
    rastgele.shuffle(etiketler)
    adlar = [e[0] for e in etiketler]
    isim_ind = [n for n, e in enumerate(etiketler) if e[1] == "isim"]
    yanilgi = sum(1 for e in etiketler if len(e[0].split()) >= 3)
    kisa_isim = rastgele.choice([e for e in etiketler if e[1] == "isim"])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-harita-tamlamalari",
        ders="edebiyat",
        baslik="Harita Tamlamaları",
        kademe=kademe,
        konu="tamlamalar",
        kazanim="Harita adları ve betimlemelerdeki tamlamaları isim ve sıfat tamlaması "
                "olarak ayırma; ayrımı kelime sayısına değil tamlayan ile tamlanan "
                "arasındaki ilişkiye dayandırma.",
        dikkat=6,
        # B46.3 (pilot dersi edebiyat): giriş alçaltıldı. Brifing kısaldı, ilk
        # ipucu okul bahçesi benzetmesi. Dil bilgisi notu yerinde kaldı (takısız
        # tamlama bilgisi 1. adımın bir yanlış şıkkını eler). Şıklar ve doğru
        # cevaplar aynı (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "{} bir kural buldu: \"İki kelimelik tamlamalar sıfat, daha "
            "uzunları isim tamlamasıdır.\"\n\nKuralı etiketlerle sınayalım."
        ).format(kisi),
        kanitlar=[
            Kanit("Harita etiketleri", "\n".join(adlar), bedel=1, kritik=True),
            Kanit("Dil bilgisi notu",
                  "İsim tamlaması iki ismin ilgisidir: tamlayan ilgi eki (-ın) alabilir, "
                  "tamlanan iyelik eki (-ı) alır; takısız tamlamada ikisi de ek almaz ve "
                  "tamlayan, tamlananın neyden yapıldığını bildirir (taş köprü). Sıfat "
                  "tamlamasında bir sıfat ya da sıfat grubu ismi niteler veya belirtir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="İsim tamlaması ile sıfat tamlaması nasıl ayrılır?",
                dogru="Tamlayanın türüne ve tamlananla ilişkisine bakılarak",
                yanlislar={
                    "Kelime sayısına bakılarak: iki kelime sıfat, üç kelime isim tamlaması":
                        "İsim ve sıfat tamlamasını yalnız kelime sayısına göre ayırdın.",
                    "İlk kelimenin ek alıp almadığına bakılarak: ek yoksa sıfat tamlamasıdır":
                        "Takısız isim tamlamasında da ek yoktur (taş köprü); belirleyen "
                        "kelimeler arasındaki ilişkidir.",
                    "Tamlamanın haritada nerede yazdığına bakılarak":
                        "Konum dil bilgisi türünü belirlemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Kervan yolu\" iki kelimedir ama iki isim arasında ilgi vardır: isim "
                    "tamlaması. \"Eski kervan yolu\" üç kelimedir ama \"eski\" bir sıfattır "
                    "ve bütün grubu niteler: sıfat tamlaması."
                ),
                ipuclari=[
                    "\"Okulun bahçesi\" ile \"büyük bahçe\"yi düşün: ilkinde bahçe "
                    "okula ait, iki isim arasında ilgi var; ikincisinde \"büyük\" "
                    "bahçenin nasıl olduğunu söylüyor.",
                    "İlk kelime bir isim mi, bir sıfat mı?",
                    "Tamlanan iyelik eki almış mı?",
                ],
                cozum="Tamlayan isim + tamlanan iyelikli (ya da takısız madde adı): isim tamlaması\nSıfat + isim: sıfat tamlaması",
            ),
            coklu_adimi(
                soru="Hangi etiketler isim tamlamasıdır? (numaraları virgülle yaz)",
                secenekler=adlar,
                dogru_indeksler=isim_ind,
                aciklama="; ".join("{}: {} tamlaması ({})".format(a, t, g) for a, t, g in etiketler),
                ipuclari=["Her etiketin ilk kelimesinin türüne bak."],
                puan=12,
            ),
            sayi_adimi(
                soru="Beş etiketten kaç tanesi isim tamlamasıdır?",
                cevap=kac_isim,
                aciklama="İsim tamlaması: {}.".format(", ".join(e[0] for e in etiketler if e[1] == "isim")),
                yaygin_yanlislar={
                    yanilgi:
                        "İsim ve sıfat tamlamasını yalnız kelime sayısına göre ayırdın; "
                        "uzun etiket isim tamlaması olmak zorunda değil.",
                },
                ipuclari=["Kelime saymak yerine ilişkiye bak."],
                puan=12,
            ),
            secim_adimi(
                soru="\"{}\" hangi tamlamadır?".format(uzun[0]),
                dogru="Sıfat tamlaması: {}".format(uzun[2]),
                yanlislar={
                    "İsim tamlaması: üç ve daha çok kelimeden oluşuyor, uzun tamlama isim tamlamasıdır":
                        "İsim ve sıfat tamlamasını yalnız kelime sayısına göre ayırdın.",
                    "Tamlama değildir: tamlama yalnız iki isimle kurulur":
                        "Bir sıfat grubu ismi niteliyor; bu bir tamlamadır.",
                },
                rastgele=rastgele,
                aciklama="{}: sıfat tamlaması; {}.".format(uzun[0], uzun[2]),
                ipuclari=["İlk kelime ne işe yarıyor?"],
                puan=10,
            ),
            secim_adimi(
                soru="\"{}\" hangi tamlamadır?".format(kisa_isim[0]),
                dogru="İsim tamlaması: {}".format(kisa_isim[2]),
                yanlislar={
                    "Sıfat tamlaması: iki kelimeden oluşuyor, kısa tamlamalar sıfat tamlaması sayılır":
                        "İsim ve sıfat tamlamasını yalnız kelime sayısına göre ayırdın.",
                    "Tamlama değildir: iki isim yan yana gelmiş, arada bağ yok":
                        "İki isim arasında ilgi var; bu bir tamlamadır.",
                },
                rastgele=rastgele,
                aciklama="{}: isim tamlaması; {}.".format(kisa_isim[0], kisa_isim[2]),
                ipuclari=["İlk kelime bir sıfat mı, yoksa bir isim mi?"],
                puan=10,
            ),
        ],
        kapanis=("Etiketler düzeltildi: beşten {} tanesi isim tamlaması; ayrım kelime "
                 "sayısına değil ilişkiye göre yapıldı.").format(kac_isim),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# ZAMAN KAYMASI: KİP EKİ İLE GERÇEK ZAMAN HER ZAMAN AYNI DEĞİLDİR (B37.17)
#
# `fiiller_cekim` tek satırlıktı (2018: 9). Bağlam: "Günlük ve tutanakta eylem
# zamanı ile anlatım zamanını karşılaştırma". `yaygin_yanlis`:
#
#   "Kip eki ile anlatılan gerçek zamanı her durumda aynı saymak."
#
# DÜZENEK: sefer günlüğü ve tutanaktan cümleler. Bazılarında kip eki ile
# anlatılan zaman aynı (dün nöbete kaldım), bazılarında kayıyor (kafile yarın
# yola çıkıyor: şimdiki zaman eki, gelecek zaman; 1071'de ... yener: geniş
# zaman eki, geçmiş zaman).
#
# YANILGININ SAYISAL KARŞILIĞI: zaman kayması sayısını 0 saymak.
# ==========================================================================

# (cümle, kip eki, ekin adı, anlatılan gerçek zaman)
_ZAMAN_CUMLELERI_KAYAN = (
    ("Kafile yarın sabah yola çıkıyor.", "-yor", "şimdiki zaman", "gelecek"),
    ("1071'de Alparslan Malazgirt'te Bizans ordusunu yener.", "-er", "geniş zaman", "geçmiş"),
    ("Geçen kış bir gece telsiz bozuluyor, herkes merakla bekliyor.", "-yor",
     "şimdiki zaman", "geçmiş"),
    ("Kafile gelmezse yarın kurulu toplarız.", "-r", "geniş zaman", "gelecek"),
)
_ZAMAN_CUMLELERI_UYAN = (
    ("Depocu şu anda çuvalları sayıyor.", "-yor", "şimdiki zaman", "şimdi"),
    ("Dün akşam nöbete kaldım.", "-dı", "görülen geçmiş zaman", "geçmiş"),
    ("Yarın kurul toplanacak.", "-acak", "gelecek zaman", "gelecek"),
)
_ZAMAN_ADLARI = ("geçmiş", "şimdi", "gelecek")


@bulmaca(ders="edebiyat", konu="fiiller_cekim", kademeler=(9, 12), agirlik=1.1)
def zaman_kaymasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kip eki ile anlatılan zaman çoğu zaman aynıdır ama kayabilir."""
    kac_kayan = rastgele.choice((2, 3))
    cumleler = (rastgele.sample(_ZAMAN_CUMLELERI_KAYAN, kac_kayan)
                + rastgele.sample(_ZAMAN_CUMLELERI_UYAN, 5 - kac_kayan))
    rastgele.shuffle(cumleler)
    metinler = [c[0] for c in cumleler]
    kayan_ind = [n for n, c in enumerate(cumleler) if c in _ZAMAN_CUMLELERI_KAYAN]
    odak = rastgele.choice([c for c in cumleler if c in _ZAMAN_CUMLELERI_KAYAN])
    ek_zamani = {"şimdiki zaman": "şimdi", "geniş zaman": "her zaman"}[odak[2]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-zaman-kaymasi",
        ders="edebiyat",
        baslik="Zaman Kayması",
        kademe=kademe,
        konu="fiiller_cekim",
        kazanim="Fiilin kip ekini belirleme; kip ekinin adı ile cümlede anlatılan "
                "gerçek zamanın farklı olabileceğini (zaman kayması) gösterme.",
        dikkat=6,
        brifing=(
            "Günlük ve tutanaktan seçilen cümleler olay çizelgesine işlenecek.\n\n"
            "{} her cümlenin zamanını fiildeki eke bakarak yazdı: \"-yor varsa şimdi, "
            "-er varsa her zaman. Ek neyse zaman odur.\"\n\n"
            "Çizelge basılmadan önce eylemlerin gerçek zamanını cümlelerden bulmamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Seçilen cümleler", "\n".join(metinler), bedel=1, kritik=True),
            Kanit("Dil bilgisi notu",
                  "Kip ekleri adlarını taşıdıkları zamanı çoğunlukla anlatır. Ama cümledeki "
                  "zaman sözcükleri (yarın, geçen kış, 1071'de) ve anlatım biçimi eylemin "
                  "gerçek zamanını değiştirebilir. Buna zaman kayması denir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Kip eki ile anlatılan zaman için hangisi doğrudur?",
                dogru="Çoğunlukla örtüşür; zaman sözcükleri ve anlatım biçimi bunu değiştirebilir",
                yanlislar={
                    "Her durumda aynıdır; ekin adı neyse zaman odur, ek zamanı taşımak için vardır":
                        "Kip eki ile anlatılan gerçek zamanı her durumda aynı saydın.",
                    "Hiçbir zaman örtüşmez; ek yalnız biçimdir, zamanı bağlam belirler":
                        "\"Dün nöbete kaldım\" gibi cümlelerde ek ile zaman örtüşür.",
                    "Gerçek zaman yalnız öznenin kim olduğuna bakılarak bulunur":
                        "Zamanı özne değil, ek ve zaman sözcükleri birlikte belirler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Kafile yarın yola çıkıyor\" cümlesinde ek şimdiki zamanın ekidir ama "
                    "\"yarın\" eylemi geleceğe taşır. Tarih anlatımında geniş zaman eki "
                    "geçmişteki bir olayı canlı anlatmak için kullanılır."
                ),
                ipuclari=[
                    "Cümlede yarın, dün, geçen kış gibi zaman sözcükleri var mı?",
                    "Eylem gerçekten şu anda mı oluyor?",
                ],
                cozum="Ek -> ekin adı; zaman sözcüğü ve bağlam -> gerçek zaman; farklıysa kayma",
            ),
            coklu_adimi(
                soru="Hangi cümlelerde kip ekinin adı ile anlatılan gerçek zaman farklıdır? "
                     "(numaraları virgülle yaz)",
                secenekler=metinler,
                dogru_indeksler=kayan_ind,
                aciklama="; ".join("{} -> ek: {}, gerçek zaman: {}".format(c[0], c[2], c[3])
                                   for c in cumleler if c in _ZAMAN_CUMLELERI_KAYAN),
                ipuclari=["Her cümlede ekin adını ve zaman sözcüğünü karşılaştır."],
                puan=12,
            ),
            sayi_adimi(
                soru="Beş cümleden kaçında zaman kayması var?",
                cevap=kac_kayan,
                aciklama="{} cümlede ekin adı ile gerçek zaman farklı.".format(kac_kayan),
                yaygin_yanlislar={
                    0:
                        "Kip eki ile anlatılan gerçek zamanı her durumda aynı saydın.",
                },
                ipuclari=["Seçtiğin cümleleri say."],
                puan=10,
            ),
            secim_adimi(
                soru="\"{}\" cümlesindeki eylemin gerçek zamanı nedir?".format(odak[0]),
                dogru=odak[3],
                yanlislar={
                    z: ("Kip eki ile anlatılan gerçek zamanı her durumda aynı saydın; ek {} "
                        "ama cümle başka bir zamanı anlatıyor.".format(odak[2])
                        if z == ek_zamani or (ek_zamani == "her zaman" and z == "şimdi")
                        else "Cümledeki zaman sözcüğüne bak.")
                    for z in _ZAMAN_ADLARI + ("her zaman",) if z != odak[3]
                },
                rastgele=rastgele,
                aciklama="Ek: {} ({}); gerçek zaman: {}.".format(odak[1], odak[2], odak[3]),
                ipuclari=["Cümledeki zaman sözcüğünü bul."],
                puan=10,
            ),
        ],
        kapanis=("Çizelge düzeltildi: beş cümleden {} tanesinde zaman kayması vardı; "
                 "eylemler gerçek zamanlarına göre işlendi.").format(kac_kayan),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# SÖZCÜKTE ANLAM: İLK ANLAM HER BAĞLAMA UYMAZ (B37.17)
#
# `sozcukte_anlam` tek satırlıktı (2018: 12). Bağlam: "Eski sefer notundaki bir
# sözcüğün bağlama uygun anlamını seçme". `yaygin_yanlis`:
#
#   "Sözlükteki ilk anlamı her bağlama uygulamak."
#
# DÜZENEK: çok anlamlı bir sözcüğün (göz, ağır, kol) sözlük maddesi ve eski
# sefer notundan üç cümle. Personel her cümleye maddenin 1. anlamını yazıyor.
#
# YANILGININ SAYISAL KARŞILIĞI: ilk anlamın geçtiği cümle sayısını bütün
# cümleler saymak.
# ==========================================================================

_SOZLUK_MADDELERI = {
    "göz": {
        "anlamlar": ("Görme organı", "Dolap, çekmece gibi eşyada bölme",
                     "İğne gibi şeylerde delik"),
        "cumleler": (
            ("Tozdan nöbetçinin gözü yaşardı.", 1),
            ("Güneş gözlerini kamaştırdı.", 1),
            ("Telsizi dolabın üst gözüne koydu.", 2),
            ("İpliği iğnenin gözünden zorla geçirdi.", 3),
        ),
    },
    "ağır": {
        "anlamlar": ("Tartıda çok gelen", "Yavaş", "Durumu ciddi, tehlikeli"),
        "cumleler": (
            ("Un çuvalları sandığımızdan ağırdı.", 1),
            ("Ağır sandığı dört kişi taşıdı.", 1),
            ("Kafile karlı yolda ağır ağır ilerledi.", 2),
            ("Telsizcinin hastalığı ağırdı; hemen üsse taşındı.", 3),
        ),
    },
    "kol": {
        "anlamlar": ("Omuzdan parmak uçlarına kadar olan organ",
                     "Bir akarsuyun ya da yolun ana gövdeden ayrılan bölümü",
                     "Belli bir iş için ayrılmış küçük ekip"),
        "cumleler": (
            ("Düşünce kolunu incitti.", 1),
            ("Kolundaki saati çıkarıp masaya koydu.", 1),
            ("Nehrin doğu kolu yazın kurur.", 2),
            ("Keşif kolu sabah erkenden geçide çıktı.", 3),
        ),
    },
}


@bulmaca(ders="edebiyat", konu="sozcukte_anlam", kademeler=(10, 13), agirlik=1.1)
def sozluk_maddesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Çok anlamlı sözcüğün anlamı bağlamdan seçilir; ilk anlam her cümleye uymaz."""
    sozcuk = rastgele.choice(sorted(_SOZLUK_MADDELERI))
    madde = _SOZLUK_MADDELERI[sozcuk]
    ilkler = [c for c in madde["cumleler"] if c[1] == 1]
    digerleri = [c for c in madde["cumleler"] if c[1] != 1]
    kac_ilk = rastgele.choice((1, 2))
    secilen = rastgele.sample(ilkler, kac_ilk) + rastgele.sample(digerleri, 3 - kac_ilk)
    rastgele.shuffle(secilen)
    cumleler = [c for c, _ in secilen]
    ilk_degil = [n for n, (_, a) in enumerate(secilen) if a != 1]
    odak = rastgele.choice([c for c in secilen if c[1] != 1])
    anlamlar = madde["anlamlar"]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-sozluk-maddesi",
        ders="edebiyat",
        baslik="Sözlük Maddesi",
        kademe=kademe,
        konu="sozcukte_anlam",
        kazanim="Çok anlamlı bir sözcüğün cümledeki anlamını bağlamdan belirleme; "
                "sözlükteki ilk anlamı her bağlama uygulamama; temel ve yan anlamları ayırma.",
        dikkat=6,
        brifing=(
            "Eski sefer notundaki \"{}\" sözcüğünün anlamları dipnotla açıklanacak.\n\n"
            "{} sözlüğü açtı ve üç cümlenin dipnotuna da maddenin ilk anlamını yazdı: "
            "\"Sözlükte ilk yazan anlam asıl anlamdır; her yerde o geçerlidir.\"\n\n"
            "Dipnotlar basılmadan önce her cümlenin bağlamına bakmamız gerekiyor."
        ).format(sozcuk, kisi),
        kanitlar=[
            Kanit("Sözlük maddesi",
                  "{}: ".format(sozcuk) + " ".join("{}. {}.".format(n + 1, a) for n, a in enumerate(anlamlar)),
                  bedel=1, kritik=True),
            Kanit("Sefer notu", "\n".join(cumleler), bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Çok anlamlı bir sözcüğün cümledeki anlamı nasıl bulunur?",
                dogru="Bağlama bakılarak sözlükteki anlamlardan uygun olan seçilir",
                yanlislar={
                    "Sözlükteki ilk anlam her cümlede geçerlidir; sözlük en doğru anlamı başa yazar":
                        "Sözlükteki ilk anlamı her bağlama uyguladın.",
                    "Sözcüğün en uzun anlamı seçilir":
                        "Anlamın uzunluğu değil, bağlama uyması belirler.",
                    "Çok anlamlı sözcükler cümlede anlamsızdır":
                        "Bağlam hangi anlamın kastedildiğini açıkça gösterir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sözlükte ilk sıradaki anlam çoğu zaman temel anlamdır; ama cümle "
                    "sözcüğü yan ya da mecaz bir anlamda kullanabilir. Anlamı cümlenin "
                    "öteki sözcükleri belirler."
                ),
                ipuclari=[
                    "Cümlede \"{}\" sözcüğüyle birlikte hangi sözcükler var?".format(sozcuk),
                    "Maddedeki anlamları tek tek cümleye yerleştir.",
                ],
                cozum="Her cümle için: maddedeki anlamları sırayla yerine koy; cümleyi bozmayanı seç.",
            ),
            sayi_adimi(
                soru="Üç cümleden kaçında \"{}\" sözlükteki ilk anlamıyla kullanılmış?".format(sozcuk),
                cevap=kac_ilk,
                aciklama="; ".join("{} -> {}. anlam".format(c, a) for c, a in secilen),
                yaygin_yanlislar={
                    3:
                        "Sözlükteki ilk anlamı her bağlama uyguladın.",
                },
                ipuclari=["Her cümleye 1. anlamı koy; cümle bozuluyorsa o anlam değildir."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi cümlelerde \"{}\" ilk anlamında kullanılmamıştır? "
                     "(numaraları virgülle yaz)".format(sozcuk),
                secenekler=cumleler,
                dogru_indeksler=ilk_degil,
                aciklama="Bu cümlelerde bağlam maddenin başka bir anlamını gerektiriyor.",
                ipuclari=["1. anlamı yerine koyunca tuhaflaşan cümleleri seç."],
                puan=10,
            ),
            secim_adimi(
                soru="\"{}\" cümlesinde \"{}\" hangi anlamdadır?".format(odak[0], sozcuk),
                dogru=anlamlar[odak[1] - 1],
                yanlislar={
                    a: ("Sözlükteki ilk anlamı her bağlama uyguladın." if n == 0
                        else "Bu anlam cümlenin bağlamına uymuyor.")
                    for n, a in enumerate(anlamlar) if n != odak[1] - 1
                },
                rastgele=rastgele,
                aciklama="{}. anlam: {}.".format(odak[1], anlamlar[odak[1] - 1]),
                ipuclari=["Sözcüğün yanındaki sözcüklere bak."],
                puan=10,
            ),
        ],
        kapanis=("Dipnotlar düzeltildi: üç cümleden yalnız {} tanesinde ilk anlam geçerli; "
                 "öteki cümlelere bağlama uygun anlam yazıldı.").format(kac_ilk),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# FİİLİMSİLER: EK TAŞIYAN HER SÖZCÜK FİİLİMSİ DEĞİLDİR (B37.17)
#
# `fiilimsiler` tek satırlıktı (2018: 10). Bağlam: "Arşiv cümlelerindeki yan
# bilgileri fiilimsi yapılarıyla ilişkilendirme". `yaygin_yanlis`:
#
#   "Fiilimsi ekini taşıyan her sözcüğü bağlama bakmadan fiilimsi saymak."
#
# DÜZENEK: arşiv cümlelerinden işaretlenmiş sözcükler. Bir kısmı eylem anlamını
# koruyan fiilimsi (yürüyen, onarmak, aşınca); bir kısmı aynı eki taşıyan ama
# kalıcı isim olmuş sözcük (çakmak, kazma, dolma, akşam yemeği).
#
# YANILGININ SAYISAL KARŞILIĞI: fiilimsi sayısını ek taşıyan bütün sözcükler
# saymak.
# ==========================================================================

# (sözcük, cümle, tür, açıklama)
_FIILIMSI_ORNEKLERI = (
    ("yürüyen", "Geçide yürüyen kafile akşam hana vardı.", "sıfat-fiil",
     "eylem anlamını koruyor; \"kafile\" ismini niteliyor"),
    ("onarmak", "Telsizi onarmak için sabaha kadar uğraştı.", "isim-fiil",
     "eylem anlamını koruyor; eylemin adı"),
    ("aşınca", "Kafile geçidi aşınca mola verdi.", "zarf-fiil",
     "eylem anlamını koruyor; zaman bildiriyor"),
    ("gelen", "Depoya gelen çuvalları saydık.", "sıfat-fiil",
     "eylem anlamını koruyor; \"çuvallar\" ismini niteliyor"),
    ("yemek", "Nöbetten sonra sıcak bir şey yemek istedi.", "isim-fiil",
     "eylem anlamını koruyor; ne istedi? sorusunun cevabı olan eylem"),
)
_KALICI_ISIMLER = (
    ("çakmak", "Nöbetçi ateşi çakmakla yaktı.", "kalıcı isim", "bir aletin adı; eylem anlamı yok"),
    ("kazma", "Karı kazmayla temizledik.", "kalıcı isim", "bir aletin adı; eylem anlamı yok"),
    ("dolma", "Aşçı öğlen dolma pişirdi.", "kalıcı isim", "bir yemeğin adı; eylem anlamı yok"),
    ("yemeği", "Akşam yemeği erken yendi.", "kalıcı isim", "öğünün adı; eylem anlamı yok"),
)


@bulmaca(ders="edebiyat", konu="fiilimsiler", kademeler=(10, 13), agirlik=1.1)
def fiilimsi_avi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Fiilimsi, eylem anlamını koruyan yapıdır; kalıcı isim olmuş sözcük fiilimsi değildir."""
    kac_kalici = rastgele.choice((2, 3))
    ornekler = (rastgele.sample(_FIILIMSI_ORNEKLERI, 5 - kac_kalici)
                + rastgele.sample(_KALICI_ISIMLER, kac_kalici))
    rastgele.shuffle(ornekler)
    secenekler = ["\"{}\" - {}".format(s, c) for s, c, _, _ in ornekler]
    fiilimsi_ind = [n for n, o in enumerate(ornekler) if o[2] != "kalıcı isim"]
    odak = rastgele.choice([o for o in ornekler if o[2] == "kalıcı isim"])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-fiilimsi-avi",
        ders="edebiyat",
        baslik="Fiilimsi Avı",
        kademe=kademe,
        konu="fiilimsiler",
        kazanim="Fiilimsileri eylem anlamını korumalarından tanıma; fiilimsi ekini taşısa "
                "da kalıcı isim olmuş sözcükleri fiilimsi saymama.",
        dikkat=6,
        brifing=(
            "Arşiv cümlelerindeki yan bilgiler fiilimsi yapılarıyla işaretlenecek.\n\n"
            "{} ekleri tarayıp işaretledi: \"-an, -en, -mak, -mek, -ma, -ınca... Bu "
            "ekleri taşıyan her sözcük fiilimsidir; beşi de fiilimsi.\"\n\n"
            "İşaretler kalıcı olmadan önce her sözcüğün cümledeki anlamına bakmamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("İşaretli sözcükler", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Dil bilgisi notu",
                  "Fiilimsi, fiile gelen eklerle oluşur ve cümlede eylem anlamını korur. "
                  "Aynı eki taşıyan bazı sözcükler zamanla bir nesnenin ya da yemeğin adı "
                  "olmuştur (çakmak, kazma, dolma); bunlar kalıcı isimdir, fiilimsi değildir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir sözcüğün fiilimsi olup olmadığı nasıl anlaşılır?",
                dogru="Cümlede eylem anlamını koruyup korumadığına bakılarak",
                yanlislar={
                    "Fiilimsi eki taşıyan her sözcük fiilimsidir; ek, türü tek başına belirler":
                        "Fiilimsi ekini taşıyan her sözcüğü bağlama bakmadan fiilimsi saydın.",
                    "Yalnız -mak ve -mek ekini taşıyanlar fiilimsidir":
                        "Sıfat-fiil (-an) ve zarf-fiil (-ınca) ekleri de fiilimsi kurar.",
                    "Cümlenin sonundaki sözcük fiilimsidir":
                        "Cümle sonundaki sözcük çoğunlukla yüklemdir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Telsizi onarmak için\" cümlesinde onarmak bir eylemdir: isim-fiil. "
                    "\"Ateşi çakmakla yaktı\" cümlesinde çakmak bir aletin adıdır: kalıcı "
                    "isim. Ek aynı, görev farklı."
                ),
                ipuclari=[
                    "Sözcük bir eylemi mi, bir nesneyi mi anlatıyor?",
                    "Sözcüğün yerine \"alet\" ya da \"yemek\" diyebilir misin?",
                ],
                cozum="Eylem anlamı var -> fiilimsi (isim-fiil, sıfat-fiil, zarf-fiil)\nNesne/yemek adı -> kalıcı isim",
            ),
            sayi_adimi(
                soru="İşaretli beş sözcükten kaç tanesi gerçekten fiilimsidir?",
                cevap=5 - kac_kalici,
                aciklama="; ".join("{}: {} ({})".format(s, t, a) for s, _, t, a in ornekler),
                yaygin_yanlislar={
                    5:
                        "Fiilimsi ekini taşıyan her sözcüğü bağlama bakmadan fiilimsi saydın.",
                },
                ipuclari=["Eylem anlamını koruyanları say."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi işaretli sözcükler fiilimsidir? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=fiilimsi_ind,
                aciklama="Eylem anlamını koruyan sözcükler fiilimsidir.",
                ipuclari=["Her sözcüğü cümlesinde oku."],
                puan=10,
            ),
            secim_adimi(
                soru="\"{}\" cümlesinde \"{}\" nedir?".format(odak[1], odak[0]),
                dogru="Kalıcı isim: {}".format(odak[3]),
                yanlislar={
                    "Fiilimsi: fiilimsi eki taşıyor; ek varsa sözcük fiilimsidir":
                        "Fiilimsi ekini taşıyan her sözcüğü bağlama bakmadan fiilimsi saydın.",
                    "Yüklem: cümlenin eylemini bildiriyor":
                        "Cümlenin yüklemi başka bir sözcük.",
                },
                rastgele=rastgele,
                aciklama="{}: {}.".format(odak[0], odak[3]),
                ipuclari=["Sözcük bir eylemi mi, bir şeyin adını mı bildiriyor?"],
                puan=10,
            ),
        ],
        kapanis=("İşaretler düzeltildi: beş sözcükten {} tanesi fiilimsi, {} tanesi kalıcı "
                 "isim.").format(5 - kac_kalici, kac_kalici),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# CÜMLE TÜRLERİ: SORU BİÇİMİ HER ZAMAN SORU DEĞİLDİR (B37.17)
#
# `cumle_turleri` tek satırlıktı (2018: 10). Bağlam: "Üs duyurusunun cümlelerini
# anlam ve kuruluş bakımından inceleme". `yaygin_yanlis`:
#
#   "Soru biçimindeki her cümleyi gerçek bilgi sorusu saymak."
#
# DÜZENEK: üs duyurusundan soru işaretiyle biten cümleler. Bir kısmı gerçekten
# bilgi istiyor; bir kısmı rica, davet, uyarı ya da olumlu/olumsuz bir yargı
# bildiriyor. Personel hepsini "yanıtlanacak sorular" listesine koyuyor.
#
# YANILGININ SAYISAL KARŞILIĞI: gerçek soru sayısını bütün soru biçimli
# cümleler saymak.
# ==========================================================================

# (cümle, gerçek bilgi sorusu mu, anlamı)
_DUYURU_SORULARI = (
    ("Kafile saat kaçta yola çıkacak?", True, "bilgi istiyor: kafilenin çıkış saati"),
    ("Depo anahtarı kimde?", True, "bilgi istiyor: anahtarın kimde olduğu"),
    ("Yarınki toplantı hangi salonda?", True, "bilgi istiyor: toplantının yeri"),
    ("Kapıyı çıkarken kapatır mısınız?", False, "rica: kapının kapatılması isteniyor"),
    ("Bu soğukta kim dışarı çıkar ki?", False, "olumsuz yargı: bu soğukta kimse dışarı çıkmaz"),
    ("Nöbeti aksatmak olur mu hiç?", False, "uyarı: nöbet aksatılmamalı"),
    ("Siz de şenliğe gelmez misiniz?", False, "davet: şenliğe çağırıyor"),
    ("Kurulun kararı hepimizi ilgilendirmez mi?", False,
     "olumlu yargı: karar herkesi ilgilendirir"),
)


@bulmaca(ders="edebiyat", konu="cumle_turleri", kademeler=(9, 13), agirlik=1.1)
def duyuru_cumleleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Soru biçimli cümle rica, davet, uyarı ya da yargı da bildirebilir."""
    gercek = [c for c in _DUYURU_SORULARI if c[1]]
    diger = [c for c in _DUYURU_SORULARI if not c[1]]
    kac_gercek = rastgele.choice((1, 2))
    cumleler = rastgele.sample(gercek, kac_gercek) + rastgele.sample(diger, 5 - kac_gercek)
    rastgele.shuffle(cumleler)
    metinler = [c[0] for c in cumleler]
    gercek_ind = [n for n, c in enumerate(cumleler) if c[1]]
    odak = rastgele.choice([c for c in cumleler if not c[1]])
    diger_anlamlar = [c[2] for c in diger if c[0] != odak[0]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-duyuru-cumleleri",
        ders="edebiyat",
        baslik="Duyuru Cümleleri",
        kademe=kademe,
        konu="cumle_turleri",
        kazanim="Soru biçimli cümlelerin anlamını bağlamdan belirleme; gerçek bilgi "
                "sorusunu rica, davet, uyarı ve yargı bildiren soru biçimli cümlelerden "
                "ayırma.",
        dikkat=6,
        brifing=(
            "Üs duyurusundaki soru işaretli cümleler yanıtlanmak üzere ayrılacak.\n\n"
            "{} hepsini \"yanıtlanacak sorular\" listesine yazdı: \"Soru işaretiyle "
            "bitiyorsa sorudur; beşine de birer yanıt yazalım.\"\n\n"
            "Yanıtlar yazılmadan önce hangi cümlelerin gerçekten bilgi istediğini "
            "bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Duyurudaki cümleler", "\n".join(metinler), bedel=1, kritik=True),
            Kanit("Dil bilgisi notu",
                  "Soru biçimli bir cümle her zaman bilgi istemez: rica, davet, uyarı, "
                  "şaşırma ya da olumlu/olumsuz bir yargı da bildirebilir. Cümlenin "
                  "anlamı bağlamdan anlaşılır.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Soru işaretiyle biten bir cümle için hangisi doğrudur?",
                dogru="Bilgi isteyebilir; rica, uyarı ya da yargı da bildirebilir, bağlam belirler",
                yanlislar={
                    "Her zaman gerçek bir bilgi sorusudur ve yanıt bekler":
                        "Soru biçimindeki her cümleyi gerçek bilgi sorusu saydın.",
                    "Hiçbir zaman gerçek soru değildir; duyuruda soru yalnız dikkat çekmek içindir":
                        "\"Kafile saat kaçta çıkacak?\" gibi cümleler gerçekten bilgi ister.",
                    "Yalnız soru sözcüğü (kim, ne) varsa sorudur":
                        "\"Kim dışarı çıkar ki?\" soru sözcüğü taşır ama olumsuz bir yargıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Kapıyı kapatır mısınız?\" bilgi istemez, kapının kapatılmasını "
                    "rica eder. \"Bu soğukta kim çıkar ki?\" bir kişiyi sormaz; kimsenin "
                    "çıkmayacağını söyler."
                ),
                ipuclari=[
                    "Cümleye bir bilgiyle yanıt vermek anlamlı mı?",
                    "Cümle aslında bir şey mi istiyor, bir şey mi söylüyor?",
                ],
                cozum="Bilgiyle yanıtlanabiliyorsa gerçek soru; değilse rica/davet/uyarı/yargı",
            ),
            sayi_adimi(
                soru="Beş cümleden kaç tanesi gerçekten bir bilgi istiyor?",
                cevap=kac_gercek,
                aciklama="; ".join("{} -> {}".format(c, a) for c, _, a in cumleler),
                yaygin_yanlislar={
                    5:
                        "Soru biçimindeki her cümleyi gerçek bilgi sorusu saydın.",
                },
                ipuclari=["Yanıtı bir bilgi olan cümleleri say."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi cümleler gerçek bilgi sorusudur? (numaraları virgülle yaz)",
                secenekler=metinler,
                dogru_indeksler=gercek_ind,
                aciklama="Gerçek soru, yanıtı bir bilgi olan sorudur.",
                ipuclari=["Cümleye bir bilgiyle yanıt verebiliyor musun?"],
                puan=10,
            ),
            secim_adimi(
                soru="\"{}\" cümlesi ne bildiriyor?".format(odak[0]),
                dogru=odak[2][:1].upper() + odak[2][1:],
                yanlislar={
                    "Gerçek bir soru: yanıt olarak bir bilgi bekliyor":
                        "Soru biçimindeki her cümleyi gerçek bilgi sorusu saydın.",
                    diger_anlamlar[0][:1].upper() + diger_anlamlar[0][1:]:
                        "Bu anlam başka bir cümleye ait; bu cümlenin bağlamına bak.",
                },
                rastgele=rastgele,
                aciklama="{}: {}.".format(odak[0], odak[2]),
                ipuclari=["Cümlenin söyleyene ne yaptırmak ya da ne demek istediğini düşün."],
                puan=10,
            ),
        ],
        kapanis=("Liste düzeltildi: beş cümleden yalnız {} tanesi gerçek soru; ötekiler "
                 "rica, davet, uyarı ya da yargı olarak ayrıldı.").format(kac_gercek),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# EDEBÎ DÖNEMLER: SINIR TARİHİ BÜTÜN ESERLERİ KESİN AYIRMAZ (B37.17)
#
# `edebiyat_donemleri` tek satırlıktı (2018: 10). Bağlam: "Arşiv belgelerinin
# dil ve alfabe özelliklerini dönemleriyle ilişkilendirme". `yaygin_yanlis`:
#
#   "Edebî dönem sınırlarını bütün eserleri kesin ayıran tarihler sanmak."
#
# DÜZENEK: arşiv belgeleri ve dönem sınırları. Geçiş dönemi eserleri
# (Kutadgu Bilig, Divanü Lügati't-Türk) İslamiyet sonrası yazıldığı hâlde
# önceki dönemin izlerini taşır; Tanzimat'tan (1860) sonra da divan şiiri
# yazılmıştır (Yenişehirli Avni).
#
# YANILGININ SAYISAL KARŞILIĞI: sınırı aşan özellik taşıyan belge sayısını 0
# saymak.
# ==========================================================================

# (belge, yıl, özellik, sınırı aşıyor mu)
_DONEM_BELGELERI = (
    ("Divanü Lügati't-Türk", 1072,
     "İslamiyet'ten sonra yazıldı ama İslamiyet öncesinden kalma sagu ve koşuklar içeriyor", True),
    ("Kutadgu Bilig", 1069,
     "İslami dönemin ilk eserlerinden; eski Türk devlet anlayışını ve töreyi de işliyor", True),
    ("Yenişehirli Avni'nin şiirleri", 1880,
     "Tanzimat döneminde yazıldı ama aruzla, divan şiiri geleneğinde", True),
    ("Tercüman-ı Ahval gazetesi", 1860, "Tanzimat edebiyatının başlangıcı sayılan gazete", False),
    ("Fuzûlî'nin Divanı", 1530, "Divan şiirinin en parlak örneklerinden", False),
    ("Nutuk", 1927, "Cumhuriyet'in ilk yıllarında Arap harfleriyle basıldı", False),
)


@bulmaca(ders="edebiyat", konu="edebiyat_donemleri", kademeler=(10, 13), agirlik=1.1)
def donem_siniri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Dönem sınırları kolaylık için konan tarihlerdir; geçiş eserleri iki dönemin izini taşır."""
    asan = [b for b in _DONEM_BELGELERI if b[3]]
    tipik = [b for b in _DONEM_BELGELERI if not b[3]]
    kac_asan = rastgele.choice((1, 2))
    belgeler = rastgele.sample(asan, kac_asan) + rastgele.sample(tipik, 4 - kac_asan)
    rastgele.shuffle(belgeler)
    secenekler = ["{} ({})".format(b[0], b[1]) for b in belgeler]
    asan_ind = [n for n, b in enumerate(belgeler) if b[3]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-donem-siniri",
        ders="edebiyat",
        baslik="Dönem Sınırı",
        kademe=kademe,
        konu="edebiyat_donemleri",
        kazanim="Edebî dönem sınırlarının eserleri kesin ayırmadığını gösterme; geçiş "
                "dönemi eserlerini ve sınırdan sonra süren gelenekleri belgelerle tanıma.",
        dikkat=6,
        # B46.3 (pilot dersi edebiyat): giriş alçaltıldı. Brifing kısaldı, ilk
        # ipucu mevsim benzetmesi. Şıklar ve doğru cevaplar aynı
        # (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "{} arşiv belgelerini edebî dönem raflarına yalnız tarihe göre "
            "dizdi: \"Dönem sınırı kesindir; hiçbir belge iki dönemin "
            "izini birlikte taşımaz.\"\n\nBelgelerin özelliklerine bakalım."
        ).format(kisi),
        kanitlar=[
            Kanit("Belgeler",
                  "\n".join("{} ({}): {}.".format(b[0], b[1], b[2]) for b in belgeler),
                  bedel=1, kritik=True),
            Kanit("Dönem notu",
                  "İslamiyet'in kabulü (10. yüzyıl), Tanzimat edebiyatının başlangıcı "
                  "(1860) ve harf değişikliği (1928) dönemleri ayırmak için kullanılan "
                  "sınırlardır. Değişim bir günde olmaz: geçiş dönemlerinde eserler iki "
                  "dönemin izini birlikte taşır.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Edebî dönem sınırları için hangisi doğrudur?",
                dogru="İncelemeyi kolaylaştıran yaklaşık tarihlerdir; geçişler yavaş olur",
                yanlislar={
                    "Bütün eserleri kesin olarak ayıran tarihlerdir; her eser tek bir döneme aittir":
                        "Edebî dönem sınırlarını bütün eserleri kesin ayıran tarihler sandın.",
                    "Dönemler arasında hiçbir fark yoktur; sınırlar yalnız ders kitabı içindir":
                        "Dönemlerin dil, biçim ve konu farkları vardır; yalnız sınır keskin değildir.",
                    "Bir eserin dönemi yalnız yazarının doğum yılından bulunur":
                        "Dönemi eserin özellikleri ve yazıldığı zaman birlikte belirler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Divanü Lügati't-Türk İslamiyet'ten sonra yazıldı ama önceki dönemin "
                    "sagu ve koşuklarını saklar. Tanzimat'tan sonra da divan şiiri yazıldı. "
                    "Sınır tarihleri bir değişimin başladığı yeri gösterir, bittiği yeri değil."
                ),
                ipuclari=[
                    "Mevsimleri düşün: takvimde yaz 22 Eylül'de biter ama hava bir "
                    "gecede soğumaz; bir süre iki mevsimin izi birlikte görülür.",
                    "Belgelerin özelliklerinde iki dönemin izini birlikte taşıyan var mı?",
                    "Dönem notu değişim için ne diyor?",
                ],
                cozum="Belgenin yılı -> resmî dönem; özellikleri -> taşıdığı izler; ikisi farklıysa geçiş",
            ),
            coklu_adimi(
                soru="Hangi belgeler yazıldığı dönemin sınırını aşan özellikler taşıyor? "
                     "(numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=asan_ind,
                aciklama="; ".join("{}: {}".format(b[0], b[2]) for b in belgeler if b[3]),
                ipuclari=["Özelliğinde \"ama\" ile önceki ya da başka bir döneme bağlanan belgeleri seç."],
                puan=12,
            ),
            sayi_adimi(
                soru="Dört belgeden kaç tanesi iki dönemin izini birlikte taşıyor?",
                cevap=kac_asan,
                aciklama="{} belge dönem sınırını aşan özellik taşıyor.".format(kac_asan),
                yaygin_yanlislar={
                    0:
                        "Edebî dönem sınırlarını bütün eserleri kesin ayıran tarihler sandın.",
                },
                ipuclari=["Seçtiğin belgeleri say."],
                puan=10,
            ),
        ],
        kapanis=("Raflar düzeltildi: {} belge iki dönemin izini taşıdığı için \"geçiş\" "
                 "etiketiyle dizildi.").format(kac_asan),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# EDEBİYAT VE TOPLUM: AYNI DÖNEM, FARKLI AKIMLAR (B37.17)
#
# `edebiyat_toplum_akim` tek satırlıktı (2018: 11). Bağlam: "Arşivdeki metin ve
# görselleri ortak sanat anlayışı açısından inceleme". `yaygin_yanlis`:
#
#   "Aynı dönemin bütün yazarlarını aynı akıma bağlamak."
#
# DÜZENEK: 1950'lerde şiir yayımlayan dört şairin sanat anlayışı kartları:
# Orhan Veli (Garip), Cemal Süreyya (İkinci Yeni), Attilâ İlhan (Mavi),
# Munis Faik Ozansoy (Hisar). Aynı yıllar, dört ayrı anlayış.
#
# YANILGININ SAYISAL KARŞILIĞI: farklı akım sayısını 1 saymak.
# ==========================================================================

# (şair, akım ya da topluluk, sanat anlayışı)
_AKIM_KARTLARI = (
    ("Orhan Veli", "Garip",
     "Ölçü, uyak ve söz sanatlarını bırakıp sıradan insanı gündelik dille anlatmak"),
    ("Cemal Süreyya", "İkinci Yeni",
     "İmgeyi öne çıkarıp anlamı kapalı ve çok katmanlı bir dil kurmak"),
    ("Attilâ İlhan", "Mavi",
     "Garip'e tepki olarak toplumsal gerçekliği halk kültürü ve imgeyle birleştirmek"),
    ("Munis Faik Ozansoy", "Hisar",
     "Geleneğe bağlı kalıp ölçü ve uyakla, açık bir Türkçeyle yazmak"),
)


@bulmaca(ders="edebiyat", konu="edebiyat_toplum_akim", kademeler=(11, 13), agirlik=1.1)
def akim_kartlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı dönemde yazan şairler farklı sanat anlayışlarına bağlı olabilir."""
    kac = rastgele.choice((3, 4))
    kartlar = rastgele.sample(_AKIM_KARTLARI, kac)
    rastgele.shuffle(kartlar)
    odak = rastgele.choice(kartlar)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-akim-kartlari",
        ders="edebiyat",
        baslik="Akım Kartları",
        kademe=kademe,
        konu="edebiyat_toplum_akim",
        kazanim="Aynı dönemde yazan şairlerin farklı sanat anlayışlarını metin ve "
                "kartlardan ayırt etme; dönemi akımla eşitlememe.",
        dikkat=6,
        brifing=(
            "Arşivin 1950'ler rafındaki {} şairin kartları sergi için gruplanacak.\n\n"
            "{} hepsini tek bir gruba koydu: \"Aynı yıllarda yazmışlar; demek ki hepsi "
            "aynı akımdan, aynı sanat anlayışından.\"\n\n"
            "Gruplar asılmadan önce kartlardaki sanat anlayışlarını karşılaştırmamız "
            "gerekiyor."
        ).format(kac, kisi),
        kanitlar=[
            Kanit("Şair kartları",
                  "\n".join("{}: {}.".format(s, a) for s, _, a in kartlar),
                  bedel=1, kritik=True),
            Kanit("Akım notu",
                  "Garip: gündelik dil, ölçü ve uyağa karşı çıkış. İkinci Yeni: imge ve "
                  "kapalı anlatım. Mavi: Garip'e tepki, toplumsal gerçeklik ve halk "
                  "kültürü. Hisar: gelenek, ölçü ve uyak, açık dil.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Aynı dönemde yazan şairler için hangisi doğrudur?",
                dogru="Farklı akımlara bağlı olabilirler; akımı tarih değil sanat anlayışı belirler",
                yanlislar={
                    "Aynı dönemde yazdıkları için hepsi aynı akımdandır; her dönemin tek bir akımı olur":
                        "Aynı dönemin bütün yazarlarını aynı akıma bağladın.",
                    "Hiçbiri bir akıma bağlı değildir":
                        "Kartlardaki anlayışlar belirli topluluklarla örtüşüyor.",
                    "Akım, şairin doğduğu şehre göre belirlenir":
                        "Akımı sanat anlayışı belirler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "1950'lerde Garip şiiri sürerken İkinci Yeni doğdu, Mavi Garip'e tepki "
                    "verdi, Hisar geleneği savundu. Aynı yıllar, birbirine karşı çıkan "
                    "anlayışlar."
                ),
                ipuclari=[
                    "Kartlardaki anlayışlar birbirine benziyor mu?",
                    "Akım notunda her akım neyi savunuyor?",
                ],
                cozum="Her kartın anlayışını akım notuyla eşle; farklı akımları say.",
            ),
            sayi_adimi(
                soru="Bu {} şair kaç farklı akım ya da topluluğa bağlı?".format(kac),
                cevap=len({a for _, a, _ in kartlar}),
                aciklama="; ".join("{}: {}".format(s, a) for s, a, _ in kartlar),
                yaygin_yanlislar={
                    1:
                        "Aynı dönemin bütün yazarlarını aynı akıma bağladın.",
                },
                ipuclari=["Her kartın anlayışını akım notundaki tanımlarla eşle."],
                puan=12,
            ),
            secim_adimi(
                soru="{} kartındaki anlayış hangi akıma aittir?".format(odak[0]),
                dogru=odak[1],
                yanlislar=[a for _, a, _ in _AKIM_KARTLARI if a != odak[1]],
                rastgele=rastgele,
                aciklama="{}: {} ({}).".format(odak[0], odak[2], odak[1]),
                ipuclari=["Akım notundaki anahtar sözcükleri karttaki anlayışta ara."],
                puan=10,
            ),
        ],
        kapanis=("Gruplar düzeltildi: aynı yıllarda yazan {} şair {} farklı akıma "
                 "ayrıldı.").format(kac, len({a for _, a, _ in kartlar})),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# EDEBİYATA GİRİŞ: EDEBÎ METİN BİLGİ DOĞRULUĞUYLA ÖLÇÜLMEZ (B37.17)
#
# `edebiyata_giris` tek satırlıktı (2018: 9). Bağlam: "Arşivdeki bilim notu ve
# edebî sefer anlatısını amaçlarına göre ayırma". `yaygin_yanlis`:
#
#   "Edebî metni yalnız bilgi doğruluğuyla değerlendirmek; ağız ile lehçeyi
#    aynı saymak."
#
# DÜZENEK: sefer anlatısından cümleler; personel "dağlar seyretti", "rüzgâr
# kapıyı çaldı" gibi cümleleri "yanlış bilgi" diye işaretliyor. Ayrıca bir
# Karadeniz ağzı kaydı ile bir Azerbaycan Türkçesi kaydını aynı sayıyor.
#
# YANILGININ SAYISAL KARŞILIĞI: edebî anlatım sayısını 0 saymak.
# ==========================================================================

_GIRIS_BILGI = (
    "Geçidin yüksekliği 2400 metredir.",
    "Gece sıcaklık sıfırın altına düştü.",
    "Kafile o gün 40 kilometre yol aldı.",
)
_GIRIS_EDEBI = (
    "Dağlar kafileyi sessizce seyretti.",
    "Rüzgâr gece boyunca çadırların kapısını çaldı.",
    "Yıldızlar yolumuza fener tuttu.",
)
# (kayıt, tür, açıklama)
_GIRIS_SESLER = (
    ("Karadenizli rehberin \"geliyrum\" demesi", "ağız",
     "Türkiye Türkçesinin bir bölgedeki söyleyiş farkı"),
    ("Azerbaycanlı bir yolcunun \"gelirem\" demesi", "lehçe",
     "Türkçenin ayrı bir kolu olan Azerbaycan Türkçesi"),
)


@bulmaca(ders="edebiyat", konu="edebiyata_giris", kademeler=(9, 12), agirlik=1.1)
def metin_amaci(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Edebî metin kurmacadır; bilgi metni gibi doğruluk ölçütüyle değerlendirilmez."""
    kac_edebi = rastgele.choice((2, 3))
    cumleler = (rastgele.sample(_GIRIS_EDEBI, kac_edebi)
                + rastgele.sample(_GIRIS_BILGI, 5 - kac_edebi))
    rastgele.shuffle(cumleler)
    edebi_ind = [n for n, c in enumerate(cumleler) if c in _GIRIS_EDEBI]
    ses = rastgele.choice(_GIRIS_SESLER)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ede-metin-amaci",
        ders="edebiyat",
        baslik="Metin Amacı",
        kademe=kademe,
        konu="edebiyata_giris",
        kazanim="Bilgi veren metin ile edebî metni amaçlarına göre ayırma; edebî metni "
                "yalnız bilgi doğruluğuyla değerlendirmeme; ağız ile lehçeyi ayırt etme.",
        dikkat=6,
        # B46.3 (pilot dersi edebiyat): giriş alçaltıldı. Brifing kısaldı;
        # ağız/lehçe tanımı ilk ekrandan çıktı, yalnız onu soran 4. adımda
        # geliyor. İlk ipucu şarkı sözü benzetmesi. Şıklar ve doğru cevaplar
        # aynı (`testler/test_yumusatma_b46.py` parmak izi).
        brifing=(
            "Sefer anlatısı arşive girecek. {} bazı cümlelerin altını kırmızıyla "
            "çizdi: \"Dağlar seyretmez, rüzgâr kapı çalmaz; bunlar yanlış bilgi.\"\n\n"
            "Metnin amacına bakalım."
        ).format(kisi),
        kanitlar=[
            Kanit("Anlatıdan cümleler", "\n".join(cumleler), bedel=1, kritik=True),
            Kanit("Arşiv notu",
                  "Bilgi veren metin gerçeği aktarır ve doğruluğuyla ölçülür. Edebî metin "
                  "kurmacadır; dili duygu ve imge için kullanır, bilgi doğruluğuyla "
                  "ölçülmez.",
                  bedel=1, kritik=True),
            Kanit("Ses kaydı", "{}.".format(ses[0]), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Edebî bir metin nasıl değerlendirilir?",
                dogru="Kurmaca olduğu bilinerek, dilin duygu ve imgeyi nasıl kurduğuna bakılarak",
                yanlislar={
                    "Bilim notu gibi, bilgi doğruluğuna bakılarak; yanlış bilgi veren metin kusurludur":
                        "Edebî metni yalnız bilgi doğruluğuyla değerlendirdin.",
                    "Yalnız yazım kurallarına uyup uymadığına bakılarak":
                        "Yazım önemlidir ama metnin edebî değerini belirlemez.",
                    "Uzunluğuna bakılarak; uzun metin daha çok emek ve değer taşır":
                        "Uzunluk edebî değeri belirlemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Dağlar kafileyi seyretti\" bir bilgi yanlışı değil, yolcuların "
                    "yalnızlığını hissettiren bir imgedir. Bilim notu ise ölçülebilir "
                    "gerçeği aktarır."
                ),
                ipuclari=[
                    "Bir şarkıda \"gözlerin deniz\" denince kimse gözde su aramaz; "
                    "o söz bir duyguyu anlatır.",
                    "Cümle bir gerçeği mi aktarıyor, bir duyguyu mu?",
                    "Arşiv notu edebî metni nasıl tanımlıyor?",
                ],
                cozum="Ölçülebilir gerçek -> bilgi cümlesi; duygu ve imge -> edebî anlatım",
            ),
            coklu_adimi(
                soru="Hangi cümleler bilgi yanlışı değil, edebî anlatımdır? "
                     "(numaraları virgülle yaz)",
                secenekler=cumleler,
                dogru_indeksler=edebi_ind,
                aciklama="Kişileştirme ve imge taşıyan cümleler edebî anlatımdır.",
                ipuclari=["Doğada kelimesi kelimesine olamayacak ama bir duygu anlatan cümleleri seç."],
                puan=12,
            ),
            sayi_adimi(
                soru="Personelin kırmızıyla çizdiği türden kaç cümle aslında edebî anlatımdır?",
                cevap=kac_edebi,
                aciklama="{} cümle imge ve kişileştirmeyle kurulmuş edebî anlatım.".format(kac_edebi),
                yaygin_yanlislar={
                    0:
                        "Edebî metni yalnız bilgi doğruluğuyla değerlendirdin; bu cümleler "
                        "yanlış bilgi değil.",
                },
                ipuclari=["Seçtiğin edebî cümleleri say."],
                puan=10,
            ),
            secim_adimi(
                soru=("{} şunu da yazmış: \"Rehberin konuşmasıyla yolcunun konuşması "
                      "aynı şey, ikisi de yöresel söyleyiş.\"\n\nArşiv notunun devamı: "
                      "Ağız, bir dilin bölgeler arası söyleyiş farkıdır; lehçe ya da "
                      "şive, dilin ayrı bir koludur.\n\nSes kaydındaki söyleyiş ağız "
                      "mıdır, lehçe mi?").format(kisi),
                dogru="{}: {}".format(ses[1][:1].upper() + ses[1][1:], ses[2]),
                yanlislar={
                    "{}: ikisi aynı şeydir; farklı söyleyişin hepsine bu ad verilir".format("Lehçe" if ses[1] == "ağız" else "Ağız"):
                        "Ağız ile lehçeyi aynı saydın.",
                    "Hiçbiri: yalnız yanlış telaffuzdur":
                        "Ağız ve lehçe yanlış değil, dilin doğal çeşitliliğidir.",
                },
                rastgele=rastgele,
                aciklama="{}: {}.".format(ses[0], ses[2]),
                ipuclari=["Konuşan Türkiye Türkçesinin bir bölgesinden mi, Türkçenin ayrı bir kolundan mı?"],
                puan=10,
            ),
        ],
        kapanis=("Kırmızı çizgiler kaldırıldı: {} cümle edebî anlatım olarak arşive girdi; "
                 "ses kaydı \"{}\" olarak etiketlendi.").format(kac_edebi, ses[1]),
        odul={"itibar": 4, "cevher": 1},
    )
