# -*- coding: utf-8 -*-
"""
Telsiz uygunsuz sozcuk listesi. KISA TUTULDU ve genisletilebilir.

Eslesme, metin NORMALLESTIRILDIKTEN sonra yapilir (kucuk harf, Turkce
harfler ASCII'ye, tekrar eden harfler tek harfe, "s.i.k" gibi araya
girmis ayiricilar silinir). Bu yuzden buradaki sozcukler NORMAL biciminde
(ASCII, kucuk harf, tekrarsiz) yazilir.

Uc liste:
  TAM       : yalniz tam sozcuk olarak eslesir ("bok" evet, "boks" hayir).
  ONEK      : sozcuk bu onekle basliyorsa eslesir (cekimleri yakalar).
              Onek en az 4 harf olmali; kisa onekler masum sozcukleri
              yakalar ("amin" -> "amino"). Test bunu denetler.
  IBARE     : bosluklu kalip (normal metinde aranir).

Okul kendi sozcuklerini `kayitlar/telsiz_yasak.txt` dosyasina (her satira
bir sozcuk, "#" yorum) ekleyebilir; sunucu her acilista okur. Dosyadaki
sozcukler TAM eslesir; sonu "*" ise ONEK olur.

Sozcukler ogrencinin yazdigi kotu sozu ENGELLEMEK icin burada durur;
oyunun hicbir ekraninda gosterilmez.
"""

# Dikkat: "sik", "sikik", "sikis", "pic", "amina", "anani" GIBI sozcukler
# bilerek YOK; normallestirmede ı->i oldugu icin "sık", "sıkık", "sıkış",
# "Amina" (ad), "ananı" gibi masum sozcukleri de yakalarlar.
TAM = (
    "amk", "aq", "got", "gotun", "bok", "pust", "ibne", "gavat", "kahpe",
    "yarrak", "orospu", "orospucocugu", "pezevenk", "yavsak", "serefsiz",
    "namussuz", "haysiyetsiz", "gerizekali", "salak", "aptal", "dangalak",
    "ahmak", "andaval", "dallama", "angut", "amcik", "siktir", "sikeyim",
    "sikerim",
)

ONEK = (
    "siktir", "sikeyim", "sikerim", "gotveren", "gotunu", "orospu",
    "pezevenk", "yavsak", "amcik", "aminakoy", "aminisik", "ananisik",
    "pickurusu", "salaksi", "aptalsi", "kahpe", "haysiyetsiz", "serefsiz", "gerizekal",
    "dangalak", "yarrak",
)

IBARE = (
    "mal mal", "kendini old", "oldurecegim", "geber", "defol git",
    "kafani kiracagim", "seni doverim", "ananin ami",
)
