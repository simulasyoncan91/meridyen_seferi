# -*- coding: utf-8 -*-
"""
Materyal: külçe ve alaşımdan yapılan parça. (GOREVLER B28.14-B28.15)

Zincirin ÇIKIŞI burasıdır: ham taş -> maden -> külçe/alaşım -> MATERYAL.
Kullanıcı kararı (11 Eylül): külçe ve alaşım yalnızca materyal üretiminde
kullanılır; materyal DERS KONULARINA KÖPRÜ olur (titanyum çubuk -> biyoloji:
protez). Bu, TASARIM_NOTLARI §3'ün istediği şeydir: üretimin çıkışı
öğrenmeye bağlanıyor, kendi içine kapanmıyor.

§0 -- ÖDÜL, KAPI DEĞİL
    * Materyal yalnızca EK görev açar (köprü). Hiçbir ders görevi materyal
      istemez; materyali olmayan öğrenci ders içeriğinden hiçbir şey
      kaybetmez.
    * Köprü görevi materyali HARCAMAZ: materyal bir anahtardır, yakıt değil.
      Sahip olmak yeter; aynı köprü tekrar tekrar açılabilir.
    * Köprü içeriği ders programındaki aynı konunun görevleridir; yani
      materyalsiz de o konu zaten oynanır. Materyal yalnızca konuyu üretimin
      hikâyesine bağlar.

Stok `Durum.materyaller` (kod -> ADET). Eski kayıtlar boş açılır; bilinmeyen
kodlar silinmez (ileriye uyumlu, B47).
"""
from __future__ import annotations

from typing import Dict, List, NamedTuple, Optional, Tuple

from . import madenler as M
from . import zincir


class Kopru(NamedTuple):
    ders: str
    konu: str
    etiket: str          # köprü görevlerini ayıran etiket (kayit_defteri)
    baslik: str
    aciklama: str


class Materyal(NamedTuple):
    kod: str
    ad: str
    tur: str             # "kulce" | "alasim"
    kaynak: str          # külçe/alaşım kodu
    gram: int            # BİR ADET için gereken gram
    acilis_kademesi: int
    kullanim: str
    kopru: Kopru


def _k(kod, ders, konu, baslik, aciklama):
    return Kopru(ders, konu, "kopru:" + kod, baslik, aciklama)


# Gram değerleri bu oturumda seçildi (kullanıcı onayı bekliyor).
MATERYALLER: List[Materyal] = [
    Materyal("demir_cubuk", "Demir çubuk", "kulce", "demir", 500, 1,
             "çit, kapı mandalı, çivi",
             _k("demir_cubuk", "fen", "yogunluk", "Çubuğun yoğunluğu",
                "Çubuğu tartıp hacmini ölçerek demirin yoğunluğunu bulursun.")),
    Materyal("bakir_tel", "Bakır tel", "kulce", "bakir", 300, 1,
             "elektrik hattı, bobin",
             _k("bakir_tel", "fen", "elektrik", "Telden akım geçer mi?",
                "Bakır teli devreye bağlayıp iletkenliği yorumlarsın.")),
    Materyal("celik_kiris", "Çelik kiriş", "alasim", "celik", 2000, 3,
             "depo çatısı, köprü ayağı",
             _k("celik_kiris", "fen", "basinc", "Kiriş altındaki basınç",
                "Kirişin ağırlığı ile zemine bindirdiği basıncı hesaplarsın.")),
    Materyal("tunc_can", "Tunç çan", "alasim", "tunc", 1500, 5,
             "üs çanı, madalya",
             _k("tunc_can", "tarih", "tarih_aritmetigi", "Tunç Çağı'nın sırası",
                "Çanı yapan alaşım bir çağa adını verdi; çağın yılını hesaplarsın.")),
    Materyal("pirinc_musluk", "Pirinç musluk", "alasim", "pirinc", 400, 5,
             "su hattı, vana",
             _k("pirinc_musluk", "matematik", "oran_oranti", "Pirincin karışımı",
                "Musluktaki bakır ve çinko payını oranla bulursun.")),
    Materyal("aluminyum_levha", "Alüminyum levha", "kulce", "aluminyum", 600, 6,
             "hafif gövde, kapak",
             _k("aluminyum_levha", "fen", "yuzme_batma", "Levha yüzer mi?",
                "Levhanın yoğunluğuna bakıp suda yüzüp yüzmeyeceğini yorumlarsın.")),
    Materyal("paslanmaz_levha", "Paslanmaz çelik levha", "alasim",
             "paslanmaz_celik", 1500, 9, "mutfak ve laboratuvar tezgâhı",
             _k("paslanmaz_levha", "kimya", "korozyon", "Neden paslanmıyor?",
                "Krom oranının neden önemli olduğunu ve korozyonun yolunu çözersin.")),
    Materyal("titanyum_cubuk", "Titanyum çubuk", "kulce", "titanyum", 300, 10,
             "protez, implant",
             _k("titanyum_cubuk", "biyoloji", "destek_hareket", "Kemik ve implant",
                "Titanyumun vücutla uyumunu ve protezin kemiğe tutunmasını anlarsın.")),
]

MATERYAL_KODLARI = [m.kod for m in MATERYALLER]
_DIZIN: Dict[str, Materyal] = {m.kod: m for m in MATERYALLER}


def materyal(kod: str) -> Optional[Materyal]:
    return _DIZIN.get(kod)


def acik_materyaller(kademe: int) -> List[Materyal]:
    return [m for m in MATERYALLER if m.acilis_kademesi <= int(kademe)]


def kaynak_adi(m: Materyal) -> str:
    kayit = M.alasim(m.kaynak) if m.tur == "alasim" else M.maden(m.kaynak)
    return kayit.ad if kayit is not None else m.kaynak


# ------------------------------------------------------------------ stok
def stok(durum) -> Dict[str, int]:
    s = getattr(durum, "materyaller", None)
    if not isinstance(s, dict):
        s = {}
        durum.materyaller = s
    return s


def adet(durum, kod: str) -> int:
    try:
        return max(0, int(stok(durum).get(kod, 0)))
    except (TypeError, ValueError):
        return 0


def uret(durum, kod: str, n: int = 1) -> Dict:
    """`n` adet materyal yapar; külçe/alaşım stoğundan gram harcar."""
    m = materyal(kod)
    n = int(n)
    if m is None:
        return {"ok": False, "neden": "Böyle bir materyal yok."}
    if m.acilis_kademesi > zincir.kademe(durum):
        return {"ok": False, "neden": "{} henüz açılmadı.".format(m.ad)}
    if n <= 0:
        return {"ok": False, "neden": "Adet sıfırdan büyük olmalı."}
    gerek = m.gram * n
    eldeki = zincir.miktar(durum, m.tur, m.kaynak)
    if eldeki < gerek:
        return {"ok": False, "eksik": gerek - eldeki,
                "neden": "{} yetmiyor: {} gerek, {} var.".format(
                    kaynak_adi(m), zincir.kg_metni(gerek), zincir.kg_metni(eldeki))}
    zincir._dus(durum, m.tur, m.kaynak, gerek)
    stok(durum)[kod] = adet(durum, kod) + n
    return {"ok": True, "adet": n, "harcanan": gerek}


def uretilebilir(durum, kod: str) -> int:
    m = materyal(kod)
    if m is None or m.acilis_kademesi > zincir.kademe(durum):
        return 0
    return zincir.miktar(durum, m.tur, m.kaynak) // m.gram


# ---------------------------------------------------------------- köprüler
def acik_koprular(durum) -> List[Dict]:
    """Elinde materyali olan öğrencinin açtığı köprüler (düz veri)."""
    sonuc = []
    for m in MATERYALLER:
        if adet(durum, m.kod) > 0:
            k = m.kopru
            sonuc.append({"materyal": m.kod, "materyal_ad": m.ad, "ders": k.ders,
                          "konu": k.konu, "etiket": k.etiket, "baslik": k.baslik,
                          "aciklama": k.aciklama})
    return sonuc


def ozet(durum) -> Dict:
    """Tesisler/Üretim ekranı ve Meridyen OS için düz veri."""
    k = zincir.kademe(durum)
    return {
        "stok": {m.kod: adet(durum, m.kod) for m in MATERYALLER
                 if adet(durum, m.kod) > 0},
        "tablo": [{"kod": m.kod, "ad": m.ad, "kaynak": m.kaynak, "tur": m.tur,
                   "gram": m.gram, "kullanim": m.kullanim,
                   "acik": m.acilis_kademesi <= k,
                   "uretilebilir": uretilebilir(durum, m.kod),
                   "ders": m.kopru.ders, "konu": m.kopru.konu} for m in MATERYALLER],
        "koprular": acik_koprular(durum),
    }
