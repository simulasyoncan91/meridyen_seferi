# -*- coding: utf-8 -*-
"""
Fen Bilimleri görevleri (fizik, kimya, biyoloji).

Çerçeve: üssün LABORATUVARI. Raflarda yarım kalmış deney defterleri var:
ölçülmüş ama yorumlanmamış sayılar, adı yazılmamış çözeltiler, sonucu
kaydedilmemiş bir çaprazlama.

Bu derste de soru "formülü uygula" değil. Defter okunur, hangi büyüklüğün
eksik olduğu bulunur, hangi bağıntının işlediğine karar verilir; hesap ondan
sonra gelir.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi,
    secim_adimi, sy, yorum_adimi,
)


# ==========================================================================
# İLKOKUL - gözlemden kurala
# ==========================================================================

@bulmaca(ders="fen", konu="yuzme_batma", kademeler=(1, 5))
def yuzme_batma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Küçük ağır batmaz, büyük hafif yüzmez: asıl belirleyici yoğunluktur."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fen-yuzme-batma",
        ders="fen",
        baslik="Su Deposundaki Şaşkınlık",
        kademe=kademe,
        konu="yuzme_batma",
        kazanim="Yüzme ve batma; cismin ağırlığı ile yoğunluğu arasındaki farkı ayırt etme.",
        dikkat=5,
        brifing=(
            "{} su deposunun kapağını açık bırakmış; içine birkaç şey düşmüş.\n\n"
            "Depoyu boşaltırken herkes şaşırdı: kocaman ağır bir tahta kütük "
            "suyun yüzünde duruyordu, küçücük bir demir çivi ise dibe çökmüştü.\n\n"
            "Aşçı \"ağır olan batar\" diyor ama tahta kütük çividen çok daha "
            "ağır. Neyin battığını, neyin yüzdüğünü açıklayan kuralı bulmamız "
            "lazım; yoksa depoya bir daha ne düşse tahmin edemeyiz."
        ).format(kisi),
        kanitlar=[
            Kanit("Tartı kaydı",
                  "Tahta kütük: 4.000 gram, yüzdü.\nDemir çivi: 8 gram, battı.",
                  bedel=1, kritik=True),
            Kanit("Hacim ölçümü",
                  "Tahta kütük: 8.000 cm³\nDemir çivi: yaklaşık 1 cm³",
                  bedel=2, kritik=True),
            Kanit("Laboratuvar el kitabı",
                  "\"Bir cismin 1 cm³'ünün kaç gram geldiğine YOĞUNLUK denir. "
                  "Suyun yoğunluğu 1 g/cm³'tür. Yoğunluğu sudan küçük olan cisim "
                  "yüzer, büyük olan batar.\"", bedel=2, kritik=True),
            Kanit("Ek gözlem",
                  "Aynı tahtadan kesilen küçücük bir parça da yüzdü; demirden "
                  "yapılmış kocaman bir levha da battı.", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir cismin yüzüp yüzmeyeceğini ne belirler?",
                dogru="1 cm³'ünün kaç gram geldiği, yani yoğunluğu.",
                yanlislar={
                    "Toplam ağırlığı; ağır cisimler batar.":
                        "Toplam ağırlıkla yoğunluğu karıştırdın. Kütük "
                        "çividen 500 kat ağır ama yüzüyor; demek ki "
                        "belirleyen tartıdaki sayı değil.",
                    "Toplam büyüklüğü; büyük cisimler yüzer.":
                        "Hacme tek başına baktın. Küçük çivi de battı, "
                        "aynı tahtadan kesilen küçücük parça da yüzdü; "
                        "büyüklük iki yönde de aynı sonucu vermiyor.",
                    "Rengi ve sertliği.":
                        "Renk ve sertlik suyla hiç ilgisi olmayan "
                        "özellikler. Aynı renkte iki maddeden biri yüzüp "
                        "diğeri batabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kütük çividen 500 kat ağır ama yine de yüzüyor. Demek ki "
                    "belirleyen toplam ağırlık değil. Önemli olan aynı hacimde ne "
                    "kadar madde olduğu: 1 cm³ tahta yarım gram gelirken 1 cm³ demir "
                    "yaklaşık 8 gram gelir. Suyun 1 cm³'ü 1 gramdır; hafif kalan "
                    "yüzer, ağır kalan batar."
                ),
                ipuclari=[
                    "Küçük parça da yüzdü, büyük levha da battı. Bu neyi eler?",
                    "Aynı büyüklükte bir parça tahta ile bir parça demiri karşılaştır.",
                ],
            ),
            sayi_adimi(
                soru="Tahta kütüğün 1 cm³'ü kaç gram gelir?",
                cevap=0.5,
                birim="g/cm³",
                aciklama="4.000 g ÷ 8.000 cm³ = 0,5 g/cm³. Sudan (1 g/cm³) küçük olduğu için yüzer.",
                yaygin_yanlislar={
                    8000 / 4000.0:
                        "Bölmeyi ters kurdun: hacmi ağırlığa böldün. "
                        "Sorulan '1 cm³ kaç gram', yani gram paya gelir.",
                    4000: "Kütüğün tamamının ağırlığını yazdın. Sorulan, "
                          "o kütükten alınan tek bir cm³'ün ağırlığı.",
                },
                ipuclari=["Ağırlığı hacme böl."],
                tolerans=0.01,
                puan=12,
            ),
            yorum_adimi(
                soru="Demirden yapılan gemiler neden batmıyor?",
                dogru=("Gemi sadece demir değil; içindeki büyük hava boşluğuyla "
                       "birlikte 1 cm³'ü sudan hafif gelir."),
                yanlislar={
                    "Gemiler özel, hafif bir demirden yapılır.":
                        "Malzemeyi suçladın; oysa gemiler sıradan çelikten "
                        "yapılır. Aynı metal topak hâlinde batarken gemi "
                        "hâlinde yüzüyorsa, değişen şey malzeme değil.",
                    "Gemiler çok hızlı gittiği için batmaz.":
                        "Yüzmeyi hızla açıkladın. Limanda demirlemiş, "
                        "motoru kapalı bir gemi de yüzer.",
                    "Deniz suyu tatlı sudan çok daha yoğun olduğu için her şeyi taşır.":
                        "Deniz suyunun farkını abarttın; aradaki fark "
                        "yüzde birkaçtır. Öyle olsaydı denizde hiçbir şey "
                        "batmazdı, oysa çapa dibe gider.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yoğunluk hesabında cismin TAMAMI sayılır - içindeki boşluk da "
                    "dahil. Geminin gövdesi büyük bir hava hacmi kaplar; demir + hava "
                    "birlikte düşünüldüğünde ortalama yoğunluk sudan küçük kalır. "
                    "Aynı demir eritilip topak yapılsa hemen batar."
                ),
                puan=10,
            ),
        ],
        kapanis="Depo temizlendi, kapağa kilit takıldı. Panoya da küçük bir not asıldı: "
                "\"Batıp batmadığını ağırlık değil yoğunluk söyler.\"",
        odul={"enerji": 4, "itibar": 3},
    )


@bulmaca(ders="fen", konu="ayirma", kademeler=(2, 7))
def madde_ayirma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Karışım bozulmuş; hangi yöntemin neden işe yaradığı bulunacak."""
    durumlar = [
        {
            "karisim": "tuz ve su",
            "aciklama_karisim": "Tuz suda tamamen çözünmüş; su berrak görünüyor.",
            "yontem": "Suyu buharlaştırmak (kaynatmak); geride tuz kalır",
            "yanlislar": {
                "Süzgeç kâğıdından süzmek":
                    "Çözünmüş bir maddeyi süzmeye çalıştın. Tuz tanecikleri "
                    "su tanecikleri arasına dağılmış durumda; kâğıdın "
                    "gözeneklerinden suyla birlikte geçerler.",
                "Mıknatısla çekmek":
                    "Tuzu mıknatıstan etkilenen bir madde saydın. Mıknatıs "
                    "demir gibi birkaç metali çeker; tuz onlardan biri değil.",
                "Elekten geçirmek":
                    "Elek, tane boyutu farklı KATILARI ayırır. Kapta berrak "
                    "tek bir sıvı var; elekte tutulacak bir tane yok.",
            },
            "neden": ("Tuz suda ÇÖZÜNMÜŞTÜR; tanecikleri su tanecikleri arasına "
                      "dağılmıştır ve hiçbir süzgeçten ayrılmaz. Su buharlaşınca "
                      "tuz kapta kalır."),
        },
        {
            "karisim": "demir tozu ve kum",
            "aciklama_karisim": "İki katı toz birbirine karışmış; gözle ayırt edilemiyor.",
            "yontem": "Mıknatıs gezdirmek; demir tozu mıknatısa yapışır",
            "yanlislar": {
                "Suda kaynatmak":
                    "Kaynatma, suda ÇÖZÜNMÜŞ bir katıyı geri kazandırır. "
                    "Demir tozu da kum da suda çözünmez; su uçtuğunda ikisi "
                    "yine karışık hâlde kapta kalır.",
                "Süzgeç kâğıdından süzmek":
                    "Süzme, katıyı SIVIDAN ayırır. Burada iki katı var; "
                    "ikisi birden kâğıdın üstünde kalırdı.",
                "Buharlaştırmak":
                    "Uçurulacak bir sıvı yok. Karışımın iki bileşeni de "
                    "katı; ortada buharlaşacak bir çözücü bulunmuyor.",
            },
            "neden": ("Demir mıknatıstan etkilenir, kum etkilenmez. İki katıyı "
                      "ayırmak için aralarındaki bir FARKI kullanmak gerekir; "
                      "burada o fark mıknatıslanma özelliğidir."),
        },
        {
            "karisim": "kum ve su",
            "aciklama_karisim": "Kum suda çözünmemiş; dibe çökmüş, su bulanık.",
            "yontem": "Süzgeç kâğıdından süzmek; kum kâğıtta kalır",
            "yanlislar": [
                "Mıknatısla çekmek",
                "Buharlaştırıp kumu uçurmak",
                "Karıştırıp beklemek yeterlidir, kendiliğinden ayrışır",
            ],
            "neden": ("Kum suda çözünmez; taneleri su içinde asılı kalır ya da "
                      "dibe çöker. Çözünmemiş katı, süzgeç kâğıdının gözeneklerinden "
                      "geçemez ve orada tutulur."),
        },
        {
            "karisim": "zeytinyağı ve su",
            "aciklama_karisim": "İki sıvı karışmıyor; yağ üstte ayrı bir tabaka oluşturmuş.",
            "yontem": "Ayırma hunisiyle alttaki suyu akıtmak",
            "yanlislar": [
                "Süzgeç kâğıdından süzmek",
                "Mıknatısla çekmek",
                "Elekten geçirmek",
            ],
            "neden": ("İki sıvı birbiri içinde çözünmüyor ve yoğunlukları farklı; "
                      "bu yüzden kendiliğinden iki tabaka oluşuyor. Alttaki sıvıyı "
                      "musluktan akıtmak yeterlidir."),
        },
    ]
    durum = rastgele.choice(durumlar)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fen-madde-ayirma",
        ders="fen",
        baslik="Karışan Kaplar",
        kademe=kademe,
        konu="ayirma",
        kazanim="Karışımları ayırma yöntemleri; yöntemi maddelerin özelliğine göre seçme.",
        dikkat=5,
        brifing=(
            "Laboratuvarda bir kaza olmuş: {} rafı devirmiş ve bir kapta {} "
            "birbirine karışmış.\n\n"
            "{}\n\n"
            "İkisi de üsse lazım; dökmek yok. Hangi yöntemle ayıracağımıza karar "
            "vermemiz gerekiyor - ve yanlış yöntem denenirse malzeme heba olur."
        ).format(kisi, durum["karisim"], durum["aciklama_karisim"]),
        kanitlar=[
            Kanit("Kap incelemesi", durum["aciklama_karisim"], bedel=1, kritik=True),
            Kanit("Ayırma yöntemleri çizelgesi",
                  "Süzme: çözünmemiş KATIYI sıvıdan ayırır.\n"
                  "Buharlaştırma: ÇÖZÜNMÜŞ katıyı sıvıdan ayırır.\n"
                  "Mıknatıslanma: mıknatıstan etkilenen maddeyi ayırır.\n"
                  "Ayırma hunisi: birbiri içinde çözünmeyen SIVILARI ayırır.\n"
                  "Eleme: tane boyutu farklı katıları ayırır.",
                  bedel=2, kritik=True),
            Kanit("Laboratuvar notu",
                  "\"Yöntem, maddelerin ORTAK özelliğine değil, aralarındaki FARKA "
                  "göre seçilir. Fark neyse yöntem odur.\"", bedel=2, kritik=True),
            Kanit("Malzeme dolabı",
                  "Rafta süzgeç kâğıdı, mıknatıs, ayırma hunisi, ısıtıcı ve elek "
                  "bulunuyor. Hepsi çalışır durumda.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Ayırma yöntemini seçerken neye bakılır?",
                dogru="Karışımdaki maddelerin birbirinden AYRILAN bir özelliğine.",
                yanlislar={
                    "Karışımın toplam ağırlığına.":
                        "Ağırlık ayırma yöntemini belirlemez. Bir kilo da olsa "
                        "yüz kilo da olsa, ayrılmayı sağlayan şey maddelerin "
                        "birbirinden FARKLI olan özelliğidir.",
                    "Hangi araç dolapta hazır duruyorsa ona.":
                        "Yöntemi elindeki alete göre seçtin. Doğru sıra tersi: "
                        "önce hangi özellik farklı, sonra o farkı kullanan "
                        "araç.",
                    "Maddelerin renklerinin farklı olup olmadığına.":
                        "Rengi ayırt edici saydın. Renk gözle ayırmaya yarar "
                        "ama karışımı ayırmaz; ayırma için tanecik boyutu, "
                        "çözünürlük ya da yoğunluk gibi bir fark gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ayırma, bir farktan yararlanma işidir: çözünürlük farkı, "
                    "mıknatıslanma farkı, yoğunluk farkı, tane boyutu farkı... "
                    "Önce 'bu iki madde neyle birbirinden ayrılıyor' diye sorulur; "
                    "yöntem o farkın adıdır. Elde hangi aletin bulunduğu ölçüt değildir."
                ),
                ipuclari=[
                    "Bu iki madde hangi özellikleriyle birbirinden ayrılıyor?",
                    "Çözünmüş mü, çözünmemiş mi? Bu tek soru yöntemi belirler.",
                ],
                puan=16,
            ),
            secim_adimi(
                soru="Bu karışımı ayırmak için hangi yöntem kullanılmalı?",
                dogru=durum["yontem"],
                yanlislar=durum["yanlislar"],
                rastgele=rastgele,
                aciklama=durum["neden"],
                ipuclari=["Çizelgeyi aç ve karışımın durumuna uyan satırı bul."],
                puan=14,
            ),
            yorum_adimi(
                soru="Yanlış yöntem seçilseydi ne olurdu?",
                dogru="Maddeler ayrılmaz, üstelik bir kısmı işe yaramaz hâle gelebilirdi.",
                yanlislar={
                    "Hiçbir şey olmazdı; her yöntem eninde sonunda ayırır.":
                        "Yöntemleri birbirinin yerine geçer saydın. Her yöntem "
                        "belirli bir farkı kullanır; o fark yoksa yöntem hiçbir "
                        "şey ayırmaz, ne kadar beklersen bekle.",
                    "Karışım daha da iyi ayrılırdı, sadece daha uzun sürerdi.":
                        "Sorunu süreye indirdin. Yanlış yöntem yavaş değil, "
                        "sonuçsuzdur; süre uzatmak işe yaramaz.",
                    "Maddeler kimyasal olarak birleşir, yeni bir madde oluşurdu.":
                        "Karışımı bileşikle karıştırdın. Karışımda maddeler "
                        "kendi kimliğini korur; ayırma işlemi yeni madde "
                        "üretmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ayırma yöntemleri fiziksel yöntemlerdir: maddenin kimliğini "
                    "değiştirmezler. Ama yanlış seçilen yöntem hem işe yaramaz hem "
                    "de zarar verebilir - örneğin süzülmesi gereken bir karışımı "
                    "kaynatmak, kurtarılacak sıvıyı uçurur."
                ),
                puan=10,
            ),
        ],
        kapanis="Karışım ayrıldı, iki madde de kurtarıldı. Raf bu sefer duvara sabitlendi.",
        odul={"cevher": 4, "enerji": 4},
    )


# ==========================================================================
# FİZİK
# ==========================================================================

@bulmaca(ders="fen", konu="yogunluk", kademeler=(5, 11))
def yogunluk_teshisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Etiketsiz metal külçe; kimliği yoğunluktan bulunacak."""
    metaller = [
        ("alüminyum", 2.7), ("demir", 7.8), ("bakır", 8.9), ("kurşun", 11.3),
    ]
    ad, yogunluk = rastgele.choice(metaller)
    hacim = rastgele.choice([20, 25, 40, 50])
    kutle = round(yogunluk * hacim, 1)
    su_once = rastgele.choice([100, 150, 200])
    su_sonra = su_once + hacim

    return Bulmaca(
        kod="fen-yogunluk-teshisi",
        ders="fen",
        baslik="Etiketsiz Külçe",
        kademe=kademe,
        konu="yogunluk",
        kazanim="Yoğunluk = kütle/hacim; suyun taşırma yöntemiyle hacim ölçümü.",
        dikkat=6,
        brifing=(
            "Depoda etiketi düşmüş bir metal külçe bulundu. Görünüşünden hangi "
            "metal olduğu anlaşılmıyor; üzeri oksitlenmiş.\n\n"
            "Külçeyi eritip kullanacağız ama önce ne olduğunu bilmemiz gerekiyor: "
            "her metalin erime sıcaklığı ve kullanım yeri farklı.\n\n"
            "Laboratuvarda terazi ve dereceli silindir var. Ölçümler yapılmış, "
            "ama defterde yalnızca sayılar duruyor; kimse yorumlamamış."
        ),
        kanitlar=[
            Kanit("Terazi ölçümü", "Külçenin kütlesi: {} g".format(sy(kutle)),
                  bedel=1, kritik=True),
            Kanit("Dereceli silindir",
                  "Külçe tamamen batırılır; suyla tepkime vermez. Batırılmadan önce su seviyesi: {} mL\n"
                  "Külçe atıldıktan sonra: {} mL".format(su_once, su_sonra),
                  bedel=2, kritik=True),
            Kanit("Yoğunluk çizelgesi",
                  "Alüminyum: 2,7 g/cm³\nDemir: 7,8 g/cm³\n"
                  "Bakır: 8,9 g/cm³\nKurşun: 11,3 g/cm³", bedel=2, kritik=True),
            Kanit("Birim notu", "1 mL = 1 cm³", bedel=1, kritik=True),
            Kanit("Külçe görünümü",
                  "Yüzeyi mat ve koyu; oksit tabakası rengi gizliyor. Gözle "
                  "tanımak mümkün değil.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Külçenin hacmini nasıl buluyoruz?",
                dogru=("Suya batırınca yükselen su miktarı kadar hacim kaplar: "
                       "iki seviye arasındaki fark hacmi verir."),
                yanlislar={
                    "Külçenin kütlesi doğrudan hacmini verir.":
                        "Kütle ile hacmi aynı şey saydın. Aynı hacimde iki "
                        "farklı metal farklı kütle verir; ikisini bağlayan şey "
                        "zaten aradığımız yoğunluk.",
                    "Son su seviyesi doğrudan külçenin hacmidir.":
                        "İlk seviyeyi düşmedin. Kapta zaten su vardı; külçenin "
                        "hacmi seviyedeki ARTIŞ kadardır, son okuma kadar "
                        "değil.",
                    "İki su seviyesinin ortalaması hacmi verir.":
                        "Ortalama aldın. Taşan hacmi bulan işlem ortalama "
                        "değil, iki okumanın FARKIdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Katı bir cisim suya battığında kendi hacmi kadar suyun yerini "
                    "değiştirir; bu yüzden seviye tam o kadar yükselir. Son seviyeyi "
                    "doğrudan almak, kaptaki suyu da hacme katmak olur - düzensiz "
                    "şekilli cisimlerde bu yöntemin bütün püf noktası farkı almaktır."
                ),
                ipuclari=[
                    "Su neden yükseldi? Yerini kim aldı?",
                    "Kapta zaten su vardı; onu hacme katmalı mısın?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Külçenin hacmi kaç cm³?",
                cevap=hacim,
                birim="cm³",
                aciklama="{} − {} = {} mL = {} cm³.".format(
                    su_sonra, su_once, hacim, hacim),
                ipuclari=["İki su seviyesinin farkını al."],
                puan=10,
            ),
            sayi_adimi(
                soru="Külçenin yoğunluğu kaç g/cm³?",
                cevap=yogunluk,
                birim="g/cm³",
                aciklama="{} g ÷ {} cm³ = {} g/cm³.".format(sy(kutle), hacim, sy(yogunluk)),
                ipuclari=["Kütleyi hacme böl."],
                tolerans=0.05,
                puan=14,
            ),
            secim_adimi(
                soru="Külçe hangi metaldir?",
                dogru=ad,
                yanlislar={
                    m: "Çizelgede {} için yazan yoğunluk {} g/cm³; senin "
                       "bulduğun {} g/cm³ başka bir satıra denk geliyor. "
                       "Ölçtüğün sayıyı çizelgeyle satır satır "
                       "karşılaştır.".format(m, sy(y), sy(yogunluk))
                    for m, y in metaller if m != ad
                },
                rastgele=rastgele,
                aciklama=(
                    "Bulunan yoğunluk {} g/cm³; çizelgede bu değere karşılık gelen "
                    "metal {}. Bu soruda külçenin çizelgedeki saf metallerden biri olduğu ve aynı sıcaklıkta ölçüldüğü kabul edilir. Yoğunluk bu koşullarda ayırt etmeye yardım eder: aynı "
                    "maddeden alınan her parça - büyük ya da küçük - aynı yoğunluğu verir."
                ).format(sy(yogunluk), ad),
                ipuclari=["Bulduğun sayıyı çizelgeyle karşılaştır."],
                puan=12,
            ),
        ],
        kapanis="Külçe {} olarak kayda geçti ve ilgili rafa kaldırıldı.".format(ad),
        odul={"cevher": 7, "itibar": 4},
    )


@bulmaca(ders="fen", konu="basinc", kademeler=(6, 12))
def basinc_zemini(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı ağırlık, farklı taban alanı: depo neden battı?"""
    agirlik = rastgele.choice([4000, 6000, 8000])       # N
    dar_alan = rastgele.choice([0.5, 0.8, 1.0])         # m²
    genis_alan = dar_alan * rastgele.choice([4, 5, 8])
    dar_basinc = agirlik / dar_alan
    genis_basinc = agirlik / genis_alan
    zemin_siniri = rastgele.choice([3000, 4000, 5000])
    while not (genis_basinc < zemin_siniri < dar_basinc):
        zemin_siniri = int((dar_basinc + genis_basinc) / 2)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="fen-basinc-zemin",
        ders="fen",
        baslik="Batan Depo",
        kademe=kademe,
        konu="basinc",
        kazanim="Katı basıncı P = F/A; aynı ağırlığın farklı taban alanlarındaki etkisi.",
        dikkat=6,
        brifing=(
            "{} mevkiindeki su deposu yumuşak zemine gömülmeye başladı; bir "
            "kenarı çökmüş.\n\n"
            "Kuran ekip şaşkın: \"Depo hafifledi bile, içi yarı boş. Nasıl "
            "batar?\" diyorlar. Aynı ağırlıkta başka bir depo, aynı zeminde, "
            "yıllardır sapasağlam duruyor.\n\n"
            "İki depo arasındaki farkı bulup yeni deponun nasıl kurulacağını "
            "yazmamız gerekiyor."
        ).format(mevki),
        kanitlar=[
            Kanit("Batan depo ölçüsü",
                  "Ağırlık: {} N\nZemine oturan taban alanı: {} m²".format(
                      agirlik, sy(dar_alan)), bedel=1, kritik=True),
            Kanit("Sağlam depo ölçüsü",
                  "Ağırlık: {} N (aynı)\nZemine oturan taban alanı: {} m²".format(
                      agirlik, sy(genis_alan)), bedel=1, kritik=True),
            Kanit("Zemin etüdü",
                  "Bu zemin en fazla {} paskal (N/m²) basınca dayanır; üstünde "
                  "kalıcı çökme başlar.".format(zemin_siniri), bedel=2, kritik=True),
            Kanit("Fizik el kitabı",
                  "\"Katı basıncı: P = F / A. Aynı kuvvet daha küçük alana "
                  "uygulanırsa basınç artar. Birim: N/m² = paskal (Pa).\"",
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="İki depo aynı ağırlıkta olduğuna göre farkı ne yaratıyor?",
                dogru="Zemine oturan taban alanları farklı; basınç kuvvete değil, "
                      "kuvvet/alan oranına bağlı.",
                yanlislar={
                    "Ağırlıkları aynı olduğu için basınçları da aynıdır; sorun "
                    "zeminin nemidir.":
                        "Ağırlık ile basıncı aynı şey saydın. Basınç, ağırlığın "
                        "kaç birim alana yayıldığına bağlı; aynı ağırlık dar "
                        "tabanda daha çok bastırır.",
                    "Geniş tabanlı depo daha çok yer kapladığı için zemine daha "
                    "çok yüklenir.":
                        "İlişkiyi ters kurdun. Geniş taban ağırlığı daha büyük "
                        "alana yayar; birim alana düşen yük AZALIR.",
                    "Deponun yüksekliği belirleyicidir; yüksek olan daha çok batar.":
                        "Yüksekliği ölçüt saydın. Zemine binen şey deponun boyu "
                        "değil, ağırlığının temas alanına oranı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zemini çökerten şey toplam ağırlık değil, birim alana düşen "
                    "kuvvettir. Aynı ağırlık geniş bir tabana yayılınca her metrekareye "
                    "düşen yük azalır. Kar ayakkabısının, geniş paletli aracın ve "
                    "sivri topuğun mantığı hep budur."
                ),
                ipuclari=[
                    "Aynı ağırlık iki kat geniş tabana yayılırsa her m²'ye ne düşer?",
                    "Formülde alan payda mı pay mı?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Batan deponun zemine uyguladığı basınç kaç Pa?",
                cevap=dar_basinc,
                birim="Pa",
                aciklama="{} N ÷ {} m² = {} Pa. Zemin sınırı {} Pa; aşılmış.".format(
                    agirlik, sy(dar_alan), sy(dar_basinc), zemin_siniri),
                ipuclari=["Kuvveti alana böl."],
                tolerans=1.0,
                puan=12,
            ),
            sayi_adimi(
                soru="Sağlam deponun basıncı kaç Pa?",
                cevap=genis_basinc,
                birim="Pa",
                aciklama="{} N ÷ {} m² = {} Pa. Zemin sınırının ({} Pa) altında.".format(
                    agirlik, sy(genis_alan), sy(genis_basinc), zemin_siniri),
                ipuclari=["Aynı işlemi geniş taban için yap."],
                tolerans=1.0,
                puan=12,
            ),
            yorum_adimi(
                soru="Yeni depo için ne önerirsin?",
                dogru=("Depoyu hafifletmek yerine tabanını genişletmek; aynı "
                       "ağırlık daha büyük alana yayılınca basınç sınırın altına iner."),
                yanlislar={
                    "Deponun yüksekliğini artırmak; ağırlık yukarı dağılır.":
                        "Ağırlığın yukarı dağıldığını düşündün. Ağırlık "
                        "yukarıda da olsa aynı zemine biner; değişen tek şey "
                        "temas alanı olabilir.",
                    "Deponun içini tamamen boşaltmak dışında çare yok.":
                        "Tek çözümü yükü kaldırmak sandın. Aynı yük, daha geniş "
                        "tabana oturtularak da taşınabilir.",
                    "Depoyu daha küçük bir tabana oturtmak; temas azalır, basınç düşer.":
                        "Yönü ters aldın. Temas alanı küçüldükçe birim alana "
                        "düşen yük ARTAR; çivinin ucu bu yüzden batar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Basıncı düşürmenin iki yolu var: kuvveti azaltmak ya da alanı "
                    "büyütmek. Depoyu boşaltmak işlevini yok eder; taban plakası "
                    "eklemek ise aynı yükü daha geniş alana yayar ve sorunu çözer. "
                    "\"Temas alanını küçültmek\" seçeneği basıncı ARTIRIR."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Yeni depo geniş bir taban plakasının üstüne kuruldu. Batan depo da "
            "kaldırılıp aynı şekilde yeniden yerleştirildi."
        ),
        odul={"cevher": 6, "enerji": 5},
    )


@bulmaca(ders="fen", konu="elektrik", kademeler=(7, 13))
def devre_kesfi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Lambalar sönük yanıyor; bağlantı biçimi ve direnç bulunacak."""
    gerilim = rastgele.choice([12, 24, 36])
    direnc = rastgele.choice([2, 3, 4, 6])
    lamba_sayisi = rastgele.choice([2, 3])
    seri_direnc = direnc * lamba_sayisi
    seri_akim = gerilim / seri_direnc
    paralel_akim = gerilim / direnc

    return Bulmaca(
        kod="fen-devre-kesfi",
        ders="fen",
        baslik="Sönük Lambalar",
        kademe=kademe,
        konu="elektrik",
        kazanim="Seri ve paralel bağlama; V = I·R bağıntısı ile akım hesabı.",
        dikkat=6,
        brifing=(
            "Koridordaki {} lamba, olması gerekenden çok daha sönük yanıyor. "
            "Ampuller yeni, kaynak sağlam: {} volt.\n\n"
            "Teknisyen \"ampuller bozuk\" deyip hepsini değiştirdi; hiçbir şey "
            "değişmedi. Sonra tek bir ampulü söktü ve şaşırdı: diğerlerinin "
            "hepsi birden söndü.\n\n"
            "Sorunun ampullerde değil bağlantıda olduğunu anlamamız lazım."
        ).format(lamba_sayisi, gerilim),
        kanitlar=[
            Kanit("Teknisyen gözlemi",
                  "\"Tek ampulü söktüm, hepsi birden söndü. Taktım, hepsi "
                  "birden yandı.\"", bedel=2, kritik=True),
            Kanit("Ampul etiketi",
                  "Her ampulün direnci: {} ohm. Ampuller birbirinin aynısı; bu ideal modelde dirençleri sabit ve kaynağın iç direnci ihmal ediliyor. Ampullerin çalışma sınırları aşılmıyor.".format(direnc),
                  bedel=1, kritik=True),
            Kanit("Kaynak ölçümü", "Kaynak gerilimi: {} V".format(gerilim),
                  bedel=1, kritik=True),
            Kanit("Elektrik el kitabı",
                  "\"Seri bağlamada akım tek bir yol izler; dirençler TOPLANIR ve "
                  "bir eleman koparsa devre kesilir.\n"
                  "Paralel bağlamada her elemanın ayrı yolu vardır; biri sökülse "
                  "diğerleri yanmaya devam eder.\n"
                  "Ohm yasası: V = I × R\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Teknisyenin gözlemi bağlantı hakkında ne söylüyor?",
                dogru=("Lambalar seri bağlı; tek yol olduğu için bir eleman "
                       "koparsa akım tamamen kesilir."),
                yanlislar={
                    "Lambalar paralel bağlı; ortak kaynak hepsini birden besliyor.":
                        "Paralel bağlantıda bir lamba sökülünce ötekiler yanmaya "
                        "devam ederdi. Burada biri sökülünce hepsi sönüyor: bu "
                        "seri bağlantının işareti.",
                    "Kaynak zayıf; gerilim bütün lambalara yetmiyor.":
                        "Sorunu kaynağa yükledin. Kaynak zayıf olsaydı bir lamba "
                        "sökülünce kalanlar daha PARLAK yanardı; oysa hepsi "
                        "birden sönüyor.",
                    "Ampullerin direnci çok küçük; bu yüzden sönük yanıyorlar.":
                        "Küçük direnç daha çok akım, yani daha parlak ışık "
                        "demektir. Gözlemi açıklayan şey direncin büyüklüğü "
                        "değil, bağlantının biçimi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ayırt edici gözlem şu: BİR ampul sökülünce HEPSİ sönüyor. Bu "
                    "yalnızca seri bağlamada olur, çünkü akımın tek bir yolu vardır "
                    "ve o yol kesilince akım hiç akmaz. Paralel bağlamada her lambanın "
                    "kendi yolu olduğu için diğerleri yanmaya devam ederdi."
                ),
                ipuclari=[
                    "Evdeki lambalardan biri patlayınca diğerleri söner mi?",
                    "Bir ampulü sökmek 'yolu kesmek' anlamına geliyorsa kaç yol vardır?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Devrenin toplam direnci kaç ohm?",
                cevap=seri_direnc,
                birim="ohm",
                aciklama="Seri bağlamada dirençler toplanır: {} × {} = {} ohm.".format(
                    lamba_sayisi, direnc, seri_direnc),
                ipuclari=["Seri bağlamada dirençlere ne olur?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Devreden geçen akım kaç amper?",
                cevap=seri_akim,
                birim="A",
                aciklama="I = V / R = {} / {} = {} A.".format(
                    gerilim, seri_direnc, sy(round(seri_akim, 3))),
                ipuclari=["Ohm yasasını akımı yalnız bırakacak şekilde yaz."],
                tolerans=0.02,
                puan=14,
            ),
            yorum_adimi(
                soru=("Lambalar paralel bağlansaydı her birinden {} A akım geçerdi. "
                      "Bu ne anlama gelir?").format(sy(round(paralel_akim, 2))),
                dogru=("Her lamba daha çok akım çeker ve daha parlak yanar; ayrıca "
                       "biri bozulunca diğerleri sönmez."),
                yanlislar={
                    "Lambalar daha sönük yanar, çünkü akım paylaşılır.":
                        "Paralelde paylaşılan şey akım değil; her kola kaynağın "
                        "TAM gerilimi düşer ve her lamba kendi akımını çeker.",
                    "Hiçbir şey değişmez; bağlantı biçimi parlaklığı etkilemez.":
                        "Bağlantı biçimi tam da parlaklığı belirleyen şey. "
                        "Seride gerilim bölünür, paralelde bölünmez.",
                    "Kaynak gerilimi düşer ve devre çalışmaz.":
                        "Kaynağın gerilimi bağlantı biçimine göre değişmez; "
                        "değişen, o gerilimin lambalar arasında nasıl "
                        "dağıldığı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Seri bağlamada kaynak gerilimi lambalar arasında paylaşılır ve "
                    "toplam direnç büyüdüğü için akım küçülür - sönük yanmalarının "
                    "sebebi budur. Paralelde her lamba kaynağın tamamını görür. "
                    "Ev tesisatlarının paralel kurulmasının nedeni de tam olarak "
                    "bu iki üstünlüktür."
                ),
                puan=12,
            ),
        ],
        kapanis="Koridor tesisatı paralel bağlanacak şekilde yeniden çekildi; lambalar "
                "tam parlaklıkta yandı.",
        odul={"enerji": 8, "itibar": 4},
    )


@bulmaca(ders="fen", konu="isi", kademeler=(9, 13))
def isi_hesabi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Q = m·c·ΔT; yakıtın yeteceği hesaplanacak."""
    kutle = rastgele.choice([2000, 3000, 5000])        # gram
    # Sıcaklık farkı hep ÇİFT olsun: son yorum adımı "farkı yarıya indir" diyor,
    # tek sayıda fark orada yaklaşık bir soru üretirdi.
    ilk = rastgele.choice([10, 12, 20])
    son = rastgele.choice([60, 70, 80])
    delta = son - ilk
    c_su = 4.18
    enerji = kutle * c_su * delta                      # joule
    enerji_kj = enerji / 1000.0

    return Bulmaca(
        kod="fen-isi-hesabi",
        ders="fen",
        baslik="Kazandaki Hesap",
        kademe=kademe,
        konu="isi",
        kazanim="Isı-sıcaklık farkı; Q = m·c·ΔT bağıntısıyla enerji hesabı.",
        dikkat=6,
        brifing=(
            "Yıkanma suyu için {} kilogram su ısıtılacak. Su şu an {} °C; "
            "{} °C'ye çıkması gerekiyor.\n\n"
            "Aşçı \"kazan büyük, o yüzden çok yakıt gider\" diyor; teknisyen "
            "\"sıcaklık farkı önemli, kütle değil\" diyor. İkisi de hesap "
            "yapmamış.\n\n"
            "Yakıt sınırlı; ne kadar enerji gerektiğini bilmeden ateşi yakmak "
            "istemiyoruz."
        ).format(kutle // 1000, ilk, son),
        kanitlar=[
            Kanit("Kazan ölçümü",
                  "Su kütlesi: {} g\nBaşlangıç sıcaklığı: {} °C".format(kutle, ilk),
                  bedel=1, kritik=True),
            Kanit("Hedef", "İstenen sıcaklık: {} °C".format(son), bedel=1, kritik=True),
            Kanit("Fizik el kitabı",
                  "\"Bir maddenin sıcaklığını yükseltmek için gereken ısı:\n"
                  "Q = m × c × ΔT\n"
                  "m: kütle (g), c: öz ısı, ΔT: sıcaklık farkı (°C)\n"
                  "Suyun öz ısısı c = 4,18 J/(g·°C)\"", bedel=2, kritik=True),
            Kanit("Kazan yalıtımı",
                  "Kazan yalıtımlı; hesabımız yalnızca suyun aldığı ısıdır. Kazanın ısı kapasitesi ve çevreye ısı kaybı ihmal edilecek. Su hâl değiştirmeyecek.",
                  bedel=1, kritik=True),
            Kanit("Aşçının notu",
                  "\"Geçen sefer aynı miktarda suyu aynı koşullarda, sıcaklık farkı bugünkü hedefin yarısı olacak şekilde ısıtmıştık; "
                  "yarısı kadar yakıt gitmişti.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Gereken ısı miktarını ne belirler?",
                dogru=("Kütle, öz ısı ve sıcaklık FARKI birlikte: üçünün çarpımı."),
                yanlislar={
                    "Yalnızca ulaşılacak son sıcaklık.":
                        "Nereye çıkıldığına baktın, nereden başlandığına değil. "
                        "Aynı hedefe soğuk sudan çıkmak, ılık sudan çıkmaktan "
                        "daha çok enerji ister.",
                    "Yalnızca suyun kütlesi; sıcaklık farkı önemsizdir.":
                        "Kütleyi tek başına yeterli saydın. Aynı kütleyi bir "
                        "derece ısıtmakla elli derece ısıtmak aynı enerjiyi "
                        "istemez.",
                    "Kütle ile son sıcaklığın çarpımı.":
                        "Çarpımda son sıcaklığı kullandın. Isı hesabına giren "
                        "şey son değer değil, başlangıçla arasındaki FARK.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Isı, sıcaklığı ne kadar YÜKSELTTİĞİMİZE bağlıdır; hangi sayıya "
                    "vardığımıza değil. 10 °C'den 20 °C'ye çıkarmak ile 70 °C'den "
                    "80 °C'ye çıkarmak (aynı madde için) aynı enerjiyi ister. Hem "
                    "aşçı hem teknisyen yarı yarıya haklı: kütle de fark da çarpanlardan biri."
                ),
                ipuclari=[
                    "Formülde ΔT ne demek: son sıcaklık mı, sıcaklık farkı mı?",
                    "Aşçının notu bir ipucu veriyor: farkı yarıya inince yakıt ne oldu?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Sıcaklık farkı (ΔT) kaç °C?",
                cevap=delta,
                birim="°C",
                aciklama="{} − {} = {} °C.".format(son, ilk, delta),
                ipuclari=["Hedef sıcaklıktan başlangıcı çıkar."],
                puan=8,
            ),
            sayi_adimi(
                soru="Gereken ısı kaç kilojoule (kJ)?",
                cevap=enerji_kj,
                birim="kJ",
                aciklama=(
                    "Q = {} g × 4,18 J/(g·°C) × {} °C = {} J = {} kJ."
                ).format(kutle, delta, sy(round(enerji, 1)), sy(round(enerji_kj, 1))),
                ipuclari=[
                    "Önce joule cinsinden hesapla: m × c × ΔT.",
                    "Sonra 1000'e bölerek kilojoule'e çevir.",
                ],
                tolerans=1.0,
                puan=16,
            ),
            yorum_adimi(
                soru=("Aynı kazanı {} °C yerine {} °C'ye çıkarsak enerji nasıl "
                      "değişir?").format(son, son - delta // 2),
                dogru="Sıcaklık farkı yarıya inerse gereken enerji de yarıya iner.",
                yanlislar={
                    "Enerji değişmez; kütle aynı kaldığı için ısı da aynıdır.":
                        "Yalnızca kütleye baktın. Kütle sabit olsa da sıcaklık "
                        "farkı değişti; ısı ikisinin çarpımıyla belirlenir.",
                    "Enerji dörtte bire iner; ısı farkın karesiyle değişir.":
                        "Kare ilişkisi uydurdun. Isı, sıcaklık farkıyla DOĞRU "
                        "orantılıdır: fark yarıya inerse enerji de yarıya "
                        "iner.",
                    "Enerji artar; düşük sıcaklığa ısıtmak daha zordur.":
                        "Yönü ters aldın. Daha az ısıtmak daha az enerji "
                        "ister; zorluk sıcaklığın düşüklüğünde değil, farkın "
                        "büyüklüğünde.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Q = m·c·ΔT bağıntısında ΔT doğrusal bir çarpandır: yarıya inince "
                    "Q da yarıya iner. Aşçının hatırladığı gözlem de bunu doğruluyor. "
                    "Karesel bir bağıntı olsaydı dörtte bire inerdi, ama burada öyle değil."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Ateş, hesaplanan enerjiye göre ayarlandı. Kazan zamanında ısındı "
            "ve yakıttan da artırdık."
        ),
        odul={"enerji": 9, "erzak": 4},
    )


# ==========================================================================
# KİMYA
# ==========================================================================

@bulmaca(ders="fen", konu="derisim", kademeler=(7, 13))
def tuzlu_su_derisimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kütlece yüzde derişim; seyreltme sonrası derişim."""
    tuz = rastgele.choice([20, 30, 40, 50])
    su = rastgele.choice([180, 220, 270, 350])
    cozelti = tuz + su
    yuzde = tuz / cozelti * 100
    eklenen_su = rastgele.choice([100, 150, 200])
    yeni_cozelti = cozelti + eklenen_su
    yeni_yuzde = tuz / yeni_cozelti * 100

    return Bulmaca(
        kod="fen-derisim",
        ders="fen",
        baslik="Adı Yazılmamış Çözelti",
        kademe=kademe,
        konu="derisim",
        kazanim="Kütlece yüzde derişim; seyreltmede çözünen miktarının değişmemesi.",
        dikkat=6,
        brifing=(
            "Laboratuvar rafında etiketsiz bir şişe var. Yanındaki deney "
            "defterinde şöyle yazıyor: \"{} g tuz, {} g suda çözüldü.\"\n\n"
            "Ama derişimi kimse yazmamış. Üstelik dünkü nöbetçi, şişeye "
            "\"seyreltmek için\" {} g daha su eklemiş ve bunu da deftere "
            "geçirmiş.\n\n"
            "Çözeltinin şu anki derişimini bulup etiketi yeniden yazmamız "
            "gerekiyor."
        ).format(tuz, su, eklenen_su),
        kanitlar=[
            Kanit("Deney defteri - ilk kayıt",
                  "Çözünen (tuz): {} g\nÇözücü (su): {} g".format(tuz, su),
                  bedel=1, kritik=True),
            Kanit("Deney defteri - ikinci kayıt",
                  "\"Şişeye {} g saf su eklendi. Tuz eklenmedi, tuz "
                  "alınmadı.\"".format(eklenen_su), bedel=2, kritik=True),
            Kanit("Kimya el kitabı",
                  "\"Kütlece yüzde derişim = (çözünen kütlesi ÷ ÇÖZELTİ kütlesi) × 100\n"
                  "Çözelti kütlesi = çözünen + çözücü\"", bedel=2, kritik=True),
            Kanit("Nöbetçi notu",
                  "\"Su ekledim ama tuza dokunmadım; şişedeki tuz miktarı aynı.\"",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Yüzde derişim hesaplanırken paydaya ne yazılır?",
                dogru="Çözeltinin toplam kütlesi (çözünen + çözücü)",
                yanlislar={
                    "Yalnızca çözücünün (suyun) kütlesi":
                        "Paydaya yalnızca suyu yazdın. Yüzde derişim, tuzun "
                        "ÇÖZELTİ içindeki payıdır; çözelti ise su ile tuzun "
                        "toplamıdır.",
                    "Yalnızca çözünenin (tuzun) kütlesi":
                        "Payla paydaya aynı şeyi yazdın; sonuç her zaman %100 "
                        "çıkardı. Payda bütünü, yani çözeltinin tamamını "
                        "göstermeli.",
                    "Çözücü ile çözünenin farkı":
                        "Fark aldın. Çözelti iki maddenin farkından değil, "
                        "TOPLAMINDAN oluşur; ikisi de kapta duruyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Derişim, \"çözeltinin yüzde kaçı çözünendir\" sorusunun cevabıdır; "
                    "bu yüzden payda çözeltinin TAMAMIDIR. Paydaya yalnızca suyu yazmak "
                    "en sık yapılan hatadır ve derişimi olduğundan büyük gösterir - "
                    "seyreltik çözeltilerde fark küçük görünür ama derişiklerde büyür."
                ),
                ipuclari=[
                    "\"Çözeltinin yüzde kaçı tuz?\" diye sorulunca bütün nedir?",
                    "Tuz + su karışınca ortaya çıkan sıvının adı ne?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Su eklenmeden önce çözeltinin kütlece yüzde derişimi neydi?",
                cevap=yuzde,
                birim="%",
                aciklama="{} ÷ ({} + {}) × 100 = {} ÷ {} × 100 = %{}.".format(
                    tuz, tuz, su, tuz, cozelti, sy(round(yuzde, 2))),
                ipuclari=["Önce çözelti kütlesini bul, sonra oranla."],
                tolerans=0.05,
                puan=14,
            ),
            sayi_adimi(
                soru="Su eklendikten sonra derişim yüzde kaç oldu?",
                cevap=yeni_yuzde,
                birim="%",
                aciklama=(
                    "Tuz miktarı değişmedi ({} g), ama çözelti {} g oldu. "
                    "{} ÷ {} × 100 = %{}."
                ).format(tuz, yeni_cozelti, tuz, yeni_cozelti, sy(round(yeni_yuzde, 2))),
                ipuclari=[
                    "Su eklenince tuz miktarı değişti mi?",
                    "Payı sabit tut, paydayı güncelle.",
                ],
                tolerans=0.05,
                puan=16,
            ),
            yorum_adimi(
                soru="Seyreltme sırasında ne değişti, ne değişmedi?",
                dogru=("Tuzun kütlesi değişmedi; çözeltinin kütlesi arttığı için "
                       "derişim azaldı."),
                yanlislar={
                    "Tuzun kütlesi azaldı, çünkü suya dağıldı.":
                        "Dağılmayı yok olmak sandın. Tuz çözeltinin içinde "
                        "duruyor; kütlesi aynı kalır, yalnızca daha çok suya "
                        "yayılır.",
                    "Hem tuz hem çözelti kütlesi arttı.":
                        "Kaba yalnızca su eklendi. Çözelti kütlesi arttı ama "
                        "tuz miktarına dokunulmadı.",
                    "Derişim değişmedi; su eklemek derişimi etkilemez.":
                        "Derişimi tuzun kendisi sandın. Derişim bir ORANdır; "
                        "payda büyürken pay sabit kalırsa oran küçülür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Seyreltmenin tanımı budur: çözünen sabit kalır, çözücü artar, "
                    "oran küçülür. Tuz \"kaybolmaz\", yalnızca daha çok suyun içine "
                    "dağılır. Bu yüzden seyreltme sorularında pay hep aynı kalır; "
                    "yalnızca payda büyür."
                ),
                puan=12,
            ),
        ],
        kapanis="Şişeye yeni etiket yazıldı: kütlece %{} tuzlu su.".format(
            sy(round(yeni_yuzde, 2))),
        odul={"enerji": 5, "cevher": 4},
    )


@bulmaca(ders="fen", konu="ph", kademeler=(9, 13))
def ph_olcegi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """pH logaritmiktir: 2 birim fark 100 kat demektir."""
    # ph_b'nin 7'yi (nötr) aşmaması için üst sınır dikkatle seçildi:
    # iki kuyunun da asidik kalması gerekiyor, yoksa yorum adımı yanlış olur.
    ph_a = rastgele.choice([2, 3])
    fark = rastgele.choice([2, 3])
    ph_b = ph_a + fark
    kat = 10 ** fark
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="fen-ph-olcegi",
        ders="fen",
        baslik="İki Kuyu",
        kademe=kademe,
        konu="ph",
        kazanim="pH ölçeğinin logaritmik olması; bir birim farkın 10 kat anlamına gelmesi.",
        dikkat=6,
        brifing=(
            "{} bölgesindeki iki kuyunun suyu 25 °C sıcaklıkta ölçüldü. Birinin pH değeri {}, "
            "diğerininki {}.\n\n"
            "Sağlık görevlisi rapora \"aralarında {} birim fark var, çok da "
            "önemli değil\" diye yazmış. Kimya sorumlusu bu cümleyi görünce "
            "raporu geri çevirdi.\n\n"
            "Farkın gerçekte ne anlama geldiğini yazmamız gerekiyor."
        ).format(mevki, ph_a, ph_b, fark),
        kanitlar=[
            Kanit("Kuyu ölçümleri",
                  "Birinci kuyu pH: {}\nİkinci kuyu pH: {}".format(ph_a, ph_b),
                  bedel=1, kritik=True),
            Kanit("Kimya el kitabı",
                  "\"pH ölçeği LOGARİTMİKTİR. pH 1 birim AZALDIĞINDA asitlik "
                  "(H+ derişimi) 10 KAT ARTAR. pH 7 nötrdür; 7'nin altı asidik, "
                  "üstü baziktir.\"", bedel=2, kritik=True),
            Kanit("Örnek çizelge",
                  "pH 6 → pH 5 : asitlik 10 kat artar\n"
                  "pH 6 → pH 4 : asitlik 100 kat artar\n"
                  "pH 6 → pH 3 : asitlik 1000 kat artar",
                  bedel=2, kritik=True),
            Kanit("Sağlık görevlisinin raporu",
                  "\"{} ile {} arasında sadece {} birim var; iki kuyu da "
                  "benzer sayılır.\"".format(ph_a, ph_b, fark), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="pH ölçeğinde 1 birimlik fark ne anlama gelir?",
                dogru="Asitliğin (H+ derişiminin) 10 kat değişmesi",
                yanlislar={
                    "Asitliğin 1 birim değişmesi; ölçek doğrusaldır":
                        "Ölçeği doğrusal saydın. pH logaritmik bir ölçektir: "
                        "her basamak eşit bir MİKTAR değil, sabit bir KAT "
                        "farkı anlatır.",
                    "Asitliğin 2 kat değişmesi":
                        "Katsayıyı 2 aldın. pH ölçeği onluk tabanlıdır; bir "
                        "basamak iki kat değil on kat fark demektir.",
                    "Asitliğin yüzde 1 değişmesi":
                        "Yüzde bir değişim ölçeğin tamamını anlamsız kılardı; "
                        "pH farkları çok daha büyük değişimleri anlatmak için "
                        "vardır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "pH logaritmik bir ölçektir: her basamak 10 katlık bir sıçramadır. "
                    "Bu yüzden \"sadece birkaç birim\" ifadesi yanıltıcıdır. Aynı "
                    "mantık deprem büyüklüğü ve ses şiddeti ölçeklerinde de geçerlidir."
                ),
                ipuclari=[
                    "Ölçek doğrusal olsaydı çizelgedeki katlar neden 10, 100, 1000 gitsin?",
                    "Her basamakta sayı nasıl büyüyor: toplanarak mı, çarpılarak mı?",
                ],
                puan=20,
            ),
            sayi_adimi(
                soru=("pH {} olan su, pH {} olan sudan kaç kat daha "
                      "asidiktir?").format(ph_a, ph_b),
                cevap=kat,
                birim="kat",
                aciklama="Fark {} birim; 10^{} = {} kat.".format(fark, fark, kat),
                ipuclari=[
                    "Her birim 10 kat. Fark kaç birim?",
                    "10'u fark kadar kez kendisiyle çarp.",
                ],
                tolerans=0.5,
                puan=16,
            ),
            secim_adimi(
                soru="İki kuyunun suyu da asidik mi?",
                dogru=("İkisi de asidik; ikisinin de pH değeri 7'nin altında."
                       if ph_b < 7 else
                       "Biri asidik, diğeri nötre yakın; pH 7 sınırdır."),
                yanlislar={
                    "İkisi de bazik; pH değerleri 0'dan büyük.":
                        "Sıfırı sınır saydın. Asit-baz sınırı 7'dir; 0'dan "
                        "büyük olmak bir şey söylemez, çünkü ölçeğin tamamı "
                        "0'dan büyüktür.",
                    "İkisi de nötr; pH farkı olsa da ikisi de içilebilir.":
                        "Nötr tek bir değerdir, bir aralık değil. İki farklı pH "
                        "birden nötr olamaz.",
                    "Belirlenemez; pH tek başına asitlik hakkında bilgi vermez.":
                        "pH'ın tanımı zaten asitliği ölçmek. Elinde tam da bu "
                        "soruya cevap veren ölçüm var.",
                },
                rastgele=rastgele,
                aciklama=(
                    "pH 7 nötrdür. {} ve {} değerlerinin ikisi de 7'nin altında "
                    "kaldığı için iki su da asidiktir; ama aralarındaki {} birimlik "
                    "fark, asitliklerinin {} kat farklı olduğu anlamına gelir."
                ).format(ph_a, ph_b, fark, kat),
                ipuclari=["Nötr nokta kaçtır? Değerler onun altında mı üstünde mi?"],
                puan=12,
            ),
            yorum_adimi(
                soru="Sağlık görevlisinin cümlesi neden düzeltilmeli?",
                dogru=("\"Sadece {} birim\" ifadesi ölçeği doğrusal sanmaktan "
                       "geliyor; gerçek fark {} kat.").format(fark, kat),
                yanlislar={
                    "Düzeltilmesine gerek yok; sayısal olarak doğru yazmış.":
                        "Cümleyi sayı olarak doğru saydın. Sayı doğru olsa bile "
                        "\"kat\" ile \"birim\" aynı şey değildir; logaritmik "
                        "ölçekte bu ayrım cümlenin anlamını değiştirir.",
                    "Yalnızca üslup sorunu var, içerik doğru.":
                        "Sorunu biçime indirdin. Yanlış olan kelime seçimi değil, "
                        "farkın büyüklüğü hakkında verdiği bilgi.",
                    "Yanlış; asıl fark daha küçüktür, görevli abartmış.":
                        "Yönü ters aldın. Logaritmik ölçekte gerçek fark, "
                        "basamak sayısının anlattığından çok daha BÜYÜKtür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sayı doğru okunmuş ama ölçek yanlış yorumlanmış. Logaritmik "
                    "ölçeklerde 'küçük görünen fark' büyük bir gerçek farkı gizler. "
                    "Bir raporda önemli olan sayının kendisi değil, o sayının hangi "
                    "ölçekte okunduğudur."
                ),
                puan=14,
            ),
        ],
        kapanis=(
            "Rapor düzeltildi: iki kuyu arasındaki asitlik farkı {} kat olarak "
            "yazıldı. İki su da asidik; kullanım uygunluğu için ayrıca inceleme istendi."
        ).format(kat),
        odul={"enerji": 6, "itibar": 6},
    )


# ==========================================================================
# BİYOLOJİ
# ==========================================================================

@bulmaca(ders="fen", konu="kalitim", kademeler=(8, 13))
def kalitim_caprazlamasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Çaprazlama yapılmış ama sonucu yazılmamış; taşıyıcılık kavranacak."""
    ozellik = rastgele.choice([
        ("koyu tüy", "açık tüy", "K", "k"),
        ("uzun kulak", "kısa kulak", "U", "u"),
        ("siyah yün", "beyaz yün", "S", "s"),
    ])
    baskin_ad, cekinik_ad, B, c = ozellik
    yavru_sayisi = rastgele.choice([8, 12, 16, 20])
    cekinik_beklenen = yavru_sayisi // 4
    baskin_beklenen = yavru_sayisi - cekinik_beklenen

    return Bulmaca(
        kod="fen-kalitim",
        ders="fen",
        baslik="Yazılmamış Çaprazlama",
        kademe=kademe,
        konu="kalitim",
        kazanim="Punnett karesi; melez çaprazlamada 3:1 oranı ve taşıyıcılık.",
        dikkat=6,
        brifing=(
            "Üssün hayvan çiftliğinde bir çaprazlama yapılmış ama sonucu "
            "deftere yazılmamış.\n\n"
            "Çaprazlanan iki hayvan da {}. Buna rağmen doğan yavruların bir "
            "kısmı {} çıkmış ve çiftlik sorumlusu şaşırmış: \"İkisi de {} idi, "
            "bu nasıl olur? Yavrular karışmış olmalı.\"\n\n"
            "Karışma olup olmadığını anlamamız gerekiyor; sürü kayıtları buna bağlı."
        ).format(baskin_ad, cekinik_ad, baskin_ad),
        kanitlar=[
            Kanit("Çiftlik defteri",
                  "Ana: {} ({}{})\nBaba: {} ({}{})\n"
                  "Toplam yavru: {}".format(baskin_ad, B, c, baskin_ad, B, c, yavru_sayisi),
                  bedel=2, kritik=True),
            Kanit("Kalıtım el kitabı",
                  "\"Baskın gen ({}) tek başına bile özelliği gösterir. Çekinik "
                  "özellik ({}) ancak iki çekinik gen bir araya gelirse ortaya "
                  "çıkar. {}{} yazılışı MELEZDİR: dıştan baskın görünür ama "
                  "çekinik geni taşır.\"".format(B, c, B, c),
                  bedel=2, kritik=True),
            Kanit("Punnett karesi şablonu",
                  "        {}      {}\n"
                  "  {}   {}{}    {}{}\n"
                  "  {}   {}{}    {}{}".format(B, c, B, B, B, B, c, c, B, c, c, c),
                  bedel=2, kritik=True),
            Kanit("Veteriner raporu",
                  "\"Yavruların hepsi bu iki hayvana ait; karışma yok. Kayıtlar "
                  "ve gözlemler bunu doğruluyor.\"", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="İki {} anne babadan {} yavru nasıl doğabilir?".format(
                    baskin_ad, cekinik_ad),
                dogru=("Anne baba melezdir ({}{}): dıştan baskın görünürler ama "
                       "ikisi de çekinik geni taşır.").format(B, c),
                yanlislar={
                    "Doğamaz; yavrular başka hayvanlara aittir.":
                        "Gözlemi reddettin. Yavrular orada; açıklanması gereken "
                        "şey onların varlığı, yokluğu değil.",
                    "Baskın gen zamanla zayıflamıştır.":
                        "Genlerin yıprandığını düşündün. Genler zamanla "
                        "zayıflamaz; çekinik özellik anne babada gizli "
                        "taşınıyordu ve yavruda ortaya çıktı.",
                    "Yavrulardan biri sonradan renk değiştirmiştir.":
                        "Sonradan değişim aradın. Bu özellik doğuştan gelen "
                        "gen çiftiyle belirlenir; sonradan değişmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir canlının GÖRÜNÜŞÜ ile GENİ aynı şey değildir. {}{} yazılışlı "
                    "bir hayvan dıştan {} görünür, ama çekinik geni de taşır ve "
                    "yavrusuna verebilir. İki taşıyıcı bir araya gelirse yavrulardan "
                    "bir kısmı çekinik geni çift alır ve {} olur."
                ).format(B, c, baskin_ad, cekinik_ad),
                ipuclari=[
                    "Görünüş ile taşınan gen aynı şey mi?",
                    "Çekinik özelliğin ortaya çıkması için kaç çekinik gen gerekir?",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="Bu çaprazlamada beklenen görünüş oranı nedir?",
                dogru="3 {} : 1 {}".format(baskin_ad, cekinik_ad),
                yanlislar={
                    "1 {} : 1 {}".format(baskin_ad, cekinik_ad):
                        "Dört olası birleşimi ikiye indirdin. İki melez "
                        "bireyin çaprazında dört farklı gen çifti çıkar; "
                        "bunların yalnızca biri çekinik görünür.",
                    "4 {} : 0 {}".format(baskin_ad, cekinik_ad):
                        "Çekinik özelliğin hiç çıkmayacağını düşündün. Her iki "
                        "ebeveyn de çekinik geni taşıdığı için o gen bir "
                        "yavruda buluşabilir.",
                    "1 {} : 3 {}".format(baskin_ad, cekinik_ad):
                        "Oranı ters yazdın. Baskın özellik dört birleşimin "
                        "üçünde görünür, birinde değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Punnett karesinde dört kutu çıkar: {}{}, {}{}, {}{}, {}{}. "
                    "İlk üçü dıştan {} görünür (biri saf, ikisi melez), yalnızca "
                    "{}{} olan {} görünür. Bu yüzden görünüş oranı 3:1'dir."
                ).format(B, B, B, c, c, B, c, c, baskin_ad, c, c, cekinik_ad),
                ipuclari=["Punnett karesindeki dört kutuyu tek tek yaz ve say."],
                puan=16,
            ),
            sayi_adimi(
                soru="{} yavrudan kaçının {} olması beklenir?".format(
                    yavru_sayisi, cekinik_ad),
                cevap=cekinik_beklenen,
                birim="yavru",
                aciklama="{} yavrunun 1/4'ü = {}. Beklenen diğer {} yavru {} görünür; gerçek sayılar farklı olabilir.".format(
                    yavru_sayisi, cekinik_beklenen, baskin_beklenen, baskin_ad),
                ipuclari=["Oran 3:1 ise çekinik olanlar toplamın kaçta kaçıdır?"],
                puan=14,
            ),
            yorum_adimi(
                soru=("Gerçekte {} yerine biraz farklı sayıda {} yavru doğsa "
                      "hesap yanlış mı olurdu?").format(cekinik_beklenen, cekinik_ad),
                dogru=("Hayır; 3:1 bir OLASILIK oranıdır, az sayıda yavruda "
                       "sapma normaldir."),
                yanlislar={
                    "Evet; oran her doğumda tam olarak gerçekleşmek zorundadır.":
                        "Oranı bir garanti saydın. Beklenen oran çok sayıda "
                        "doğumda ortaya çıkar; tek bir batında sapma olağandır.",
                    "Evet; sapma varsa anne babanın geni yanlış belirlenmiştir.":
                        "Küçük bir sapmadan büyük bir sonuç çıkardın. Az "
                        "sayıda yavruda sapma beklenen bir şeydir; gen "
                        "belirlemesini çürütmez.",
                    "Hayır; çünkü oran zaten yaklaşık bir tahmindir ve hiçbir "
                    "şey öngörmez.":
                        "Ters uca gittin. Oran öngörü yapar; yalnızca bu "
                        "öngörü tek tek doğumlar için değil, çoğunluk için "
                        "geçerlidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Punnett karesi her yavru için ayrı ayrı geçerli bir olasılık "
                    "verir; zar atmak gibi. Dört zar atışında bir kez altı gelmesi "
                    "şart değildir, ama dört yüz atışta oran 1/6'ya yaklaşır. "
                    "Kalıtımda da yavru sayısı arttıkça gerçek oran beklenene yaklaşır."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Deftere yazıldı: karışma yok, anne baba melez. Sürü kayıtları "
            "taşıyıcılık bilgisiyle birlikte güncellendi."
        ),
        odul={"erzak": 7, "itibar": 5},
    )


@bulmaca(ders="fen", konu="fotosentez", kademeler=(8, 13))
def sinirlayici_etmen(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Grafiğin düzleşen kısmı: artık başka bir şey sınırlıyor."""
    plato_isik = rastgele.choice([40, 50, 60])
    sicaklik = rastgele.choice([18, 20, 22])

    return Bulmaca(
        kod="fen-sinirlayici-etmen",
        ders="fen",
        baslik="Seranın Sırrı",
        kademe=kademe,
        konu="fotosentez",
        kazanim="Fotosentez hızını etkileyen etmenler; sınırlayıcı etmen kavramı.",
        dikkat=6,
        brifing=(
            "Üssün serasında verim düşük. Ekip lamba ekleyerek ışığı artırmış; "
            "ilk başta bitkiler hızlanmış, sonra hiçbir şey değişmemiş.\n\n"
            "Deney defterinde ölçümler var: ışık şiddeti artırıldıkça fotosentez "
            "hızı da artmış, ama {} birimden sonra grafik düzleşmiş. Işığı iki "
            "katına çıkarmak bile bir şey değiştirmemiş.\n\n"
            "Ekip \"daha çok lamba alalım\" diyor. Bunun işe yarayıp "
            "yaramayacağına karar vermemiz gerekiyor; lamba pahalı ve enerji "
            "harcıyor."
        ).format(plato_isik),
        kanitlar=[
            Kanit("Deney defteri - ışık ölçümü",
                  "Işık 10 → hız düşük\nIşık 20 → hız arttı\nIşık 30 → hız arttı\n"
                  "Işık {} → hız arttı\nIşık {} → DEĞİŞMEDİ\n"
                  "Işık {} → DEĞİŞMEDİ".format(plato_isik, plato_isik + 20, plato_isik + 40),
                  bedel=2, kritik=True),
            Kanit("Kontrollü karşılaştırma", "Işık, sıcaklık ve su sabitken yalnızca CO₂ artırıldı; fotosentez hızı yükseldi. CO₂ eski düzeye dönünce hız tekrar düştü.", bedel=2, kritik=True),
            Kanit("Sera koşulları",
                  "Sıcaklık: {} °C (sabit)\nKarbondioksit: sera kapalı, "
                  "havalandırma çalışmıyor\nSu: yeterli".format(sicaklik),
                  bedel=2, kritik=True),
            Kanit("Biyoloji el kitabı",
                  "\"Fotosentez hızını ışık, karbondioksit ve sıcaklık birlikte "
                  "etkiler. Bir etmen artırıldığında hız bir yere kadar artar; "
                  "sonra en YETERSİZ olan etmen hızı belirlemeye başlar. Buna "
                  "SINIRLAYICI ETMEN denir.\"", bedel=2, kritik=True),
            Kanit("Havalandırma kaydı",
                  "Sera fanı iki haftadır arızalı; kapılar da sıkı kapatılmış "
                  "durumda.", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Grafiğin düzleştiği nokta neyi gösterir?",
                dogru=("Işığın artık sınırlayıcı olmadığını; hızı başka bir "
                       "etmenin belirlemeye başladığını."),
                yanlislar={
                    "Bitkilerin fotosentez yapma yeteneğini kaybettiğini.":
                        "Düzleşmeyi durma sandın. Grafik düşmüyor, sabit "
                        "kalıyor: fotosentez tam hızla sürüyor ama artık "
                        "ışıkla hızlanmıyor.",
                    "Işığın bitkilere zarar vermeye başladığını.":
                        "Zarar olsaydı eğri düşerdi. Yatay bir çizgi zararı "
                        "değil, doyuma ulaşmayı gösterir.",
                    "Ölçüm aletinin bozulduğunu.":
                        "Aleti suçladın. Düzleşme beklenen bir davranıştır: "
                        "bir noktadan sonra hızı belirleyen şey ışık olmaktan "
                        "çıkar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir etmeni artırdıkça hız artıyorsa, o etmen sınırlayıcıdır. "
                    "Artırmaya devam ettiğinde hız değişmiyorsa, artık başka bir şey "
                    "sınırlıyordur - tıpkı yemek yaparken un bitince şeker eklemenin "
                    "işe yaramaması gibi. Düzleşen grafik bir arıza değil, bir bilgidir."
                ),
                ipuclari=[
                    "Işık artıyor ama hız artmıyorsa, hızı ne tutuyor olabilir?",
                    "Sera koşulları kartında hangi değer şüpheli görünüyor?",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="Bu serada şu anda sınırlayıcı etmen hangisidir?",
                dogru="Karbondioksit; sera kapalı ve fan arızalı olduğu için CO₂ tükeniyor.",
                yanlislar={
                    "Işık; daha fazla lamba gerekiyor.":
                        "Grafiğin düzleştiği yerde ışığı sınırlayıcı saydın. "
                        "Işık sınırlayıcı olsaydı eğri hâlâ yükseliyor olurdu.",
                    "Su; bitkilere yeterince su verilmiyor.":
                        "Kayıtlarda su eksikliğine dair bir ölçüm yok. "
                        "Sınırlayıcı etmen, elindeki veriyle gösterilebilen "
                        "olmalı.",
                    "Toprak; besin maddesi kalmamış.":
                        "Toprak tükenmesi elindeki ölçümlerle desteklenmiyor. "
                        "Deneyde değiştirilen ve ölçülen şey ışıktı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Su yeterli, sıcaklık makul ve ışık artırıldığında bir etki "
                    "olmuyor. Bunlar tek başına CO₂ eksikliğini kanıtlamaz. Kontrollü karşılaştırmada yalnız CO₂ artırılınca hızın yükselmesi bu yorumu destekliyor. Kapalı serada bitkiler "
                    "havadaki karbondioksiti tüketiyor ve fan arızalı olduğu için "
                    "yerine yenisi gelmiyor. Kanıtların birleştiği nokta burası."
                ),
                ipuclari=[
                    "Hangi koşul kartı bir arıza bildiriyor?",
                    "Kapalı bir serada bitkiler havadan neyi alır ve o biterse ne olur?",
                ],
                puan=16,
            ),
            yorum_adimi(
                soru="Ekibin \"daha çok lamba alalım\" önerisi işe yarar mı?",
                dogru=("Hayır; sınırlayıcı etmen ışık olmadığı için ek lamba "
                       "yalnızca enerji harcar."),
                yanlislar={
                    "Evet; ışık ne kadar artarsa fotosentez o kadar hızlanır.":
                        "İlişkiyi sınırsız saydın. Grafik bir noktadan sonra "
                        "düzleşiyor: o noktadan sonra eklenen ışık hıza bir "
                        "şey katmıyor.",
                    "Evet; ama ancak lamba sayısı iki katına çıkarılırsa.":
                        "Miktarı artırarak doyum noktasını aşacağını düşündün. "
                        "Doyumdan sonra ışığın miktarı değil, başka bir etmen "
                        "belirleyici.",
                    "Belirlenemez; fotosentez hızı tahmin edilemez.":
                        "Elinde tam da bunu gösteren bir grafik var; eğrinin "
                        "biçimi soruya cevap veriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sınırlayıcı olmayan bir etmeni artırmak sonucu değiştirmez. "
                    "Doğru çözüm fanı onarmak, yani asıl darboğazı açmaktır. Bu, "
                    "yalnızca biyolojiye özgü değil: her sistemde iyileştirme, en "
                    "zayıf halkadan başlar."
                ),
                puan=14,
            ),
        ],
        kapanis=(
            "Fan onarıldı, sera havalandırıldı. Ek lamba alınmadı ve verim bir "
            "hafta içinde yükseldi."
        ),
        odul={"erzak": 8, "enerji": 5},
    )


@bulmaca(ders="fen", konu="ekosistem", kademeler=(7, 12))
def enerji_piramidi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Besin zincirinde enerji aktarımı; üst basamakların az olmasının nedeni."""
    uretici = rastgele.choice([10000, 20000, 50000])   # kJ
    birinci = uretici // 10
    ikinci = birinci // 10

    return Bulmaca(
        kod="fen-enerji-piramidi",
        ders="fen",
        baslik="Neden Az Kurt Var",
        kademe=kademe,
        konu="ekosistem",
        kazanim="Besin zincirinde enerji aktarımı; enerji piramidinin daralması.",
        dikkat=5,
        brifing=(
            "Bölgedeki av hayvanlarının sayımı yapıldı ve komutan bir soru "
            "sordu: \"Ot her yerde, geyik epeyce var, ama kurt neden bu kadar az? "
            "Kurtları mı avlıyorlar?\"\n\n"
            "Ekoloji ekibi ölçümleri yapmış: bir yılda bitkilerin ürettiği "
            "toplam enerji {} kJ. Ama zincirin üst basamaklarında ne kadar enerji "
            "kaldığını kimse hesaplamamış.\n\n"
            "Kurt sayısının az olmasının doğal mı yoksa yapay mı olduğunu "
            "belirlememiz gerekiyor."
        ).format(uretici),
        kanitlar=[
            Kanit("Ekoloji ölçümü",
                  "Üreticiler (bitkiler) bir yılda: {} kJ enerji üretiyor.".format(uretici),
                  bedel=1, kritik=True),
            Kanit("Biyoloji el kitabı",
                  "\"Besin zincirinde bir basamaktan diğerine enerjinin ancak "
                  "yaklaşık %10'u aktarılır; bu sorunun hesabında aktarımı %10 kabul ediyoruz. Kalan %90 solunumla ısıya dönüşür, "
                  "hareket ve yaşamsal işler için harcanır ya da sindirilemeden "
                  "atılır.\"", bedel=2, kritik=True),
            Kanit("Besin zinciri şeması",
                  "Ot → Geyik → Kurt\n"
                  "(üretici) (birincil tüketici) (ikincil tüketici)",
                  bedel=1, kritik=True),
            Kanit("Av kaydı",
                  "Bölgede son üç yılda kurt avlandığına dair hiçbir kayıt yok. "
                  "Geyik sayısı da sabit.", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Üst basamaklarda daha az canlı bulunmasının temel nedeni nedir?",
                dogru=("Her basamakta enerjinin yalnızca küçük bir kısmı bir üste "
                       "aktarılır; geri kalanı harcanır."),
                yanlislar={
                    "Üst basamaktaki hayvanlar daha çok avlandığı için.":
                        "Sebebi insan avcılığına bağladın. Piramidin biçimi "
                        "avcılık olmasa da aynıdır; sebep enerjinin her "
                        "basamakta azalması.",
                    "Üst basamaktaki hayvanlar daha az yavru yaptığı için.":
                        "Üreme hızını sebep saydın. Az yavru yapmak sonuçtur; "
                        "asıl sınır, üst basamağa ulaşan enerjinin azlığı.",
                    "Üst basamaktaki hayvanlar daha uzun yaşadığı için.":
                        "Ömür uzunluğu sayıyı azaltmaz. Kaç canlının "
                        "beslenebileceğini belirleyen şey mevcut enerji.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir geyik yediği otun enerjisinin çoğunu yaşamak için harcar; "
                    "yalnızca küçük bir kısmı vücudunda birikir ve onu yiyene geçer. "
                    "Bu örnekte %10 enerji aktarımı varsayılıyor; canlı sayısı veya biyokütle aynı oranda azalmak zorunda değildir. Enerji azalması "
                    "enerjinin canlıların yaşamsal faaliyetlerinde kullanılması ve ısı olarak çevreye yayılmasıyla ilişkilidir."
                ),
                ipuclari=[
                    "Bir geyik yediği otun enerjisinin tamamını vücudunda mı tutar?",
                    "Harcanan enerji nereye gidiyor?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Geyiklere (birincil tüketicilere) kaç kJ enerji aktarılır?",
                cevap=birinci,
                birim="kJ",
                aciklama="{} kJ'ün %10'u = {} kJ.".format(uretici, birinci),
                ipuclari=["Üretici enerjisinin yüzde kaçı bir üst basamağa geçer?"],
                tolerans=1.0,
                puan=12,
            ),
            sayi_adimi(
                soru="Kurtlara (ikincil tüketicilere) kaç kJ enerji ulaşır?",
                cevap=ikinci,
                birim="kJ",
                aciklama=(
                    "Geyiklere ulaşan {} kJ'ün yine %10'u: {} kJ. Yani bitkilerin "
                    "ürettiği enerjinin yalnızca yüzde biri kurtlara kalıyor."
                ).format(birinci, ikinci),
                ipuclari=["Aynı %10 kuralını bir kez daha uygula."],
                tolerans=1.0,
                puan=14,
            ),
            yorum_adimi(
                soru="Komutanın sorusuna ne cevap vereceksin?",
                dogru=("Üst basamağa daha az enerji ulaşması daha az kurdu destekleyebilir; "
                       "gerçek sayının normal olduğunu bu veriler tek başına kanıtlamaz."),
                yanlislar={
                    "Kurtların azlığının tek ve kesin nedeni kaçak avlanmadır.":
                        "Elinde olmayan bir sebep uydurdun. Sayıların bu "
                        "biçimde olması için kaçak avlanmaya gerek yok; "
                        "besin piramidi zaten bunu öngörüyor.",
                    "Geyik sayısı fazla olduğu için kurtlar yer bulamıyor.":
                        "İlişkiyi ters kurdun. Av bolluğu yırtıcıyı azaltmaz; "
                        "yırtıcı sayısını sınırlayan şey avın enerjisinin "
                        "yalnızca küçük bir kısmının ona geçmesi.",
                    "Bölgede bitki örtüsü yetersiz; asıl sorun otlarda.":
                        "Tabanı sorunlu saydın. Kayıtlarda otların yetersiz "
                        "olduğunu gösteren bir şey yok; piramit zaten sağlıklı "
                        "bir sistemde de üste doğru daralır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Av kaydı temiz, geyik sayısı sabit ve bitki üretimi yüksek. "
                    "Av kaydının olmaması hiç av yapılmadığını kanıtlamaz. Enerji piramidi olası bir açıklamadır; üst basamağa "
                    "ulaşan enerji, ancak az sayıda büyük yırtıcıyı besleyebilir. "
                    "Ekosistemin durumunu değerlendirmek için zaman içindeki sayımlar, hastalık ve yaşam alanı verileri de gerekir."
                ),
                puan=14,
            ),
        ],
        kapanis=(
            "Rapora yazıldı: üst basamaklara daha az enerji ulaşıyor; kurt sayısının normal olup olmadığı henüz belirlenemez. Avlanma "
            "kararı için ek saha verisi toplanacak; izleme sürdürülecek."
        ),
        odul={"erzak": 6, "itibar": 6},
    )


@bulmaca(ders="fen", konu="mikroskop", kademeler=(5, 10))
def mikroskop_buyutmesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Toplam büyütme çarpımdır; gerçek boyut bölmeyle bulunur."""
    okuler = rastgele.choice([5, 10, 15])
    objektif = rastgele.choice([4, 10, 40])
    toplam = okuler * objektif
    # Gerçek boyu önce seçip görüntüyü ondan üretiyoruz; tersi yapılırsa
    # 0,3 mikrometrelik "hücre" gibi gerçekçi olmayan sonuçlar çıkıyor.
    gercek = rastgele.choice([10, 20, 25, 40, 50])      # mikrometre
    gorunen_mm = gercek * toplam / 1000.0               # milimetre

    return Bulmaca(
        kod="fen-mikroskop",
        ders="fen",
        baslik="Mercekteki Sayı",
        kademe=kademe,
        konu="mikroskop",
        kazanim="Mikroskopta toplam büyütme; görüntü boyutundan gerçek boyuta geçiş.",
        dikkat=5,
        brifing=(
            "Laboratuvardaki mikroskopla su örneğine bakıldı ve bir hücrenin "
            "boyu ölçüldü: görüntüde {} milimetre.\n\n"
            "Deney defterine bu sayı \"hücre boyu\" diye yazılmış. Ama bu, "
            "büyütülmüş görüntünün boyu; hücrenin gerçek boyu değil.\n\n"
            "Mikroskobun üzerinde iki ayrı sayı var ve kimse hangisinin "
            "kullanılacağını bilmiyor."
        ).format(sy(gorunen_mm)),
        kanitlar=[
            Kanit("Oküler merceği", "Üzerinde yazan: {}x".format(okuler),
                  bedel=1, kritik=True),
            Kanit("Objektif merceği", "Üzerinde yazan: {}x".format(objektif),
                  bedel=1, kritik=True),
            Kanit("Mikroskop el kitabı",
                  "\"Toplam büyütme = oküler büyütmesi × objektif büyütmesi.\n"
                  "Fotoğraftan boy ölçmek için ayrıca görüntü ölçeğinin kalibrasyonu gerekir.\"", bedel=2, kritik=True),
            Kanit("Görüntü kalibrasyonu", "Bu sorudaki sabit boyutlu görüntü, ölçek cetveliyle kalibre edilmiş: görüntüdeki uzunluk gerçek uzunluğun {} katı. Görüntü yeniden boyutlandırılmamış.".format(toplam), bedel=2, kritik=True),
            Kanit("Ölçüm kaydı",
                  "Görüntüdeki hücre boyu: {} mm".format(sy(gorunen_mm)),
                  bedel=1, kritik=True),
            Kanit("Birim çizelgesi", "1 mm = 1000 mikrometre", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Mikroskobun toplam büyütmesi nasıl bulunur?",
                dogru="İki merceğin büyütmeleri ÇARPILIR.",
                yanlislar={
                    "İki merceğin büyütmeleri TOPLANIR.":
                        "Büyütmeleri topladın. İkinci mercek, birincinin "
                        "ürettiği görüntüyü yeniden büyütür; art arda gelen "
                        "büyütmeler toplanmaz, çarpılır.",
                    "Büyük olan mercek doğrudan toplam büyütmedir.":
                        "Yalnızca birini saydın. Işık iki mercekten de geçiyor; "
                        "ikisi de görüntüyü büyütüyor.",
                    "İki merceğin büyütmelerinin ortalaması alınır.":
                        "Ortalama aldın. Ortalama, iki merceğin yerine tek bir "
                        "mercek koymak gibi olurdu; oysa etkileri üst üste "
                        "biniyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Işık önce objektiften geçip büyütülüyor, sonra bu büyütülmüş "
                    "görüntü okülerden geçip bir kez daha büyütülüyor. Art arda iki "
                    "büyütme uygulandığı için etkileri çarpılır. Toplamak, ikinci "
                    "merceğin birinciden çıkan görüntüyü değil, orijinali büyüttüğünü "
                    "varsaymak olurdu."
                ),
                ipuclari=[
                    "Görüntü kaç mercekten geçiyor? Her biri ne yapıyor?",
                    "Bir şeyi 2 kat, sonra o sonucu 3 kat büyütürsen toplam kaç kat olur?",
                ],
                puan=16,
            ),
            sayi_adimi(
                soru="Mikroskobun toplam büyütmesi kaç kattır?",
                cevap=toplam,
                birim="kat",
                aciklama="{} × {} = {} kat.".format(okuler, objektif, toplam),
                ipuclari=["İki mercek sayısını çarp."],
                puan=10,
            ),
            sayi_adimi(
                soru="Hücrenin gerçek boyu kaç mikrometredir?",
                cevap=gercek,
                birim="mikrometre",
                aciklama="{} mm = {} mikrometre; {} ÷ {} = {} mikrometre.".format(
                    sy(gorunen_mm), sy(gorunen_mm * 1000), sy(gorunen_mm * 1000),
                    toplam, sy(gercek)),
                ipuclari=[
                    "Önce görüntü boyunu mikrometreye çevir (1 mm = 1000 mikrometre).",
                    "Sonra görünen boyu toplam büyütmeye böl.",
                ],
                tolerans=0.05,
                puan=14,
            ),
            yorum_adimi(
                soru="Objektif {}x yerine daha küçük bir mercekle değiştirilseydi ne olurdu?".format(
                    objektif),
                dogru=("Toplam büyütme azalır; hücre daha küçük görünür ama gerçek "
                       "boyu elbette değişmez."),
                yanlislar={
                    "Hücrenin gerçek boyu da küçülürdü.":
                        "Görüntü ile nesneyi karıştırdın. Mikroskop hücreyi "
                        "değiştirmez, yalnızca onu nasıl gördüğünü değiştirir.",
                    "Toplam büyütme artardı.":
                        "Küçük mercekle büyütmenin artacağını düşündün. Toplam "
                        "büyütme iki merceğin çarpımı; çarpanlardan biri "
                        "küçülürse sonuç da küçülür.",
                    "Görüntü değişmezdi; yalnızca oküler büyütmeyi belirler.":
                        "Objektifi devre dışı bıraktın. Toplam büyütmeye iki "
                        "mercek de girer; birini değiştirmek sonucu "
                        "değiştirir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Mikroskop nesneyi değiştirmez, yalnızca görüntüsünü büyütür. "
                    "Bu yüzden ölçümü kaydederken hangi büyütmede yapıldığını yazmak "
                    "şarttır; büyütme yazılmamış bir ölçüm, gerçek boyuta çevrilemez."
                ),
                puan=10,
            ),
        ],
        kapanis="Deftere düzeltme yazıldı: gerçek hücre boyu {} mikrometre, {} kat "
                "büyütmeyle ölçüldü.".format(sy(round(gercek, 3)), toplam),
        odul={"enerji": 5, "itibar": 4},
    )
