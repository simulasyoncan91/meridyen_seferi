# -*- coding: utf-8 -*-
"""
Sayıya kesme işaretiyle bitişen eklerin ses uyumu denetimi (B37.16).

NEDEN VAR
Görevler sayıları şablondan üretiyor: "%{}'i geri kazanılıyor". Ek, sayının
OKUNUŞUNA uymak zorunda -- "%80'i" (seksen) doğru ama "%60'i" yanlış, doğrusu
"%60'ı" (altmış). Değer kümesi tesadüfen tek bir eke uyduğu sürece hata
görünmez; biri kümeye yeni bir değer eklediği an sessizce bozulur. 16 Eylül
2026'da geri dönüşüm görevinde tam olarak bu oldu ve denetleyici göremedi.

KAPSAM -- BİLİNÇLİ OLARAK DAR
Yalnız TAM SAYILAR. Sayının okunuşu kesin: son okunan sözcük ek ünlüsünü ve
sert/yumuşak ünsüzü belirler. Harf kısaltmaları (V, A, kg) DIŞARIDA: "40 V'a"
mı "40 V'ye" mi, okunuşa göre ikisi de savunulabilir ve yanlış alarm üretir.
Denetleyicinin "noktalamadan önce boşluk" kuralı tam da bu yüzden geri
çekilmişti (861 isabetin çoğu kasıtlıydı).

Tanınmayan ek biçimleri (sıra sayısı "'ncı", zincirler) SESSİZCE ATLANIR:
emin olunamayan yerde alarm vermemek, yanlış alarm vermekten iyidir.
"""
from __future__ import annotations

import re
from typing import List, Tuple

_BIRLER = {1: "bir", 2: "iki", 3: "üç", 4: "dört", 5: "beş",
           6: "altı", 7: "yedi", 8: "sekiz", 9: "dokuz"}
_ONLAR = {1: "on", 2: "yirmi", 3: "otuz", 4: "kırk", 5: "elli",
          6: "altmış", 7: "yetmiş", 8: "seksen", 9: "doksan"}

_UNLULER = "aeıioöuü"
_KALIN = set("aıou")
_SERT = set("fstkçşhp")          # fıstıkçı şahap


def son_sozcuk(sayi: int) -> str:
    """Bir tam sayının okunuşundaki SON sözcük (ekin uyacağı sözcük)."""
    if sayi == 0:
        return "sıfır"
    if sayi % 10:
        return _BIRLER[sayi % 10]
    if sayi % 100:
        return _ONLAR[(sayi // 10) % 10]
    if sayi % 1000:
        return "yüz"
    if sayi % 1_000_000:
        return "bin"
    if sayi % 1_000_000_000:
        return "milyon"
    return "milyar"


def _son_unlu(sozcuk: str) -> str:
    return next(h for h in reversed(sozcuk) if h in _UNLULER)


def _iki_yollu(unlu: str) -> str:
    return "a" if unlu in _KALIN else "e"


def _dort_yollu(unlu: str) -> str:
    return {"a": "ı", "ı": "ı", "e": "i", "i": "i",
            "o": "u", "u": "u", "ö": "ü", "ü": "ü"}[unlu]


def beklenen(sayi: int, ek: str) -> str:
    """`ek`in bu sayıya uyan doğru biçimi; ek tanınmazsa boş dizgi.

    Yalnız ekin İLK biçimbirimi denetlenir; ardından gelen zincir ("'daki",
    "'dan") olduğu gibi korunur.
    """
    sozcuk = son_sozcuk(sayi)
    unlu = _son_unlu(sozcuk)
    iki, dort = _iki_yollu(unlu), _dort_yollu(unlu)
    unluyle_biter = sozcuk[-1] in _UNLULER
    sert = sozcuk[-1] in _SERT
    d = "t" if sert else "d"

    # Sıra sayısı ("'ncı", "'inci") ve bilinmeyen biçimler: denetleme.
    if re.match(r"^[ıiuü]?nc", ek):
        return ""

    # -DIr  (bildirme): dır dir dur dür tır tir tur tür
    m = re.match(r"^[dt][ıiuü]r", ek)
    if m:
        return d + dort + "r" + ek[3:]
    # -DAn  (ayrılma) ve -DA (bulunma): dan den tan ten / da de ta te
    m = re.match(r"^[dt][ae]", ek)
    if m:
        return d + iki + ek[2:]
    # -lAr / -lIk: yalnız ünlü uyumu
    m = re.match(r"^l([ae])r", ek)
    if m:
        return "l" + iki + "r" + ek[3:]
    m = re.match(r"^l([ıiuü])k", ek)
    if m:
        return "l" + dort + "k" + ek[3:]
    # -lI ("5'li turlar", "1990'lı yıllar")
    m = re.match(r"^l[ıiuü](?![a-zçğıöşü])", ek)
    if m:
        return "l" + dort
    # -(s)I(n)DA(n) iyelik + hâl zinciri: "%20'sinden", "%10'undan". İlgi
    # ekinden ÖNCE denenmeli; yoksa "inden" ilgi eki sanılıp yanlış düzeltilir
    # ("20'ninden" önerilirdi, doğrusu "20'sinden"). n'den sonra D hep "d".
    m = re.match(r"^(s?)([ıiuü])n[dt]([ae])(n?)", ek)
    if m:
        uzunluk = m.end()
        return (("s" if unluyle_biter else "") + dort + "nd"
                + _iki_yollu(dort) + m.group(4) + ek[uzunluk:])
    # -(n)In (ilgi): ın in un ün / nın nin nun nün
    m = re.match(r"^n?[ıiuü]n(?![ıiuüc])", ek)
    if m:
        uzunluk = m.end()
        return ("n" if unluyle_biter else "") + dort + "n" + ek[uzunluk:]
    # -(y)A (yönelme): a e / ya ye
    m = re.match(r"^y?[ae](?![a-zçğıöşü])", ek)
    if m:
        return ("y" if unluyle_biter else "") + iki
    # -(y)I belirtme / -(s)I iyelik: ı i u ü / yı yi yu yü / sı si su sü
    m = re.match(r"^([ys]?)[ıiuü](?![a-zçğıöşü])", ek)
    if m:
        tampon = m.group(1)
        if unluyle_biter:
            if tampon:
                return tampon + dort
            # Tamponsuz ek HER ZAMAN yanlış; ama belirtme mi ("%12'yi geçme")
            # iyelik mi ("2/9'si kadar") sözdiziminden anlaşılır. İkisini de
            # öneriyoruz, tek birini uydurmuyoruz.
            return "s" + dort + "/y" + dort
        return dort              # ünsüzle bitende tampon olmamalı
    return ""


# "a/b" kesir, "SS:DD" saat; ikisi de ayrıca yakalanır (aşağıda). Önünde ","
# ya da "." varsa ondalık/binlik parçası: atlanır.
_EK_KALIBI = re.compile(r"(?<![\d.,:/])(?:(\d+)([/:]))?(\d+)'([a-zçğıöşü]+)")


def _saat_okunusu(saat: str, dakika: str) -> int:
    """SAAT: "18:00'de" -> "on sekizde", "07:30'da" -> "yedi otuzda".

    Dakika sıfırsa saat okunur, değilse dakika. İlk sürüm saatleri hiç
    denetlemiyordu ("00" sıfır sanılınca ~150 yanlış alarm çıkmıştı); bu
    yüzden nakliyedeki "sabah {}'de" gibi kalıplar görünmüyordu.
    """
    return int(saat) if int(dakika) == 0 else int(dakika)


def hatalari_bul(metin: str) -> List[Tuple[str, str]]:
    """Metindeki uyumsuz ekler: [(yazılan, doğrusu), ...].

    KESİRLERİN İKİ OKUNUŞU VAR: "3/5" hem "beşte üç" (ek payı izler: "3/5'ü")
    hem "üç bölü beş" (ek paydayı izler: "3/5'i") diye okunur. Yalnız HİÇBİR
    okunuşa uymayan ek hatadır ("2/9'i": ne "dokuzda ikisi" ne "iki bölü
    dokuzu"). Önerilen düzeltme yazıda yerleşik olan pay okunuşudur.
    """
    sonuc = []
    for m in _EK_KALIBI.finditer(metin):
        pay, ayrac, sayi_metni, ek = m.groups()
        if ayrac == ":":
            dogru = beklenen(_saat_okunusu(pay, sayi_metni), ek)
            govde = "{}:{}".format(pay, sayi_metni)
        elif pay:
            dogru = beklenen(int(pay), ek)
            if ek == beklenen(int(sayi_metni), ek):
                continue
            govde = "{}/{}".format(pay, sayi_metni)
        else:
            dogru = beklenen(int(sayi_metni), ek)
            govde = sayi_metni
        if dogru and dogru != ek:
            sonuc.append(("{}'{}".format(govde, ek), "{}'{}".format(govde, dogru)))
    return sonuc
