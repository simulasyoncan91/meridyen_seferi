# -*- coding: utf-8 -*-
"""
Kimya görevleri (lise, 9-13).

Çerçeve: üssün TEPKİME MASASI. Masada yarım yazılmış denklemler var:
maddeler biliniyor, katsayılar boş. Sorulan şey "şu denklemi denkleştir"
değil; kapalı bir sığınakta ne kadar oksijenin harcanacağı, denklemi
denkleştirmeden bilinemiyor.

Fen Bilimleri (ortaokul) kaldırılmadı; bu modül onun üstüne biner.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import PERSONEL, ad_sec, model_adimi, sayi_adimi, yorum_adimi


# Katsayılar: (yakıt, O₂, CO₂, H₂O)
_YANMALAR = [
    {"ad": "metan", "formul": "CH₄", "kats": (1, 2, 1, 2),
     "denk": "CH₄ + 2O₂ → CO₂ + 2H₂O"},
    {"ad": "propan", "formul": "C₃H₈", "kats": (1, 5, 3, 4),
     "denk": "C₃H₈ + 5O₂ → 3CO₂ + 4H₂O"},
    {"ad": "etan", "formul": "C₂H₆", "kats": (2, 7, 4, 6),
     "denk": "2C₂H₆ + 7O₂ → 4CO₂ + 6H₂O"},
    {"ad": "bütan", "formul": "C₄H₁₀", "kats": (2, 13, 8, 10),
     "denk": "2C₄H₁₀ + 13O₂ → 8CO₂ + 10H₂O"},
]


# ==========================================================================
# TEPKİME DENKLEŞTİRME - katsayı, oran ve harcanan oksijen
# ==========================================================================

@bulmaca(ders="kimya", konu="denklestirme", kademeler=(9, 13), agirlik=1.2)
def yanma_denklestirme(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yanma denklemini denkleştirip mol oranından harcanan O₂'yi bulma."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    yanma = rastgele.choice(_YANMALAR)
    yakit_k, o2_k, co2_k, su_k = yanma["kats"]

    kat = rastgele.choice([2, 3, 4, 5])
    mol_yakit = yakit_k * kat          # oran tam çıksın
    mol_o2 = o2_k * kat
    # Oksijen ATOMU sayısı: en sık yapılan hata bunu molekül sanmak.
    oksijen_atomu = 2 * co2_k + su_k

    return Bulmaca(
        kod="kimya-yanma-denklestirme",
        ders="kimya",
        baslik="Isıtıcının Oksijen Hesabı",
        kademe=kademe,
        konu="denklestirme",
        kazanim="Kimyasal denklem denkleştirme; katsayıların mol oranı olarak "
                "okunması ve kütlenin korunumu.",
        dikkat=6,
        brifing=(
            "Fırtına yüzünden ekip yeraltı sığınağına indi. Ekip, dışarıda çalışacak ısıtıcı için {} "
            "gazının tam yanmasında harcanacak oksijeni hesaplıyor.\n\n"
            "{} hatırlatıyor: \"Kapı kapalı, hava sınırlı. Bu ısıtıcı içeride çalıştırılırsa bizim "
            "soluduğumuz oksijeni de yakacak.\"\n\n"
            "Masadaki tepkime kâğıdında maddeler yazılı ama önlerindeki "
            "sayılar boş bırakılmış. Ne kadar oksijenin gideceğini o sayıları "
            "koymadan söylemek mümkün değil."
        ).format(yanma["ad"], kisi),
        kanitlar=[
            Kanit("Tepkime kâğıdı",
                  "{} + O₂ → CO₂ + H₂O\n(katsayılar yazılmamış)".format(
                      yanma["formul"]),
                  bedel=1, kritik=True),
            Kanit("Isıtıcı çizelgesi",
                  "Bu vardiyada yakılacak yakıt: {} mol {}".format(
                      mol_yakit, yanma["ad"]),
                  bedel=1, kritik=True),
            Kanit("Kimya el kitabı",
                  "\"Denkleştirmede yalnızca formüllerin ÖNÜNDEKİ katsayılar "
                  "değiştirilir; alt indisler maddenin kimliğidir. Her element "
                  "için atom sayısı iki yanda eşit olmalıdır. Katsayılar en "
                  "küçük tam sayı olacak biçimde sadeleştirilir. Denkleşmiş "
                  "denklemdeki katsayılar aynı zamanda mol oranını verir.\"",
                  bedel=2, kritik=True),
            Kanit("Sığınak havalandırma notu",
                  "Isıtıcı sığınakta çalıştırılmayacak. Bu hesap yalnızca yeterli oksijenle TAM YANMA modelidir; ortamın güvenli olduğunu göstermez.", bedel=1),
            Kanit("Depo kaydı",
                  "Yedek tüplerin son basınç ölçümü on gün önce yapıldı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir denklemi denkleştirirken neyi değiştirmeye hakkımız var?",
                dogru=("Yalnızca formüllerin önündeki katsayıları; alt indisler "
                       "maddenin kimliğidir, dokunulmaz."),
                yanlislar={
                    "Gerekirse alt indisleri de değiştiririz; önemli olan atom "
                    "sayılarının tutmasıdır.":
                        "İndise dokundun. H₂O'yu H₂O₂ yaparsan denklem tutar "
                        "ama artık sudan değil, oksijenli sudan söz ediyorsun. "
                        "Denkleştirme maddeleri değil, kaç tane olduklarını ayarlar.",
                    "Sol ve sağdaki molekül sayılarını eşitleriz.":
                        "Korunan şeyi molekül sayısı sandın. Tepkimede korunan "
                        "ATOM sayısıdır; molekül sayısı iki yanda pekâlâ farklı "
                        "olabilir.",
                    "Katsayıların toplamı iki yanda eşit olsun, yeter.":
                        "Toplama baktın. Denklik her element için AYRI AYRI "
                        "sağlanmalıdır; toplamların tutması hiçbir şeyi "
                        "garanti etmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Denklemin iki yanında aynı atomlar bulunur; tepkimede atomlar "
                    "yok olmaz, yalnızca yeniden dizilir. Alt indis bir molekülün "
                    "İÇ yapısıdır - onu değiştirmek maddeyi değiştirmek demektir. "
                    "Elimizdeki tek serbestlik, her maddeden kaç tane olduğunu "
                    "söyleyen katsayılardır."
                ),
                ipuclari=[
                    "H₂O'daki 2'yi değiştirirsen elinde hâlâ su var mı?",
                    "Katsayı 'kaç tane', indis 'içinde kaç atom' demek.",
                ],
                cozum=(
                    "1) Her elementin iki yandaki atom sayısı yazılır.\n"
                    "2) Yalnızca katsayılar değiştirilerek bu sayılar eşitlenir; "
                    "önce karbon, sonra hidrojen, en son oksijen ayarlanır.\n"
                    "3) Kesirli katsayı çıkarsa tüm denklem uygun sayıyla çarpılır.\n"
                    "Bu tepkimenin denkleşmiş hâli: {}"
                ).format(yanma["denk"]),
                puan=18,
            ),
            sayi_adimi(
                soru="En küçük pozitif tam sayı katsayılarla denkleştirildiğinde O₂ katsayısı kaçtır?",
                cevap=o2_k,
                aciklama=(
                    "Denkleşmiş hâli: {}. Sağ tarafta {} oksijen ATOMU var; "
                    "bunlar O₂ molekülü olarak geldiği için ikiye bölünür ve "
                    "O₂ katsayısı {} çıkar."
                ).format(yanma["denk"], oksijen_atomu, o2_k),
                yaygin_yanlislar={
                    oksijen_atomu:
                        "Oksijen ATOMLARINI saydın, molekülleri değil. Oksijen "
                        "tepkimeye O₂ olarak giriyor; her molekülde iki atom var.",
                    "*": "Önce karbonu, sonra hidrojeni sağda karşıla; oksijeni "
                         "her zaman en sona bırak. Oksijeni erken sabitlersen "
                         "sonraki adımda geri dönmek zorunda kalırsın.",
                },
                ipuclari=[
                    "Karbonu ve hidrojeni sağda karşıla; oksijeni en sona bırak.",
                    "Sağdaki toplam oksijen atomunu bul, sonra O₂ molekülüne çevir.",
                ],
                tolerans=0.01,
                puan=14,
            ),
            sayi_adimi(
                soru="Isıtıcı {} mol {} yakacak. Bunun için kaç mol O₂ "
                     "harcanır?".format(mol_yakit, yanma["ad"]),
                cevap=mol_o2,
                birim="mol",
                aciklama=(
                    "Katsayılar mol oranıdır: {} mol yakıt başına {} mol O₂. "
                    "{} mol yakıt için {} × {} ÷ {} = {} mol oksijen gerekir."
                ).format(yakit_k, o2_k, mol_yakit, mol_yakit, o2_k, yakit_k, mol_o2),
                yaygin_yanlislar={
                    mol_yakit:
                        "Yakıt molünü olduğu gibi yazdın; oranı 1'e 1 saydın. "
                        "Denklem her yakıt molü için birden çok O₂ istiyor.",
                    "*": "Oranı denklemden kur: O₂ katsayısı bölü yakıt "
                         "katsayısı. Bu oranı yakıtın mol sayısıyla çarp.",
                },
                ipuclari=[
                    "Denklemdeki iki katsayının oranını kur.",
                    "Yakıtın mol sayısını bu oranla çarp.",
                ],
                tolerans=0.01,
                puan=16,
            ),
            yorum_adimi(
                soru="Sığınak tümüyle kapalı olsaydı, içerideki toplam kütle "
                     "yanma sonunda nasıl değişirdi?",
                dogru=("Değişmezdi; atomlar yok olmadı, yalnızca yeni "
                       "moleküllere dizildi."),
                yanlislar={
                    "Azalırdı; yakıt tükendiği için kütlesi de ortadan kalkar.":
                        "Yanmayı yok olma saydın. Yakıtın karbonu ve hidrojeni "
                        "kaybolmadı; CO₂ ile H₂O'nun içine geçti.",
                    "Artardı; tepkimeye oksijen katıldığı için toplam büyür.":
                        "Oksijeni dışarıdan gelmiş gibi saydın. Kapalı "
                        "sığınakta oksijen zaten içerideydi; sayıma ikinci kez "
                        "girmez.",
                    "Su buharı yoğuşursa azalır, gaz kalırsa değişmez.":
                        "Kütleyi maddenin hâline bağladın. Sıvıya dönen su "
                        "aynı moleküllerdir ve hâlâ kapta durur; hâl değişimi "
                        "kütleyi değiştirmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Denkleştirmenin dayandığı fikir tam olarak budur: iki yanda "
                    "aynı atomlar bulunur. Kapalı bir kapta girenlerin toplam "
                    "kütlesi çıkanların toplam kütlesine eşittir. Değişen şey "
                    "kütle değil, atomların hangi moleküllerde toplandığıdır - ve "
                    "ekip için asıl mesele de bu: oksijen yok olmadı ama artık "
                    "solunabilir hâlde değil."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Gerekli oksijen miktarı rapora yazıldı. Bu miktar tek başına kapalı bir "
            "ortamda güvenli çalışma süresi vermez. Tepkime kâğıdı katsayılarıyla "
            "birlikte panoya asıldı."
        ),
        odul={"enerji": 7, "erzak": 4},
    )
