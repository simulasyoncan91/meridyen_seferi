# -*- coding: utf-8 -*-
"""
Geri bildirim paketi: oyuncunun yazdığı not + ilerleme kayıtları, tek zip.

NEDEN VAR
---------
Deneme sürümünü birine verip "nasıl gitti?" diye sorduğunda gelen cevap
genelde "güzeldi" ya da "bir yerde takıldım" olur. İkisi de işe yaramaz.
İşe yarayan şey, o kişinin NEREDE takıldığını gösteren kayıt dosyasıdır.

Ama kimseden "kayitlar klasörünü bul ve zip'le" denmesi beklenemez. Oyun
bunu kendisi yapmalı.

NE KOYULUR, NE KOYULMAZ
-----------------------
Koyulan: oyuncunun yazdığı metin, kayıt dosyaları (oyun içi ilerleme),
Python ve işletim sistemi sürümü (hata ayıklamak için gerekiyor).

Koyulmayan: başka hiçbir şey. Bilgisayardaki dosyalar taranmıyor, ağa
hiçbir şey gönderilmiyor, kişisel klasörlere bakılmıyor. Paket diske
yazılır ve gönderip göndermemeye oyuncu karar verir.

**Paket oluşturulmadan ÖNCE içindekiler ekranda listelenir.** Bu bir
nezaket değil, kuraldır: birinden dosya istiyorsan ne istediğini
göstereceksin.
"""
from __future__ import annotations

import io
import json
import os
import platform
import sys
import time
import zipfile
from typing import Dict, List, Optional, Tuple

from oyun.motor import durum as durum_modulu

PAKET_KLASORU_ADI = "geri_bildirim"


def paket_klasoru() -> str:
    """Paketler oyunun yanına yazılır: oyuncu klasörü zaten biliyor."""
    kok = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(kok, PAKET_KLASORU_ADI)


def kayit_dosyalari(yalnizca_kimlik: Optional[str] = None) -> List[str]:
    """Pakete girecek kayıt dosyalarının tam yolları.

    `yalnizca_kimlik` verilirse SADECE o öğrencinin kaydı döner.

    NEDEN BU PARAMETRE VAR (8 Eylül 2026 düzeltmesi):
    İlk hâli klasördeki BÜTÜN öğrenci kayıtlarını pakete koyuyordu.
    Öğretmen parolasını ve sınıf tanımlarını elemiştim ama asıl sorunu
    kaçırmıştım: okulda `MERIDYEN_KAYIT` ortak bir klasöre bakar ve orada
    bütün sınıfın kayıtları durur. Yani bir öğrencinin gönderdiği geri
    bildirim paketi SINIF ARKADAŞLARININ ilerlemesini de taşıyordu.

    Öğrenci kendi verisini gönderir. Öğretmenin toplu inceleme ihtiyacı
    ayrı bir iştir ve öğretmen masasından, parolayla yapılır.
    """
    klasor = durum_modulu.KAYIT_KLASORU
    if not os.path.isdir(klasor):
        return []
    aranan = (yalnizca_kimlik or "").strip().lower()
    bulunan = []
    for ad in sorted(os.listdir(klasor)):
        if not ad.endswith(".json"):
            continue
        yol = os.path.join(klasor, ad)
        try:
            with io.open(yol, encoding="utf-8") as dosya:
                veri = json.load(dosya)
        except Exception:          # noqa: BLE001 - bozuk dosya atlanir
            continue
        # Yalnizca OGRENCI kayitlari. Ogretmen parolasi ozeti
        # (ogretmen.json) ve sinif tanimlari pakete GIRMEZ.
        if not (isinstance(veri, dict) and "dersler" in veri):
            continue
        if aranan and os.path.splitext(ad)[0].lower() != aranan:
            continue
        bulunan.append(yol)
    return bulunan


def icerik_ozeti(yalnizca_kimlik: Optional[str] = None) -> Dict[str, object]:
    """Pakete ne gireceğinin dökümü. Oluşturmadan ÖNCE gösterilir."""
    dosyalar = kayit_dosyalari(yalnizca_kimlik)
    adlar = []
    for yol in dosyalar:
        try:
            with io.open(yol, encoding="utf-8") as dosya:
                veri = json.load(dosya)
            adlar.append("{}  ({} görev)".format(
                veri.get("ad", "?"), veri.get("oynanan_gorev", 0)))
        except Exception:          # noqa: BLE001
            adlar.append(os.path.basename(yol))
    return {
        "kayit_sayisi": len(dosyalar),
        "kayitlar": adlar,
        "ortam": "{} · Python {}".format(platform.platform(),
                                         platform.python_version()),
    }


def _ortam_metni() -> str:
    return "\n".join([
        "işletim sistemi : {}".format(platform.platform()),
        "python          : {}".format(sys.version.replace("\n", " ")),
        "zaman           : {}".format(
            time.strftime("%d.%m.%Y %H:%M:%S")),
    ])


def paket_olustur(metin: str, gonderen: str = "",
                  yalnizca_kimlik: Optional[str] = None) -> Tuple[Optional[str], str]:
    """Paketi yazar. (yol, mesaj) döner; yol None ise mesaj sebebi söyler."""
    metin = (metin or "").strip()
    if not metin:
        return None, "Yazdığın bir şey yok; paket oluşturulmadı."

    dosyalar = kayit_dosyalari(yalnizca_kimlik)
    klasor = paket_klasoru()
    try:
        os.makedirs(klasor, exist_ok=True)
    except OSError as sorun:
        return None, "Klasör açılamadı: {}".format(sorun)

    damga = time.strftime("%Y%m%d-%H%M%S")
    ad_parcasi = durum_modulu.dosya_adi_yap(gonderen) if gonderen else "oyuncu"
    # Ayni saniyede iki paket olusturulursa ikincisi birincinin USTUNE
    # yazardi. Test eden birinin arka arkaya iki not gondermesi olagan;
    # ilkini sessizce kaybetmek kabul edilemez.
    hedef = os.path.join(klasor, "geribildirim-{}-{}.zip".format(ad_parcasi, damga))
    sayac = 2
    while os.path.exists(hedef):
        hedef = os.path.join(klasor, "geribildirim-{}-{}-{}.zip".format(
            ad_parcasi, damga, sayac))
        sayac += 1

    basliklar = [
        "MERİDYEN SEFERİ - GERİ BİLDİRİM",
        "=" * 46,
        "gönderen: {}".format(gonderen or "(ad yazılmadı)"),
        "",
        _ortam_metni(),
        "",
        "OYUNCUNUN NOTU",
        "-" * 46,
        metin,
        "",
        "-" * 46,
        "Bu pakette YALNIZCA şunlar vardır: yukarıdaki not, paketi",
        "oluşturan öğrencinin kendi ilerleme kaydı ve sürüm bilgisi.",
        "",
        "Başka öğrencilerin kayıtları YOKTUR. Bilgisayarda başka hiçbir",
        "dosya taranmamış, hiçbir şey ağa gönderilmemiştir.",
    ]
    try:
        with zipfile.ZipFile(hedef, "w", zipfile.ZIP_DEFLATED) as zp:
            zp.writestr("geri_bildirim.txt", "\n".join(basliklar))
            for yol in dosyalar:
                zp.write(yol, os.path.join("kayitlar", os.path.basename(yol)))
    except OSError as sorun:
        return None, "Paket yazılamadı: {}".format(sorun)

    return hedef, "{} kayıt paketlendi.".format(len(dosyalar))
