# -*- coding: utf-8 -*-
"""
MEB konu haritası: hangi konu hangi sınıfta, hangi program sürümünde.

`oyun/veri/konu_haritasi.csv` dokuz dersin (matematik, fizik, kimya, biyoloji,
edebiyat, tarih, inkılap, coğrafya, felsefe) 9-12 ve seçilmiş 5-8. sınıf
satırlarını tutar. Her satır bir konu
grubudur: MEB ünitesi, konu metni, resmî kazanım kodları, yaygın yanlışlar,
oyun içi bağlam önerisi ve -varsa- oyundaki karşılığı.

NE İŞE YARAR
  * Öğretmen konu seçerken oyunun iç kodlarını (`denklem_kurma`) değil kendi
    programındaki konu adını görür.
  * Bir konunun oyunda karşılığı YOK ise öğretmen bunu SEÇMEDEN ÖNCE görür;
    boş pano sürprizi olmaz.
  * `oyunda_karsiligi` alanı bir konu adı iddia eder; o konunun soruları
    öğrencinin sınıfını kapsamıyorsa (ör. 1-4. kademe içeriği 11. sınıfa)
    `oyunda_hazir()` onu saymaz.

SINIRLAR
  * Tablo bir ARAŞTIRMA çıktısıdır (ChatGPT, 11-12 Eylül 2026); ham hâli ve
    denetim notları `taramalar/` altındadır. 1735 kazanım kodunun tamamı MEB
    belgelerinde ve atıf verilen sayfada bulundu, ama satırların öğretmence
    incelenmesi yapılmadı. "MEB onaylı" DEĞİLDİR.
  * "Hazır" satır sayısı KAPSAMA DEĞİL. Bir satırın karşılığı olması, o
    satırın konusundan soru geldiği anlamına gelmez: tarih ve inkılapta 141
    satırı 7 genel beceri konusu (neden-sonuç, kronoloji...) karşılıyor.
    `python main.py --konu-haritasi` bunu "EŞLEME GENİŞLİĞİ" başlığında
    ayrıca yazıyor ve kaba eşlemeyi işaretliyor.
  * `onkosul` ve ilerleme notları öğretim önerisidir, MEB'in zorunlu ön koşul
    listesi değildir.
  * Eski ve yeni program satırları aynı öğrencinin havuzunda karıştırılmaz;
    okulun uyguladığı sürüm `surum` alanıyla seçilir.

ÖĞRENCİYE GÖSTERİLMEZ: `sinif` okul sınıfıdır ve oyunun `kademeler`
aralığıyla sayısal olarak eşleşir, ama oyuncu bunu ZORLUK olarak görür.
Bu modülün ürettiği hiçbir metin (ünite adı, kazanım kodu, sınıf) öğrenci
ekranına gitmez; burası öğretmen masası ve içerik planlaması içindir.
"""
from __future__ import annotations

import csv
import io
import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

SURUMLER = ("eski_2018", "eski_2019", "eski_2023", "yeni_2024", "yeni_2026")
SURUM_ADLARI = {
    "eski_2018": "2018 programı (eski)",
    "eski_2019": "2019 programı (eski)",
    "eski_2023": "2023 programı (eski)",
    "yeni_2024": "Maarif Modeli - 2024 sürümü",
    "yeni_2026": "Maarif Modeli - 2026 sürümü",
}

# Satırların kaynağı. CSV'de yalnız belge kodu + sayfa durur ("biyo_2018#16");
# aynı bağlantı 710 satırda tekrar etmesin ve tek yerden düzeltilebilsin diye.
BELGELER: Dict[str, Dict[str, str]] = {
    "biyo_2018": {
        "ad": "Biyoloji Dersi Öğretim Programı (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/20182215535566-Biyoloji%20d%C3%B6p.pdf"},
    "biyo_2026": {
        "ad": "Biyoloji DÖP (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/202651815105221-biyolojid%C3%B6p.pdf"},
    "fizik_2018": {
        "ad": "Ortaöğretim Fizik Dersi Öğretim Programı (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/201812103112910-orta%C3%B6%C4%9Fretim_fizik_son.pdf"},
    "fizik_2026": {
        "ad": "Fizik DÖP (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026518151437471-fizikd%C3%B6p.pdf"},
    "kimya_2018": {
        "ad": "Kimya Dersi Öğretim Programı (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/201812102955190-19.01.2018%20Kimya%20Dersi%20%C3%96%C4%9Fretim%20Program%C4%B1.pdf"},
    "kimya_2026": {
        "ad": "Kimya DÖP (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026518151539674-kimya.pdf"},
    "edebiyat_2018": {
        "ad": "Türk Dili ve Edebiyatı Öğretim Programı (2018 programı, 2022 baskısı)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/20221229132522794-T%C3%BCrk%20Dili%20ve%20Edebiyat%C4%B1%20Dersi%20%C3%96%C4%9Fretim%20Program%C4%B1.pdf"},
    "edebiyat_2026": {
        "ad": "Türk Dili ve Edebiyatı DÖP (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026518151228236-edebiyatd%C3%B6p.pdf"},
    "mat_orta_2018": {
        "ad": "Matematik Dersi Öğretim Programı 1-8 (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/201813017165445-MATEMAT%C4%B0K%20%C3%96%C4%9ERET%C4%B0M%20PROGRAMI%202018v.pdf"},
    "mat_lise_2018": {
        "ad": "Ortaöğretim Matematik Dersi Öğretim Programı (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/201821102727101-OGM%20MATEMAT%C4%B0K%20PRG%2020.01.2018.pdf"},
    "mat_lise_2024": {
        "ad": "Matematik DÖP 9-12 (TYMM, 2024 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/202582695225533-matematik.pdf"},
    "mat_lise_2026": {
        "ad": "Matematik DÖP 9-12 (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026518151640408-mated%C3%B6p.pdf"},
    "mat_orta_2026": {
        "ad": "Matematik DÖP 5-8 (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/202681491243620-Matematik%20(5-8)%20D%C3%96P.pdf"},
    "tarih_2023": {
        "ad": "Tarih Dersi Öğretim Programı (2023)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2023428142759840-2023_tarih.pdf"},
    "tarih_2026": {
        "ad": "Tarih DÖP (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026691344767-tarihd%C3%B6p.pdf"},
    "inkilap_2018": {
        "ad": "İnkılap Tarihi ve Atatürkçülük Öğretim Programı (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/201812104016155-%C4%B0NKILAP%20TAR%C4%B0H%C4%B0%20VE%20ATAT%C3%9CRK%C3%87%C3%9CL%C3%9CK%20%C3%96%C4%9ERET%C4%B0M%20PROGRAMI.pdf"},
    "inkilap_2022": {
        "ad": "T.C. İnkılap Tarihi ve Atatürkçülük ÖP (2022 baskısı)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/20221229131923491-T.C.%20%C4%B0nk%C4%B1lap%20Tarihi%20ve%20Atat%C3%BCrk%C3%A7%C3%BCl%C3%BCk%20Dersi%20%C3%96%C4%9Fretim%20Program%C4%B1.pdf"},
    "inkilap_2026": {
        "ad": "T.C. İnkılap Tarihi ve Atatürkçülük DÖP (TYMM, 2026)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026716114859749-%C4%B1nk%C4%B1laptarihi.pdf"},
    "inkilap_orta_2025": {
        "ad": "T.C. İnkılap Tarihi ve Atatürkçülük 8 (2025 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2025825154713595-ink%C4%B1lap%208.pdf"},
    "sosyal_2023": {
        "ad": "Sosyal Bilgiler Dersi Öğretim Programı (2023)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2023428142532575-2023_sosyal_bilgiler.pdf"},
    "sosyal_2026": {
        "ad": "Sosyal Bilgiler DÖP (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/20268149286708-Sosyal%20Bilgiler%20D%C3%96P.pdf"},
    "cografya_2018": {
        "ad": "Coğrafya Dersi Öğretim Programı (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2018120203724482-Cografya%20dop%20pdf.pdf"},
    "cografya_2026": {
        "ad": "Coğrafya DÖP (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026518151120283-cogd%C3%B6p.pdf"},
    "felsefe_2018": {
        "ad": "Felsefe Dersi Öğretim Programı (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2018122175632591-Felsefe%20d%C3%B6p%20pdf.pdf"},
    "felsefe_2026": {
        "ad": "Felsefe DÖP (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026518151339111-felsefed%C3%B6p.pdf"},
    "fen_2018": {
        "ad": "Fen Bilimleri Dersi Öğretim Programı (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/201812312311937-FEN%20B%C4%B0L%C4%B0MLER%C4%B0%20%C3%96%C4%9ERET%C4%B0M%20PROGRAMI2018.pdf"},
    "fen_2026": {
        "ad": "Fen Bilimleri DÖP 3-8 (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/20268149031570-Fen%20Bilimleri%20(3-8)%20D%C3%96P.pdf"},
    "turkce_2019": {
        "ad": "Türkçe Dersi Öğretim Programı (2019)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/20195716392253-02-T%C3%BCrk%C3%A7e%20%C3%96%C4%9Fretim%20Program%C4%B1%202019.pdf"},
    "turkce_ilk_2026": {
        "ad": "Türkçe DÖP 1-4 (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/202681493354625-T%C3%BCrk%C3%A7e%20(1-4)%20D%C3%96P%20TTKB.pdf"},
    "turkce_2026": {
        "ad": "Türkçe DÖP 5-8 (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/202681493819891-T%C3%BCrk%C3%A7e%20(5-8)%20D%C3%96P.pdf"},
    "din_lise_2018": {
        "ad": "DKAB DÖP 9-12 (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/20221229134742302-DKAB_%289-12.%20S%C4%B1n%C4%B1f%29_DOP_%202018.pdf"},
    "din_orta_2018": {
        "ad": "DKAB DÖP 4-8 (2018)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/20221229134650712-DKAB_%284-8.%20S%C4%B1n%C4%B1f%29_DOP_%202018.pdf"},
    "din_lise_2026": {
        "ad": "DKAB DÖP 9-12 (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/2026313101155916-dkab912.pdf"},
    "din_orta_2026": {
        "ad": "DKAB DÖP 4-8 (TYMM, 2026 sürümü)",
        "url": "https://mufredat.meb.gov.tr/Dosyalar/202631310725635-dkab48.pdf"},
}

YOK = "YOK"
YUKLEME_HATASI = ""          # tablo okunamazsa sebep; oyun yine de açılır


@dataclass(frozen=True)
class HaritaSatiri:
    ders: str
    sinif: int
    surum: str
    secenek: str                        # aynı sürümün kapsam seçeneği
    unite: str
    konu: str
    kod: str                            # önerilen kısa kod (oyun adı adayı)
    kazanimlar: Tuple[str, ...]         # resmî MEB kazanım / öğrenme çıktısı kodları
    onkosul: str
    fark: str                           # önceki sınıftan farkı
    yaygin_yanlis: str
    baglam: str                         # oyun içi bağlam önerisi
    karsiliklar: Tuple[str, ...]        # ARAŞTIRMANIN iddia ettiği oyun konuları
    ek_karsilik: Tuple[str, ...]        # BİZİM sonradan eklediğimiz konular
    kaynak: Tuple[str, ...]             # "belge_kodu#sayfa" parçaları

    def baglantilar(self) -> List[str]:
        """Atıf verilen MEB sayfalarının tam bağlantıları."""
        sonuc = []
        for parca in self.kaynak:
            kod, _, sayfa = parca.partition("#")
            belge = BELGELER.get(kod)
            if not belge:
                continue
            sonuc.append(belge["url"] + ("#page=" + sayfa if sayfa else ""))
        return list(dict.fromkeys(sonuc))

    def belge_adlari(self) -> List[str]:
        adlar = [BELGELER[p.partition("#")[0]]["ad"]
                 for p in self.kaynak if p.partition("#")[0] in BELGELER]
        return list(dict.fromkeys(adlar))

    def adaylar(self) -> List[str]:
        """Bu satıra karşılık gelebilecek oyun konusu adları.

        ÜÇ KAYNAKTAN geliyorlar ve üçü de ayrı sütunda durur:

        * `onerilen_kod` -- araştırmanın önerdiği ad. Yeni içerik o adla
          yazılınca satır kendiliğinden kapanır; aksi hâlde her içerik
          görevinden sonra CSV'yi elle düzeltmek gerekirdi ve kapsama
          raporu sessizce eskirdi.
        * `oyunda_karsiligi` -- araştırmanın o gün bulduğu eşleşme.
          DONDURULMUŞ: oyunda olmayan konu için "YOK" yazar ve sonradan
          düzeltilmez.
        * `ek_karsilik` -- BİZİM sonradan verdiğimiz karar. Ayrı sütunda,
          çünkü araştırmanın o gün ne iddia ettiğiyle bizim ne karar
          verdiğimiz aynı hücrede karışırsa bir daha ayrılamaz. Ders
          sınırını aşan eşleştirmeler buraya yazılır: din satırının
          tarihsel yanını `anakronizm`e bağlamak gibi.
        """
        return list(dict.fromkeys(
            [self.kod] + list(self.karsiliklar) + list(self.ek_karsilik)))

    def oyunda_hazir(self) -> List[Tuple[str, str]]:
        """Bu satır için GERÇEKTEN soru gelebilecek (ders, konu) çiftleri.

        İki süzgeç var: konu kayıt defterinde var mı, ve o konunun içerik
        kademesi satırın sınıfını kapsıyor mu. İkincisi olmadan öğretmen
        11. sınıfa 1-4. kademe içeriği seçebilirdi.
        """
        from .kayit_defteri import uygun_kayitlar
        sonuc: List[Tuple[str, str]] = []
        for konu in self.adaylar():
            for kayit in uygun_kayitlar(konu=konu, kademe=self.sinif or None):
                cift = (kayit.ders, konu)
                if cift not in sonuc:
                    sonuc.append(cift)
        return sonuc

    def kademe_disi(self) -> List[Tuple[str, str]]:
        """Karşılığı var ama içeriği bu sınıfı kapsamayan çiftler."""
        from .kayit_defteri import uygun_kayitlar
        hazir = {cift[1] for cift in self.oyunda_hazir()}
        sonuc: List[Tuple[str, str]] = []
        for konu in self.adaylar():
            if konu in hazir:
                continue
            for kayit in uygun_kayitlar(konu=konu):
                cift = (kayit.ders, konu)
                if cift not in sonuc:
                    sonuc.append(cift)
        return sonuc

    def etiket(self) -> str:
        """Öğretmen listesinde görünen satır adı.

        Coğrafya aynı programı iki haftalık ders saatiyle veriyor; seçenek
        yazılmazsa öğretmen listede aynı konuyu iki kez görür ve hangisinin
        kendi dersi olduğunu ayıramaz.
        """
        ad = "{} - {}".format(self.unite, self.konu) if self.unite else self.konu
        return "{} [{}]".format(ad, self.secenek) if self.secenek else ad


_TABLO: Optional[Tuple[HaritaSatiri, ...]] = None


def veri_yolu() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "veri", "konu_haritasi.csv")


def ek_karsilik_yolu() -> str:
    return os.path.join(os.path.dirname(veri_yolu()), "ek_karsilik.csv")


def _parcala(alan: str) -> Tuple[str, ...]:
    return tuple(p.strip() for p in alan.split(";") if p.strip())


def ek_karsilik_tablosu() -> Dict[str, Tuple[str, ...]]:
    """BİZİM verdiğimiz ek eşleştirmeler: `onerilen_kod` -> oyun konuları.

    NEDEN AYRI DOSYA: `konu_haritasi.csv` araştırma dosyalarından SIFIRDAN
    yeniden üretiliyor (her yeni ders haritası geldiğinde). Kararlarımız o
    tabloda dursaydı, bir sonraki yeniden üretimde sessizce silinirdi ve
    sütunu ayırmanın bütün amacı boşa giderdi. Burada ayrı durdukları için
    tablo kaç kez yeniden kurulursa kurulsun kaybolmazlar; her birinin
    `gerekce` sütunu da kararın neden verildiğini taşır.

    Dosya yoksa ya da okunamazsa boş döner -- ek eşleme olmadan da tablo
    çalışır.
    """
    sonuc: Dict[str, Tuple[str, ...]] = {}
    try:
        with io.open(ek_karsilik_yolu(), encoding="utf-8-sig", newline="") as dosya:
            for ham in csv.DictReader(dosya):
                kod = (ham.get("onerilen_kod") or "").strip()
                konular = _parcala((ham.get("ek_karsilik") or "").replace(",", ";"))
                if kod and konular:
                    sonuc[kod] = tuple(dict.fromkeys(sonuc.get(kod, ()) + konular))
    except (OSError, csv.Error):
        return {}
    return sonuc


def tablo(zorla: bool = False) -> Tuple[HaritaSatiri, ...]:
    """Konu haritasını okur (bir kez). Dosya yoksa boş döner, oyun çökmez."""
    global _TABLO, YUKLEME_HATASI
    if _TABLO is not None and not zorla:
        return _TABLO
    satir_listesi: List[HaritaSatiri] = []
    YUKLEME_HATASI = ""
    ekler = ek_karsilik_tablosu()
    try:
        with io.open(veri_yolu(), encoding="utf-8-sig", newline="") as dosya:
            for ham in csv.DictReader(dosya):
                if not (ham.get("ders") or "").strip():
                    continue
                sinif = (ham.get("sinif") or "").strip()
                karsilik = (ham.get("oyunda_karsiligi") or "").strip()
                satir_listesi.append(HaritaSatiri(
                    ders=ham["ders"].strip(),
                    sinif=int(sinif) if sinif.isdigit() else 0,
                    surum=(ham.get("surum") or "").strip(),
                    secenek=(ham.get("secenek") or "").strip(),
                    unite=(ham.get("unite") or "").strip(),
                    konu=(ham.get("konu") or "").strip(),
                    kod=(ham.get("onerilen_kod") or "").strip(),
                    kazanimlar=_parcala(ham.get("kazanim_kodu") or ""),
                    onkosul=(ham.get("onkosul") or "").strip(),
                    fark=(ham.get("onceki_siniftan_fark") or "").strip(),
                    yaygin_yanlis=(ham.get("yaygin_yanlis") or "").strip(),
                    baglam=(ham.get("gunluk_baglam") or "").strip(),
                    karsiliklar=() if karsilik.upper() == YOK else _parcala(
                        karsilik.replace(",", ";")),
                    ek_karsilik=tuple(dict.fromkeys(_parcala(
                        (ham.get("ek_karsilik") or "").replace(",", ";"))
                        + ekler.get((ham.get("onerilen_kod") or "").strip(), ()))),
                    kaynak=_parcala(ham.get("kaynak") or ""),
                ))
    except Exception as sorun:  # noqa: BLE001 - tablo yoksa oyun yine açılır
        YUKLEME_HATASI = "{}: {}".format(type(sorun).__name__, sorun)
        satir_listesi = []
    _TABLO = tuple(satir_listesi)
    return _TABLO


def satirlar(ders: Optional[str] = None, sinif: Optional[int] = None,
             surum: Optional[str] = None, unite: Optional[str] = None
             ) -> List[HaritaSatiri]:
    sonuc = []
    for s in tablo():
        if ders and s.ders != ders:
            continue
        if sinif and s.sinif != sinif:
            continue
        if surum and s.surum != surum:
            continue
        if unite and s.unite != unite:
            continue
        sonuc.append(s)
    return sonuc


def dersler() -> List[str]:
    return sorted({s.ders for s in tablo()})


def surumler(ders: Optional[str] = None) -> List[str]:
    bulunan = {s.surum for s in satirlar(ders=ders)}
    return [s for s in SURUMLER if s in bulunan]


def siniflar(ders: Optional[str] = None, surum: Optional[str] = None) -> List[int]:
    return sorted({s.sinif for s in satirlar(ders=ders, surum=surum) if s.sinif})


def uniteler(ders: str, sinif: int, surum: str) -> List[str]:
    gorulen: List[str] = []
    for s in satirlar(ders=ders, sinif=sinif, surum=surum):
        if s.unite and s.unite not in gorulen:
            gorulen.append(s.unite)
    return gorulen


def kapsam(ders: Optional[str] = None, sinif: Optional[int] = None,
           surum: Optional[str] = None) -> Dict[str, List[HaritaSatiri]]:
    """Üç yığın: oyunda hazır, kademesi tutmayan, hiç karşılığı olmayan."""
    sonuc: Dict[str, List[HaritaSatiri]] = {"hazir": [], "kademe_disi": [], "bos": []}
    for s in satirlar(ders=ders, sinif=sinif, surum=surum):
        if s.oyunda_hazir():
            sonuc["hazir"].append(s)
        elif s.karsiliklar:
            sonuc["kademe_disi"].append(s)
        else:
            sonuc["bos"].append(s)
    return sonuc


def ogretmen_listesi(ders: str, sinif: int, surum: Optional[str] = None
                     ) -> List[Dict[str, object]]:
    """Öğretmen ekranında gösterilecek konu satırları.

    Her öğe: `satir` (HaritaSatiri), `konular` (o satırdan gelecek oyun
    konuları), `durum` ("hazir" / "kademe_disi" / "bos"). Sıra tabloyla
    aynıdır; ünite ünite gider, böylece öğretmen kendi yıllık planındaki
    sırayı görür.

    Ekranı çizen taraf karar vermesin diye durumu BURADA belirliyoruz:
    "kademe_disi", oyunda o adla içerik var ama bu sınıfı kapsamıyor demek.
    """
    liste: List[Dict[str, object]] = []
    for satir in satirlar(ders=ders, sinif=sinif, surum=surum):
        hazir = satir.oyunda_hazir()
        if hazir:
            durum = "hazir"
        elif satir.karsiliklar:
            durum = "kademe_disi"
        else:
            durum = "bos"
        liste.append({"satir": satir, "konular": [k for _, k in hazir],
                      "durum": durum})
    return liste


def oyun_konulari(ders: Optional[str] = None, sinif: Optional[int] = None,
                  surum: Optional[str] = None) -> List[Tuple[str, str]]:
    """Seçili kesitte soru gelebilecek bütün (ders, konu) çiftleri."""
    sonuc: List[Tuple[str, str]] = []
    for s in satirlar(ders=ders, sinif=sinif, surum=surum):
        for cift in s.oyunda_hazir():
            if cift not in sonuc:
                sonuc.append(cift)
    return sonuc
