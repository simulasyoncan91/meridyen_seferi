# -*- coding: utf-8 -*-
"""
Cevap değerlendirme.

Öğrenciyi biçim yüzünden cezalandırmamak esas. "12,5" ile "12.5", "3/4" ile
"0,75", "İSTANBUL" ile "istanbul" aynı cevaptır. Ama yuvarlama toleransı
bulmacayı yazan kişinin elindedir (Adim.tolerans).
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any, List, Optional, Sequence, Tuple

from .modeller import Adim, COKLU, ESLESTIR, METIN, SAYI, SECIM, SIRALA

# --------------------------------------------------------------------------
# Türkçe metin normalleştirme
# --------------------------------------------------------------------------

_BUYUK_KUCUK = str.maketrans({
    "I": "ı", "İ": "i", "Ş": "ş", "Ğ": "ğ", "Ü": "ü", "Ö": "ö", "Ç": "ç",
})

_SAPKA = str.maketrans({
    "â": "a", "Â": "a", "î": "i", "Î": "i", "û": "u", "Û": "u",
})


def tr_kucuk(metin: str) -> str:
    """Türkçe kurallarına göre küçük harfe çevirir (I->ı, İ->i)."""
    return metin.translate(_BUYUK_KUCUK).lower()


def sadelestir(metin: str, harf_duyarsiz: bool = True) -> str:
    """
    Karşılaştırma için metni sadeleştirir:
    küçük harf, şapkasız, noktalamasız, tek boşluklu.
    """
    if metin is None:
        return ""
    metin = unicodedata.normalize("NFC", str(metin)).strip()
    if harf_duyarsiz:
        metin = tr_kucuk(metin)
    metin = metin.translate(_SAPKA)
    metin = re.sub(r"[^\w\s]", " ", metin, flags=re.UNICODE)
    metin = re.sub(r"\s+", " ", metin).strip()
    return metin


def _duzeyleme_uzakligi(a: str, b: str) -> int:
    """Levenshtein. Yazım hatasını 'yakın' saymak için."""
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    onceki = list(range(len(b) + 1))
    for i, harf_a in enumerate(a, 1):
        simdiki = [i]
        for j, harf_b in enumerate(b, 1):
            simdiki.append(min(
                onceki[j] + 1,
                simdiki[j - 1] + 1,
                onceki[j - 1] + (harf_a != harf_b),
            ))
        onceki = simdiki
    return onceki[-1]


def yakin_mi(verilen: str, beklenen: str) -> bool:
    """Sadece 'az kalmıştı' geri bildirimi için; doğru saymaz."""
    a, b = sadelestir(verilen), sadelestir(beklenen)
    if not a or not b:
        return False
    esik = 1 if len(b) <= 6 else 2
    return _duzeyleme_uzakligi(a, b) <= esik


# --------------------------------------------------------------------------
# Sayı ayrıştırma
# --------------------------------------------------------------------------

_SAYI_TEMIZ = re.compile(r"[^\d,.\-/eE+ ]")

# Üslü yazım. Telefonda "^" klavyenin ikinci sayfasında; kimi öğrenci "**"
# yazar, kimi kopyaladığı "2⁵"i yapıştırır. Üçü de aynı şey demek.
_UST_SIMGE = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺", "0123456789-+")
_UST_SIMGE_KALIBI = re.compile(r"[⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺]+")
_CARPI = re.compile(r"\s*[x×*·]\s*")
_AZAMI_US = 100


def _us_coz(metin: str) -> Optional[float]:
    """'2^5' -> 32, '(-3)^2' -> 9, '-3^2' -> -9, '3,2 × 10^-4' -> 0,00032.

    Çözemediğini (iki üs, dev üs, negatif tabanın kesirli üssü) None
    döndürür; öğrenci "anlaşılamadı" görür, uydurma bir sayı değil.
    """
    parcalar = metin.split("^")
    if len(parcalar) != 2:
        return None
    sol, us_metni = parcalar[0].strip(), parcalar[1].strip()
    us = sayi_coz(us_metni)
    if us is None or abs(us) > _AZAMI_US:
        return None
    carpan = 1.0
    carpim = _CARPI.split(sol)
    if len(carpim) == 2:                     # bilimsel gösterim: a × 10^n
        carpan = sayi_coz(carpim[0])
        sol = carpim[1].strip()
        if carpan is None:
            return None
    elif len(carpim) > 2:
        return None
    # "-3^2" matematikte -(3^2)'dir; parantezli "(-3)^2" ise 9.
    isaret = 1.0
    if sol.startswith("-"):
        isaret, sol = -1.0, sol[1:]
    taban = sayi_coz(sol.replace("(", "").replace(")", ""))
    if taban is None or (taban < 0 and us != int(us)) or (taban == 0 and us < 0):
        return None
    try:
        sonuc = isaret * carpan * (taban ** us)
    except (OverflowError, ZeroDivisionError):
        return None
    return sonuc if abs(sonuc) < 1e300 else None


def sayi_coz(ham: str) -> Optional[float]:
    """
    '12,5' / '12.5' / '3/4' / '1 200' / '%25' / '12 kg' gibi girdileri sayıya çevirir.
    Üslü yazımı da okur: '2^5', '2**5', '2⁵', '3,2 × 10^-4'.
    Çözemezse None döner.
    """
    if ham is None:
        return None
    if isinstance(ham, (int, float)):
        return float(ham)
    metin = str(ham).strip()
    if not metin:
        return None

    metin = metin.replace("−", "-")  # unicode eksi
    # ESKİ HATA: "^" temizlenip "2 5" -> 25 okunuyordu; "2⁵" -> 2. Doğru
    # cevabı yazan öğrenci "yanlış" görüyordu (11 Eylül 2026). Üs yoksa
    # aşağıdaki eski yol aynen çalışır.
    metin = _UST_SIMGE_KALIBI.sub(
        lambda m: "^" + m.group().translate(_UST_SIMGE), metin).replace("**", "^")
    if "^" in metin:
        return _us_coz(metin)
    metin = _SAYI_TEMIZ.sub(" ", metin).strip()
    if not metin:
        return None

    # Kesir: "3/4", "-3 / 4"
    if "/" in metin:
        parcalar = [p.strip() for p in metin.split("/") if p.strip()]
        if len(parcalar) == 2:
            ust, alt = sayi_coz(parcalar[0]), sayi_coz(parcalar[1])
            if ust is not None and alt not in (None, 0):
                return ust / alt
        return None

    metin = metin.replace(" ", "")
    if not metin:
        return None

    # Hem nokta hem virgül varsa: sonuncusu ondalık ayracıdır.
    if "," in metin and "." in metin:
        if metin.rfind(",") > metin.rfind("."):
            metin = metin.replace(".", "").replace(",", ".")
        else:
            metin = metin.replace(",", "")
    elif "," in metin:
        # Tek virgül -> ondalık. Birden çok virgül -> binlik ayracı.
        metin = metin.replace(",", ".") if metin.count(",") == 1 else metin.replace(",", "")

    try:
        return float(metin)
    except ValueError:
        return None


def sayi_bicimle(deger: Any, birim: str = "") -> str:
    """Sonucu okunur biçimde yazar: 12.0 -> '12', 12.50 -> '12,5'."""
    try:
        sayi = float(deger)
    except (TypeError, ValueError):
        return str(deger)
    if abs(sayi - round(sayi)) < 1e-9:
        metin = str(int(round(sayi)))
    else:
        metin = ("{:.4f}".format(sayi)).rstrip("0").rstrip(".").replace(".", ",")
    return (metin + " " + birim).strip()


# --------------------------------------------------------------------------
# Şık listesi ayrıştırma
# --------------------------------------------------------------------------

def liste_coz(ham: str, sik_sayisi: int) -> Optional[List[int]]:
    """
    '1,3,5' / '1 3 5' / '135' / 'a,c,e' girdisini 0-tabanlı indeks listesine çevirir.
    Aralık dışı ya da anlaşılmaz girdi için None döner.
    """
    if ham is None:
        return None
    metin = ham.strip().lower()
    if not metin:
        return None

    parcalar = re.split(r"[\s,;./+\-]+", metin)
    parcalar = [p for p in parcalar if p]

    # Ayraçsız yazılmışsa ('135') ve tüm karakterler rakamsa tek tek ayır.
    if (len(parcalar) == 1 and parcalar[0].isdecimal()
            and len(parcalar[0]) > 1 and sik_sayisi < 10):
        parcalar = list(parcalar[0])

    indeksler = []
    for parca in parcalar:
        if parca.isdecimal():
            deger = int(parca) - 1
        elif len(parca) == 1 and "a" <= parca <= "z":
            deger = ord(parca) - ord("a")
        else:
            return None
        if not (0 <= deger < sik_sayisi):
            return None
        indeksler.append(deger)
    return indeksler or None


# --------------------------------------------------------------------------
# Ana değerlendirme
# --------------------------------------------------------------------------

def degerlendir(adim: Adim, ham_cevap: str) -> Tuple[bool, str]:
    """
    (dogru_mu, geri_bildirim) döner.
    Geri bildirim, yanlışsa öğrenciyi yönlendiren kısa bir nottur.
    """
    if adim.tur == SAYI:
        return _sayi_degerlendir(adim, ham_cevap)
    if adim.tur == SECIM:
        return _secim_degerlendir(adim, ham_cevap)
    if adim.tur == COKLU:
        return _coklu_degerlendir(adim, ham_cevap)
    if adim.tur == SIRALA:
        return _sirala_degerlendir(adim, ham_cevap)
    if adim.tur == METIN:
        return _metin_degerlendir(adim, ham_cevap)
    if adim.tur == ESLESTIR:
        return _eslestir_degerlendir(adim, ham_cevap)
    return False, "Bilinmeyen adım türü."


def teshis(adim: Adim, ham: str) -> str:
    """
    Yanlış cevabın teşhisi: öğrencinin hangi hatayı yaptığını söyleyen cümle.

    `degerlendir` genel bir geri bildirim verir ("iki katını buldun"). Burası
    ondan farklı: görev yazarının o yanlışa özel yazdığı açıklamayı bulur.
    Eşleşme yoksa boş metin döner ve oyun genel geri bildirimle devam eder.
    """
    teshisler = adim.yanlis_teshis or {}
    if not teshisler:
        return ""

    if adim.tur == SECIM and adim.secenekler:
        indeksler = liste_coz(ham, len(adim.secenekler))
        if indeksler and len(indeksler) == 1:
            secilen = adim.secenekler[indeksler[0]]
            if secilen in teshisler:
                return teshisler[secilen]
            # Şık metni uzun; yazar kısaltarak yazmış olabilir.
            sade = sadelestir(secilen)
            for anahtar, metin in teshisler.items():
                if anahtar != "*" and sadelestir(anahtar) == sade:
                    return metin

    elif adim.tur == SAYI:
        verilen = sayi_coz(ham)
        if verilen is not None:
            for anahtar, metin in teshisler.items():
                if anahtar == "*":
                    continue
                beklenen = sayi_coz(str(anahtar))
                if beklenen is None:
                    continue
                tolerans = max(abs(adim.tolerans), abs(beklenen) * 1e-9)
                if abs(verilen - beklenen) <= tolerans:
                    return metin

    elif adim.tur == METIN:
        verilen = sadelestir(ham)
        for anahtar, metin in teshisler.items():
            if anahtar != "*" and sadelestir(anahtar) == verilen:
                return metin

    return teshisler.get("*", "")


def _sayi_degerlendir(adim: Adim, ham: str) -> Tuple[bool, str]:
    verilen = sayi_coz(ham)
    if verilen is None:
        return False, "Bunu sayı olarak okuyamadım. Örnek: 124, 12,5 ya da 3/4."
    beklenen = float(adim.cevap)
    tolerans = max(abs(adim.tolerans), abs(beklenen) * 1e-9)
    if abs(verilen - beklenen) <= tolerans:
        return True, ""
    if beklenen != 0 and abs(abs(verilen) - abs(beklenen)) <= tolerans:
        return False, "Büyüklük doğru, işaret ters. Yönü bir düşün."
    if beklenen != 0 and abs(verilen - beklenen * 2) <= tolerans:
        return False, "Sonucun iki katını buldun; bir yerde ikiye bölmeyi atlamış olabilirsin."
    if beklenen != 0 and abs(verilen - beklenen / 2) <= tolerans:
        return False, "Sonucun yarısını buldun; iki parçadan yalnızca birini hesaplamış olabilirsin."
    if beklenen != 0 and abs(verilen - beklenen) <= abs(beklenen) * 0.05:
        return False, "Çok yaklaştın. Yuvarlamayı ya da bir küçük terimi gözden geçir."
    return False, ""


def _secim_degerlendir(adim: Adim, ham: str) -> Tuple[bool, str]:
    indeksler = liste_coz(ham, len(adim.secenekler))
    if not indeksler:
        return False, "Şıkkın numarasını yaz (örnek: 2)."
    if len(indeksler) > 1:
        return False, "Burada tek bir şık seçmelisin."
    return (indeksler[0] == int(adim.cevap)), ""


def _coklu_degerlendir(adim: Adim, ham: str) -> Tuple[bool, str]:
    sik_sayisi = len(adim.secenekler)
    if sadelestir(ham) in ("yok", "hicbiri", "hic biri", "temiz", "0"):
        secilen = set()
    else:
        indeksler = liste_coz(ham, sik_sayisi)
        if indeksler is None:
            return False, "Numaraları virgülle ayırarak yaz (örnek: 1,3,5). Hiçbiri ise: yok"
        secilen = set(indeksler)
    beklenen = set(int(i) for i in adim.cevap)
    if secilen == beklenen:
        return True, ""
    eksik = len(beklenen - secilen)
    fazla = len(secilen - beklenen)
    if eksik and not fazla:
        return False, "Bulduklarının hepsi doğru ama {} tanesini gözden kaçırdın.".format(eksik)
    if fazla and not eksik:
        return False, "Doğruların hepsi listende, ama {} tane fazladan işaret var.".format(fazla)
    return False, "Bir kısmı eksik, bir kısmı fazla."


def _sirala_degerlendir(adim: Adim, ham: str) -> Tuple[bool, str]:
    sik_sayisi = len(adim.secenekler)
    indeksler = liste_coz(ham, sik_sayisi)
    if indeksler is None:
        return False, "Sırayı numaralarla yaz (örnek: 3,1,4,2)."
    if len(set(indeksler)) != len(indeksler):
        return False, "Aynı numarayı iki kez yazmışsın."
    if len(indeksler) != sik_sayisi:
        return False, "{} öğenin hepsini sıraya dizmelisin.".format(sik_sayisi)
    beklenen = [int(i) for i in adim.cevap]
    if indeksler == beklenen:
        return True, ""
    # Ters sıralama en sık yapılan hata; kısmi isabet mesajının önüne geçmeli.
    # (Tek sayıda öğede orta eleman yerinde kaldığı için 'yerinde' sayacı da dolar.)
    if indeksler == list(reversed(beklenen)):
        return False, "Sıra tam ters. Hangi uçtan başladığını gözden geçir."
    yerinde = sum(1 for a, b in zip(indeksler, beklenen) if a == b)
    if yerinde:
        return False, "{} öğe doğru yerde, gerisi değil.".format(yerinde)
    return False, ""


def _metin_degerlendir(adim: Adim, ham: str) -> Tuple[bool, str]:
    beklenenler: Sequence[str]
    if isinstance(adim.cevap, (list, tuple)):
        beklenenler = adim.cevap
    else:
        beklenenler = [adim.cevap]
    verilen = sadelestir(ham)
    if not verilen:
        return False, "Boş bıraktın."
    for beklenen in beklenenler:
        if verilen == sadelestir(beklenen):
            return True, ""
    for beklenen in beklenenler:
        if yakin_mi(ham, str(beklenen)):
            return False, "Neredeyse. Yazımı bir daha kontrol et."
    return False, ""


def _eslestir_degerlendir(adim: Adim, ham: str) -> Tuple[bool, str]:
    """
    Cevap biçimi: '1a,2c,3b' ya da '1-a 2-c 3-b'.
    adim.cevap: ['a', 'c', 'b'] gibi, sol öğelerin sırasına göre harfler.
    """
    beklenen = [sadelestir(str(x)) for x in adim.cevap]
    ciftler = re.findall(r"(\d+)\s*[-:.]?\s*([a-zA-ZçğıöşüÇĞİÖŞÜ]+)", ham or "")
    if len(ciftler) != len(beklenen):
        return False, "Her satır için bir eşleşme yaz (örnek: 1a, 2c, 3b)."
    sonuc = [""] * len(beklenen)
    for numara, harf in ciftler:
        sira = int(numara) - 1
        if not (0 <= sira < len(beklenen)):
            return False, "1 ile {} arasında numara kullan.".format(len(beklenen))
        sonuc[sira] = sadelestir(harf)
    if sonuc == beklenen:
        return True, ""
    dogru_sayisi = sum(1 for a, b in zip(sonuc, beklenen) if a == b)
    return False, "{} eşleşme doğru.".format(dogru_sayisi) if dogru_sayisi else ""


def dogru_cevap_metni(adim: Adim) -> str:
    """Doğru cevabı öğrenciye gösterirken kullanılacak okunur biçim."""
    if adim.tur == SAYI:
        return sayi_bicimle(adim.cevap, adim.birim)
    if adim.tur == SECIM:
        return "{}) {}".format(int(adim.cevap) + 1, adim.secenekler[int(adim.cevap)])
    if adim.tur in (COKLU, SIRALA):
        sira = sorted(adim.cevap) if adim.tur == COKLU else list(adim.cevap)
        return ", ".join("{}) {}".format(i + 1, adim.secenekler[i]) for i in sira) or "hiçbiri"
    if adim.tur == METIN:
        return adim.cevap[0] if isinstance(adim.cevap, (list, tuple)) else str(adim.cevap)
    if adim.tur == ESLESTIR:
        return ", ".join("{}{}".format(i + 1, h) for i, h in enumerate(adim.cevap))
    return str(adim.cevap)

# --------------------------------------------------------------------------
# Sefer kapanışı: dürüst değerlendirme
# --------------------------------------------------------------------------
def sefer_degerlendirmesi(sonuclar) -> dict:
    """Bir zaman seferinin bölümlerine bakıp DÜRÜST bir özet çıkarır.

    Neden var: sefer kapanışı her tamamlamada aynı kutlama metnini
    gösteriyordu. Öğrenci birkaç hata yapıp "mükemmel" duyuyordu. Yanlışı
    doğru göstermek öğretmemektir; §0 "oyun öğretir, ölçmez" der, ama
    ölçmemek gerçeği gizlemek demek değildir.

    Ceza yok: dönen sözlükte puan, sıralama, başarısızlık damgası yoktur.
    Yalnızca "ne oldu" ve "neye bakmalı" bilgisi vardır.
    """
    toplam_adim = ilk_denemede = ipuclu = 0
    zorlanilan_konular = []
    teshisler = []
    for sonuc in sonuclar:
        for adim in sonuc.adim_sonuclari:
            toplam_adim += 1
            if adim.dogru and adim.deneme == 1 and not adim.destek_aldi:
                ilk_denemede += 1
            if adim.destek_aldi:
                ipuclu += 1
        takildi = any(
            (not a.dogru) or a.deneme > 1 or a.destek_aldi
            for a in sonuc.adim_sonuclari)
        if takildi and sonuc.konu and sonuc.konu not in zorlanilan_konular:
            zorlanilan_konular.append(sonuc.konu)
        teshisler.extend(sonuc.teshisler or [])

    puan = sum(s.puan for s in sonuclar)
    azami = sum(s.azami_puan for s in sonuclar)
    kusursuz = bool(toplam_adim) and ilk_denemede == toplam_adim

    # Tekrar eden teşhis, tek seferlik dalgınlıktan farklıdır.
    tekrar = {}
    for t in teshisler:
        tekrar[t] = tekrar.get(t, 0) + 1
    tekrarlayan = [t for t, n in sorted(tekrar.items(), key=lambda x: -x[1]) if n > 1]

    if kusursuz:
        baslik = "Kusursuz sefer."
        oneri = "Hiçbir adımda takılmadın. Bir üst zorluğu denemenin tam sırası."
    elif azami and puan / azami >= 0.8:
        baslik = "Sefer tamam, birkaç yerde takıldın."
        oneri = "Aşağıdaki konulara bir kez daha bakman yeter."
    elif azami and puan / azami >= 0.5:
        baslik = "Sefer tamam ama zorlandın."
        oneri = ("Bu konuları serbest çalışmadan tekrar iste; acele etme, "
                 "soruyu iki kez oku.")
    else:
        baslik = "Sefer bitti, ama çoğu adımda destek aldın."
        oneri = ("Bu konular henüz oturmamış. Birlikte çalışma aşamasında "
                 "tekrar etmek en hızlı yol.")

    return {
        "kusursuz": kusursuz,
        "baslik": baslik,
        "oneri": oneri,
        "toplam_adim": toplam_adim,
        "ilk_denemede": ilk_denemede,
        "ipuclu_adim": ipuclu,
        "puan": puan,
        "azami_puan": azami,
        "zorlanilan_konular": zorlanilan_konular,
        "tekrarlayan_hatalar": tekrarlayan[:3],
    }


def gorev_geri_bildirimi(bulmaca, sonuc) -> dict:
    """Tek bir görevin sonunda "neyi çalışmalıyım" bilgisi üretir.

    Kullanıcının isteği: "hatalı yaptığı sorularda yanlış yaptığı konuyu
    söyleyebilir." Şu an ekranda puan ve yıldız var, ama öğrenci NEYİ
    çalışacağını öğrenmiyor - oysa oyunun asıl birimi konudur
    (TASARIM_NOTLARI: "öğrenci matematikte değil, denklem kurmada zorlanır").

    §0: ceza yok. Zorlanmadıysa hiçbir şey döndürmüyoruz - başarılı
    öğrenciye "şunu da çalış" demek gereksiz yük.
    """
    zorlanan_adim = 0
    ipuclu_adim = 0
    for adim in sonuc.adim_sonuclari:
        if (not adim.dogru) or adim.deneme > 1:
            zorlanan_adim += 1
        if adim.destek_aldi:
            ipuclu_adim += 1

    if not zorlanan_adim and not ipuclu_adim:
        return {"zorlandi": False}

    # Aynı teşhis birden çok kez çıktıysa bu yerleşmiş bir karışıklıktır,
    # tek seferlik dalgınlık değil. Karnedeki ayrım burada da geçerli.
    tekrar = {}
    for t in (sonuc.teshisler or []):
        tekrar[t] = tekrar.get(t, 0) + 1
    tekrarlayan = [t for t, n in tekrar.items() if n > 1]

    if zorlanan_adim and ipuclu_adim:
        ozet = "Bu görevde hem takıldın hem destek aldın."
    elif zorlanan_adim:
        ozet = "Bu görevde {} adımda takıldın.".format(zorlanan_adim)
    else:
        ozet = "Adımları geçerken {} yerde destek kullandın.".format(ipuclu_adim)

    return {
        "zorlandi": True,
        "ozet": ozet,
        "konu": (getattr(bulmaca, "konu", "") or "").replace("_", " "),
        "kazanim": getattr(bulmaca, "kazanim", "") or "",
        "zorlanan_adim": zorlanan_adim,
        "ipuclu_adim": ipuclu_adim,
        "tekrarlayan_hatalar": tekrarlayan[:2],
    }


def gorev_ozeti(sonuc) -> dict:
    """Bir görevin, bir sonrakiyle karşılaştırılacak kadar kısa özeti."""
    adimlar = list(sonuc.adim_sonuclari or [])
    return {
        "adim": len(adimlar),
        "yardimli": sum(1 for a in adimlar if a.destek_aldi),
        "takilan": sum(1 for a in adimlar if (not a.dogru) or a.deneme > 1),
        "model": sonuc.model_basarisi(),
    }


def _oran(pay: int, payda: int) -> float:
    return pay / payda if payda else 0.0


def kisisel_karsilastirma(onceki: Optional[dict], simdi: dict) -> Optional[str]:
    """Aynı konudaki bir önceki bağımsız görevle karşılaştırma. (B31.14)

    Kıyas yalnızca öğrencinin KENDİ geçmişiyle yapılır, sınıfla asla.
    Yalnızca İLERLEME söylenir: kötüleşmeyi söylemek §0'ın tam tersi olurdu
    ve zorlanmayı zaten `gorev_geri_bildirimi` adıyla söylüyor. İlk görevde
    kıyaslanacak bir şey yok; o da susar.

    Görevlerin adım sayısı farklı olabilir. Bu yüzden "daha az yardım"
    hem SAYIDA hem ORANDA doğru olmalı; yoksa ekrandaki sayılar ("geçen
    sefer 1, bu kez 2") söylenen şeyle çelişirdi.
    """
    if not onceki or not simdi.get("adim") or not onceki.get("adim"):
        return None

    if onceki.get("model") is False and simdi.get("model") is True:
        return ("Geçen sefer bu konuda planı kurarken zorlanmıştın; "
                "bu kez kendin kurdun.")

    on, sn = onceki["adim"], simdi["adim"]
    oy, sy = onceki.get("yardimli", 0), simdi.get("yardimli", 0)
    if sy < oy and _oran(sy, sn) < _oran(oy, on):
        if sy == 0:
            return ("Geçen sefer bu konuda {} adımda yardım almıştın; "
                    "bu kez hiç almadın.".format(oy))
        return "Geçen sefer bu konuda {} adımda yardım aldın; bu kez {}.".format(
            oy, sy)

    ot, st = onceki.get("takilan", 0), simdi.get("takilan", 0)
    if st < ot and _oran(st, sn) < _oran(ot, on):
        if st == 0:
            return ("Geçen sefer bu konuda {} adımda takılmıştın; "
                    "bu kez hiç takılmadın.".format(ot))
        return "Geçen sefer bu konuda {} adımda takıldın; bu kez {}.".format(
            ot, st)
    return None
