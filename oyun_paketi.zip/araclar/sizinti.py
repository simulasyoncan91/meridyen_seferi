# -*- coding: utf-8 -*-
"""
Şık sızıntısı ölçümü (B46.5b): doğru şık, soruyu okumadan bulunabiliyor mu?

    python main.py --sizinti

NEDEN VAR
---------
Sınavı iyi bilen öğrenci içeriği bilmeden de puan toplar: "en uzun, en
ayrıntılı şık doğrudur" ya da "doğru hep aynı yerdedir". Görev yazarı doğru
cevabı özenle niteler ("... çünkü ...; ... ile birlikte okunur"), yanlışları
kısa bırakır -- iyi niyetle yapılan en yaygın sızıntı budur. Pilot öncesi
(B46.6) ölçülmeli: sızıntı varsa oyun ölçtüğünü sandığı şeyi ölçmez.

NE ÖLÇER
--------
Seçim türündeki (SECIM) her adımda: doğru şık TEK BAŞINA en uzun mu, ve
doğru şıkkın sırası. Rastgele dağılımda "en uzun" oranı yaklaşık 1/şık
sayısıdır (4 şıkta %25). Üretici başına oran ve genel sıra dağılımı basılır.

KALIP SIZINTISI (24 Eylül 2026)
-------------------------------
En-uzun sızıntısı "yanlış şıkka yanılgının gerekçesini ekle" diye giderildi;
ekler çoğunlukla "; ..." biçiminde. Yanlışların HEPSİ ekliyse ve doğru
eksizse öğrenci "noktalı virgülü olmayanı seç" der: aynı ipucu kılık
değiştirmiş olur. Bu yüzden üç ölçü daha: doğru şık tek başına EN KISA mı,
';' içermeyen TEK şık mı, ';' içeren TEK şık mı.
"""
from __future__ import annotations

import collections
import random
from typing import Dict, List, Optional, Tuple

from oyun.motor import kayit_defteri
from oyun.motor.modeller import SECIM

TOHUM_SAYISI = 8
ESIK = 0.6          # bu oranın üstü "sızdırıyor" sayılır (4 şıkta beklenen ~0,25)


def en_uzun_mu(adim) -> bool:
    uzunluklar = [len(s) for s in adim.secenekler]
    dogru = uzunluklar[adim.cevap]
    return all(dogru > u for i, u in enumerate(uzunluklar) if i != adim.cevap)


def en_kisa_mi(adim) -> bool:
    uzunluklar = [len(s) for s in adim.secenekler]
    dogru = uzunluklar[adim.cevap]
    return all(dogru < u for i, u in enumerate(uzunluklar) if i != adim.cevap)


def _ekli(secenek: str) -> bool:
    return ";" in secenek


def tek_eksiz_mi(adim) -> bool:
    """Doğru şık, ';' içermeyen TEK şık mı (öteki hepsi ekli)?"""
    return (not _ekli(adim.secenekler[adim.cevap])
            and all(_ekli(s) for i, s in enumerate(adim.secenekler) if i != adim.cevap))


def tek_ekli_mi(adim) -> bool:
    """Doğru şık, ';' içeren TEK şık mı (ötekilerin hiçbiri ekli değil)?"""
    return (_ekli(adim.secenekler[adim.cevap])
            and not any(_ekli(s) for i, s in enumerate(adim.secenekler) if i != adim.cevap))


def tarama(tohum_sayisi: int = TOHUM_SAYISI,
           aralik: Optional[Tuple[int, int]] = None) -> Dict:
    """`aralik` verilirse (ör. lise 9-12) üreticiler o aralıktaki en düşük
    kademelerinde ölçülür; aralığa girmeyenler atlanır (bkz. duvar.ilk_kademe)."""
    from araclar.duvar import ilk_kademe
    kayit_defteri.icerigi_yukle()
    ureticiler: List[Dict] = []
    sira = collections.Counter()
    kalip = collections.Counter()
    toplam = uzun = 0
    for kayit in kayit_defteri.tum_kayitlar():
        kademe = ilk_kademe(kayit, aralik)
        if kademe is None:
            continue
        n = u = k = 0
        ks = ke = ka = 0
        for tohum in range(tohum_sayisi):
            try:
                b = kayit.fonksiyon(random.Random(tohum), kademe)
            except Exception:          # noqa: BLE001 -- denetim ayrı araçta
                continue
            for adim in b.adimlar:
                if adim.tur != SECIM or not adim.secenekler or len(adim.secenekler) < 3:
                    continue
                n += 1
                u += en_uzun_mu(adim)
                sira[(len(adim.secenekler), adim.cevap)] += 1
                eksiz, ekli = tek_eksiz_mi(adim), tek_ekli_mi(adim)
                kisa = en_kisa_mi(adim)
                kalip["en_kisa"] += kisa
                kalip["tek_eksiz"] += eksiz
                kalip["tek_ekli"] += ekli
                k += eksiz or ekli
                ks += kisa
                ke += eksiz
                ka += ekli
        if n:
            ureticiler.append({"ders": kayit.ders, "ad": kayit.fonksiyon.__name__,
                               "adim": n, "oran": u / n, "kalip": k / n,
                               "en_kisa": ks / n, "tek_eksiz": ke / n,
                               "tek_ekli": ka / n})
            toplam += n
            uzun += u
    ureticiler.sort(key=lambda o: -o["oran"])
    payda = max(1, toplam)
    return {"ureticiler": ureticiler, "toplam": toplam,
            "en_uzun_orani": uzun / payda, "sira": sira,
            "en_kisa_orani": kalip["en_kisa"] / payda,
            "tek_eksiz_orani": kalip["tek_eksiz"] / payda,
            "tek_ekli_orani": kalip["tek_ekli"] / payda}


def yazdir(adet: int = 25, aralik: Optional[Tuple[int, int]] = None) -> None:
    s = tarama(aralik=aralik)
    sizan = [o for o in s["ureticiler"] if o["oran"] > ESIK]
    print("ŞIK SIZINTISI -- {} seçim adımı, {} üretici{}".format(
        s["toplam"], len(s["ureticiler"]),
        "" if aralik is None else " ({}-{}. sınıf)".format(*aralik)))
    print("Doğru şık tek başına EN UZUN: %{:.0f} (rastgele 4 şıkta ~%25)".format(
        100 * s["en_uzun_orani"]))
    print("Eşik %{:.0f} üstü: {} üretici".format(100 * ESIK, len(sizan)))
    print("Kalıp: doğru tek başına EN KISA %{:.0f} | ';' içermeyen TEK şık %{:.0f} | "
          "';' içeren TEK şık %{:.0f}".format(100 * s["en_kisa_orani"],
                                             100 * s["tek_eksiz_orani"],
                                             100 * s["tek_ekli_orani"]))
    for sayi in sorted({k[0] for k in s["sira"]}):
        dagilim = [s["sira"][(sayi, i)] for i in range(sayi)]
        tum = max(1, sum(dagilim))
        print("  {} şıklı adımlarda doğrunun sırası: {}".format(
            sayi, "  ".join("{}. %{:.0f}".format(i + 1, 100 * d / tum)
                            for i, d in enumerate(dagilim))))
    print()
    for o in s["ureticiler"][:adet]:
        print("  %{:>3.0f}  {:<40} ({} adım)".format(
            100 * o["oran"], "{}.{}".format(o["ders"], o["ad"]), o["adim"]))
    kalipli = sorted((o for o in s["ureticiler"] if o["kalip"] > ESIK),
                     key=lambda o: -o["kalip"])
    if kalipli:
        print()
        print("Kalıp sızıntısı (doğru tek eksiz/tek ekli) %{:.0f} üstü: {} üretici".format(
            100 * ESIK, len(kalipli)))
        for o in kalipli[:adet]:
            print("  %{:>3.0f}  {:<40} ({} adım)".format(
                100 * o["kalip"], "{}.{}".format(o["ders"], o["ad"]), o["adim"]))
