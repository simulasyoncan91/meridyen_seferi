# -*- coding: utf-8 -*-
"""
İfade adımı: öğrenci SORUYU KURAR.

Kullanıcı (5 Kasım 2026): "matematikte bir işlem sonucu verilir ve istenen
şekilde sorunun tekrar yazılması istenir. Yani sadece soruyu çözmek için
eğitilmez, sorunun nasıl yapıldığını görüp mantık yürütmesi de öğretilir."

Adımın cevabı tek bir sayı değil, bir KURAL: verilen sayıların her biri
tam bir kez kullanılacak, dört işlem ve parantezle hedefe ulaşılacak, varsa
ek koşul (son işlem çıkarma olsun, çarpma kullanılmasın...) sağlanacak.
Birden çok doğru cevap vardır; hepsi kabul edilir.

GÜVENLİK: öğrencinin yazdığı metin `eval` EDİLMEZ. `ast` ile ayrıştırılır;
yalnız sayı, + - * / ve parantez kabul edilir, hesap `Fraction` ile kesin
yapılır (0,1 + 0,2 sorunu yok, sıfıra bölme yakalanır).
"""
from __future__ import annotations

import ast
import itertools
from fractions import Fraction
from typing import Dict, Iterable, List, Optional, Tuple

ISLEM_ADLARI = {"+": "toplama", "-": "çıkarma", "*": "çarpma", "/": "bölme"}


def _asal_mi(n: int) -> bool:
    return n >= 2 and all(n % k for k in range(2, int(n ** 0.5) + 1))


# Sayı kuralları: (öğrenciye görünen metin, sınama). Kural merdiveni bunlardan
# karışık seçer; aynı soru tipi her seferinde başka bir kısıtla gelir.
SAYI_OZELLIKLERI = {
    "cift": ("her sayı çift olsun", lambda s: s % 2 == 0),
    "tek": ("her sayı tek olsun", lambda s: s % 2 == 1),
    "kat3": ("her sayı 3'ün katı olsun", lambda s: s % 3 == 0),
    "kat5": ("her sayı 5'in katı olsun", lambda s: s % 5 == 0),
    "asal": ("her sayı asal olsun", _asal_mi),
    "sifirsiz": ("hiçbir sayıda 0 rakamı geçmesin", lambda s: "0" not in str(s)),
}
_AST_ISLEM = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/"}
AZAMI_UZUNLUK = 120


class IfadeHatasi(ValueError):
    pass


def _normalle(ham: str) -> str:
    metin = (ham or "").strip()
    for eski, yeni in (("×", "*"), ("x", "*"), ("X", "*"), ("·", "*"),
                       ("÷", "/"), (":", "/"), ("−", "-"), ("[", "("), ("]", ")")):
        metin = metin.replace(eski, yeni)
    return metin


def coz(ham: str) -> Tuple[Fraction, List[int], List[str], Optional[str]]:
    """(değer, kullanılan sayılar, kullanılan işlemler, son işlem).

    Geçersiz yazımda IfadeHatasi; mesajı öğrenciye gösterilir.
    """
    metin = _normalle(ham)
    if not metin:
        raise IfadeHatasi("Boş bıraktın.")
    if len(metin) > AZAMI_UZUNLUK:
        raise IfadeHatasi("İşlem çok uzun.")
    try:
        agac = ast.parse(metin, mode="eval")
    except SyntaxError:
        raise IfadeHatasi("İşlemi okuyamadım. Örnek yazım: (3+5)×2")
    sayilar: List[int] = []
    islemler: List[str] = []

    def hesap(dugum) -> Fraction:
        if isinstance(dugum, ast.Expression):
            return hesap(dugum.body)
        if isinstance(dugum, ast.Constant) and isinstance(dugum.value, int) \
                and not isinstance(dugum.value, bool):
            sayilar.append(int(dugum.value))
            return Fraction(dugum.value)
        if isinstance(dugum, ast.BinOp) and type(dugum.op) in _AST_ISLEM:
            sol, sag = hesap(dugum.left), hesap(dugum.right)
            isaret = _AST_ISLEM[type(dugum.op)]
            islemler.append(isaret)
            if isaret == "+":
                return sol + sag
            if isaret == "-":
                return sol - sag
            if isaret == "*":
                return sol * sag
            if sag == 0:
                raise IfadeHatasi("Sıfıra bölme var.")
            return sol / sag
        raise IfadeHatasi("Yalnız tam sayılar, + − × ÷ ve parantez kullanılabilir.")

    deger = hesap(agac)
    govde = agac.body
    son = _AST_ISLEM.get(type(govde.op)) if isinstance(govde, ast.BinOp) else None
    return deger, sayilar, islemler, son


def iliskiler(ham: str) -> set:
    """(üst işlem, alt işlem) çiftleri: "(9-4)×3" -> {("*", "-")}.

    "Parantez içinde çıkarma, sonucu çarpılsın" gibi kuralları sınamak için.
    `coz` başarılıysa çağrılır; yazım geçersizse boş küme.
    """
    try:
        agac = ast.parse(_normalle(ham), mode="eval")
    except SyntaxError:
        return set()
    ciftler = set()
    for dugum in ast.walk(agac):
        if isinstance(dugum, ast.BinOp) and type(dugum.op) in _AST_ISLEM:
            ust = _AST_ISLEM[type(dugum.op)]
            for cocuk in (dugum.left, dugum.right):
                if isinstance(cocuk, ast.BinOp) and type(cocuk.op) in _AST_ISLEM:
                    ciftler.add((ust, _AST_ISLEM[type(cocuk.op)]))
    return ciftler


def kosul_metni(kosul: Dict) -> str:
    parcalar = []
    if kosul.get("serbest"):
        parcalar.append("tam {} sayı kullan".format(kosul.get("adet", "?")))
        if kosul.get("farkli"):
            parcalar.append("sayıların hepsi birbirinden farklı olsun")
        if kosul.get("yayilim") is not None:
            parcalar.append("en büyükle en küçük arasındaki fark en çok {} olsun".format(
                kosul["yayilim"]))
        if kosul.get("en_kucuk") is not None:
            parcalar.append("her sayı en az {} olsun".format(kosul["en_kucuk"]))
        if kosul.get("en_buyuk") is not None:
            parcalar.append("her sayı en çok {} olsun".format(kosul["en_buyuk"]))
        for ozellik in kosul.get("ozellik", ()):
            parcalar.append(SAYI_OZELLIKLERI[ozellik][0])
        if kosul.get("artan"):
            parcalar.append("sayıları küçükten büyüğe sırayla yaz")
    for isaret in kosul.get("gerekli", ()):
        parcalar.append("en az bir {} olsun".format(ISLEM_ADLARI[isaret]))
    for ust, alt in kosul.get("yapi", ()):
        parcalar.append("bir {} parantez içinde olsun ve sonucu {} girsin".format(
            ISLEM_ADLARI[alt], {"*": "çarpmaya", "/": "bölmeye", "+": "toplamaya",
                                "-": "çıkarmaya"}[ust]))
    if kosul.get("son_islem"):
        parcalar.append("son yapılan işlem {} olsun".format(
            ISLEM_ADLARI[kosul["son_islem"]]))
    yasak = list(kosul.get("yasak", ()))
    izinli = [i for i in "+-*/" if i not in yasak]
    if len(izinli) == 1:
        parcalar.append("yalnız {} kullan".format(ISLEM_ADLARI[izinli[0]]))
    else:
        for isaret in yasak:
            parcalar.append("{} kullanılmasın".format(ISLEM_ADLARI[isaret]))
    return "; ".join(parcalar)


def denetle(ham: str, hedef, sayilar: Iterable[int], kosul: Optional[Dict] = None
            ) -> Tuple[bool, str]:
    """(doğru mu, geri bildirim)."""
    kosul = kosul or {}
    try:
        deger, kullanilan, islemler, son = coz(ham)
    except IfadeHatasi as hata:
        return False, str(hata)
    if kosul.get("serbest"):
        hata = _serbest_denetle(ham, kullanilan, islemler, kosul)
        if hata:
            return False, hata
        if deger != Fraction(hedef):
            return False, "İşlemin sonucu {}, hedef {}.".format(_yaz(deger), hedef)
        return True, ""
    beklenen = sorted(int(s) for s in sayilar)
    if sorted(kullanilan) != beklenen:
        eksik = list(beklenen)
        fazla = []
        for s in kullanilan:
            if s in eksik:
                eksik.remove(s)
            else:
                fazla.append(s)
        parca = []
        if eksik:
            parca.append("kullanmadığın: " + ", ".join(map(str, eksik)))
        if fazla:
            parca.append("listede olmayan ya da fazla: " + ", ".join(map(str, fazla)))
        return False, "Sayıların her biri tam bir kez kullanılmalı ({}).".format(
            "; ".join(parca))
    for isaret in kosul.get("yasak", ()):
        if isaret in islemler:
            return False, "Bu kez {} kullanmamalısın.".format(ISLEM_ADLARI[isaret])
    if deger != Fraction(hedef):
        return False, "İşlemin sonucu {}, hedef {}.".format(_yaz(deger), hedef)
    if kosul.get("son_islem") and son != kosul["son_islem"]:
        return False, "Sonuç doğru ama son işlem {} değil.".format(
            ISLEM_ADLARI[kosul["son_islem"]])
    return True, ""


def _serbest_denetle(ham, kullanilan, islemler, kosul) -> str:
    """Sayıları öğrencinin seçtiği kural merdiveni (kullanıcı, 5 Kasım 2026:
    "58 sonucuna 58+0 ya da 57+1 yazıp geçebilirler; kurallar ekleyelim,
    seçenekleri yavaş yavaş daraltalım")."""
    adet = kosul.get("adet")
    if adet and len(kullanilan) != adet:
        return "Tam {} sayı kullanmalısın; sen {} sayı kullandın.".format(adet, len(kullanilan))
    if kosul.get("farkli") and len(set(kullanilan)) != len(kullanilan):
        return "Sayıların hepsi birbirinden farklı olmalı."
    if kosul.get("en_kucuk") is not None and min(kullanilan) < kosul["en_kucuk"]:
        return "Her sayı en az {} olmalı.".format(kosul["en_kucuk"])
    if kosul.get("en_buyuk") is not None and max(kullanilan) > kosul["en_buyuk"]:
        return "Her sayı en çok {} olmalı.".format(kosul["en_buyuk"])
    for ozellik in kosul.get("ozellik", ()):
        metin, sina = SAYI_OZELLIKLERI[ozellik]
        uymayan = [s for s in kullanilan if not sina(s)]
        if uymayan:
            return "Kural: {} ({} uymuyor).".format(
                metin, ", ".join(map(str, uymayan)))
    if kosul.get("artan") and any(a >= b for a, b in zip(kullanilan, kullanilan[1:])):
        return "Sayıları yazdığın sıra küçükten büyüğe gitmeli."
    if kosul.get("yayilim") is not None and max(kullanilan) - min(kullanilan) > kosul["yayilim"]:
        return ("Sayılar birbirine yakın olmalı: en büyükle en küçük arasındaki "
                "fark en çok {} (seninkinde {}).").format(
                    kosul["yayilim"], max(kullanilan) - min(kullanilan))
    for isaret in kosul.get("gerekli", ()):
        if isaret not in islemler:
            return "En az bir {} kullanmalısın.".format(ISLEM_ADLARI[isaret])
    for isaret in kosul.get("yasak", ()):
        if isaret in islemler:
            return "Bu kez {} kullanmamalısın.".format(ISLEM_ADLARI[isaret])
    var = iliskiler(ham)
    for ust, alt in kosul.get("yapi", ()):
        if (ust, alt) not in var:
            return "Bir {} parantez içinde olmalı ve sonucu {} girmeli.".format(
                ISLEM_ADLARI[alt], {"*": "çarpmaya", "/": "bölmeye", "+": "toplamaya",
                                    "-": "çıkarmaya"}[ust])
    return ""


def _yaz(deger: Fraction) -> str:
    if deger.denominator == 1:
        return str(deger.numerator)
    return "{}/{}".format(deger.numerator, deger.denominator)


# ------------------------------------------------------------------ çözücü
def tum_ifadeler(sayilar: List[int], islemler: str = "+-*/"
                 ) -> Dict[Fraction, List[Tuple[str, str]]]:
    """Sayıların hepsini birer kez kullanan bütün ifadeler.

    {değer: [(yazım, son işlem), ...]}. Dört sayıya kadar anlık (görev
    üretimi ve denetim için; öğrenciye gösterilmez).
    """
    def kur(dizi):
        if len(dizi) == 1:
            yield Fraction(dizi[0]), str(dizi[0]), None
            return
        for i in range(1, len(dizi)):
            for sd, sy, _ in kur(dizi[:i]):
                for gd, gy, _ in kur(dizi[i:]):
                    for isaret in islemler:
                        if isaret == "/" and gd == 0:
                            continue
                        deger = {"+": sd + gd, "-": sd - gd, "*": sd * gd,
                                 "/": sd / gd if gd else None}[isaret]
                        yield deger, "({}{}{})".format(sy, isaret, gy), isaret

    sonuc: Dict[Fraction, List[Tuple[str, str]]] = {}
    for dizi in set(itertools.permutations(sayilar)):
        for deger, yazim, son in kur(list(dizi)):
            sonuc.setdefault(deger, []).append((yazim[1:-1] if len(dizi) > 1 else yazim, son))
    return sonuc


def kosula_uyan(sayilar: List[int], hedef, kosul: Optional[Dict] = None
                ) -> Optional[str]:
    """Koşula uyan bir örnek çözüm; yoksa None."""
    kosul = kosul or {}
    izinli = "".join(i for i in "+-*/" if i not in kosul.get("yasak", ()))
    for yazim, son in tum_ifadeler(sayilar, izinli).get(Fraction(hedef), []):
        if kosul.get("son_islem") and son != kosul["son_islem"]:
            continue
        return okunur(yazim)
    return None


def okunur(yazim: str) -> str:
    return yazim.replace("*", "×").replace("/", "÷")
