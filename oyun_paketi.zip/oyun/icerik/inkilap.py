# -*- coding: utf-8 -*-
"""
Yakın tarih ve değişim görevleri.

Kronograf bu dersi doğal olarak taşıyor: aygıt bir belge parçası getiriyor,
üzerinde tarih ya da başlık yok, yalnızca kararlar yazılı. Öğrenci hangi
kongreye ya da hangi aşamaya ait olduğunu kararların içeriğinden çıkarıyor.

Bu, dersin ezber kısmını değil ayırt etme kısmını çalıştırır: Erzurum ile
Sivas kararlarını birbirinden ayıran şey tarih değil, kapsamdır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi, secim_adimi, sirala_adimi,
    yorum_adimi,
)


# ==========================================================================
# BELGEDEN AŞAMA TESPİTİ
# ==========================================================================

_BELGELER = [
    {
        "ad": "Amasya Genelgesi (1919)",
        "kararlar": (
            "- Vatanın bütünlüğü ve milletin bağımsızlığı tehlikededir.\n"
            "- İstanbul Hükûmeti üzerine aldığı sorumluluğu yerine "
            "getirememektedir.\n"
            "- Milletin bağımsızlığını yine milletin azim ve kararı "
            "kurtaracaktır.\n"
            "- Sivas'ta millî bir kongre toplanacaktır."
        ),
        "ayirt_edici": ("Kurtuluşun yöntemini ilk kez ortaya koyan ve bir kongre "
                        "toplanmasını duyuran genelgedir; henüz kararlar alınmamış, "
                        "çağrı yapılmıştır."),
    },
    {
        "ad": "Erzurum Kongresi (1919)",
        "kararlar": (
            "- Millî sınırlar içinde vatan bir bütündür, bölünemez.\n"
            "- Kuvâ-yi Millîye'yi etkin, millî iradeyi hâkim kılmak esastır.\n"
            "- Manda ve himaye kabul edilemez.\n"
            "- Doğu illerinin haklarını korumak için çalışılacaktır."
        ),
        "ayirt_edici": ("Toplanışı bakımından BÖLGESEL, aldığı kararlar bakımından "
                        "millîdir. \"Doğu illeri\" ifadesi bölgesel niteliğini ele verir."),
    },
    {
        "ad": "Sivas Kongresi (1919)",
        "kararlar": (
            "- Erzurum Kongresi kararları biraz genişletilerek kabul edilmiştir.\n"
            "- Bütün millî cemiyetler \"Anadolu ve Rumeli Müdafaa-i Hukuk "
            "Cemiyeti\" adı altında birleştirilmiştir.\n"
            "- Manda ve himaye kesin olarak reddedilmiştir.\n"
            "- Temsil Heyeti bütün vatanı temsil eder."
        ),
        "ayirt_edici": ("Hem toplanışı hem kararları bakımından MİLLÎDİR. "
                        "Cemiyetlerin tek çatı altında birleştirilmesi yalnızca "
                        "bu kongrede olmuştur."),
    },
]


@bulmaca(ders="inkilap", konu="milli_mucadele", kademeler=(6, 10), agirlik=1.5)
def belge_tespiti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Başlıksız bir karar metninden hangi aşamaya ait olduğunu çıkarma."""
    belge = rastgele.choice(_BELGELER)
    digerleri = [b for b in _BELGELER if b["ad"] != belge["ad"]]

    return Bulmaca(
        kod="ink-belge-tespiti",
        ders="inkilap",
        baslik="Başlıksız Karar",
        kademe=kademe,
        konu="milli_mucadele",
        kazanim="Millî Mücadele belgelerini içeriklerinden ayırt etme.",
        dikkat=6,
        brifing=(
            "Kronograf bir belge parçası getirdi. Üst kısmı yanmış: başlık da "
            "tarih de okunmuyor. Yalnızca kararlar sağlam kalmış:\n\n"
            "{}\n\n"
            "Arşive hangi belge olduğunu yazmamız gerekiyor. Tarih yok, imza "
            "yok; elimizde sadece kararların kendisi var."
        ).format(belge["kararlar"]),
        kanitlar=[
            Kanit("Belge metni", belge["kararlar"], bedel=1, kritik=True),
            Kanit("Karşılaştırma çizelgesi",
                  "AMASYA GENELGESİ: Kurtuluşun yöntemini duyurur, Sivas'ta "
                  "kongre toplanmasını ÇAĞIRIR. Karar organı değil, çağrıdır.\n\n"
                  "ERZURUM KONGRESİ: Toplanışı BÖLGESEL (doğu illeri), kararları "
                  "millîdir. Manda ve himaye reddedilir.\n\n"
                  "SİVAS KONGRESİ: Toplanışı da kararları da MİLLÎDİR. Bütün millî "
                  "cemiyetler tek çatı altında birleştirilir.",
                  bedel=2, kritik=True),
            Kanit("Arşivci notu",
                  "\"Bu üç belgeyi tarihle değil KAPSAMLA ayır. Metinde 'doğu "
                  "illeri' geçiyorsa bölgesel, 'bütün cemiyetler birleştirildi' "
                  "geçiyorsa millî, 'kongre toplanacaktır' geçiyorsa henüz "
                  "çağrı aşamasındadır.\"", bedel=2, kritik=True),
            Kanit("Belgenin kâğıdı",
                  "Kâğıt ve mürekkep aynı dönemin; hepsi 1919 yılına ait "
                  "olabilir. Kâğıttan ayrım yapmak mümkün değil.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu belgeyi tanımak için neye bakmak gerekir?",
                dogru="Kararların kapsamına: bölgesel mi, millî mi, çağrı mı.",
                yanlislar={
                    "Belgenin kaç madde içerdiğine; önemli belge daha çok madde taşır.":
                        "Madde sayısına baktın. Belgeleri ayıran şey kaç madde "
                        "oldukları değil, hangi KARARI ilk kez dile "
                        "getirdikleri.",
                    "Kullanılan kâğıdın ve mürekkebin cinsine; eski belge kâğıdından tanınır.":
                        "Fiziksel özelliğe baktın. Bu bir belge sahteciliği "
                        "incelemesi değil; belgeyi tanıtan şey içeriği.",
                    "Cümlelerin uzunluğuna.":
                        "Üsluba baktın. Dönemin bütün belgeleri benzer dille "
                        "yazılmıştır.",
                    "Belgede geçen kişi adlarına; imzalayan kimse belge onundur.":
                        "Adlara baktın. Aynı kişiler birçok belgede geçer; "
                        "ayırt edici olan alınan kararın kendisi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Üç belge de 1919'a ait ve üçü de aynı amaca hizmet ediyor; bu "
                    "yüzden tarih ya da üslup ayırt etmez. Ayıran şey kapsamdır: "
                    "Amasya bir çağrıdır, Erzurum bölgesel toplanmıştır, Sivas bütün "
                    "cemiyetleri birleştirmiştir. Belgeyi tanımak, bu üç kapsamdan "
                    "hangisinin metinde göründüğünü görmektir."
                ),
                ipuclari=[
                    "Metinde bir bölge adı geçiyor mu?",
                    "Metin bir kongre topluyor mu, yoksa toplanmasını mı istiyor?",
                ],
                puan=20,
                cozum=(
                    "1) Metinde kapsam işaretlerini ara:\n"
                    "   - \"kongre toplanacaktır\" -> henüz ÇAĞRI (Amasya)\n"
                    "   - \"doğu illeri\" gibi bölge adı -> BÖLGESEL toplanış (Erzurum)\n"
                    "   - \"bütün cemiyetler birleştirilmiştir\" -> MİLLÎ (Sivas)\n"
                    "2) Bu belgede öne çıkan: {}\n\n"
                    "Sonuç: {}"
                ).format(belge["ayirt_edici"], belge["ad"]),
            ),
            secim_adimi(
                soru="Bu belge hangisidir?",
                dogru=belge["ad"],
                yanlislar=dict(
                    [(b["ad"], "{} belgesinin ayırt edici kararı bu metinde "
                               "geçmiyor. Çizelgedeki tanımı metinle "
                               "karşılaştır.".format(b["ad"])) for b in digerleri]
                    + [("Lozan Antlaşması (1923)",
                        "Lozan bir barış antlaşmasıdır ve Kurtuluş Savaşı'nın "
                        "SONUNDA imzalandı. Elindeki metin savaş öncesi "
                        "örgütlenme dönemine ait.")]
                ),
                rastgele=rastgele,
                aciklama=belge["ayirt_edici"],
                ipuclari=["Çizelgedeki üç tanımı metinle karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Erzurum Kongresi neden \"toplanışı bölgesel, kararları millî\" diye anılır?",
                dogru="Doğu illerinden temsilcilerle toplanıp bütün vatana dair karar aldığı için.",
                yanlislar={
                    "Bütün illerin temsilcileriyle toplandığı için; \"millî\" sözü katılanları anlatır.":
                        "Toplanışı ülke geneli saydın. Erzurum'a yalnızca doğu "
                        "illerinin temsilcileri katıldı; bütün illeri toplayan "
                        "kongre Sivas'tır.",
                    "Yalnızca doğu illerini ilgilendiren kararlar aldığı için; toplandığı yer de doğudadır.":
                        "Kararları da bölgesel saydın. Oysa alınan kararlar "
                        "vatanın bütününü ilgilendiriyordu; ifadeyi ilginç "
                        "kılan tam da bu.",
                    "Kararları sonradan geçersiz sayıldığı için.":
                        "Kararları geçersiz saydın. Erzurum'da alınanlar Sivas "
                        "Kongresi'nde benimsendi ve sürdü.",
                    "İstanbul Hükûmeti tarafından toplandığı için; millî kararı ancak hükûmet alabilir.":
                        "Toplayanı yanlış belirledin. Kongre yerel "
                        "cemiyetlerin girişimiyle toplandı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kongreye katılanlar doğu illerinin temsilcileriydi; bu yönüyle "
                    "toplanış bölgeseldir. Ama alınan \"millî sınırlar içinde vatan "
                    "bir bütündür\" kararı bütün ülkeyi kapsar. Bir kongreyi "
                    "değerlendirirken kimin toplandığı ile neye karar verildiği ayrı "
                    "ayrı bakılması gereken iki şeydir."
                ),
                puan=12,
            ),
        ],
        kapanis="Belge \"{}\" olarak fişlendi ve arşive kaldırıldı.".format(belge["ad"]),
        odul={"itibar": 8},
    )


# ==========================================================================
# KRONOLOJİ
# ==========================================================================

@bulmaca(ders="inkilap", konu="kronoloji", kademeler=(6, 10))
def milli_mucadele_kronolojisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Millî Mücadele olaylarını sıraya dizme."""
    havuz = [
        ("Mondros Ateşkesi'nin imzalanması", 1918.10),
        ("Mustafa Kemal'in Samsun'a çıkması", 1919.05),
        ("Amasya Genelgesi'nin yayımlanması", 1919.06),
        ("Erzurum Kongresi'nin toplanması", 1919.07),
        ("Sivas Kongresi'nin toplanması", 1919.09),
        ("Büyük Millet Meclisi'nin açılması", 1920.04),
        ("Sakarya Meydan Muharebesi'nin kazanılması", 1921.08),
        ("Büyük Taarruz'un başlaması", 1922.08),
        ("Lozan Barış Antlaşması'nın imzalanması", 1923.07),
        ("Cumhuriyet yönetiminin ilan edilmesi", 1923.10),
    ]
    adet = 4 if kademe <= 7 else 5
    secilen = rastgele.sample(havuz, adet)
    karisik = list(secilen)
    rastgele.shuffle(karisik)
    secenekler = [ad for ad, _ in karisik]
    sirali = sorted(range(len(karisik)), key=lambda i: karisik[i][1])
    dogru_liste = " -> ".join(karisik[i][0] for i in sirali)

    return Bulmaca(
        kod="ink-kronoloji",
        ders="inkilap",
        baslik="Dağılan Zaman Şeridi",
        kademe=kademe,
        konu="kronoloji",
        kazanim="Millî Mücadele dönemi olaylarını kronolojik sıraya koyma.",
        dikkat=5,
        brifing=(
            "Arşivde Millî Mücadele için hazırlanmış bir zaman şeridi vardı; "
            "kartlar yere düşüp karışmış.\n\n"
            "Kartların üzerinde tarih yazmıyor, yalnızca olay adı var. Şeridin "
            "yeniden kurulması gerekiyor: sırasız bir zaman şeridi, hangi olayın "
            "hangisine yol açtığını göstermez."
        ),
        kanitlar=[
            Kanit("Dönem çizelgesi",
                  "1918: Mondros Ateşkesi, işgallerin başlaması\n"
                  "1919: Samsun'a çıkış, Amasya, Erzurum, Sivas\n"
                  "1920: Büyük Millet Meclisi'nin (TBMM) açılması\n"
                  "1921: Sakarya\n"
                  "1922: Büyük Taarruz\n"
                  "1923: Lozan, Cumhuriyet'in ilanı",
                  bedel=2, kritik=True),
            Kanit("Arşivci notu",
                  "\"Sıralamayı ezberden değil mantıktan da kurabilirsin: bir "
                  "meclis açılmadan antlaşma imzalanamaz, ateşkes olmadan işgal "
                  "başlamaz, savaş kazanılmadan barış görüşülmez.\"",
                  bedel=2, kritik=True),
            Kanit("Kart arkaları", "Hepsi boş; tarih yazılmamış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kartları sıraya dizerken hangi ölçüt işler?",
                dogru="Olayların birbirini gerektirme sırası ve tarihleri.",
                yanlislar={
                    "Olay adlarının uzunluğu.":
                        "Ad uzunluğunu ölçüt saydın. Bir olayın adının kaç "
                        "harf olduğunun ne zaman gerçekleştiğiyle ilgisi yok.",
                    "Olayların önem derecesi; en büyük olay şeridin başına gelir.":
                        "Önemi zamanla karıştırdın. Sıralama olayların "
                        "büyüklüğüne göre değil, TARİHİNE göre yapılır.",
                    "Olayların geçtiği şehirlerin alfabetik sırası.":
                        "Alfabeye baktın. Şehir adının sırası olayın tarihini "
                        "söylemez.",
                    "Kartların yerde bulunduğu sıra; düşerken sıraları bozulmamıştır.":
                        "Bulunuş sırasını kanıt saydın. Kartlar karışmış "
                        "hâlde; sıralamayı olayların kendi tarihleri "
                        "belirler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kronoloji yalnızca tarih ezberi değildir; olaylar birbirini "
                    "gerektirir. Barış antlaşması, savaşın sonucundan sonra gelir; "
                    "kongreler, kurtuluş yönteminin duyurulmasından sonra toplanır. "
                    "Tarihi hatırlamasan bile bu bağlar sıralamayı büyük ölçüde verir."
                ),
                ipuclari=[
                    "Hangi olay diğerlerinin başlamasına sebep oldu?",
                    "Bir antlaşma, savaştan önce mi sonra mı imzalanır?",
                ],
                puan=16,
                cozum=(
                    "1) Önce kesin olarak bildiğin uçları koy: en erken ve en geç olay.\n"
                    "2) Aradakileri neden-sonuç bağıyla yerleştir: ateşkes -> işgal -> "
                    "örgütlenme -> meclis -> savaş -> barış -> yeni rejim.\n"
                    "3) Dönem çizelgesiyle denetle.\n\n"
                    "Doğru sıra: " + dogru_liste
                ),
            ),
            sirala_adimi(
                soru="Olayları en eskiden en yeniye sırala (numaraları sırayla yaz):",
                secenekler=secenekler,
                dogru_sira=sirali,
                aciklama="Doğru sıra: " + dogru_liste,
                ipuclari=[
                    "Dönem çizelgesindeki yıllara bak.",
                    "Aynı yıl içindeki olayları neden-sonuç bağıyla ayır.",
                ],
                puan=22,
            ),
            secim_adimi(
                soru="Bu sıralamadaki en erken olay hangisidir?",
                dogru=karisik[sirali[0]][0],
                yanlislar={
                    karisik[i][0]: "Bu olay kurduğun sıralamada daha sonra "
                                   "geliyor. En SOLDAKİ karta bak."
                    for i in sirali[1:]
                },
                rastgele=rastgele,
                aciklama="Sıralamanın başındaki olay: {}.".format(karisik[sirali[0]][0]),
                ipuclari=["Kurduğun sıranın en solundaki karta bak."],
                puan=10,
            ),
        ],
        kapanis="Zaman şeridi yeniden kuruldu ve duvara asıldı.",
        odul={"itibar": 7},
    )


# ==========================================================================
# NEDEN - SONUÇ
# ==========================================================================

@bulmaca(ders="inkilap", konu="neden_sonuc", kademeler=(7, 10))
def inkilap_neden_sonuc(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir gelişmenin nedeni ile sonucunu ayırma."""
    olaylar = [
        {
            "olay": "TBMM'nin açılması (1920)",
            "neden": "İstanbul'un işgali ve Meclis-i Mebusan'ın kapatılması",
            "sonuc": "Ankara'da millî iradeye dayanan bir yönetimin doğması",
            "yanlis_nedenler": [
                "Lozan Antlaşması'nın imzalanması",
                "Cumhuriyet'in ilan edilmesi",
                "Büyük Taarruz'un kazanılması ve Batı Anadolu'nun kurtarılması",
            ],
        },
        {
            "olay": "Sivas Kongresi'nin toplanması (1919)",
            "neden": "Millî cemiyetlerin dağınık çalışması ve tek çatı ihtiyacı",
            "sonuc": "Bütün millî cemiyetlerin tek bir cemiyet altında birleşmesi",
            "yanlis_nedenler": [
                "TBMM'nin açılmış olması",
                "Sakarya Savaşı'nın kazanılıp düşman ilerleyişinin durdurulması",
                "Saltanatın kaldırılması",
            ],
        },
        {
            "olay": "Lozan Antlaşması'nın imzalanması (1923)",
            "neden": "Büyük Taarruz'un kazanılıp askerî üstünlüğün sağlanması",
            "sonuc": "Türkiye'nin bağımsızlığının uluslararası alanda tanınması",
            "yanlis_nedenler": [
                "Cumhuriyet'in ilan edilmiş olması",
                "Mondros Ateşkesi'nin imzalanması",
                "Amasya Genelgesi'nin yayımlanması ve kongrelere çağrı yapılması",
            ],
        },
    ]
    olay = rastgele.choice(olaylar)

    return Bulmaca(
        kod="ink-neden-sonuc",
        ders="inkilap",
        baslik="Öncesi ve Sonrası",
        kademe=kademe,
        konu="neden_sonuc",
        kazanim="Tarihsel olaylarda neden ile sonucu ayırt etme.",
        dikkat=5,
        brifing=(
            "Arşiv fişlerinde her olayın \"öncesi\" ve \"sonrası\" hanesi var. "
            "Elindeki fişte olay yazılı ama iki hane de boş:\n\n"
            "  {}\n\n"
            "Fişi tamamlaman gerekiyor. Bir hataya dikkat: sonradan olan her şey "
            "sonuç değildir; sonuç, o olayın YOL AÇTIĞI şeydir."
        ).format(olay["olay"]),
        kanitlar=[
            Kanit("Fiş", olay["olay"], bedel=1, kritik=True),
            Kanit("Arşiv yönergesi",
                  "\"NEDEN: olaydan önce var olan ve olayı hazırlayan durum.\n"
                  "SONUÇ: olaydan sonra ortaya çıkan ve olayın yol açtığı değişiklik.\n"
                  "Sonradan gerçekleşen her olay sonuç değildir; arada bir bağ "
                  "olmalıdır.\"", bedel=2, kritik=True),
            Kanit("Zaman şeridi",
                  "1918 Mondros -> 1919 kongreler -> 1920 TBMM -> 1921-22 savaşlar "
                  "-> 1923 Lozan ve Cumhuriyet", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir gelişmenin \"sonuç\" sayılması için ne gerekir?",
                dogru="Olaydan sonra gerçekleşmesi VE olayın ona yol açmış olması.",
                yanlislar={
                    "Yalnızca olaydan sonra gerçekleşmesi; ardından gelen her şey sonuçtur.":
                        "Zamanı tek koşul saydın. Sonra gerçekleşen her şey "
                        "sonuç değildir; arada bir NEDEN-SONUÇ bağı da "
                        "olmalı.",
                    "Olaydan önce gerçekleşmesi.":
                        "Yönü ters aldın. Önce gerçekleşen şey sonuç değil, "
                        "olsa olsa nedendir.",
                    "Aynı yıl içinde gerçekleşmesi.":
                        "Aynı yıla düşmeyi bağ saydın. Bir olayın sonucu "
                        "yıllar sonra ortaya çıkabilir.",
                    "Aynı kişilerin karıştığı bir olay olması; ortak kişi ortak bağ demektir.":
                        "Ortak kişiyi bağ saydın. Aynı kişiler birbiriyle "
                        "ilgisiz olaylarda da bulunabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zaman sırası tek başına yetmez. Cumhuriyet, Lozan'dan sonra "
                    "ilan edilmiştir ama Lozan'ın sonucu diye anılmaz; ikisi ayrı "
                    "gelişmelerdir. Sonuç ilan edebilmek için olayla arasında bir "
                    "yol açma bağı kurulabilmelidir - tarihte \"ardından geldi\" ile "
                    "\"yüzünden oldu\" farklı iddialardır."
                ),
                ipuclari=[
                    "Bu iki olay arasında bir sebep bağı kurabiliyor musun?",
                    "\"Sonra oldu\" ile \"bu yüzden oldu\" aynı şey mi?",
                ],
                puan=18,
                cozum=(
                    "Fişi doldururken iki soru sor:\n"
                    "  1) Bu olayı ne HAZIRLADI? -> neden hanesi\n"
                    "  2) Bu olay neye YOL AÇTI? -> sonuç hanesi\n\n"
                    "  Olay: {}\n"
                    "  Neden: {}\n"
                    "  Sonuç: {}"
                ).format(olay["olay"], olay["neden"], olay["sonuc"]),
            ),
            secim_adimi(
                soru="Bu olayın nedeni aşağıdakilerden hangisidir?",
                dogru=olay["neden"],
                yanlislar=olay["yanlis_nedenler"] + [olay["sonuc"]],
                rastgele=rastgele,
                aciklama=(
                    "Neden olaydan ÖNCE gelir ve onu hazırlar: {}. Şıklardaki diğer "
                    "gelişmeler ya olaydan sonradır ya da onunla sebep bağı yoktur."
                ).format(olay["neden"]),
                ipuclari=["Zaman şeridine bak: hangisi bu olaydan önce gerçekleşti?"],
                puan=16,
            ),
            secim_adimi(
                soru="Bu olayın sonucu aşağıdakilerden hangisidir?",
                dogru=olay["sonuc"],
                yanlislar=dict(
                    [(olay["neden"],
                      "Bu, olayın NEDENİ - yani onu başlatan şey. Sonuç ise "
                      "olayın kendisinden sonra gelen değişikliktir.")]
                    + [(y, "Bu gelişmenin bu olayla neden-sonuç bağı yok. "
                           "\"Bu olay olmasaydı gerçekleşmez miydi?\" diye "
                           "sor.") for y in olay["yanlis_nedenler"]]
                ),
                rastgele=rastgele,
                aciklama="Sonuç, olayın yol açtığı değişikliktir: {}".format(olay["sonuc"]),
                ipuclari=["Bu olay olmasaydı hangisi gerçekleşmezdi?"],
                puan=16,
            ),
        ],
        kapanis="Fişin iki hanesi de dolduruldu.",
        odul={"itibar": 7},
    )


# ==========================================================================
# İÇ SİYASET: PARTİ KURULMASI, KESİNTİSİZ ÇOK PARTİLİ HAYAT DEĞİLDİR (B37.14)
#
# `ataturk_ic_siyaset_urunu` tek satırlıktı (2026: 12). Bağlam: "Arşivde
# farklı siyasi girişimlerin neden ve sonuçlarını karşılaştırma".
# `yaygin_yanlis`:
#
#   "Parti kurulmasını kesintisiz çok partili hayatla eşitlemek."
#
# DÜZENEK: arşivdeki parti kartları. Terakkiperver Cumhuriyet Fırkası
# (Kasım 1924 - Haziran 1925) Şeyh Said İsyanı ve Takrir-i Sükûn Kanunu
# döneminde kapatıldı; Serbest Cumhuriyet Fırkası (Ağustos - Kasım 1930)
# kurucularınca feshedildi. Kalıcı geçiş 1945-1946: Millî Kalkınma Partisi,
# Demokrat Parti, 1946 seçimi.
#
# YANILGININ SAYISAL KARŞILIĞI: 1924'ten kalıcı geçişe kadar geçen bütün
# ayları muhalefetli saymak (yüzde 100); oysa iki deneme toplam ~10 ay sürdü.
# ==========================================================================

# (tarih metni, olay) - kronolojik
_IC_SIYASET_OLAYLARI = (
    ("Kasım 1924", "Terakkiperver Cumhuriyet Fırkası kuruldu."),
    ("Şubat 1925", "Doğu'da Şeyh Said İsyanı çıktı."),
    ("Mart 1925", "Takrir-i Sükûn Kanunu çıkarıldı."),
    ("Haziran 1925", "Terakkiperver Cumhuriyet Fırkası hükûmet kararıyla kapatıldı."),
    ("Ağustos 1930", "Serbest Cumhuriyet Fırkası kuruldu."),
    ("Kasım 1930", "Serbest Cumhuriyet Fırkası kurucuları partiyi feshetti."),
    ("Aralık 1930", "Menemen Olayı yaşandı."),
    ("Temmuz 1945", "Millî Kalkınma Partisi kuruldu."),
    ("Ocak 1946", "Demokrat Parti kuruldu."),
    ("Temmuz 1946", "İlk çok partili genel seçim yapıldı."),
)

# (tarih, o tarihte faaliyette muhalefet partisi var mı)
_MUHALEFET_TARIHLERI = (
    ("Ocak 1925", True), ("Nisan 1925", True), ("Ekim 1930", True),
    ("Mayıs 1946", True), ("Temmuz 1947", True),
    ("Eylül 1925", False), ("Mart 1928", False), ("Mart 1931", False),
    ("Haziran 1936", False), ("Mart 1943", False),
)

# (kalıcı dönemin ilk partisi, kuruluş tarihi, Kasım 1924'ten ay farkı)
_KALICI_BASLANGIC = (
    ("Millî Kalkınma Partisi", "Temmuz 1945", (1945 - 1924) * 12 + (7 - 11)),
    ("Demokrat Parti", "Ocak 1946", (1946 - 1924) * 12 + (1 - 11)),
)
_DENEME_AYLARI = (7, 3)   # Kasım 1924 -> Haziran 1925; Ağustos -> Kasım 1930


@bulmaca(ders="inkilap", konu="ataturk_ic_siyaset_urunu", kademeler=(12, 13), agirlik=1.3)
def parti_arsivi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """1924 ve 1930 denemeleri kısa sürdü; parti kurulması kalıcı çok partili hayat demek değildir."""
    evet = [t for t in _MUHALEFET_TARIHLERI if t[1]]
    hayir = [t for t in _MUHALEFET_TARIHLERI if not t[1]]
    kac_evet = rastgele.choice((2, 3))
    tarihler = rastgele.sample(evet, kac_evet) + rastgele.sample(hayir, 5 - kac_evet)
    rastgele.shuffle(tarihler)
    secenekler = [t[0] for t in tarihler]
    dogrular = [n for n, t in enumerate(tarihler) if t[1]]
    parti, parti_tarih, toplam_ay = rastgele.choice(_KALICI_BASLANGIC)
    deneme_ay = sum(_DENEME_AYLARI)
    yuzde = round(100.0 * deneme_ay / toplam_ay)
    odak = rastgele.choice(("tcf", "scf"))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    if odak == "tcf":
        odak_soru = "Terakkiperver Cumhuriyet Fırkası neden kısa ömürlü oldu?"
        odak_dogru = "Şeyh Said İsyanı sonrası Takrir-i Sükûn döneminde kapatıldı"
        odak_yanlislar = {
            "Kapanmadı; 1946'ya kadar muhalefeti kesintisiz sürdürdü":
                "Parti kurulmasını kesintisiz çok partili hayatla eşitledin. Kartta "
                "Haziran 1925'te kapatıldığı yazıyor.",
            "Menemen Olayı üzerine kapatıldı; gerici ayaklanmayla suçlanan parti oydu":
                "Menemen Olayı Aralık 1930'dadır; parti o tarihten beş yıldan fazla önce kapanmıştı.",
            "Seçimi kazanıp iktidara geçtiği için muhalefetten çekildi":
                "Parti hiç seçim kazanmadı; kapatıldı.",
        }
    else:
        odak_soru = "Serbest Cumhuriyet Fırkası nasıl sona erdi?"
        odak_dogru = "Kuruluşundan yaklaşık üç ay sonra kurucuları partiyi feshetti"
        odak_yanlislar = {
            "Kapanmadı; 1946'ya kadar muhalefeti kesintisiz sürdürdü":
                "Parti kurulmasını kesintisiz çok partili hayatla eşitledin. Kartta "
                "Kasım 1930'da feshedildiği yazıyor.",
            "Şeyh Said İsyanı üzerine kapatıldı; isyan sonrası muhalefet susturulmuştu":
                "Şeyh Said İsyanı 1925'tedir; bu parti 1930'da kuruldu.",
            "Seçimleri kazanıp iktidara geldi; halktan çok büyük ilgi görmüştü":
                "Parti iktidara gelmedi; üç ay içinde feshedildi.",
        }

    return Bulmaca(
        kod="ink-parti-arsivi",
        ders="inkilap",
        baslik="Parti Arşivi",
        kademe=kademe,
        konu="ataturk_ic_siyaset_urunu",
        kazanim="Atatürk dönemi iç siyasetinde çok partili hayata geçiş denemelerini "
                "(1924, 1930) neden ve sonuçlarıyla karşılaştırma; bir partinin "
                "kurulmasını kalıcı çok partili hayattan ayırma; kaynaklı zaman "
                "çizelgesi hazırlama.",
        dikkat=7,
        brifing=(
            "Sefer arşivi için Cumhuriyet'in ilk yıllarındaki siyasi partiler üzerine "
            "bir sergi panosu hazırlanıyor.\n\n"
            "{} panoya şunu yazdı: \"Kasım 1924'te ilk muhalefet partisi kuruldu; "
            "demek ki Türkiye o günden beri kesintisiz çok partili. {} kuruluncaya "
            "kadar ({}) geçen {} ayın hepsinde faaliyette bir muhalefet partisi "
            "vardı.\"\n\n"
            "Pano asılmadan önce parti kartlarını kaynaklarla karşılaştırmamız gerekiyor."
        ).format(kisi, parti, parti_tarih, toplam_ay),
        kanitlar=[
            Kanit("Parti kartları",
                  "Terakkiperver Cumhuriyet Fırkası: Kasım 1924'te kuruldu, Haziran "
                  "1925'te hükûmet kararıyla kapatıldı.\n"
                  "Serbest Cumhuriyet Fırkası: Ağustos 1930'da kuruldu, Kasım 1930'da "
                  "kurucuları tarafından feshedildi.\n"
                  "Millî Kalkınma Partisi: Temmuz 1945'te kuruldu.\n"
                  "Demokrat Parti: Ocak 1946'da kuruldu; 1946 seçimine girdi, 1950'de "
                  "seçimle iktidara geldi.",
                  bedel=1, kritik=True),
            Kanit("Olay kayıtları",
                  "\n".join("{}: {}".format(t, o) for t, o in _IC_SIYASET_OLAYLARI),
                  bedel=1, kritik=True),
            Kanit("Tanım notu",
                  "Çok partili hayat: birden fazla partinin sürekli faaliyet gösterip "
                  "seçimlerde yarışabildiği düzen. Bir partinin kurulması tek başına "
                  "bunu göstermez; partinin ne kadar yaşadığına ve yerine yenisinin "
                  "gelip gelmediğine bakılır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir muhalefet partisinin kurulması neyi gösterir?",
                dogru="Çok partili hayat için bir girişimi; kalıcılığı partinin ömründen anlaşılır",
                yanlislar={
                    "O günden sonra çok partili hayatın kesintisiz sürdüğünü; kurulan muhalefet kalıcıdır":
                        "Parti kurulmasını kesintisiz çok partili hayatla eşitledin. "
                        "1924 ve 1930'da kurulan iki parti de bir yıl dolmadan kapandı.",
                    "Hükûmetin artık seçimle değişebileceğini; muhalefet varsa seçim de yarışmalıdır":
                        "Seçimle iktidar değişikliği ancak 1950'de oldu.",
                    "Tek parti döneminin hiç yaşanmadığını; ilk muhalefet 1924'te kurulmuştu":
                        "Haziran 1925 - Ağustos 1930 ve Kasım 1930 - Temmuz 1945 arasında "
                        "faaliyette muhalefet partisi yoktu.",
                },
                rastgele=rastgele,
                aciklama=(
                    "1924 ve 1930'daki partiler çok partili hayata geçiş denemeleriydi; "
                    "ikisi de kısa sürdü. Kalıcı geçiş, II. Dünya Savaşı'ndan sonra "
                    "1945-1946'da yeni partilerin kurulması ve 1946 seçimiyle oldu."
                ),
                ipuclari=[
                    "Parti kartlarında her partinin ne zaman kapandığına bak.",
                    "Tanım notunda çok partili hayat için ne aranıyor?",
                ],
                cozum=("Deneme 1: Kasım 1924 - Haziran 1925\nDeneme 2: Ağustos - Kasım 1930\n"
                       "Kalıcı geçiş: 1945-1946"),
            ),
            coklu_adimi(
                soru="Kartlara göre hangi tarihlerde faaliyette olan bir muhalefet partisi "
                     "vardı? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogrular,
                aciklama=("Muhalefet yalnız iki deneme sırasında (1924-1925 ve 1930) ve "
                          "1945'ten sonra vardı; aradaki yıllarda tek parti vardı."),
                ipuclari=["Her tarihi parti kartlarındaki kuruluş ve kapanış aralıklarıyla karşılaştır."],
                puan=14,
            ),
            sayi_adimi(
                soru=("Kasım 1924 ile {} arasında iki denemede muhalefet partisi "
                      "toplam yaklaşık kaç ay faaliyette kaldı?").format(parti_tarih),
                cevap=deneme_ay,
                birim="ay",
                aciklama=("Kasım 1924 - Haziran 1925: {} ay; Ağustos - Kasım 1930: {} ay; "
                          "toplam yaklaşık {} ay.").format(_DENEME_AYLARI[0], _DENEME_AYLARI[1],
                                                           deneme_ay),
                yaygin_yanlislar={
                    toplam_ay:
                        "Parti kurulmasını kesintisiz çok partili hayatla eşitledin: bütün "
                        "dönemi muhalefetli saydın.",
                },
                ipuclari=["Her partinin kuruluş ayından kapanış ayına kadar geçen ayları say, sonra topla."],
                puan=12,
                tolerans=1,
            ),
            sayi_adimi(
                soru=("Kasım 1924 ile {} arasındaki {} ayın yüzde kaçında faaliyette "
                      "bir muhalefet partisi vardı? (tam sayıya yuvarla)").format(parti_tarih, toplam_ay),
                cevap=yuzde,
                aciklama="{} ÷ {} × 100 ≈ {}.".format(deneme_ay, toplam_ay, yuzde),
                yaygin_yanlislar={
                    100:
                        "Parti kurulmasını kesintisiz çok partili hayatla eşitledin; "
                        "dönemin çoğunda tek parti vardı.",
                },
                ipuclari=["Muhalefetli ayları bütün döneme böl, 100 ile çarp."],
                puan=10,
                tolerans=1,
            ),
            secim_adimi(
                soru=odak_soru,
                dogru=odak_dogru,
                yanlislar=odak_yanlislar,
                rastgele=rastgele,
                aciklama=("Terakkiperver Cumhuriyet Fırkası 1925'te Takrir-i Sükûn döneminde "
                          "kapatıldı; Serbest Cumhuriyet Fırkası 1930'da kurucularınca "
                          "feshedildi. İki deneme de kalıcı olmadı."),
                ipuclari=["Olay kayıtlarında partinin kapanışından hemen önce ne oluyor?"],
                puan=12,
            ),
        ],
        kapanis=("Pano düzeltildi: 1924 ve 1930'daki iki deneme toplam yaklaşık {} ay "
                 "sürdü; {} kuruluncaya kadar geçen {} ayın yalnız yüzde {} kadarında "
                 "muhalefet partisi vardı. Kalıcı çok partili hayata 1945-1946'da "
                 "geçildi.").format(deneme_ay, parti, toplam_ay, yuzde),
        odul={"itibar": 5, "erzak": 1, "cevher": 1},
    )


# ==========================================================================
# SAVAŞ YILLARI KARARLARI: SONUCU BİLMEK, KARARI KOLAYLAŞTIRMAZ (B37.14)
#
# `ikinci_dunya_turkiye_alternatif` tek satırlıktı (2026: 12). Bağlam: "Savaş
# dönemi kaynak ve diplomasi kayıtlarından koşulları gözeten alternatif karar
# gerekçesi hazırlama". `yaygin_yanlis`:
#
#   "Sonucu bildiğimiz için kararın geçmişte de açık ve kolay olduğunu sanmak."
#
# DÜZENEK: arşivde bir karar dosyası (1941 saldırmazlık antlaşması, 1943 Adana,
# 1943 Kahire, 1945 savaş ilanı). Tarihli kartların bir kısmı karardan önce
# (karar verenler biliyordu), bir kısmı sonra (bilmiyorlardı). Alternatif
# gerekçe o günün koşullarıyla kurulur.
#
# YANILGININ SAYISAL KARŞILIĞI: karar anında bilinmeyen kart sayısını 0
# saymak; sonradan olan olayı gerekçe yapmak.
# ==========================================================================

_SAVAS_KARARLARI = (
    {
        "tarih": "18 Haziran 1941", "yil": 1941, "ay": 6,
        "karar": "Almanya ile Dostluk ve Saldırmazlık Antlaşması imzalamak",
        "kosul": ("Alman ordusu Bulgaristan'a girmiş, Yunanistan'ı işgal etmişti; Trakya "
                  "sınırı tehdit altındaydı. Türk ordusunun modern uçak, tank ve uçaksavar "
                  "silahı azdı. 1939'daki ittifakın ortaklarından Fransa yenilmişti."),
        "bilinen": (
            ("Ekim 1939", "Türkiye, İngiltere ve Fransa ile karşılıklı yardım antlaşması imzaladı."),
            ("Haziran 1940", "Fransa, Almanya karşısında yenildi."),
            ("Mart 1941", "Alman ordusu Bulgaristan'a girdi; Türkiye sınırına dayandı."),
            ("Nisan 1941", "Almanya Yunanistan'ı işgal etti."),
        ),
        "sonradan": (
            ("22 Haziran 1941", "Almanya Sovyetler Birliği'ne saldırdı."),
            ("Aralık 1941", "ABD savaşa girdi."),
            ("Şubat 1943", "Stalingrad'daki Alman ordusu teslim oldu."),
            ("Mayıs 1945", "Almanya teslim oldu."),
        ),
        "alternatif": ("Almanya'ya karşı açık tavır almak düşünülebilirdi; ama sınırdaki "
                       "Alman ordusu Trakya'yı tehdit ediyordu"),
        "sonradan_gerekce": ("Almanya'nın dört gün sonra Sovyetler Birliği'ne saldıracağı "
                             "belli olduğu için antlaşma hiçbir risk taşımıyordu"),
    },
    {
        "tarih": "Ocak 1943", "yil": 1943, "ay": 1,
        "karar": ("Adana Görüşmesi'nde Churchill'in savaşa girme çağrısına karşı tarafsız "
                  "kalıp önce silah yardımı istemek"),
        "kosul": ("Alman ordusu hâlâ Bulgaristan ve Yunanistan'daydı. Türk ordusu modern "
                  "silah bakımından zayıftı; savaşa girilirse İstanbul ve Trakya hava "
                  "saldırısına açık kalacaktı."),
        "bilinen": (
            ("Haziran 1941", "Türkiye ile Almanya saldırmazlık antlaşması imzaladı."),
            ("Haziran 1941", "Almanya Sovyetler Birliği'ne saldırdı."),
            ("Aralık 1941", "ABD savaşa girdi."),
            ("Kasım 1942", "El Alamein'de Mihver ordusu yenildi."),
        ),
        "sonradan": (
            ("Temmuz 1943", "Kursk'ta Alman taarruzu durduruldu."),
            ("Eylül 1943", "İtalya teslim oldu."),
            ("Haziran 1944", "Müttefikler Normandiya'ya çıktı."),
            ("Mayıs 1945", "Almanya teslim oldu."),
        ),
        "alternatif": ("Savaşa girmek düşünülebilirdi; ama ordu silahça zayıftı, İstanbul "
                       "hava saldırısına açıktı"),
        "sonradan_gerekce": ("İtalya'nın birkaç ay sonra teslim olacağı belli olduğu için "
                             "savaşa girmek hiçbir risk taşımıyordu"),
    },
    {
        "tarih": "Aralık 1943", "yil": 1943, "ay": 12,
        "karar": ("Kahire Konferansı'nda savaşa girmeyi ordunun donatılması şartına bağlayıp "
                  "tarafsızlığı sürdürmek"),
        "kosul": ("Almanya Onikiada'da İngiliz birliklerini yenmiş, Türkiye kıyılarının "
                  "dibinde güçlüydü. Türkiye, Adana'da istediği silah yardımının yeterince "
                  "gelmediğini öne sürüyordu; Bulgaristan'daki Alman kuvvetleri yerindeydi."),
        "bilinen": (
            ("Şubat 1943", "Stalingrad'daki Alman ordusu teslim oldu."),
            ("Temmuz 1943", "Kursk'ta Alman taarruzu durduruldu."),
            ("Eylül 1943", "İtalya teslim oldu."),
            ("Kasım 1943", "Almanya Onikiada'da İngiliz birliklerini yendi."),
        ),
        "sonradan": (
            ("Haziran 1944", "Müttefikler Normandiya'ya çıktı."),
            ("Ağustos 1944", "Türkiye Almanya ile diplomatik ilişkilerini kesti."),
            ("Şubat 1945", "Yalta Konferansı toplandı."),
            ("Mayıs 1945", "Almanya teslim oldu."),
        ),
        "alternatif": ("Hemen savaşa girmek düşünülebilirdi; ama Almanya Onikiada'da "
                       "güçlüydü, silah yardımı yetersizdi"),
        "sonradan_gerekce": ("Normandiya çıkarmasının başarılı olacağı belli olduğu için "
                             "savaşa girmek hiçbir risk taşımıyordu"),
    },
    {
        "tarih": "23 Şubat 1945", "yil": 1945, "ay": 2,
        "karar": "Almanya ve Japonya'ya savaş ilan etmek",
        "kosul": ("Yalta'da, 1 Mart 1945'e kadar Mihver'e savaş ilan eden devletlerin "
                  "Birleşmiş Milletler kuruluş konferansına çağrılması kararlaştırılmıştı. "
                  "Savaşın ne zaman biteceği ise bilinmiyordu."),
        "bilinen": (
            ("Haziran 1944", "Müttefikler Normandiya'ya çıktı."),
            ("Ağustos 1944", "Türkiye Almanya ile diplomatik ilişkilerini kesti."),
            ("Ocak 1945", "Sovyet ordusu Varşova'ya girdi."),
            ("11 Şubat 1945", "Yalta Konferansı sona erdi."),
        ),
        "sonradan": (
            ("Mart 1945", "Sovyetler Birliği, Türkiye ile 1925 antlaşmasını yenilemeyeceğini bildirdi."),
            ("Mayıs 1945", "Almanya teslim oldu."),
            ("Haziran 1945", "Birleşmiş Milletler Antlaşması imzalandı."),
            ("Ağustos 1945", "Hiroşima'ya atom bombası atıldı."),
        ),
        "alternatif": ("Tarafsız kalmak düşünülebilirdi; ama o zaman Türkiye BM kuruluş "
                       "konferansına çağrılmayacaktı"),
        "sonradan_gerekce": ("Almanya'nın üç ay sonra teslim olacağı belli olduğu için "
                             "savaş ilanı hiçbir risk taşımıyordu"),
    },
)


@bulmaca(ders="inkilap", konu="ikinci_dunya_turkiye_alternatif", kademeler=(12, 13), agirlik=1.3)
def karar_dosyasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Savaş yıllarındaki bir kararı o günün bilgisi ve koşullarıyla değerlendirme."""
    d = rastgele.choice(_SAVAS_KARARLARI)
    kac_bilinen = rastgele.choice((2, 3))
    kartlar = ([(t, o, True) for t, o in rastgele.sample(d["bilinen"], kac_bilinen)]
               + [(t, o, False) for t, o in rastgele.sample(d["sonradan"], 5 - kac_bilinen)])
    rastgele.shuffle(kartlar)
    secenekler = ["{}: {}".format(t, o) for t, o, _ in kartlar]
    bilinenler = [n for n, k in enumerate(kartlar) if k[2]]
    bilinmeyen = len(kartlar) - len(bilinenler)
    kalan_ay = (1945 - d["yil"]) * 12 + (5 - d["ay"])
    yil_farki = (1945 - d["yil"]) * 12
    ay_yanlis = {yil_farki: "Yalnız yılları çıkardın; ayları da hesaba kat."} \
        if yil_farki not in (0, kalan_ay) else {}
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ink-karar-dosyasi",
        ders="inkilap",
        baslik="Karar Dosyası",
        kademe=kademe,
        konu="ikinci_dunya_turkiye_alternatif",
        kazanim="II. Dünya Savaşı yıllarında Türkiye'nin iç ve dış sorunlarına yönelik "
                "bir kararı, karar anında bilinenler ve dönemin koşullarıyla "
                "değerlendirme; sonradan olanları ayırma; koşulları gözeten alternatif "
                "bir karar gerekçesi kurma.",
        dikkat=7,
        brifing=(
            "Sefer arşivinde II. Dünya Savaşı yıllarına ait bir karar dosyası "
            "açıldı.\n\n"
            "  Karar ({}): {}\n\n"
            "{} dosyaya şunu yazdı: \"Bu karar çok kolaydı; sonunda Almanya'nın "
            "savaşı kaybedeceği belliydi. Karar verenlerin önünde düşünecek başka bir "
            "seçenek yoktu.\"\n\n"
            "Dosya kapanmadan önce kararı o günün bilgileriyle değerlendirip "
            "alternatif bir gerekçe hazırlamamız gerekiyor."
        ).format(d["tarih"], d["karar"], kisi),
        kanitlar=[
            Kanit("Durum notu", d["kosul"], bedel=1, kritik=True),
            Kanit("Tarihli kartlar", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Yöntem notu",
                  "Bir karar değerlendirilirken yalnız karar tarihine kadar olan "
                  "bilgiler kullanılır. Sonradan olanları karar verenler bilmiyordu; "
                  "alternatif, o günün olanakları ve riskleriyle kurulur.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Geçmişteki bir kararı değerlendirmenin doğru yolu hangisidir?",
                dogru="Karar anında bilinenlerle ve dönemin koşullarıyla değerlendirmek",
                yanlislar={
                    "Sonucu bildiğimize göre kararın o gün de açık ve kolay olduğunu kabul etmek":
                        "Sonucu bildiğimiz için kararın geçmişte de açık ve kolay olduğunu "
                        "sandın. Karar verenler savaşın nasıl biteceğini bilmiyordu.",
                    "Kararı yalnız sonucuna bakarak iyi ya da kötü saymak; sonuç her şeyi gösterir":
                        "Sonuç, karar verenlerin bilmediği sonraki olaylara da bağlıdır.",
                    "Dönemin koşullarını bugünün olanaklarıyla karşılaştırmak":
                        "Alternatif, bugünün değil o günün olanaklarıyla kurulur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarihçi kararı, karar verenin yerinden bakarak inceler: o gün hangi "
                    "bilgiler vardı, hangi tehlikeler görünüyordu, hangi seçenekler "
                    "masadaydı? Sonradan olanlar kararı açıklamak için kullanılamaz."
                ),
                ipuclari=[
                    "Yöntem notunda hangi bilgilerin kullanılacağı yazıyor?",
                    "Karar verenler savaşın sonunu biliyor muydu?",
                ],
                cozum="Karar tarihinden önceki kartlar: bilinen\nSonraki kartlar: bilinmeyen",
            ),
            coklu_adimi(
                soru="{} tarihinde karar verenler hangi gelişmeleri biliyordu? "
                     "(numaraları virgülle yaz)".format(d["tarih"]),
                secenekler=secenekler,
                dogru_indeksler=bilinenler,
                aciklama="Karar tarihinden önce olan gelişmeler biliniyordu; sonrakiler bilinmiyordu.",
                ipuclari=["Her kartın tarihini karar tarihiyle karşılaştır."],
                puan=14,
            ),
            sayi_adimi(
                soru="Kartlardan kaç tanesi karar anında bilinmiyordu?",
                cevap=bilinmeyen,
                aciklama="{} kart karar tarihinden sonraya ait.".format(bilinmeyen),
                yaygin_yanlislar={
                    0:
                        "Sonucu bildiğimiz için kararın geçmişte de açık ve kolay olduğunu "
                        "sandın: sonradan olanları da karar anının bilgisi saydın.",
                },
                ipuclari=["Karar tarihinden sonraki kartları say."],
                puan=10,
            ),
            sayi_adimi(
                soru="Karar ayından Almanya'nın teslim olduğu Mayıs 1945'e kaç ay vardı?",
                cevap=kalan_ay,
                birim="ay",
                aciklama="Karar verildiğinde savaşın Avrupa'da daha {} ay süreceği "
                         "bilinmiyordu.".format(kalan_ay),
                yaygin_yanlislar=ay_yanlis,
                ipuclari=["Yıl farkını 12 ile çarp, ay farkını ekle ya da çıkar."],
                puan=8,
            ),
            yorum_adimi(
                soru="Hangisi dönemin koşullarını gözeten bir alternatif karar gerekçesidir?",
                dogru=d["alternatif"],
                yanlislar={
                    d["sonradan_gerekce"]:
                        "Sonucu bildiğimiz için kararın geçmişte de açık ve kolay olduğunu "
                        "sandın; bu olay karar verildiğinde henüz olmamıştı.",
                    "Karar kolaydı; o günlerde düşünülecek başka bir seçenek yoktu":
                        "Sonucu bildiğimiz için kararın geçmişte de açık ve kolay olduğunu "
                        "sandın. Durum notu seçeneklerin ve risklerin olduğunu gösteriyor.",
                    "Koşullar önemsizdir; savaşın sonucunu büyük devletler belirliyordu, hangi yol seçilse aynı olurdu":
                        "Her seçeneğin o günün koşullarında farklı riskleri vardı.",
                },
                rastgele=rastgele,
                aciklama="Alternatif gerekçe, karar anındaki bilgileri ve durum notundaki riskleri kullanır.",
                ipuclari=["Gerekçede karar tarihinden sonraki bir olay kullanılıyor mu?"],
                puan=12,
            ),
        ],
        kapanis=("Dosya düzeltildi: kartların {} tanesi karardan sonraya aitti ve karar "
                 "verenler savaşın daha {} ay süreceğini bilmiyordu. Alternatif gerekçe "
                 "o günün koşullarıyla yazıldı.").format(bilinmeyen, kalan_ay),
        odul={"itibar": 5, "erzak": 1, "cevher": 1},
    )


# ==========================================================================
# SAVAŞ SONRASI BİLİM VE KÜLTÜR: AYNI DÖNEM, NEDEN BAĞI DEĞİLDİR (B37.14)
#
# `ataturk_sonrasi_kultur_urunu` tek satırlıktı (2026: 12). Bağlam: "Sefer
# arşivinden bilim, eğitim, kültür ve spor gelişmelerine ilişkin kaynaklı bir
# zaman çizelgesi ve sergi hazırlama". `yaygin_yanlis`:
#
#   "Aynı dönemde olan iki gelişme arasında otomatik neden bağı kurmak."
#
# DÜZENEK: sergi panosunda kartlar ve kartlar arasına çizilmiş oklar. Aynı ya
# da ardışık yıllardaki çiftlere çizilen okların hiçbiri kaynakla desteklenmiyor;
# yıllar arayla olan bazı oklar ise kart notlarıyla destekleniyor (Atom Enerjisi
# Komisyonu -> Çekmece reaktörü; Konservatuvar -> Devlet Tiyatrosu).
#
# YANILGININ SAYISAL KARŞILIĞI: silinmesi gereken ok sayısını 0 saymak.
# ==========================================================================

# (yıl, olay, kaynak notu)
_SERGI_KARTLARI = (
    (1940, "Köy Enstitüleri Kanunu çıkarıldı.",
     "Amaç: köy okullarına öğretmen yetiştirmek. Enstitü mezunları köy okullarına "
     "öğretmen olarak atandı."),
    (1940, "Tercüme Bürosu kuruldu.",
     "Amaç: dünya klasiklerini Türkçeye kazandırmak."),
    (1948, "Londra Olimpiyatları'nda Türk güreşçileri 6 altın madalya kazandı.",
     "Kaynak: olimpiyat sonuç listesi."),
    (1949, "Devlet Tiyatrosu kanunla kuruldu.",
     "Kadrosu, 1936'da açılan Ankara Devlet Konservatuvarı'nın tiyatro bölümünden "
     "yetişti."),
    (1952, "İTÜ'de ilk deneme televizyon yayını yapıldı.",
     "Üniversitenin elektrik mühendisliği laboratuvarında hazırlandı."),
    (1954, "Millî futbol takımı ilk kez Dünya Kupası'nda oynadı.",
     "Kaynak: turnuva kayıtları."),
    (1956, "Orta Doğu Teknik Üniversitesi kuruldu.",
     "Birleşmiş Milletler desteğiyle mühendis, mimar ve planlamacı yetiştirmek için "
     "kuruldu."),
    (1956, "Atom Enerjisi Komisyonu kuruldu.",
     "Amaç: nükleer enerjinin barışçı kullanımına yönelik araştırmaları yürütmek."),
    (1962, "Çekmece'de ilk araştırma reaktörü çalıştırıldı.",
     "Atom Enerjisi Komisyonu'na bağlı Çekmece Nükleer Araştırma Merkezi'nde kuruldu."),
    (1963, "TÜBİTAK kuruldu.",
     "Amaç: temel ve uygulamalı bilimsel araştırmaları desteklemek."),
)

# Kart notlarıyla desteklenen oklar
_DESTEKLI_OKLAR = (
    "Atom Enerjisi Komisyonu (1956) → Çekmece araştırma reaktörü (1962)",
    "Ankara Devlet Konservatuvarı (1936) → Devlet Tiyatrosu (1949)",
    "Köy Enstitüleri Kanunu (1940) → köy okullarına enstitü mezunu öğretmen atanması",
)
# Aynı ya da ardışık yıllar için çizilmiş, kaynakla desteklenmeyen oklar
# (ok, ortak bağlam açıklaması)
_DAYANAKSIZ_OKLAR = (
    ("Köy Enstitüleri Kanunu (1940) → Tercüme Bürosu (1940)",
     "İkisi de aynı Millî Eğitim Bakanlığı döneminin eğitim ve kültür politikasının "
     "parçasıydı; bu ortak bağlamdır, neden bağı değildir."),
    ("Atom Enerjisi Komisyonu (1956) → ODTÜ (1956)",
     "İkisi de savaş sonrası bilim ve teknik atılımının parçasıydı ama kart notları "
     "farklı amaçlar gösteriyor."),
    ("Olimpiyatta güreş başarısı (1948) → Devlet Tiyatrosu (1949)",
     "Devlet Tiyatrosu'nun kadrosu 1936'da açılan Konservatuvar'dan yetişti; "
     "olimpiyatla bağ kuran bir kaynak yok."),
    ("Çekmece araştırma reaktörü (1962) → TÜBİTAK (1963)",
     "Reaktör Atom Enerjisi Komisyonu'nun işiydi; TÜBİTAK araştırmaları desteklemek "
     "için kuruldu. Ardışık yıllarda olmaları neden bağı göstermez."),
)


@bulmaca(ders="inkilap", konu="ataturk_sonrasi_kultur_urunu", kademeler=(12, 13), agirlik=1.3)
def sergi_panosu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı dönemde olmak neden bağı değildir; ok ancak kaynakla desteklenirse çizilir."""
    iddia, iddia_baglam = rastgele.choice(_DAYANAKSIZ_OKLAR)
    diger_dayanaksiz = [o for o, _ in _DAYANAKSIZ_OKLAR if o != iddia]
    kac_destekli = rastgele.choice((1, 2))
    oklar = ([(o, True) for o in rastgele.sample(_DESTEKLI_OKLAR, kac_destekli)]
             + [(iddia, False)]
             + [(o, False) for o in rastgele.sample(diger_dayanaksiz, 4 - kac_destekli)])
    rastgele.shuffle(oklar)
    ok_metinleri = [o for o, _ in oklar]
    destekli = [n for n, (_, d) in enumerate(oklar) if d]
    silinecek = len(oklar) - len(destekli)

    yillar = sorted({y for y, _, _ in _SERGI_KARTLARI})
    secilen_yillar = rastgele.sample(yillar, 5)
    cizelge = [rastgele.choice([k for k in _SERGI_KARTLARI if k[0] == y]) for y in secilen_yillar]
    cizelge_metin = [k[1] for k in cizelge]
    dogru_sira = [cizelge.index(k) for k in sorted(cizelge, key=lambda k: k[0])]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="ink-sergi-panosu",
        ders="inkilap",
        baslik="Sergi Panosu",
        kademe=kademe,
        konu="ataturk_sonrasi_kultur_urunu",
        kazanim="II. Dünya Savaşı sonrası Türkiye'de bilim, teknoloji, kültür, eğitim ve "
                "spor gelişmelerinden kaynaklı bir zaman çizelgesi hazırlama; aynı "
                "dönemde olan gelişmeler arasında kanıtsız neden bağı kurmama; ortak "
                "bağlam ile neden bağını ayırt etme.",
        dikkat=7,
        brifing=(
            "Sefer arşivinden savaş sonrası bilim, eğitim, kültür ve spor gelişmeleri "
            "üzerine bir sergi hazırlanıyor.\n\n"
            "{} panoya kartları dizip aralarına oklar çizdi ve şunu yazdı: \"{} ok "
            "çizdim. Örneğin '{}': aynı dönemde oldukları için biri ötekine yol açmış "
            "olmalı.\"\n\n"
            "Sergi açılmadan önce her okun kaynakla desteklenip desteklenmediğini "
            "kontrol etmemiz gerekiyor."
        ).format(kisi, len(oklar), iddia),
        kanitlar=[
            Kanit("Sergi kartları",
                  "\n".join("{}: {} ({})".format(y, o, n) for y, o, n in _SERGI_KARTLARI),
                  bedel=1, kritik=True),
            Kanit("Panodaki oklar", "\n".join(ok_metinleri), bedel=1, kritik=True),
            Kanit("Küratör notu",
                  "Bir ok, nedenin önce geldiğini ve kaynakta birinin ötekine yol "
                  "açtığını gösteren bir kanıt bulunduğunu anlatır. Aynı dönemde olmak "
                  "ya da aynı politikanın parçası olmak ok çizmek için yetmez.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Sergide iki gelişme arasına neden oku çizmek için ne gerekir?",
                dogru="Nedenin önce gelmesi ve kaynakta yol açtığını gösteren kanıt; aynı dönem yetmez",
                yanlislar={
                    "Aynı yıl ya da ardışık yıllarda olmaları yeterlidir; yakın olaylar birbirini etkiler":
                        "Aynı dönemde olan iki gelişme arasında otomatik neden bağı "
                        "kurdun. Aynı yıl olmak ancak ortak bir bağlamı gösterebilir.",
                    "Birinin ötekinden sonra olması yeterlidir":
                        "Sonra olmak tek başına sonuç olmak demek değildir; kanıt gerekir.",
                    "İkisinin de devlet eliyle yapılması yeterlidir; aynı politika hepsini bağlar":
                        "Aynı aktörün yaptığı iki iş birbirinin nedeni olmak zorunda değildir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Neden bağı iki şart ister: zaman sırası ve bağı gösteren kanıt. "
                    "Aynı dönemde olan gelişmeler çoğu zaman ortak bir bağlamı (aynı "
                    "politika, aynı dönem koşulları) paylaşır; bu, birinin ötekine yol "
                    "açtığı anlamına gelmez."
                ),
                ipuclari=[
                    "Küratör notunda ok için ne isteniyor?",
                    "Kart notlarında bu iki gelişmeyi bağlayan bir ifade var mı?",
                ],
                cozum="Ok = zaman sırası + kaynakta yol açma kanıtı\nAynı dönem = en fazla ortak bağlam",
            ),
            sirala_adimi(
                soru="Zaman çizelgesi için kartları eskiden yeniye sırala.",
                secenekler=cizelge_metin,
                dogru_sira=dogru_sira,
                aciklama="Sıra: {}.".format(", ".join(
                    "{} ({})".format(k[1].rstrip("."), k[0]) for k in sorted(cizelge, key=lambda k: k[0]))),
                ipuclari=["Sergi kartlarındaki yıllara bak."],
                puan=12,
            ),
            secim_adimi(
                soru="Kaynaklara göre '{}' oku için hangisi doğrudur?".format(iddia),
                dogru="Aynı dönemdeler ama kaynakta yol açma kanıtı yok; ok silinmeli",
                yanlislar={
                    "Aynı dönemde oldukları için biri ötekinin nedenidir; ok kalmalı":
                        "Aynı dönemde olan iki gelişme arasında otomatik neden bağı kurdun.",
                    "Ok ters çizilmiş; asıl neden sonraki gelişmedir, ok çevrilmeli":
                        "Yönü çevirmek kanıt eksikliğini gidermez.",
                    "İkisi de devlet eliyle yapıldığı için aralarında neden bağı vardır":
                        "Ortak aktör ya da ortak politika, neden bağı değildir.",
                },
                rastgele=rastgele,
                aciklama=iddia_baglam,
                ipuclari=["İki kartın notunu yan yana oku: biri ötekinden söz ediyor mu?"],
                puan=12,
            ),
            coklu_adimi(
                soru="Panodaki oklardan hangileri kart notlarıyla desteklenir? "
                     "(numaraları virgülle yaz)",
                secenekler=ok_metinleri,
                dogru_indeksler=destekli,
                aciklama=("Desteklenen oklarda kart notu bağı açıkça yazıyor: reaktör "
                          "komisyonun merkezinde kuruldu; tiyatro kadrosu konservatuvardan "
                          "yetişti; enstitü mezunları köy okullarına atandı."),
                ipuclari=["Her okun iki ucundaki kartların notlarında birbirlerinden söz ediliyor mu?"],
                puan=14,
            ),
            sayi_adimi(
                soru="Panodan kaç ok silinmeli?",
                cevap=silinecek,
                aciklama="{} ok kaynakla desteklenmiyor; yalnız aynı dönemde oldukları için çizilmiş.".format(silinecek),
                yaygin_yanlislar={
                    0:
                        "Aynı dönemde olan iki gelişme arasında otomatik neden bağı "
                        "kurdun; okların çoğunun kanıtı yok.",
                },
                ipuclari=["Desteklenmeyen okları say."],
                puan=8,
            ),
        ],
        kapanis=("Pano düzeltildi: {} ok silindi, {} ok kaynakla desteklendiği için "
                 "kaldı. Zaman çizelgesi yıllara göre dizildi.").format(silinecek, len(destekli)),
        odul={"itibar": 5, "erzak": 1, "cevher": 1},
    )
