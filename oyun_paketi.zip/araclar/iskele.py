# -*- coding: utf-8 -*-
"""
Yeni görev iskelesi.

    python main.py --yeni-icerik bilisim veri_boyutu

Komut, oyun/icerik altına ÇALIŞIR durumda bir taslak görev yazar. Öğrenci ya da
öğretmen dosyayı açıp metinleri değiştirir; oyun taslağı hemen tanır, ilk
katkıya kadar geçen süre saatlerden dakikalara iner.

Taslak bilerek eksiksiz yazılır: içinde modelleme adımı, yanlış teşhisleri,
kanıtlar ve kapanış vardır. Boş bir dosya vermek "nereden başlayacağımı
bilmiyorum" sorununu çözmez; doldurulacak bir örnek verir.
"""
from __future__ import annotations

import os
import re
from typing import Optional, Tuple

from oyun.motor import terminal as ekran
from oyun.motor.modeller import ALAN_TANIMLARI, DERS_ADLARI

ICERIK_KLASORU = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "oyun", "icerik")

_GECERLI_AD = re.compile(r"^[a-z0-9_]+$")

TASLAK = '''# -*- coding: utf-8 -*-
"""
{ders_adi} - {konu_baslik} görevleri (TASLAK).

Bu dosya `--yeni-icerik` ile üretildi. Aşağıdaki üretici çalışır durumdadır;
metinleri kendi konunla değiştir, sayıları kendi bağıntına göre kur.

Yazarken üç kurala uy:
  1) Brifing "x'i bul" demez. Bir aksaklık anlatır; neyin bilinmediğini
     öğrenci kendisi fark eder.
  2) İlk adım MODELLEME adımıdır: olayı hangi bağıntı anlatıyor? Doğru sayıyı
     yanlış modelle bulmanın yolu olmamalı.
  3) Her yanlış şık, gerçekten yapılan bir hatadır ve teşhisi yanına yazılır.
     "Yanlış" demek öğretmez; "şunu karıştırdın" demek öğretir.

Bittiğinde şunu çalıştır - hatalıysa oyuna hiç girmeden yakalanır:

    python main.py --denetle {ders}

Denemek için:

    python main.py --demo {ders}
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, model_adimi, sayi_adimi, sy, yorum_adimi,
)


@bulmaca(ders="{ders}", konu="{konu}", kademeler=({alt}, {ust}))
def {fonksiyon}(rastgele: random.Random, kademe: int) -> Bulmaca:
    """TODO: bu görevin öğrettiği şeyi tek cümleyle yaz."""
    # Sayılar her oynayışta değişmeli; ezber işe yaramasın.
    birinci = rastgele.randrange(6, 20)
    ikinci = rastgele.randrange(2, 8)
    sonuc = birinci * ikinci
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="{ders}-{konu_kod}",
        ders="{ders}",
        baslik="TODO: kısa ve merak uyandıran bir başlık",
        kademe=kademe,
        konu="{konu}",
        kazanim="TODO: müfredat karşılığı - yalnızca öğretmen raporunda görünür.",
        dikkat=5,
        brifing=(
            "TODO: Olayı anlat. {{}} adet ve {{}} katsayısı gibi sayıları "
            "metnin içine yedir; öğrenci hangi büyüklüğün bilinmediğini "
            "kendisi fark etsin.\\n\\n"
            "{{}} bu işi bugün teslim etmek zorunda."
        ).format(birinci, ikinci, kisi),
        kanitlar=[
            Kanit("TODO: kaynağın adı",
                  "TODO: burada ne yazıyor. Kritik kanıtlar olmadan görev "
                  "çözülemez.", bedel=1, kritik=True),
            Kanit("TODO: ikinci kaynak",
                  "TODO: çözüme katkısı olan ama şart olmayan bilgi.", bedel=1),
            Kanit("TODO: çeldirici kaynak",
                  "TODO: doğru ama işe yaramayan bir bilgi. Her kanıt işe "
                  "yaramamalı; ayıklamak da öğrenmenin parçası.", bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="TODO: olayı hangi bağıntı anlatıyor?",
                dogru="TODO: doğru bağıntının sözle anlatımı.",
                yanlislar={{
                    "TODO: sık yapılan yanlış kurulum.":
                        "TODO: bu şıkkı seçen öğrenci neyi karıştırmıştır? "
                        "Doğru cevabı söyleme; hatanın adını koy.",
                    "TODO: ikinci yanlış kurulum.":
                        "TODO: bunun teşhisi.",
                    "TODO: üçüncü yanlış kurulum.":
                        "TODO: bunun teşhisi.",
                }},
                rastgele=rastgele,
                aciklama="TODO: cevaptan sonra gösterilen 'neden böyle' metni.",
                ipuclari=[
                    "TODO: yönlendiren ama söylemeyen ilk ipucu.",
                    "TODO: biraz daha açık ikinci ipucu.",
                ],
            ),
            sayi_adimi(
                soru="TODO: sayısal soru.",
                cevap=sonuc,
                birim="TODO",
                aciklama="{{}} × {{}} = {{}}".format(birinci, ikinci, sonuc),
                yaygin_yanlislar={{
                    birinci + ikinci:
                        "Çarpmak yerine topladın. TODO: neden çarpma gerekiyor?",
                }},
                puan=12,
            ),
            yorum_adimi(
                soru="TODO: bu sonuç üsse ne söyler?",
                dogru="TODO: doğru yorum.",
                yanlislar={{
                    "TODO: yanlış yorum.": "TODO: teşhisi.",
                    "TODO: ikinci yanlış yorum.": "TODO: teşhisi.",
                }},
                rastgele=rastgele,
                aciklama="TODO: yorumun gerekçesi.",
            ),
        ],
        kapanis="TODO: olayın sonu - tek cümle.",
        odul={{"itibar": 2}},
    )
'''


def _dogrula(ders: str, konu: str) -> Optional[str]:
    """Sorun varsa açıklama metni, yoksa None döner."""
    if ders not in ALAN_TANIMLARI:
        return (
            "\"{}\" diye bir alan yok.\n\n"
            "Geçerli alanlar: {}\n\n"
            "Yeni bir alan (örneğin yeni bir meslek dersi) eklemek için önce "
            "oyun/motor/modeller.py içindeki ALAN_TANIMLARI tablosuna bir "
            "satır ekle; ayrıntısı ICERIK_EKLEME.md dosyasında.".format(
                ders, ", ".join(sorted(ALAN_TANIMLARI))))
    if not _GECERLI_AD.match(konu or ""):
        return ("Konu kodu yalnızca küçük harf, rakam ve alt çizgi "
                "içerebilir: \"veri_boyutu\" gibi. Verilen: \"{}\"".format(konu))
    return None


def iskele_yaz(ders: str, konu: str, kademeler: Tuple[int, int] = (5, 9)) -> int:
    sorun = _dogrula(ders, konu)
    if sorun:
        ekran.hata(sorun)
        return 1

    dosya_adi = "{}_{}_taslak.py".format(ders, konu)
    yol = os.path.join(ICERIK_KLASORU, dosya_adi)
    if os.path.exists(yol):
        ekran.hata("Bu taslak zaten var: {}\nÜstüne yazmıyorum; dosyayı açıp "
                   "düzenleyebilir ya da silip yeniden üretebilirsin.".format(yol))
        return 1

    icerik = TASLAK.format(
        ders=ders,
        ders_adi=DERS_ADLARI.get(ders, ders),
        konu=konu,
        konu_baslik=konu.replace("_", " "),
        konu_kod=konu.replace("_", "-"),
        fonksiyon="{}_taslak".format(konu),
        alt=int(kademeler[0]),
        ust=int(kademeler[1]),
    )
    with open(yol, "w", encoding="utf-8") as dosya:
        dosya.write(icerik)

    ekran.basari("Taslak hazır")
    ekran.yaz(yol, "gri", sar=False, girinti="    ")
    ekran.yaz()
    ekran.yaz("Sırada ne var:", "kalin")
    ekran.madde("Dosyayı aç, TODO yazan yerleri kendi konunla doldur.")
    ekran.madde("Denemek için:  python main.py --demo {}".format(ders))
    ekran.madde("Denetlemek için:  python main.py --denetle {}".format(ders))
    ekran.madde("Bittiğinde dosya adındaki \"_taslak\" ekini kaldırabilirsin; "
                "oyun her iki adda da tanır.")
    return 0
