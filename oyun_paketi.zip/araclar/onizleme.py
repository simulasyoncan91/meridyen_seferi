# -*- coding: utf-8 -*-
"""
Öğretmen için soru önizleme (B42.2): öğretmen masasında "Görevleri dene".

Kullanıcı 11 Eylül 2026: "Öğretmen de soruları yapacak mı? Onda üs yönetimi
çok gereken bir şey değil... ama denetim ve örnek soru için kullanabilirler."

Ders, sınıf ve konu seçilir; görev öğrenci gibi oynanabilir ya da cevap
anahtarı açılır. ÜS, KAYNAK, RÜTBE VE KAYIT YOKTUR: `Oturum` bir Durum'a
bağlı değildir, önizleme diske hiçbir şey yazmaz (bir test bunu kilitler).
Cevap anahtarı her adımın doğru cevabını, açıklamasını, çözümünü,
ipuçlarını ve görev yazarının beklediği yanlışların teşhislerini gösterir --
öğretmen soruyu hem tahtaya örnek olarak alabilir hem de içeriği denetler.

"Bu soruda sorun var" (B42.3): öğretmen önizlemede bir kategori ve kısa not
bırakır; `kayitlar/icerik_notlari.jsonl` dosyasına bir satır eklenir.
Öğrenci verisi değildir (görevin metni, öğretmenin notu). Önizlemenin diske
yazdığı TEK şey budur ve yalnız öğretmen isteyince. Bekleyen içerik onayları
(tarih, din kültürü, alaşım aralıkları) bu yoldan toplanabilir.

Branş (B42.1): masadaki "Branşım" seçimiyle ders listesi öğretmenin
derslerine daralır; "Bütün dersler" ile yeniden açılır.
"""
from __future__ import annotations

import io
import json
import os
import time
from typing import List, Optional

from oyun.motor import terminal as ekran
from oyun.motor.degerlendirme import dogru_cevap_metni
from oyun.motor.kayit_defteri import icerigi_yukle, uret, uygun_kayitlar
from oyun.motor.modeller import DERS_ADLARI, Bulmaca

SINIFLAR = tuple(range(1, 13))
NOT_DOSYASI = "icerik_notlari.jsonl"
KATEGORILER = ("Hatalı: cevap, sayı ya da anlatı yanlış",
               "Düzeye uygun değil",
               "Programda yok",
               "Dil ya da yazım")


def not_dosyasi() -> str:
    from oyun.motor import durum as durum_modulu
    return os.path.join(durum_modulu.KAYIT_KLASORU, NOT_DOSYASI)


def sorun_bildir(bulmaca: Bulmaca, kategori: str, not_metni: str = "") -> str:
    """Öğretmenin içerik notunu ekler, dosya yolunu döner.

    Soru tohumla üretildiği için aynı görev bir daha birebir gelmeyebilir;
    bu yüzden kodun yanında sorunun kendisi de yazılır.
    """
    yol = not_dosyasi()
    os.makedirs(os.path.dirname(yol), exist_ok=True)
    kayit = {
        "zaman": time.strftime("%Y-%m-%d %H:%M"),
        "kod": bulmaca.kod, "ders": bulmaca.ders, "konu": bulmaca.konu,
        "kademe": bulmaca.kademe, "baslik": bulmaca.baslik,
        "kategori": kategori, "not": (not_metni or "").strip(),
        "brifing": bulmaca.brifing,
        "adimlar": [{"soru": a.soru, "dogru": dogru_cevap_metni(a)}
                    for a in bulmaca.adimlar],
    }
    with io.open(yol, "a", encoding="utf-8") as dosya:
        dosya.write(json.dumps(kayit, ensure_ascii=False) + "\n")
    return yol


def cevap_anahtari(bulmaca: Bulmaca) -> str:
    """Görevin öğretmene gösterilen tam çözümü."""
    satirlar = [
        "{} -- {}, {}. kademe".format(bulmaca.baslik,
                                      DERS_ADLARI.get(bulmaca.ders, bulmaca.ders),
                                      bulmaca.kademe),
        "Kazanım: " + (bulmaca.kazanim or "-"),
        "",
    ]
    for sira, adim in enumerate(bulmaca.adimlar, start=1):
        satirlar.append("{}) {}".format(sira, adim.soru))
        for n, secenek in enumerate(adim.secenekler or [], start=1):
            satirlar.append("   {}. {}".format(n, secenek))
        satirlar.append("   DOĞRU: " + dogru_cevap_metni(adim))
        if adim.aciklama:
            satirlar.append("   Açıklama: " + adim.aciklama)
        if getattr(adim, "cozum", ""):
            satirlar.append("   Çözüm: " + adim.cozum.replace("\n", "\n           "))
        for ipucu in adim.ipuclari or []:
            satirlar.append("   İpucu: " + ipucu)
        for yanlis, teshis in (adim.yanlis_teshis or {}).items():
            if yanlis != "*":
                satirlar.append("   Yanlış \"{}\": {}".format(yanlis, teshis))
        satirlar.append("")
    return "\n".join(satirlar)


def tum_dersler() -> List[str]:
    return sorted({k.ders for k in uygun_kayitlar()},
                  key=lambda d: DERS_ADLARI.get(d, d))


def _dersler(hepsi: bool = False) -> List[str]:
    """Branş seçildiyse (B42.1) yalnız o dersler; yoksa ya da `hepsi` ise tümü."""
    from araclar.ogretmen import branslar
    tum = tum_dersler()
    secili = [d for d in branslar() if d in tum]
    return tum if (hepsi or not secili) else secili


def _sec(baslik: str, secenekler: List[str]) -> Optional[int]:
    secim = ekran.menu(baslik, list(secenekler) + ["Geri"])
    if secim is None or secim < 0 or secim >= len(secenekler):
        return None
    return secim


def _goster(ders: str, sinif: int, konu: Optional[str]) -> None:
    from oyun.motor.oturum import Oturum, sonucu_ozetle

    bulmaca = uret(ders=ders, kademe=sinif, konu=konu)
    while bulmaca is not None:
        ekran.temizle()
        ekran.baslik("GÖREVLERİ DENE -- " + bulmaca.baslik, "kalin", "acik_cam")
        ekran.yaz("{}, {}. sınıf, konu: {}".format(
            DERS_ADLARI.get(ders, ders), sinif, bulmaca.konu), "gri")
        secim = _sec("", ["Öğrenci gibi oyna (kayıt tutulmaz)",
                          "Cevap anahtarını göster",
                          "Başka bir örnek üret",
                          "Bu soruda sorun var (not bırak)"])
        if secim is None:
            return
        if secim == 0:
            sonuc = Oturum(bulmaca).oyna()
            sonucu_ozetle(bulmaca, sonuc)
            ekran.bekle()
        elif secim == 1:
            ekran.temizle()
            ekran.yaz(cevap_anahtari(bulmaca), sar=False)
            ekran.bekle()
        elif secim == 2:
            bulmaca = uret(ders=ders, kademe=sinif, konu=konu)
        else:
            k = _sec("Sorun ne?", list(KATEGORILER))
            if k is None:
                continue
            not_metni = ekran.sor("Kısa not (boş bırakılabilir):", "")
            ekran.basari("Not kaydedildi: " + sorun_bildir(
                bulmaca, KATEGORILER[k], not_metni))
            ekran.bekle()
    ekran.bilgi("Bu seçim için görev üretilemedi.")
    ekran.bekle()


def onizleme() -> None:
    """Öğretmen masasındaki "Görevleri dene" akışı."""
    icerigi_yukle()
    hepsi = False
    while True:
        dersler = _dersler(hepsi)
        suzgecli = len(dersler) < len(tum_dersler())
        ekran.temizle()
        ekran.baslik("GÖREVLERİ DENE", "kalin", "acik_cam")
        ekran.bilgi("Örnek soru ve içerik denetimi için. Kayıt tutulmaz; üs, "
                    "kaynak ve rütbe yok.")
        adlar = [DERS_ADLARI.get(x, x) for x in dersler]
        d = _sec("Hangi ders?", adlar + (["Bütün dersler"] if suzgecli else []))
        if d is None:
            return
        if d == len(dersler):
            hepsi = True
            continue
        ders = dersler[d]
        siniflar = [s for s in SINIFLAR if uygun_kayitlar(ders=ders, kademe=s)]
        s = _sec("Hangi sınıf düzeyi?", ["{}. sınıf".format(x) for x in siniflar])
        if s is None:
            continue
        sinif = siniflar[s]
        konu_listesi = sorted({k.konu for k in uygun_kayitlar(ders=ders, kademe=sinif)})
        k = _sec("Hangi konu?", ["Karışık (rastgele konu)"] + konu_listesi)
        if k is None:
            continue
        _goster(ders, sinif, None if k == 0 else konu_listesi[k - 1])
