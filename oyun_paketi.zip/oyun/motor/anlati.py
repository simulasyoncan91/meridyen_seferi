# -*- coding: utf-8 -*-
"""Öğrencinin seçtiği anlatım çerçevesi ve tamamlanınca konu keşfi.

Tercihler beceri/kişilik sınıflandırması değildir. Soru verileri, doğru
cevaplar, destek ve ödül bu modül tarafından değiştirilmez.
"""
import random
from functools import lru_cache

from .kayit_defteri import uygun_kayitlar
from .modeller import ANLATIM, BIRLIKTE

TARZLAR = {
    "kesif": ("Keşif", "ipuçlarını takip et, olayın ardındaki bağlantıyı bul",
              "Bu dosyada fark edilmeyi bekleyen bir bağlantı var. İzleri birleştirip ne olduğunu ortaya çıkarabilirsin.",
              "Dosyaya yeni bir iz eklendi. Sonraki keşfe hazır olduğunda devam edebilirsin."),
    "uretim": ("Üretme", "bir sorunu çöz, üste bir işin nasıl yapılacağını öğren",
               "Bugünkü işin, üste işe yarayan bir çözüm hazırlamak. Önce eldeki bilgileri incele, sonra çözümünü kur.",
               "Çözüm yolu atölye defterine girdi. Sonraki işte bu yolu yeniden kullanabilirsin."),
    "dayanisma": ("Dayanışma", "ekibin işine yarayan çözümü birlikte bul",
                  "Ekip bu dosyayı seninle birlikte incelemek istiyor. Senin fark ettiğin bir ayrıntı ortak çözümün bir parçası olabilir.",
                  "Bu dosyadaki deneyimin ekibin notlarına eklendi. Yardım istemek de ortak çalışmanın bir parçası."),
    "sade": ("Sade anlatım", "doğrudan olayı oku; ek hikâye çerçevesi gösterilmez", "", ""),
}


def tarz(durum):
    kod = durum.ayarlar.get("hikaye_tarzi", "kesif") if durum else "sade"
    return kod if kod in TARZLAR else "kesif"


def giris_metni(durum):
    return TARZLAR[tarz(durum)][2]


def kapanis_metni(durum):
    return TARZLAR[tarz(durum)][3]


def konu_kimligi(ders, konu):
    return ders + ":" + konu


@lru_cache(maxsize=1024)
def _dosya_basligi(ders, konu, kademe):
    kayitlar = uygun_kayitlar(ders=ders, konu=konu)
    if kayitlar:
        k = min(kayitlar, key=lambda k: abs(max(k.kademeler[0], min(kademe, k.kademeler[1])) - kademe))
        try:
            b = k.fonksiyon(random.Random(0), max(k.kademeler[0], min(kademe, k.kademeler[1])))
            if b and b.baslik:
                return b.baslik
        except Exception:
            # Yarım yazılmış bir üretici konu haritasını kapatmamalı.
            pass
    return "Mühürlü dosya"


def konu_etiketi(durum, ders, konu):
    if konu_kimligi(ders, konu) in durum.kesfedilen_konular:
        return konu.replace("_", " ")
    return "? " + _dosya_basligi(ders, konu, durum.ders(ders).kademe)


def kesif_metni(bulmaca, sonuc):
    """Gözlenen başarıyı aşmadan, çalışılan beceriyi adlandırır."""
    if sonuc.birakildi or not sonuc.tamamlandi:
        return ""
    konu = bulmaca.kazanim or bulmaca.konu.replace("_", " ")
    if sonuc.asama == ANLATIM:
        return "Az önce çözüm yolunu izlediğin konu: {}\nŞimdi aynı yolu birlikte deneyebilirsin.".format(konu)
    if sonuc.asama == BIRLIKTE:
        return "Az önce birlikte çalıştığın konu: {}\nYol gösterilirken {} adımda ilk denemede doğru seçim yaptın.".format(
            konu, sonuc.ilk_denemede_dogru)
    return "Az önce çalıştığın konu: {}\n{} adımın {} tanesini ilk denemede, ipucu almadan geçtin. İstersen destekle yeniden deneyebilirsin.".format(
        konu, len(sonuc.adim_sonuclari), sonuc.ilk_denemede_dogru)
