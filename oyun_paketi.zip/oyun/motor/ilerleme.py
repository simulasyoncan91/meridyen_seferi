# -*- coding: utf-8 -*-
"""
İlerleme ve uyarlanır zorluk.

Oyun her dersi ayrı ayrı takip eder: bir öğrenci Türkçede 9. sınıf, matematikte
6. sınıf seviyesinde olabilir; oyun da ona göre soru verir. Ölçüt salt puan
değil, "modelleme adımını ilk denemede geçebildi mi" bilgisidir - yani işlemi
yapabilmek değil, olayı doğru bağıntıya oturtabilmek.
"""
from __future__ import annotations

from typing import List, Tuple

from .durum import DersDurumu, Durum, KonuDurumu
from .modeller import (
    ANLATIM, BIRLIKTE, BulmacaSonucu, DERS_ADLARI, KADEME_ADLARI, SERBEST,
    ZORLUK_ADLARI, kademe_zorlugu,
)

# Kayan ortalama katsayısı: 0.35 => son görev biraz ağır basar ama tek görev
# öğrenciyi bir kademe aşağı atmaz.
KATSAYI = 0.35

YUKSELME_ESIGI = 0.80
DUSME_ESIGI = 0.34
YUKSELME_SERISI = 2
DUSME_SERISI = 2

ROZETLER = {
    "ilk_gorev": "İlk Rapor",
    "modelci": "Modelci - 5 görevde bilinmeyeni ilk denemede kurdu",
    "kanitsiz": "Sezgi - hiç kanıt açmadan bir görevi tam çözdü",
    "tam_puan": "Kusursuz Rapor - bir görevden tam puan",
    "cok_yonlu": "Çok Yönlü - bütün öğrenme yollarından görev tamamladı",
    "kararli": "Kararlı - üst üste 5 başarılı görev",
    "lise": "İleri Adım - Zorluk 4 düzeyine ulaştı",
    "universite": "Ustalık Adımı - Zorluk 5 düzeyine ulaştı",
}


def _basari_olcusu(sonuc: BulmacaSonucu) -> float:
    """
    0..1 arası tek bir başarı sayısı.
    Puan oranı ana bileşen; modelleme adımı ayrıca ödüllendirilir/cezalandırılır.
    """
    olcu = sonuc.oran
    model = sonuc.model_basarisi()
    if model is True:
        olcu = min(1.0, olcu + 0.12)
    elif model is False:
        olcu = max(0.0, olcu - 0.12)
    if sonuc.birakildi:
        olcu = min(olcu, 0.25)
    return max(0.0, min(1.0, olcu))


# Serbest aşamada "iyi geçti" sayılan en düşük oran.
IYI_ESIGI = 0.6
# Bu oranın altı, konunun henüz oturmadığı anlamına gelir.
ZORLANMA_ESIGI = 0.4


def konu_asamasini_isle(durum: Durum, sonuc: BulmacaSonucu) -> List[str]:
    """
    Konunun öğretim aşamasını sonuca göre ilerletir ya da geri alır.

    Kural basit: anlatımı izleyen birlikte çalışmaya, birlikte çalışmayı
    tamamlayan kendi başına çözmeye geçer. Kendi başına iki kez üst üste
    zorlanan öğrenci birlikte çalışmaya geri döner - bu bir ceza değil,
    desteğin geri gelmesidir.
    """
    bildirimler: List[str] = []
    konu = durum.ders(sonuc.ders).konu(sonuc.konu)
    konu_adi = sonuc.konu.replace("_", " ")

    if sonuc.birakildi:
        return bildirimler

    if sonuc.asama == ANLATIM:
        konu.anlatim_sayisi += 1
        if konu.asama == ANLATIM:
            konu.asama = BIRLIKTE
            bildirimler.append(
                "{}: anlatımı gördün, sıra birlikte çözmede.".format(konu_adi))

    elif sonuc.asama == BIRLIKTE:
        konu.birlikte_sayisi += 1
        hepsi_dogru = bool(sonuc.adim_sonuclari) and all(
            a.dogru for a in sonuc.adim_sonuclari)
        if hepsi_dogru and konu.asama in (ANLATIM, BIRLIKTE):
            konu.asama = SERBEST
            bildirimler.append(
                "{}: birlikte çözdün, artık tek başına deneyebilirsin.".format(konu_adi))
        elif konu.asama == ANLATIM:
            konu.asama = BIRLIKTE
        else:
            bildirimler.append(
                "{}: bir tur daha birlikte çalışalım, acele yok.".format(konu_adi))

    else:  # SERBEST
        konu.serbest_toplam += 1
        oran = sonuc.oran
        konu.ustalik = 0.65 * konu.ustalik + 0.35 * oran
        if oran >= IYI_ESIGI:
            konu.serbest_dogru += 1
            konu.ust_uste_zorlanma = 0
            if konu.tamamlandi:
                bildirimler.append("{}: bu konu oturmuş görünüyor.".format(konu_adi))
        elif oran < ZORLANMA_ESIGI:
            konu.ust_uste_zorlanma += 1
            if konu.ust_uste_zorlanma >= 2:
                konu.asama = BIRLIKTE
                konu.ust_uste_zorlanma = 0
                bildirimler.append(
                    "{}: bu konuyu birlikte tekrar edelim; yalnız bırakmak "
                    "için erken.".format(konu_adi))
        else:
            konu.ust_uste_zorlanma = 0

    return bildirimler


def _hatalari_isle(durum: Durum, sonuc: BulmacaSonucu) -> None:
    """
    Görevde gösterilen yanlış teşhislerini öğrencinin dosyasına yazar.

    Birlikte aşamasında yapılan hata da sayılır: destekle bile aynı yere
    takılıyorsa, bu konunun tekrar edilmesi gerektiğinin en net işaretidir.
    """
    if not sonuc.teshisler:
        return
    sayac = durum.ders(sonuc.ders).hata_turleri
    for metin in sonuc.teshisler:
        sayac[metin] = sayac.get(metin, 0) + 1


def _kisisel_ilerleme(durum: Durum, sonuc: BulmacaSonucu) -> List[str]:
    """Aynı konudaki bir önceki bağımsız görevle kıyas satırı. (B31.14)

    Kayıt ve kıyas aynı yerde yapılıyor: önce eski özet okunur, sonra
    yenisi yazılır. Ayrı yerlerde olsalardı çağrı sırası değişince görev
    kendisiyle kıyaslanır ve özellik sessizce ölürdü.

    Yalnızca tamamlanan bağımsız görevler sayılır. Anlatım ve birlikte
    aşamalarında yardım zaten işin kendisi; onları kıyasa katmak "yardım
    azaldı" diye sahte bir ilerleme üretirdi.
    """
    if sonuc.birakildi or sonuc.asama in (ANLATIM, BIRLIKTE):
        return []
    if not sonuc.adim_sonuclari:
        return []
    from . import degerlendirme
    konu = durum.ders(sonuc.ders).konu(sonuc.konu)
    onceki = dict(konu.son_gorev or {})
    simdi = degerlendirme.gorev_ozeti(sonuc)
    konu.son_gorev = simdi
    satir = degerlendirme.kisisel_karsilastirma(onceki, simdi)
    return [satir] if satir else []


def sonucu_isle(durum: Durum, sonuc: BulmacaSonucu, uretici_adi: str = "") -> List[str]:
    """
    Bir görev sonucunu duruma işler.
    Oyuncuya gösterilecek bildirim satırlarını döner (kademe değişimi, rozet...).

    Anlatım ve birlikte aşamaları PUANLANMAZ: onlar öğrenme aşamalarıdır,
    ölçme aşaması değil. Yalnızca konu aşaması ilerletilir.
    """
    bildirimler: List[str] = _kisisel_ilerleme(durum, sonuc)
    bildirimler.extend(konu_asamasini_isle(durum, sonuc))
    from .konu_secimi import zorlanmayi_guncelle
    zorlanmayi_guncelle(durum, sonuc)
    _hatalari_isle(durum, sonuc)
    from .tekrar import tekrari_planla
    tekrari_planla(durum, sonuc)

    if sonuc.asama in (ANLATIM, BIRLIKTE):
        durum.gorevi_say()
        if uretici_adi:
            ders_durumu = durum.ders(sonuc.ders)
            ders_durumu.son_ureticiler.append(uretici_adi)
            del ders_durumu.son_ureticiler[:-6]
        bildirimler.extend(_rozetleri_kontrol_et(durum, sonuc))
        return bildirimler

    ders_durumu = durum.ders(sonuc.ders)
    olcu = _basari_olcusu(sonuc)

    ders_durumu.ustalik = (1 - KATSAYI) * ders_durumu.ustalik + KATSAYI * olcu
    ders_durumu.cozulen += 1
    ders_durumu.toplam_puan += sonuc.puan
    ders_durumu.toplam_yildiz += sonuc.yildiz

    model = sonuc.model_basarisi()
    if model is not None:
        ders_durumu.model_toplam += 1
        if model:
            ders_durumu.model_dogru += 1

    onceki = ders_durumu.konu_puani.get(sonuc.konu, 0.5)
    ders_durumu.konu_puani[sonuc.konu] = round((1 - KATSAYI) * onceki + KATSAYI * olcu, 3)

    if uretici_adi:
        ders_durumu.son_ureticiler.append(uretici_adi)
        del ders_durumu.son_ureticiler[:-6]

    if olcu >= 0.65:
        ders_durumu.seri += 1
        ders_durumu.kotu_seri = 0
    elif olcu <= 0.4:
        ders_durumu.kotu_seri += 1
        ders_durumu.seri = 0
    else:
        ders_durumu.seri = 0
        ders_durumu.kotu_seri = 0

    durum.gorevi_say()

    if durum.ayarlar.get("zorluk", "uyarlanir") == "uyarlanir":
        bildirimler.extend(_kademe_ayarla(ders_durumu, sonuc.ders))

    bildirimler.extend(_rozetleri_kontrol_et(durum, sonuc))
    return bildirimler


def _kademe_ayarla(ders_durumu: DersDurumu, ders_kodu: str) -> List[str]:
    bildirimler = []
    onceki_zorluk = kademe_zorlugu(ders_durumu.kademe)

    if (ders_durumu.ustalik >= YUKSELME_ESIGI
            and ders_durumu.seri >= YUKSELME_SERISI
            and ders_durumu.kademe < 13):
        ders_durumu.kademe += 1
        ders_durumu.seri = 0
        ders_durumu.ustalik = 0.62  # yeni kademede sıfırdan başlamasın ama rahat da olmasın
        yeni_zorluk = kademe_zorlugu(ders_durumu.kademe)
        if yeni_zorluk > onceki_zorluk:
            bildirimler.append("Bu masada Zorluk {} - {} düzeyine geçtin.".format(
                yeni_zorluk, ZORLUK_ADLARI[yeni_zorluk]))

    elif (ders_durumu.ustalik <= DUSME_ESIGI
            and ders_durumu.kotu_seri >= DUSME_SERISI
            and ders_durumu.kademe > 1):
        ders_durumu.kademe -= 1
        ders_durumu.kotu_seri = 0
        ders_durumu.ustalik = 0.5
        yeni_zorluk = kademe_zorlugu(ders_durumu.kademe)
        if yeni_zorluk < onceki_zorluk:
            bildirimler.append("Desteği artırdım; bir süre Zorluk {} - {} görevleri "
                               "gelecek.".format(yeni_zorluk,
                                                 ZORLUK_ADLARI[yeni_zorluk]))

    return bildirimler


def _rozetleri_kontrol_et(durum: Durum, sonuc: BulmacaSonucu) -> List[str]:
    bildirimler = []

    def ver(anahtar: str) -> None:
        if durum.rozet_ekle(ROZETLER[anahtar]):
            bildirimler.append("Yeni rozet: " + ROZETLER[anahtar])

    if durum.oynanan_gorev == 1:
        ver("ilk_gorev")
    if sonuc.puan == sonuc.azami_puan and sonuc.azami_puan > 0:
        ver("tam_puan")
    if sonuc.acilan_kanit == 0 and sonuc.oran >= 0.9:
        ver("kanitsiz")
    aktif = durum.aktif_dersler()
    if aktif and all(durum.ders(d).cozulen > 0 for d in aktif):
        ver("cok_yonlu")
    if any(durum.ders(d).seri >= 5 for d in aktif):
        ver("kararli")
    if sum(durum.ders(d).model_dogru for d in aktif) >= 5:
        ver("modelci")
    if any(durum.ders(d).kademe >= 9 for d in aktif):
        ver("lise")
    if any(durum.ders(d).kademe >= 13 for d in aktif):
        ver("universite")

    return bildirimler


def karne(durum: Durum) -> List[Tuple[str, DersDurumu]]:
    """Ders adı + durum çiftlerini sabit sırayla döner (karne ekranı için)."""
    return [(DERS_ADLARI.get(d, d), durum.ders(d)) for d in durum.aktif_dersler()]


def genel_degerlendirme(durum: Durum) -> str:
    """Karnenin altına yazılacak tek cümlelik değerlendirme."""
    # (ders_kodu, DersDurumu) çiftleriyle çalışıyoruz: DersDurumu bir dataclass
    # olduğu için sözlük anahtarı yapılamaz, ters çevirme denemesi çöker.
    ciftler = [(kod, durum.ders(kod)) for kod in durum.aktif_dersler()]
    oynanmis = [(kod, d) for kod, d in ciftler if d.cozulen > 0]
    if not oynanmis:
        return "Henüz görev tamamlamadın. Görev panosundan birini seç."

    if len(oynanmis) == 1:
        return ("Şimdilik tek bir görev türünde ilerliyorsun; başka öğrenme "
                "yollarını da açarsan üs dengeli büyür.")

    en_iyi_kod, en_iyi = max(oynanmis, key=lambda c: c[1].ustalik)
    en_zayif_kod, en_zayif = min(oynanmis, key=lambda c: c[1].ustalik)

    if en_iyi_kod == en_zayif_kod:
        return "Bütün alanlarda aynı düzeydesin. Haritadan yeni bir konu seç."

    model_toplam = sum(d.model_toplam for _, d in ciftler)
    model_dogru = sum(d.model_dogru for _, d in ciftler)
    model_notu = ""
    if model_toplam >= 3:
        oran = model_dogru / model_toplam
        if oran >= 0.7:
            model_notu = " Bilinmeyeni kurmakta iyisin; asıl beceri bu."
        elif oran <= 0.4:
            model_notu = (" İşlemler tamam ama olayı bağıntıya çevirirken acele "
                          "ediyorsun; kanıtları okumadan adıma geçme.")

    return ("Bazı konularda artık kendi başına ilerliyorsun; en düşük rahatlık "
            "gösteren konuları birlikte tekrar edeceğiz.{}".format(model_notu))
