# -*- coding: utf-8 -*-
"""
Türkçe görevleri.

Çerçeve: ARŞİV ve RAPOR. İki tür iş var:

  (A) Üst makama gidecek bir rapor hazırlanıyor; yazımı, noktalaması ve
      üslubu kusursuz olmak zorunda.
  (B) Personelin yazdığı mektup ve tutanaklarda yazım yanlışlarını bulup
      düzeltmek gerekiyor.

Bu derste "keşif" şöyle işler: öğrenci önce hatayı bulur, sonra HANGİ KURALIN
çiğnendiğini teşhis eder, ancak ondan sonra düzeltir. Kuralı bilmeden yapılan
düzeltme, bir sonraki metinde işe yaramaz.

NOT: Buradaki bütün yazım kuralları TDK ölçütüne göredir.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, coklu_siklar, metin_adimi, model_adimi,
    secim_adimi, sirala_adimi, yorum_adimi,
)


# ==========================================================================
# MEKTUP DÜZELTME - bu dersin ana görevi
# ==========================================================================

_MEKTUPLAR = [
    {
        "yazan": "Onbaşı Demir",
        "konu": "depo sayımı",
        "hatali": [
            {
                "cumle": "Depoya gelen malzemeyi saydım, bende raporu yazdım.",
                "yanlis": "bende", "dogru": "ben de",
                "kural": "Bağlaç olan \"de/da\" her zaman ayrı yazılır",
                "neden": ("Buradaki \"de\" \"ayrıca, aynı zamanda\" anlamındadır; "
                          "yani bağlaçtır ve ayrı yazılır. Cümleden çıkarıldığında "
                          "cümle bozulmuyorsa bağlaçtır. Bitişik yazılan \"-de\" "
                          "bulunma hâli ekidir: \"depoda\", \"elimde\"."),
            },
            {
                "cumle": "Sayımda hiç bir eksik çıkmadı.",
                "yanlis": "hiç bir", "dogru": "hiçbir",
                "kural": "\"hiçbir\" kalıplaşmıştır ve bitişik yazılır",
                "neden": ("\"hiçbir\" kalıplaşmış birleşik bir sözcüktür ve bitişik "
                          "yazılır; \"hiçbiri\", \"birkaç\", \"birçok\" da öyledir. "
                          "Buna karşılık \"her şey\" ve \"bir şey\" AYRI yazılır."),
            },
            {
                "cumle": "Bu işi yanlız başıma tamamladım.",
                "yanlis": "yanlız", "dogru": "yalnız",
                "kural": "Bu sözcüğün doğru yazımı ayrıca ezberlenir",
                "neden": ("Doğru yazım \"yalnız\"tır. Sık karıştırılan iki sözcük "
                          "var: \"yalnız\" (tek başına) ve \"yanlış\" (doğru "
                          "olmayan). \"yanlız\" diye bir sözcük yoktur."),
            },
        ],
        "dogru": [
            "Kışlık erzak sayımı yarın tamamlanacak.",
            "Ambar kapısının kilidi değiştirildi.",
            "Gerekli görülürse ek liste hazırlayabilirim.",
        ],
    },
    {
        "yazan": "Teknisyen Aylin",
        "konu": "jeneratör bakımı",
        "hatali": [
            {
                "cumle": "Jeneratörü onardım, yedek parçayıda getirdim.",
                "yanlis": "parçayıda", "dogru": "parçayı da",
                "kural": "Bağlaç olan \"de/da\" her zaman ayrı yazılır",
                "neden": ("\"da\" burada \"ayrıca\" anlamında bağlaçtır, ayrı "
                          "yazılır. Ayrıca bağlaç olan \"de/da\" hiçbir zaman "
                          "\"te/ta\" biçimine girmez; \"kitapta\" gibi bitişik "
                          "yazılanlar hâl ekidir."),
            },
            {
                "cumle": "Bir kaç gün içinde ikinci jeneratöre bakacağım.",
                "yanlis": "Bir kaç", "dogru": "birkaç",
                "kural": "\"birkaç\" kalıplaşmıştır ve bitişik yazılır",
                "neden": ("\"birkaç\" kalıplaşmış bir belirsizlik sıfatıdır, bitişik "
                          "yazılır. Aynı grupta \"birçok\", \"birtakım\", \"hiçbir\" "
                          "vardır."),
            },
            {
                "cumle": "Ankaraya gönderilecek listeyi hazırladım.",
                "yanlis": "Ankaraya", "dogru": "Ankara'ya",
                "kural": "Özel ada gelen çekim eki kesme ile ayrılır",
                "neden": ("Özel adlara gelen çekim ekleri kesme işaretiyle ayrılır: "
                          "\"Ankara'ya\", \"Ahmet'in\", \"Türkiye'de\". Ama YAPIM "
                          "ekleri ayrılmaz: \"Ankaralı\", \"Türkçe\"."),
            },
        ],
        "dogru": [
            "Kablo bağlantıları yeniden yapıldı.",
            "Ölçüm sonuçlarını deftere işledim.",
            "Konuyla ilgili onayınızı bekliyorum.",
        ],
    },
    {
        "yazan": "Kâtip Sarp",
        "konu": "arşiv düzeni",
        "hatali": [
            {
                "cumle": "Raporun bittimi diye sordular.",
                "yanlis": "bittimi", "dogru": "bitti mi",
                "kural": "Soru ekleri \"mi/mı\" her zaman ayrı yazılır",
                "neden": ("Soru eki daima ayrı yazılır: \"bitti mi\", \"geldi mi\", "
                          "\"gelecek misin\". Kendisinden sonra gelen ekler ise ona "
                          "bitişir: \"mısın\", \"midir\"."),
            },
            {
                "cumle": "Herkez elinden geleni yaptı.",
                "yanlis": "Herkez", "dogru": "herkes",
                "kural": "Bu sözcüğün doğru yazımı ayrıca ezberlenir",
                "neden": ("Doğru yazım \"herkes\"tir. Sonundaki ses konuşurken "
                          "yumuşak duyulduğu için sık yanlış yazılır; ama yazımda "
                          "\"s\" ile biter."),
            },
            {
                "cumle": "Dosyaları düzenledim, hiç birini atmadım.",
                "yanlis": "hiç birini", "dogru": "hiçbirini",
                "kural": "\"hiçbir\" kalıplaşmıştır ve bitişik yazılır",
                "neden": ("\"hiçbiri\" de \"hiçbir\" gibi bitişik yazılır. Ayrı "
                          "yazılanlar \"her şey\", \"bir şey\", \"hiç kimse\"dir."),
            },
        ],
        "dogru": [
            "Yeni dosya dolabı bugün teslim alındı.",
            "Eski tutanaklar tarih sırasına dizildi.",
            "Merkeze gidecek evrakı ayırdım.",
        ],
    },
]


# Yanlış kural şıkkını seçen öğrenciye söylenecek söz. "{}" cümledeki sorunlu
# ifadeyle doldurulur; öğrenci hatayı hangi kurala yanlışlıkla bağladığını
# görsün diye. Doğru kuralı söylemez, yalnızca seçtiği kuralın neyi
# düzenlediğini hatırlatır.
_KURAL_TESHISI = {
    "Bağlaç olan \"de/da\" her zaman ayrı yazılır":
        "Bu madde yalnızca \"de/da\" yazımını düzenler. \"{}\" ifadesinde "
        "ayrı mı bitişik mi diye tartışılacak bir \"de/da\" yok; hatayı "
        "başka bir maddeye bağlaman gerekiyor.",
    "\"hiçbir\" kalıplaşmıştır ve bitişik yazılır":
        "Bu madde \"hiçbir, hiçbiri, birkaç, birçok\" gibi kalıplaşmış "
        "sözcükleri düzenler. \"{}\" bu listede geçmiyor; sorunun kaynağı "
        "kalıplaşma değil.",
    "Soru ekleri \"mi/mı\" her zaman ayrı yazılır":
        "Bu madde soru ekiyle ilgilidir. \"{}\" ifadesinde soru eki yok; "
        "cümle bir şey sormuyor, bildiriyor.",
    "Özel ada gelen çekim eki kesme ile ayrılır":
        "Bu madde özel adlarla ilgilidir. \"{}\" bir kişi, yer ya da kurum "
        "adı değil; kesme işareti tartışması buraya girmiyor.",
    "Bu sözcüğün doğru yazımı ayrıca ezberlenir":
        "Bu madde, arkasında bir kural olmayan tek tek yazımlar içindir "
        "(\"yalnız\", \"herkes\" gibi). \"{}\" ise açık bir kurala bağlı; "
        "kuralı bulursan aynı türden bütün hataları düzeltirsin.",
    "Tamamlanan her cümlenin sonuna nokta konur":
        "Bu madde noktalamayla ilgilidir. Cümlenin sonunda nokta zaten var; "
        "aksayan yer \"{}\" ifadesinin yazımı.",
}


@bulmaca(ders="turkce", konu="mektup_duzeltme", kademeler=(3, 12), agirlik=1.6)
def mektup_duzeltme(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Personelin mektubundaki yazım yanlışları bulunacak ve düzeltilecek."""
    mektup = rastgele.choice(_MEKTUPLAR)
    hatalar = list(mektup["hatali"])
    rastgele.shuffle(hatalar)
    odak = hatalar[0]

    hatali_cumleler = [h["cumle"] for h in hatalar]
    secenekler, dogru_indeksler = coklu_siklar(
        rastgele, hatali_cumleler, mektup["dogru"])

    kurallar = list({h["kural"] for h in mektup["hatali"]})
    diger_kurallar = [k for k in [
        "Bağlaç olan \"de/da\" her zaman ayrı yazılır",
        "\"hiçbir\" kalıplaşmıştır ve bitişik yazılır",
        "Soru ekleri \"mi/mı\" her zaman ayrı yazılır",
        "Özel ada gelen çekim eki kesme ile ayrılır",
        "Bu sözcüğün doğru yazımı ayrıca ezberlenir",
        "Tamamlanan her cümlenin sonuna nokta konur",
    ] if k != odak["kural"]
        # "birkaç" hatasında "hiçbir" maddesi aynı kuralı söyler (ikisi de
        # kalıplaşmış birleşik sözcük); çeldirici olursa iki doğru şık çıkar.
        and not ("kalıplaşmıştır" in k and "kalıplaşmıştır" in odak["kural"])]

    return Bulmaca(
        kod="tur-mektup-duzeltme",
        ders="turkce",
        baslik="Arşive Gelen Mektup",
        kademe=kademe,
        konu="mektup_duzeltme",
        kazanim="Yazım yanlışlarını bulma ve hangi kuralın çiğnendiğini belirleme.",
        dikkat=6,
        brifing=(
            "{} , {} hakkında bir mektup yazıp arşive bırakmış. Mektup elden "
            "geçmeden merkeze gidecek dosyaya konamaz.\n\n"
            "Metni okudun; anlatılan iş temiz, sorun yok. Ama yazımda "
            "aksaklıklar var ve arşiv sorumlusu \"yanlış yazılmış tek cümleyle "
            "bile gönderilmez\" diyor.\n\n"
            "Hatalı cümleleri bulup düzeltmen, ayrıca hangi kuralın "
            "çiğnendiğini de yazman gerekiyor - {} bir daha aynı hatayı "
            "yapmasın diye."
        ).format(mektup["yazan"], mektup["konu"], mektup["yazan"]),
        kanitlar=[
            Kanit("Yazım kılavuzu - de/da",
                  "Bağlaç olan \"de/da\" AYRI yazılır ve \"ayrıca, aynı zamanda\" "
                  "anlamı katar; cümleden çıkarılabilir.\n"
                  "Bulunma hâli eki \"-de/-da/-te/-ta\" BİTİŞİK yazılır ve "
                  "çıkarılırsa cümle bozulur.\n"
                  "Bağlaç olan de/da asla \"te/ta\" olmaz.",
                  bedel=2, kritik=True),
            Kanit("Yazım kılavuzu - birleşik yazım",
                  "Bitişik: hiçbir, hiçbiri, birkaç, birçok, birtakım, herkes\n"
                  "Ayrı: her şey, bir şey, hiç kimse, pek çok",
                  bedel=2, kritik=True),
            Kanit("Yazım kılavuzu - soru eki ve kesme",
                  "Soru eki \"mi/mı/mu/mü\" HER ZAMAN ayrı yazılır: \"geldi mi\", "
                  "\"gelecek misin\".\n"
                  "Özel adlara gelen ÇEKİM ekleri kesme ile ayrılır: "
                  "\"Ankara'ya\". YAPIM ekleri ayrılmaz: \"Ankaralı\".",
                  bedel=2, kritik=True),
            Kanit("Sık yanlış yazılanlar listesi",
                  "yalnız (yanlız değil)   yanlış (yalnış değil)\n"
                  "herkes (herkez değil)   sürpriz (süpriz değil)\n"
                  "orijinal (orjinal değil)   kılavuz (klavuz değil)",
                  bedel=2, kritik=True),
            Kanit("Arşiv sorumlusunun notu",
                  "\"Düzeltmeyi yaparken kuralı da yaz. Yoksa aynı mektup gelecek "
                  "ay aynı hatayla yine gelir.\"", bedel=1),
        ],
        adimlar=[
            coklu_adimi(
                soru="Mektuptaki hangi cümlelerde yazım yanlışı var? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Hatalı cümleler ve düzeltmeleri:\n" + "\n".join(
                        "- \"{}\" -> \"{}\"".format(h["yanlis"], h["dogru"])
                        for h in hatalar
                    ) + "\nDiğer cümlelerde yazım hatası yoktur."
                ),
                ipuclari=[
                    "Kılavuzdaki dört başlığı sırayla her cümleye uygula.",
                    "Bitişik yazılmış \"de/da\"ları ve ayrı yazılmış \"hiç bir\" "
                    "türü kalıpları ara.",
                ],
                puan=20,
            ),
            model_adimi(
                soru="\"{}\" cümlesinde hangi kural çiğnenmiş?".format(odak["cumle"]),
                dogru=odak["kural"],
                yanlislar={
                    kural: _KURAL_TESHISI[kural].format(odak["yanlis"])
                    for kural in rastgele.sample(
                        diger_kurallar, min(3, len(diger_kurallar)))
                },
                rastgele=rastgele,
                aciklama=odak["neden"],
                ipuclari=[
                    "Cümledeki sorunlu sözcüğü önce tek başına yaz.",
                    "O sözcük bitişik mi yazılmalıydı, ayrı mı? Kılavuz ne diyor?",
                ],
                puan=18,
            ),
            metin_adimi(
                soru=("\"{}\" ifadesinin doğru yazımı nedir? "
                      "(yalnızca düzeltilmiş hâlini yaz)").format(odak["yanlis"]),
                cevap=[odak["dogru"]],
                aciklama="Doğrusu: \"{}\". {}".format(odak["dogru"], odak["neden"]),
                ipuclari=["Kılavuzdaki ilgili maddeyi bulup birebir uygula."],
                puan=16,
            ),
            yorum_adimi(
                soru="Arşiv sorumlusu neden kuralın da yazılmasını istiyor?",
                dogru="Kuralı öğrenen kişi benzer hataları da düzeltir.",
                yanlislar={
                    "Raporun daha uzun görünmesi için.":
                        "Kural notunu süs saydın. Not, mektubu uzatmak için "
                        "değil, aynı hatanın bir daha yazılmaması için "
                        "isteniyor; uzunluk bir yazının değeri değildir.",
                    "Merkez, düzeltme sayısına göre puan verdiği için.":
                        "Amacı sayı biriktirmek sandın. Tek sözcüğü "
                        "düzeltmek yalnızca o mektubu kurtarır; kuralı "
                        "yazmak sonraki mektupları da kurtarır.",
                    "Mektubu yazan kişiyi cezalandırmak için.":
                        "Kuralı yazmayı suçlama olarak okudun. Arşiv "
                        "sorumlusunun notu cezadan değil tekrardan söz "
                        "ediyor: \"aynı mektup gelecek ay aynı hatayla yine "
                        "gelir.\"",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir yazım hatasını düzeltmek o metni kurtarır; kuralı öğretmek "
                    "ise bütün metinleri kurtarır. Bu görevin \"hangi kural\" adımı "
                    "da bu yüzden var: doğru yazımı bilmek yetmez, neden doğru "
                    "olduğunu bilmek gerekir."
                ),
                puan=10,
            ),
        ],
        kapanis=(
            "Mektup düzeltildi ve kenarına kural notu düşüldü. {} ertesi hafta "
            "yazdığı yazıda aynı hatayı yapmadı."
        ).format(mektup["yazan"]),
        odul={"itibar": 8, "erzak": 2},
    )


# ==========================================================================
# İLKOKUL
# ==========================================================================

@bulmaca(ders="turkce", konu="buyuk_harf", kademeler=(1, 6))
def buyuk_harf_nokta(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Cümle başı, özel ad ve nokta: ilkokul düzeyi temel yazım."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0].split()[-1]
    hatali = [
        "üsse yeni bir öğretmen geldi.",
        "{} dün ankara'dan döndü".format(kisi.lower()),
        "bizim köpeğimizin adı karabaş.",
    ]
    dogru = [
        "Sabah kar yağmaya başladı.",
        "Kütüphaneye üç yeni kitap geldi.",
        "Yemekhane saat birde açılıyor.",
    ]
    secenekler, dogru_indeksler = coklu_siklar(rastgele, hatali, dogru)

    return Bulmaca(
        kod="tur-buyuk-harf",
        ders="turkce",
        baslik="Panodaki Duyurular",
        kademe=kademe,
        konu="buyuk_harf",
        kazanim="Cümle başında ve özel adlarda büyük harf; cümle sonunda nokta.",
        dikkat=5,
        brifing=(
            "Üssün panosuna asılacak duyurular yazılmış. Ama yazan kişi acele "
            "etmiş.\n\n"
            "Bazı cümleler küçük harfle başlamış, bazılarında isimler küçük "
            "yazılmış, bir tanesinde de nokta unutulmuş.\n\n"
            "Pano herkesin gördüğü yer; oraya hatalı yazı asılmaz. Hangi "
            "duyuruların düzeltilmesi gerektiğini bulman lazım."
        ),
        kanitlar=[
            Kanit("Yazım kuralı - 1",
                  "Her cümle BÜYÜK harfle başlar.", bedel=1, kritik=True),
            Kanit("Yazım kuralı - 2",
                  "Kişi adları, yer adları ve hayvanlara verilen adlar özel "
                  "addır; büyük harfle başlar: Ayşe, Ankara, Karabaş.",
                  bedel=1, kritik=True),
            Kanit("Yazım kuralı - 3",
                  "Tamamlanmış her cümlenin sonuna nokta konur.",
                  bedel=1, kritik=True),
            Kanit("Pano yönergesi",
                  "\"Panoya asılan yazılar üssün yüzüdür. Hatalı yazı asılmaz.\"",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir sözcüğün büyük harfle başlaması gerekip gerekmediğini ne belirler?",
                dogru="Cümle başında olması ya da özel ad olması.",
                yanlislar={
                    "Sözcüğün uzun olması.":
                        "Harf sayısını ölçüt saydın. \"Kütüphaneye\" uzundur "
                        "ama küçük yazılır; \"Ay\" kısacıktır ama bir gök "
                        "cisminin adı olduğunda büyük yazılır.",
                    "Sözcüğün cümlede önemli olması; önemli sözcük büyük yazılır.":
                        "Önemi ölçüt saydın. Hangi sözcüğün önemli olduğu "
                        "okuyana göre değişir; büyük harf ise değişmeyen iki "
                        "duruma bağlıdır.",
                    "Sözcüğün adla ilgili olması; bütün adlar büyük yazılır.":
                        "Tür adı ile özel adı karıştırdın. \"köpek\" de bir "
                        "addır ama bütün köpekleri anlatır, küçük yazılır; "
                        "büyük yazılan, tek bir köpeğe verilen addır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki durum vardır: cümle başı ve özel ad. \"kitap\", \"köpek\", "
                    "\"şehir\" gibi tür adları küçük yazılır; ama o köpeğin adı "
                    "\"Karabaş\" ise, o şehrin adı \"Ankara\" ise büyük yazılır. "
                    "Yani önemli olan sözcüğün türü değil, tek bir varlığı adıyla "
                    "gösterip göstermediğidir."
                ),
                ipuclari=[
                    "\"köpek\" ile \"Karabaş\" arasındaki fark ne?",
                    "Cümle nerede başlıyor?",
                ],
                puan=16,
            ),
            coklu_adimi(
                soru="Hangi duyuruların düzeltilmesi gerekiyor? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Düzeltilmesi gerekenler:\n"
                    "- \"üsse yeni bir öğretmen geldi.\" -> cümle küçük harfle başlamış.\n"
                    "- \"{} dün ankara'dan döndü\" -> hem kişi ve yer adı küçük "
                    "yazılmış hem de nokta unutulmuş.\n"
                    "- \"bizim köpeğimizin adı karabaş.\" -> cümle başı küçük, "
                    "hayvanın özel adı küçük yazılmış.\n"
                    "Diğer üç duyuruda hata yoktur."
                ).format(kisi.lower()),
                ipuclari=[
                    "Her cümlenin ilk harfine tek tek bak.",
                    "Sonra adlara bak: kişi, yer, hayvan adı var mı?",
                    "En son noktaları say.",
                ],
                puan=18,
            ),
            metin_adimi(
                soru="\"karabaş\" sözcüğünün doğru yazımı nedir?",
                cevap=["Karabaş"],
                aciklama=(
                    "Bir hayvana verilen ad özel addır ve büyük harfle başlar: "
                    "\"Karabaş\". Ama \"köpek\" sözcüğü tür adıdır, küçük yazılır."
                ),
                ipuclari=["Bu, bir köpeğin kendi adı. Özel ad mı, tür adı mı?"],
                puan=12,
            ),
        ],
        kapanis="Duyurular düzeltilip panoya asıldı.",
        odul={"itibar": 4},
    )


# ==========================================================================
# YAZIM KURALLARI
# ==========================================================================

@bulmaca(ders="turkce", konu="de_da_ki_mi", kademeler=(4, 12))
def de_da_ayrimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bağlaç mı hâl eki mi: çıkarma testi."""
    baglac_ornekleri = [
        "Komutan da raporu okudu.",
        "Sen de gel, birlikte gidelim.",
        "Bu işi ben de yapabilirim.",
    ]
    ek_ornekleri = [
        "Malzemeler depoda duruyor.",
        "Ölçüm defterde kayıtlı.",
        "Nöbetçi kulede bekliyor.",
    ]
    baglaclar = rastgele.sample(baglac_ornekleri, 2)
    ekler = rastgele.sample(ek_ornekleri, 2)
    secenekler, dogru_indeksler = coklu_siklar(rastgele, baglaclar, ekler)

    return Bulmaca(
        kod="tur-de-da",
        ders="turkce",
        baslik="Ayrı mı, Bitişik mi?",
        kademe=kademe,
        konu="de_da_ki_mi",
        kazanim="Bağlaç olan de/da ile bulunma hâli ekini ayırt etme.",
        dikkat=5,
        brifing=(
            "Merkeze gidecek raporda \"de/da\" yazımı sürekli karışıyor. Kâtip "
            "\"kulağıma göre yazıyorum\" diyor; ama kulak burada yanıltıyor, "
            "çünkü ikisi de aynı okunuyor.\n\n"
            "Arşiv sorumlusu bir yöntem istiyor: kulağa değil, kurala dayanan "
            "ve her cümlede işleyen bir yöntem.\n\n"
            "Önce yöntemi bulup sonra cümleleri ayırman gerekiyor."
        ),
        kanitlar=[
            Kanit("Yazım kılavuzu",
                  "Bağlaç olan \"de/da\": AYRI yazılır. \"Ayrıca, aynı zamanda\" "
                  "anlamı katar.\n"
                  "Bulunma hâli eki \"-de/-da/-te/-ta\": BİTİŞİK yazılır. "
                  "\"nerede\" sorusuna cevap verir.",
                  bedel=2, kritik=True),
            Kanit("Çıkarma testi",
                  "\"de/da\" cümleden çıkarıldığında cümle anlamlı kalıyorsa "
                  "BAĞLAÇTIR, ayrı yazılır. Çıkarılınca cümle bozuluyorsa EKTİR, "
                  "bitişik yazılır.", bedel=2, kritik=True),
            Kanit("Sertleşme kuralı",
                  "Bağlaç olan \"de/da\" hiçbir zaman \"te/ta\" olmaz. "
                  "\"kitapta\", \"sokakta\" gibi yazımlar bu yüzden hep ektir.",
                  bedel=2, kritik=True),
            Kanit("Kâtibin notu",
                  "\"Ben okuyunca ikisi de aynı geliyor, bu yüzden karıştırıyorum.\"",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="\"de/da\"nın ayrı mı bitişik mi yazılacağını hangi yöntem belirler?",
                dogru=("Çıkarma testi: cümle bozulmuyorsa bağlaçtır (ayrı), "
                       "bozuluyorsa ektir (bitişik)."),
                yanlislar={
                    ("Sözcüğün uzunluğu: kısa sözcüklerden sonra ayrı, uzun "
                     "sözcüklerden sonra bitişik yazılır."):
                        "Harf sayısını ölçüt saydın. \"Sen de gel\" ile "
                        "\"defterde kayıtlı\" örneklerinde önceki sözcükler "
                        "benzer uzunlukta ama yazımları farklı; belirleyen "
                        "uzunluk değil, \"de/da\"nın cümledeki görevi.",
                    "Okunuşu: vurgulu okunuyorsa ayrı yazılır.":
                        "Kulağa güvendin; kâtibin düştüğü tuzak tam olarak "
                        "bu. Bağlaç da ek de aynı okunur, bu yüzden okunuş "
                        "bir ayırt etme ölçütü olamaz.",
                    "Cümledeki yeri: cümle sonundaysa bitişik, ortadaysa ayrı yazılır.":
                        "Yazımı konuma bağladın. \"Birlikte gidelim, sen de "
                        "gel\" cümlesinde olduğu gibi aynı \"de\" cümlenin "
                        "sonuna da gelebilir; yeri değişince görevi "
                        "değişmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çıkarma testi işe yarar çünkü bağlaç cümleye \"ayrıca\" anlamı "
                    "KATAR; çıkarılırsa anlam daralır ama cümle ayakta kalır. "
                    "Hâl eki ise sözcüğün cümledeki görevini belirler; çıkarılırsa "
                    "cümle bozulur. Okunuş ölçüt olamaz: ikisi de aynı okunur."
                ),
                ipuclari=[
                    "\"Komutan da raporu okudu\" cümlesinden \"da\"yı çıkar. Cümle ayakta mı?",
                    "\"Malzemeler depoda duruyor\" cümlesinden \"da\"yı çıkar. Ne oluyor?",
                ],
                puan=18,
            ),
            coklu_adimi(
                soru="Hangi cümlelerde \"de/da\" AYRI yazılmalıdır? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Ayrı yazılanlar bağlaçtır; çıkarınca cümle ayakta kalır "
                    "(\"Komutan raporu okudu\" gibi). Bitişik yazılanlar bulunma "
                    "hâli ekidir; çıkarınca cümle bozulur (\"Malzemeler duruyor\" "
                    "eksik kalır: nerede?)."
                ),
                ipuclari=[
                    "Her cümlede \"de/da\"yı sil ve cümleyi yeniden oku.",
                    "\"Nerede?\" sorusuna cevap veriyorsa ektir.",
                ],
                puan=18,
            ),
            metin_adimi(
                soru="\"Raporu bende yazdım.\" cümlesinde \"bende\" ifadesinin "
                     "doğru yazımı nedir?",
                cevap=["ben de"],
                aciklama=(
                    "Cümlede anlatılmak istenen \"ben de yazdım\", yani \"ayrıca ben\". "
                    "Bu bir bağlaçtır, ayrı yazılır. Bitişik yazılan \"bende\" "
                    "\"bende kaldı\" örneğindeki gibi \"bende bulunuyor\" anlamı verir."
                ),
                ipuclari=["Çıkarma testini uygula: \"Raporu yazdım\" anlamlı mı?"],
                puan=14,
            ),
        ],
        kapanis="Rapor \"de/da\" yazımı düzeltilerek merkeze gönderildi.",
        odul={"itibar": 6},
    )


@bulmaca(ders="turkce", konu="de_da_ki_mi", kademeler=(3, 10))
def soru_eki_yazimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Soru eki her zaman ayrı; ekler ona bitişir."""
    hatali = [
        "Sayım bittimi öğrenmek istiyorum.",
        "Yarın gelecekmisin?",
        "Depo kapısı kilitlimi?",
    ]
    dogru = [
        "Raporu okudunuz mu?",
        "Yola çıkacak mısın?",
        "Bu liste eksik mi acaba?",
    ]
    secenekler, dogru_indeksler = coklu_siklar(rastgele, hatali, dogru)

    return Bulmaca(
        kod="tur-soru-eki",
        ders="turkce",
        baslik="Telsiz Kayıtları",
        kademe=kademe,
        konu="de_da_ki_mi",
        kazanim="Soru ekinin ayrı yazılması; soru ekine gelen eklerin bitişik yazılması.",
        dikkat=5,
        brifing=(
            "Telsiz konuşmaları yazıya geçirilirken soru cümlelerinde bir "
            "karışıklık olmuş.\n\n"
            "Yazıya geçiren kişi soru ekini bazen bitişik, bazen ayrı yazmış. "
            "Kendi de fark etmiş: \"konuşurken bitişik söylüyoruz, o yüzden "
            "bitişik yazdım\" diyor.\n\n"
            "Kayıtlar arşive girmeden düzeltilmesi gerekiyor."
        ),
        kanitlar=[
            Kanit("Yazım kılavuzu",
                  "Soru eki \"mi / mı / mu / mü\" HER ZAMAN ayrı yazılır: "
                  "\"geldi mi\", \"okudun mu\", \"güzel mi\".",
                  bedel=2, kritik=True),
            Kanit("Ek kuralı",
                  "Soru ekinden SONRA gelen ekler soru ekine BİTİŞİK yazılır: "
                  "\"gelecek misin\", \"okudun mu\", \"doğru mudur\".\n"
                  "Yani ayrılan yer sözcük ile soru eki arasıdır.",
                  bedel=2, kritik=True),
            Kanit("Söyleyiş notu",
                  "Konuşurken soru eki önceki sözcüğe yapışık söylenir; ama "
                  "yazımda ayrı yazılır. Söyleyiş yazımın ölçütü değildir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Soru ekinin yazımında kural nedir?",
                dogru="Önceki sözcükten ayrı, sonraki eklerle bitişik yazılır.",
                yanlislar={
                    "Her zaman önceki sözcüğe bitişik yazılır, çünkü öyle duyulur.":
                        "Söyleyişi olduğu gibi yazıya taşıdın. Konuşurken "
                        "soru eki önceki sözcüğe yapışık duyulur; ama "
                        "Türkçede söyleyiş ile yazım pek çok yerde ayrılır, "
                        "kulak burada ölçüt değil.",
                    ("Cümle sonundaysa ayrı, cümlenin ortasındaysa önceki "
                     "sözcüğe bitişik yazılır."):
                        "Yazımı ekin cümledeki yerine bağladın. Aynı soru "
                        "eki cümlenin ortasında da sonunda da geçer ve iki "
                        "yerde de aynı biçimde yazılır; kural yer "
                        "değiştirdiği için değişmez.",
                    "Söyleyişte nasıl duyuluyorsa öyle yazılır.":
                        "Yazımı kulağa bağladın. Kayıtları tutan kişi de tam "
                        "bunu yaptı ve hata buradan çıktı; kılavuzun "
                        "söyleyiş notu bunun için var.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Soru eki ayrı bir sözcük gibi yazılır ama ek gibi çekimlenir: "
                    "\"gelecek misin\" örneğinde \"-sin\" soru ekine bitişmiştir. "
                    "Söyleyişte bitişik duyulması yazımı değiştirmez; Türkçede pek "
                    "çok yerde söyleyiş ile yazım ayrılır."
                ),
                ipuclari=[
                    "\"Gelecek misin\" ifadesinde boşluk nereye giriyor?",
                    "Soru ekinden sonraki \"-sin\" nereye yapışıyor?",
                ],
                puan=16,
            ),
            coklu_adimi(
                soru="Hangi kayıtlarda soru eki YANLIŞ yazılmış? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Yanlış yazılanlar ve doğruları:\n"
                    "- \"bittimi\" -> \"bitti mi\"\n"
                    "- \"gelecekmisin\" -> \"gelecek misin\"\n"
                    "- \"kilitlimi\" -> \"kilitli mi\"\n"
                    "Doğru yazılanlarda soru eki önceki sözcükten ayrılmış, "
                    "kendi eklerini ise bitişik almıştır."
                ),
                ipuclari=["Her cümlede soru ekini bul ve önünde boşluk var mı diye bak."],
                puan=18,
            ),
            metin_adimi(
                soru="\"gelecekmisin\" ifadesinin doğru yazımı nedir?",
                cevap=["gelecek misin"],
                aciklama=(
                    "Doğrusu \"gelecek misin\". Sözcük ile soru eki arasına boşluk "
                    "girer; \"-sin\" eki ise soru ekine bitişik kalır."
                ),
                ipuclari=["Boşluğu doğru yere koy: sözcük | soru eki + ek"],
                puan=14,
            ),
        ],
        kapanis="Telsiz kayıtları düzeltilip arşive kondu.",
        odul={"itibar": 5},
    )


@bulmaca(ders="turkce", konu="kesme_isareti", kademeler=(6, 13))
def kesme_isareti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Özel ada çekim eki kesmeyle; yapım eki ve kurum adları kesmesiz."""
    hatali = [
        "Yazı Türk Dil Kurumu'ndan geldi.",
        "Belge Millî Eğitim Bakanlığı'na gönderildi.",
        "Meridyen Üssünde bir toplantı yapıldı.",
    ]
    dogru = [
        "Ekip Ankara'ya sabah hareket etti.",
        "Rapor Ahmet'in masasında duruyor.",
        "Ölçümler Türkiye'nin doğusunda yapıldı.",
    ]
    secenekler, dogru_indeksler = coklu_siklar(rastgele, hatali, dogru)

    return Bulmaca(
        kod="tur-kesme-isareti",
        ders="turkce",
        baslik="Kesme Kararı",
        kademe=kademe,
        konu="kesme_isareti",
        kazanim="Kesme işaretinin kullanımı; özel ad, yapım eki ve kurum adı ayrımı.",
        dikkat=6,
        brifing=(
            "Merkeze gidecek üst yazıda kesme işaretleri karışmış. Yazıyı "
            "hazırlayan \"özel ad görünce kesme koydum\" demiş.\n\n"
            "Ama arşiv sorumlusu itiraz ediyor: \"Kurum adlarına gelen ekler "
            "kesmeyle ayrılmaz; sen hepsine koymuşsun. Bir yerde de koyman "
            "gerekirken koymamışsın.\"\n\n"
            "Kuralı bilmeden düzeltilirse yeni hatalar çıkar. Önce kuralı "
            "netleştirmemiz gerekiyor."
        ),
        kanitlar=[
            Kanit("Yazım kılavuzu - kesme",
                  "Özel adlara gelen ÇEKİM ekleri kesme işaretiyle ayrılır: "
                  "Ankara'ya, Ahmet'in, Türkiye'de, Meridyen Üssü'nde.",
                  bedel=2, kritik=True),
            Kanit("Yazım kılavuzu - istisna 1",
                  "Özel adlara gelen YAPIM ekleri ve onlardan sonra gelen çekim "
                  "ekleri kesmeyle AYRILMAZ: Türkçe, Ankaralı, Türkiyeli, "
                  "Avrupalılaşmak.", bedel=2, kritik=True),
            Kanit("Yazım kılavuzu - istisna 2",
                  "Kurum, kuruluş ve kurul adlarına gelen ekler kesmeyle "
                  "AYRILMAZ: Türk Dil Kurumundan, Millî Eğitim Bakanlığına, "
                  "Türkiye Büyük Millet Meclisine.", bedel=2, kritik=True),
            Kanit("Üst yazı taslağı",
                  "Yazıda hem kurum adları hem kişi ve yer adları geçiyor; "
                  "hepsine aynı işlem uygulanmış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kesme işareti konup konmayacağını ne belirler?",
                dogru=("Ekin ve adın türü: özel adın çekim eki ayrılır; yapım "
                       "eki ve kurum adının ekleri ayrılmaz."),
                yanlislar={
                    ("Sözcüğün büyük harfle başlayıp başlamadığı; büyük harfle "
                     "başlayan her ada gelen ek kesmeyle ayrılır."):
                        "Yazıyı hazırlayan kişinin hatasını tekrarladın. "
                        "Kurum adları da büyük harfle başlar; kılavuzun "
                        "ikinci istisnası tam da onları bu işaretin dışında "
                        "tutuyor.",
                    "Sözcüğün uzunluğu; uzun adlarda kesme konur.":
                        "Harf sayısını ölçüt saydın. \"Ali'nin\" kısacıktır "
                        "ve kesme alır; sayfa dolduran bir kurum adı almaz. "
                        "Uzunluğun ekin türüyle ilgisi yok.",
                    "Cümledeki yeri; cümle başındaki adlarda kesme konur.":
                        "Kararı konuma bağladın. Aynı ad cümlenin neresinde "
                        "durursa dursun aynı eki aynı biçimde alır; kesmeyi "
                        "belirleyen yer değil, ekin ve adın türü.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Büyük harfle başlıyorsa kesme koy\" kuralı yanlıştır ve tam "
                    "da bu yazıdaki hatayı üretir: kurum adları da büyük harfle "
                    "başlar ama ekleri ayrılmaz. Karar iki soruya bağlı: bu bir "
                    "kurum adı mı, ve gelen ek çekim eki mi yapım eki mi?"
                ),
                ipuclari=[
                    "\"Türk Dil Kurumu\" bir kurum adı mı, yer adı mı?",
                    "\"Türkçe\" sözcüğünde neden kesme yok?",
                ],
                puan=20,
            ),
            coklu_adimi(
                soru="Hangi cümlelerde kesme işareti YANLIŞ kullanılmış? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Yanlışlar:\n"
                    "- \"Türk Dil Kurumu'ndan\" -> kurum adı, doğrusu "
                    "\"Türk Dil Kurumundan\"\n"
                    "- \"Millî Eğitim Bakanlığı'na\" -> kurum adı, doğrusu "
                    "\"Millî Eğitim Bakanlığına\"\n"
                    "- \"Meridyen Üssünde\" -> özel ad + çekim eki, doğrusu "
                    "\"Meridyen Üssü'nde\"\n"
                    "Diğerlerinde kesme doğru kullanılmıştır."
                ),
                ipuclari=[
                    "Önce kurum adlarını işaretle: onlarda kesme OLMAMALI.",
                    "Sonra kişi ve yer adlarına bak: onlarda kesme OLMALI.",
                ],
                puan=20,
            ),
            metin_adimi(
                soru="\"Türk Dil Kurumu'ndan\" ifadesinin doğru yazımı nedir?",
                cevap=["Türk Dil Kurumundan"],
                aciklama=(
                    "Kurum adlarına gelen ekler kesmeyle ayrılmaz: "
                    "\"Türk Dil Kurumundan\". Aynı kural \"Millî Eğitim "
                    "Bakanlığına\", \"Türkiye Büyük Millet Meclisine\" için de geçerlidir."
                ),
                ipuclari=["Kurum adlarında kesme kullanılmaz; işareti kaldır."],
                puan=16,
            ),
        ],
        kapanis="Üst yazı düzeltildi; kesme işaretleri kurala göre yeniden konuldu.",
        odul={"itibar": 8},
    )


@bulmaca(ders="turkce", konu="birlesik_yazim", kademeler=(3, 10))
def birlesik_yazim(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bitişik yazılanlar ile ayrı yazılanlar karışıyor."""
    yanlis_yazimlar = [
        ("hiç bir", "hiçbir"),
        ("bir kaç", "birkaç"),
        ("herşey", "her şey"),
        ("birşey", "bir şey"),
        ("bir çok", "birçok"),
    ]
    secilen = rastgele.sample(yanlis_yazimlar, 3)
    odak = secilen[0]
    secenekler, dogru_indeksler = coklu_siklar(
        rastgele,
        [y for y, _ in secilen],
        rastgele.sample(["hiçbiri", "herkes", "bir şey", "birtakım", "hiç kimse"], 3),
    )

    return Bulmaca(
        kod="tur-birlesik-yazim",
        ders="turkce",
        baslik="Yapışık Sözcükler",
        kademe=kademe,
        konu="birlesik_yazim",
        kazanim="Kalıplaşmış birleşik sözcüklerin yazımı; bitişik-ayrı ayrımı.",
        dikkat=5,
        brifing=(
            "Personelin yazdığı dilekçelerde aynı hatalar tekrar ediyor: bazı "
            "sözcükler bitişik yazılması gerekirken ayrı, bazıları ayrı "
            "yazılması gerekirken bitişik yazılmış.\n\n"
            "Kâtip \"kulağa göre\" yazdığını söylüyor. Ama bu grupta kulak "
            "yardımcı olmuyor: hepsi aynı akıcılıkta söyleniyor.\n\n"
            "Panoya asılacak bir düzeltme listesi hazırlaman isteniyor."
        ),
        kanitlar=[
            Kanit("Yazım kılavuzu - bitişik yazılanlar",
                  "hiçbir, hiçbiri, birkaç, birçok, birtakım, herkes, biraz",
                  bedel=2, kritik=True),
            Kanit("Yazım kılavuzu - ayrı yazılanlar",
                  "her şey, bir şey, hiç kimse, pek çok, her biri",
                  bedel=2, kritik=True),
            Kanit("Arşiv notu",
                  "\"Bu sözcüklerde kural ezberlenir; söyleyişten çıkarılamaz. "
                  "Kılavuz listesi bu yüzden panoya asılıyor.\"",
                  bedel=1, kritik=True),
            Kanit("Dilekçe örnekleri",
                  "Aynı hata beş ayrı dilekçede tekrarlanmış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu sözcüklerin bitişik mi ayrı mı yazılacağını ne belirler?",
                dogru="Kalıplaşma: kalıplaşmışlar bitişik, kalıplaşmamışlar ayrı yazılır.",
                yanlislar={
                    "Söyleyişte duraklama olup olmaması; duraksanıyorsa ayrı yazılır.":
                        "Kulağı ölçüt aldın; kâtibin düştüğü tuzak bu. "
                        "Kılavuzun iki listesindeki sözcükler aynı "
                        "akıcılıkta söylenir, buna rağmen farklı yazılırlar.",
                    "Sözcüklerin toplam harf sayısı.":
                        "Harf saydın. Bu gruptaki sözcükler neredeyse aynı "
                        "uzunlukta ama biri bitişik biri ayrı yazılıyor; "
                        "uzunluk kalıplaşma hakkında bir şey söylemez.",
                    ("Cümledeki görevleri: cümlenin öznesiyse bitişik, "
                     "nesnesiyse ayrı yazılır."):
                        "Yazımı cümledeki göreve bağladın. Bu sözcükler "
                        "cümlede özne de nesne de olabilir ve yazımları "
                        "değişmez; kalıplaşma sözcüğün kendi özelliğidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"hiçbir\" ile \"her şey\" aynı yapıda görünür ama biri "
                    "kalıplaşarak tek sözcük olmuş, diğeri olmamıştır. Bu ayrım "
                    "söyleyişten çıkarılamaz; kılavuzdan öğrenilir. Türkçenin bu "
                    "grubunda ezber gerekli olan az sayıda yerden biridir."
                ),
                ipuclari=[
                    "İki listeyi yan yana koy: hangileri bitişik, hangileri ayrı?",
                    "\"her şey\" ile \"hiçbir\" aynı listede mi?",
                ],
                puan=16,
            ),
            coklu_adimi(
                soru="Aşağıdaki yazımlardan hangileri YANLIŞTIR? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Yanlış yazımlar ve doğruları:\n" + "\n".join(
                        "- \"{}\" -> \"{}\"".format(y, d) for y, d in secilen
                    ) + "\nDiğerleri kılavuzdaki doğru biçimlerdir."
                ),
                ipuclari=["Her yazımı kılavuzdaki iki listeyle karşılaştır."],
                puan=18,
            ),
            metin_adimi(
                soru="\"{}\" ifadesinin doğru yazımı nedir?".format(odak[0]),
                cevap=[odak[1]],
                aciklama="Doğrusu: \"{}\". Kılavuz listesinde bu biçimde geçer.".format(
                    odak[1]),
                ipuclari=["Kılavuzun iki listesinden hangisinde geçiyor?"],
                puan=14,
            ),
        ],
        kapanis="Düzeltme listesi panoya asıldı; dilekçelerdeki hatalar azaldı.",
        odul={"itibar": 5},
    )


# ==========================================================================
# NOKTALAMA, ANLATIM, ÜSLUP
# ==========================================================================

@bulmaca(ders="turkce", konu="noktalama", kademeler=(5, 12))
def virgul_anlami(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Virgülün yeri anlamı değiştiriyor."""
    return Bulmaca(
        kod="tur-virgul",
        ders="turkce",
        baslik="Virgülün Yeri",
        kademe=kademe,
        konu="noktalama",
        kazanim="Virgülün anlam ayırt edici işlevi; özneden sonra virgül kullanımı.",
        dikkat=6,
        brifing=(
            "Merkezden gelen emirde tek bir cümle var ve üste iki kişi bu "
            "cümleyi iki ayrı biçimde anlamış:\n\n"
            "  \"Genç nöbetçiyi uyardı.\"\n\n"
            "Biri \"genç olan kişi, nöbetçiyi uyardı\" diye anlıyor; diğeri "
            "\"birisi, genç nöbetçiyi uyardı\" diye.\n\n"
            "Merkeze bunun hangisi olduğunu soramayız; ama cümlenin nasıl "
            "yazılması gerektiğini yazabiliriz. Emir yeniden yazılacak."
        ),
        kanitlar=[
            Kanit("Yazım kılavuzu - virgül",
                  "\"Anlam karışıklığını önlemek için özneden sonra virgül "
                  "konabilir: Genç, nöbetçiyi uyardı.\"", bedel=2, kritik=True),
            Kanit("Anlam çözümlemesi",
                  "Virgülsüz hâlde \"genç\" sözcüğü hem özne (genç olan kişi) hem "
                  "de sıfat (genç nöbetçi) olarak okunabiliyor.",
                  bedel=2, kritik=True),
            Kanit("Merkez yazışma kuralı",
                  "\"Emir cümleleri tek anlama gelecek biçimde yazılır. İki türlü "
                  "okunabilen emir geçersiz sayılır.\"", bedel=2, kritik=True),
            Kanit("Nöbet çizelgesi",
                  "O gece iki nöbetçi görevliydi; ikisi de genç sayılır. "
                  "Çizelgeden anlam çıkmıyor.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu cümlede karışıklık neden doğuyor?",
                dogru="\"Genç\" hem özne hem sıfat olarak okunabildiği için.",
                yanlislar={
                    "Cümlede yazım hatası olduğu için.":
                        "Yazım hatası aradın; oysa cümledeki her sözcük "
                        "doğru yazılmış. Sorun harflerde değil, sözcüklerin "
                        "hangi öbeğe ait olduğunun belli olmamasında.",
                    "Cümle çok kısa olduğu için; kısa cümlede bağlam eksik kalır.":
                        "Kısalığı sebep saydın. Uzun bir cümle de aynı "
                        "ikiliği taşıyabilir; belirleyici olan sözcük sayısı "
                        "değil, bir sözcüğün iki ayrı göreve birden uyması.",
                    "\"Uyardı\" fiili birden çok anlama geldiği için.":
                        "Belirsizliği yükleme yükledin. \"Uyarmak\" bu "
                        "cümlede tek anlamda kullanılıyor; iki farklı okuma "
                        "fiilin anlamından değil, sözcüklerin gruplanma "
                        "biçiminden doğuyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sorun sözcüklerde değil, sözcüklerin nasıl gruplandığında. "
                    "\"Genç\" tek başına özne olabilir; \"genç nöbetçi\" olarak da "
                    "bir tamlama kurabilir. Yazıda bu iki okumayı ayıran şey "
                    "noktalamadır - konuşmada ise tonlama ve duraklama ayırır."
                ),
                ipuclari=[
                    "Cümleyi iki farklı biçimde okumayı dene ve nerede duraklıyorsun bak.",
                    "\"Genç\" kimi niteliyor: kendisi mi bir kişi, yoksa nöbetçiyi mi niteliyor?",
                ],
                puan=18,
            ),
            secim_adimi(
                soru="\"Genç olan kişi, nöbetçiyi uyardı\" anlamı için cümle nasıl yazılmalı?",
                dogru="Genç, nöbetçiyi uyardı.",
                yanlislar={
                    "Genç nöbetçiyi, uyardı.":
                        "Virgülü nesne ile yüklem arasına koydun. Oradaki "
                        "virgül \"genç\" ile \"nöbetçiyi\" arasındaki bağı "
                        "kesmez; tamlama olduğu gibi duruyor, üstelik cümle "
                        "yükleminden de kopmuş oluyor.",
                    "Genç nöbetçiyi uyardı!":
                        "Ünlem tonu değiştirir, yapıyı değil. Cümle hâlâ iki "
                        "türlü okunabiliyor; ünlem hangi okumanın "
                        "kastedildiğini söylemiyor.",
                    "Genç; nöbetçiyi uyardı.":
                        "Noktalı virgül, birbirine bağlı iki ayrı cümleyi "
                        "ayırmak içindir. Burada iki cümle yok, tek cümle "
                        "var; bu işaret o cümlenin içini bölmek için "
                        "kullanılmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Özneden sonra konan virgül, \"genç\" sözcüğünün kendi başına "
                    "özne olduğunu gösterir ve sıfat okumasını keser. Nesneden sonra "
                    "virgül koymak (\"nöbetçiyi,\") bu ayrımı yapmaz; ünlem ise "
                    "anlamı değil tonu değiştirir."
                ),
                ipuclari=[
                    "Virgül hangi iki sözcüğün birbirine bağlanmasını engellemeli?",
                    "Özneyi ayırmak istiyorsan virgül nereye girer?",
                ],
                puan=16,
            ),
            yorum_adimi(
                soru="Bu durum yazışmalar için ne anlama geliyor?",
                dogru="Noktalama anlamın parçasıdır, tek virgül emri değiştirebilir.",
                yanlislar={
                    "Noktalama yalnızca okumayı kolaylaştırır, anlamı etkilemez.":
                        "Noktalamayı bir kolaylık saydın. Oysa bu görevin "
                        "tamamı tek bir virgülün emri iki ayrı anlama "
                        "böldüğünü gösteriyor; burada değişen okuma hızı "
                        "değil, kimin ne yaptığı.",
                    "Emirler kısa yazılırsa noktalamaya gerek kalmaz.":
                        "Kısaltmayı çözüm saydın. Karışıklığa yol açan cümle "
                        "zaten üç sözcüklük; kısalık belirsizliği azaltmıyor, "
                        "çoğu zaman artırıyor.",
                    "Konuşarak iletilen emirlerde de aynı sorun çıkar, çözüm yoktur.":
                        "Konuşmada bu ayrımı tonlama ve duraklama yapar; "
                        "sorun ancak yazıya geçerken doğar. Yani durum "
                        "çözümsüz değil: yazıda tonlamanın yerini noktalama "
                        "alır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Konuşmada tonlama ve duraklama anlamı ayırır; yazıda bu işi "
                    "noktalama yapar. Bu yüzden resmî yazışmalarda noktalama, "
                    "yazının süsü değil taşıyıcısıdır. İki türlü okunabilen bir "
                    "emir, uygulanamayan bir emirdir."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Emir \"Genç, nöbetçiyi uyardı.\" biçiminde yeniden yazılıp merkeze "
            "teyit için gönderildi."
        ),
        odul={"itibar": 7},
    )


@bulmaca(ders="turkce", konu="anlatim_bozuklugu", kademeler=(8, 13))
def anlatim_bozuklugu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Gereksiz sözcük ve mantık hatası: rapor cümleleri elden geçecek."""
    bozuk = [
        {
            "cumle": "Ödünç aldığımız bütün aletleri geri iade ettik.",
            "tur": "gereksiz sözcük",
            "dogru": "Ödünç aldığımız bütün aletleri iade ettik.",
            "neden": ("\"İade etmek\" zaten \"geri vermek\" demektir; başına \"geri\" "
                      "eklemek aynı anlamı iki kez söylemektir."),
        },
        {
            "cumle": "Toplantıya yaklaşık otuz beş kişi civarında katıldı.",
            "tur": "gereksiz sözcük",
            "dogru": "Toplantıya yaklaşık otuz beş kişi katıldı.",
            "neden": ("\"Yaklaşık\" ve \"civarında\" aynı işi yapar; ikisini birlikte "
                      "kullanmak gereksizdir."),
        },
        {
            "cumle": "Bu yöntem en ideal çözümdür.",
            "tur": "gereksiz sözcük",
            "dogru": "Bu yöntem ideal çözümdür.",
            "neden": ("\"İdeal\" zaten en üstün derecedir; başına \"en\" getirilmez."),
        },
        {
            "cumle": "Depoda hiçbir eksik yoktu, sadece altı kasa kayıptı.",
            "tur": "mantık hatası",
            "dogru": "Depoda altı kasa eksikti.",
            "neden": ("Cümle önce hiç eksik olmadığını söylüyor, sonra altı kasanın "
                      "kayıp olduğunu; iki bilgi birbiriyle çelişiyor."),
        },
    ]
    secilen = rastgele.sample(bozuk, 3)
    odak = secilen[0]
    # Düzeltme adımının teşhisi ve ipucu, sorulan cümlenin bozukluk türüne uyar.
    duzeltme_yolu = {
        "gereksiz sözcük": (
            "onun gereksiz sözcüğünü at",
            "Gereksiz olan sözcüğü at; kalan cümle anlamı tam vermeli."),
        "mantık hatası": (
            "birbirini yalanlayan iki bilgiden yanlış olanı çıkar",
            "Cümlenin iki yarısı birbirini tutuyor mu? Yalanlanan bilgiyi çıkar."),
    }
    duzelt_teshis, duzelt_ipucu = duzeltme_yolu[odak["tur"]]
    duzgun = [
        "Sayım sonuçları deftere işlendi.",
        "Ekip, ölçümleri sabah tamamladı.",
        "Rapor bugün merkeze gönderilecek.",
    ]
    secenekler, dogru_indeksler = coklu_siklar(
        rastgele, [b["cumle"] for b in secilen], rastgele.sample(duzgun, 3))

    return Bulmaca(
        kod="tur-anlatim-bozuklugu",
        ders="turkce",
        baslik="Rapor Provası",
        kademe=kademe,
        konu="anlatim_bozuklugu",
        kazanim="Anlatım bozukluklarını tanıma: gereksiz sözcük ve çelişki.",
        dikkat=6,
        brifing=(
            "Altı aylık rapor yazıldı ve masana geldi. Yazımda hata yok, "
            "noktalama düzgün.\n\n"
            "Ama bazı cümleler kulağa doğru gelse de aslında bozuk: kimi aynı "
            "şeyi iki kez söylüyor, kimi kendi içinde çelişiyor.\n\n"
            "Merkeze giden bir raporda böyle cümleler, yazanın konuya "
            "hâkim olmadığı izlenimi verir. Elden geçirmen gerekiyor."
        ),
        kanitlar=[
            Kanit("Yazışma kılavuzu - gereksiz sözcük",
                  "Aynı anlamı taşıyan iki sözcük birlikte kullanılmaz:\n"
                  "\"geri iade etmek\", \"yaklaşık ... civarında\", \"en ideal\", "
                  "\"birlikte beraber\" gibi kullanımlar bozuktur.",
                  bedel=2, kritik=True),
            Kanit("Yazışma kılavuzu - çelişki",
                  "Bir cümle kendi içinde birbirini yalanlayan iki bilgi "
                  "veremez. \"Hiç eksik yok\" ile \"altı kasa kayıp\" aynı cümlede "
                  "duramaz.", bedel=2, kritik=True),
            Kanit("Arşiv sorumlusunun notu",
                  "\"Cümle akıcı diye doğru olmaz. Yüksek sesle okuduğunda kulağa "
                  "hoş gelen bir cümle de bozuk olabilir; ölçüt anlamdır.\"",
                  bedel=1, kritik=True),
            Kanit("Rapor taslağı",
                  "Yazım ve noktalama denetimi yapılmış; bulunan tek sorun "
                  "anlatım düzeyinde.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir cümlenin anlatım bakımından bozuk olduğunu ne gösterir?",
                dogru="Gereksiz anlam tekrarı ya da cümlenin kendi içinde çelişmesi.",
                yanlislar={
                    "Cümlenin uzun olması.":
                        "Uzunluğu ölçüt saydın. Sayfa boyu bir cümle "
                        "kusursuz olabilir, üç sözcüklük bir cümle bozuk "
                        "olabilir; bakılan yer biçim değil anlam.",
                    "Cümlede yabancı kökenli sözcük bulunması.":
                        "Kusuru sözcüğün kökeninde aradın. \"İade\" de "
                        "\"ideal\" de yabancı kökenlidir ve tek başlarına "
                        "hiçbir bozukluk yaratmaz; bozukluk yanlarına aynı "
                        "anlamda ikinci bir sözcük konunca doğuyor.",
                    "Cümlenin edilgen çatıyla kurulmuş olması, çünkü yapan belirsiz kalır.":
                        "Çatıyı kusur saydın. Edilgen çatı resmî yazının "
                        "olağan biçimidir; \"Sayım tamamlandı\" cümlesinde "
                        "bozulan bir şey yok.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Anlatım bozukluğu bir yazım hatası değildir: harfler doğru, "
                    "noktalama yerinde olabilir. Bozukluk anlam düzeyindedir - "
                    "gereksiz tekrar, çelişki, eksik öge ya da yanlış bağlantı. "
                    "Uzunluk ve çatı tek başına bozukluk yaratmaz."
                ),
                ipuclari=[
                    "Cümledeki sözcüklerden birini silsen anlam kaybolur mu?",
                    "Cümlenin ilk yarısı ile ikinci yarısı birbirini tutuyor mu?",
                ],
                puan=20,
            ),
            coklu_adimi(
                soru="Hangi cümlelerde anlatım bozukluğu var? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Bozuk cümleler:\n" + "\n".join(
                        "- \"{}\" ({}): {}".format(b["cumle"], b["tur"], b["neden"])
                        for b in secilen
                    )
                ),
                ipuclari=[
                    "Aynı anlama gelen iki sözcüğün yan yana durduğu yerleri ara.",
                    "Bir cümle önce \"hiç yok\" deyip sonra bir şey sayıyor mu?",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="\"{}\" cümlesi nasıl düzeltilmeli?".format(odak["cumle"]),
                dogru=odak["dogru"],
                yanlislar={
                    b["dogru"]: "Bu, listedeki BAŞKA bir cümlenin düzeltilmiş "
                                "hâli. Sana sorulan cümleye dön ve {}."
                                .format(duzelt_teshis)
                    for b in bozuk if b["dogru"] != odak["dogru"]
                },
                rastgele=rastgele,
                aciklama=odak["neden"] + " Düzeltilmiş hâli: \"" + odak["dogru"] + "\"",
                ipuclari=[duzelt_ipucu],
                puan=16,
            ),
        ],
        kapanis="Rapor elden geçirildi; bozuk cümleler sadeleşti ve merkeze gönderildi.",
        odul={"itibar": 9},
    )


@bulmaca(ders="turkce", konu="uslup", kademeler=(8, 13))
def rapor_uslubu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Resmî yazı ile günlük dil ayrımı; üst makama yazma."""
    gunluk = [
        "Jeneratör yine bozuldu, bir türlü uğraşamadık.",
        "Depoda bir sürü şey var ama sayamadık işte.",
        "Bu iş böyle gitmez, birinin bakması lazım artık.",
    ]
    resmi = [
        "Jeneratörde ikinci kez arıza meydana gelmiştir.",
        "Depo sayımı, personel yetersizliği nedeniyle tamamlanamamıştır.",
        "Konunun ilgili birimce değerlendirilmesi arz olunur.",
    ]
    secenekler, dogru_indeksler = coklu_siklar(rastgele, resmi, gunluk)

    return Bulmaca(
        kod="tur-rapor-uslubu",
        ders="turkce",
        baslik="Üst Makama",
        kademe=kademe,
        konu="uslup",
        kazanim="Metin türüne uygun üslup seçme; resmî yazı dili ile günlük dil ayrımı.",
        dikkat=6,
        brifing=(
            "Merkeze gidecek raporun taslağını nöbetçi kâtip hazırlamış. "
            "Anlattığı olaylar doğru, hiçbir bilgi hatası yok.\n\n"
            "Ama cümleler sohbet eder gibi yazılmış. Komutan taslağı okuyunca "
            "tek bir şey söyledi: \"Bunu bana anlatırken böyle konuşabilirsin. "
            "Merkeze böyle yazamazsın.\"\n\n"
            "Rapora hangi cümlelerin gireceğini seçmen gerekiyor."
        ),
        kanitlar=[
            Kanit("Resmî yazışma kılavuzu",
                  "Resmî yazıda: nesnel anlatım kullanılır, kişisel yakınma ve "
                  "duygu ifadeleri yer almaz, edilgen çatı tercih edilir, "
                  "belirsiz nicelikler (\"bir sürü\", \"bir türlü\") "
                  "kullanılmaz.", bedel=2, kritik=True),
            Kanit("Örnek karşılaştırma",
                  "Günlük: \"Sayamadık işte.\"\n"
                  "Resmî: \"Sayım tamamlanamamıştır.\"\n"
                  "İkisi de aynı olayı anlatır; ikincisi değerlendirme değil, "
                  "durum bildirir.", bedel=2, kritik=True),
            Kanit("Komutanın notu",
                  "\"Merkez raporu okurken bizi tanımıyor. Ne yazdıysak oyuz.\"",
                  bedel=1),
            Kanit("Taslak metin",
                  "Bilgiler doğru; sorun yalnızca üslupta.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir metnin üslubunu ne belirler?",
                dogru=("Kime, hangi amaçla yazıldığı; yani metnin türü ve "
                       "okuyucusu."),
                yanlislar={
                    "Yazarın o günkü ruh hâli.":
                        "Üslubu kişisel bir duruma bağladın. Üslubu belirleyen "
                        "şey yazarın hâli değil, metnin KİME ve NİÇİN "
                        "yazıldığı.",
                    "Metnin uzunluğu; uzun metinler resmî sayılır.":
                        "Uzunluğu ölçüt saydın. Kısa bir dilekçe de resmîdir; "
                        "uzun bir mektup samimi olabilir.",
                    "Konunun ciddi olup olmaması; ciddi konu her zaman resmî yazılır.":
                        "Konuyu belirleyici saydın. Ciddi bir konu yakın bir "
                        "arkadaşa samimi dille de anlatılabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı olay bir arkadaşa mesajla, bir günlüğe, bir habere ve bir "
                    "resmî rapora dört ayrı biçimde yazılır. Doğru üslup, metnin "
                    "kime gittiğine ve ne işe yaradığına göre seçilir. Ciddi bir "
                    "konu bir arkadaşa günlük dille de anlatılabilir; belirleyici "
                    "olan konu değil, iletişim durumudur."
                ),
                ipuclari=[
                    "Bu metin kime gidiyor? Yazan kişiyi tanıyor mu?",
                    "Aynı bilgiyi arkadaşına anlatsan aynı cümleleri kurar mıydın?",
                ],
                puan=18,
            ),
            coklu_adimi(
                soru="Rapora hangi cümleler girmelidir? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Rapora giren cümleler durumu nesnel biçimde bildirir: "
                    "\"arıza meydana gelmiştir\", \"tamamlanamamıştır\", "
                    "\"arz olunur\". Elenenler yakınma ve belirsizlik taşır: "
                    "\"bir türlü uğraşamadık\", \"bir sürü şey\", \"böyle gitmez\". "
                    "Bunlar bilgi değil, kişisel değerlendirme aktarır."
                ),
                ipuclari=[
                    "Hangi cümleler bir OLAY bildiriyor, hangileri bir YAKINMA?",
                    "\"bir sürü\", \"işte\", \"bir türlü\" gibi ifadeler nereye ait?",
                ],
                puan=20,
            ),
            yorum_adimi(
                soru="Resmî üslup neden \"daha kibar konuşmak\" demek değildir?",
                dogru="Amacı nezaket değil, açıklık ve nesnelliktir.",
                yanlislar={
                    "Aslında öyledir; resmî üslubun tek amacı saygı göstermektir.":
                        "Resmî üslubu nezakete indirdin. Samimi bir mektup da "
                        "kibar olabilir; resmî üslubu ayıran şey açıklık ve "
                        "belgelenebilirlik.",
                    "Amacı metni uzatmak ve ciddi göstermektir.":
                        "Amacı görüntüye bağladın. Uzun ve ağır yazmak resmî "
                        "yapmaz; iyi bir resmî metin kısa ve nettir.",
                    "Amacı okuyanın anlamasını zorlaştırmaktır.":
                        "Amacı tam tersine çevirdin. Resmî üslup yanlış "
                        "anlaşılmayı önlemek için vardır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Bir türlü uğraşamadık\" cümlesi kaba olduğu için değil, "
                    "ölçülemez olduğu için raporluk değildir: kaç kez denendiğini, "
                    "neyin engellediğini söylemez. Resmî üslup, okuyanın olayı "
                    "yazandan bağımsız olarak değerlendirebilmesini sağlar."
                ),
                puan=14,
            ),
        ],
        kapanis=(
            "Rapor resmî üslupla yeniden yazıldı. Komutan imzalarken \"şimdi "
            "oldu\" dedi."
        ),
        odul={"itibar": 10},
    )


@bulmaca(ders="turkce", konu="paragraf", kademeler=(7, 13))
def paragraf_akisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Cümleler karışmış; anlam akışına göre sıralanacak."""
    paragraflar = [
        [
            "Üssün su deposu geçen ay temizlendi.",
            "Temizlik sırasında tabanda ince bir çatlak fark edildi.",
            "Çatlak hemen onarıldı ve depo yeniden dolduruldu.",
            "Bu sayede kış boyunca su kaybı yaşanmadı.",
        ],
        [
            "Kronograf ilk çalıştırıldığında kimse ne yaptığını anlamadı.",
            "Birkaç deneme sonunda aygıtın geçmişten ses getirdiği görüldü.",
            "Kayıtlar arşivlenmeye başlandı ve bir düzen kuruldu.",
            "Bugün arşivde yüzlerce tarihlendirilmiş kayıt bulunuyor.",
        ],
        [
            "Sonbaharda ikinci kamp için yer aranmaya başlandı.",
            "Dört mevki gezildi ve ölçümleri alındı.",
            "Ölçümler değerlendirilerek en uygun mevki seçildi.",
            "Kamp kışa girmeden kuruldu.",
        ],
    ]
    paragraf = rastgele.choice(paragraflar)
    sirali_hali = list(paragraf)
    karisik = list(paragraf)
    rastgele.shuffle(karisik)
    dogru_sira = [karisik.index(c) for c in sirali_hali]

    return Bulmaca(
        kod="tur-paragraf-akisi",
        ders="turkce",
        baslik="Dağılan Paragraf",
        kademe=kademe,
        konu="paragraf",
        kazanim="Paragrafta anlam akışı; cümleler arası mantıksal ve zamansal bağ.",
        dikkat=5,
        brifing=(
            "Yıllık faaliyet raporunun bir paragrafı, dosya düşünce dağılmış. "
            "Cümleler tek tek duruyor ama sıraları kayıp.\n\n"
            "Kâtip \"hepsi aynı konuda, nasıl dizsek olur\" diyor. Ama olmaz: "
            "bir paragrafta cümleler rastgele durmaz, birbirini takip eder.\n\n"
            "Paragrafı yeniden kurman gerekiyor."
        ),
        kanitlar=[
            Kanit("Yazım kılavuzu - paragraf",
                  "\"Bir paragrafta cümleler zaman ve mantık sırasına göre "
                  "dizilir. Giriş cümlesi konuyu tanıtır; sonraki cümleler "
                  "gelişmeyi anlatır; son cümle sonucu bildirir.\"",
                  bedel=2, kritik=True),
            Kanit("Bağlantı ipuçları",
                  "\"Bu sayede\", \"birkaç deneme sonunda\", \"bugün\" gibi "
                  "ifadeler cümlenin nereye ait olduğunu ele verir: bunlar "
                  "kendilerinden önce bir şey olduğunu varsayar.",
                  bedel=2, kritik=True),
            Kanit("Dosya notu",
                  "Cümlelerin hepsi aynı paragrafa ait; eksik ya da fazla cümle yok.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Cümlelerin sırasını ne belirler?",
                dogru="Olayların zaman ve neden-sonuç sırası.",
                yanlislar={
                    "Cümlelerin uzunluğu; kısa cümleler başa konur.":
                        "Uzunluğu ölçüt saydın. Sıralamayı belirleyen şey "
                        "cümlelerin boyu değil, aralarındaki ANLAM bağı.",
                    "Alfabetik sıra.":
                        "Alfabe sözlükte işe yarar. Paragrafta cümleler "
                        "birbirini tamamlayacak şekilde dizilir.",
                    "Cümlelerin önemi; en önemli cümle sona konur.":
                        "Önemi sıra kuralı yaptın. Önemli cümle başta da "
                        "sonda da olabilir; belirleyici olan hangi cümlenin "
                        "hangisini gerektirdiği.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Paragraf bir yığın değil, bir zincirdir. Her cümle kendinden "
                    "öncekine bağlanır: sonuç bildiren bir cümle, sonucu doğuran "
                    "olaydan önce gelemez. \"Bu sayede\" ya da \"bugün\" gibi "
                    "ifadeler bu bağı açıkça gösterir."
                ),
                ipuclari=[
                    "Hangi cümle hiçbir şeye dayanmadan tek başına okunabiliyor? O giriştir.",
                    "\"Bu sayede\" diye başlayan cümle neyin ardından gelir?",
                ],
                puan=18,
            ),
            sirala_adimi(
                soru="Paragrafı doğru sıraya diz (numaraları sırayla yaz):",
                secenekler=karisik,
                dogru_sira=dogru_sira,
                aciklama="Doğru sıra:\n" + "\n".join(
                    "{}. {}".format(i + 1, c) for i, c in enumerate(sirali_hali)),
                ipuclari=[
                    "Önce giriş cümlesini bul: hiçbir öncekine gönderme yapmayan cümle.",
                    "Sonra zaman sırasını takip et.",
                ],
                puan=22,
            ),
            secim_adimi(
                soru="Paragrafın son cümlesi hangi işi görüyor?",
                dogru="Sürecin sonucunu bildiriyor.",
                yanlislar={
                    "Konuyu ilk kez tanıtıyor; giriş cümlesi gibi çalışıyor.":
                        "Son cümleye giriş görevi verdin. Konu zaten önceki "
                        "cümlelerde tanıtılmış; son cümle onların üstüne "
                        "biner.",
                    "Yeni bir konu açıyor.":
                        "Paragrafı ortadan böldün. Yeni konu yeni paragrafta "
                        "açılır; son cümle mevcut konuyu bağlar.",
                    "Önceki cümleleri yalanlıyor.":
                        "Son cümleyi karşı çıkış saydın. Paragraf içinde "
                        "cümleler birbirini yalanlamaz, tamamlar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Son cümle (\"{}\") kendinden önce anlatılanların vardığı noktayı "
                    "bildirir. Bir paragrafın sonuç cümlesi yeni bilgi açmaz; "
                    "açarsa orada yeni bir paragraf başlaması gerekir."
                ).format(sirali_hali[-1]),
                ipuclari=["Son cümle yeni bir şey mi başlatıyor, yoksa bir şeyi mi bitiriyor?"],
                puan=12,
            ),
        ],
        kapanis="Paragraf yeniden kuruldu ve rapora yerleştirildi.",
        odul={"itibar": 7},
    )


@bulmaca(ders="turkce", konu="anlam", kademeler=(5, 12))
def sozcukte_anlam(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Gerçek, mecaz ve terim anlam ayrımı."""
    durumlar = [
        {
            "sozcuk": "soğuk",
            "mecaz_cumle": "Komutan bu öneriye soğuk baktı.",
            "gercek_cumle": "Sabah suyu çok soğuktu.",
            "terim_cumle": "Bölgede soğuk hava dalgası bekleniyor.",
            "aciklama": ("\"Soğuk bakmak\" sıcaklıkla ilgili değildir; \"ilgi "
                         "göstermemek, benimsememek\" anlamındadır. Sözcük burada "
                         "asıl anlamından uzaklaşmış, yani MECAZ anlamda kullanılmıştır."),
        },
        {
            "sozcuk": "düşmek",
            "mecaz_cumle": "Erzak stoğu tehlikeli seviyeye düştü.",
            "gercek_cumle": "Çocuk merdivenden düştü.",
            "terim_cumle": "Termometrede sıcaklık iki derece düştü.",
            "aciklama": ("Stok \"düşmez\", azalır; burada sözcük yer değiştirme "
                         "anlamından çıkıp \"azalmak\" anlamı kazanmıştır. Bu bir "
                         "MECAZ kullanımdır."),
        },
        {
            "sozcuk": "ağır",
            "mecaz_cumle": "Bu görev ekibe ağır geldi.",
            "gercek_cumle": "Sandık çok ağırdı, tek başına kaldıramadım.",
            "terim_cumle": "Kurşun ağır bir metaldir.",
            "aciklama": ("Görevin kütlesi yoktur; \"ağır gelmek\" burada \"zor "
                         "gelmek, altından kalkılamamak\" demektir. Sözcük MECAZ "
                         "anlamda kullanılmıştır."),
        },
    ]
    durum = rastgele.choice(durumlar)

    return Bulmaca(
        kod="tur-sozcukte-anlam",
        ders="turkce",
        baslik="Aynı Sözcük, Başka Anlam",
        kademe=kademe,
        konu="anlam",
        kazanim="Sözcükte gerçek, mecaz ve terim anlam ayrımı.",
        dikkat=5,
        brifing=(
            "Arşivde tutulan tutanaklarda \"{}\" sözcüğü üç ayrı yerde geçiyor "
            "ve üçünde de farklı bir şey anlatıyor.\n\n"
            "Arşiv dizini hazırlanırken her cümlenin hangi anlamda kullanıldığı "
            "işaretlenecek; yoksa arama yapan kişi yanlış tutanağı bulur.\n\n"
            "Sözcüğün hangi cümlede asıl anlamından uzaklaştığını belirlemen "
            "gerekiyor."
        ).format(durum["sozcuk"]),
        kanitlar=[
            Kanit("Anlam kılavuzu",
                  "GERÇEK ANLAM: sözcüğün ilk akla gelen, sözlükteki temel anlamı.\n"
                  "MECAZ ANLAM: sözcüğün asıl anlamından uzaklaşıp başka bir "
                  "kavramı anlatması.\n"
                  "TERİM ANLAM: bir bilim, sanat ya da meslek dalına özgü anlam.",
                  bedel=2, kritik=True),
            Kanit("Tutanak alıntıları",
                  "1) {}\n2) {}\n3) {}".format(
                      durum["gercek_cumle"], durum["mecaz_cumle"], durum["terim_cumle"]),
                  bedel=2, kritik=True),
            Kanit("Dizinci notu",
                  "\"Sözcük aynı yazılır ama anlamı bağlamdan çıkar. Tek başına "
                  "sözcüğe bakarak karar verilmez.\"", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir sözcüğün mecaz anlamda kullanıldığını ne gösterir?",
                dogru="Sözcüğün temel anlamının orada işlememesi.",
                yanlislar={
                    "Sözcüğün cümlede ilk sırada bulunması; başa gelen sözcük vurgulanır.":
                        "Yeri ölçüt saydın. Mecaz, sözcüğün cümledeki "
                        "konumuyla değil, TEMEL ANLAMININ orada işleyip "
                        "işlemediğiyle belirlenir.",
                    "Sözcüğün eskimiş bir sözcük olması.":
                        "Eskiliği ölçüt saydın. Gündelik sözcükler de mecaz "
                        "anlamda kullanılır.",
                    "Cümlenin soru cümlesi olması.":
                        "Cümle türünü ölçüt saydın. Mecaz her cümle türünde "
                        "olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Mecazı yakalamanın yolu şudur: sözcüğü temel anlamıyla "
                    "yerleştirmeyi dene. \"Ağır\" temel anlamda kütleyle ilgilidir; "
                    "\"görev ağır geldi\" cümlesinde bir kütle yoktur, demek ki "
                    "sözcük başka bir anlama kaymıştır."
                ),
                ipuclari=[
                    "Sözcüğü sözlükteki ilk anlamıyla düşün ve cümleye yerleştir.",
                    "Anlatılan şey gerçekten o özelliğe sahip mi?",
                ],
                puan=16,
            ),
            secim_adimi(
                soru="\"{}\" sözcüğü hangi cümlede MECAZ anlamda kullanılmıştır?".format(
                    durum["sozcuk"]),
                dogru=durum["mecaz_cumle"],
                yanlislar={
                    durum["gercek_cumle"]:
                        "Bu cümlede sözcük sözlükteki TEMEL anlamıyla "
                        "kullanılmış; mecaz için temel anlamın orada "
                        "işlememesi gerekir.",
                    durum["terim_cumle"]:
                        "Bu cümlede sözcük bir alanın TERİMİ olarak "
                        "kullanılmış. Terim anlam da mecaz değildir; belirli "
                        "bir iş kolunda kazanılmış özel anlamdır.",
                },
                rastgele=rastgele,
                aciklama=durum["aciklama"],
                ipuclari=["Hangi cümlede sözcüğün temel anlamı işlemiyor?"],
                puan=16,
            ),
            secim_adimi(
                soru="\"{}\" cümlesinde sözcük hangi anlamdadır?".format(
                    durum["gercek_cumle"]),
                dogru="Gerçek anlam",
                yanlislar={
                    "Mecaz anlam":
                        "Mecaz, temel anlamın işlemediği yerde olur. Burada "
                        "sözcüğün akla ilk gelen anlamı cümleye tam oturuyor.",
                    "Terim anlam":
                        "Terim anlam, sözcüğün belirli bir meslek ya da bilim "
                        "dalında kazandığı özel anlamdır. Bu cümlede öyle bir "
                        "kullanım yok.",
                    "Hiçbiri; sözcük burada anlam taşımıyor.":
                        "Üç seçenekten biri mutlaka geçerlidir; sözcük her "
                        "cümlede bir anlamla kullanılır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bu cümlede sözcük sözlükteki temel anlamıyla, doğrudan "
                    "kullanılmıştır. Gerçek anlam, sözcüğün akla ilk gelen anlamıdır."
                ),
                ipuclari=["Sözcüğün sözlükteki ilk anlamı bu cümleye uyuyor mu?"],
                puan=12,
            ),
        ],
        kapanis="Arşiv dizini anlam işaretleriyle birlikte tamamlandı.",
        odul={"itibar": 6},
    )


# ==========================================================================
# EŞ ANLAM KÖPRÜSÜ — muhatabı tanıma (kademe 5-10)
# ==========================================================================
#
# Kullanıcının fikri (9 Eylül 2026): "üstlerimiz biraz eski kafalı
# olduğunda bazı kelimelerin anlamlarını bilmiyorlar, kelimelerin yanlarına
# eş anlamlarını yazman gerek... veya tersi. üst yönetici yeni mezun ve
# eski anlamları bilmiyor gibi."
#
# NEDEN İYİ BİR GÖREV
# -------------------
# Sözlük işi değil, MUHATABI TANIMA işi. KARAR adımı gerçek: *hangi*
# kelimelerin karşılığı yazılmalı? Hepsi değil -- yalnızca o okuyucunun
# bilmediği olanlar. Aynı metin, iki farklı okuyucu için iki farklı
# listeye ihtiyaç duyar.
#
# ASIL DERS DEĞERLENDİRME ADIMINDA: eş anlamlılar TAM EŞ DEĞİLDİR.
# "Kara gün" ile "siyah gün" aynı şey değil. Öğrenci karşılığı yazar,
# sonra anlamın hayatta kalıp kalmadığına bakar. Çalışma kâğıdında
# öğretilemeyen şey bu.
#
# İki yönlü olduğu için ezberle çözülmüyor: bazen eskiyi yeniye, bazen
# yeniyi eskiye çevirmek gerekiyor.

# (eski sözcük, yeni sözcük, anlam, cümle kalıbı)
#
# CÜMLE KALIBI HER SÖZCÜĞE ÖZEL. İlk yazımda tek bir sabit cümleye üç
# rastgele sözcük yerleştiriliyordu ve "Sevkiyat özel edildi" gibi
# Türkçe olmayan cümleler çıkıyordu -- sözcüklerin dilbilgisel rolü
# farklı (kimi ad, kimi sıfat). Kalıp sözcükle birlikte saklanınca
# rapor gerçek bir rapor gibi okunuyor.
#
# `{}` seçilen sözcükle doldurulur. KALIP EK İSTEMEMELİ: "etkisi" ya da
# "yeterliliği" gibi iyelik ekleri ünlü uyumuna göre değiştiği için
# kalıptan çıkmıyor. Kalıp, sözcüğü YALIN hâliyle alacak şekilde kurulur.
# Sözcük CÜMLE BAŞINDA olmamalı: küçük harfle başlayan cümle çıkıyor.
SOZCUK_KOPRUSU = [
    ("sükûnet", "sakinlik", "gürültüsüzlük, dinginlik",
     "Hat boyunda gece boyunca {} vardı."),
    ("muvaffakiyet", "başarı", "amaca ulaşma",
     "Tatbikat {} ile sonuçlandı."),
    ("tehir", "erteleme", "sonraya bırakma",
     "Sevkiyatta iki günlük {} oldu."),
    ("münasebet", "ilişki", "iki şey arasındaki bağ",
     "İki olay arasında bir {} görünmüyor."),
    ("vaziyet", "durum", "işlerin o anki hâli",
     "Cephanelikteki {} bildirildiği gibidir."),
    ("tesir", "etki", "bir şeyin bıraktığı iz",
     "İki hat arasında {} bakımından fark görülmedi."),
    ("kifayet", "yeterlilik", "işi görecek kadar olma",
     "Mevcut erzak {} bakımından tartışmalıdır."),
    ("teçhizat", "donanım", "iş için gereken takım",
     "Depoya yeni {} girişi yapılmadı."),
    ("mesai", "çalışma", "iş için ayrılan süre",
     "Nöbetçi ekibin {} saatleri değiştirildi."),
]

# Eş anlamlı SAYILAN ama bağlamda AYRIŞAN çiftler. Değerlendirme adımının
# malzemesi. Buraya YALNIZCA değiştirilmesi AÇIKÇA yanlış olan ifadeler
# konur -- "ak saçlı / beyaz saçlı" gibi ikisi de söylenebilen bir çift
# eklenmişti ve doğru cevabı tartışmalı yapıyordu; çıkarıldı.
AYRISAN_CIFTLER = [
    ("kara", "siyah", "kara gün",
     "\"siyah gün\" denmez; kara burada renk değil, uğursuzluk anlatıyor."),
    ("baş", "kafa", "baş komutan",
     "\"kafa komutan\" denmez; baş burada \"en üstteki\" demek."),
    ("yüz", "surat", "yüz akı",
     "\"surat akı\" denmez; yüz burada onur anlamında."),
    ("el", "yabancı", "el âlem",
     "\"yabancı âlem\" denmez; el burada kalıplaşmış bir sözcük."),
]


@bulmaca(ders="turkce", konu="es_anlam", kademeler=(5, 10), agirlik=1.2)
def es_anlam_koprusu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı raporu iki farklı okuyucu anlayacak.

    Yükselen tek eksen: sorunun kendisi -- doğru cevap metne değil
    OKUYUCUYA bağlı. Sayı yok, hesap yok; zorluk tamamen muhatabı
    tanımakta. (ICERIK_EKLEME.md §2c)
    """
    # Yön: eski komutan mı yeni amir mi okuyacak?
    eskiye_ceviri = rastgele.random() < 0.5
    secilen = rastgele.sample(SOZCUK_KOPRUSU, 3)
    ayrisan = rastgele.choice(AYRISAN_CIFTLER)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    if eskiye_ceviri:
        okuyucu = ("üsse yeni atanan komutan. Kendisi eski kuşaktan; "
                   "raporlarda bugünkü sözcükleri değil, alışık olduğu "
                   "eski karşılıklarını görmek istiyor")
        kaynak, hedef = 1, 0            # yeni -> eski
        yon_adi = "eski karşılığı"
    else:
        okuyucu = ("üsse yeni atanan amir. Kendisi taze mezun; eski "
                   "sözcükleri bilmiyor ve raporu anlamadığını söylüyor")
        kaynak, hedef = 0, 1            # eski -> yeni
        yon_adi = "bugünkü karşılığı"

    # Her sözcük KENDİ cümlesine yerleşiyor; ortak bir kalıba
    # doldurulmuyor. Sebebi veri tablosunun başında yazılı.
    metin = " ".join(kalip.format(cift[kaynak])
                     for cift in secilen
                     for kalip in [cift[3]])

    return Bulmaca(
        kod="tur-es-anlam-koprusu",
        ders="turkce",
        baslik="Rapor Kimin İçin",
        kademe=kademe,
        konu="es_anlam",
        kazanim=("Eş anlamlı sözcükleri okuyucuya göre seçme; eş anlamın "
                 "her bağlamda geçerli olmadığını görme."),
        dikkat=4,
        brifing=(
            "{} bir rapor yazdı ama raporu okuyacak kişi {}.\n\n"
            "RAPOR:\n\"{}\"\n\n"
            "Senden istenen: raporu okuyacak kişinin anlayacağı hâle "
            "getirmek. Ama bütün sözcükleri değiştirmek de doğru değil -- "
            "yalnızca onun takılacağı yerlere dokun."
        ).format(kisi, okuyucu, metin),
        kanitlar=[
            Kanit("Sözcük defteri",
                  "\n".join("{} = {} ({})".format(e, y, a)
                            for e, y, a, _ in secilen),
                  bedel=1, kritik=True),
            Kanit("Önceki raporun kenar notu",
                  "\"{}\" ifadesi düzeltilmiş: {}".format(
                      ayrisan[2], ayrisan[3]),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Raporda neyi değiştirmeli?",
                dogru="Yalnızca okuyucunun bilmediği sözcükleri.",
                yanlislar=[
                    "Bütün sözcükleri, metin baştan yazılmalı.",
                    "Hiçbirini; rapor zaten doğru yazılmış.",
                    "Yalnızca uzun olan sözcükleri.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Rapor zaten doğru; sorun anlamda değil, okuyucuda. "
                    "Anlaşılan sözcüğe dokunmak metni gereksiz uzatır ve "
                    "asıl değişikliği gizler."
                ),
                cozum=(
                    "Bir metni düzeltmeden önce sorulacak soru şu: kim "
                    "okuyacak?\n"
                    "Aynı rapor, iki farklı okuyucu için iki farklı "
                    "değişiklik ister. Burada okuyucu {}\n"
                    "Yani {} bilmediği sözcükler değişecek, diğerleri "
                    "kalacak."
                ).format(okuyucu + ".", "onun"),
            ),
            metin_adimi(
                soru=("Raporda geçen \"{}\" sözcüğünün {} nedir?").format(
                    secilen[0][kaynak], yon_adi),
                cevap=[secilen[0][hedef]],
                aciklama="{} = {} ({})".format(
                    secilen[0][0], secilen[0][1], secilen[0][2]),
                cozum=(
                    "\"{}\" ile \"{}\" aynı şeyi anlatıyor: {}.\n"
                    "Okuyucu {} bildiği için rapora o yazılacak."
                ).format(secilen[0][0], secilen[0][1], secilen[0][2],
                         "\"" + secilen[0][hedef] + "\""),
            ),
            yorum_adimi(
                soru=("\"{}\" ifadesinde \"{}\" yerine \"{}\" yazılabilir mi?"
                      ).format(ayrisan[2], ayrisan[0], ayrisan[1]),
                dogru="Hayır; bu ifadede anlam değişir.",
                yanlislar=[
                    "Evet; ikisi eş anlamlı, her yerde değişebilir.",
                    "Evet, ama yalnızca resmî yazışmalarda.",
                ],
                rastgele=rastgele,
                aciklama=ayrisan[3] + (
                    " Eş anlamlı sözcükler sözlükte eş, cümlede her zaman "
                    "eş değildir."
                ),
                cozum=(
                    "Sözlükte \"{}\" ile \"{}\" eş anlamlı görünür.\n"
                    "Ama \"{}\" ifadesinde değiller: {}\n\n"
                    "Bu yüzden eş anlamlı sözcük değiştirirken tek tek "
                    "sözcüğe değil, İFADENİN TAMAMINA bakılır."
                ).format(ayrisan[0], ayrisan[1], ayrisan[2], ayrisan[3]),
            ),
        ],
        kapanis=(
            "Rapor {} için yeniden yazıldı. Arşiv memuru kenara not "
            "düştü: \"Aynı metin, iki nüsha.\""
        ).format("eski kuşak" if eskiye_ceviri else "yeni amir"),
        odul={"itibar": 6, "erzak": 3},
    )
