# -*- coding: utf-8 -*-
"""
Olay kaydedici kabuk (Meridyen OS, bkz. MERIDYEN_OS.md).

`olay()` yöntemi taşıdığı için terminal işlevleri bu kabukta metin değil
yapısal olay gönderir. Her olay ve motorun her girdi isteğine verilen cevap
sırayla `kayit` listesine yazılır:

    {"olay": {"t": "menu", ...}}
    {"girdi": "3"}

Cevapları `surucu(kabuk, istem)` verir (kayıt aracı için betikli bir
oyuncu, testler için küçük bir işlev). Sürücü yoksa girdi istenince
EOFError atılır; motor bunu `OyunuBirak` yapar.
"""
from __future__ import annotations

import copy


class OlayKabugu:
    yazim_hizi_destekli = False

    def __init__(self, surucu=None, genislik: int = 60, sinir: int = 0):
        self.surucu = surucu
        self.sinir = sinir      # >0: bu kadar girdiden sonra AssertionError
        self._genislik = genislik
        self.olaylar = []       # yalnız olaylar (sıralı)
        self.kayit = []         # {"olay": ...} ve {"girdi": ...} öğeleri
        self.girdiler = []      # verilen cevaplar

    # ---------------------------------------------------------- kabuk yüzü
    def olay(self, veri: dict) -> None:
        kopya = copy.deepcopy(veri)
        self.olaylar.append(kopya)
        self.kayit.append({"olay": kopya})

    def bas(self, satir) -> None:
        """Olay yoluna girmeyen doğrudan çıktı da kaybolmasın."""
        self.olay({"t": "satir", "metin": str(satir)})

    def oku(self, istem) -> str:
        if self.surucu is None:
            raise EOFError("olay kabuğunda sürücü yok")
        if self.sinir and len(self.girdiler) >= self.sinir:
            raise AssertionError(
                "{} girdide bitmedi; akış dönüp duruyor".format(self.sinir))
        cevap = str(self.surucu(self, istem))
        self.girdiler.append(cevap)
        self.kayit.append({"girdi": cevap})
        return cevap

    def temizle(self) -> bool:
        return True

    def genislik(self) -> int:
        return self._genislik

    # ------------------------------------------------------------ yardımcı
    def son(self, tur: str):
        """En son gelen `tur` olayı (yoksa None)."""
        for olay in reversed(self.olaylar):
            if olay.get("t") == tur:
                return olay
        return None

    def baglamlar(self, ad: str = ""):
        return [o for o in self.olaylar
                if o.get("t") == "baglam" and (not ad or o.get("ad") == ad)]
