# -*- coding: utf-8 -*-
"""
Üssün konumu: nereye kurulduğu oyunun ekonomisini değiştirir.

Kullanıcı (12 Eylül 2026): "Yeryüzünde yerleşmek isteyen için artıları
genişlemesi ucuz ve hızlı. Fakat fırtınalarda hasar görme ihtimali hâlâ var.
Yerin altında olan için güneş panelleri ve rüzgâr türbini ile bacalar
yerleştirmek masraflı, genişlemek biraz pahalı ve uzun sürer çünkü önce kazı
sonra yerleştirme olur."

ALTI KUŞAK: yeryüzü, yeraltı, yüzen şehir, su altı, gökyüzü, uzay. Yeryüzü ve
yeraltı aynı üç araziye (orman, düzlük, dağ eteği) kurulur; yüzen şehir ve su
altı aynı üç suya (göl, deniz, okyanus). Gökyüzü ve uzayda arazi seçimi yok.
Değiştiriciler KUŞAK + ARAZİ olarak toplanır: dağ eteğinin cevheri, altında da
üstünde de bol.

BEŞ KALDIRAÇ (hepsi mevcut sistemlere bağlanır, süs değil)
  1. `genisleme_carpani`  -> tesis geliştirme bedeli (tesis.gelistirme_bedeli)
  2. `kazi_gorevi`        -> geliştirme kaç görev sonra biter (önce kazı!)
  3. `seviye_farki`       -> azami tesis seviyesi ("daha fazla yer")
  4. `uretim`             -> görev başına kaynak farkı
  5. `tehlike` + `gider`  -> arıza olasılığı ve görev başına enerji gideri

GÖKYÜZÜ NEDEN EN ZOR
Üssü havada tutan motorlar her görevde enerji yer ve üs büyüdükçe AĞIRLAŞIR:
gider tesis seviyelerinin toplamıyla birlikte artar. Üretilen enerji giderin
altına düşerse üs alçalmaya başlar.

GİDERİN ÜST SINIRI NEREDEN GELİYOR
`oyun._odulu_hesapla` kuralı: "tamamlanan bir görev en azından kendi bedelini
öder" (5 Eylül 2026 §0 düzeltmesi). Bir görev en az 1 enerji bırakır, atölye
1. seviyede 1 enerji üretir. Bu yüzden hiçbir konumun TABAN gideri 1'den büyük
değil: en pahalı konumda bile başlangıçtaki öğrenci başabaşta durur, açığa
düşmez. Gökyüzünün gideri ancak öğrenci üssü BÜYÜTTÜKÇE artar -- yani açığı
öğrencinin kendi tercihi doğurur ve atölyeyi geliştirerek kapatabilir.

KİLİT YOK (TASARIM_NOTLARI §0)
Enerji yetmezse eksi bakiye YAZILMAZ ve oyun bitmez: gerilim sayacı artar,
üçüncüde üs güvenli biçimde düzlüğe iner. Kaynaklar, tesisler, seviyeler
durur. Ceza konumun kaybı ve iniş anlatısıdır; öğrenci hiçbir zaman
oynayamaz hâle gelmez. Bir öğrenci yanlış konum seçtiği için kilitlenirse
bu modül yanlış yazılmış demektir.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

VARSAYILAN = "yeryuzu:duzluk"        # en ucuz, en hızlı, en açık
GERILIM_SINIRI = 3                   # kaçıncı karşılıksız görevde iniş


@dataclass(frozen=True)
class Kusak:
    kod: str
    ad: str
    ozet: str
    zorluk: int                       # 1-5, yalnız gösterim
    artilar: Tuple[str, ...]
    eksiler: Tuple[str, ...]
    genisleme_carpani: float = 1.0
    kazi_gorevi: int = 0
    seviye_farki: int = 0
    uretim: Dict[str, int] = field(default_factory=dict)
    tehlike_olasiligi: float = 0.0    # arıza olasılığına EKLENİR
    tehlike_metni: str = ""
    gider_tabani: int = 0             # görev başına enerji
    gider_agirlik: int = 0            # her N seviye başına +1 enerji (0 = yok)
    arazi_turu: str = ""              # "kara", "su" ya da "" (arazisiz)
    # Üs dış havaya AÇIK mı? Yeryüzü ve yüzen şehir açık; yeraltı, su altı ve
    # uzay kapalı. Kapalı üste arazinin HAVA ile gelen etkileri (fırtına
    # tehlikesi, ısıtma gideri) işlemez -- kuşağın kendi artısı bu zaten.
    # Arazinin taş/toprak ile gelen etkileri (genişleme bedeli, üretim) her
    # durumda işler: kaya, üstünde de altında da serttir.
    dis_havaya_acik: bool = True
    # Enerji gideri üst üste karşılanamazsa üs buraya taşınır; metin o anı
    # anlatır. Kaynak, tesis ve seviyeler DURUR (bkz. enerji_isle).
    inis_metni: str = ""


@dataclass(frozen=True)
class Arazi:
    kod: str
    ad: str
    tur: str                          # "kara" / "su"
    ozet: str
    genisleme_carpani: float = 1.0
    uretim: Dict[str, int] = field(default_factory=dict)
    tehlike_olasiligi: float = 0.0
    gider: int = 0                    # ısıtma/soğutma; yalnız açık üste işler
    uyumsuz: Tuple[str, ...] = ()     # bu arazide kurulamayan kuşaklar


KUSAKLAR: Tuple[Kusak, ...] = (
    Kusak(
        kod="yeryuzu", ad="Yeryüzü", arazi_turu="kara", zorluk=1,
        ozet="Açık arazide kurulu üs. Genişlemek kazı istemez.",
        artilar=("Genişleme en ucuz ve anında biter",
                 "Güneş ve rüzgâr doğrudan; ek enerji gideri yok"),
        eksiler=("Fırtınalar tesisleri vurur",
                 "Yer sınırlı: tesisler en çok 4. seviyeye çıkar"),
        genisleme_carpani=1.0, kazi_gorevi=0,
        tehlike_olasiligi=0.0,          # taban: oyunun bugünkü arıza oranı
        tehlike_metni="Fırtına çatıyı aldı",
    ),
    Kusak(
        kod="yeralti", ad="Yeraltı", arazi_turu="kara", zorluk=3,
        ozet="Aynı arazinin altına oyulmuş üs. Yer bol, hava pahalı.",
        artilar=("Fırtına ve dış hava üssü etkilemez",
                 "Yer geniş: tesisler bir seviye daha yükselir"),
        eksiler=("Genişleme pahalı ve YAVAŞ: önce kazı, sonra yerleştirme",
                 "Güneş paneli, türbin ve baca yukarıda; enerji gideri var"),
        genisleme_carpani=1.6, kazi_gorevi=2, seviye_farki=1,
        dis_havaya_acik=False,
        tehlike_olasiligi=-0.08,
        tehlike_metni="Tavandan toprak kaydı",
        gider_tabani=1, gider_agirlik=0,
        inis_metni=("Havalandırma durdu. Galeriler kapatıldı ve üs yüzeye, "
                    "düzlüğe çıkarıldı."),
    ),
    Kusak(
        kod="yuzen", ad="Yüzen şehir", arazi_turu="su", zorluk=3,
        ozet="Su üstünde duran platformlar. Genişlemek yeni platform demek.",
        artilar=("Su ve balık bol: erzak üretimi artar",
                 "Kazı yok; platform eklemek görece hızlı"),
        eksiler=("Dalga ve fırtına bağlantıları koparır",
                 "Platformlar pahalı; her ek modül ağırlık demek"),
        genisleme_carpani=1.4, kazi_gorevi=1,
        uretim={"erzak": 1},
        tehlike_olasiligi=0.05,
        tehlike_metni="Dalga bağlantı halatını kopardı",
    ),
    Kusak(
        kod="su_alti", ad="Su altı", arazi_turu="su", zorluk=4,
        ozet="Basınç altında kapalı kubbeler. Dışarısı hep tehdit.",
        artilar=("Fırtına hiç ulaşmaz; yüzeydeki hava olayları önemsiz",
                 "Derin sudan cevher ve mineral çıkar"),
        eksiler=("Basınç kubbeleri pahalı ve yavaş kurulur",
                 "Hava ve aydınlatma sürekli enerji yer"),
        genisleme_carpani=1.8, kazi_gorevi=2,
        dis_havaya_acik=False,
        uretim={"cevher": 1},
        tehlike_olasiligi=-0.06,
        tehlike_metni="Kubbe contasından su sızdı",
        gider_tabani=1, gider_agirlik=0,
        inis_metni=("Hava üretimi durunca kubbeler boşaltıldı. Üs kıyıya, "
                    "düzlüğe taşındı."),
    ),
    Kusak(
        kod="gokyuzu", ad="Gökyüzü", zorluk=5,
        ozet="Motorlarla havada tutulan üs. Büyüdükçe ağırlaşır.",
        artilar=("Güneş kesintisiz; panel verimi en yüksek",
                 "Yerden gelen hiçbir tehlike ulaşmaz"),
        eksiler=("Motorlar her görevde enerji yer; ÜS BÜYÜDÜKÇE GİDER ARTAR",
                 "Enerji yetmezse üs alçalır ve sonunda yere iner"),
        genisleme_carpani=1.5, kazi_gorevi=1,
        uretim={"enerji": 1},
        tehlike_olasiligi=0.0,
        tehlike_metni="Türbülans bir modülü sarstı",
        gider_tabani=1, gider_agirlik=2,
        inis_metni=("Motorlar birer birer sustu. Üs alçaldı ve düzlüğe "
                    "indirildi; kimse yaralanmadı."),
    ),
    Kusak(
        kod="uzay", ad="Uzay", zorluk=4,
        ozet="Yörüngedeki istasyon. Her şey yukarı taşınır.",
        artilar=("Güneş hiç batmaz, hava olayı yok",
                 "Yörüngede yer geniş: tesisler bir seviye daha yükselir"),
        eksiler=("Her modül yukarı taşınır: genişleme en pahalısı",
                 "Yaşam desteği sürekli enerji ister"),
        genisleme_carpani=2.0, kazi_gorevi=1, seviye_farki=1,
        dis_havaya_acik=False,
        uretim={"enerji": 1},
        tehlike_olasiligi=-0.04,
        tehlike_metni="Mikro göktaşı paneli deldi",
        gider_tabani=1, gider_agirlik=0,
        inis_metni=("Yaşam desteği azalınca istasyon tahliye edildi. Üs "
                    "düzlüğe indi."),
    ),
)

ARAZILER: Tuple[Arazi, ...] = (
    Arazi(kod="orman", ad="Orman", tur="kara",
          ozet="Kereste ve av bol; güneş ağaçların arasından zor geçer.",
          uretim={"erzak": 1}, genisleme_carpani=1.1),
    Arazi(kod="duzluk", ad="Düzlük", tur="kara",
          ozet="Açık ova. Kurmak kolay, saklanmak zor.",
          uretim={"enerji": 1}, genisleme_carpani=0.9,
          tehlike_olasiligi=0.05),   # açık ova: fırtınaya en açık yer
    Arazi(kod="dag_etegi", ad="Dağ eteği", tur="kara",
          ozet="Kayalık yamaç. Taş serttir ama içinde maden vardır.",
          uretim={"cevher": 1}, genisleme_carpani=1.2,
          tehlike_olasiligi=-0.05),
    Arazi(kod="col", ad="Çöl", tur="kara",
          ozet="Kurak ova. Güneş hiç esirgenmiyor, su esirgeniyor.",
          uretim={"enerji": 2, "erzak": -1}, genisleme_carpani=0.85,
          tehlike_olasiligi=0.04),
    Arazi(kod="nehir_kiyisi", ad="Nehir kıyısı", tur="kara",
          ozet="Akarsu boyu. Hem su gücü hem verimli toprak; bir de sel.",
          uretim={"enerji": 1, "erzak": 1}, genisleme_carpani=1.05,
          tehlike_olasiligi=0.05),
    Arazi(kod="jeotermal", ad="Jeotermal bölge", tur="kara",
          ozet="Yerin ısısı yüzeye yakın. Bedava ısı, huzursuz zemin.",
          uretim={"enerji": 1, "cevher": 1}, genisleme_carpani=1.15,
          tehlike_olasiligi=0.12),
    Arazi(kod="tundra", ad="Tundra", tur="kara",
          ozet="Donmuş toprak. Depodaki hiçbir şey bozulmuyor; kazma da girmiyor.",
          uretim={"erzak": 1}, genisleme_carpani=1.35,
          tehlike_olasiligi=-0.07, gider=1),
    Arazi(kod="gol", ad="Göl", tur="su",
          ozet="Durgun tatlı su. Dalga küçük, kaynak da küçük.",
          genisleme_carpani=0.9, tehlike_olasiligi=-0.04),
    Arazi(kod="deniz", ad="Deniz", tur="su",
          ozet="Kıyıya yakın tuzlu su. Dengeli ama fırtınalı.",
          uretim={"erzak": 1}),
    Arazi(kod="okyanus", ad="Okyanus", tur="su",
          ozet="Açık deniz. En zengin sular, en büyük dalgalar.",
          uretim={"erzak": 1, "cevher": 1}, genisleme_carpani=1.2,
          tehlike_olasiligi=0.06),
    Arazi(kod="resif", ad="Resif sığlığı", tur="su",
          ozet="Sığ, kaynak dolu su. Derinlik yok: altına inilemez.",
          uretim={"erzak": 1}, genisleme_carpani=0.95,
          tehlike_olasiligi=0.03, uyumsuz=("su_alti",)),
)

_KUSAK = {k.kod: k for k in KUSAKLAR}
_ARAZI = {a.kod: a for a in ARAZILER}


def araziler(kusak_kodu: str) -> List[Arazi]:
    """Bu kuşakta seçilebilecek araziler; arazisiz kuşakta boş liste."""
    kusak = _KUSAK.get(kusak_kodu)
    if not kusak or not kusak.arazi_turu:
        return []
    return [a for a in ARAZILER
            if a.tur == kusak.arazi_turu and kusak_kodu not in a.uyumsuz]


def kod_yap(kusak_kodu: str, arazi_kodu: str = "") -> str:
    return "{}:{}".format(kusak_kodu, arazi_kodu) if arazi_kodu else kusak_kodu


def coz(kod: str) -> Tuple[Optional[Kusak], Optional[Arazi]]:
    """"yeralti:orman" -> (Kusak, Arazi). Tanınmayan kod (None, None)."""
    kusak_kodu, _, arazi_kodu = (kod or "").partition(":")
    kusak = _KUSAK.get(kusak_kodu)
    arazi = _ARAZI.get(arazi_kodu) if arazi_kodu else None
    if kusak and arazi and (arazi.tur != kusak.arazi_turu
                            or kusak.kod in arazi.uyumsuz):
        arazi = None                  # kuşağa uymayan arazi yok sayılır
    return kusak, arazi


def gecerli_mi(kod: str) -> bool:
    kusak, arazi = coz(kod)
    if kusak is None:
        return False
    return bool(arazi) or not kusak.arazi_turu


def konum_kodu(durum) -> str:
    """Durumdaki konum; yoksa varsayılan. Eski kayıtlar bozulmaz."""
    kod = getattr(durum, "konum", "") or ""
    return kod if gecerli_mi(kod) else VARSAYILAN


def ad(kod: str) -> str:
    kusak, arazi = coz(kod)
    if kusak is None:
        return "?"
    return "{} · {}".format(kusak.ad, arazi.ad) if arazi else kusak.ad


def ozet(kod: str) -> str:
    kusak, arazi = coz(kod)
    if kusak is None:
        return ""
    return kusak.ozet + (" " + arazi.ozet if arazi else "")


def zorluk(kod: str) -> int:
    kusak, _ = coz(kod)
    return kusak.zorluk if kusak else 1


# --------------------------------------------------------------------------
# Kaldıraçlar
# --------------------------------------------------------------------------

def genisleme_carpani(kod: str) -> float:
    kusak, arazi = coz(kod)
    if kusak is None:
        return 1.0
    return kusak.genisleme_carpani * (arazi.genisleme_carpani if arazi else 1.0)


def kazi_gorevi(kod: str) -> int:
    kusak, _ = coz(kod)
    return kusak.kazi_gorevi if kusak else 0


def seviye_farki(kod: str) -> int:
    kusak, _ = coz(kod)
    return kusak.seviye_farki if kusak else 0


def uretim_farki(kod: str) -> Dict[str, int]:
    """Görev başına kaynak farkı: kuşak + arazi toplanır."""
    kusak, arazi = coz(kod)
    sonuc: Dict[str, int] = {}
    for kaynak_tablosu in ((kusak.uretim if kusak else {}),
                           (arazi.uretim if arazi else {})):
        for kaynak, miktar in kaynak_tablosu.items():
            sonuc[kaynak] = sonuc.get(kaynak, 0) + miktar
    return sonuc


def tehlike_farki(kod: str) -> float:
    """Arıza olasılığı farkı.

    Arazinin tehlikesi HAVA ile geliyor (fırtına, dalga, sel): kapalı üste
    işlemez. Yeraltındaki üs, üstündeki ovanın fırtınasını yemez -- zaten
    kuşağın artısı bu. Bir istisna yok, çünkü tersi kuşağın kendi vaadini
    çürütürdü.
    """
    kusak, arazi = coz(kod)
    if kusak is None:
        return 0.0
    fark = kusak.tehlike_olasiligi
    if arazi and kusak.dis_havaya_acik:
        fark += arazi.tehlike_olasiligi
    return fark


def tehlike_metni(kod: str) -> str:
    kusak, _ = coz(kod)
    return kusak.tehlike_metni if kusak else ""


def enerji_gideri(kod: str, toplam_seviye: int = 3) -> int:
    """Görev başına enerji gideri.

    `gider_agirlik` varsa üs BÜYÜDÜKÇE gider artar: gökyüzünde motorlar daha
    ağır bir üssü kaldırmak zorunda. Taban üç tesisin 1. seviyesidir; onun
    üstündeki her `gider_agirlik` seviye +1 enerji demektir.
    """
    kusak, arazi = coz(kod)
    if kusak is None:
        return 0
    gider = kusak.gider_tabani
    if arazi and kusak.dis_havaya_acik:
        # Isıtma/soğutma da hava ile gelir: kapalı üs zaten yalıtılmış.
        gider += arazi.gider
    if kusak.gider_agirlik > 0:
        fazladan = max(0, toplam_seviye - 3)
        gider += fazladan // kusak.gider_agirlik
    return gider


# --------------------------------------------------------------------------
# Üssün durumu: enerji gideri, gerilim ve zorunlu iniş
# --------------------------------------------------------------------------

def toplam_seviye(durum) -> int:
    """Tesis seviyelerinin toplamı = üssün büyüklüğü.

    `tesis` modülünü İÇE AKTARMIYOR: tesis bu modülü kullanıyor, ters yönde
    bir bağ döngü yapardı. Tablo boşsa üç tesisin 1. seviyesi varsayılır.
    """
    tesisler = getattr(durum, "tesisler", None) or {}
    toplam = sum(int(t.get("seviye", 1) or 1) for t in tesisler.values()
                 if isinstance(t, dict))
    return toplam or 3


def us_durumu(durum) -> Dict[str, Any]:
    """Üssün konumla ilgili sayaçları. Eski kayıtta yoksa kurulur."""
    mevcut = getattr(durum, "us", None)
    if not isinstance(mevcut, dict):
        mevcut = {}
        durum.us = mevcut
    mevcut.setdefault("gerilim", 0)
    mevcut.setdefault("inis", 0)
    return mevcut


def enerji_isle(durum) -> Optional[Dict[str, Any]]:
    """Bir görev bitti: konumun enerji giderini düş.

    Dönüş None ise bu konumun gideri yok (yeryüzü). Aksi hâlde rapor:
    gider, ödenip ödenmediği, gerilim ve -oluştuysa- iniş metni.

    KİLİT YOK: enerji eksiye DÜŞMEZ. Ödenemeyen görevde gerilim artar,
    üçüncüde üs düzlüğe iner ve her şey (kaynak, tesis, seviye) kalır.
    """
    kod = konum_kodu(durum)
    gider = enerji_gideri(kod, toplam_seviye(durum))
    if gider <= 0:
        return None
    us = us_durumu(durum)
    mevcut = int(durum.kaynaklar.get("enerji", 0))
    rapor: Dict[str, Any] = {"gider": gider, "konum": kod, "indi": False}
    if mevcut >= gider:
        durum.kaynaklar["enerji"] = mevcut - gider
        us["gerilim"] = max(0, int(us.get("gerilim", 0)) - 1)
        rapor.update(odendi=True, gerilim=us["gerilim"], eksik=0)
        return rapor
    # Yetmedi: elindeki kadarı alınır, bakiye sıfırda durur.
    durum.kaynaklar["enerji"] = 0
    us["gerilim"] = int(us.get("gerilim", 0)) + 1
    rapor.update(odendi=False, gerilim=us["gerilim"], eksik=gider - mevcut)
    if us["gerilim"] >= GERILIM_SINIRI:
        kusak, _ = coz(kod)
        durum.konum = VARSAYILAN
        us["gerilim"] = 0
        us["inis"] = int(us.get("inis", 0)) + 1
        rapor["indi"] = True
        rapor["inis_metni"] = (kusak.inis_metni if kusak else "")
        rapor["yeni_konum"] = VARSAYILAN
    return rapor


def uyari(durum) -> str:
    """Panoda gösterilecek kısa uyarı; sorun yoksa boş."""
    kod = konum_kodu(durum)
    gider = enerji_gideri(kod, toplam_seviye(durum))
    if gider <= 0:
        return ""
    us = us_durumu(durum)
    gerilim = int(us.get("gerilim", 0))
    if gerilim <= 0:
        return ""
    kalan = GERILIM_SINIRI - gerilim
    return ("Enerji gideri karşılanamıyor ({} görevdir). {} görev daha "
            "karşılanmazsa üs iner.".format(gerilim, kalan))


def secenekler() -> List[Dict[str, Any]]:
    """Seçim ekranı için kuşak listesi (gösterim sırası: kolaydan zora)."""
    return [{"kod": k.kod, "ad": k.ad, "ozet": k.ozet, "zorluk": k.zorluk,
             "artilar": list(k.artilar), "eksiler": list(k.eksiler),
             "arazili": bool(k.arazi_turu)}
            for k in sorted(KUSAKLAR, key=lambda k: (k.zorluk, k.kod))]
