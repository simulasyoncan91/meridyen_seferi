# -*- coding: utf-8 -*-
"""
Kimya görevleri (lise, 9-13).

Çerçeve: üssün TEPKİME MASASI. Masada yarım yazılmış denklemler var:
maddeler biliniyor, katsayılar boş. Sorulan şey "şu denklemi denkleştir"
değil; kapalı bir sığınakta ne kadar oksijenin harcanacağı, denklemi
denkleştirmeden bilinemiyor.

Fen Bilimleri (ortaokul) kaldırılmadı; bu modül onun üstüne biner.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi, secim_adimi, sirala_adimi, sy,
    yorum_adimi,
)


# Katsayılar: (yakıt, O₂, CO₂, H₂O)
_YANMALAR = [
    {"ad": "metan", "formul": "CH₄", "kats": (1, 2, 1, 2),
     "denk": "CH₄ + 2O₂ → CO₂ + 2H₂O"},
    {"ad": "propan", "formul": "C₃H₈", "kats": (1, 5, 3, 4),
     "denk": "C₃H₈ + 5O₂ → 3CO₂ + 4H₂O"},
    {"ad": "etan", "formul": "C₂H₆", "kats": (2, 7, 4, 6),
     "denk": "2C₂H₆ + 7O₂ → 4CO₂ + 6H₂O"},
    {"ad": "bütan", "formul": "C₄H₁₀", "kats": (2, 13, 8, 10),
     "denk": "2C₄H₁₀ + 13O₂ → 8CO₂ + 10H₂O"},
]


# ==========================================================================
# TEPKİME DENKLEŞTİRME - katsayı, oran ve harcanan oksijen
# ==========================================================================

@bulmaca(ders="kimya", konu="denklestirme", kademeler=(9, 13), agirlik=1.2)
def yanma_denklestirme(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yanma denklemini denkleştirip mol oranından harcanan O₂'yi bulma."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    yanma = rastgele.choice(_YANMALAR)
    yakit_k, o2_k, co2_k, su_k = yanma["kats"]

    kat = rastgele.choice([2, 3, 4, 5])
    mol_yakit = yakit_k * kat          # oran tam çıksın
    mol_o2 = o2_k * kat
    # Oksijen ATOMU sayısı: en sık yapılan hata bunu molekül sanmak.
    oksijen_atomu = 2 * co2_k + su_k

    return Bulmaca(
        kod="kimya-yanma-denklestirme",
        ders="kimya",
        baslik="Isıtıcının Oksijen Hesabı",
        kademe=kademe,
        konu="denklestirme",
        kazanim="Kimyasal denklem denkleştirme; katsayıların mol oranı olarak "
                "okunması ve kütlenin korunumu.",
        dikkat=6,
        brifing=(
            "Fırtına yüzünden ekip yeraltı sığınağına indi. Ekip, dışarıda çalışacak ısıtıcı için {} "
            "gazının tam yanmasında harcanacak oksijeni hesaplıyor.\n\n"
            "{} hatırlatıyor: \"Kapı kapalı, hava sınırlı. Bu ısıtıcı içeride çalıştırılırsa bizim "
            "soluduğumuz oksijeni de yakacak.\"\n\n"
            "Masadaki tepkime kâğıdında maddeler yazılı ama önlerindeki "
            "sayılar boş bırakılmış. Ne kadar oksijenin gideceğini o sayıları "
            "koymadan söylemek mümkün değil."
        ).format(yanma["ad"], kisi),
        kanitlar=[
            Kanit("Tepkime kâğıdı",
                  "{} + O₂ → CO₂ + H₂O\n(katsayılar yazılmamış)".format(
                      yanma["formul"]),
                  bedel=1, kritik=True),
            Kanit("Isıtıcı çizelgesi",
                  "Bu vardiyada yakılacak yakıt: {} mol {}".format(
                      mol_yakit, yanma["ad"]),
                  bedel=1, kritik=True),
            Kanit("Kimya el kitabı",
                  "\"Denkleştirmede yalnızca formüllerin ÖNÜNDEKİ katsayılar "
                  "değiştirilir; alt indisler maddenin kimliğidir. Her element "
                  "için atom sayısı iki yanda eşit olmalıdır. Katsayılar en "
                  "küçük tam sayı olacak biçimde sadeleştirilir. Denkleşmiş "
                  "denklemdeki katsayılar aynı zamanda mol oranını verir.\"",
                  bedel=2, kritik=True),
            Kanit("Sığınak havalandırma notu",
                  "Isıtıcı sığınakta çalıştırılmayacak. Bu hesap yalnızca yeterli oksijenle TAM YANMA modelidir; ortamın güvenli olduğunu göstermez.", bedel=1),
            Kanit("Depo kaydı",
                  "Yedek tüplerin son basınç ölçümü on gün önce yapıldı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir denklemi denkleştirirken neyi değiştirmeye hakkımız var?",
                dogru=("Yalnız katsayıları; alt indisler maddenin kimliğidir, "
                       "dokunulmaz."),
                yanlislar={
                    "Gerekirse alt indisleri de değiştiririz; önemli olan atom "
                    "sayılarının tutmasıdır.":
                        "İndise dokundun. H₂O'yu H₂O₂ yaparsan denklem tutar "
                        "ama artık sudan değil, oksijenli sudan söz ediyorsun. "
                        "Denkleştirme maddeleri değil, kaç tane olduklarını ayarlar.",
                    ("Sol ve sağdaki molekül sayılarını eşitleriz; madde "
                     "korunuyorsa molekül de korunur."):
                        "Korunan şeyi molekül sayısı sandın. Tepkimede korunan "
                        "ATOM sayısıdır; molekül sayısı iki yanda pekâlâ farklı "
                        "olabilir.",
                    "Katsayıların toplamı iki yanda eşit olsun, yeter.":
                        "Toplama baktın. Denklik her element için AYRI AYRI "
                        "sağlanmalıdır; toplamların tutması hiçbir şeyi "
                        "garanti etmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Denklemin iki yanında aynı atomlar bulunur; tepkimede atomlar "
                    "yok olmaz, yalnızca yeniden dizilir. Alt indis bir molekülün "
                    "İÇ yapısıdır - onu değiştirmek maddeyi değiştirmek demektir. "
                    "Elimizdeki tek serbestlik, her maddeden kaç tane olduğunu "
                    "söyleyen katsayılardır."
                ),
                ipuclari=[
                    "H₂O'daki 2'yi değiştirirsen elinde hâlâ su var mı?",
                    "Katsayı 'kaç tane', indis 'içinde kaç atom' demek.",
                ],
                cozum=(
                    "1) Her elementin iki yandaki atom sayısı yazılır.\n"
                    "2) Yalnızca katsayılar değiştirilerek bu sayılar eşitlenir; "
                    "önce karbon, sonra hidrojen, en son oksijen ayarlanır.\n"
                    "3) Kesirli katsayı çıkarsa tüm denklem uygun sayıyla çarpılır.\n"
                    "Bu tepkimenin denkleşmiş hâli: {}"
                ).format(yanma["denk"]),
                puan=18,
            ),
            sayi_adimi(
                soru="En küçük pozitif tam sayı katsayılarla denkleştirildiğinde O₂ katsayısı kaçtır?",
                cevap=o2_k,
                aciklama=(
                    "Denkleşmiş hâli: {}. Sağ tarafta {} oksijen ATOMU var; "
                    "bunlar O₂ molekülü olarak geldiği için ikiye bölünür ve "
                    "O₂ katsayısı {} çıkar."
                ).format(yanma["denk"], oksijen_atomu, o2_k),
                yaygin_yanlislar={
                    oksijen_atomu:
                        "Oksijen ATOMLARINI saydın, molekülleri değil. Oksijen "
                        "tepkimeye O₂ olarak giriyor; her molekülde iki atom var.",
                    "*": "Önce karbonu, sonra hidrojeni sağda karşıla; oksijeni "
                         "her zaman en sona bırak. Oksijeni erken sabitlersen "
                         "sonraki adımda geri dönmek zorunda kalırsın.",
                },
                ipuclari=[
                    "Karbonu ve hidrojeni sağda karşıla; oksijeni en sona bırak.",
                    "Sağdaki toplam oksijen atomunu bul, sonra O₂ molekülüne çevir.",
                ],
                tolerans=0.01,
                puan=14,
            ),
            sayi_adimi(
                soru="Isıtıcı {} mol {} yakacak. Bunun için kaç mol O₂ "
                     "harcanır?".format(mol_yakit, yanma["ad"]),
                cevap=mol_o2,
                birim="mol",
                aciklama=(
                    "Katsayılar mol oranıdır: {} mol yakıt başına {} mol O₂. "
                    "{} mol yakıt için {} × {} ÷ {} = {} mol oksijen gerekir."
                ).format(yakit_k, o2_k, mol_yakit, mol_yakit, o2_k, yakit_k, mol_o2),
                yaygin_yanlislar={
                    mol_yakit:
                        "Yakıt molünü olduğu gibi yazdın; oranı 1'e 1 saydın. "
                        "Denklem her yakıt molü için birden çok O₂ istiyor.",
                    "*": "Oranı denklemden kur: O₂ katsayısı bölü yakıt "
                         "katsayısı. Bu oranı yakıtın mol sayısıyla çarp.",
                },
                ipuclari=[
                    "Denklemdeki iki katsayının oranını kur.",
                    "Yakıtın mol sayısını bu oranla çarp.",
                ],
                tolerans=0.01,
                puan=16,
            ),
            yorum_adimi(
                soru="Sığınak tümüyle kapalı olsaydı, içerideki toplam kütle "
                     "yanma sonunda nasıl değişirdi?",
                dogru="Değişmezdi; atomlar yok olmadı, yeni moleküllere dizildi.",
                yanlislar={
                    ("Azalırdı; yakıt tükendiği için kütlesi de ortadan kalkar, "
                     "geriye yalnız kül kalır."):
                        "Yanmayı yok olma saydın. Yakıtın karbonu ve hidrojeni "
                        "kaybolmadı; CO₂ ile H₂O'nun içine geçti.",
                    "Artardı; tepkimeye oksijen katıldığı için toplam büyür.":
                        "Oksijeni dışarıdan gelmiş gibi saydın. Kapalı "
                        "sığınakta oksijen zaten içerideydi; sayıma ikinci kez "
                        "girmez.",
                    ("Su buharı yoğuşursa azalır, gaz kalırsa değişmez; sıvı "
                     "gazdan çok daha az yer kaplar."):
                        "Kütleyi maddenin hâline bağladın. Sıvıya dönen su "
                        "aynı moleküllerdir ve hâlâ kapta durur; hâl değişimi "
                        "kütleyi değiştirmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Denkleştirmenin dayandığı fikir tam olarak budur: iki yanda "
                    "aynı atomlar bulunur. Kapalı bir kapta girenlerin toplam "
                    "kütlesi çıkanların toplam kütlesine eşittir. Değişen şey "
                    "kütle değil, atomların hangi moleküllerde toplandığıdır - ve "
                    "ekip için asıl mesele de bu: oksijen yok olmadı ama artık "
                    "solunabilir hâlde değil."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Gerekli oksijen miktarı rapora yazıldı. Bu miktar tek başına kapalı bir "
            "ortamda güvenli çalışma süresi vermez. Tepkime kâğıdı katsayılarıyla "
            "birlikte panoya asıldı."
        ),
        odul={"enerji": 7, "erzak": 4},
    )


# ==========================================================================
# ATOMUN YAPISI VE İYONLAR (B37.13 -- müfredat haritası)
#
# `atom_yapisi` kodu hem 2018 hem 2026 programında (9. sınıf) geçiyor; ikisi
# de boştu ve oyunda proton/nötron/elektron sayan hiçbir görev yoktu. Satırın
# `yaygin_yanlis` alanı iki parçalı:
#
#   1. "İyon oluşurken çekirdeğin değiştiğini sanmak" -- iyon oluşurken
#      YALNIZ elektron sayısı değişir; proton ve nötron (çekirdek) aynı kalır.
#   2. "Kütle numarasıyla atom numarasını karıştırmak" -- nötron = A - Z.
#
# ÖNCEDEN YAKALANAN TUZAK -- A = 2Z OLAN ELEMENTLER DIŞARIDA:
# Nötron sorusunda "atom numarasını nötron sanmak" çeldiricisi, A = 2Z olan
# elementlerde (O, Mg, S, Ca...) DOĞRU CEVABA EŞİT düşer: oksijende nötron da
# 8, atom numarası da 8. O hatayı yapan öğrenci doğru sayılırdı. Bu projede
# aynı tür çakışma dört kez yaşandı; havuz yalnız nötron != proton olan
# elementleri alıyor.
#
# BİR ÇAKIŞMA DA BİLİNÇLİ: "protonu yük kadar değiştirmek" yanılgısının
# verdiği sayı, iyonun ELEKTRON sayısına tam eşit. Yani etiketi yazan asistan
# elektron sayısını proton sayısı yerine yazmış -- iki yanılgı aynı sayıda
# birleşiyor ve son adım bunu doğrudan soruyor.
#
# Değerler gerçek: her element için en yaygın izotop ve en yaygın iyon.
# ==========================================================================

# (sembol, ad, atom numarası Z, kütle numarası A, iyon yükü)
_ATOMLAR = (
    ("Li", "lityum", 3, 7, 1),
    ("Na", "sodyum", 11, 23, 1),
    ("F", "flor", 9, 19, -1),
    ("Al", "alüminyum", 13, 27, 3),
    ("Cl", "klor", 17, 35, -1),
    ("K", "potasyum", 19, 39, 1),
)

_UST = {"0": "⁰", "1": "¹", "2": "²", "3": "³"}


def _iyon_gosterimi(sembol, yuk):
    buyukluk = "" if abs(yuk) == 1 else _UST[str(abs(yuk))]
    return "{}{}{}".format(sembol, buyukluk, "⁺" if yuk > 0 else "⁻")


@bulmaca(ders="kimya", konu="atom_yapisi", kademeler=(9, 13), agirlik=1.3)
def numune_etiketleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Nötron = A - Z; iyon oluşurken yalnız elektron sayısı değişir."""
    sembol, ad, z, a, yuk = rastgele.choice(_ATOMLAR)
    notron = a - z
    elektron = z - yuk
    iyon = _iyon_gosterimi(sembol, yuk)
    yuk_metni = "{}{}".format(abs(yuk), "+" if yuk > 0 else "−")
    hareket = "verdiği" if yuk > 0 else "aldığı"
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-numune-etiketleri",
        ders="kimya",
        baslik="Numune Etiketleri",
        kademe=kademe,
        konu="atom_yapisi",
        kazanim="Atom numarası ve kütle numarasından proton, nötron ve elektron "
                "sayısını bulma; iyon oluşumunda çekirdeğin değişmediğini açıklama.",
        dikkat=7,
        brifing=(
            "Laboratuvara {} içeren numuneler geldi. Asistan {} etiketleri "
            "doldurmuş ama laboratuvar şefi etiketlerde hata olduğunu "
            "düşünüyor.\n\n"
            "Etiketlere doğru tanecik sayılarını yazmamız gerekiyor -- önce "
            "atomun kendisi, sonra numunede bulunan iyonu için."
        ).format(ad, kisi),
        kanitlar=[
            Kanit("Element kartı",
                  "{} ({}) -- atom numarası: {}, kütle numarası: {}"
                  .format(ad.capitalize(), sembol, z, a),
                  bedel=1, kritik=True),
            Kanit("Numune analizi",
                  "Numunedeki {} {} iyonu hâlinde bulunuyor ({} yüklü)."
                  .format(ad, iyon, yuk_metni),
                  bedel=1, kritik=True),
            Kanit("Asistanın etiketi",
                  "{} iyonu -- proton sayısı: {}".format(iyon, elektron),
                  bedel=1, kritik=True),
            Kanit("Tanım notu",
                  "Atom numarası = proton sayısı.\n"
                  "Kütle numarası = proton sayısı + nötron sayısı.\n"
                  "Nötr atomda elektron sayısı proton sayısına eşittir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir atom iyon oluşturduğunda hangi tanecik sayısı değişir?",
                dogru=("Yalnız elektron sayısı; çekirdekteki proton ve nötron "
                       "aynı kalır"),
                yanlislar={
                    ("Proton sayısı, iyonun yükü kadar değişir; artı yük fazladan "
                     "protondan gelir"):
                        "İyon oluşurken çekirdeğin değiştiğini sandın. Yük, "
                        "elektron alıp vermekten gelir; çekirdeğe dokunulmaz.",
                    "Proton ve elektron sayısı birlikte değişir":
                        "İkisi birlikte değişseydi atom nötr kalırdı ve yük "
                        "oluşmazdı. Yük tam da proton ile elektron sayısının "
                        "EŞİT OLMAMASINDAN gelir.",
                    ("Kütle numarası, iyonun yükü kadar değişir; alınan ya da "
                     "verilen tanecik kütleyi değiştirir"):
                        "Kütle numarası proton + nötrondur; ikisi de çekirdekte. "
                        "İyon oluşurken çekirdek değişmediği için kütle numarası "
                        "da değişmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kimyasal olaylarda yalnız elektronlar yer değiştirir. Proton "
                    "sayısı değişseydi ortaya BAŞKA BİR ELEMENT çıkardı -- çünkü "
                    "elementi belirleyen şey proton sayısıdır. Bu yüzden "
                    "{} ile {} aynı elementtir."
                ).format(sembol, iyon),
                ipuclari=[
                    "Elementi ne belirler? O değişirse ne olur?",
                    "Yük nereden geliyor: çekirdekten mi, elektronlardan mı?",
                ],
                cozum=(
                    "İyon oluşumu = elektron alıp vermek.\n"
                    "Proton ve nötron sayısı değişmez.\n"
                    "Elektron sayısı = proton sayısı - yük."
                ),
            ),
            sayi_adimi(
                soru="{} atomunun çekirdeğinde kaç nötron vardır?".format(sembol),
                cevap=notron,
                birim="nötron",
                aciklama="Nötron = kütle numarası - atom numarası = {} - {} = {}."
                         .format(a, z, notron),
                yaygin_yanlislar={
                    a:
                        "Kütle numarasını nötron sayısı sandın. Kütle numarası "
                        "proton ile nötronun TOPLAMI.",
                    z:
                        "Atom numarasını yazdın; o proton sayısı. Nötron için "
                        "kütle numarasından çıkarman gerekiyor.",
                    a + z:
                        "Topladın; ama kütle numarası zaten protonları içeriyor. "
                        "Çıkarman gerekiyor.",
                },
                ipuclari=["Kütle numarası = proton + nötron."],
                puan=12,
            ),
            sayi_adimi(
                soru="Numunedeki {} iyonunda kaç elektron vardır?".format(iyon),
                cevap=elektron,
                birim="elektron",
                aciklama=(
                    "Nötr {} atomunda {} elektron var. {} yüklü iyon, {} elektron "
                    "{} için {} elektronludur."
                ).format(sembol, z, yuk_metni, abs(yuk), hareket, elektron),
                yaygin_yanlislar={
                    z:
                        "Nötr atomun elektron sayısını yazdın; iyonun yükünü "
                        "hesaba katmadın.",
                    z + yuk:
                        "Yükün yönünü ters çevirdin. Pozitif iyon elektron "
                        "VERMİŞTİR, negatif iyon elektron ALMIŞTIR.",
                },
                ipuclari=["Pozitif yük elektron kaybından, negatif yük elektron kazancından gelir."],
                puan=12,
            ),
            yorum_adimi(
                soru=("Asistan {} iyonunun proton sayısını {} yazmış. Etiket "
                      "doğru mu?").format(iyon, elektron),
                dogru=("Hayır: çekirdek değişmez, proton sayısı yine {}; yazılan "
                       "sayı elektron sayısı").format(z),
                yanlislar={
                    "Evet: iyon {} elektron {} için proton sayısı da o kadar değişir."
                    .format(abs(yuk), hareket):
                        "İyon oluşurken çekirdeğin değiştiğini sandın. Proton "
                        "sayısı değişseydi {} başka bir element olurdu."
                        .format(sembol),
                    ("Evet: iyonun yükü değiştiği için atom numarası da değişir; "
                     "etiket yeni yükü gösteriyor."):
                        "Atom numarası proton sayısıdır ve elementin kimliğidir. "
                        "Yük değişse de element aynı; atom numarası aynı.",
                    ("Hayır: proton sayısı kütle numarasına ({}) eşittir; "
                     "çekirdekteki her tanecik protondur.").format(a):
                        "Hüküm doğru ama gerekçe yanlış. Kütle numarasını atom "
                        "numarasıyla karıştırdın; proton sayısı atom "
                        "numarasıdır ({}).".format(z),
                },
                rastgele=rastgele,
                aciklama=(
                    "Asistanın hatası iki yanılgının kesişiminde: iyonun yükünü "
                    "protona uygulamış, ve çıkan sayı tesadüfen iyonun elektron "
                    "sayısına eşit. Proton sayısı elementin kimliğidir; {} "
                    "atomu da {} iyonu da {} protonludur."
                ).format(sembol, iyon, z),
                puan=12,
            ),
        ],
        kapanis=("Düzeltilmiş etiket: {} iyonu -- {} proton, {} nötron, {} elektron."
                 ).format(iyon, z, notron, elektron),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# STOKİYOMETRİ: SINIRLAYICI GİRDİ (B37.13 -- müfredat haritası)
#
# `stokiyometri` (2018+2026, 10. sınıf) boştu. Bağlam: "İki girdili
# üretimde oluşabilecek ürün miktarını bulma". `yaygin_yanlis`:
#
#   "Katsayı oranını doğrudan kütle oranı sanmak; artan maddeyi unutmak."
#
# `denklestirme` görevi katsayıdan MOL oranını ölçüyor; bu görev bir adım
# ötesi: iki girdi, biri önce tükenir.
#
# YANILGININ VERİDEKİ KARŞILIĞI -- havuz her örnekte garanti ediyor:
#   * katsayıyı kütle gibi okuyan öğrenci (gram ÷ katsayı karşılaştırması)
#     YANLIŞ girdiyi sınırlayıcı seçer; ürünü de o girdiden hesaplar ve
#     bu sayı ayrı bir teşhis alır;
#   * artan maddeyi unutan öğrenci iki girdinin kütlesini toplar -- bu
#     sayı da ayrı teşhis alır ve doğru cevaptan hep farklıdır (artan > 0).
# ==========================================================================

# (ad, formül, mol kütlesi g/mol, katsayı) -- A + B -> C
_TEPKIMELER = (
    {"kod": "su", "denklem": "2H₂ + O₂ → 2H₂O",
     "A": ("hidrojen", "H₂", 2, 2), "B": ("oksijen", "O₂", 32, 1),
     "C": ("su", "H₂O", 18, 2),
     "baglam": "Üssün yakıt hücresi hidrojen ile oksijeni birleştirip içme "
               "suyu üretiyor. Gece vardiyası tanklarda kalan gazla ne kadar "
               "su çıkacağını bilmek istiyor."},
    {"kod": "fes", "denklem": "Fe + S → FeS",
     "A": ("demir tozu", "Fe", 56, 1), "B": ("kükürt tozu", "S", 32, 1),
     "C": ("demir sülfür", "FeS", 88, 1),
     "baglam": "Atölye, pil deneyi için demir tozu ile kükürt tozunu ısıtıp "
               "demir sülfür hazırlayacak. Rafta iki kavanoz var."},
    {"kod": "mgo", "denklem": "2Mg + O₂ → 2MgO",
     "A": ("magnezyum", "Mg", 24, 2), "B": ("oksijen", "O₂", 32, 1),
     "C": ("magnezyum oksit", "MgO", 40, 2),
     "baglam": "Fırın astarı için magnezyum oksit gerekiyor. Magnezyum "
               "talaşı kapalı bir hücrede oksijenle yakılacak."},
    {"kod": "nh3", "denklem": "N₂ + 3H₂ → 2NH₃",
     "A": ("azot", "N₂", 28, 1), "B": ("hidrojen", "H₂", 2, 3),
     "C": ("amonyak", "NH₃", 17, 2),
     "baglam": "Sera gübresi için küçük reaktörde azot ile hidrojenden "
               "amonyak üretilecek. İki gaz tüpü teslim edildi."},
    {"kod": "co2", "denklem": "C + O₂ → CO₂",
     "A": ("kömür (karbon)", "C", 12, 1), "B": ("oksijen", "O₂", 32, 1),
     "C": ("karbon dioksit", "CO₂", 44, 1),
     "baglam": "Seradaki bitkilerin büyümesi için havaya karbon dioksit "
               "verilecek. Kapalı bir yakma kabında kömür oksijenle yakılacak."},
)


def _stokiyometri_havuzu():
    """(tepkime sırası, mol_a, mol_b).

    Koşullar:
      1. Tam olarak bir girdi sınırlayıcı; ürün ve harcanan öbür girdi TAM
         mol; artan > 0.
      2. Gram ÷ katsayı karşılaştırması (yanılgı) ÖBÜR girdiyi seçer.
      3. Artan girdiden hesaplanan ürün tam sayı; doğru ürün, toplam kütle
         ve bu sayı üçü ayrışır.
      4. Her girdi en çok 600 g.
    Denklemlerin kendisi kütle korunumunu sağlamalı (test kilitliyor).
    """
    havuz = []
    for sira, t in enumerate(_TEPKIMELER):
        _, _, m_a, k_a = t["A"]
        _, _, m_b, k_b = t["B"]
        _, _, m_c, k_c = t["C"]
        for mol_a in range(1, 13):
            for mol_b in range(1, 13):
                g_a, g_b = mol_a * m_a, mol_b * m_b
                if g_a > 600 or g_b > 600 or mol_a * k_b == mol_b * k_a:
                    continue
                a_sinirlar = mol_a * k_b < mol_b * k_a
                mol_s, k_s, mol_f, k_f = ((mol_a, k_a, mol_b, k_b) if a_sinirlar
                                          else (mol_b, k_b, mol_a, k_a))
                if (k_c * mol_s) % k_s or (k_f * mol_s) % k_s:
                    continue
                if g_a * k_b == g_b * k_a:
                    continue
                if (g_a * k_b < g_b * k_a) == a_sinirlar:
                    continue          # yanılgı da doğru girdiyi seçiyor
                if (k_c * mol_f) % k_f:
                    continue
                urun = k_c * mol_s // k_s * m_c
                fazladan = k_c * mol_f // k_f * m_c
                if len({urun, g_a + g_b, fazladan}) < 3:
                    continue
                havuz.append((sira, mol_a, mol_b))
    return tuple(havuz)


_STOKIYOMETRI = _stokiyometri_havuzu()


@bulmaca(ders="kimya", konu="stokiyometri", kademeler=(10, 13), agirlik=1.3)
def sinirlayici_girdi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki girdili üretim: katsayılar mol oranıdır; ürünü önce tükenen girdi belirler."""
    sira = rastgele.choice(sorted({s for s, _, _ in _STOKIYOMETRI}))
    _, mol_a, mol_b = rastgele.choice([h for h in _STOKIYOMETRI if h[0] == sira])
    t = _TEPKIMELER[sira]
    ad_a, f_a, m_a, k_a = t["A"]
    ad_b, f_b, m_b, k_b = t["B"]
    ad_c, f_c, m_c, k_c = t["C"]
    g_a, g_b = mol_a * m_a, mol_b * m_b

    a_sinirlar = mol_a * k_b < mol_b * k_a
    if a_sinirlar:
        s_ad, s_f, s_mol, s_k, s_g = ad_a, f_a, mol_a, k_a, g_a
        e_ad, e_f, e_mol, e_k, e_g, e_m = ad_b, f_b, mol_b, k_b, g_b, m_b
    else:
        s_ad, s_f, s_mol, s_k, s_g = ad_b, f_b, mol_b, k_b, g_b
        e_ad, e_f, e_mol, e_k, e_g, e_m = ad_a, f_a, mol_a, k_a, g_a, m_a
    urun_mol = k_c * s_mol // s_k
    urun_g = urun_mol * m_c
    harcanan_e_mol = e_k * s_mol // s_k
    artan_mol = e_mol - harcanan_e_mol
    artan_g = artan_mol * e_m
    fazladan_g = k_c * e_mol // e_k * m_c
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    def buyuk(metin):
        return metin[:1].upper() + metin[1:]

    secenek_s = "{} ({})".format(buyuk(s_ad), s_f)
    secenek_e = "{} ({})".format(buyuk(e_ad), e_f)

    artan_yanlislari = {
        e_g: "Hiç harcanmamış gibi girdinin tamamını yazdın. Tepkime bu "
             "girdiden {} mol kullandı; artan, geriye kalan kısım."
             .format(harcanan_e_mol),
        0: "Artan maddeyi unuttun. Girdilerden biri önce tükenir; öbüründen "
           "kullanılmayan kısım kapta kalır.",
    }
    # Katsayıyı kütle gibi okuyan: harcanan = sınırlayıcı gram × katsayı oranı
    if (s_g * e_k) % s_k == 0:
        kutle_gibi = e_g - s_g * e_k // s_k
        if kutle_gibi > 0 and kutle_gibi not in artan_yanlislari and kutle_gibi != artan_g:
            artan_yanlislari[kutle_gibi] = (
                "Katsayı oranını kütle oranı sandın: harcanan gramı katsayılardan "
                "hesapladın. Katsayılar mol oranı; harcanan mol, mol kütlesiyle "
                "grama çevrilir.")

    return Bulmaca(
        kod="kim-sinirlayici-girdi",
        ders="kimya",
        baslik="Sınırlayıcı Girdi",
        kademe=kademe,
        konu="stokiyometri",
        kazanim="Denkleştirilmiş denklemde katsayıları mol oranı olarak kullanma; "
                "sınırlayıcı girdiyi, oluşan ürünü ve artan maddeyi hesaplama.",
        dikkat=7,
        brifing=(
            "{}\n\n"
            "{} kısa yoldan hesapladı: \"Katsayılar kütle oranını verir. Gram "
            "başına bakınca önce {} biter; daha çok ürün için ondan "
            "eklemeliyiz.\"\n\n"
            "Üretime başlamadan önce ne kadar {} çıkacağını, kapta ne kalacağını "
            "ve hangi girdinin üretimi sınırladığını bulmamız gerekiyor."
        ).format(t["baglam"], kisi, e_ad, ad_c),
        kanitlar=[
            Kanit("Tepkime kartı",
                  "Denkleştirilmiş denklem: {}".format(t["denklem"]),
                  bedel=1, kritik=True),
            Kanit("Stok sayımı",
                  "{} ({}): {} g\n{} ({}): {} g".format(buyuk(ad_a), f_a, g_a, buyuk(ad_b), f_b, g_b),
                  bedel=1, kritik=True),
            Kanit("Mol kütleleri",
                  "{}: {} g/mol\n{}: {} g/mol\n{}: {} g/mol".format(
                      f_a, m_a, f_b, m_b, f_c, m_c),
                  bedel=1, kritik=True),
            Kanit("Önceki üretim kaydı",
                  "Geçen üretimde tepkime bittiğinde kapta tepkimeye girmemiş bir "
                  "miktar girdi kaldı. Nedeni kayda geçmemiş.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Denkleştirilmiş denklemdeki katsayılar neyin oranını verir?",
                dogru=("Mol (tanecik) sayılarının oranını; kütle için her mol "
                       "sayısı mol kütlesiyle çarpılır"),
                yanlislar={
                    "Kütlelerin oranını: katsayısı büyük olan maddeden daha çok gram gerekir":
                        "Katsayı oranını kütle oranı sandın. Katsayılar tanecik "
                        "sayar; bir mol maddelerin kütlesi farklı olduğu için "
                        "eşit katsayı eşit gram demek değildir.",
                    ("Hacimlerin oranını; gazlarda böyle olduğu için katı ve sıvı "
                     "maddelerde de geçerlidir"):
                        "Katsayıları hacim oranı olarak okumak yalnız aynı "
                        "koşullardaki gazlarda geçerlidir; katıda değil.",
                    "Hiçbir şeyin; katsayılar yalnız atom sayısını eşitlemek için yazılır":
                        "Denkleştirme atomları korur, ama ortaya çıkan katsayılar "
                        "tepkimeye giren tanecik sayılarının oranını da verir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{} denklemi tanecik sayısıyla okunur. Hangi girdinin önce "
                    "biteceğini bulmak için gramlar önce mole çevrilir (gram ÷ "
                    "mol kütlesi), sonra katsayılarla karşılaştırılır."
                ).format(t["denklem"]),
                ipuclari=[
                    "Bir mol {} ile bir mol {} aynı kütlede mi?".format(f_a, f_b),
                    "Katsayı bir tanecik sayısı mı, bir kütle mi?",
                ],
                cozum=(
                    "mol = gram ÷ mol kütlesi\n"
                    "Her girdi için: mol ÷ katsayı\n"
                    "Küçük çıkan önce tükenir."
                ),
            ),
            secim_adimi(
                soru="Hangi girdi önce tükenir ve üretimi sınırlar?",
                dogru=secenek_s,
                yanlislar={
                    secenek_e:
                        "Katsayıları kütle oranı gibi okudun: gramları "
                        "katsayılara bölüp karşılaştırdın. Karşılaştırma MOL ile "
                        "yapılır; önce gramı mol kütlesine böl.",
                    "İkisi aynı anda tükenir":
                        "Aynı anda tükenmeleri için mol sayılarının oranı "
                        "katsayıların oranına tam eşit olmalı; burada değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{}: {} g ÷ {} g/mol = {} mol; {}: {} g ÷ {} g/mol = {} mol. "
                    "Denkleme göre {} mol {} için {} mol {} gerekir, elde {} mol "
                    "var. Önce tükenen: {}."
                ).format(f_a, g_a, m_a, mol_a, f_b, g_b, m_b, mol_b,
                         s_mol, s_f, harcanan_e_mol, e_f, e_mol, s_f),
                ipuclari=["İki girdiyi de mole çevir; sonra her birini kendi katsayısına böl."],
                puan=12,
            ),
            sayi_adimi(
                soru="Kaç gram {} ({}) oluşur?".format(ad_c, f_c),
                cevap=urun_g,
                birim="g",
                aciklama=(
                    "Ürünü önce tükenen girdi belirler: {} mol {} -> {} mol {}. "
                    "{} mol × {} g/mol = {} g."
                ).format(s_mol, s_f, urun_mol, f_c, urun_mol, m_c, urun_g),
                yaygin_yanlislar={
                    g_a + g_b:
                        "İki girdinin kütlesini topladın; hepsinin tepkimeye "
                        "girdiğini varsaydın. Artan madde ürüne katılmaz.",
                    fazladan_g:
                        "Ürünü artan girdiden hesapladın. O girdinin bir kısmı "
                        "eşi tükendiği için tepkimeye giremiyor.",
                },
                ipuclari=["Önce tükenen girdinin mol sayısından, katsayı oranıyla ürün molüne geç."],
                puan=14,
            ),
            sayi_adimi(
                soru="Tepkime bittiğinde kapta kaç gram {} ({}) kalır?".format(e_ad, e_f),
                cevap=artan_g,
                birim="g",
                aciklama=(
                    "Harcanan: {} mol. Kalan: {} − {} = {} mol. {} mol × {} g/mol "
                    "= {} g. Kontrol: {} + {} = {} + {} (kütle korunur)."
                ).format(harcanan_e_mol, e_mol, harcanan_e_mol, artan_mol,
                         artan_mol, e_m, artan_g, g_a, g_b, urun_g, artan_g),
                yaygin_yanlislar=artan_yanlislari,
                ipuclari=["Bu girdiden tepkimede kaç mol harcandığını bul, elindekinden çıkar."],
                puan=12,
            ),
            yorum_adimi(
                soru="Daha çok {} gerekiyor. Hangi girdiden eklemek üretimi artırır?".format(ad_c),
                dogru=("{}: üretimi o sınırlıyor; öbür girdiden zaten artan "
                       "kalıyor").format(secenek_s),
                yanlislar={
                    ("{}: gram başına bakınca önce o bitiyor; gramı az olan girdi "
                     "üretimi sınırlar").format(secenek_e):
                        "Katsayıları kütle gibi okuyan hesap bu. Bu girdiden kapta "
                        "{} g artıyor; eklemek yalnız artanı büyütür.".format(artan_g),
                    "İkisinden eşit gram":
                        "Eşit gram eşit mol değildir. Ürünü artırmak için eksik "
                        "olan girdiyi eklemek yeter; öbürü zaten fazla.",
                    "Hiçbirinden: artan girdi beklerse zamanla tepkimeye girer":
                        "Artan girdi tepkimeye giremez, çünkü eşi tükendi. "
                        "Beklemek ürünü artırmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{} tükenince tepkime durur ve {} g {} kapta kalır. Ürünü "
                    "artırmanın yolu sınırlayıcı girdiyi eklemektir. {} haklı "
                    "değildi: katsayılar kütle oranı değil, mol oranı."
                ).format(s_f, artan_g, e_f, kisi),
                puan=10,
            ),
        ],
        kapanis=("Rapor: {} g {} çıkacak ve kapta {} g {} kalacak. Sonraki "
                 "sipariş {} için yazıldı."
                 ).format(urun_g, f_c, artan_g, e_f, s_ad),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# PERİYODİK SİSTEM: GRUPTA NE AYNI, NE DEĞİŞİR? (B37.13 -- müfredat haritası)
#
# `periyodik_sistem` ÜÇ satırda boştu (2018: 9, 11; 2026: 9). Bağlam:
# "Atölye element kartlarını özelliklerine göre düzenleme". `yaygin_yanlis`:
#
#   "Bir grupta bütün özelliklerin aynı olduğunu sanmak."
#
# DÜZENEK: aynı gruptan alt alta üç element kartı; ortadaki yarım kalmış ve
# asistan onu ÜSTTEKİ kartın değerleriyle doldurmuş. Değerlik elektronu ve
# iyon yükü gerçekten kopyalanabilir; proton sayısı ve erime noktası
# kopyalanamaz.
#
# ÜÇLÜLER, erime noktası grup boyunca TEKDÜZE değişenlerden seçildi; ortadaki
# elementin erime noktası komşularının ARASINA düşer ve bu, eğilimden
# çıkarılabilir. (2. grup Be-Mg-Ca bilerek yok: Mg'nin erime noktası iki
# komşusundan da düşük, eğilim tekdüze değil.)
# ==========================================================================

# (ad, sembol, proton sayısı, erime noktası °C) -- yukarıdan aşağıya
_GRUP_UCLULERI = (
    {"grup": 1, "degerlik": 1, "iyon": "+1",
     "elementler": (("lityum", "Li", 3, 180.5), ("sodyum", "Na", 11, 97.8),
                    ("potasyum", "K", 19, 63.5))},
    {"grup": 1, "degerlik": 1, "iyon": "+1",
     "elementler": (("sodyum", "Na", 11, 97.8), ("potasyum", "K", 19, 63.5),
                    ("rubidyum", "Rb", 37, 39.3))},
    {"grup": 17, "degerlik": 7, "iyon": "−1",
     "elementler": (("flor", "F", 9, -219.6), ("klor", "Cl", 17, -101.5),
                    ("brom", "Br", 35, -7.2))},
    {"grup": 17, "degerlik": 7, "iyon": "−1",
     "elementler": (("klor", "Cl", 17, -101.5), ("brom", "Br", 35, -7.2),
                    ("iyot", "I", 53, 113.7))},
    {"grup": 16, "degerlik": 6, "iyon": "−2",
     "elementler": (("oksijen", "O", 8, -218.8), ("kükürt", "S", 16, 115.2),
                    ("selenyum", "Se", 34, 220.8))},
)

# Çoklu seçim şıkları: (metin, grup boyunca aynı mı)
_GRUP_OZELLIKLERI = (
    ("Değerlik elektron sayısı", True),
    ("Oluşturduğu iyonun yükü", True),
    ("Proton sayısı", False),
    ("Atom yarıçapı", False),
    ("Erime noktası", False),
    ("Birinci iyonlaşma enerjisi", False),
)


def _buyuk_harfle(ad):
    """Türkçe baş harf: "iyot" -> "İyot" (str.capitalize "Iyot" yapar)."""
    return ("İ" if ad[:1] == "i" else ad[:1].upper()) + ad[1:]


def _derece(deger):
    return "{} °C".format(sy(deger).replace("-", "−"))


@bulmaca(ders="kimya", konu="periyodik_sistem", kademeler=(9, 13), agirlik=1.3)
def element_kartlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı grupta değerlik elektronu ve iyon yükü ortak; diğer özellikler değişir."""
    uclu = rastgele.choice(_GRUP_UCLULERI)
    (ad_u, s_u, z_u, e_u), (ad_o, s_o, _, e_o), (ad_a, s_a, z_a, e_a) = uclu["elementler"]
    grup, degerlik, iyon = uclu["grup"], uclu["degerlik"], uclu["iyon"]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    sira = list(range(len(_GRUP_OZELLIKLERI)))
    rastgele.shuffle(sira)
    ozellikler = [_GRUP_OZELLIKLERI[i][0] for i in sira]
    ayni = [n for n, i in enumerate(sira) if _GRUP_OZELLIKLERI[i][1]]

    def kart(ad, sembol, z, erime):
        return ("{} ({}) -- {}. grup. Proton sayısı: {}. Değerlik elektronu: {}. "
                "İyon yükü: {}. Erime noktası: {}.").format(
                    _buyuk_harfle(ad), sembol, grup, z, degerlik, iyon, _derece(erime))

    return Bulmaca(
        kod="kim-element-kartlari",
        ders="kimya",
        baslik="Element Kartları",
        kademe=kademe,
        konu="periyodik_sistem",
        kazanim="Aynı gruptaki elementlerin ortak özelliklerini (değerlik elektronu, "
                "iyon yükü) grup boyunca değişen özelliklerden ayırt etme; eğilimden "
                "tahmin yapma.",
        dikkat=7,
        brifing=(
            "Atölyenin element panosunda aynı gruptan üç kart alt alta asılı. "
            "Ortadaki kart yıllar önce ıslanmış, değerleri okunmuyor.\n\n"
            "{} kartı kurşun kalemle doldurdu: \"Aynı gruptalar, bütün "
            "özellikleri aynı. Üstteki kartın değerlerini aynen yazdım.\"\n\n"
            "Kart panoya geri asılmadan önce hangi değerlerin doğru olduğunu "
            "bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Üstteki kart", kart(ad_u, s_u, z_u, e_u), bedel=1, kritik=True),
            Kanit("Alttaki kart", kart(ad_a, s_a, z_a, e_a), bedel=1, kritik=True),
            Kanit("Ortadaki kart",
                  "{} ({}) -- {}. grup. Kurşun kalemle: proton sayısı {}, değerlik "
                  "elektronu {}, iyon yükü {}, erime noktası {}.".format(
                      _buyuk_harfle(ad_o), s_o, grup, z_u, degerlik, iyon, _derece(e_u)),
                  bedel=1, kritik=True),
            Kanit("Periyodik tablo notu",
                  "Grup numarası, dış kabuktaki (değerlik) elektron düzenini "
                  "gösterir. Grupta aşağı inildikçe elektron katmanı sayısı artar.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Aynı gruptaki elementler için hangisi doğrudur?",
                dogru=("Değerlik elektron sayıları aynı, tepkimeleri benzerdir; "
                       "atom büyüklüğü ve erime noktası grupta değişir"),
                yanlislar={
                    ("Bütün özellikleri aynıdır; aynı sütunda olmalarının sebebi "
                     "budur, birinin erime noktasını bilen hepsini bilir"):
                        "Bir grupta bütün özelliklerin aynı olduğunu sandın. "
                        "Ortak olan dış kabuk düzeni; katman sayısı arttıkça "
                        "büyüklük ve erime noktası değişir. Üstteki ile alttaki "
                        "kartın erime noktaları bile farklı.",
                    "Proton sayıları aynıdır; değerlik elektron sayıları farklıdır":
                        "Tersi: proton sayısı her elementte farklıdır, grubu "
                        "belirleyen değerlik elektron sayısıdır.",
                    "Hiçbir özellikleri ortak değildir; grup yalnızca bir sıra numarasıdır":
                        "Grup numarası dış kabuk düzenini gösterir; kartlardaki "
                        "değerlik elektronu ve iyon yükü bunu doğruluyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı gruptaki atomların dış kabuğunda aynı sayıda elektron "
                    "vardır; kimyasal davranışlarının benzerliği buradan gelir. "
                    "Ama her aşağı inişte bir elektron katmanı eklenir: atom büyür "
                    "ve fiziksel özellikler düzenli olarak değişir."
                ),
                ipuclari=[
                    "Üstteki ve alttaki kartta hangi değerler aynı, hangileri farklı?",
                    "Grup numarası neyi gösteriyor?",
                ],
                cozum=(
                    "Aynı: değerlik elektronu, iyon yükü.\n"
                    "Değişen: proton sayısı, yarıçap, erime noktası, iyonlaşma "
                    "enerjisi."
                ),
            ),
            coklu_adimi(
                soru=("Grup boyunca AYNI kalan özelliklerin hepsini seç "
                      "(numaraları virgülle yaz):"),
                secenekler=ozellikler,
                dogru_indeksler=ayni,
                aciklama=(
                    "Aynı kalan: değerlik elektron sayısı ({}) ve iyon yükü ({}). "
                    "Proton sayısı her elementte farklı; atom yarıçapı aşağı "
                    "doğru büyür; erime noktası ve iyonlaşma enerjisi düzenli "
                    "değişir."
                ).format(degerlik, iyon),
                ipuclari=["Üstteki ve alttaki kartı satır satır karşılaştır."],
                puan=14,
            ),
            secim_adimi(
                soru="Ortadaki elementin ({}) erime noktası için hangisi doğrudur?".format(s_o),
                dogru="{} ile {} arasındadır".format(_derece(e_u), _derece(e_a)),
                yanlislar={
                    "Üstteki kartla aynıdır: {}".format(_derece(e_u)):
                        "Bir grupta bütün özelliklerin aynı olduğunu sandın. "
                        "Üstteki ile alttaki kartın erime noktaları farklıysa "
                        "ortadaki ikisine birden eşit olamaz.",
                    "Alttaki kartla aynıdır: {}".format(_derece(e_a)):
                        "Grupta erime noktası değişiyor; alttaki kartınkini "
                        "kopyalamak da aynı hata.",
                    "İkisinin de dışında bir değerdir; grupta erime noktası bir düzene uymaz":
                        "Bu üç elementte erime noktası grup boyunca tek yönde "
                        "değişiyor; ortadaki elementin değeri komşularının "
                        "arasına düşer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Erime noktası bu üç elementte yukarıdan aşağıya düzenli "
                    "değişiyor: {} -> ? -> {}. Ortadakinin değeri ikisinin arasında; "
                    "gerçek değer {}."
                ).format(_derece(e_u), _derece(e_a), _derece(e_o)),
                ipuclari=["Üstten alta erime noktası artıyor mu, azalıyor mu?"],
                puan=12,
            ),
            yorum_adimi(
                soru="Ortadaki karttaki kurşun kalem değerleri için hangisi doğrudur?",
                dogru=("Değerlik elektronu ve iyon yükü doğru; grup boyunca değişen "
                       "proton sayısı ve erime noktası yanlış"),
                yanlislar={
                    "Hepsi doğru: aynı gruptaki elementlerin bütün özellikleri aynıdır":
                        "Bir grupta bütün özelliklerin aynı olduğunu sandın. İki "
                        "farklı elementin proton sayısı aynı olamaz.",
                    "Hepsi yanlış: değerlik elektronu da grup boyunca değişir":
                        "Değerlik elektron sayısı grubu belirler; üstteki ve "
                        "alttaki kartta aynı.",
                    ("Yalnız erime noktası yanlış; proton sayısı grupta aynıdır, "
                     "sütun zaten aynı proton sayısını gösterir"):
                        "Proton sayısı elementin kimliğidir; {} ile {} aynı "
                        "sayıda protona sahip olamaz.".format(s_u, s_o),
                },
                rastgele=rastgele,
                aciklama=(
                    "Kopyalanabilen yalnız grubu tanımlayan değerler: {} değerlik "
                    "elektronu ve {} iyon yükü. {} ile {} farklı elementler; proton "
                    "sayıları da, erime noktaları da farklı."
                ).format(degerlik, iyon, s_u, s_o),
                puan=10,
            ),
        ],
        kapanis=("Kart düzeltildi: {} değerlik elektronu ve {} iyon yükü yerinde "
                 "kaldı; proton sayısı ve erime noktası ({}) yeniden yazıldı. Panoya "
                 "not düşüldü: \"Aynı grup, aynı dış kabuk -- aynı element değil.\""
                 ).format(degerlik, iyon, _derece(e_o)),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# GAZ YASALARI: KELVİN VE MUTLAK BASINÇ (B37.13 -- müfredat haritası)
#
# `gaz_yasalari` iki satırda boştu (2018: 11; 2026: 10). Bağlam: "Gaz
# numunesinin basınç-hacim-sıcaklık verisini modelleme". `yaygin_yanlis`:
#
#   "Sıcaklığı Celsius ile gaz denklemine koymak; mutlak basıncı ihmal etmek."
#
# DÜZENEK: sert (hacmi sabit) bir gaz tüpü güneşte ısınıyor. Manometre GÖSTERGE
# basıncı okur; mutlak basınç = gösterge + 100 kPa (atmosfer). Sabit hacimde
# P1/T1 = P2/T2, sıcaklık KELVİN, basınç MUTLAK.
#
# YANILGILARIN SAYISAL KARŞILIĞI: Celsius oranıyla hesap; gösterge basıncını
# mutlak sanmak; mutlak sonucu manometreye aynen yazmak. Havuz Celsius
# oranını tam sayı seçtiği için yanlış yolun sayısı da temiz çıkıyor.
# ==========================================================================

_ATMOSFER_KPA = 100


def _gaz_havuzu():
    """(t1_c, t2_c, p1_mutlak): °C, °C, kPa.

    Koşullar: t2_c / t1_c tam sayı (Celsius yanılgısının sayısı temiz); doğru P2
    tam sayı; gösterge temelli yanlış hesap en çok bir ondalık; üç sonuç farklı.
    """
    havuz = []
    for t1_c in (7, 27):
        t1_k = t1_c + 273
        for kat in (2, 3, 4):
            t2_c = t1_c * kat
            t2_k = t2_c + 273
            for p1 in (t1_k, 2 * t1_k):
                if (p1 * t2_k) % t1_k:
                    continue
                p2 = p1 * t2_k // t1_k
                gosterge_hesap10 = 10 * (p1 - _ATMOSFER_KPA) * t2_k
                if gosterge_hesap10 % t1_k:
                    continue
                celsius = p1 * kat
                if len({p2, celsius, gosterge_hesap10 / (10.0 * t1_k)}) < 3:
                    continue
                havuz.append((t1_c, t2_c, p1))
    return tuple(havuz)


_GAZ = _gaz_havuzu()


@bulmaca(ders="kimya", konu="gaz_yasalari", kademeler=(10, 13), agirlik=1.3)
def gaz_tupu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Gaz yasalarında sıcaklık kelvin, basınç mutlak basınçla kullanılır."""
    t1_c, t2_c, p1 = rastgele.choice(_GAZ)
    t1_k, t2_k = t1_c + 273, t2_c + 273
    p2 = p1 * t2_k // t1_k
    gosterge1 = p1 - _ATMOSFER_KPA
    gosterge2 = p2 - _ATMOSFER_KPA
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-gaz-tupu",
        ders="kimya",
        baslik="Gaz Tüpü",
        kademe=kademe,
        konu="gaz_yasalari",
        kazanim="Gaz yasalarında sıcaklığı kelvine, gösterge basıncını mutlak "
                "basınca çevirerek sabit hacimde basınç değişimini hesaplama.",
        dikkat=7,
        brifing=(
            "Güneşte bekleyen sert bir gaz tüpünün güvenlik sınırı manometrede "
            "denetlenecek.\n\n"
            "{} hesabı hızlıca yaptı: \"Sıcaklık {} °C iken güneşte {} °C olacak, yani {} "
            "katı. Manometre de {} kPa gösteriyordu; o da {} katına çıkar.\"\n\n"
            "Tüp güneşe çıkarılmadan önce doğru basıncı bulmamız gerekiyor."
        ).format(kisi, t1_c, t2_c, t2_c // t1_c, gosterge1, t2_c // t1_c),
        kanitlar=[
            Kanit("Tüp kaydı",
                  "Sert çelik tüp: hacim sabit. Başlangıç sıcaklığı {} °C; güneşte "
                  "{} °C olacak.".format(t1_c, t2_c),
                  bedel=1, kritik=True),
            Kanit("Manometre",
                  "Başlangıçta manometre {} kPa gösteriyor. Manometre gösterge "
                  "basıncı okur: atmosfer basıncının ({} kPa) üstündeki kısmı."
                  .format(gosterge1, _ATMOSFER_KPA),
                  bedel=1, kritik=True),
            Kanit("Gaz notu",
                  "Sabit hacimde P1 ÷ T1 = P2 ÷ T2. T kelvin (K = °C + 273); P mutlak "
                  "basınç (gösterge + atmosfer).",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Gaz yasası bu tüpe nasıl uygulanır?",
                dogru=("Sıcaklık kelvine, manometre değeri mutlak basınca "
                       "çevrilir; sonra P1 ÷ T1 = P2 ÷ T2"),
                yanlislar={
                    ("Celsius değerleri doğrudan kullanılır; ölçek fark etmez, "
                     "oranlar aynı çıkar"):
                        "Sıcaklığı Celsius ile gaz denklemine koydun. Sıcaklık 0 °C olunca "
                        "gazın basıncı sıfır olmaz; basınç kelvinle orantılıdır.",
                    ("Manometre değeri doğrudan kullanılır; atmosfer tüpün dışında "
                     "olduğu için hesaba girmez"):
                        "Mutlak basıncı ihmal ettin. Gazı sıkıştıran toplam basınç, "
                        "gösterge değerine atmosferin eklenmesiyle bulunur.",
                    ("Sıcaklık iki katına çıkınca basınç her birimde iki katına "
                     "çıkar; P ile T doğru orantılıdır"):
                        "Bu yalnız kelvin ölçeğinde doğrudur; Celsius sıfır noktası "
                        "gazın sıfır basıncı değildir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Gaz basıncı mutlak sıcaklıkla orantılıdır; Celsius ölçeğinin "
                    "sıfırı keyfidir. Basınçta da orantı gazın gerçek (mutlak) "
                    "basıncı için geçerlidir; manometre bunun atmosferin üstündeki "
                    "kısmını gösterir."
                ),
                ipuclari=[
                    "Sıcaklık 0 °C olunca bir gazın basıncı sıfır olur mu?",
                    "Manometre neyi okuyor?",
                ],
                cozum="T(K) = °C + 273\nP_mutlak = P_gösterge + 100\nP2 = P1 · T2 ÷ T1",
            ),
            sayi_adimi(
                soru="Tüpteki gazın başlangıçtaki mutlak basıncı kaç kPa?",
                cevap=p1,
                birim="kPa",
                aciklama="{} + {} = {} kPa.".format(gosterge1, _ATMOSFER_KPA, p1),
                yaygin_yanlislar={
                    gosterge1:
                        "Manometre değerini yazdın; mutlak basınç için atmosferi ekle.",
                },
                ipuclari=["Manometre kaydını oku."],
                puan=10,
            ),
            sayi_adimi(
                soru="Güneşte tüpteki mutlak basınç kaç kPa olur?",
                cevap=p2,
                birim="kPa",
                aciklama="T1 = {} K, T2 = {} K. P2 = {} × {} ÷ {} = {} kPa.".format(
                    t1_k, t2_k, p1, t2_k, t1_k, p2),
                yaygin_yanlislar={
                    p1 * (t2_c // t1_c):
                        "Sıcaklığı Celsius ile gaz denklemine koydun; basınç {} "
                        "katına çıkmaz, kelvin oranı çok daha küçük.".format(t2_c // t1_c),
                    sy(gosterge1 * t2_k / float(t1_k)).replace(",", "."):
                        "Mutlak basıncı ihmal ettin: gösterge değeriyle hesapladın.",
                },
                ipuclari=["Önce iki sıcaklığı da kelvine çevir."],
                puan=14,
            ),
            sayi_adimi(
                soru="Güneşte manometre kaç kPa gösterir?",
                cevap=gosterge2,
                birim="kPa",
                aciklama="{} − {} = {} kPa (gösterge).".format(p2, _ATMOSFER_KPA, gosterge2),
                yaygin_yanlislar={
                    p2:
                        "Mutlak basıncı manometreye yazdın; manometre atmosferin "
                        "üstündeki kısmı gösterir.",
                    gosterge1 * (t2_c // t1_c):
                        "Kişinin Celsius hesabını tekrarladın.",
                },
                ipuclari=["Mutlak basınçtan atmosferi çıkar."],
                puan=10,
            ),
        ],
        kapanis=("Hesap düzeltildi: güneşte mutlak basınç {} kPa, manometre {} kPa -- "
                 "\"{} katı\" değil. Sıcaklık kelvinle, basınç mutlak değerle."
                 ).format(p2, gosterge2, t2_c // t1_c),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# MOL: TANECİK SAYISI BİRİMİ (B37.13 -- müfredat haritası)
#
# `mol` iki satırda boştu (2018: 10; 2026: 10). Bağlam: "Depo numunesinin
# kütlesinden tanecik miktarına geçme". `yaygin_yanlis`:
#
#   "Molü kütle birimi sanmak; katsayıyla mol kütlesini karıştırmak."
#
# DÜZENEK: depo kavanozunda bir madde; yanında o maddenin geçtiği denklem
# kartı (ör. 2H₂ + O₂ → 2H₂O). Kütleden mole: n = m ÷ M; molden taneciğe:
# × 6,02 × 10²³. Denklemdeki katsayı mol ORANIDIR, mol kütlesini değiştirmez.
#
# YANILGILARIN SAYISAL KARŞILIĞI: mol sayısına gramı yazmak; mol kütlesini
# katsayıyla çarpıp bölmek; tanecik sayısında 1 mol varsaymak.
#
# İLK EKRAN DUVARI (B46.1, 30 Eylül 2026): kullanıcı 22 Eylül'de oyunu bu
# görevin İLK EKRANINDA kapattı. İlk ekranda aynı anda denklem, beş formül,
# "264 mol / 264 g" ve × 10²³ vardı (`--duvar` puanı 33,9; 290 görevde 3.).
# Giriş alçaltıldı, ölçülen ayrım AYNEN kaldı:
#   * giriş tanıdık benzetmeyle: yumurtayı düzineyle sayarız; tartıdaki gram
#     düzine sayısı değildir, bir düzinenin kütlesine bölünür (n = m ÷ M'nin
#     gündelik karşılığı). Formül (n = m ÷ M) açıklamaya ve çözüme kaldı.
#   * Avogadro sayısı (× 10²³) ilk gerektiği adımda, tanecik adımında gelir;
#     orada da × 10²³ YAZDIRILMAZ, "mol sayısı × Avogadro" işlemi SEÇİLİR.
#     Yanlış şıklar eski yaygın yanlışların aynısı (bir mollük sayı, gramı
#     mol sanmak) artı mol kütlesini paket sayısı sanmak.
#   * denklem kartı yalnız SON adımda, katsayı sorusunun içinde görünür.
# Değişmeyenler: mol sayısı hâlâ yazılarak bulunur (n = m ÷ M); katsayı
# adımının şıkları ve teşhisleri aynı; kazanım ve doğru cevaplar aynı.
# ==========================================================================

# (ad, formül, mol kütlesi g/mol, denklem, formülün denklemdeki katsayısı)
_MOL_MADDELERI = (
    ("su", "H₂O", 18, "2H₂ + O₂ → 2H₂O", 2),
    ("karbon dioksit", "CO₂", 44, "C₃H₈ + 5O₂ → 3CO₂ + 4H₂O", 3),
    ("amonyak", "NH₃", 17, "N₂ + 3H₂ → 2NH₃", 2),
    ("oksijen", "O₂", 32, "C₃H₈ + 5O₂ → 3CO₂ + 4H₂O", 5),
)
_AVOGADRO_KAT = 6.02    # × 10²³
_AVOGADRO = "6,02 × 10²³"
# Düzine benzetmesi (brifing): bir düzine yumurta ~720 g (yumurta başına ~60 g).
_DUZINE_KUTLE = 720
_DUZINE_TARTI = 1440


@bulmaca(ders="kimya", konu="mol", kademeler=(10, 13), agirlik=1.3)
def numune_kavanozu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Mol tanecik sayısı birimidir: n = m ÷ M; katsayı mol kütlesini değiştirmez."""
    ad, formul, mol_kutle, denklem, kats = rastgele.choice(_MOL_MADDELERI)
    mol = rastgele.choice((2, 3, 4, 5, 6))
    kutle = mol * mol_kutle
    tanecik = round(mol * _AVOGADRO_KAT, 2)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    mol_yanlislari = {
        kutle: "Molü kütle birimi sandın: gramı mol diye yazdın. Mol bir tanecik "
               "sayısı birimidir; kütleyi mol kütlesine böl.",
        kutle * mol_kutle: "Böleceğin yerde çarptın: n = m ÷ M.",
    }
    if (mol * 100) % kats == 0:
        mol_yanlislari[sy(mol / float(kats)).replace(",", ".")] = (
            "Katsayıyla mol kütlesini karıştırdın: mol kütlesini denklemdeki {} ile "
            "çarptın. {} maddesinin mol kütlesi her yerde {} g/mol; katsayı yalnız "
            "tepkimedeki mol oranını verir.".format(kats, formul, mol_kutle))

    def carpim(carpan: str, sonuc: float) -> str:
        return "{} × {} = {} × 10²³ molekül".format(carpan, _AVOGADRO, sy(sonuc))

    return Bulmaca(
        kod="kim-numune-kavanozu",
        ders="kimya",
        baslik="Numune Kavanozu",
        kademe=kademe,
        konu="mol",
        kazanim="Kütleden mol sayısına ve tanecik sayısına geçme; denklem "
                "katsayısını mol kütlesinden ayırt etme.",
        dikkat=7,
        brifing=(
            "Depo rafındaki bir kavanozda {} var. Deney ekibi kavanozda kaç "
            "tanecik olduğunu bilmek istiyor.\n\n"
            "{} etikete \"Kavanozda {} mol {} var\" yazmış; oysa {} sayısı "
            "tartının gösterdiği gram. Etiket yapıştırılmadan önce hesabı "
            "düzeltmemiz gerekiyor.\n\n"
            "Tanıdık bir örnek: yumurtaları tek tek saymayız, düzineyle sayarız. "
            "Bir düzine 12 yumurtadır ve yaklaşık {} gram gelir. Tartı {} gram "
            "gösteriyorsa kasada {} düzine değil, {} düzine yumurta vardır. "
            "Kimyacılar da gözle görülmeyecek kadar küçük tanecikleri paketle "
            "sayar; bu paketin adı mol."
        ).format(ad, kisi, kutle, ad, kutle, _DUZINE_KUTLE, _DUZINE_TARTI,
                 _DUZINE_TARTI, _DUZINE_TARTI // _DUZINE_KUTLE),
        kanitlar=[
            Kanit("Tartı", "Kavanozdaki {}: {} g.".format(ad, kutle),
                  bedel=1, kritik=True),
            Kanit("Mol kütlesi",
                  "{} ({}): {} g/mol. Yani 1 mol {} {} gramdır.".format(
                      ad.capitalize(), formul, mol_kutle, ad, mol_kutle),
                  bedel=1, kritik=True),
            Kanit("Mol notu",
                  "Mol, düzine gibi bir sayma paketidir. Kaç mol olduğunu bulmak "
                  "için kütle, bir molün kütlesine (mol kütlesine) bölünür.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Etiketi düzeltmeden önce {} ile anlaşalım: mol neyi "
                     "anlatır?".format(kisi),
                dogru="Mol tanecik sayısı birimidir; kütle, mol kütlesine bölünerek mole çevrilir",
                yanlislar={
                    "Mol bir kütle birimidir: kavanozda kaç gram varsa o kadar mol vardır, bölmeye gerek yok":
                        "Molü kütle birimi sandın. Gram kütleyi, mol tanecik sayısını "
                        "anlatır; aradaki köprü mol kütlesidir.",
                    "Denklemdeki katsayı maddenin mol kütlesini verir; katsayı büyüdükçe madde ağırlaşır":
                        "Katsayıyla mol kütlesini karıştırdın. Katsayı tepkimedeki "
                        "mol oranıdır; mol kütlesi maddenin kendi özelliğidir.",
                    "Mol bir hacim birimidir; her maddenin bir molü aynı hacmi kaplar":
                        "Aynı hacim yalnız aynı koşuldaki gazlar için geçerlidir; mol "
                        "tanecik sayısıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Mol, çok sayıda taneciği saymanın birimidir: tıpkı 'düzine' gibi, "
                    "ama bir molde {} tanecik vardır. Farklı maddelerin bir molü farklı "
                    "kütlededir; bu kütle mol kütlesidir. Kütleden mole: n = m ÷ M."
                ).format(_AVOGADRO),
                ipuclari=[
                    "Yumurtayı düşün: tartıdaki gram, düzine sayısı değildir; "
                    "önce bir düzinenin kütlesine böleriz.",
                    "Mol de düzine gibi tane sayan bir pakettir; kütle birimi değildir.",
                    "Katsayı bir oran mı, kütle mi?",
                ],
                cozum="n = m ÷ M\nTanecik = n × {}".format(_AVOGADRO),
            ),
            sayi_adimi(
                soru="Kavanozda kaç mol {} var?".format(ad),
                cevap=mol,
                birim="mol",
                aciklama="{} g ÷ {} g/mol = {} mol.".format(kutle, mol_kutle, mol),
                yaygin_yanlislar=mol_yanlislari,
                ipuclari=["Yumurtada toplam gramı bir düzinenin gramına bölerdik; "
                          "burada da tartıyı bir molün gramına böl.",
                          "Tartıyı mol kütlesine böl."],
                puan=12,
            ),
            secim_adimi(
                soru=("Bir mol paketinde {} tanecik vardır; bu sayıya Avogadro "
                      "sayısı denir. Kavanozdaki molekül sayısını hangi işlem "
                      "verir?").format(_AVOGADRO),
                dogru=carpim("{} mol".format(mol), tanecik),
                yanlislar={
                    carpim("1 mol", _AVOGADRO_KAT):
                        "Bir mollük tanecik sayısını yazdın; kavanozda {} mol var."
                        .format(mol),
                    carpim("{} g".format(kutle), round(kutle * _AVOGADRO_KAT, 2)):
                        "Gramı mol sanıp {} ile çarptın; önce mole çevir."
                        .format(_AVOGADRO),
                    carpim("{} g/mol".format(mol_kutle),
                           round(mol_kutle * _AVOGADRO_KAT, 2)):
                        "Mol kütlesi bir molün gramıdır, paket sayısı değil. "
                        "Kavanozda {} paket, yani {} mol var.".format(mol, mol),
                },
                rastgele=rastgele,
                aciklama="{} mol × {} = {} × 10²³ molekül.".format(
                    mol, _AVOGADRO, sy(tanecik)),
                ipuclari=["Paket sayısını paketteki tane sayısıyla çarp: "
                          "kasadaki 2 düzine, 2 × 12 yumurta eder.",
                          "Kavanozda kaç mol olduğunu bir önceki adımda buldun."],
                puan=12,
            ),
            secim_adimi(
                soru=("Son iş denklem kartında. Deneyde kullanılacak tepkime: {}. "
                      "{} bu karta bakıp etikete \"mol kütlesi {} katı\" diye "
                      "eklemiş. \"{}{}\" ifadesindeki {} neyi anlatır?").format(
                    denklem, kisi, kats, kats, formul, kats),
                dogru=("Tepkimeye {} mol oranında girdiğini; mol kütlesi yine {} g/mol"
                       .format(kats, mol_kutle)),
                yanlislar={
                    "{} maddesinin mol kütlesinin {} katına, yani {} g/mol değerine çıktığını".format(
                        formul, kats, kats * mol_kutle):
                        "Katsayıyla mol kütlesini karıştırdın; katsayı yalnız mol "
                        "oranını değiştirir.",
                    "Kavanozda {} gram {} olduğunu; katsayı tartının gösterdiği kütledir".format(kats, formul):
                        "Katsayı gram değil; kütle tartıda yazılı.",
                    "{} maddesinin mol kütlesinin {} g/mol olduğunu".format(formul, kats):
                        "Mol kütlesi ayrı kartta yazılı; katsayı bir oran.",
                },
                rastgele=rastgele,
                aciklama=("Katsayı, tepkimeye giren ve çıkan maddelerin mol oranını "
                          "verir. {} maddesinin mol kütlesi hangi denklemde olursa "
                          "olsun {} g/mol.").format(formul, mol_kutle),
                ipuclari=["Mol kütlesi kartı ile denklem kartını karşılaştır.",
                          "Tartı değişmedi; mol kütlesi maddenin kendi özelliğidir."],
                puan=12,
            ),
        ],
        kapanis=("Etiket düzeltildi: {} g {} = {} mol = {} × 10²³ molekül. Katsayı "
                 "mol kütlesini değiştirmez."
                 ).format(kutle, formul, mol, sy(tanecik)),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# ENTALPİ: BAĞ KIRMAK ENERJİ İSTER (B37.13 -- müfredat haritası)
#
# `entalpi` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Üs üretim
# modelinin enerji bilançosunu kurma". `yaygin_yanlis`:
#
#   "Bağ kırılmasının enerji verdiğini sanmak; işaretleri ters kullanmak."
#
# DÜZENEK: üs üretim hattında bir tepkime; bağ enerjisi tablosu. Bağ kırmak
# enerji İSTER, bağ oluşurken enerji AÇIĞA ÇIKAR:
# ΔH = Σ(kırılan bağlar) − Σ(oluşan bağlar). Havuzda ısı veren ve ısı alan
# (ayrışma) tepkimeler var; işareti tahminle bulmak işe yaramaz.
#
# YANILGILARIN SAYISAL KARŞILIĞI: kırılan bağların toplamını kazanç saymak
# (−Σkırılan); iki toplamı da açığa çıkan enerji saymak (−(Σk + Σo));
# işareti ters kullanmak (Σo − Σk); katsayıları unutmak.
# ==========================================================================

_BAG_ENERJISI = {   # kJ/mol
    "H–H": 436, "Cl–Cl": 243, "H–Cl": 432, "F–F": 158, "H–F": 568,
    "Br–Br": 193, "H–Br": 366, "O=O": 498, "O–H": 463, "N≡N": 945, "N–H": 391,
}
# (denklem, kırılan bağlar ((bağ, adet), ...), oluşan bağlar)
_ENTALPI_TEPKIMELERI = (
    ("H₂ + Cl₂ → 2HCl", (("H–H", 1), ("Cl–Cl", 1)), (("H–Cl", 2),)),
    ("H₂ + F₂ → 2HF", (("H–H", 1), ("F–F", 1)), (("H–F", 2),)),
    ("H₂ + Br₂ → 2HBr", (("H–H", 1), ("Br–Br", 1)), (("H–Br", 2),)),
    ("2H₂ + O₂ → 2H₂O", (("H–H", 2), ("O=O", 1)), (("O–H", 4),)),
    ("N₂ + 3H₂ → 2NH₃", (("N≡N", 1), ("H–H", 3)), (("N–H", 6),)),
    ("2H₂O → 2H₂ + O₂", (("O–H", 4),), (("H–H", 2), ("O=O", 1))),
    ("2NH₃ → N₂ + 3H₂", (("N–H", 6),), (("N≡N", 1), ("H–H", 3))),
)


def _isaretli(sayi):
    """ΔH gösterimi: 185 -> +185, -185 -> −185."""
    return ("+" if sayi > 0 else "−") + str(abs(sayi))


@bulmaca(ders="kimya", konu="entalpi", kademeler=(11, 13), agirlik=1.3)
def enerji_bilancosu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bağ kırmak enerji ister, bağ oluşumu enerji verir: ΔH = Σkırılan − Σoluşan."""
    denklem, kirilan, olusan = rastgele.choice(_ENTALPI_TEPKIMELERI)
    tur = rastgele.choice((2, 3, 4))
    kir_top = sum(_BAG_ENERJISI[b] * n for b, n in kirilan)
    olu_top = sum(_BAG_ENERJISI[b] * n for b, n in olusan)
    dh = kir_top - olu_top
    isi_veren = dh < 0
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    baglar = []
    for b, _ in kirilan + olusan:
        if b not in baglar:
            baglar.append(b)
    tablo = "; ".join("{}: {} kJ/mol".format(b, _BAG_ENERJISI[b]) for b in baglar)
    parca = " + ".join("{} × {}".format(n, _BAG_ENERJISI[b]) for b, n in kirilan)
    parca_o = " + ".join("{} × {}".format(n, _BAG_ENERJISI[b]) for b, n in olusan)

    kir_yanlislari = {olu_top: "Oluşan bağları topladın; soru tepkimeye girenlerde "
                               "kırılan bağları soruyor."}
    tek_tek = sum(_BAG_ENERJISI[b] for b, _ in kirilan)
    if tek_tek != kir_top:
        kir_yanlislari[tek_tek] = ("Katsayıları ve molekül başına bağ sayısını hesaba "
                                   "katmadın; her bağ türünü bir kez saydın.")

    if isi_veren:
        hat_sorusu = "Hat {} tur çalışınca kaç kJ ısı açığa çıkar?".format(tur)
        dogru_yorum = "Isı veren tepkime: hattın soğutulması gerekir"
        ters_yorum = "Isı alan tepkime: hatta ısıtıcı gerekir"
        ters_teshis = ("İşaretleri ters kullandın. ΔH negatif: ürünlerin bağları "
                       "daha güçlü, fark ısı olarak açığa çıkıyor.")
        durum = "açığa çıkıyor"
    else:
        hat_sorusu = "Hat {} tur çalışınca dışarıdan kaç kJ ısı verilmelidir?".format(tur)
        dogru_yorum = "Isı alan tepkime: hatta ısıtıcı gerekir"
        ters_yorum = "Isı veren tepkime: hattın soğutulması gerekir"
        ters_teshis = ("İşaretleri ters kullandın. ΔH pozitif: kırılan bağlar daha "
                       "güçlü, aradaki fark dışarıdan verilmeli.")
        durum = "dışarıdan verilmeli"

    return Bulmaca(
        kod="kim-enerji-bilancosu",
        ders="kimya",
        baslik="Enerji Bilançosu",
        kademe=kademe,
        konu="entalpi",
        kazanim="Bağ enerjilerinden tepkime entalpisini hesaplama; bağ kırılmasının "
                "enerji gerektirdiğini, bağ oluşumunun enerji verdiğini açıklama; "
                "ΔH işaretini ısı alan ya da veren tepkimeyle ilişkilendirme.",
        dikkat=8,
        brifing=(
            "Üssün üretim hattı yeni bir tepkimeye geçecek: {}.\n\n"
            "{} enerji bilançosunu şöyle çıkardı: \"Tepkimede kırılan bağların "
            "enerjisi toplam {} kJ. Bağ kırılınca enerji açığa çıkar; hat {} tur "
            "çalışınca {} kJ kazanırız. Ne ısıtıcı ne soğutucu gerekir.\"\n\n"
            "Hat çalıştırılmadan önce bilançoyu doğru kurmamız gerekiyor."
        ).format(denklem, kisi, kir_top, tur, tur * kir_top),
        kanitlar=[
            Kanit("Üretim denklemi",
                  "{}. Hat her turda denklemdeki miktarları (mol) işler."
                  .format(denklem),
                  bedel=1, kritik=True),
            Kanit("Bağ enerjisi tablosu", tablo + ".", bedel=1, kritik=True),
            Kanit("Molekül yapısı",
                  "H₂O: iki O–H bağı. NH₃: üç N–H bağı. H₂, Cl₂, F₂, Br₂, HCl, HF, "
                  "HBr: birer tekli bağ. O₂: bir O=O. N₂: bir N≡N.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bağlar ve tepkime ısısı için hangisi doğrudur?",
                dogru=("Bağ kırmak enerji ister, bağ oluşumu enerji verir; ΔH = "
                       "kırılan − oluşan bağ enerjileri"),
                yanlislar={
                    "Bağ kırılınca enerji açığa çıkar; kırılan bağlar ne kadar güçlüyse o kadar enerji kazanılır":
                        "Bağ kırılmasının enerji verdiğini sandın. İki atomu "
                        "birbirinden ayırmak için enerji harcamak gerekir.",
                    ("ΔH = oluşan bağların toplamı − kırılan bağların toplamı; bağ "
                     "enerjilerinde de son eksi ilk alınır"):
                        "İşaretleri ters kullandın. Isı veren tepkimede ΔH negatif "
                        "olmalı; bu formül onu pozitif yapar.",
                    "Hem bağ kırılması hem bağ oluşumu enerji ister":
                        "Bağ oluşurken atomlar daha kararlı hâle geçer ve enerji "
                        "açığa çıkar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Atomları ayırmak enerji ister; atomlar bağlanınca aynı miktar "
                    "açığa çıkar. Tepkimede eski bağlar kırılır, yenileri oluşur. "
                    "Kırmaya harcanan, oluşumda kazanılandan azsa ΔH negatiftir ve "
                    "tepkime ısı verir."
                ),
                ipuclari=[
                    "Bir mıknatısı çelikten ayırmak mı, yaklaştırmak mı çaba ister?",
                    "Isı veren tepkimede ΔH hangi işaretli olmalı?",
                ],
                cozum="ΔH = Σ kırılan − Σ oluşan\nΔH < 0: ısı veren; ΔH > 0: ısı alan",
            ),
            sayi_adimi(
                soru="Bir turda bağları kırmak için kaç kJ enerji gerekir?",
                cevap=kir_top,
                birim="kJ",
                aciklama="{} = {} kJ.".format(parca, kir_top),
                yaygin_yanlislar=kir_yanlislari,
                ipuclari=["Tepkimeye girenlerin bağlarını katsayılarıyla say."],
                puan=12,
            ),
            sayi_adimi(
                soru="Bir tur için ΔH kaç kJ? (işaretiyle yaz)",
                cevap=dh,
                birim="kJ",
                aciklama="Oluşan bağlar: {} = {} kJ. ΔH = {} − {} = {} kJ.".format(
                    parca_o, olu_top, kir_top, olu_top, _isaretli(dh)),
                yaygin_yanlislar={
                    -dh: ters_teshis,
                    -kir_top:
                        "Bağ kırılmasının enerji verdiğini sandın: kırılan bağların "
                        "toplamını kazanç yazdın.",
                    -(kir_top + olu_top):
                        "Bağ kırılmasının enerji verdiğini sandın: iki toplamı da "
                        "açığa çıkan enerji saydın.",
                },
                ipuclari=["Önce oluşan bağların toplamını bul, sonra kırılandan çıkar."],
                puan=14,
            ),
            sayi_adimi(
                soru=hat_sorusu,
                cevap=tur * abs(dh),
                birim="kJ",
                aciklama="{} × {} = {} kJ.".format(tur, abs(dh), tur * abs(dh)),
                yaygin_yanlislar={
                    abs(dh): "Bir turun değerini yazdın; hat {} tur çalışıyor.".format(tur),
                    tur * kir_top:
                        "Bağ kırılmasının enerji verdiğini sandın; brifingdeki hesabı "
                        "tekrarladın.",
                },
                ipuclari=["Bir turun ΔH değerini tur sayısıyla çarp."],
                puan=10,
            ),
            yorum_adimi(
                soru="Üretim hattı için hangisi doğru?",
                dogru=dogru_yorum,
                yanlislar={
                    ters_yorum: ters_teshis,
                    "Enerji değişimi yok: ne ısıtıcı ne soğutucu gerekir":
                        "Kırılan ve oluşan bağların toplamı eşit değil; fark ısı "
                        "olarak alınır ya da verilir.",
                },
                rastgele=rastgele,
                aciklama="ΔH = {} kJ: ısı {}.".format(_isaretli(dh), durum),
                ipuclari=["ΔH işaretine bak."],
                puan=10,
            ),
        ],
        kapanis=("Bilanço düzeltildi: bir turda ΔH = {} kJ; {} turda {} kJ ısı {}. "
                 "Bağ kırmak enerji ister, bağ oluşumu enerji verir."
                 ).format(_isaretli(dh), tur, tur * abs(dh), durum),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# TEPKİME HIZI: DENEY VERİSİNDEN HIZ DENKLEMİ, KATALİZÖR VE K (B37.13)
#
# `tepkime_hizi` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Üretim
# verisinden hızın hangi değişkene bağlı olduğunu çıkarma". `yaygin_yanlis`:
#
#   "Katalizörün denge sabitini değiştirdiğini sanmak."
#
# DÜZENEK: üretim hattında üç deneme; birinde yalnız A, ötekinde yalnız B
# derişimi iki katına çıkıyor. Hız = k[A]^m[B]^n; mertebe DENEYDEN bulunur,
# denklem katsayısından değil. Katalizör ileri ve geri tepkimeyi aynı oranda
# hızlandırır: dengeye daha çabuk varılır, K değişmez.
#
# YANILGILARIN SAYISAL KARŞILIĞI: K'yi katalizör çarpanıyla büyütmek;
# mertebe yerine katsayıyı ya da hız oranını yazmak; hızı derişimle doğrusal
# saymak. Havuz mertebelerin katsayılarla birebir aynı olduğu durumu dışarıda
# bırakır: öğrenci katsayıyı kopyalayarak doğruya ulaşamaz.
# ==========================================================================

# (denklem, A katsayısı, B katsayısı)
_HIZ_DENKLEMLERI = (("A + 2B → C", 1, 2), ("2A + B → C", 2, 1))


def _hiz_havuzu():
    havuz = []
    for denklem, ka, kb in _HIZ_DENKLEMLERI:
        for m in (1, 2):
            for n in (0, 1, 2):
                if m == n or (m, n) == (ka, kb):
                    continue
                havuz.append((denklem, ka, kb, m, n))
    return tuple(havuz)


_HIZ = _hiz_havuzu()


@bulmaca(ders="kimya", konu="tepkime_hizi", kademeler=(11, 13), agirlik=1.3)
def uretim_denemeleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Hız mertebesi deneyden bulunur; katalizör hızı artırır, K'yi değiştirmez."""
    denklem, ka, kb, m, n = rastgele.choice(_HIZ)
    r = rastgele.choice((2, 3, 4, 5))            # × 10⁻³ mol/(L·s)
    r_a = r * 2 ** m
    r_b = r * 2 ** n
    yeni = r * 3 ** m * 2 ** n                   # [A] = 0,3; [B] = 0,2
    k_denge = rastgele.choice((2, 4, 6, 8))
    kat = rastgele.choice((3, 5, 10))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    def mertebe_yanlislari(mertebe, katsayi, oran, ad):
        sozluk = {oran: "Hızın kaç katına çıktığını yazdın; mertebe o sayının "
                        "2'nin kaçıncı kuvveti olduğudur."}
        if katsayi != mertebe and katsayi not in sozluk:
            sozluk[katsayi] = ("Denklemdeki katsayıyı mertebe sandın. {} için mertebe "
                               "deney tablosundan bulunur.".format(ad))
        return sozluk

    yeni_yanlislari = {}
    for deger, metin in (
            (r * 3 * 2, "Hızı derişimle doğrusal saydın; mertebeleri üs olarak kullan."),
            (r * 3 ** ka * 2 ** kb, "Katsayıları mertebe sandın; mertebeler deneyden "
                                    "bulunan sayılardır.")):
        if deger != yeni and deger not in yeni_yanlislari:
            yeni_yanlislari[deger] = metin

    return Bulmaca(
        kod="kim-uretim-denemeleri",
        ders="kimya",
        baslik="Üretim Denemeleri",
        kademe=kademe,
        konu="tepkime_hizi",
        kazanim="Deney verisinden hız denklemindeki mertebeleri bulma; hız denklemiyle "
                "yeni koşulda hızı hesaplama; katalizörün hızı artırdığını ama denge "
                "sabitini değiştirmediğini açıklama.",
        dikkat=8,
        brifing=(
            "Üretim hattında {} tepkimesi yavaş ilerliyor; hızlandırma planı "
            "yapılacak.\n\n"
            "{} planı şöyle yazdı: \"Denklemde A katsayısı {}, B katsayısı {}; hız bu "
            "sayılara göre artar. Bir de katalizör ekleyelim: tepkime {} kat hızlanırsa "
            "denge sabiti de {} olur, dengede çok daha fazla ürün alırız.\"\n\n"
            "Plan onaylanmadan önce deneme verisini doğru okumamız gerekiyor."
        ).format(denklem, kisi, ka, kb, kat, k_denge * kat),
        kanitlar=[
            Kanit("Deneme tablosu",
                  "Hızlar × 10⁻³ mol/(L·s).\n"
                  "1. deneme: [A] = 0,1; [B] = 0,1 -> hız {}\n"
                  "2. deneme: [A] = 0,2; [B] = 0,1 -> hız {}\n"
                  "3. deneme: [A] = 0,1; [B] = 0,2 -> hız {}".format(r, r_a, r_b),
                  bedel=1, kritik=True),
            Kanit("Denge kaydı",
                  "Katalizörsüz kapalı kapta dengede K = {}.".format(k_denge),
                  bedel=1, kritik=True),
            Kanit("Katalizör kartı",
                  "Katalizör etkinleşme enerjisini düşürür; ileri tepkime {} kat "
                  "hızlanıyor. Geri tepkime de aynı yoldan geçer.".format(kat),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Hız denklemi ve katalizör için hangisi doğrudur?",
                dogru=("Mertebeler deneyle bulunur; katalizör iki yönü de "
                       "hızlandırır, denge sabitini değiştirmez"),
                yanlislar={
                    ("Katalizör ileri tepkimeyi hızlandırdığı için denge sabitini "
                     "büyütür; denge ürünlere doğru kayar"):
                        "Katalizörün denge sabitini değiştirdiğini sandın. Katalizör "
                        "geri tepkimeyi de aynı oranda hızlandırır; dengeye yalnız "
                        "daha çabuk varılır.",
                    ("Mertebeler denklemdeki katsayılara her zaman eşittir; denklem "
                     "hangi taneciğin kaç kez çarpıştığını söyler"):
                        "Katsayılar tepkimenin oranını verir; hızın derişime nasıl "
                        "bağlı olduğunu yalnız deney gösterir.",
                    "Katalizör tepkimede harcanır; bu yüzden ürün miktarını artırır":
                        "Katalizör tepkimeden değişmeden çıkar ve dengedeki ürün "
                        "miktarını değiştirmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Hız = k[A]^m[B]^n. Bir derişim iki katına çıkınca hız 2^m katına "
                    "çıkar; m bu karşılaştırmadan bulunur. Katalizör etkinleşme "
                    "enerjisini iki yön için de düşürür; K ileri ve geri hız "
                    "sabitlerinin oranı olduğundan değişmez."
                ),
                ipuclari=[
                    "Deneme tablosunda hangi iki satırda yalnız [A] değişiyor?",
                    "Katalizör geri tepkimeyi de hızlandırır mı?",
                ],
                cozum="Hız = k[A]^m[B]^n\nKatalizör: hız artar, K sabit",
            ),
            sayi_adimi(
                soru="Hız denkleminde A için mertebe kaçtır?",
                cevap=m,
                aciklama="[A] iki katına çıkınca hız {} -> {}: {} katı = 2^{}. Mertebe {}."
                .format(r, r_a, 2 ** m, m, m),
                yaygin_yanlislar=mertebe_yanlislari(m, ka, 2 ** m, "A"),
                ipuclari=["1. ve 2. denemeyi karşılaştır."],
                puan=10,
            ),
            sayi_adimi(
                soru="Hız denkleminde B için mertebe kaçtır?",
                cevap=n,
                aciklama="[B] iki katına çıkınca hız {} -> {}: {} katı = 2^{}. Mertebe {}."
                .format(r, r_b, 2 ** n, n, n),
                yaygin_yanlislar=mertebe_yanlislari(n, kb, 2 ** n, "B"),
                ipuclari=["1. ve 3. denemeyi karşılaştır."],
                puan=10,
            ),
            sayi_adimi(
                soru="[A] = 0,3 ve [B] = 0,2 mol/L olursa hız kaç × 10⁻³ mol/(L·s) olur?",
                cevap=yeni,
                aciklama="{} × 3^{} × 2^{} = {}.".format(r, m, n, yeni),
                yaygin_yanlislar=yeni_yanlislari,
                ipuclari=["1. denemeye göre [A] 3 katı, [B] 2 katı."],
                puan=12,
            ),
            sayi_adimi(
                soru="Katalizör eklenince dengede K kaç olur?",
                cevap=k_denge,
                aciklama=("Katalizör ileri ve geri tepkimeyi {} kat hızlandırır; oranları "
                          "değişmez. K = {}.").format(kat, k_denge),
                yaygin_yanlislar={
                    k_denge * kat:
                        "Katalizörün denge sabitini değiştirdiğini sandın. Geri "
                        "tepkime de aynı oranda hızlanır; K aynı kalır.",
                },
                ipuclari=["Katalizör kartı geri tepkime için ne diyor?"],
                puan=12,
            ),
        ],
        kapanis=("Plan düzeltildi: hız = k[A]^{}[B]^{} (katsayılar değil, deney). "
                 "Katalizör hattı hızlandırır ama K = {} kalır; dengedeki ürün "
                 "miktarı değişmez.").format(m, n, k_denge),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# KİMYASAL DENGE: DİNAMİK DENGE, EŞİT DERİŞİM DEĞİL (B37.13)
#
# `kimyasal_denge` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Kapalı
# sistemde ileri-geri süreç verilerini yorumlama". `yaygin_yanlis`:
#
#   "Dengede tepkimenin durduğunu veya derişimlerin eşit olduğunu sanmak."
#
# DÜZENEK: kapalı tankta N₂O₄ ⇌ 2NO₂. On saniyede bir derişim ölçümü. Bir
# anda iki derişim EŞİTLENİR ama değişmeye devam eder; denge, derişimlerin
# SABİTLENDİĞİ andır. Dengede ileri ve geri hız eşit ve sıfırdan büyük.
#
# YANILGILARIN SAYISAL KARŞILIĞI: eşitlik anını denge anı sanmak; o anın
# değerleriyle K hesaplamak; kare almayı unutmak; dengede ileri hızı sıfır
# yazmak.
# ==========================================================================

# (başlangıç [N₂O₄], her 10 saniyede ayrışan x değerleri: 0, 10, ..., 50 s)
_DENGE_SERILERI = (
    (0.6, (0, 0.1, 0.2, 0.3, 0.3, 0.3)),
    (0.9, (0, 0.2, 0.3, 0.4, 0.4, 0.4)),
    (1.2, (0, 0.4, 0.5, 0.6, 0.6, 0.6)),
    (1.5, (0, 0.3, 0.5, 0.6, 0.7, 0.7)),
)


@bulmaca(ders="kimya", konu="kimyasal_denge", kademeler=(11, 13), agirlik=1.3)
def kapali_tank(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Denge dinamiktir: derişimler sabitlenir (eşitlenmez), ileri ve geri hız eşittir."""
    c0, seri = rastgele.choice(_DENGE_SERILERI)
    n2o4 = [round(c0 - x, 2) for x in seri]
    no2 = [round(2 * x, 2) for x in seri]
    esit_i = [i for i in range(len(seri)) if n2o4[i] == no2[i]][0]
    denge_i = min(i for i in range(len(seri)) if all(s == seri[-1] for s in seri[i:]))
    esit_t, denge_t = 10 * esit_i, 10 * denge_i
    a_d, b_d = n2o4[-1], no2[-1]
    k_c = round(b_d ** 2 / a_d, 4)
    k_kare_yok = round(b_d / a_d, 4)
    k_esit = round(no2[esit_i] ** 2 / n2o4[esit_i], 4)
    hiz = rastgele.choice((4, 6, 8))
    olcum_t = 10 * (len(seri) - 1)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    tablo = "\n".join("{} s: [N₂O₄] = {}; [NO₂] = {}".format(10 * i, sy(n2o4[i]), sy(no2[i]))
                      for i in range(len(seri)))

    return Bulmaca(
        kod="kim-kapali-tank",
        ders="kimya",
        baslik="Kapalı Tank",
        kademe=kademe,
        konu="kimyasal_denge",
        kazanim="Derişim-zaman verisinden dengenin kurulduğu anı bulma; dengenin "
                "dinamik olduğunu (ileri ve geri hız eşit, sıfır değil) açıklama; "
                "denge derişimleriyle Kc hesaplama.",
        dikkat=8,
        brifing=(
            "Kapalı tanka {} mol/L N₂O₄ kondu; tankta N₂O₄ ⇌ 2NO₂ tepkimesi "
            "yürüyor.\n\n"
            "{} kayda şunu yazdı: \"{}. saniyede iki derişim eşitlendi; demek ki "
            "denge o anda kuruldu ve tepkime durdu. Tankta artık hiçbir şey "
            "olmuyor, ölçümü kapatalım.\"\n\n"
            "Kayıt kapanmadan önce veriyi doğru yorumlamamız gerekiyor."
        ).format(sy(c0), kisi, esit_t),
        kanitlar=[
            Kanit("Derişim tablosu", "Derişimler mol/L.\n" + tablo,
                  bedel=1, kritik=True),
            Kanit("Hız ölçümü",
                  "{}. saniyede geri tepkime (2NO₂ → N₂O₄) hızı {} × 10⁻³ "
                  "mol/(L·s).".format(olcum_t, hiz),
                  bedel=1, kritik=True),
            Kanit("Denge notu",
                  "N₂O₄ ⇌ 2NO₂ için Kc = [NO₂]² ÷ [N₂O₄] (denge derişimleriyle).",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kapalı kaptaki kimyasal denge için hangisi doğrudur?",
                dogru=("İleri ve geri tepkime aynı hızla sürer; derişimler sabit "
                       "kalır ama eşit olmaları gerekmez"),
                yanlislar={
                    ("Dengede tepkime durur; derişimler değişmediğine göre artık "
                     "hiçbir tanecik dönüşmüyor"):
                        "Dengede tepkimenin durduğunu sandın. Dönüşüm iki yönde de "
                        "sürüyor; hızlar eşit olduğu için net değişim görünmüyor.",
                    ("Denge, girenlerle ürünlerin derişimleri eşitlendiği anda "
                     "kurulur; denge zaten eşitlik demektir"):
                        "Derişimlerin eşit olduğunu sandın. Denge derişimlerin "
                        "eşitlendiği değil, sabitlendiği andır.",
                    "Dengede yalnız ileri tepkime sürer, geri tepkime durur":
                        "Geri tepkime durursa derişimler değişmeye devam ederdi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kapalı kapta ürün biriktikçe geri tepkime hızlanır, ileri "
                    "tepkime yavaşlar. Hızlar eşitlenince derişimler artık "
                    "değişmez: denge dinamiktir. Derişimlerin değerleri tepkimeye "
                    "ve başlangıca bağlıdır; eşit olmaları gerekmez."
                ),
                ipuclari=[
                    "Tabloda derişimlerin eşitlendiği andan sonra değerler değişiyor mu?",
                    "Hız ölçümünde geri tepkime hızı sıfır mı?",
                ],
                cozum="Denge: derişimler sabit, ileri hız = geri hız ≠ 0",
            ),
            sayi_adimi(
                soru="Denge kaçıncı saniyede kuruldu? (derişimlerin sabitlendiği ilk ölçüm anını yaz)",
                cevap=denge_t,
                birim="s",
                aciklama=("{}. saniyeden sonra derişimler değişmiyor: [N₂O₄] = {}, "
                          "[NO₂] = {}.").format(denge_t, sy(a_d), sy(b_d)),
                yaygin_yanlislar={
                    esit_t:
                        "Derişimlerin eşit olduğunu sandın. O anda derişimler eşit "
                        "ama sonraki ölçümde yine değişiyor; denge henüz yok.",
                },
                ipuclari=["Derişimlerin artık değişmediği ilk satırı bul."],
                puan=12,
            ),
            sayi_adimi(
                soru="Kc kaçtır? (virgülden sonra en çok iki basamak)",
                cevap=k_c,
                aciklama="Kc = {}² ÷ {} = {}.".format(sy(b_d), sy(a_d), sy(k_c)),
                yaygin_yanlislar={
                    k_esit:
                        "Derişimlerin eşit olduğu anın değerlerini kullandın; Kc "
                        "denge derişimleriyle hesaplanır.",
                    k_kare_yok:
                        "Kc ifadesinde NO₂ derişiminin karesini almayı unuttun "
                        "(katsayı 2).",
                },
                ipuclari=["Dengedeki derişimleri denge notundaki ifadeye koy."],
                puan=14,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="{}. saniyede ileri tepkime hızı kaç × 10⁻³ mol/(L·s)?".format(olcum_t),
                cevap=hiz,
                aciklama=("Dengede ileri hız geri hıza eşittir: {} × 10⁻³ mol/(L·s). "
                          "Hız sıfır değil; iki yönde de dönüşüm sürüyor.").format(hiz),
                yaygin_yanlislar={
                    0:
                        "Dengede tepkimenin durduğunu sandın. Geri tepkime {} hızla "
                        "sürüyor; derişim sabit kaldığına göre ileri tepkime de aynı "
                        "hızda.".format(hiz),
                },
                ipuclari=["Derişimler sabitse ileri ve geri hız arasında ne ilişki var?"],
                puan=12,
            ),
            yorum_adimi(
                soru="Kayıttaki \"tepkime durdu, ölçümü kapatalım\" notu için hangisi doğru?",
                dogru=("Tepkime durmadı: iki yönde eşit hızla sürüyor; denge {}. "
                       "saniyede kuruldu").format(denge_t),
                yanlislar={
                    ("Doğru: derişimler {}. saniyede eşitlendi; eşit derişimde "
                     "tepkime durur, ölçüm kapatılabilir").format(esit_t):
                        "Derişimlerin eşit olduğunu ve tepkimenin durduğunu sandın; "
                        "ikisi de tabloyla çelişiyor.",
                    "Tepkime {}. saniyede durdu, çünkü derişimler artık değişmiyor".format(denge_t):
                        "Dengede tepkimenin durduğunu sandın. Hız ölçümü geri "
                        "tepkimenin sürdüğünü gösteriyor.",
                    ("Denge hiç kurulmadı; derişimler birbirine eşit kalmadığı "
                     "için dengeden söz edilemez"):
                        "Denge için derişimlerin eşitlenmesi gerekmez; sabitlenmeleri "
                        "yeter.",
                },
                rastgele=rastgele,
                aciklama=("Derişimler {}. saniyeden sonra sabit, ama ileri ve geri "
                          "tepkime {} × 10⁻³ mol/(L·s) hızla sürüyor.").format(denge_t, hiz),
                ipuclari=["Hız ölçümüne bak."],
                puan=10,
            ),
        ],
        kapanis=("Kayıt düzeltildi: denge {}. saniyede kuruldu (eşitlik anı olan {}. "
                 "saniyede değil), Kc = {}. Tankta dönüşüm iki yönde de sürüyor."
                 ).format(denge_t, esit_t, sy(k_c)),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# ÇÖZÜNÜRLÜK DENGESİ: SAF KATI Kçç İFADESİNE GİRMEZ (B37.13)
#
# `cozunurluk_dengesi` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Atık
# su modelindeki çökelme koşulunu yorumlama". `yaygin_yanlis`:
#
#   "Kçç ifadesine saf katıyı katmak."
#
# DÜZENEK: atık su tankında az çözünen bir tuzun doygun çözeltisi; dipte
# katı var. Ölçülen iyon derişimlerinden Kçç; iki eşit hacimli akış
# karışınca derişimler yarıya iner, Q ile Kçç karşılaştırılır. Dipteki
# katıyı artırmak iyon derişimini DEĞİŞTİRMEZ.
#
# YANILGILARIN SAYISAL KARŞILIĞI: Kçç'yi katı miktarına bölmek ya da onunla
# çarpmak; katı artınca iyon derişimini artırmak; karışımda seyrelmeyi
# unutmak. Havuz Q = Kçç durumunu dışarıda bırakır, iki sonuç da çıkar.
# ==========================================================================

# (tuz, katyon, anyon)
_KCC_TUZLARI = (
    ("BaSO₄", "Ba²⁺", "SO₄²⁻"),
    ("AgCl", "Ag⁺", "Cl⁻"),
    ("CaCO₃", "Ca²⁺", "CO₃²⁻"),
)


@bulmaca(ders="kimya", konu="cozunurluk_dengesi", kademeler=(11, 13), agirlik=1.3)
def atik_su_tanki(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kçç yalnız çözünmüş iyonları içerir; çökelme Q ile Kçç karşılaştırılarak bulunur."""
    tuz, katyon, anyon = rastgele.choice(_KCC_TUZLARI)
    s = rastgele.choice((1, 2, 3))                  # × 10⁻⁵ mol/L
    k_cc = s * s                                    # × 10⁻¹⁰
    kati = rastgele.choice((2, 5))                  # mol, 1 L tankta
    while True:
        p, q = rastgele.choice((1, 2, 3, 4)), rastgele.choice((1, 2, 3, 4))
        if p * q != k_cc:
            break
    q_deger = p * q                                 # karışımda, × 10⁻¹⁰
    cokelir = q_deger > k_cc
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    if cokelir:
        dogru_yorum = "Çökelme olur: Q, Kçç değerinden büyük"
        ters_yorum = "Çökelme olmaz: Q, Kçç değerinden küçük"
    else:
        dogru_yorum = "Çökelme olmaz: Q, Kçç değerinden küçük"
        ters_yorum = "Çökelme olur: Q, Kçç değerinden büyük"

    return Bulmaca(
        kod="kim-atik-su-tanki",
        ders="kimya",
        baslik="Atık Su Tankı",
        kademe=kademe,
        konu="cozunurluk_dengesi",
        kazanim="Kçç ifadesini yalnız çözünmüş iyonlarla yazma; iyon derişimlerinden "
                "Kçç hesaplama; karışımda Q ile Kçç karşılaştırarak çökelmeyi "
                "öngörme.",
        dikkat=8,
        brifing=(
            "Atık su tankında {} doygun çözeltisi var; dipte katı {} birikmiş. İki "
            "atık akışı birleştirilecek ve boruda çökelme olup olmayacağı "
            "soruluyor.\n\n"
            "{} hesabı şöyle kurdu: \"Dipteki katı da dengeye girer: Kçç = "
            "[{}] × [{}] ÷ katı miktarı. Dibe biraz daha katı eklersek sudaki iyon "
            "derişimi de artar.\"\n\n"
            "Borular birleştirilmeden önce hesabı doğru kurmamız gerekiyor."
        ).format(tuz, tuz, kisi, katyon, anyon),
        kanitlar=[
            Kanit("Tank ölçümü",
                  "1 L doygun çözelti: [{}] = [{}] = {} × 10⁻⁵ mol/L. Dipte {} mol "
                  "katı {}.".format(katyon, anyon, s, kati, tuz),
                  bedel=1, kritik=True),
            Kanit("Akış kaydı",
                  "1. akış: [{}] = {} × 10⁻⁵ mol/L. 2. akış: [{}] = {} × 10⁻⁵ mol/L. "
                  "İki akış eşit hacimde karışacak.".format(katyon, 2 * p, anyon, 2 * q),
                  bedel=1, kritik=True),
            Kanit("Çözünürlük notu",
                  "{}(k) ⇌ {}(suda) + {}(suda). Q > Kçç ise çökelme olur."
                  .format(tuz, katyon, anyon),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Çözünürlük dengesi için hangisi doğrudur?",
                dogru=("Kçç yalnız çözünmüş iyonlarla yazılır; dipteki saf katı "
                       "ifadeye girmez"),
                yanlislar={
                    ("Kçç ifadesine dipteki katının miktarı da yazılır; dipte ne "
                     "kadar katı varsa denge o kadar kayar"):
                        "Kçç ifadesine saf katıyı kattın. Saf katının derişimi "
                        "değişmez; ifadeye girmez.",
                    ("Dibe katı eklendikçe doygun çözeltideki iyon derişimi artar; "
                     "çok katı daha çok çözünür"):
                        "Çözelti zaten doygun; eklenen katı çözünmeden dipte kalır.",
                    "Q, Kçç değerinden küçükse çökelme olur":
                        "Tersi: iyonların çarpımı Kçç değerini aşınca çökelme olur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Doygun çözeltide katı ile iyonlar dengededir. Saf katının "
                    "derişimi sabit olduğundan ifadeye yazılmaz: Kçç = [katyon] × "
                    "[anyon]. Karışımda iyonların çarpımı (Q) Kçç değerini aşarsa "
                    "fazlası çöker."
                ),
                ipuclari=[
                    "Doygun bir çözeltiye katı eklersen ne olur?",
                    "Çözünürlük notunda çökelme koşulu ne?",
                ],
                cozum="Kçç = [katyon][anyon]\nQ > Kçç: çökelme",
            ),
            sayi_adimi(
                soru="{} için Kçç kaç × 10⁻¹⁰?".format(tuz),
                cevap=k_cc,
                aciklama="Kçç = {} × 10⁻⁵ × {} × 10⁻⁵ = {} × 10⁻¹⁰. Dipteki katı "
                         "ifadeye girmez.".format(s, s, k_cc),
                yaygin_yanlislar={
                    sy(k_cc / float(kati)).replace(",", "."):
                        "Kçç ifadesine saf katıyı kattın: katı miktarına böldün.",
                    k_cc * kati:
                        "Kçç ifadesine saf katıyı kattın: katı miktarıyla çarptın.",
                },
                ipuclari=["Yalnız iki iyon derişimini çarp."],
                puan=12,
            ),
            sayi_adimi(
                soru="Dibe {} mol daha katı {} eklenirse [{}] kaç × 10⁻⁵ mol/L olur?"
                .format(kati, tuz, katyon),
                cevap=s,
                aciklama="Çözelti zaten doygun; eklenen katı dipte kalır. [{}] = {} × "
                         "10⁻⁵ mol/L.".format(katyon, s),
                yaygin_yanlislar={
                    2 * s:
                        "Kçç ifadesine saf katıyı kattın: katı iki katına çıkınca "
                        "iyon derişimini de iki katına çıkardın.",
                },
                ipuclari=["Doygun çözelti daha fazla çözebilir mi?"],
                puan=10,
            ),
            sayi_adimi(
                soru="Akışlar karışınca Q = [{}] × [{}] kaç × 10⁻¹⁰ olur?".format(katyon, anyon),
                cevap=q_deger,
                aciklama=("Eşit hacimde karışınca derişimler yarıya iner: {} × 10⁻⁵ ve "
                          "{} × 10⁻⁵. Q = {} × 10⁻¹⁰.").format(p, q, q_deger),
                yaygin_yanlislar={
                    4 * q_deger:
                        "Karışımda seyrelmeyi unuttun; her derişim yarıya iner.",
                },
                ipuclari=["Karıştıktan sonra her iyon iki kat hacme yayılır."],
                puan=12,
            ),
            yorum_adimi(
                soru="Birleşen boruda ne olur?",
                dogru=dogru_yorum,
                yanlislar={
                    ters_yorum:
                        "Q ile Kçç karşılaştırmasını ters okudun: Q = {}, Kçç = {} "
                        "(× 10⁻¹⁰).".format(q_deger, k_cc),
                    "Dipte zaten katı olduğu için her durumda çökelme olur":
                        "Tanktaki katı borudaki karışımı belirlemez; karar Q ile "
                        "Kçç karşılaştırmasıdır.",
                },
                rastgele=rastgele,
                aciklama="Q = {} × 10⁻¹⁰, Kçç = {} × 10⁻¹⁰: {}.".format(
                    q_deger, k_cc, "çökelme olur" if cokelir else "çökelme olmaz"),
                ipuclari=["Q ile Kçç değerini karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("Hesap düzeltildi: Kçç = {} × 10⁻¹⁰ (katı ifadeye girmez); boruda Q "
                 "= {} × 10⁻¹⁰, {}.").format(
                     k_cc, q_deger, "çökelme bekleniyor" if cokelir else "çökelme yok"),
        odul={"itibar": 5, "cevher": 2, "erzak": 1},
    )


# ==========================================================================
# ELEKTROLİZ: ELEKTRON MOLÜ METAL MOLÜ DEĞİLDİR (B37.13)
#
# `elektroliz` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Metal kaplama
# modelinin akım-süre verisini çözme". `yaygin_yanlis`:
#
#   "Elektron molü ile biriken madde molünü koşulsuz eşitlemek."
#
# DÜZENEK: atölyede bir parça metal kaplanıyor. Q = I × t; elektron molü =
# Q ÷ 96500; biriken metal molü = elektron molü ÷ iyon yükü (yarı tepkimeden).
# Havuzda yalnız yükü 2 ya da 3 olan iyonlar var: yanılgı her zaman yanlış
# sayı verir.
#
# YANILGILARIN SAYISAL KARŞILIĞI: metal molünü elektron molüne eşitlemek;
# yükle bölmek yerine çarpmak; kütleyi elektron molüyle hesaplamak.
# ==========================================================================

_FARADAY = 96500
# (metal adı, simge, mol kütlesi, iyon yükü)
_KAPLAMA_METALLERI = (
    ("bakır", "Cu", 64, 2),
    ("nikel", "Ni", 59, 2),
    ("çinko", "Zn", 65, 2),
    ("krom", "Cr", 52, 3),
    ("altın", "Au", 197, 3),
)
_IYON_UST = {2: "²⁺", 3: "³⁺"}


def _kaplama_havuzu():
    havuz = []
    for metal in _KAPLAMA_METALLERI:
        yuk = metal[3]
        for akim in (9.65, 19.3):
            for sure in (1000, 2000, 3000, 4000, 6000):
                yuzde_mol_e = round(akim * sure * 100 / _FARADAY)
                if yuzde_mol_e % yuk:
                    continue
                havuz.append((metal, akim, sure))
    return tuple(havuz)


_KAPLAMA = _kaplama_havuzu()


@bulmaca(ders="kimya", konu="elektroliz", kademeler=(12, 13), agirlik=1.3)
def kaplama_banyosu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Biriken metal molü = elektron molü ÷ iyon yükü; ikisi koşulsuz eşit değildir."""
    (ad, simge, mol_kutle, yuk), akim, sure = rastgele.choice(_KAPLAMA)
    yuk_c = round(akim * sure)
    yuzde_e = round(yuk_c * 100 / _FARADAY)
    mol_e = yuzde_e / 100.0
    mol_metal = (yuzde_e // yuk) / 100.0
    kutle = round(mol_metal * mol_kutle, 2)
    iyon = simge + _IYON_UST[yuk]
    yari = "{} + {}e⁻ → {}".format(iyon, yuk, simge)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-kaplama-banyosu",
        ders="kimya",
        baslik="Kaplama Banyosu",
        kademe=kademe,
        konu="elektroliz",
        kazanim="Akım ve süreden yük ve elektron molünü hesaplama; yarı tepkimeyi "
                "kullanarak katotta biriken metalin mol sayısını ve kütlesini bulma.",
        dikkat=8,
        brifing=(
            "Atölyede bir parça {} ile kaplanıyor; kaplama kalınlığı için biriken "
            "kütle gerekiyor.\n\n"
            "{} hesabı şöyle yaptı: \"Devreden {} mol elektron geçti; demek ki "
            "parçaya {} mol {} kaplandı, yani {} g.\"\n\n"
            "Parça teslim edilmeden önce hesabı doğru kurmamız gerekiyor."
        ).format(ad, kisi, sy(mol_e), sy(mol_e), ad, sy(round(mol_e * mol_kutle, 2))),
        kanitlar=[
            Kanit("Güç kaynağı kaydı",
                  "Akım {} A; süre {} s.".format(sy(akim), sure),
                  bedel=1, kritik=True),
            Kanit("Katot tepkimesi", "{} (mol kütlesi {} g/mol)".format(yari, mol_kutle),
                  bedel=1, kritik=True),
            Kanit("Elektroliz notu",
                  "Yük = akım × süre. 1 mol elektronun yükü 96500 C.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Katotta biriken metal miktarı nasıl bulunur?",
                dogru=("Yükten elektron molü bulunur ve bir metal atomunun aldığı "
                       "elektron sayısına bölünür"),
                yanlislar={
                    ("Kaç mol elektron geçtiyse o kadar mol metal birikir; her "
                     "elektron bir atomu katoda indirir"):
                        "Elektron molü ile biriken madde molünü koşulsuz eşitledin. "
                        "Her iyon katotta yükü kadar elektron alır.",
                    ("Elektron molü iyon yüküyle çarpılır; yükü büyük iyon daha "
                     "çok metal bırakır"):
                        "Bir atom için birden çok elektron gerekiyorsa biriken metal "
                        "azalır; bölmek gerekir.",
                    "Biriken metal akıma bağlıdır ama süreye bağlı değildir":
                        "Yük akım ile sürenin çarpımıdır; süre uzadıkça daha çok "
                        "metal birikir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Katotta her {} iyonu {} elektron alıp {} atomuna dönüşür. Bu "
                    "yüzden biriken metalin molü, elektron molü {} ile bölünerek "
                    "bulunur."
                ).format(iyon, yuk, simge, yuk),
                ipuclari=[
                    "Katot tepkimesinde bir atom için kaç elektron gerekiyor?",
                    "Elektron molü ile metal molü aynı mı?",
                ],
                cozum="Q = I × t\nmol e⁻ = Q ÷ 96500\nmol metal = mol e⁻ ÷ iyon yükü",
            ),
            sayi_adimi(
                soru="Devreden kaç C yük geçti?",
                cevap=yuk_c,
                birim="C",
                aciklama="{} A × {} s = {} C.".format(sy(akim), sure, yuk_c),
                ipuclari=["Akımı süreyle çarp."],
                puan=8,
            ),
            sayi_adimi(
                soru="Kaç mol elektron geçti?",
                cevap=mol_e,
                birim="mol",
                aciklama="{} ÷ 96500 = {} mol elektron.".format(yuk_c, sy(mol_e)),
                ipuclari=["Yükü 1 mol elektronun yüküne böl."],
                puan=10,
                tolerans=0.001,
            ),
            sayi_adimi(
                soru="Parçaya kaç mol {} birikti?".format(ad),
                cevap=mol_metal,
                birim="mol",
                aciklama="{}: her atom için {} elektron. {} ÷ {} = {} mol.".format(
                    yari, yuk, sy(mol_e), yuk, sy(mol_metal)),
                yaygin_yanlislar={
                    sy(mol_e).replace(",", "."):
                        "Elektron molü ile biriken madde molünü koşulsuz eşitledin. "
                        "Katot tepkimesinde bir atom {} elektron alıyor.".format(yuk),
                    sy(round(mol_e * yuk, 2)).replace(",", "."):
                        "İyon yüküyle çarptın; bir atom birden çok elektron "
                        "istediği için bölmelisin.",
                },
                ipuclari=["Elektron molünü iyon yüküne böl."],
                puan=14,
                tolerans=0.001,
            ),
            sayi_adimi(
                soru="Parçaya kaç gram {} kaplandı?".format(ad),
                cevap=kutle,
                birim="g",
                aciklama="{} mol × {} g/mol = {} g.".format(sy(mol_metal), mol_kutle, sy(kutle)),
                yaygin_yanlislar={
                    sy(round(mol_e * mol_kutle, 2)).replace(",", "."):
                        "Elektron molü ile biriken madde molünü koşulsuz eşitledin; "
                        "brifingdeki hesabı tekrarladın.",
                },
                ipuclari=["Metal molünü mol kütlesiyle çarp."],
                puan=12,
                tolerans=0.01,
            ),
        ],
        kapanis=("Hesap düzeltildi: {} mol elektron, yükü {} olan iyondan {} mol {} "
                 "biriktirdi: {} g. Elektron molü metal molüne ancak yük 1 ise eşittir."
                 ).format(sy(mol_e), yuk, sy(mol_metal), ad, sy(kutle)),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# KOROZYON: METALLER AYNI HIZLA AŞINMAZ; KURBAN ANOT (B37.13)
#
# `korozyon` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Atölye metal
# parçaları için verilen koruma seçeneklerini karşılaştırma". `yaygin_yanlis`:
#
#   "Bütün metallerin aynı koşulda aynı hızla aşındığını sanmak."
#
# DÜZENEK: tuzlu toprağa gömülü demir boru. Standart indirgenme potansiyeli
# tablosu: potansiyeli düşük (aktif) metal daha kolay yükseltgenir. İki metal
# temas edince aktif olan anot olur ve aşınır; demirden aktif bir metal
# bağlanırsa demir korunur (kurban anot). Magnezyum ve çinko anotların
# ölçülen tüketimi de farklı.
#
# YANILGILARIN KARŞILIĞI: "ikisi aynı hızla aşınır" şıkkı; bakırı kurban
# anot saymak; anot ömrünü öteki metalin tüketimiyle hesaplamak.
# ==========================================================================

# (ad, simge, E° V: M²⁺/M ya da Ag⁺/Ag)
_AKTIF_METALLER = (("magnezyum", "Mg", -2.37), ("çinko", "Zn", -0.76))
_SOY_METALLER = (("kalay", "Sn", -0.14), ("bakır", "Cu", 0.34), ("gümüş", "Ag", 0.80))
_DEMIR = ("demir", "Fe", -0.44)
_ANOT_TUKETIMI = {"Mg": 4, "Zn": 2}   # kg/yıl, bu depo toprağında ölçülen


@bulmaca(ders="kimya", konu="korozyon", kademeler=(12, 13), agirlik=1.3)
def kurban_anot(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aktif metal önce aşınır; demirden aktif metal bağlanınca demir korunur."""
    soylar = rastgele.sample(_SOY_METALLER, 2)
    metaller = list(_AKTIF_METALLER) + soylar + [_DEMIR]
    karisik = list(range(len(metaller)))
    rastgele.shuffle(karisik)
    kartlar = ["{} ({}): E° = {} V".format(metaller[i][0], metaller[i][1],
                                           ("+" if metaller[i][2] > 0 else "−") + sy(abs(metaller[i][2])))
               for i in karisik]
    siralama = sorted(range(len(metaller)), key=lambda i: metaller[i][2])
    dogru_sira = [karisik.index(i) for i in siralama]
    soy_ad, soy_simge, _ = rastgele.choice(soylar)
    adaylar = [m for m in metaller if m is not _DEMIR]
    rastgele.shuffle(adaylar)
    aday_kartlari = ["{} ({})".format(ad, simge) for ad, simge, _ in adaylar]
    koruyanlar = [n for n, m in enumerate(adaylar) if m[2] < _DEMIR[2]]
    anot_ad, anot_simge, _ = rastgele.choice(_AKTIF_METALLER)
    diger_simge = "Zn" if anot_simge == "Mg" else "Mg"
    kutle = rastgele.choice((12, 16, 24))
    omur = kutle / float(_ANOT_TUKETIMI[anot_simge])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-kurban-anot",
        ders="kimya",
        baslik="Kurban Anot",
        kademe=kademe,
        konu="korozyon",
        kazanim="Standart indirgenme potansiyellerinden metallerin korozyona "
                "yatkınlığını sıralama; temas eden metallerde hangisinin aşınacağını "
                "belirleme; kurban anot seçimi ve ömrünü hesaplama.",
        dikkat=8,
        brifing=(
            "Deponun tuzlu toprağa gömülü demir su borusu paslanıyor; koruma "
            "seçenekleri karşılaştırılacak.\n\n"
            "{} önerisini yazdı: \"Tuzlu toprakta bütün metaller aynı hızla aşınır; "
            "boruya hangi metali bağlasak sonuç aynı. Elde {} bir parça var, onu "
            "bağlayalım. {} kg anot bloğu hangi metalden olursa olsun aynı sürede "
            "biter.\"\n\n"
            "Boru kazılmadan önce seçenekleri doğru karşılaştırmamız gerekiyor."
        ).format(kisi, soy_ad, kutle),
        kanitlar=[
            Kanit("Potansiyel tablosu",
                  "Standart indirgenme potansiyelleri:\n" + "\n".join(kartlar),
                  bedel=1, kritik=True),
            Kanit("Anot tüketimi",
                  "Bu toprakta ölçülen kurban anot tüketimi: magnezyum yılda {} kg, "
                  "çinko yılda {} kg.".format(_ANOT_TUKETIMI["Mg"], _ANOT_TUKETIMI["Zn"]),
                  bedel=1, kritik=True),
            Kanit("Korozyon notu",
                  "İndirgenme potansiyeli düşük olan metal daha kolay yükseltgenir. "
                  "Temas eden iki metalden aktif olan anot olur.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Aynı nemli ve tuzlu ortamdaki metaller için hangisi doğrudur?",
                dogru=("İndirgenme potansiyeli düşük metal kolay yükseltgenir; "
                       "temasta aktif olan aşınır, öteki korunur"),
                yanlislar={
                    ("Aynı ortamdaki bütün metaller aynı hızla aşınır; aşınmayı "
                     "metal değil nem ve tuz belirler"):
                        "Bütün metallerin aynı koşulda aynı hızla aşındığını sandın. "
                        "Potansiyel tablosu metallerin yükseltgenme eğiliminin çok "
                        "farklı olduğunu gösteriyor.",
                    ("İndirgenme potansiyeli yüksek metal önce aşınır; potansiyeli "
                     "yüksek olan tepkimeye daha yatkındır"):
                        "Potansiyeli yüksek metal indirgenmeye yatkındır; "
                        "yükseltgenip aşınan, potansiyeli düşük olandır.",
                    "İki metal temas edince ikisi de korunur":
                        "Temas bir pil kurar: aktif metal anot olup aşınır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Korozyon metalin yükseltgenmesidir. Potansiyeli düşük metal "
                    "elektronunu daha kolay verir. İki metal aynı nemli ortamda "
                    "temas ederse bir pil oluşur: aktif metal anot olur ve aşınır, "
                    "öteki katot olur ve korunur."
                ),
                ipuclari=[
                    "Tabloda hangi metalin potansiyeli en düşük?",
                    "Korozyon notunda anot hangisi?",
                ],
                cozum="Düşük E° -> kolay yükseltgenir -> anot, aşınır",
            ),
            sirala_adimi(
                soru="Metalleri aşınma eğilimi en yüksekten en düşüğe sırala (numaraları sırayla yaz):",
                secenekler=kartlar,
                dogru_sira=dogru_sira,
                aciklama="Potansiyel küçükten büyüğe: {}.".format(
                    " -> ".join(metaller[i][1] for i in siralama)),
                ipuclari=["En düşük potansiyelden başla."],
                puan=12,
            ),
            secim_adimi(
                soru="Demir boruya {} bir bağlantı parçası takılırsa ne olur?".format(soy_ad),
                dogru=("Demir daha aktif: anot olur, daha hızlı aşınır; "
                       "{} korunur").format(soy_ad),
                yanlislar={
                    "İkisi aynı hızla aşınır; temasın etkisi yoktur":
                        "Bütün metallerin aynı koşulda aynı hızla aşındığını sandın. "
                        "Potansiyelleri farklı iki metal temas edince bir pil kurulur.",
                    ("{} anot olur ve demiri korur; değerli metal paslanmaya "
                     "karşı kalkan olur").format(soy_ad.capitalize()):
                        "{} demirden soy (potansiyeli yüksek); anot olan demirdir."
                        .format(soy_simge),
                    "İkisi de korunur; iki metal birbirini örter, arasına su giremez":
                        "Temas koruma değil pil kurar; aktif olan aşınır.",
                },
                rastgele=rastgele,
                aciklama=("E°(Fe) = −0,44 V, {} potansiyeli daha yüksek. Demir anot "
                          "olur: bağlantı parçası boruyu korumaz, tersine demirin "
                          "aşınmasını hızlandırır.").format(soy_simge),
                ipuclari=["İki metalin potansiyelini karşılaştır."],
                puan=12,
            ),
            coklu_adimi(
                soru="Boruya bağlanınca demiri kurban anot olarak koruyan metaller hangileri? (numaraları virgülle yaz)",
                secenekler=aday_kartlari,
                dogru_indeksler=koruyanlar,
                aciklama=("Kurban anot demirden aktif olmalı: magnezyum ve çinko. "
                          "Potansiyeli demirden yüksek metaller boruyu korumaz."),
                ipuclari=["Potansiyeli −0,44 V değerinden küçük olanları seç."],
                puan=12,
            ),
            sayi_adimi(
                soru="{} kg {} anot bu toprakta kaç yıl dayanır?".format(kutle, anot_ad),
                cevap=omur,
                birim="yıl",
                aciklama="{} kg ÷ yılda {} kg = {} yıl.".format(
                    kutle, _ANOT_TUKETIMI[anot_simge], sy(omur)),
                yaygin_yanlislar={
                    sy(kutle / float(_ANOT_TUKETIMI[diger_simge])).replace(",", "."):
                        "Bütün metallerin aynı koşulda aynı hızla aşındığını sandın: "
                        "öteki anodun tüketimini kullandın.",
                },
                ipuclari=["Anot tüketimi kaydında bu metalin satırını kullan."],
                puan=10,
            ),
        ],
        kapanis=("Öneri düzeltildi: {} bağlantı demiri hızlandırarak aşındırırdı. "
                 "Boruya {} kg {} anot bağlandı; yaklaşık {} yıl dayanacak."
                 ).format(soy_ad, kutle, anot_ad, sy(omur)),
        odul={"itibar": 5, "cevher": 2, "erzak": 1},
    )


# ==========================================================================
# ELEKTROKİMYA: ANOT, KATOT VE PİL POTANSİYELİ (B37.13)
#
# `elektrokimya` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Üs pil
# modelinin tepkime ve gerilim verilerini inceleme". `yaygin_yanlis`:
#
#   "Anot-katot tepkimelerini karıştırmak; katsayıyla potansiyeli çarpmak."
#
# DÜZENEK: üs lambası için iki yarı hücreden pil kurulacak. Anot: potansiyeli
# düşük olan, yükseltgenir. E°pil = E°katot − E°anot. Denklemi dengelemek
# için yarı tepkime katsayıyla çarpılır ama POTANSİYEL ÇARPILMAZ (şiddet
# özelliği). Havuz yalnız elektron sayıları farklı çiftleri alır: katsayı
# yanılgısı her zaman farklı bir sayı verir.
# ==========================================================================

# (simge, iyon, elektron sayısı, E° V)
_YARI_HUCRELER = {
    "Mg": ("Mg²⁺", 2, -2.37), "Al": ("Al³⁺", 3, -1.66), "Zn": ("Zn²⁺", 2, -0.76),
    "Cu": ("Cu²⁺", 2, 0.34), "Ag": ("Ag⁺", 1, 0.80),
}
_PIL_CIFTLERI = (("Mg", "Ag"), ("Al", "Cu"), ("Al", "Ag"), ("Zn", "Ag"), ("Cu", "Ag"))


def _volt(sayi):
    return ("+" if sayi > 0 else "−") + sy(abs(round(sayi, 2)))


def _pil_katsayilari(anot, katot):
    """Verilen ve alınan elektronu eşitleyen (anot, katot) katsayıları."""
    a_n, k_n = _YARI_HUCRELER[anot][1], _YARI_HUCRELER[katot][1]
    ortak = a_n * k_n // (2 if a_n % 2 == 0 and k_n % 2 == 0 else 1)
    return ortak // a_n, ortak // k_n


def _pil_denklemi(anot, katot, ters=False):
    a_iyon, k_iyon = _YARI_HUCRELER[anot][0], _YARI_HUCRELER[katot][0]
    a_kat, k_kat = _pil_katsayilari(anot, katot)

    def k(sayi):
        return "" if sayi == 1 else str(sayi)
    if ters:
        return "{}{} + {}{} → {}{} + {}{}".format(k(k_kat), katot, k(a_kat), a_iyon,
                                                 k(k_kat), k_iyon, k(a_kat), anot)
    return "{}{} + {}{} → {}{} + {}{}".format(k(a_kat), anot, k(k_kat), k_iyon,
                                             k(a_kat), a_iyon, k(k_kat), katot)


@bulmaca(ders="kimya", konu="elektrokimya", kademeler=(12, 13), agirlik=1.3)
def us_pili(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Anot yükseltgenir; E°pil = E°katot − E°anot; potansiyel katsayıyla çarpılmaz."""
    anot, katot = rastgele.choice(_PIL_CIFTLERI)
    a_iyon, a_n, e_a = _YARI_HUCRELER[anot]
    k_iyon, k_n, e_k = _YARI_HUCRELER[katot]
    denklem = _pil_denklemi(anot, katot)
    a_kat, k_kat = _pil_katsayilari(anot, katot)
    ters_denklem = _pil_denklemi(anot, katot, ters=True)
    dengesiz = "{} + {} → {} + {}".format(anot, k_iyon, a_iyon, katot)
    e_pil = round(e_k - e_a, 2)
    e_katsayili = round(k_kat * e_k - a_kat * e_a, 2)
    gerekli = rastgele.choice((3, 6, 9, 12))
    adet = -(-int(gerekli * 100) // int(round(e_pil * 100)))
    adet_yanlis = -(-int(gerekli * 100) // int(round(e_katsayili * 100)))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    kartlar = sorted((anot, katot))

    adet_yanlislari = {}
    if adet_yanlis != adet:
        adet_yanlislari[adet_yanlis] = ("Katsayıyla potansiyeli çarptın; pil gerilimini "
                                        "büyük bulunca daha az pil yeter sandın.")
    alt = int(gerekli * 100) // int(round(e_pil * 100))
    if alt != adet and alt not in adet_yanlislari and alt > 0:
        adet_yanlislari[alt] = ("Aşağı yuvarladın; {} pil {} V değerine ulaşmaz."
                                .format(alt, sy(round(alt * e_pil, 2))))

    return Bulmaca(
        kod="kim-us-pili",
        ders="kimya",
        baslik="Üs Pili",
        kademe=kademe,
        konu="elektrokimya",
        kazanim="Standart indirgenme potansiyellerinden anot ve katodu belirleme; "
                "pil potansiyelini hesaplama; potansiyelin katsayıyla çarpılmadığını "
                "açıklama; net pil tepkimesini yazma.",
        dikkat=8,
        brifing=(
            "Üssün yedek lambası {} V istiyor. Depoda {} ve {} yarı hücreleri "
            "var; bunlardan pil kurulacak.\n\n"
            "{} hesabı şöyle yaptı: \"Dengeli denklemde katsayılar {} ve {}; "
            "potansiyelleri de bu katsayılarla çarparız, pil {} V verir.\"\n\n"
            "Piller bağlanmadan önce hesabı doğru kurmamız gerekiyor."
        ).format(gerekli, kartlar[0], kartlar[1], kisi, a_kat, k_kat, sy(e_katsayili)),
        kanitlar=[
            Kanit("Potansiyel tablosu",
                  "Standart indirgenme potansiyelleri:\n{} + {}e⁻ → {}: E° = {} V\n"
                  "{} + {}e⁻ → {}: E° = {} V".format(
                      a_iyon, a_n, anot, _volt(e_a), k_iyon, k_n, katot, _volt(e_k)),
                  bedel=1, kritik=True),
            Kanit("Pil notu",
                  "Anotta yükseltgenme, katotta indirgenme olur. E°pil = E°katot − "
                  "E°anot. Seri bağlı pillerin gerilimleri toplanır.",
                  bedel=1, kritik=True),
            Kanit("Lamba etiketi", "En az {} V ile yanar.".format(gerekli), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir pilin potansiyeli için hangisi doğrudur?",
                dogru=("Düşük potansiyelli anot olup yükseltgenir; E°pil = E°katot "
                       "− E°anot, katsayılar potansiyeli değiştirmez"),
                yanlislar={
                    "Potansiyeli yüksek olan anot olur; anotta indirgenme olur":
                        "Anot-katot tepkimelerini karıştırdın. Anotta yükseltgenme "
                        "olur ve anot, elektron vermeye yatkın olandır.",
                    ("Yarı tepkime kaç ile çarpılırsa potansiyel de o sayıyla "
                     "çarpılır; iki kat madde iki kat potansiyel verir"):
                        "Katsayıyla potansiyeli çarptın. Potansiyel, madde miktarına "
                        "bağlı olmayan bir özelliktir: iki kat metal iki kat gerilim "
                        "vermez.",
                    "Pil potansiyeli iki potansiyelin toplamıdır":
                        "Pil potansiyeli katot ile anot potansiyellerinin farkıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Elektronlar potansiyeli düşük elektrottan (anot) yüksek olana "
                    "(katot) akar. Gerilim iki potansiyelin farkıdır. Denklemi "
                    "dengelemek elektron sayısını eşitler; elektron başına enerjiyi, "
                    "yani potansiyeli değiştirmez."
                ),
                ipuclari=[
                    "Pil notunda anotta ne oluyor?",
                    "Bir pilden iki kat büyük olanı iki kat gerilim verir mi?",
                ],
                cozum="E°pil = E°katot − E°anot (katsayısız)",
            ),
            secim_adimi(
                soru="Bu pilde anot hangisidir?",
                dogru="{}: yükseltgenir, anottur".format(anot),
                yanlislar={
                    "{}: yükseltgenir, anottur".format(katot):
                        "Anot-katot tepkimelerini karıştırdın. {} potansiyeli daha "
                        "yüksek; indirgenmeye yatkın, katottur.".format(katot),
                    "{}: indirgenir, katottur".format(anot):
                        "Anot-katot tepkimelerini karıştırdın. {} potansiyeli daha "
                        "düşük; elektron verir.".format(anot),
                },
                rastgele=rastgele,
                aciklama="E°({}) = {} V < E°({}) = {} V: {} anot, {} katot.".format(
                    anot, _volt(e_a), katot, _volt(e_k), anot, katot),
                ipuclari=["Potansiyeli düşük olanı bul."],
                puan=10,
            ),
            sayi_adimi(
                soru="Pilin standart potansiyeli kaç V?",
                cevap=e_pil,
                birim="V",
                aciklama="E°pil = {} − ({}) = {} V.".format(_volt(e_k), _volt(e_a), sy(e_pil)),
                yaygin_yanlislar={
                    sy(e_katsayili).replace(",", "."):
                        "Katsayıyla potansiyeli çarptın; brifingdeki hesabı "
                        "tekrarladın.",
                    sy(-e_pil).replace(",", "."):
                        "Anot-katot tepkimelerini karıştırdın: katottan anodu değil, "
                        "anottan katodu çıkardın.",
                },
                ipuclari=["Katodun potansiyelinden anodunkini çıkar."],
                puan=14,
                tolerans=0.005,
            ),
            secim_adimi(
                soru="Pilin net tepkimesi hangisidir?",
                dogru=denklem,
                yanlislar={
                    ters_denklem:
                        "Anot-katot tepkimelerini karıştırdın: bu denklemde {} "
                        "yükseltgeniyor.".format(katot),
                    dengesiz:
                        "Elektronlar dengelenmemiş: {} {} elektron veriyor, {} {} "
                        "elektron alıyor.".format(anot, a_n, k_iyon, k_n),
                },
                rastgele=rastgele,
                aciklama=("Verilen ve alınan elektron eşit olmalı: {} × {} = {} × {}. "
                          "Katsayılar bu yüzden {} ve {}; potansiyel yine {} V."
                          ).format(a_kat, a_n, k_kat, k_n, a_kat, k_kat, sy(e_pil)),
                ipuclari=["Anot solda metal olarak, katot solda iyon olarak yer alır."],
                puan=10,
            ),
            sayi_adimi(
                soru="Lamba için bu pilden en az kaç tane seri bağlanmalı?",
                cevap=adet,
                birim="pil",
                aciklama="{} ÷ {} = {}; tam sayıya yukarı yuvarlanır: {} pil.".format(
                    gerekli, sy(e_pil), sy(round(gerekli / e_pil, 2)), adet),
                yaygin_yanlislar=adet_yanlislari,
                ipuclari=["Gerekli gerilimi bir pilin gerilimine böl, yukarı yuvarla."],
                puan=10,
            ),
        ],
        kapanis=("Hesap düzeltildi: {} anot, {} katot; pil {} V (katsayısız). Lamba "
                 "için {} pil seri bağlandı.").format(anot, katot, sy(e_pil), adet),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# KOLİGATİF ÖZELLİKLER: GRAM DEĞİL TANECİK SAYISI (B37.13)
#
# `koligatif` iki satırda boştu (2018: 11; 2026: 10). Bağlam: "İki çözeltinin
# donma veya kaynama değişimini karşılaştırma". `yaygin_yanlis`:
#
#   "Etkiyi yalnız çözünenin kütlesine bağlamak; tanecik sayısını ihmal etmek."
#
# DÜZENEK: üs araçlarının soğutma suyu için iki tank (her biri 1 kg su).
# Birinde moleküler bir çözünen (glikoz ya da üre) DAHA ÇOK GRAM; ötekinde
# iyonik bir tuz daha az gram ama DAHA ÇOK TANECİK. ΔTd = 1,86 × tanecik molü.
# Havuz yalnız kütle sırasıyla tanecik sırasının ters olduğu çiftleri alır:
# kütleye bakan öğrenci her seferinde yanlış tankı seçer.
# ==========================================================================

_MOLEKULER = (("glikoz", "C₆H₁₂O₆", 180), ("üre", "CO(NH₂)₂", 60))
_IYONIK = (("sodyum klorür", "NaCl", 58.5, 2), ("kalsiyum klorür", "CaCl₂", 111, 3))
_KD_SU = 1.86   # °C·kg/mol


def _koligatif_havuzu():
    havuz = []
    for mol_madde in _MOLEKULER:
        for n_mol in (1, 2, 3):
            for iyon_madde in _IYONIK:
                for n_iyon in (1, 2):
                    kutle_mol = n_mol * mol_madde[2]
                    kutle_iyon = n_iyon * iyon_madde[2]
                    if kutle_mol > kutle_iyon and n_mol < n_iyon * iyon_madde[3]:
                        havuz.append((mol_madde, n_mol, iyon_madde, n_iyon))
    return tuple(havuz)


_KOLIGATIF = _koligatif_havuzu()


@bulmaca(ders="kimya", konu="koligatif", kademeler=(10, 13), agirlik=1.3)
def sogutma_suyu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Donma noktası alçalması çözünenin kütlesine değil tanecik sayısına bağlıdır."""
    (m_ad, m_formul, m_M), n_mol, (i_ad, i_formul, i_M, i_kat), n_iyon = rastgele.choice(_KOLIGATIF)
    kutle_mol = n_mol * m_M
    kutle_iyon = n_iyon * i_M
    tanecik_iyon = n_iyon * i_kat
    donma_iyon = round(-_KD_SU * tanecik_iyon, 2)
    donma_yazi = "−" + sy(-donma_iyon)
    iyonik_birinci = rastgele.random() < 0.5
    iyon_tank = "1. tank" if iyonik_birinci else "2. tank"
    mol_tank = "2. tank" if iyonik_birinci else "1. tank"
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    tank_yazisi = {
        iyon_tank: "{} g {} ({}; {} g/mol)".format(sy(kutle_iyon), i_ad, i_formul, sy(i_M)),
        mol_tank: "{} g {} ({}; {} g/mol)".format(kutle_mol, m_ad, m_formul, m_M),
    }

    return Bulmaca(
        kod="kim-sogutma-suyu",
        ders="kimya",
        baslik="Soğutma Suyu",
        kademe=kademe,
        konu="koligatif",
        kazanim="Donma noktası alçalmasının çözünen tanecik sayısına bağlı olduğunu "
                "açıklama; iyonik çözünenlerin ayrışmasını hesaba katarak tanecik "
                "molünü ve donma noktasını hesaplama; iki çözeltiyi karşılaştırma.",
        dikkat=8,
        brifing=(
            "Kış seferinden önce araçların soğutma suyuna donmayı geciktiren bir "
            "katkı konacak. İki deneme tankı hazırlandı.\n\n"
            "{} seçimini yaptı: \"{} içinde çok daha fazla gram çözünen var; daha "
            "düşük sıcaklıkta o donar. Araçlara onu koyalım.\"\n\n"
            "Katkı araçlara konmadan önce tankları doğru karşılaştırmamız gerekiyor."
        ).format(kisi, mol_tank.capitalize()),
        kanitlar=[
            Kanit("Tank kaydı",
                  "Her tankta 1 kg su var.\n1. tank: {}.\n2. tank: {}.".format(
                      tank_yazisi["1. tank"], tank_yazisi["2. tank"]),
                  bedel=1, kritik=True),
            Kanit("Çözünme notu",
                  "Glikoz ve üre suda molekül olarak kalır. NaCl suda Na⁺ ve Cl⁻ "
                  "iyonlarına, CaCl₂ ise Ca²⁺ ve iki Cl⁻ iyonuna ayrışır.",
                  bedel=1, kritik=True),
            Kanit("Donma notu",
                  "Saf su 0 °C sıcaklıkta donar. 1 kg suda 1 mol tanecik donma noktasını "
                  "1,86 °C düşürür.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir çözünenin donma noktasını ne kadar düşüreceğini ne belirler?",
                dogru=("Oluşturduğu tanecik sayısı: iyonik madde ayrışır, her iyon "
                       "ayrı tanecik sayılır"),
                yanlislar={
                    "Çözünenin kütlesi: kaç gram konduysa etki o kadar büyük olur":
                        "Etkiyi yalnız çözünenin kütlesine bağladın. Ağır moleküllerin "
                        "bir gramında daha az tanecik vardır.",
                    ("Çözünenin mol sayısı; iyonlara ayrışması fark etmez, 1 mol "
                     "tuz yine 1 mol madde sayılır"):
                        "Tanecik sayısını ihmal ettin. 1 mol NaCl suda 2 mol "
                        "tanecik oluşturur.",
                    ("Çözünenin türü: tuzlar her zaman şekerden daha az etki eder; "
                     "şeker suyla daha iyi karışır"):
                        "Etki türe değil tanecik sayısına bağlıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Donma noktası alçalması koligatif bir özelliktir: su "
                    "molekülleri arasına giren tanecik sayısına bağlıdır. Kütle ancak "
                    "mol kütlesine bölünüp ayrışma hesaba katılınca anlam kazanır."
                ),
                ipuclari=[
                    "Çözünme notunda hangi madde kaç taneciğe ayrışıyor?",
                    "Gramı tanecik sayısına nasıl çevirirsin?",
                ],
                cozum="tanecik molü = (kütle ÷ mol kütlesi) × ayrışma sayısı\nΔT = 1,86 × tanecik molü",
            ),
            sayi_adimi(
                soru="{}ta kaç mol tanecik var?".format(mol_tank.capitalize()),
                cevap=n_mol,
                birim="mol",
                aciklama="{} g ÷ {} g/mol = {} mol; {} ayrışmaz: {} mol tanecik.".format(
                    kutle_mol, m_M, n_mol, m_ad, n_mol),
                yaygin_yanlislar={
                    kutle_mol:
                        "Etkiyi yalnız çözünenin kütlesine bağladın: gramı tanecik "
                        "sayısı diye yazdın.",
                },
                ipuclari=["Kütleyi mol kütlesine böl."],
                puan=10,
            ),
            sayi_adimi(
                soru="{}ta kaç mol tanecik var?".format(iyon_tank.capitalize()),
                cevap=tanecik_iyon,
                birim="mol",
                aciklama="{} g ÷ {} g/mol = {} mol {}; her birim {} iyona ayrışır: "
                         "{} mol tanecik.".format(sy(kutle_iyon), sy(i_M), n_iyon, i_formul,
                                                  i_kat, tanecik_iyon),
                yaygin_yanlislar={
                    n_iyon:
                        "Tanecik sayısını ihmal ettin: {} suda {} iyona ayrışır."
                        .format(i_formul, i_kat),
                },
                ipuclari=["Önce mol, sonra ayrışma sayısıyla çarp."],
                puan=12,
            ),
            sayi_adimi(
                soru="{} içindeki çözelti kaç °C sıcaklıkta donar?".format(iyon_tank.capitalize()),
                cevap=donma_iyon,
                birim="°C",
                aciklama="ΔT = 1,86 × {} = {} °C; donma noktası 0 − {} = {} °C.".format(
                    tanecik_iyon, sy(-donma_iyon), sy(-donma_iyon), donma_yazi),
                yaygin_yanlislar={
                    sy(round(-_KD_SU * n_iyon, 2)).replace(",", "."):
                        "Tanecik sayısını ihmal ettin; iyonların hepsini say.",
                    sy(-donma_iyon).replace(",", "."):
                        "Düşüş miktarını donma noktası diye yazdın; su 0 °C altına iner.",
                },
                ipuclari=["Düşüşü bul, sıfırdan çıkar."],
                puan=12,
                tolerans=0.01,
            ),
            yorum_adimi(
                soru="Araçlara hangi tanktaki katkı konmalı?",
                dogru="{}: daha çok tanecik, daha düşük donma noktası".format(iyon_tank.capitalize()),
                yanlislar={
                    ("{}: daha çok gram çözünen var; çok madde donmayı daha çok "
                     "geciktirir").format(mol_tank.capitalize()):
                        "Etkiyi yalnız çözünenin kütlesine bağladın. O tankta gram "
                        "çok ama tanecik az: {} mol.".format(n_mol),
                    "Fark etmez: iki tankta da çözünen var":
                        "Donma noktası tanecik sayısıyla düşer; tanecik sayıları farklı.",
                },
                rastgele=rastgele,
                aciklama="{} {} mol, {} {} mol tanecik içeriyor.".format(
                    iyon_tank.capitalize(), tanecik_iyon, mol_tank, n_mol),
                ipuclari=["İki tankın tanecik mollerini karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("Seçim düzeltildi: {} ({} g {}) {} mol tanecikle {} °C donuyor; "
                 "daha çok gram içeren {} yalnız {} mol tanecik içeriyor."
                 ).format(iyon_tank, sy(kutle_iyon), i_ad, tanecik_iyon, donma_yazi,
                          m_ad, n_mol),
        odul={"itibar": 5, "enerji": 1, "erzak": 2},
    )


# ==========================================================================
# KİMYASAL BAĞ: ALIŞVERİŞ, ORTAKLAŞMA VE ATOM-İYON FARKI (B37.13)
#
# `kimyasal_bag` iki satırda boştu (2018: 9; 2026: 9). Bağlam: "Malzeme
# modellerindeki tanecik bağlantılarını sınıflandırma". `yaygin_yanlis`:
#
#   "Bağ oluşumunu yalnız elektron alışverişi sanmak; atomla iyonu karıştırmak."
#
# DÜZENEK: malzeme kartları (iyonik bileşikler, kovalent moleküller, metal).
# İyonik bağda elektron aktarılır; kovalent bağda ORTAKLAŞA kullanılır;
# metalde elektronlar serbestçe dolaşır. İyon, atomun elektron vermiş ya da
# almış hâlidir: elektron sayısı atom numarasından farklıdır.
#
# YANILGILARIN SAYISAL KARŞILIĞI: iyonun elektron sayısını atom numarası
# yazmak; yük yönünü ters çevirmek; su gibi moleküllerde iyon aramak.
# ==========================================================================

# (kart, bağ türü)
_BAG_IYONIK = (("NaCl (sofra tuzu)", "iyonik"), ("MgO (fırın tuğlası)", "iyonik"),
               ("KF (lehim tozu katkısı)", "iyonik"), ("CaCl₂ (yol tuzu)", "iyonik"))
_BAG_KOVALENT = (("H₂O (su)", "kovalent"), ("CO₂ (karbon dioksit)", "kovalent"),
                 ("NH₃ (amonyak)", "kovalent"), ("Cl₂ (klor gazı)", "kovalent"),
                 ("CH₄ (metan)", "kovalent"))
_BAG_METAL = (("Cu (bakır tel)", "metalik"), ("Al (alüminyum levha)", "metalik"))
# (simge, ad, atom numarası, iyon yükü büyüklüğü, iyon yazımı)
_KATYONLAR = (("Na", "sodyum", 11, 1, "Na⁺"), ("Mg", "magnezyum", 12, 2, "Mg²⁺"),
              ("Al", "alüminyum", 13, 3, "Al³⁺"), ("K", "potasyum", 19, 1, "K⁺"),
              ("Ca", "kalsiyum", 20, 2, "Ca²⁺"))
_ANYONLAR = (("O", "oksijen", 8, 2, "O²⁻"), ("F", "flor", 9, 1, "F⁻"),
             ("Cl", "klor", 17, 1, "Cl⁻"), ("S", "kükürt", 16, 2, "S²⁻"),
             ("N", "azot", 7, 3, "N³⁻"))


@bulmaca(ders="kimya", konu="kimyasal_bag", kademeler=(9, 13), agirlik=1.3)
def malzeme_baglari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bağ yalnız elektron alışverişi değildir; iyon atomdan farklı sayıda elektron taşır."""
    kartlar = (rastgele.sample(_BAG_IYONIK, 2) + rastgele.sample(_BAG_KOVALENT, 3)
               + [rastgele.choice(_BAG_METAL)])
    rastgele.shuffle(kartlar)
    secenekler = [k for k, _ in kartlar]
    kovalentler = [n for n, (_, tur) in enumerate(kartlar) if tur == "kovalent"]
    kat_simge, kat_ad, kat_z, kat_q, kat_iyon = rastgele.choice(_KATYONLAR)
    an_simge, an_ad, an_z, an_q, an_iyon = rastgele.choice(_ANYONLAR)
    kat_e, an_e = kat_z - kat_q, an_z + an_q
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-malzeme-baglari",
        ders="kimya",
        baslik="Malzeme Bağları",
        kademe=kademe,
        konu="kimyasal_bag",
        kazanim="İyonik, kovalent ve metalik bağı elektronların davranışına göre "
                "ayırt etme; atom ile iyonun elektron sayısını karşılaştırma.",
        dikkat=7,
        brifing=(
            "Malzeme deposunun kartlarına bağ türü yazılacak.\n\n"
            "{} kartlara şu notu düşmüş: \"Bütün bağlar elektron alışverişiyle "
            "oluşur; suda bile hidrojen elektron verir, oksijen alır. Zaten "
            "{} atomu ile {} iyonu aynı şeydir, elektron sayıları da aynıdır.\"\n\n"
            "Kartlar dağıtılmadan önce bağları doğru sınıflandırmamız gerekiyor."
        ).format(kisi, kat_ad, kat_iyon),
        kanitlar=[
            Kanit("Malzeme kartları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Atom numaraları",
                  "{}: {}; {}: {}. Nötr atomda elektron sayısı atom numarasına eşittir."
                  .format(kat_simge, kat_z, an_simge, an_z),
                  bedel=1, kritik=True),
            Kanit("Bağ notu",
                  "Metal ile ametal: elektron aktarılır, iyonlar oluşur. Ametal ile "
                  "ametal: elektronlar ortaklaşa kullanılır, molekül oluşur. Metal "
                  "atomları: değerlik elektronları bütün yapıda serbestçe dolaşır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kimyasal bağlar için hangisi doğrudur?",
                dogru=("Elektron iyonikte aktarılır, kovalentte ortaklaşa kullanılır, "
                       "metalikte serbest dolaşır; iyon elektron almış ya da vermiş atomdur"),
                yanlislar={
                    ("Bütün bağlar elektron alışverişiyle oluşur; her bağda iyonlar "
                     "vardır, çünkü atomlar ancak zıt yüklü olduklarında birbirini "
                     "tutabilir"):
                        "Bağ oluşumunu yalnız elektron alışverişi sandın. İki ametal "
                        "elektronlarını ortaklaşa kullanır; iyon oluşmaz.",
                    ("Atom ile iyonun elektron sayısı aynıdır; yalnız adları farklıdır, "
                     "iyon çözeltideki atoma verilen addır"):
                        "Atomla iyonu karıştırdın. İyon, elektron vererek ya da "
                        "alarak yüklenmiş taneciktir.",
                    "Metal atomları elektronlarını tek bir komşuya kalıcı olarak verir":
                        "Metalde elektronlar tek bir atoma bağlı kalmaz; yapının "
                        "bütününde dolaşır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bağın türü elektronların ne yaptığına bağlıdır: metal ile ametal "
                    "arasında aktarılır (iyonik), ametaller arasında paylaşılır "
                    "(kovalent), metal atomları arasında ortak bir elektron denizi "
                    "oluşur (metalik)."
                ),
                ipuclari=[
                    "Bağ notunda ametal ile ametal arasında ne oluyor?",
                    "İyonun yükü nereden geliyor?",
                ],
                cozum="İyonik: aktarım.\nKovalent: ortaklaşma.\nMetalik: elektron denizi.",
            ),
            coklu_adimi(
                soru="Hangi kartlarda bağlar elektron ortaklaşmasıyla (kovalent) oluşur? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=kovalentler,
                aciklama=("Ametal atomlarından oluşan moleküller kovalenttir. Metal ile "
                          "ametal içerenler iyonik, tek bir metal metaliktir."),
                ipuclari=["Formülde metal atomu olmayan kartları seç."],
                puan=12,
            ),
            sayi_adimi(
                soru="{} iyonunda kaç elektron var?".format(kat_iyon),
                cevap=kat_e,
                aciklama="{} atomunda {} elektron; {} elektron verince {} elektron kalır."
                .format(kat_ad.capitalize(), kat_z, kat_q, kat_e),
                yaygin_yanlislar={
                    kat_z:
                        "Atomla iyonu karıştırdın: {}, atomun elektron sayısı. "
                        "Pozitif iyon elektron vermiştir.".format(kat_z),
                    kat_z + kat_q:
                        "Yük yönünü ters çevirdin: pozitif iyon elektron almış "
                        "değil, vermiştir.",
                },
                ipuclari=["Pozitif yük, elektron verildiğini gösterir."],
                puan=10,
            ),
            sayi_adimi(
                soru="{} iyonunda kaç elektron var?".format(an_iyon),
                cevap=an_e,
                aciklama="{} atomunda {} elektron; {} elektron alınca {} elektron olur."
                .format(an_ad.capitalize(), an_z, an_q, an_e),
                yaygin_yanlislar={
                    an_z:
                        "Atomla iyonu karıştırdın: {}, atomun elektron sayısı. "
                        "Negatif iyon elektron almıştır.".format(an_z),
                    an_z - an_q:
                        "Yük yönünü ters çevirdin: negatif iyon elektron almıştır.",
                },
                ipuclari=["Negatif yük, elektron alındığını gösterir."],
                puan=10,
            ),
            secim_adimi(
                soru="Sudaki (H₂O) O–H bağı için hangisi doğrudur?",
                dogru="Oksijen ve hidrojen elektronlarını ortaklaşa kullanır; iyon oluşmaz",
                yanlislar={
                    "Hidrojen elektronunu verir, oksijen alır; H⁺ ve O²⁻ iyonları oluşur":
                        "Bağ oluşumunu yalnız elektron alışverişi sandın. Oksijen ve "
                        "hidrojen ametaldir; elektronlarını paylaşırlar.",
                    "Elektronlar bütün suda serbestçe dolaşır":
                        "Bu metalik bağın özelliği; su bir molekül.",
                    "Suda bağ yoktur; atomlar yalnız yan yana durur":
                        "Su molekülünde iki O–H kovalent bağı vardır.",
                },
                rastgele=rastgele,
                aciklama=("Oksijen ve hidrojen ametaldir: elektron aktarmak yerine "
                          "ortak elektron çiftleriyle bağlanır. Su bu yüzden iyon "
                          "değil molekül olarak bulunur."),
                ipuclari=["Bağ notunda ametal ile ametal satırını oku."],
                puan=10,
            ),
        ],
        kapanis=("Kartlar düzeltildi: moleküllerde elektronlar paylaşılıyor, iyonik "
                 "bileşiklerde aktarılıyor. {} iyonunda {}, {} iyonunda {} elektron var; "
                 "atomdan farklı.").format(kat_iyon, kat_e, an_iyon, an_e),
        odul={"itibar": 4, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# ZAYIF ETKİLEŞİMLER: KAYNAMADA MOLEKÜL İÇİ BAĞ KIRILMAZ (B37.13)
#
# `zayif_etkilesim` iki satırda boştu (2018: 9; 2026: 9). Bağlam: "Benzer
# maddelerin kaynama davranışlarını karşılaştırma". `yaygin_yanlis`:
#
#   "Moleküller arası etkileşimle molekül içi bağı karıştırmak."
#
# DÜZENEK: üs kazanında su buharlaştırılacak. Buharlaşma ısısı (41 kJ/mol)
# molekülleri birbirinden ayırır; O–H bağı (463 kJ/mol) kırılmaz, buhar yine
# H₂O. İkinci kart: benzer iki madde; ağır olanın molekül içi bağı ZAYIF ama
# kaynama noktası YÜKSEK. Bağ enerjisine bakan yanlış maddeyi seçer.
#
# YANILGILARIN SAYISAL KARŞILIĞI: buharlaşma enerjisini iki O–H bağıyla (ya da
# bir tanesiyle) hesaplamak; gramı mol saymak; molekül içi bağı güçlü olanın
# daha yüksek sıcaklıkta kaynadığını sanmak.
# ==========================================================================

_BUHARLASMA_SU = 41      # kJ/mol
_OH_BAG = 463            # kJ/mol
# (hafif, bağı, bağ enerjisi, kaynama °C), (ağır, ...): ağırın bağı zayıf, kaynaması yüksek
_KAYNAMA_CIFTLERI = (
    (("CH₄", "C–H", 413, -162), ("SiH₄", "Si–H", 318, -112)),
    (("HCl", "H–Cl", 432, -85), ("HBr", "H–Br", 366, -67)),
    (("H₂S", "H–S", 363, -60), ("H₂Se", "H–Se", 276, -41)),
)


def _eksi_derece(sayi):
    return ("−" if sayi < 0 else "") + str(abs(sayi))


@bulmaca(ders="kimya", konu="zayif_etkilesim", kademeler=(9, 13), agirlik=1.3)
def buhar_kazani(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kaynama moleküller arası etkileşimleri yener; molekül içi bağlar kırılmaz."""
    mol = rastgele.choice((2, 3, 5))
    kutle = mol * 18
    enerji = mol * _BUHARLASMA_SU
    hafif, agir = rastgele.choice(_KAYNAMA_CIFTLERI)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-buhar-kazani",
        ders="kimya",
        baslik="Buhar Kazanı",
        kademe=kademe,
        konu="zayif_etkilesim",
        kazanim="Hâl değişiminde moleküller arası etkileşimlerin yenildiğini, molekül "
                "içi kovalent bağların kırılmadığını açıklama; kaynama noktasını "
                "moleküller arası etkileşimlerle karşılaştırma.",
        dikkat=7,
        brifing=(
            "Üs kazanında {} g su buharlaştırılacak; ısıtıcının enerjisi ayarlanacak.\n\n"
            "{} ayarı şöyle hesapladı: \"Su kaynarken O–H bağları kopar; buhar aslında "
            "hidrojen ve oksijendir. Her molekülde iki O–H bağı var, enerjiyi ona göre "
            "verelim. Ayrıca {} bağı {} bağından güçlü; demek ki {} daha yüksek "
            "sıcaklıkta kaynar.\"\n\n"
            "Isıtıcı ayarlanmadan önce hesabı doğru kurmamız gerekiyor."
        ).format(kutle, kisi, hafif[1], agir[1], hafif[0]),
        kanitlar=[
            Kanit("Su kartı",
                  "Su: 18 g/mol. Buharlaşma ısısı {} kJ/mol. O–H bağ enerjisi {} kJ/mol."
                  .format(_BUHARLASMA_SU, _OH_BAG),
                  bedel=1, kritik=True),
            Kanit("Buhar analizi",
                  "Kazandan çıkan buhar yoğunlaştırıldı: yine su elde edildi; "
                  "hidrojen ya da oksijen gazı bulunmadı.",
                  bedel=1, kritik=True),
            Kanit("Madde kartı",
                  "{}: {} bağı {} kJ/mol. {}: {} bağı {} kJ/mol. Ağır ve daha "
                  "çok elektronlu moleküller arasındaki çekim daha büyüktür.".format(
                      hafif[0], hafif[1], hafif[2], agir[0], agir[1], agir[2]),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir molekül maddesi kaynarken ne olur?",
                dogru=("Moleküller arası etkileşimler yenilir, moleküller ayrılır; "
                       "molekül içi kovalent bağlar kırılmaz"),
                yanlislar={
                    ("Molekül içindeki kovalent bağlar kırılır ve atomlar ayrılır; "
                     "buhar kabarcıkları bu atomlardan oluşur"):
                        "Moleküller arası etkileşimle molekül içi bağı karıştırdın. "
                        "Buhar analizinde yine su çıkıyor: moleküller bozulmamış.",
                    "Hem moleküller arası etkileşimler hem molekül içi bağlar aynı anda kırılır":
                        "Molekül içi bağlar çok daha güçlüdür; kaynama sıcaklığında "
                        "kırılmazlar.",
                    "Hiçbir etkileşim yenilmez; yalnız sıcaklık artar":
                        "Kaynamada sıcaklık sabit kalır, verilen enerji molekülleri "
                        "ayırmaya harcanır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kaynama bir hâl değişimidir: moleküller aynı kalır, aralarındaki "
                    "çekim yenilir. Bu çekimler bağlardan çok zayıftır; bu yüzden "
                    "buharlaşma ısısı bağ enerjisinden çok küçüktür."
                ),
                ipuclari=[
                    "Buhar analizi ne gösteriyor?",
                    "Su kartındaki iki enerjiyi karşılaştır.",
                ],
                cozum="Kaynama: moleküller arası etkileşim yenilir; kovalent bağ sağlam.",
            ),
            secim_adimi(
                soru="Kazandan çıkan buhar hangi taneciklerden oluşur?",
                dogru="H₂O moleküllerinden; moleküller yalnız birbirinden ayrıldı",
                yanlislar={
                    ("H₂ ve O₂ moleküllerinden; ısıyla O–H bağları koptu, su "
                     "bileşenlerine ayrıştı"):
                        "Moleküller arası etkileşimle molekül içi bağı karıştırdın; "
                        "buhar analizi yalnız su buldu.",
                    "Tek tek H ve O atomlarından":
                        "Atomları ayırmak bağ kırmayı gerektirir; kaynamada olmaz.",
                },
                rastgele=rastgele,
                aciklama="Buhar yoğunlaşınca yine su oluyor: moleküller bozulmadı.",
                ipuclari=["Buhar analizini oku."],
                puan=10,
            ),
            sayi_adimi(
                soru="{} g suyu buharlaştırmak için kaç kJ gerekir?".format(kutle),
                cevap=enerji,
                birim="kJ",
                aciklama="{} g ÷ 18 g/mol = {} mol. {} × {} = {} kJ.".format(
                    kutle, mol, mol, _BUHARLASMA_SU, enerji),
                yaygin_yanlislar={
                    mol * 2 * _OH_BAG:
                        "Moleküller arası etkileşimle molekül içi bağı karıştırdın: "
                        "iki O–H bağının enerjisini kullandın.",
                    mol * _OH_BAG:
                        "Moleküller arası etkileşimle molekül içi bağı karıştırdın: "
                        "O–H bağ enerjisini kullandın.",
                    kutle * _BUHARLASMA_SU:
                        "Gramı mol saydın; önce 18 g/mol ile böl.",
                },
                ipuclari=["Önce mol sayısını bul; buharlaşma ısısını kullan."],
                puan=12,
            ),
            secim_adimi(
                soru="{} ile {} hangisi daha yüksek sıcaklıkta kaynar?".format(hafif[0], agir[0]),
                dogru="{}: moleküller arası çekimi daha büyük".format(agir[0]),
                yanlislar={
                    "{}: molekül içi bağı daha güçlü".format(hafif[0]):
                        "Moleküller arası etkileşimle molekül içi bağı karıştırdın. "
                        "Kaynarken {} bağı kırılmaz; önemli olan moleküller "
                        "arasındaki çekimdir.".format(hafif[1]),
                    "İkisi aynı sıcaklıkta kaynar; benzer maddelerdir":
                        "Benzer moleküllerde ağır ve çok elektronlu olanın "
                        "moleküller arası çekimi daha büyüktür.",
                },
                rastgele=rastgele,
                aciklama=("{} {} °C sıcaklıkta, {} {} °C sıcaklıkta kaynar. {} bağı daha zayıf olsa da "
                          "molekülleri arasındaki çekim daha büyüktür.").format(
                    agir[0], _eksi_derece(agir[3]), hafif[0], _eksi_derece(hafif[3]), agir[1]),
                ipuclari=["Madde kartındaki son cümleyi oku."],
                puan=12,
            ),
        ],
        kapanis=("Ayar düzeltildi: {} g su için {} kJ yeter; O–H bağları sağlam kalıyor. "
                 "{}, {} maddesinden daha yüksek sıcaklıkta kaynıyor."
                 ).format(kutle, enerji, agir[0], hafif[0]),
        odul={"itibar": 4, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# SIVILARIN ÖZELLİKLERİ: BUHARLAŞMA HER SICAKLIKTA, KAYNAMA BASINCA BAĞLI
#
# `sivi_ozellikleri` iki satırda boştu (2018: 9; 2026: 9). Bağlam: "Depodaki
# sıvıların sıcaklık ve akış kayıtlarını karşılaştırma". `yaygin_yanlis`:
#
#   "Buharlaşmayı yalnız kaynama sıcaklığında olur sanmak."
#
# DÜZENEK: 20 °C depoda kapağı açık iki su tankı (geniş ve dar) ve kapalı bir
# kavanoz. Açık tanklar yüzeyden su kaybeder, kayıp yüzey alanıyla orantılı.
# Dağ istasyonunda dış basınç düşük: su, buhar basıncı dış basınca eşit
# olduğunda (100 °C altında) kaynar.
#
# YANILGILARIN SAYISAL KARŞILIĞI: 100 °C altında kaybı sıfır yazmak; dar
# tankın alanını ya da alanı hiç kullanmamak; kaynamayı her yerde 100 °C
# saymak.
# ==========================================================================

# dış basınç kPa -> suyun kaynadığı sıcaklık °C (buhar basıncı tablosundan)
_BUHAR_BASINCI = ((47, 80), (58, 85), (70, 90), (85, 95), (101, 100))
_DAR_ALAN = 0.5   # m²


@bulmaca(ders="kimya", konu="sivi_ozellikleri", kademeler=(9, 13), agirlik=1.3)
def depo_tanklari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Buharlaşma kaynama sıcaklığının altında da yüzeyde olur; kaynama dış basınca bağlıdır."""
    hiz = rastgele.choice((300, 400, 500))          # g / (m² · gün)
    alan = rastgele.choice((2, 3))
    gun = rastgele.choice((5, 10))
    kayip = hiz * alan * gun / 1000.0               # kg
    istasyon_p, istasyon_t = rastgele.choice(_BUHAR_BASINCI[1:4])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    tablo = "; ".join("{} °C: {} kPa".format(t, p) for p, t in _BUHAR_BASINCI)

    return Bulmaca(
        kod="kim-depo-tanklari",
        ders="kimya",
        baslik="Depo Tankları",
        kademe=kademe,
        konu="sivi_ozellikleri",
        kazanim="Buharlaşmanın kaynama sıcaklığının altında da sıvı yüzeyinde "
                "gerçekleştiğini açıklama; buharlaşma hızını yüzey alanıyla "
                "ilişkilendirme; kaynamayı buhar basıncı ve dış basınçla açıklama.",
        dikkat=7,
        brifing=(
            "Depodaki su tanklarının kapakları açık duruyor; sefer öncesi su "
            "stoku hesaplanacak.\n\n"
            "{} rapora şunu yazdı: \"Depo hiç 100 °C olmuyor, su da ancak 100 °C "
            "sıcaklıkta buharlaşır. Kapaklar açık kalabilir, stok eksilmez. Dağ "
            "istasyonunda da su yine 100 °C sıcaklıkta kaynar.\"\n\n"
            "Stok onaylanmadan önce kayıtları doğru yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Tank kaydı",
                  "Depo 20 °C. Geniş tankın su yüzeyi {} m², dar tankınki {} m². "
                  "Açık su yüzeyi bu depoda günde metrekare başına {} g buharlaşıyor. "
                  "Kapalı kavanozdaki su bir ayda eksilmedi.".format(alan, sy(_DAR_ALAN), hiz),
                  bedel=1, kritik=True),
            Kanit("Buhar basıncı tablosu", "Suyun buhar basıncı: " + tablo + ".",
                  bedel=1, kritik=True),
            Kanit("İstasyon kaydı",
                  "Dağ istasyonunda hava basıncı {} kPa.".format(istasyon_p),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Buharlaşma ve kaynama için hangisi doğrudur?",
                dogru=("Buharlaşma her sıcaklıkta yüzeyde olur; kaynama, buhar "
                       "basıncı dış basınca eşitken tüm sıvıda olur"),
                yanlislar={
                    ("Buharlaşma yalnız kaynama sıcaklığında olur; daha soğuk "
                     "sıvıda moleküller yüzeyden kopacak enerjiyi bulamaz"):
                        "Buharlaşmayı yalnız kaynama sıcaklığında olur sandın. Yüzeydeki "
                        "hızlı moleküller her sıcaklıkta sıvıdan kopabilir.",
                    ("Su her yerde yalnız 100 °C sıcaklıkta kaynar; kaynama "
                     "noktası suyun değişmez bir özelliğidir"):
                        "Kaynama sıcaklığı dış basınca bağlıdır; basınç düşükse su "
                        "daha düşük sıcaklıkta kaynar.",
                    "Kapalı kapta buharlaşma hiç olmaz":
                        "Kapalı kapta da buharlaşma olur; ama buhar kaçamaz ve "
                        "yoğuşmayla dengelenir, su eksilmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sıvının yüzeyindeki moleküllerin bir kısmı her sıcaklıkta "
                    "kopacak kadar enerjiye sahiptir: buharlaşma sürekli olur ve "
                    "yüzey büyüdükçe hızlanır. Kaynama ise sıvının içinde de buhar "
                    "kabarcıkları oluşmasıdır; buhar basıncı dış basınca ulaşınca "
                    "başlar."
                ),
                ipuclari=[
                    "Tank kaydında 20 °C depoda su eksiliyor mu?",
                    "Buhar basıncı tablosunda 100 °C karşısında hangi basınç var?",
                ],
                cozum="Buharlaşma: yüzey, her sıcaklık.\nKaynama: buhar basıncı = dış basınç.",
            ),
            sayi_adimi(
                soru="Geniş tank {} günde kaç kg su kaybeder?".format(gun),
                cevap=kayip,
                birim="kg",
                aciklama="{} g × {} m² × {} gün = {} g = {} kg.".format(
                    hiz, alan, gun, int(kayip * 1000), sy(kayip)),
                yaygin_yanlislar={
                    0:
                        "Buharlaşmayı yalnız kaynama sıcaklığında olur sandın; 20 °C "
                        "depoda da açık yüzeyden su buharlaşıyor.",
                    sy(hiz * _DAR_ALAN * gun / 1000.0).replace(",", "."):
                        "Dar tankın yüzey alanını kullandın.",
                    sy(hiz * gun / 1000.0).replace(",", "."):
                        "Yüzey alanını hesaba katmadın; kayıp metrekare başına verilmiş.",
                },
                ipuclari=["Metrekare başına günlük kaybı alanla ve gün sayısıyla çarp."],
                puan=12,
                tolerans=0.001,
            ),
            secim_adimi(
                soru="Aynı depoda geniş ve dar tanktan hangisi günde daha çok su kaybeder?",
                dogru="Geniş tank: buharlaşma yüzeyden olur, yüzeyi daha büyük",
                yanlislar={
                    "İkisi de hiç kaybetmez; depo 100 °C değil":
                        "Buharlaşmayı yalnız kaynama sıcaklığında olur sandın.",
                    ("İkisi aynı miktarda kaybeder; buharlaşmayı yalnız sıcaklık "
                     "belirler, sıcaklıkları aynı"):
                        "Aynı sıcaklıkta birim yüzeyden aynı hızla buharlaşır; toplam "
                        "kayıp yüzey alanıyla artar.",
                    "Dar tank: su daha derin olduğu için buharlaşacak su da daha çok":
                        "Derinlik değil yüzey alanı belirler.",
                },
                rastgele=rastgele,
                aciklama="Geniş tank {} m², dar tank {} m²: geniş tank {} kat fazla kaybeder."
                .format(alan, sy(_DAR_ALAN), int(alan / _DAR_ALAN)),
                ipuclari=["Buharlaşma sıvının neresinde olur?"],
                puan=10,
            ),
            sayi_adimi(
                soru="Dağ istasyonunda su kaç °C sıcaklıkta kaynar?",
                cevap=istasyon_t,
                birim="°C",
                aciklama=("Kaynama, buhar basıncı dış basınca eşit olunca başlar. "
                          "Tabloda {} kPa karşısında {} °C var.").format(istasyon_p, istasyon_t),
                yaygin_yanlislar={
                    100:
                        "Kaynamayı her yerde 100 °C saydın; 100 °C yalnız deniz "
                        "seviyesindeki basınç (101 kPa) için geçerli.",
                },
                ipuclari=["Buhar basıncı tablosunda istasyon basıncını bul."],
                puan=12,
            ),
            yorum_adimi(
                soru="Tank kapakları için hangi karar doğru?",
                dogru="Kapaklar kapatılmalı: su 20 °C sıcaklıkta da yüzeyden buharlaşıp eksiliyor",
                yanlislar={
                    ("Kapaklar açık kalabilir: depo 100 °C olmadığı için su "
                     "kaynamaz, dolayısıyla eksilmez"):
                        "Buharlaşmayı yalnız kaynama sıcaklığında olur sandın; tank "
                        "kaydı açık tankların su kaybettiğini gösteriyor.",
                    "Yalnız dar tankın kapağı kapatılmalı":
                        "Geniş tank daha çok su kaybediyor; ikisi de kapatılmalı.",
                },
                rastgele=rastgele,
                aciklama=("Kapalı kavanozda buhar kaçamadığı için su eksilmedi; açık "
                          "tanklar {} günde geniş tanktan {} kg kaybediyor.").format(gun, sy(kayip)),
                ipuclari=["Kapalı kavanozla açık tankı karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("Rapor düzeltildi: açık geniş tank {} günde {} kg su kaybediyor, "
                 "kapaklar kapatıldı. Dağ istasyonunda su {} °C sıcaklıkta kaynar."
                 ).format(gun, sy(kayip), istasyon_t),
        odul={"itibar": 4, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# ORBİTAL VE ELEKTRON DAĞILIMI: OLASILIK BÖLGESİ, YERLEŞME KURALLARI (B37.13)
#
# `orbital_elektron` iki satırda boştu (2018: 9; 2026: 9). Bağlam: "Bilim
# arşivindeki elektron dağılımlarını denetleme". `yaygin_yanlis`:
#
#   "Orbitali elektronun kesin yörüngesi sanmak; yerleşme kurallarını karıştırmak."
#
# DÜZENEK: arşivde dört elementin dağılım kartı; bir ya da ikisi hatalı
# (Pauli: s orbitaline 3 elektron; Aufbau: 3s boşken 3p, 4s yerine 3d).
# Hund kuralı sayısal adımda: p² / p³ / p⁴ katmanında yarı dolu orbital sayısı.
# Hund yanılgısı (önce eşleştirmek) p² ve p⁴ için 0, p³ için 1 verir.
# ==========================================================================

_ORBITAL_SIRASI = (("1s", 2), ("2s", 2), ("2p", 6), ("3s", 2), ("3p", 6), ("4s", 2))
_UST_RAKAM = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")
_ELEMENT_Z = (("lityum", "Li", 3), ("berilyum", "Be", 4), ("bor", "B", 5),
              ("karbon", "C", 6), ("azot", "N", 7), ("oksijen", "O", 8),
              ("flor", "F", 9), ("neon", "Ne", 10), ("sodyum", "Na", 11),
              ("magnezyum", "Mg", 12), ("alüminyum", "Al", 13), ("silisyum", "Si", 14),
              ("fosfor", "P", 15), ("kükürt", "S", 16), ("klor", "Cl", 17),
              ("argon", "Ar", 18), ("potasyum", "K", 19), ("kalsiyum", "Ca", 20))
_HUND_ELEMENTLERI = ("C", "N", "O", "Si", "P", "S")


def _dagilim(z):
    """Atom numarasından (z ≤ 20) [(alt katman, elektron), ...]."""
    parca, kalan = [], z
    for ad, kapasite in _ORBITAL_SIRASI:
        if kalan <= 0:
            break
        n = min(kapasite, kalan)
        parca.append((ad, n))
        kalan -= n
    return parca


def _dagilim_yazisi(parca):
    return " ".join(ad + str(n).translate(_UST_RAKAM) for ad, n in parca)


def _hatali_dagilim(z, rastgele):
    """Yerleşme kuralını çiğneyen bir dağılım yazısı (z için uygun bir hata türüyle)."""
    dogru = _dagilim(z)
    turler = []
    if 5 <= z <= 10:
        turler.append("pauli")
    if 12 <= z <= 16 or z in (19, 20):
        turler.append("aufbau")
    tur = rastgele.choice(turler)
    if tur == "pauli":
        yeni = [("1s", 2), ("2s", 3)] + ([("2p", z - 5)] if z > 5 else [])
    elif z <= 16:
        yeni = [("1s", 2), ("2s", 2), ("2p", 6), ("3p", z - 10)]
    else:
        yeni = dogru[:-1] + [("3d", z - 18)]
    return _dagilim_yazisi(yeni)


@bulmaca(ders="kimya", konu="orbital_elektron", kademeler=(9, 13), agirlik=1.3)
def dagilim_arsivi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Orbital olasılık bölgesidir; elektronlar Aufbau, Pauli ve Hund kurallarıyla yerleşir."""
    hatali_adaylar = [e for e in _ELEMENT_Z if 5 <= e[2] <= 10 or 12 <= e[2] <= 16 or e[2] in (19, 20)]
    hatali_sayi = rastgele.choice((1, 2))
    hatalilar = rastgele.sample(hatali_adaylar, hatali_sayi)
    dogrular = rastgele.sample([e for e in _ELEMENT_Z if e not in hatalilar], 4 - hatali_sayi)
    arsiv = [(e, False) for e in dogrular] + [(e, True) for e in hatalilar]
    rastgele.shuffle(arsiv)
    kartlar = []
    for (ad, simge, z), hatali in arsiv:
        yazi = _hatali_dagilim(z, rastgele) if hatali else _dagilim_yazisi(_dagilim(z))
        kartlar.append("{} ({}, Z = {}): {}".format(_buyuk_harfle(ad), simge, z, yazi))
    hatali_indeksler = [n for n, (_, hatali) in enumerate(arsiv) if hatali]

    hund_simge = rastgele.choice(_HUND_ELEMENTLERI)
    hund_ad, _, hund_z = [e for e in _ELEMENT_Z if e[1] == hund_simge][0]
    son_katman, p_sayi = _dagilim(hund_z)[-1]
    yari_dolu = p_sayi if p_sayi <= 3 else 6 - p_sayi
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-dagilim-arsivi",
        ders="kimya",
        baslik="Dağılım Arşivi",
        kademe=kademe,
        konu="orbital_elektron",
        kazanim="Orbitali elektronun bulunma olasılığının yüksek olduğu bölge olarak "
                "açıklama; Aufbau, Pauli ve Hund kurallarıyla elektron dağılımı yazma "
                "ve hatalı dağılımları bulma.",
        dikkat=8,
        brifing=(
            "Bilim arşivindeki elektron dağılımı kartları denetlenecek; hatalı "
            "kartlar eğitim setinden çıkarılacak.\n\n"
            "{} kartların arkasına not düşmüş: \"Orbital, elektronun çekirdek "
            "çevresinde döndüğü kesin yoldur. {} atomunun {} elektronları aynı "
            "orbitalde çift oluşturur; önce çiftler dolar.\"\n\n"
            "Kartlar dağıtılmadan önce dağılımları doğru denetlememiz gerekiyor."
        ).format(kisi, _buyuk_harfle(hund_ad), son_katman),
        kanitlar=[
            Kanit("Arşiv kartları", "\n".join(kartlar), bedel=1, kritik=True),
            Kanit("Yerleşme kuralları",
                  "Aufbau: elektronlar düşük enerjili orbitalden başlar (1s, 2s, 2p, "
                  "3s, 3p, 4s, 3d). Pauli: bir orbitalde en çok 2 zıt spinli elektron "
                  "bulunur; s alt katmanı 2, p alt katmanı 6 elektron alır. Hund: eş "
                  "enerjili orbitallere elektronlar önce birer birer yerleşir.",
                  bedel=1, kritik=True),
            Kanit("Orbital notu",
                  "Orbital, elektronun bulunma olasılığının yüksek olduğu bölgedir; "
                  "elektronun izlediği bir yol değildir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Orbital ve elektron yerleşimi için hangisi doğrudur?",
                dogru=("Orbital, elektronun büyük olasılıkla bulunduğu bölgedir; "
                       "yerleşim Aufbau, Pauli ve Hund kurallarına uyar"),
                yanlislar={
                    ("Orbital, elektronun çekirdek çevresinde döndüğü kesin yoldur; "
                     "gezegenlerin Güneş çevresindeki yörüngesi gibi"):
                        "Orbitali elektronun kesin yörüngesi sandın. Elektronun yolu "
                        "belirlenemez; orbital yalnız nerede bulunma olasılığının "
                        "yüksek olduğunu gösterir.",
                    ("Eş enerjili orbitallerde elektronlar önce çift oluşturur; "
                     "eşleşen elektronlar daha kararlıdır"):
                        "Yerleşme kurallarını karıştırdın. Hund kuralına göre önce "
                        "birer birer yerleşirler.",
                    "Bir orbitale istenildiği kadar elektron girebilir":
                        "Pauli ilkesine göre bir orbitalde en çok 2 elektron bulunur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kuantum modelinde elektronun kesin konumu ve yolu bilinemez; "
                    "orbital bir olasılık bölgesidir. Elektronlar önce düşük enerjili "
                    "orbitallere (Aufbau), orbital başına en çok iki (Pauli), eş "
                    "enerjililere önce tek tek (Hund) yerleşir."
                ),
                ipuclari=[
                    "Orbital notu ne diyor?",
                    "Yerleşme kurallarında Hund kuralını oku.",
                ],
                cozum="Orbital: olasılık bölgesi.\nAufbau -> Pauli -> Hund.",
            ),
            sayi_adimi(
                soru="{} atomunun {} alt katmanında kaç yarı dolu orbital var?".format(
                    _buyuk_harfle(hund_ad), son_katman),
                cevap=yari_dolu,
                aciklama=("{} alt katmanında {} elektron, 3 orbital. Hund: önce her "
                          "orbitale birer elektron. Yarı dolu orbital: {}.").format(
                    son_katman, p_sayi, yari_dolu),
                yaygin_yanlislar={
                    p_sayi % 2:
                        "Yerleşme kurallarını karıştırdın: elektronları önce çift "
                        "yaptın. Hund kuralına göre eş enerjili orbitallere önce "
                        "birer birer yerleşirler.",
                },
                ipuclari=["Üç p orbitalini üç kutu gibi düşün; önce her kutuya bir elektron."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi arşiv kartlarındaki dağılım hatalı? (numaraları virgülle yaz)",
                secenekler=kartlar,
                dogru_indeksler=hatali_indeksler,
                aciklama=("Hatalı kartlarda ya bir s alt katmanına 2'den fazla elektron "
                          "konmuş (Pauli) ya da düşük enerjili orbital boşken üstteki "
                          "doldurulmuş (Aufbau)."),
                ipuclari=["Her kartta elektron toplamını ve orbital sırasını denetle."],
                puan=14,
            ),
            secim_adimi(
                soru="Karttaki \"orbital kesin yoldur\" notu için hangisi doğru?",
                dogru="Yanlış: orbital elektronun bulunma olasılığının yüksek olduğu bölgedir",
                yanlislar={
                    ("Doğru: elektron orbital boyunca sabit bir yolda döner, tıpkı "
                     "Bohr modelindeki gibi"):
                        "Orbitali elektronun kesin yörüngesi sandın; bu Bohr modelinin "
                        "yörünge fikridir, orbital değil.",
                    "Doğru, ama yalnız s orbitalleri için":
                        "Hiçbir orbital kesin bir yol değildir.",
                },
                rastgele=rastgele,
                aciklama="Orbital notu: olasılık bölgesi, yol değil.",
                ipuclari=["Orbital notunu oku."],
                puan=8,
            ),
        ],
        kapanis=("Arşiv düzeltildi: {} hatalı kart ayrıldı; {} alt katmanında {} yarı dolu "
                 "orbital var. Orbital bir yol değil, olasılık bölgesi."
                 ).format(hatali_sayi, son_katman, yari_dolu),
        odul={"itibar": 5, "cevher": 1, "enerji": 1},
    )


# ==========================================================================
# HİDROKARBONLAR: AYNI MOLEKÜL FORMÜLÜ, FARKLI YAPI (İZOMERİ) (B37.13)
#
# `hidrokarbon` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Üs bilim
# arşivindeki organik yapı modellerini sınıflandırma". `yaygin_yanlis`:
#
#   "Aynı molekül formülünü aynı yapı sanmak."
#
# DÜZENEK: arşivde yapı kartları. Hedef formülün (C₄H₁₀ ya da C₅H₁₂) bütün
# yapı izomerleri + başka formülde iki kart. Kaynama noktaları farklı:
# dallanma arttıkça düşer. İzomer sayısı yanılgısı 1 verir ("hepsi aynı").
# ==========================================================================

# formül -> ((ad, yapı, kaynama °C), ...): bütün yapı izomerleri
_IZOMERLER = {
    "C₄H₁₀": (("bütan", "CH₃–CH₂–CH₂–CH₃", -1),
              ("2-metilpropan", "CH₃–CH(CH₃)–CH₃", -12)),
    "C₅H₁₂": (("pentan", "CH₃–CH₂–CH₂–CH₂–CH₃", 36),
              ("2-metilbütan", "CH₃–CH(CH₃)–CH₂–CH₃", 28),
              ("2,2-dimetilpropan", "CH₃–C(CH₃)₂–CH₃", 10)),
}
_BASKA_YAPILAR = {
    "C₄H₁₀": (("1-büten", "CH₂=CH–CH₂–CH₃"), ("pentan", "CH₃–CH₂–CH₂–CH₂–CH₃")),
    "C₅H₁₂": (("1-penten", "CH₂=CH–CH₂–CH₂–CH₃"), ("bütan", "CH₃–CH₂–CH₂–CH₃")),
}


@bulmaca(ders="kimya", konu="hidrokarbon", kademeler=(12, 13), agirlik=1.3)
def yapi_kartlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı molekül formülündeki farklı yapılar farklı maddelerdir (yapı izomerisi)."""
    formul = rastgele.choice(sorted(_IZOMERLER))
    izomerler = _IZOMERLER[formul]
    kartlar = [(y, True) for _, y, _ in izomerler] + [(y, False) for _, y in _BASKA_YAPILAR[formul]]
    rastgele.shuffle(kartlar)
    secenekler = [y for y, _ in kartlar]
    hedefler = [n for n, (_, uygun) in enumerate(kartlar) if uygun]
    iki = rastgele.sample(izomerler, 2)
    yuksek = max(iki, key=lambda i: i[2])
    dusuk = min(iki, key=lambda i: i[2])
    c_sayi, h_sayi = (4, 10) if formul == "C₄H₁₀" else (5, 12)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-yapi-kartlari",
        ders="kimya",
        baslik="Yapı Kartları",
        kademe=kademe,
        konu="hidrokarbon",
        kazanim="Aynı molekül formülüne sahip farklı yapıların (yapı izomerleri) farklı "
                "maddeler olduğunu açıklama; yapı formülünden molekül formülünü "
                "çıkarma; dallanmanın kaynama noktasına etkisini yorumlama.",
        dikkat=8,
        brifing=(
            "Bilim arşivindeki organik yapı kartları sınıflandırılacak.\n\n"
            "{} kartları ayıklarken şunu yazdı: \"{} yazan kartların hepsi aynı "
            "madde; formülleri aynıysa yapıları da aynıdır. Birini tutup ötekileri "
            "atalım. Kaynama noktaları farklı yazılmışsa ölçüm hatasıdır.\"\n\n"
            "Kartlar atılmadan önce yapıları doğru karşılaştırmamız gerekiyor."
        ).format(kisi, formul),
        kanitlar=[
            Kanit("Yapı kartları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Kaynama kaydı",
                  "{} ({}): {} °C.\n{} ({}): {} °C.".format(
                      _buyuk_harfle(iki[0][0]), iki[0][1], _eksi_derece(iki[0][2]),
                      _buyuk_harfle(iki[1][0]), iki[1][1], _eksi_derece(iki[1][2])),
                  bedel=1, kritik=True),
            Kanit("İzomeri notu",
                  "Molekül formülü yalnız atom sayılarını verir. Atomların farklı "
                  "sırayla bağlandığı yapılar farklı maddelerdir. Zincir dallandıkça "
                  "molekül küreselleşir, kaynama noktası düşer.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Aynı molekül formülüne sahip hidrokarbonlar için hangisi doğrudur?",
                dogru=("Atomlar farklı sırayla bağlanabilir; farklı yapılar farklı "
                       "özellikte farklı maddelerdir"),
                yanlislar={
                    ("Aynı molekül formülü her zaman aynı yapıyı ve aynı maddeyi "
                     "gösterir; formül maddenin kimliğidir"):
                        "Aynı molekül formülünü aynı yapı sandın. Formül atomları "
                        "sayar; nasıl bağlandıklarını söylemez.",
                    ("Yapıları farklı olabilir ama bütün özellikleri aynıdır; "
                     "özellikleri atomların türü ve sayısı belirler"):
                        "Yapı değişince moleküller arası çekim de değişir; kaynama "
                        "noktaları farklıdır.",
                    "Aynı formüllü iki madde ancak biri doymamışsa farklı olur":
                        "Doymuş zincirler de dallanarak farklı yapılar oluşturabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yapı izomerlerinde atom sayıları aynı, bağlanma sırası farklıdır. "
                    "Düz zincir ile dallanmış zincir farklı maddelerdir: molekül "
                    "biçimi değişince moleküller arası çekim ve kaynama noktası da "
                    "değişir."
                ),
                ipuclari=[
                    "Kaynama kaydındaki iki kartın formülünü say.",
                    "İzomeri notu dallanma için ne diyor?",
                ],
                cozum="Aynı formül ≠ aynı yapı (izomer).",
            ),
            sayi_adimi(
                soru="Arşivde {} formülüne uyan kaç farklı yapı kartı var?".format(formul),
                cevap=len(izomerler),
                aciklama="Karbon ve hidrojenleri say: {} kart {} formülünde ve yapıları "
                         "birbirinden farklı.".format(len(izomerler), formul),
                yaygin_yanlislar={
                    1:
                        "Aynı molekül formülünü aynı yapı sandın; kartlardaki "
                        "bağlanma sıraları farklı.",
                },
                ipuclari=["Her kartta C ve H atomlarını say; parantezdeki grupları unutma."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi kartlar {} formülündedir? (numaraları virgülle yaz)".format(formul),
                secenekler=secenekler,
                dogru_indeksler=hedefler,
                aciklama=("{} için {} karbon ve {} hidrojen olmalı. Çift bağlı kartta "
                          "iki hidrojen eksik, öteki kartta karbon sayısı farklı."
                          ).format(formul, c_sayi, h_sayi),
                ipuclari=["Parantez içindeki CH₃ gruplarını da say."],
                puan=12,
            ),
            secim_adimi(
                soru="{} ile {} için hangisi doğrudur?".format(_buyuk_harfle(iki[0][0]), iki[1][0]),
                dogru="{} daha yüksek sıcaklıkta kaynar: zinciri daha az dallanmış".format(_buyuk_harfle(yuksek[0])),
                yanlislar={
                    "İkisi aynı maddedir; farklı kaynama noktası ölçüm hatasıdır":
                        "Aynı molekül formülünü aynı yapı sandın. Yapıları farklı; "
                        "kaynama noktaları da gerçekten farklı.",
                    "{} daha yüksek sıcaklıkta kaynar: zinciri daha çok dallanmış".format(_buyuk_harfle(dusuk[0])):
                        "Dallanma molekülü küreselleştirir, temas yüzeyi küçülür; "
                        "kaynama noktası düşer.",
                },
                rastgele=rastgele,
                aciklama="{}: {} °C; {}: {} °C. Aynı formül, farklı yapı, farklı madde.".format(
                    _buyuk_harfle(yuksek[0]), _eksi_derece(yuksek[2]), dusuk[0], _eksi_derece(dusuk[2])),
                ipuclari=["Kaynama kaydını ve izomeri notunu birlikte oku."],
                puan=12,
            ),
        ],
        kapanis=("Arşiv düzeltildi: {} formülünde {} ayrı madde var; hiçbir kart "
                 "atılmadı. {} ile {} arasındaki kaynama farkı ölçüm hatası değil, "
                 "yapı farkı.").format(formul, len(izomerler), _buyuk_harfle(yuksek[0]), dusuk[0]),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# KARBON KİMYASI: ORGANİK-İNORGANİK, MOLEKÜL VE YAPI FORMÜLÜ (B37.13)
#
# `karbon_yapisi` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Karbonlu
# malzeme kartlarında yapı ve gösterimi eşleme". `yaygin_yanlis`:
#
#   "Her karbon bileşiğini organik sanmak; molekül formülünü yapı formülüyle
#    eşitlemek."
#
# DÜZENEK: malzeme rafında karbonlu maddeler (CO₂, kireç taşı, kabartma tozu
# gibi inorganikler ve metan, etanol gibi organikler). Yapı kartlarında aynı
# molekül formülüne (C₂H₆O ya da C₃H₈O) uyan farklı yapılar: alkol ve eter.
#
# YANILGILARIN KARŞILIĞI: karbon içeren her kartı organik seçmek; aynı
# molekül formülündeki yapıları tek madde saymak (sayı adımında 1).
# ==========================================================================

_INORGANIK_KARBON = (("CO₂", "karbon dioksit"), ("CaCO₃", "kireç taşı"),
                     ("CO", "karbon monoksit"), ("NaHCO₃", "kabartma tozu"))
_ORGANIK_KARBON = (("CH₄", "metan"), ("C₂H₅OH", "etanol"), ("C₁₂H₂₂O₁₁", "sakaroz"),
                   ("CH₃COOH", "asetik asit"), ("C₃H₈", "propan"))
# molekül formülü -> (uyan yapılar (ad, yapı, kaynama °C), uymayan yapılar)
_FORMUL_YAPILARI = {
    "C₂H₆O": ((("etanol", "CH₃–CH₂–OH", 78), ("dimetil eter", "CH₃–O–CH₃", -24)),
              ("CH₃–CHO", "CH₃–CH₂–CH₂–OH")),
    "C₃H₈O": ((("1-propanol", "CH₃–CH₂–CH₂–OH", 97), ("2-propanol", "CH₃–CH(OH)–CH₃", 82),
               ("etil metil eter", "CH₃–CH₂–O–CH₃", 7)),
              ("CH₃–CO–CH₃", "CH₃–CH₂–OH")),
}


@bulmaca(ders="kimya", konu="karbon_yapisi", kademeler=(12, 13), agirlik=1.3)
def karbon_rafi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Karbon içeren her bileşik organik değildir; molekül formülü yapıyı belirlemez."""
    inorganik = rastgele.sample(_INORGANIK_KARBON, 3)
    organik = rastgele.sample(_ORGANIK_KARBON, 3)
    raf = [(m, False) for m in inorganik] + [(m, True) for m in organik]
    rastgele.shuffle(raf)
    raf_secenekleri = ["{} ({})".format(f, ad) for (f, ad), _ in raf]
    organikler = [n for n, (_, org) in enumerate(raf) if org]

    formul = rastgele.choice(sorted(_FORMUL_YAPILARI))
    uyanlar, uymayanlar = _FORMUL_YAPILARI[formul]
    yapilar = [y for _, y, _ in uyanlar] + list(uymayanlar)
    rastgele.shuffle(yapilar)
    iki = rastgele.sample(uyanlar, 2)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-karbon-rafi",
        ders="kimya",
        baslik="Karbon Rafı",
        kademe=kademe,
        konu="karbon_yapisi",
        kazanim="Karbon içeren inorganik bileşikleri organik bileşiklerden ayırma; "
                "molekül formülü ile yapı formülünün farkını açıklama; aynı molekül "
                "formülüne uyan farklı yapıları bulma.",
        dikkat=8,
        brifing=(
            "Malzeme deposunda karbonlu maddeler için yeni raf düzeni kurulacak.\n\n"
            "{} planı yazdı: \"İçinde karbon olan her madde organiktir; hepsi organik "
            "rafa. Yapı kartlarında da {} yazanlar tek bir maddedir; molekül formülü "
            "aynıysa yapı da aynıdır, bir kart yeter.\"\n\n"
            "Raflar düzenlenmeden önce kartları doğru ayırmamız gerekiyor."
        ).format(kisi, formul),
        kanitlar=[
            Kanit("Raf listesi", "\n".join(raf_secenekleri), bedel=1, kritik=True),
            Kanit("Yapı kartları", "\n".join(yapilar), bedel=1, kritik=True),
            Kanit("Sınıflandırma notu",
                  "Organik bileşiklerde karbon atomları hidrojenle (çoğu kez zincir "
                  "hâlinde) bağlanır. CO, CO₂, karbonatlar ve hidrojen karbonatlar "
                  "karbon içerse de inorganik sayılır.",
                  bedel=1),
            Kanit("Kaynama kaydı",
                  "{} ({}): {} °C. {} ({}): {} °C.".format(
                      _buyuk_harfle(iki[0][0]), iki[0][1], _eksi_derece(iki[0][2]),
                      _buyuk_harfle(iki[1][0]), iki[1][1], _eksi_derece(iki[1][2])),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Karbon bileşikleri ve formüller için hangisi doğrudur?",
                dogru=("CO₂ gibi bazı karbon bileşikleri inorganiktir; molekül "
                       "formülü atom sayısını, yapı formülü bağlanışı gösterir"),
                yanlislar={
                    ("İçinde karbon bulunan her bileşik organiktir; organik kimya "
                     "karbonun kimyasıdır"):
                        "Her karbon bileşiğini organik sandın. CO₂, CO ve karbonatlar "
                        "karbon içerse de inorganiktir.",
                    ("Molekül formülü aynı olan maddelerin yapı formülü de aynıdır; "
                     "aynı atomlar ancak tek bir şekilde bağlanabilir"):
                        "Molekül formülünü yapı formülüyle eşitledin. C₂H₆O hem "
                        "etanolün hem dimetil eterin formülüdür.",
                    "Yapı formülü yalnız atom sayılarını, molekül formülü bağları gösterir":
                        "Tersi: yapı formülü bağları, molekül formülü atom "
                        "sayılarını gösterir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Organik kimya karbonun hidrojenle kurduğu bileşiklerle ilgilenir; "
                    "karbon oksitleri ve karbonatlar inorganik kimyada incelenir. "
                    "Molekül formülü bir sayım, yapı formülü bir haritadır: aynı "
                    "sayımdan farklı haritalar çıkabilir."
                ),
                ipuclari=[
                    "Sınıflandırma notunda hangi karbon bileşikleri inorganik?",
                    "Yapı kartlarında aynı atom sayılarına sahip olanlar var mı?",
                ],
                cozum="Karbon içermek organik olmak için yetmez.\nMolekül formülü ≠ yapı formülü.",
            ),
            coklu_adimi(
                soru="Raf listesinde hangi maddeler organiktir? (numaraları virgülle yaz)",
                secenekler=raf_secenekleri,
                dogru_indeksler=organikler,
                aciklama=("Karbonu hidrojenle bağlı olanlar organik. CO, CO₂, "
                          "karbonatlar ve hidrojen karbonatlar inorganik rafa."),
                ipuclari=["Sınıflandırma notundaki istisnaları ayır."],
                puan=12,
            ),
            sayi_adimi(
                soru="Yapı kartlarından kaç tanesi {} molekül formülüne uyar?".format(formul),
                cevap=len(uyanlar),
                aciklama="C, H ve O atomlarını say: {} kart {} formülüne uyuyor; yapıları "
                         "farklı.".format(len(uyanlar), formul),
                yaygin_yanlislar={
                    1:
                        "Molekül formülünü yapı formülüyle eşitledin: aynı formüle "
                        "uyan farklı yapıları tek kart saydın.",
                },
                ipuclari=["Her kartta C, H ve O atomlarını ayrı ayrı say."],
                puan=12,
            ),
            secim_adimi(
                soru="{} ile {} için hangisi doğrudur?".format(
                    _buyuk_harfle(iki[0][0]), iki[1][0]),
                dogru=("Molekül formülleri aynı ({}), yapı formülleri farklı: farklı "
                       "maddelerdir").format(formul),
                yanlislar={
                    ("Molekül formülleri aynı olduğu için aynı maddedir; yalnız "
                     "adları farklı konmuştur"):
                        "Molekül formülünü yapı formülüyle eşitledin. Kaynama kaydı "
                        "iki farklı madde gösteriyor.",
                    "Molekül formülleri farklı olduğu için farklı maddelerdir":
                        "Atomları say: ikisinin de molekül formülü {}.".format(formul),
                },
                rastgele=rastgele,
                aciklama="{}: {} °C; {}: {} °C. Aynı formül, farklı yapı.".format(
                    _buyuk_harfle(iki[0][0]), _eksi_derece(iki[0][2]),
                    _buyuk_harfle(iki[1][0]), _eksi_derece(iki[1][2])),
                ipuclari=["Kaynama kaydını oku."],
                puan=10,
            ),
        ],
        kapanis=("Raflar düzeltildi: karbonlu inorganikler ayrı rafta. {} formülüne "
                 "uyan {} yapı ayrı madde olarak arşivlendi.").format(formul, len(uyanlar)),
        odul={"itibar": 5, "cevher": 2, "erzak": 1},
    )


# ==========================================================================
# FONKSİYONEL GRUPLAR: AYNI ATOMLAR, FARKLI ÖZELLİK (B37.13)
#
# `fonksiyonel_grup` iki satırda boştu (2018: 12; 2026: 12). Bağlam:
# "Malzeme kartlarını fonksiyonel grubuna göre düzenleme". `yaygin_yanlis`:
#
#   "Aynı atom türlerinden oluşan bütün maddelerin aynı özelliği taşıdığını
#    sanmak."
#
# DÜZENEK: beş malzeme kartı; hepsi yalnız C, H ve O içeriyor. Karboksil,
# hidroksil, eter, keton, aldehit, ester grupları farklı davranış verir:
# kabartma tozuyla yalnız karboksilik asitler gaz (CO₂) çıkarır.
#
# YANILGILARIN SAYISAL KARŞILIĞI: farklı grup sayısını 1 yazmak ("hepsi C, H,
# O"); asidi ve alkolü aynı davranıyor saymak.
# ==========================================================================

# (yapı, ad, fonksiyonel grup)
_ASIT_KARTLARI = (("CH₃–COOH", "asetik asit", "karboksil"),
                  ("H–COOH", "formik asit", "karboksil"),
                  ("CH₃–CH₂–COOH", "propanoik asit", "karboksil"))
_DIGER_KARTLAR = (("CH₃–CH₂–OH", "etanol", "hidroksil"),
                  ("CH₃–OH", "metanol", "hidroksil"),
                  ("CH₃–O–CH₃", "dimetil eter", "eter"),
                  ("CH₃–CO–CH₃", "aseton", "keton"),
                  ("CH₃–CHO", "asetaldehit", "aldehit"),
                  ("CH₃–COO–CH₃", "metil asetat", "ester"))


@bulmaca(ders="kimya", konu="fonksiyonel_grup", kademeler=(12, 13), agirlik=1.3)
def kimya_dolabi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı atomlardan oluşan maddeler fonksiyonel gruplarına göre farklı davranır."""
    asit_sayi = rastgele.choice((1, 2))
    asitler = rastgele.sample(_ASIT_KARTLARI, asit_sayi)
    digerleri = rastgele.sample(_DIGER_KARTLAR, 5 - asit_sayi)
    kartlar = asitler + digerleri
    rastgele.shuffle(kartlar)
    secenekler = ["{} ({})".format(yapi, ad) for yapi, ad, _ in kartlar]
    asit_indeksleri = [n for n, k in enumerate(kartlar) if k[2] == "karboksil"]
    grup_sayisi = len({g for _, _, g in kartlar})
    asit = asitler[0]
    karsit = digerleri[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-kimya-dolabi",
        ders="kimya",
        baslik="Kimya Dolabı",
        kademe=kademe,
        konu="fonksiyonel_grup",
        kazanim="Aynı atom türlerinden oluşan organik bileşiklerde fonksiyonel grubu "
                "belirleme; karboksilik asitlerin karakteristik tepkimesini diğer "
                "gruplardan ayırma.",
        dikkat=8,
        brifing=(
            "Kimya dolabındaki şişeler yeniden dizilecek; kabartma tozuyla köpüren "
            "sıvılar ayrı rafa konmalı.\n\n"
            "{} şunu önerdi: \"Bu şişelerin hepsi yalnız karbon, hidrojen ve "
            "oksijenden oluşuyor; aynı atomlar aynı davranış demek. Hepsini aynı "
            "rafa koyalım, ayırmaya gerek yok.\"\n\n"
            "Dolap düzenlenmeden önce kartları gruplarına göre ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Şişe kartları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Grup tablosu",
                  "–COOH karboksil (asit); –OH hidroksil (alkol); –O– eter; –CO– "
                  "keton; –CHO aldehit; –COO– ester. Kabartma tozuyla (NaHCO₃) "
                  "yalnız karboksilik asitler CO₂ gazı çıkarır.",
                  bedel=1, kritik=True),
            Kanit("Deneme notu",
                  "{} şişesine kabartma tozu atıldı: köpürdü. {} şişesine atıldı: "
                  "değişiklik yok.".format(_buyuk_harfle(asit[1]), _buyuk_harfle(karsit[1])),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yalnız C, H ve O içeren organik maddeler için hangisi doğrudur?",
                dogru=("Atomlar aynı olsa da fonksiyonel grup farklı olabilir; "
                       "karakteristik özelliği o grup belirler"),
                yanlislar={
                    ("Aynı atom türlerinden oluşan maddelerin hepsi aynı özelliği "
                     "taşır; bir maddenin özelliğini içindeki atomlar belirler"):
                        "Aynı atom türlerinden oluşan bütün maddelerin aynı özelliği "
                        "taşıdığını sandın. Deneme notunda biri köpürdü, öteki köpürmedi.",
                    "Özellikleri yalnız karbon sayısına bağlıdır":
                        "Aynı karbon sayısındaki etanol ve asetik asit bile çok farklı "
                        "davranır; belirleyici fonksiyonel gruptur.",
                    ("Oksijen içeren her organik madde asittir; asitlerin hepsinde "
                     "oksijen bulunur"):
                        "Asit özelliği –COOH grubundan gelir; alkol, eter ve keton "
                        "oksijen içerse de asit değildir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Fonksiyonel grup, molekülün tepkimeye giren kısmıdır. Aynı "
                    "atomlar farklı biçimde bağlanınca karboksil, hidroksil, eter "
                    "gibi farklı gruplar oluşur ve her grup kendi davranışını getirir."
                ),
                ipuclari=[
                    "Deneme notunda iki şişe aynı davrandı mı?",
                    "Grup tablosunda kabartma tozuyla kim tepki veriyor?",
                ],
                cozum="Aynı atomlar ≠ aynı grup ≠ aynı özellik.",
            ),
            sayi_adimi(
                soru="Şişe kartlarında kaç farklı fonksiyonel grup var?",
                cevap=grup_sayisi,
                aciklama="Gruplar: {}.".format(", ".join(sorted({g for _, _, g in kartlar}))),
                yaygin_yanlislar={
                    1:
                        "Aynı atom türlerinden oluşan bütün maddelerin aynı özelliği "
                        "taşıdığını sandın; hepsi C, H ve O içeriyor ama grupları farklı.",
                },
                ipuclari=["Her kartın yapısını grup tablosuyla eşle; aynı grubu bir kez say."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi şişeler kabartma tozuyla köpürür? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=asit_indeksleri,
                aciklama="Yalnız –COOH taşıyan kartlar: karboksilik asitler CO₂ çıkarır.",
                ipuclari=["–COOH grubunu ara; –COO– (ester) ile karıştırma."],
                puan=12,
            ),
            secim_adimi(
                soru="{} ile {} için hangisi doğrudur?".format(
                    _buyuk_harfle(asit[1]), karsit[1]),
                dogru="{} asittir (–COOH); {} {} grubu taşır ve asit gibi davranmaz".format(
                    _buyuk_harfle(asit[1]), karsit[1], karsit[2]),
                yanlislar={
                    ("İkisi de C, H ve O içerdiği için aynı davranır; atomları aynı "
                     "olan maddeler aynı tepkimeleri verir"):
                        "Aynı atom türlerinden oluşan bütün maddelerin aynı özelliği "
                        "taşıdığını sandın; deneme notu farklı davrandıklarını gösteriyor.",
                    "İkisi de oksijen içerdiği için asittir":
                        "Oksijen tek başına asitlik vermez; asitliği –COOH grubu verir.",
                },
                rastgele=rastgele,
                aciklama="{} {} grubu taşıyor, köpürdü; {} {} grubu taşıyor, köpürmedi.".format(
                    _buyuk_harfle(asit[1]), "karboksil", karsit[1], karsit[2]),
                ipuclari=["İki kartın yapısındaki grubu bul."],
                puan=10,
            ),
        ],
        kapanis=("Dolap düzeltildi: {} farklı fonksiyonel grup ayrı raflarda; "
                 "karboksilik asitler kabartma tozundan uzak tutuluyor."
                 ).format(grup_sayisi),
        odul={"itibar": 5, "cevher": 1, "erzak": 2},
    )


# ==========================================================================
# KİMYA BİLİMİ: SİMYA DEĞİL BİLİMSEL YÖNTEM; TEHLİKE İŞARETLERİ (B37.13)
#
# `kimya_bilimi` iki satırda boştu (2018: 9; 2026: 9). Bağlam: "Üs
# laboratuvarının malzeme etiketlerini ve çalışma kayıtlarını inceleme".
# `yaygin_yanlis`:
#
#   "Simya ile bilimsel yöntemi aynı saymak; tehlike işaretlerini karıştırmak."
#
# DÜZENEK: laboratuvar çalışma kayıtları (bir kısmı simya tarzı: gizli
# tarif, ay evresi, sınanamayan iddia) ve şişe etiketleri. Karıştırılan
# işaret çiftleri: alev (yanıcı) / alev üstünde daire (oksitleyici), korozif
# (sıvı damlası yüzeyi ve eli yakıyor) / kurukafa (akut zehirli).
# ==========================================================================

_BILIMSEL_KAYITLAR = (
    "Hipotez: sıcaklık arttıkça tuz daha hızlı çözünür. Yalnız sıcaklık değiştirildi, su miktarı sabit tutuldu.",
    "Deney üç kez tekrarlandı; üç sonucun hepsi deftere yazıldı.",
    "Yöntem ve sonuçlar öteki ekiple paylaşıldı; onlar da deneyi yineleyip aynı sonucu buldu.",
    "Beklenmeyen sonuç silinmedi; olası ölçüm hatası nedenleriyle birlikte not edildi.",
)
_SIMYA_KAYITLARI = (
    "Kurşunu altına çeviren karışımın tarifi gizli tutulacak; kimseyle paylaşılmayacak.",
    "Karışım işe yaramadıysa ay evresi uygun değildir; dolunayı beklemek gerek.",
    "Ölçü kullanılmadı; malzemeler gözle, sezgiyle karıştırıldı. Sonuç kaydedilmedi.",
)
# işaret -> (anlamı, karıştırılan işaret)
_ISARETLER = {
    "alev": "Yanıcı; kolayca tutuşur",
    "alev üstünde daire": "Oksitleyici; yanmayı başlatır ya da büyütür",
    "korozif (damla yüzeyi ve eli yakıyor)": "Yakıcı; deriyi ve metali tahrip eder",
    "kurukafa ve çapraz kemikler": "Akut zehirli; az miktarı bile öldürücü olabilir",
}
_KARISAN_CIFT = {
    "alev": "alev üstünde daire", "alev üstünde daire": "alev",
    "korozif (damla yüzeyi ve eli yakıyor)": "kurukafa ve çapraz kemikler",
    "kurukafa ve çapraz kemikler": "korozif (damla yüzeyi ve eli yakıyor)",
}
# (madde, doğru işaret)
_ETIKET_MADDELERI = (("etanol", "alev"), ("potasyum nitrat", "alev üstünde daire"),
                     ("derişik hidroklorik asit", "korozif (damla yüzeyi ve eli yakıyor)"),
                     ("metanol", "alev"))


@bulmaca(ders="kimya", konu="kimya_bilimi", kademeler=(9, 13), agirlik=1.2)
def laboratuvar_kayitlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bilimsel yöntem sınanabilir, tekrarlanabilir ve paylaşılır; tehlike işaretleri ayrı anlam taşır."""
    bilimsel = rastgele.sample(_BILIMSEL_KAYITLAR, rastgele.choice((2, 3)))
    simya = rastgele.sample(_SIMYA_KAYITLARI, 5 - len(bilimsel))
    kayitlar = [(k, True) for k in bilimsel] + [(k, False) for k in simya]
    rastgele.shuffle(kayitlar)
    secenekler = [k for k, _ in kayitlar]
    bilimsel_indeksler = [n for n, (_, b) in enumerate(kayitlar) if b]
    isaret = rastgele.choice(sorted(_ISARETLER))
    karisan = _KARISAN_CIFT[isaret]
    madde, madde_isareti = rastgele.choice(_ETIKET_MADDELERI)
    madde_karisan = _KARISAN_CIFT[madde_isareti]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-laboratuvar-kayitlari",
        ders="kimya",
        baslik="Laboratuvar Kayıtları",
        kademe=kademe,
        konu="kimya_bilimi",
        kazanim="Simya uygulamalarını bilimsel yöntemden ayırma (sınanabilirlik, "
                "tekrarlanabilirlik, paylaşım); laboratuvar tehlike işaretlerinin "
                "anlamını ayırt etme.",
        dikkat=6,
        brifing=(
            "Üs laboratuvarının çalışma defteri ve şişe etiketleri denetlenecek.\n\n"
            "{} deftere şunu eklemiş: \"Eski simya notları da bilimsel deneydir; "
            "sonuç çıkmıyorsa ay evresi uygun değildir. Etiketlerdeki alev ile alev "
            "üstünde daire de aynı şeyi söyler, korozif ile kurukafa da.\"\n\n"
            "Defter onaylanmadan önce kayıtları ve etiketleri doğru ayırmamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Çalışma defteri", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("İşaret tablosu",
                  "\n".join("{}: {}".format(_buyuk_harfle(i), a) for i, a in sorted(_ISARETLER.items())),
                  bedel=1, kritik=True),
            Kanit("Bilimsel yöntem notu",
                  "Bilimsel çalışma sınanabilir bir hipotez kurar, değişkenleri "
                  "denetler, sonuçları eksiksiz kaydeder ve başkalarının "
                  "yineleyebileceği biçimde paylaşır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Simya ile bilimsel kimya arasındaki fark için hangisi doğrudur?",
                dogru=("Bilimsel kimya hipotezini denetimli, yinelenebilir deneyle sınar "
                       "ve kaydeder; simya tariflerini gizlerdi"),
                yanlislar={
                    ("İkisi de karışım hazırladığı için aynı yöntemi kullanır; "
                     "ısıtmak, karıştırmak ve damıtmak ikisinde de vardı"):
                        "Simya ile bilimsel yöntemi aynı saydın. Fark karışımda değil "
                        "yöntemde: sınama, kayıt ve paylaşım.",
                    "Simya da bilimseldir; yalnız amacı altın elde etmekti":
                        "Amaç değil yöntem belirleyici; gizli tarifler ve sınanamayan "
                        "açıklamalar bilimsel değildir.",
                    ("Bilimsel yöntemde başarısız deneyler kayda geçirilmez; yalnız "
                     "işe yarayan sonuç paylaşılır, gerisi zaman kaybıdır"):
                        "Beklenmeyen ya da başarısız sonuçlar da kaydedilir; bilgi "
                        "onlardan da çıkar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Simyacılar pek çok laboratuvar tekniği geliştirdi ama "
                    "açıklamalarını sınamadı, tariflerini gizledi. Bilimsel kimya "
                    "hipotezini denetimli deneyle sınar, sonucunu paylaşır ve "
                    "başkalarının yinelemesine açar."
                ),
                ipuclari=[
                    "Bilimsel yöntem notunda hangi dört öğe var?",
                    "Gizli tutulan bir tarifi başkası yineleyebilir mi?",
                ],
                cozum="Bilim: hipotez + denetim + kayıt + paylaşım/yineleme.",
            ),
            coklu_adimi(
                soru="Defterdeki hangi kayıtlar bilimsel yönteme uygundur? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=bilimsel_indeksler,
                aciklama=("Hipotez ve denetimli değişken, tekrar, paylaşım ve "
                          "beklenmeyen sonucu kaydetme bilimseldir. Gizli tarif, ay "
                          "evresi açıklaması ve ölçüsüz, kayıtsız çalışma değildir."),
                ipuclari=["Her kaydın sınanabilir ve yinelenebilir olup olmadığına bak."],
                puan=12,
            ),
            secim_adimi(
                soru="Etikette \"{}\" işareti ne anlatır?".format(isaret),
                dogru=_ISARETLER[isaret],
                yanlislar={
                    _ISARETLER[karisan]:
                        "Tehlike işaretlerini karıştırdın: bu, \"{}\" işaretinin "
                        "anlamı.".format(karisan),
                    "Genel uyarı: özel bir tehlike yok, yalnız dikkatli kullanılmalı":
                        "Her işaretin kendine özgü bir tehlike anlamı var; işaret "
                        "tablosuna bak.",
                },
                rastgele=rastgele,
                aciklama="{}: {}.".format(_buyuk_harfle(isaret), _ISARETLER[isaret]),
                ipuclari=["İşaret tablosunu oku."],
                puan=10,
            ),
            secim_adimi(
                soru="{} şişesinin etiketinde hangi işaret olmalı?".format(_buyuk_harfle(madde)),
                dogru=_buyuk_harfle(madde_isareti),
                yanlislar={
                    _buyuk_harfle(madde_karisan):
                        "Tehlike işaretlerini karıştırdın: \"{}\" başka bir tehlikeyi "
                        "anlatır.".format(madde_karisan),
                    "Hiçbir işaret gerekmez; laboratuvar personeli maddeyi zaten tanır":
                        "Laboratuvardaki tehlikeli maddelerin hepsi işaretlenir.",
                },
                rastgele=rastgele,
                aciklama="{} için doğru işaret: {}. {}.".format(
                    _buyuk_harfle(madde), madde_isareti, _ISARETLER[madde_isareti]),
                ipuclari=["Maddenin başlıca tehlikesini düşün: tutuşma mı, yakma mı, yanmayı besleme mi?"],
                puan=10,
            ),
        ],
        kapanis=("Defter düzeltildi: {} kayıt bilimsel yönteme uygun, simya notları "
                 "ayrıldı. Etiketler işaret tablosuna göre yenilendi."
                 ).format(len(bilimsel_indeksler)),
        odul={"itibar": 4, "cevher": 1, "erzak": 1},
    )


# ==========================================================================
# GAZLARIN KİNETİK MODELİ: AYNI SICAKLIK AYNI HIZ DEĞİLDİR (B37.13)
#
# `gaz_kinetik` (2018: 11) ve `gaz_yayilmasi` (2026: 10) tek satırlıktı; ikisinin
# `yaygin_yanlis` ve bağlamı aynı ("Gazların yayılma verilerini tanecik
# modeliyle karşılaştırma"):
#
#   "Aynı sıcaklıkta bütün taneciklerin aynı hızda olduğunu sanmak."
#
# DÜZENEK: sızıntı bandı deneyi. Uzun tüpün iki ucundan aynı anda iki gaz
# bırakılıyor. Aynı sıcaklıkta ORTALAMA kinetik enerji aynı: hafif gaz daha
# hızlı, v1/v2 = √(M2/M1) (Graham). Buluşma noktası hafif gazın ucuna uzak.
# Ayrıca aynı gazın tanecikleri de tek hızda değil, bir hız dağılımında.
#
# YANILGILARIN SAYISAL KARŞILIĞI: hız oranını 1 almak (tüpün ortasında
# buluşma); karekökü unutmak (mol kütlesi oranı).
# ==========================================================================

# (hafif gaz, M, ağır gaz, M): karekök oranı tam sayı
_GRAHAM_CIFTLERI = (("H₂", 2, "O₂", 32), ("He", 4, "CH₄", 16),
                    ("CH₄", 16, "SO₂", 64), ("He", 4, "SO₂", 64))
_TUP_BOYLARI = (90, 100, 120, 150)   # cm


@bulmaca(ders="kimya", konu="gaz_kinetik", kademeler=(10, 13), agirlik=1.3)
def sizinti_tupu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı sıcaklıkta gazların ortalama kinetik enerjisi aynıdır, hızları değil."""
    hafif, m_hafif, agir, m_agir = rastgele.choice(_GRAHAM_CIFTLERI)
    oran = int(round((m_agir / m_hafif) ** 0.5))
    uzunluk = rastgele.choice([u for u in _TUP_BOYLARI if (u * oran) % (oran + 1) == 0]
                              or _TUP_BOYLARI)
    bulusma = uzunluk * oran / (oran + 1)
    kutle_orani = m_agir // m_hafif
    kokusuz = round(uzunluk * kutle_orani / (kutle_orani + 1), 1)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-sizinti-tupu",
        ders="kimya",
        baslik="Sızıntı Tüpü",
        kademe=kademe,
        konu="gaz_kinetik",
        kazanim="Aynı sıcaklıktaki gazların ortalama kinetik enerjisinin eşit, ortalama "
                "hızlarının mol kütlesine bağlı olduğunu açıklama; Graham bağıntısıyla "
                "hız oranını ve buluşma noktasını hesaplama; tanecik hızlarının "
                "dağılımını yorumlama.",
        dikkat=8,
        brifing=(
            "Üssün gaz sızıntısı bandı ayarlanacak. Deneme için {} cm uzunluğundaki "
            "tüpün bir ucundan {}, öteki ucundan {} aynı anda bırakılacak; iki gazın "
            "karşılaştığı yere algılayıcı konacak.\n\n"
            "{} algılayıcıyı tüpün tam ortasına koymak istiyor: \"Tüpün her yeri aynı "
            "sıcaklıkta; o zaman iki gazın bütün tanecikleri aynı hızda gider ve "
            "ortada buluşur.\"\n\n"
            "Algılayıcı sabitlenmeden önce buluşma noktasını doğru hesaplamamız gerekiyor."
        ).format(uzunluk, hafif, agir, kisi),
        kanitlar=[
            Kanit("Gaz kartları",
                  "{}: {} g/mol. {}: {} g/mol. Tüp ve iki gaz aynı sıcaklıkta."
                  .format(hafif, m_hafif, agir, m_agir),
                  bedel=1, kritik=True),
            Kanit("Kinetik model notu",
                  "Aynı sıcaklıkta gaz taneciklerinin ORTALAMA kinetik enerjisi aynıdır: "
                  "½·m·v². Bu yüzden v1 ÷ v2 = √(M2 ÷ M1).",
                  bedel=1, kritik=True),
            Kanit("Hız ölçümü",
                  "Aynı kaptaki {} taneciklerinin hızları ölçüldü: bir kısmı yavaş, "
                  "çoğu ortalama civarında, bir kısmı çok hızlı.".format(agir),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Aynı sıcaklıktaki gaz tanecikleri için hangisi doğrudur?",
                dogru=("Ortalama kinetik enerji aynıdır; hafif gaz ortalamada daha "
                       "hızlıdır, aynı gazda da hızlar farklıdır"),
                yanlislar={
                    ("Aynı sıcaklıkta bütün tanecikler aynı hızda hareket eder; "
                     "sıcaklık, taneciklerin hızını gösteren ölçüdür"):
                        "Aynı sıcaklıkta bütün taneciklerin aynı hızda olduğunu "
                        "sandın. Eşit olan ortalama kinetik enerji; kütle farklıysa "
                        "hız da farklıdır.",
                    "Ağır gazın tanecikleri daha hızlıdır; çünkü daha çok enerji taşır":
                        "Aynı sıcaklıkta enerji ortalamada eşit; kütlesi büyük olanın "
                        "hızı küçük olmalı.",
                    ("Aynı gazın bütün tanecikleri aynı hızdadır, farklı gazlarınki "
                     "değil; hızı gazın türü belirler"):
                        "Hız ölçümü aynı gazda bile yavaş ve hızlı taneciklerin "
                        "bulunduğunu gösteriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sıcaklık, taneciklerin ortalama kinetik enerjisinin ölçüsüdür. "
                    "½·m·v² aynıysa, m küçük olanın v değeri büyük olur. Tek tek "
                    "tanecikler çarpışarak sürekli hız değiştirir; bu yüzden bir hız "
                    "dağılımı vardır."
                ),
                ipuclari=[
                    "Kinetik model notunda eşit olan büyüklük hangisi?",
                    "Hız ölçümünde bütün tanecikler aynı hızda mı?",
                ],
                cozum="Aynı T: ortalama ½mv² aynı\nv1 ÷ v2 = √(M2 ÷ M1)",
            ),
            sayi_adimi(
                soru="{} taneciklerinin ortalama hızı {} taneciklerininkinin kaç katı?".format(hafif, agir),
                cevap=oran,
                aciklama="v({}) ÷ v({}) = √({} ÷ {}) = √{} = {}.".format(
                    hafif, agir, m_agir, m_hafif, kutle_orani, oran),
                yaygin_yanlislar={
                    1:
                        "Aynı sıcaklıkta bütün taneciklerin aynı hızda olduğunu sandın; "
                        "eşit olan hız değil ortalama kinetik enerji.",
                    kutle_orani:
                        "Karekökü unuttun: hız oranı mol kütlesi oranının kareköküdür.",
                },
                ipuclari=["Ağır gazın mol kütlesini hafif gazınkine böl, karekökünü al."],
                puan=12,
            ),
            sayi_adimi(
                soru="İki gaz, {} bırakılan uçtan kaç cm uzakta buluşur?".format(hafif),
                cevap=bulusma,
                birim="cm",
                aciklama=("Aynı sürede {} gazı {} kat yol alır: tüp {} + 1 = {} parçaya "
                          "bölünür. {} × {} ÷ {} = {} cm.").format(
                    hafif, oran, oran, oran + 1, uzunluk, oran, oran + 1, sy(bulusma)),
                yaygin_yanlislar={
                    sy(uzunluk / 2).replace(",", "."):
                        "Aynı sıcaklıkta bütün taneciklerin aynı hızda olduğunu sandın; "
                        "bu yüzden tüpün ortasını buldun.",
                    sy(kokusuz).replace(",", "."):
                        "Hız oranı yerine mol kütlesi oranını kullandın; karekök gerekir.",
                    sy(uzunluk - bulusma).replace(",", "."):
                        "Buluşma noktasını ağır gazın ucundan ölçtün.",
                },
                ipuclari=["Hafif gaz aynı sürede ağır gazdan kaç kat yol alıyor?"],
                puan=14,
                tolerans=0.5,
            ),
            secim_adimi(
                soru="Hız ölçümüne göre aynı kaptaki {} tanecikleri için hangisi doğru?".format(agir),
                dogru="Hızları farklıdır; sıcaklık yalnız ortalama kinetik enerjiyi belirler",
                yanlislar={
                    ("Hepsi aynı hızdadır; ölçümdeki farklar hatadır, aynı "
                     "sıcaklıktaki aynı gaz tek hızla gider"):
                        "Aynı sıcaklıkta bütün taneciklerin aynı hızda olduğunu sandın; "
                        "çarpışmalar hızları sürekli değiştirir.",
                    "Hızlı olanlar daha sıcak, yavaş olanlar daha soğuktur":
                        "Sıcaklık tek bir taneciğin değil, bütün gazın ortalama "
                        "özelliğidir.",
                },
                rastgele=rastgele,
                aciklama="Gaz taneciklerinin hızları bir dağılım gösterir; sıcaklık bu dağılımın ortalamasını belirler.",
                ipuclari=["Hız ölçümü kartını oku."],
                puan=10,
            ),
        ],
        kapanis=("Algılayıcı düzeltildi: {} ucundan {} cm uzağa kondu, tüpün ortasına "
                 "değil. {} tanecikleri ortalamada {} kat hızlı."
                 ).format(hafif, sy(bulusma), hafif, oran),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# YÜKSELTGENME: ELEKTRON VERMEK (B37.13)
#
# `yukseltgenme` tek satırlıktı (2018: 11). Bağlam: "Metal dönüşümlerinde
# elektron hesabını denetleme". `yaygin_yanlis`:
#
#   "Yükseltgenmede elektron alındığını sanmak."
#
# DÜZENEK: atölyede metal geri kazanım banyosu: metal parça, başka bir metalin
# iyonunu içeren çözeltiye daldırılıyor (Üs Pili görevinin yarı hücre verisi
# yeniden kullanılır). Metal atomu elektron VERİR: yükseltgenir, basamağı
# artar. Çözeltideki iyon elektron alır: indirgenir; bu iyon yükseltgen
# (oksitleyici) maddedir.
#
# YANILGILARIN SAYISAL KARŞILIĞI: basamak değişimini eksi yazmak; dengeli
# denklemde aktarılan elektronu tek atomunki saymak.
# ==========================================================================


@bulmaca(ders="kimya", konu="yukseltgenme", kademeler=(11, 13), agirlik=1.3)
def geri_kazanim_banyosu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yükseltgenme elektron vermektir; yükseltgenme basamağı artar."""
    metal, iyon_metal = rastgele.choice(_PIL_CIFTLERI)
    m_iyon, m_n, _ = _YARI_HUCRELER[metal]
    k_iyon, k_n, _ = _YARI_HUCRELER[iyon_metal]
    denklem = _pil_denklemi(metal, iyon_metal)
    a_kat, k_kat = _pil_katsayilari(metal, iyon_metal)
    toplam_e = a_kat * m_n
    adlar = {"Mg": "magnezyum", "Al": "alüminyum", "Zn": "çinko", "Cu": "bakır", "Ag": "gümüş"}
    metal_ad, iyon_ad = adlar[metal], adlar[iyon_metal]
    toplam_yanlislari = {}
    if m_n != toplam_e:
        toplam_yanlislari[m_n] = ("Tek atomun verdiği elektronu yazdın; denklemdeki "
                                  "katsayıyı da hesaba kat.")
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-geri-kazanim-banyosu",
        ders="kimya",
        baslik="Geri Kazanım Banyosu",
        kademe=kademe,
        konu="yukseltgenme",
        kazanim="Yükseltgenmeyi elektron verme, indirgenmeyi elektron alma olarak "
                "açıklama; yükseltgenme basamağı değişimini ve aktarılan elektron "
                "sayısını bulma; yükseltgen ve indirgen maddeyi belirleme.",
        dikkat=8,
        brifing=(
            "Atölyede eski parçalardan metal geri kazanılıyor: {} bir parça, {} iyonu "
            "içeren banyoya daldırıldı ve üstünde {} birikti.\n\n"
            "{} kayda şunu yazdı: \"{} atomları ({}) elektron aldı, yani yükseltgendi; "
            "yükseltgenme basamağı düştü. Banyodaki {} iyonları da elektron verip "
            "{} metaline dönüştü.\"\n\n"
            "Kayıt onaylanmadan önce elektron hesabını doğru denetlememiz gerekiyor."
        ).format(metal_ad, k_iyon, iyon_ad, kisi, metal_ad[:1].upper() + metal_ad[1:],
                 metal, k_iyon, iyon_ad),
        kanitlar=[
            Kanit("Banyo denklemi", denklem, bedel=1, kritik=True),
            Kanit("Yükseltgenme notu",
                  "Yükseltgenme: elektron verme, yükseltgenme basamağı artar. "
                  "İndirgenme: elektron alma, basamak azalır. Metal atomunun basamağı 0; "
                  "iyonun basamağı yüküne eşittir.",
                  bedel=1, kritik=True),
            Kanit("Terim kartı",
                  "Yükseltgen (oksitleyici) madde: karşısındakini yükseltgeyen, kendisi "
                  "indirgenen maddedir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yükseltgenme için hangisi doğrudur?",
                dogru="Yükseltgenen tanecik elektron verir ve yükseltgenme basamağı artar",
                yanlislar={
                    "Yükseltgenen tanecik elektron alır ve yükseltgenme basamağı düşer":
                        "Yükseltgenmede elektron alındığını sandın. Elektron veren "
                        "taneciğin pozitif yükü artar; basamağı yükselir.",
                    "Yükseltgenmede elektron alınır ama basamak yine artar":
                        "Elektron negatif yüklüdür; alınınca basamak artmaz, azalır.",
                    "Yükseltgenme yalnız oksijenle birleşmedir; elektronla ilgisi yoktur":
                        "Oksijenle birleşme yükseltgenmenin bir örneğidir; genel tanım "
                        "elektron vermedir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Elektron negatif yüklüdür. Bir tanecik elektron verirse pozitif "
                    "yükü, yani yükseltgenme basamağı artar: yükseltgenir. Elektronu "
                    "alan tanecik indirgenir. İkisi her zaman birlikte olur."
                ),
                ipuclari=[
                    "{} atomu {} iyonuna dönüşürken yükü nasıl değişiyor?".format(metal, m_iyon),
                    "Elektron alan taneciğin yükü artar mı, azalır mı?",
                ],
                cozum="Yükseltgenme: e⁻ verir, basamak ↑\nİndirgenme: e⁻ alır, basamak ↓",
            ),
            secim_adimi(
                soru="Banyoda hangi tanecik yükseltgeniyor?",
                dogru="{} atomu: elektron verip {} iyonuna dönüşüyor".format(metal, m_iyon),
                yanlislar={
                    "{} iyonu: elektron alıp {} metaline dönüşüyor".format(k_iyon, iyon_metal):
                        "Yükseltgenmede elektron alındığını sandın; elektron alan "
                        "{} iyonu indirgeniyor.".format(k_iyon),
                    "Hiçbiri: yalnız metaller yer değiştiriyor, elektron alışverişi olmuyor":
                        "Metallerin yer değiştirmesi elektron aktarımıyla olur.",
                },
                rastgele=rastgele,
                aciklama="{} → {}: yük 0'dan +{} değerine çıkıyor; elektron veren {}.".format(
                    metal, m_iyon, m_n, metal),
                ipuclari=["Denklemin iki yanında {} taneciğinin yükünü karşılaştır.".format(metal)],
                puan=10,
            ),
            sayi_adimi(
                soru="{} için yükseltgenme basamağındaki değişim kaçtır? (işaretiyle yaz)".format(metal),
                cevap=m_n,
                aciklama="0 → +{}: değişim +{}.".format(m_n, m_n),
                yaygin_yanlislar={
                    -m_n:
                        "Yükseltgenmede elektron alındığını sandın; basamağı düşürdün.",
                },
                ipuclari=["Son basamaktan ilk basamağı çıkar."],
                puan=10,
            ),
            sayi_adimi(
                soru="Denklem yazıldığı gibi gerçekleşince toplam kaç elektron aktarılır?",
                cevap=toplam_e,
                aciklama=("{} tane {} atomunun her biri {} elektron verir: {} × {} = {}. "
                          "Alınan elektron da aynı: {} × {} = {}.").format(
                    a_kat, metal, m_n, a_kat, m_n, toplam_e, k_kat, k_n, k_kat * k_n),
                yaygin_yanlislar=toplam_yanlislari,
                ipuclari=["Katsayı × atom başına verilen elektron."],
                puan=12,
            ),
            secim_adimi(
                soru="Bu tepkimede yükseltgen (oksitleyici) madde hangisidir?",
                dogru="{} iyonu: {} atomunu yükseltgiyor, kendisi indirgeniyor".format(k_iyon, metal),
                yanlislar={
                    ("{} atomu: kendisi yükseltgendiği için yükseltgendir; adı "
                     "yaşadığı olayı söyler").format(metal):
                        "Yükseltgen ile yükseltgeneni karıştırdın; yükseltgen madde "
                        "karşısındakini yükseltgeyen, kendisi indirgenendir.",
                    "{} metali: banyoda biriktiği için".format(iyon_metal):
                        "Biriken metal ürün; yükseltgen madde tepkimeye giren iyon.",
                },
                rastgele=rastgele,
                aciklama="Elektronları {} iyonu alıyor: indirgeniyor ve {} atomunu yükseltgiyor.".format(
                    k_iyon, metal),
                ipuclari=["Terim kartını oku: yükseltgen kendisi ne oluyor?"],
                puan=10,
            ),
        ],
        kapanis=("Kayıt düzeltildi: {} elektron vererek yükseltgendi (0 → +{}), {} "
                 "iyonu elektron alarak indirgendi. Denklemde {} elektron aktarılıyor."
                 ).format(metal, m_n, k_iyon, toplam_e),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# SÜRDÜRÜLEBİLİRLİK: YENİ TEKNOLOJİ DE YAŞAM DÖNGÜSÜYLE ÖLÇÜLÜR (B37.13)
#
# Beş tek satırlık kimya kodu aynı `yaygin_yanlis` ve aynı bağlamı paylaşıyor
# ("Üs tedarik seçeneklerini atık ve kaynak kullanımıyla karşılaştırma"):
# `kimyasal_surdurulebilirlik` (2018: 12), `metal_nano_ekosistem` (2026: 9),
# `hidrojen_nano_plastik` (2026: 11), `gunes_polimer_yapay_zeka` (2026: 12),
# `karbon_yakit` (2026: 12).
#
#   "Yeni veya küçük ölçekli teknolojiyi etkisiz/risksiz sanmak."
#
# DÜZENEK: tedarik masasında eski ve yeni seçenek; üretim, kullanım ve
# bertaraf aşamalarının model verisi. Yeni seçenek kullanımda sıfır salımlı
# görünür ama üretim ve bertaraf da sayılır: bazı senaryolarda yeni seçenek
# kazanır, bazısında (kompost tesisi olmayan biyoplastik) kaybeder. Her yeni
# seçeneğin ayrıca kendine özgü bir riski var (nanoparçacık, akü atığı...).
#
# YANILGININ SAYISAL KARŞILIĞI: yeni seçeneğin toplam etkisini yalnız kullanım
# aşamasıyla (çoğu kez 0) yazmak.
# ==========================================================================

# (konu, eski ad, yeni ad, birim, eski (üretim, kullanım, bertaraf), yeni (...), yeni riski)
_TEDARIK_SENARYOLARI = (
    ("ambalaj", "klasik plastik ambalaj", "biyoplastik ambalaj", "kg CO₂ eşdeğeri (1000 ambalaj)",
     (60, 0, 20), (40, 0, 55),
     "Üste endüstriyel kompost tesisi yok; çöpe giden biyoplastik bozunurken metan salıyor."),
    ("jeneratör", "dizel jeneratör", "hidrojen yakıt hücresi (doğal gazdan üretilmiş hidrojen)",
     "kg CO₂ eşdeğeri (1000 kWh)", (140, 700, 10), (700, 0, 20),
     "Hidrojen doğal gazdan üretiliyor; salım kullanımdan üretim aşamasına kaymış durumda."),
    ("su filtresi", "aktif karbon filtre", "nano gümüş kaplı filtre", "g katı atık (1 yıl)",
     (200, 0, 900), (350, 0, 300),
     "Nano gümüş parçacıkları atık suyla sera toprağına karışıyor; toprak bakterilerine zarar verebilir."),
    ("enerji", "dizel jeneratör", "güneş paneli ve akü", "kg CO₂ eşdeğeri (10 yıl)",
     (150, 4000, 10), (900, 0, 150),
     "Akülerin ömrü 5 yıl; ağır metal ve lityum atığı ayrı toplanmazsa toprağa karışır."),
)


@bulmaca(ders="kimya", konu="kimyasal_surdurulebilirlik", kademeler=(9, 13), agirlik=1.3)
def tedarik_masasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yeni ya da küçük ölçekli teknoloji de üretimden bertarafa bütün aşamalarıyla değerlendirilir."""
    konu, eski_ad, yeni_ad, birim, eski, yeni, risk = rastgele.choice(_TEDARIK_SENARYOLARI)
    eski_top, yeni_top = sum(eski), sum(yeni)
    yeni_kazanir = yeni_top < eski_top
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    def satir(ad, degerler):
        return "{}: üretim {}, kullanım {}, bertaraf {}".format(
            ad[:1].upper() + ad[1:], *degerler)

    if yeni_kazanir:
        dogru_karar = "Yeni seçenek alınmalı, ama riski için önlem planıyla"
        yanlis_karar = "Eski seçenek alınmalı: yeni teknoloji her zaman daha risklidir"
        yanlis_teshis = ("Toplamlara bakmadın; bu senaryoda yeni seçeneğin bütün aşamalardaki "
                         "etkisi daha küçük.")
    else:
        dogru_karar = "Eski seçenek alınmalı: yeni seçeneğin toplam etkisi bu üste daha büyük"
        yanlis_karar = ("Yeni seçenek alınmalı ve önlem gerekmez; yeni teknoloji "
                        "küçük ölçekli olduğu için risksizdir")
        yanlis_teshis = ("Yeni ya da küçük ölçekli teknolojiyi etkisiz/risksiz saydın; "
                         "toplamda daha büyük etki yapıyor.")

    return Bulmaca(
        kod="kim-tedarik-masasi",
        ders="kimya",
        baslik="Tedarik Masası",
        kademe=kademe,
        konu="kimyasal_surdurulebilirlik",
        kazanim="Tedarik seçeneklerini üretim, kullanım ve bertaraf aşamalarının "
                "toplam etkisiyle karşılaştırma; yeni ya da nano ölçekli teknolojilerin "
                "de çevresel etki ve risk taşıdığını açıklama.",
        dikkat=7,
        brifing=(
            "Üssün {} tedariki yenilenecek: {} ile {} arasında seçim yapılacak.\n\n"
            "{} önerisini yazdı: \"{} yeni bir teknoloji; kullanırken hiç salım ya da "
            "atık yok. Yeni olduğu için temiz ve risksiz, karşılaştırmaya gerek yok.\"\n\n"
            "Sipariş verilmeden önce iki seçeneği bütün aşamalarıyla karşılaştırmamız "
            "gerekiyor."
        ).format(konu, eski_ad, yeni_ad, kisi, yeni_ad[:1].upper() + yeni_ad[1:]),
        kanitlar=[
            Kanit("Yaşam döngüsü tablosu",
                  "Birim: {} (üs modeli verisi).\n{}\n{}".format(
                      birim, satir(eski_ad, eski), satir(yeni_ad, yeni)),
                  bedel=1, kritik=True),
            Kanit("Risk notu", risk, bedel=1, kritik=True),
            Kanit("Değerlendirme notu",
                  "Bir seçeneğin etkisi üretimden bertarafa kadar bütün aşamaların "
                  "toplamıdır. Küçük ölçek ya da yeni teknoloji, etkinin sıfır olduğu "
                  "anlamına gelmez.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yeni ya da küçük ölçekli bir teknoloji için hangisi doğrudur?",
                dogru=("Onun da üretimden bertarafa etkisi ve riskleri olabilir; "
                       "tüm aşamalar toplanıp eskiyle kıyaslanır"),
                yanlislar={
                    ("Yeni ya da küçük ölçekli teknoloji çevreye etki etmez, "
                     "risksizdir; küçük parçacık küçük etki yapar"):
                        "Yeni veya küçük ölçekli teknolojiyi etkisiz/risksiz saydın. "
                        "Yaşam döngüsü tablosunda onun da üretim ve bertaraf etkisi var.",
                    ("Yalnız kullanım aşaması önemlidir; üretim ve bertaraf bizim "
                     "elimizde olmadığı için hesaba hiç katılmaz"):
                        "Salım ve atık kullanımdan önce ya da sonra da oluşabilir.",
                    "Yeni teknoloji her zaman eski teknolojiden daha zararlıdır":
                        "Bu da kanıtsız bir genelleme; karar toplamlara göre verilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sürdürülebilirlik değerlendirmesi bir ürünün bütün yaşamına bakar: "
                    "hammadde ve üretim, kullanım, atık. Nano ölçekli maddeler de dahil "
                    "olmak üzere yeni teknolojilerin kendine özgü riskleri ayrıca "
                    "değerlendirilir."
                ),
                ipuclari=[
                    "Tabloda yeni seçeneğin hangi aşamalarında sıfırdan büyük değer var?",
                    "Risk notu ne söylüyor?",
                ],
                cozum="Toplam etki = üretim + kullanım + bertaraf\nYeni ≠ risksiz",
            ),
            sayi_adimi(
                soru="{} için toplam etki kaç birim?".format(yeni_ad[:1].upper() + yeni_ad[1:]),
                cevap=yeni_top,
                aciklama="{} + {} + {} = {}.".format(yeni[0], yeni[1], yeni[2], yeni_top),
                yaygin_yanlislar={
                    yeni[1]:
                        "Yeni veya küçük ölçekli teknolojiyi etkisiz/risksiz saydın: "
                        "yalnız kullanım aşamasını yazdın.",
                },
                ipuclari=["Üç aşamanın değerini topla."],
                puan=12,
            ),
            sayi_adimi(
                soru="{} için toplam etki kaç birim?".format(eski_ad[:1].upper() + eski_ad[1:]),
                cevap=eski_top,
                aciklama="{} + {} + {} = {}.".format(eski[0], eski[1], eski[2], eski_top),
                yaygin_yanlislar=({eski[1]: "Yalnız kullanım aşamasını yazdın; üç aşamayı topla."}
                                  if eski[1] != eski_top else {}),
                ipuclari=["Aynı üç aşamayı eski seçenek için de topla."],
                puan=8,
            ),
            yorum_adimi(
                soru="Tedarik kararı için hangisi doğru?",
                dogru=dogru_karar,
                yanlislar={
                    yanlis_karar: yanlis_teshis,
                    "Fark etmez: ikisi de aynı işi görüyor":
                        "Aynı işi gören iki seçeneğin toplam etkileri farklı; karar toplamlara göre verilir.",
                },
                rastgele=rastgele,
                aciklama="Toplamlar: {} {}, {} {}. {}".format(
                    eski_ad, eski_top, yeni_ad, yeni_top,
                    "Yeni seçenek daha az etkili ama riski yönetilmeli." if yeni_kazanir
                    else "Bu üste yeni seçenek daha büyük etki yapıyor."),
                ipuclari=["İki toplamı karşılaştır, risk notunu da unutma."],
                puan=10,
            ),
            secim_adimi(
                soru="Yeni seçeneğin raporuna hangi risk notu eklenmeli?",
                dogru=risk.split(";")[0],
                yanlislar={
                    "Risk yok: yeni teknoloji olduğu için ayrıca not gerekmez":
                        "Yeni veya küçük ölçekli teknolojiyi etkisiz/risksiz saydın; "
                        "risk notu kartını oku.",
                    ("Tek risk yüksek fiyattır; çevresel risk yoktur, çünkü cihaz "
                     "çok az madde kullanıyor"):
                        "Risk notu çevresel bir risk anlatıyor.",
                },
                rastgele=rastgele,
                aciklama=risk,
                ipuclari=["Risk notu kartını oku."],
                puan=8,
            ),
        ],
        kapanis=("Karar verildi: {} toplamda {}, {} toplamda {} birim. Yeni teknoloji "
                 "de ölçüldü; riski rapora yazıldı."
                 ).format(eski_ad, eski_top, yeni_ad, yeni_top),
        odul={"itibar": 5, "cevher": 1, "erzak": 2},
    )


# ==========================================================================
# FİZİKSEL VE KİMYASAL DEĞİŞİM: RENK YA DA HÂL DEĞİŞİMİ YETMEZ (B37.13)
#
# `fiziksel_kimyasal_degisim` tek satırlıktı (2018: 9). Bağlam: "Atölyedeki
# değişim kayıtlarını kanıta göre ayırma". `yaygin_yanlis`:
#
#   "Her renk veya hâl değişimini yeni madde oluşumu saymak."
#
# DÜZENEK: atölye değişim defteri. Kimyasal değişimlerin hepsinde renk ya da
# hâl değişimi var, AMA renk ya da hâl değiştiren fiziksel olaylar da var:
# mor buhara dönüp yeniden kristalleşen iyot, kızarıp soğuyunca eski rengine
# dönen demir, eriyen buz, suya dağılan mürekkep. Ölçüt yeni madde oluşup
# oluşmadığıdır.
#
# YANILGININ SAYISAL KARŞILIĞI: kimyasal değişim sayısına renk ya da hâl
# değişimi gözlenen bütün kayıtları yazmak.
# ==========================================================================

_KIMYASAL_KAYITLAR = (
    "Demir kapıda turuncu-kahverengi pas oluştu.",
    "Gümüş kaşık zamanla karardı; ovunca siyah bir tabaka döküldü.",
    "Mum yandı; alevin üstündeki soğuk camda su damlaları ve is birikti.",
)
_TUZAK_FIZIKSEL_KAYITLAR = (
    "İyot kristalleri ısıtılınca mor buhara dönüştü; soğuk camda yeniden aynı kristaller oluştu.",
    "Demir çubuk ocakta kızıllaştı; soğuyunca eski rengine döndü.",
    "Buz kalıbı eridi, su oldu; su dondurulunca yeniden buz oldu.",
    "Mavi mürekkep suya damlatılınca su açık maviye boyandı.",
)
_DUZ_FIZIKSEL_KAYITLAR = (
    "Cam şişe düşüp kırıldı.",
    "Bakır tel bükülerek halka yapıldı.",
)


@bulmaca(ders="kimya", konu="fiziksel_kimyasal_degisim", kademeler=(9, 13), agirlik=1.3)
def degisim_defteri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kimyasal değişimin ölçütü yeni madde oluşumudur; renk ya da hâl değişimi tek başına yetmez."""
    kimyasal = rastgele.sample(_KIMYASAL_KAYITLAR, 2)
    tuzak = rastgele.sample(_TUZAK_FIZIKSEL_KAYITLAR, 2)
    duz = rastgele.sample(_DUZ_FIZIKSEL_KAYITLAR, 1)
    kayitlar = ([(k, "kimyasal") for k in kimyasal] + [(k, "tuzak") for k in tuzak]
                + [(k, "duz") for k in duz])
    rastgele.shuffle(kayitlar)
    metinler = [k for k, _ in kayitlar]
    kimyasal_indeksler = [n for n, (_, tur) in enumerate(kayitlar) if tur == "kimyasal"]
    renk_hal_sayisi = len(kimyasal) + len(tuzak)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-degisim-defteri",
        ders="kimya",
        baslik="Değişim Defteri",
        kademe=kademe,
        konu="fiziksel_kimyasal_degisim",
        kazanim="Fiziksel ve kimyasal değişimi yeni madde oluşumu ölçütüyle ayırt etme; "
                "renk ya da hâl değişiminin tek başına kimyasal değişim kanıtı "
                "olmadığını açıklama.",
        dikkat=7,
        brifing=(
            "Atölyenin değişim defteri güvenlik raporuna eklenecek; kimyasal "
            "değişimler ayrı işaretlenmeli.\n\n"
            "{} işaretlemeyi şöyle yaptı: \"Rengi ya da hâli değişen her şey yeni bir "
            "maddeye dönüşmüştür. Defterde renk ya da hâl değişimi olan {} kayıt var; "
            "hepsi kimyasal değişim.\"\n\n"
            "Rapor gönderilmeden önce kayıtları kanıta göre ayırmamız gerekiyor."
        ).format(kisi, renk_hal_sayisi),
        kanitlar=[
            Kanit("Değişim defteri", "\n".join(metinler), bedel=1, kritik=True),
            Kanit("Değişim notu",
                  "Kimyasal değişimde özellikleri farklı yeni bir madde oluşur (pas, is, "
                  "su, kararmış tabaka); çoğu zaman basit yollarla geri dönülmez. Fiziksel "
                  "değişimde madde aynı kalır: hâl, biçim, renk ya da dağılım değişebilir "
                  "ama madde yenisine dönüşmez.",
                  bedel=1, kritik=True),
            Kanit("Laboratuvar notu",
                  "Soğuk camda toplanan mor kristaller yeniden tartıldı ve incelendi: "
                  "başlangıçtaki iyotla aynı özellikte.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir değişimin kimyasal olduğunu ne gösterir?",
                dogru=("Özellikleri farklı yeni madde oluşması; renk ya da hâl "
                       "değişimi fiziksel de olabilir"),
                yanlislar={
                    "Rengin ya da hâlin değişmesi: her renk veya hâl değişimi yeni maddedir":
                        "Her renk veya hâl değişimini yeni madde oluşumu saydın. "
                        "Eriyen buz yine su; mor buhar yeniden iyot kristali oluyor.",
                    "Değişimin hızlı olması: yavaş değişimler fizikseldir":
                        "Paslanma yavaş ama kimyasal; hız ölçüt değil.",
                    ("Isı kullanılması: ısıtılan her madde kimyasal değişime uğrar; "
                     "ısı maddenin yapısını bozar"):
                        "Kızaran demir soğuyunca aynı demir; ısı tek başına yeni madde "
                        "oluşturmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kimyasal değişimi ayırt eden, maddenin kimliğinin değişmesidir: "
                    "pas demirden, is ve su mumdan farklı maddelerdir. Hâl, renk ya da "
                    "biçim değişimi maddeyi değiştirmeden de olabilir."
                ),
                ipuclari=[
                    "Laboratuvar notunda soğuyan iyot neye dönüşüyor?",
                    "Değişim notunda ölçüt nedir?",
                ],
                cozum="Kimyasal: yeni madde.\nFiziksel: madde aynı (hâl/renk/biçim değişebilir).",
            ),
            sayi_adimi(
                soru="Defterdeki kayıtlardan kaç tanesi kimyasal değişimdir?",
                cevap=len(kimyasal),
                aciklama="Yeni madde oluşan kayıtlar: {}. Öteki renk ve hâl değişimleri fiziksel.".format(
                    len(kimyasal)),
                yaygin_yanlislar={
                    renk_hal_sayisi:
                        "Her renk veya hâl değişimini yeni madde oluşumu saydın; kızaran "
                        "demir, eriyen buz ya da süblimleşen iyotta madde aynı kalıyor.",
                    len(kayitlar):
                        "Bütün kayıtları saydın; kırılma ve bükülmede madde değişmiyor.",
                },
                ipuclari=["Yalnız yeni madde oluşan kayıtları say."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi kayıtlar kimyasal değişimdir? (numaraları virgülle yaz)",
                secenekler=metinler,
                dogru_indeksler=kimyasal_indeksler,
                aciklama="Pas, kararma tabakası, is ve su yeni maddelerdir. Öteki kayıtlarda madde aynı kalıyor.",
                ipuclari=["Her kayıtta 'sonunda aynı madde mi var?' diye sor."],
                puan=12,
            ),
            secim_adimi(
                soru="İyotun mor buhara dönüşmesi için hangisi doğru?",
                dogru="Fiziksel değişim: hâl ve renk değişti ama soğuyunca aynı iyot kristalleri oluştu",
                yanlislar={
                    ("Kimyasal değişim: renk mora döndüğü için yeni bir madde "
                     "oluştu; her renk değişimi tepkime demektir"):
                        "Her renk veya hâl değişimini yeni madde oluşumu saydın; "
                        "laboratuvar notu kristallerin aynı iyot olduğunu söylüyor.",
                    "Kimyasal değişim: ısıtıldığı için":
                        "Isıtma tek başına yeni madde oluşturmaz.",
                },
                rastgele=rastgele,
                aciklama="Süblimleşme bir hâl değişimidir; madde yine iyottur.",
                ipuclari=["Laboratuvar notunu oku."],
                puan=10,
            ),
        ],
        kapanis=("Rapor düzeltildi: {} kayıttan yalnız {} tanesi kimyasal değişim; renk ya "
                 "da hâl değişimi tek başına yeni madde demek değil."
                 ).format(len(kayitlar), len(kimyasal)),
        odul={"itibar": 4, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# MADDENİN HÂLLERİ: GAZIN KÜTLESİ VAR; ISINAN TANECİK BÜYÜMEZ (B37.13)
#
# `maddenin_halleri` tek satırlıktı (2018: 9). Bağlam: "Numunelerin hâl ve
# tanecik modellerini eşleme". `yaygin_yanlis`:
#
#   "Gazların kütlesi olmadığını sanmak; tanecik boyutunu sıcaklıkla büyütmek."
#
# DÜZENEK: dolu ve boş tartılan gaz tüpü (fark gazın kütlesi); ısıtılınca
# şişen balon (hacim artar ama tanecik çapı değişmez: tanecikler hızlanır,
# aralarındaki boşluk büyür); üç tanecik modeli kartı (katı, sıvı, gaz).
#
# YANILGILARIN SAYISAL KARŞILIĞI: gaz kütlesini 0 yazmak; tanecik çapını
# hacim oranıyla büyütmek.
# ==========================================================================

_MODEL_KARTLARI = (
    ("katı", "tanecikler düzenli sıralar hâlinde, birbirine değiyor, yerinde titreşiyor"),
    ("sıvı", "tanecikler düzensiz, birbirine değiyor, birbirinin üstünden kayıyor"),
    ("gaz", "tanecikler arasında büyük boşluklar var, düzensiz ve hızlı hareket ediyor"),
)
_TANECIK_CAPI = 0.3   # nm, hava tanecikleri için yaklaşık


@bulmaca(ders="kimya", konu="maddenin_halleri", kademeler=(9, 13), agirlik=1.3)
def gaz_tupu_tartimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Gazların da kütlesi vardır; ısınınca tanecik büyümez, aralarındaki boşluk artar."""
    bos = rastgele.choice((12.0, 15.0))
    gaz = rastgele.choice((1.5, 2.2, 3.0))
    dolu = round(bos + gaz, 1)
    v1 = rastgele.choice((2.0, 3.0))
    v2 = round(v1 * 1.2, 2)
    harfler = ["A", "B", "C"]
    rastgele.shuffle(harfler)
    kart_harfi = {hal: harfler[i] for i, (hal, _) in enumerate(_MODEL_KARTLARI)}
    kartlar = sorted(("Kart {}: {}".format(kart_harfi[hal], tarif) for hal, tarif in _MODEL_KARTLARI))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-gaz-tupu-tartimi",
        ders="kimya",
        baslik="Gaz Tüpü Tartımı",
        kademe=kademe,
        konu="maddenin_halleri",
        kazanim="Gazların kütlesi olduğunu ölçümle gösterme; ısınan gazda taneciklerin "
                "büyümediğini, hızlanıp aralarındaki boşluğun arttığını açıklama; "
                "katı, sıvı ve gaz tanecik modellerini eşleme.",
        dikkat=7,
        brifing=(
            "Depodaki gaz tüpleri ve numune kapları yeniden etiketlenecek.\n\n"
            "{} etiketlere şunu eklemek istiyor: \"Gazın kütlesi yok; tüp dolu da olsa "
            "boş da olsa aynı ağırlıkta taşınır. Güneşte balon şişiyor, çünkü içindeki "
            "tanecikler ısınınca büyüyor.\"\n\n"
            "Etiketler basılmadan önce ölçümleri doğru yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Tartı kaydı",
                  "Boş tüp: {} kg. Aynı tüp gazla doldurulunca: {} kg.".format(sy(bos), sy(dolu)),
                  bedel=1, kritik=True),
            Kanit("Balon deneyi",
                  "Ağzı bağlı balonun hacmi 27 °C sıcaklıkta {} L, güneşte 87 °C sıcaklıkta "
                  "{} L oldu. Hava taneciklerinin çapı yaklaşık {} nm.".format(
                      sy(v1), sy(v2), sy(_TANECIK_CAPI)),
                  bedel=1, kritik=True),
            Kanit("Tanecik modeli kartları", "\n".join(kartlar), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Gazlar ve ısınma için hangisi doğrudur?",
                dogru=("Gaz tanecikleri de kütle taşır; ısınınca büyümez, hızlanır "
                       "ve aralarındaki boşluk artar"),
                yanlislar={
                    ("Gazların kütlesi yoktur; bu yüzden tüp dolu ya da boş aynı "
                     "gelir, gaz havada uçtuğuna göre ağırlıksızdır"):
                        "Gazların kütlesi olmadığını sandın. Tartı kaydında dolu tüp "
                        "daha ağır.",
                    ("Isınınca taneciklerin kendisi büyür; hacim bu yüzden artar, "
                     "tıpkı ısınan metalin genleşmesi gibi"):
                        "Tanecik boyutunu sıcaklıkla büyüttün. Isınan tanecikler "
                        "hızlanır, birbirinden uzaklaşır; boyutları değişmez.",
                    "Isınınca tanecik sayısı artar":
                        "Balonun ağzı bağlı; içeri tanecik girmiyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Madde hangi hâlde olursa olsun tanecikleri kütle taşır. Sıcaklık "
                    "taneciklerin hareket enerjisini artırır; gazda tanecikler daha hızlı "
                    "ve daha uzak olur, hacim bu boşluk yüzünden büyür."
                ),
                ipuclari=[
                    "Tartı kaydında dolu ve boş tüp aynı mı?",
                    "Balon ısınınca içeri yeni tanecik girdi mi?",
                ],
                cozum="Gaz kütlesi = dolu − boş\nIsınma: hız ve boşluk ↑, tanecik boyutu sabit",
            ),
            sayi_adimi(
                soru="Tüpteki gazın kütlesi kaç kg?",
                cevap=gaz,
                birim="kg",
                aciklama="{} − {} = {} kg.".format(sy(dolu), sy(bos), sy(gaz)),
                yaygin_yanlislar={
                    0:
                        "Gazların kütlesi olmadığını sandın; dolu tüp {} kg daha ağır.".format(sy(gaz)),
                    sy(dolu).replace(",", "."):
                        "Tüpün kendi kütlesini de saydın; boş tüpü çıkar.",
                },
                ipuclari=["Dolu tüpten boş tüpü çıkar."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Güneşte ısınan balonda hava taneciklerinin çapı yaklaşık kaç nm?",
                cevap=_TANECIK_CAPI,
                birim="nm",
                aciklama="Tanecikler büyümez: yine yaklaşık {} nm. Hacim, tanecikler arası boşluk arttığı için büyüdü.".format(
                    sy(_TANECIK_CAPI)),
                yaygin_yanlislar={
                    sy(round(_TANECIK_CAPI * 1.2, 2)).replace(",", "."):
                        "Tanecik boyutunu sıcaklıkla büyüttün: çapı hacimle aynı oranda "
                        "artırdın.",
                },
                ipuclari=["Isınınca değişen tanecik boyutu mu, aralarındaki boşluk mu?"],
                puan=12,
                tolerans=0.01,
            ),
            secim_adimi(
                soru="Tanecik modeli kartlarından hangisi gazı gösterir?",
                dogru="Kart {}".format(kart_harfi["gaz"]),
                yanlislar={
                    "Kart {}".format(kart_harfi["sıvı"]):
                        "Bu kartta tanecikler birbirine değiyor: sıvı.",
                    "Kart {}".format(kart_harfi["katı"]):
                        "Düzenli ve yerinde titreşen tanecikler katıyı gösterir.",
                },
                rastgele=rastgele,
                aciklama="Gazda tanecikler arasında büyük boşluklar var; düzensiz ve hızlı hareket ediyorlar.",
                ipuclari=["Tanecikler arasında en çok boşluk olan kartı bul."],
                puan=10,
            ),
        ],
        kapanis=("Etiketler düzeltildi: tüpteki gaz {} kg; balon şişince tanecikler "
                 "büyümedi, aralarındaki boşluk arttı."
                 ).format(sy(gaz)),
        odul={"itibar": 4, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# KARIŞIMLARI AYIRMA: SÜZME HER KARIŞIMA YARAMAZ (B37.13)
#
# `ayirma` tek satırlıktı (2018: 10). Bağlam: "Numunenin özelliklerine uygun
# ayırma işlemini seçme". `yaygin_yanlis`:
#
#   "Her karışımı süzerek ayırabileceğini sanmak."
#
# DÜZENEK: kum, tuz ve su karışımı numune süzülüyor: süzgeçte yalnız kum
# kalır; çözünmüş tuz süzüntüye geçer ve ancak buharlaştırmayla geri alınır.
# Ardından iki karışım için bileşenlerin farklı özelliğine uygun yöntem
# seçilir (mıknatıs, ayırma hunisi, ayrımsal damıtma, kromatografi).
#
# YANILGILARIN SAYISAL KARŞILIĞI: süzgeçte kum + tuz kaldığını yazmak;
# süzüntüde tuz kalmadığını sanmak. Seçimlerde "süzme" şıkkı.
# ==========================================================================

# (karışım, doğru yöntem, yararlanılan özellik, yanlış ikinci yöntem)
_AYIRMA_KARISIMLARI = (
    ("demir tozu ve kum", "mıknatısla ayırma", "demirin mıknatısa çekilmesi", "buharlaştırma"),
    ("zeytinyağı ve su", "ayırma hunisi", "birbirinde çözünmemeleri ve yoğunluk farkı", "mıknatısla ayırma"),
    ("alkol ve su", "ayrımsal damıtma", "kaynama noktalarının farklı olması", "ayırma hunisi"),
    ("mürekkepteki renkli boyalar", "kâğıt kromatografisi", "çözücüyle kâğıtta farklı hızla ilerlemeleri",
     "mıknatısla ayırma"),
)

_SUZME_SIKKI = (
    "Süzme: süzgeç kâğıdı iki bileşeni ayırır, çünkü tanecik boyutları farklıdır",
    "Her karışımı süzerek ayırabileceğini sandın; süzme yalnız çözünmeyen katıyı "
    "sıvıdan ayırır.",
)
# Yağ-su karışımında süzme şıkkı savunulabilir (ıslak süzgeç kâğıdı yağı
# tutabilir); orada süzme yerine açıkça yanlış bir yöntem sorulur.
_AYIRMA_ILK_YANLIS = {
    "zeytinyağı ve su": (
        "Buharlaştırma: yağ sudan önce uçar, su kapta kalır",
        "Yağın sudan önce uçacağını sandın; zeytinyağının kaynama noktası sudan "
        "çok yüksektir. Isıtınca önce su uçar ve kaybolur.",
    ),
}


@bulmaca(ders="kimya", konu="ayirma", kademeler=(10, 13), agirlik=1.3)
def ayirma_masasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Ayırma yöntemi bileşenlerin farklı özelliğine göre seçilir; süzme çözünmüş katıyı ayırmaz."""
    kum = rastgele.choice((20, 30, 40))
    tuz = rastgele.choice((5, 8, 12))
    su = rastgele.choice((150, 200))
    iki = rastgele.sample(_AYIRMA_KARISIMLARI, 2)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    def yontem_adimi(karisim):
        ad, dogru, ozellik, yanlis = karisim
        ilk_sik, ilk_teshis = _AYIRMA_ILK_YANLIS.get(ad, _SUZME_SIKKI)
        return secim_adimi(
            soru="{} nasıl ayrılır?".format(ad[:1].upper() + ad[1:]),
            dogru="{} (yararlanılan özellik: {})".format(dogru[:1].upper() + dogru[1:], ozellik),
            yanlislar={
                ilk_sik: ilk_teshis,
                ("{}: aynı sonucu verir; bileşenler birbirinden farklı olduğu "
                 "sürece her yöntem ayırır").format(yanlis[:1].upper() + yanlis[1:]):
                    "Bu yöntem bu karışımın bileşenlerindeki farktan yararlanmaz.",
            },
            rastgele=rastgele,
            aciklama="{}: {}; yararlanılan fark: {}.".format(ad[:1].upper() + ad[1:], dogru, ozellik),
            ipuclari=["İki bileşeni birbirinden ayıran özellik ne?"],
            puan=10,
        )

    return Bulmaca(
        kod="kim-ayirma-masasi",
        ders="kimya",
        baslik="Ayırma Masası",
        kademe=kademe,
        konu="ayirma",
        kazanim="Karışımın bileşenlerindeki özellik farkına göre uygun ayırma yöntemini "
                "seçme; süzmenin yalnız çözünmeyen katıyı ayırdığını ölçümle gösterme.",
        dikkat=7,
        brifing=(
            "Laboratuvara bir kutu karışık numune geldi; bileşenler ayrılıp depoya "
            "konacak.\n\n"
            "{} iş planını şöyle yazdı: \"Hepsini süzgeç kâğıdından geçirelim; kâğıt "
            "her şeyi ayırır. Kum-tuz-su karışımında kum da tuz da süzgeçte kalır, "
            "{} ile {} karışımlarını da aynı yolla ayırırız.\"\n\n"
            "İşe başlamadan önce her karışım için doğru yöntemi seçmemiz gerekiyor."
        ).format(kisi, iki[0][0], iki[1][0]),
        kanitlar=[
            Kanit("Numune kaydı",
                  "Karışım: {} g kum, {} g tuz, {} g su. Tuz suda tamamen çözünmüş.".format(kum, tuz, su),
                  bedel=1, kritik=True),
            Kanit("Yöntem notu",
                  "Süzme: sıvıda çözünmeyen katıyı ayırır. Buharlaştırma: çözünmüş katıyı "
                  "sudan ayırır. Mıknatısla ayırma: manyetik maddeyi ayırır. Ayırma hunisi: "
                  "birbirinde çözünmeyen sıvıları ayırır. Ayrımsal damıtma: kaynama noktası "
                  "farklı sıvıları ayırır. Kromatografi: çözücüde farklı hızla ilerleyen "
                  "maddeleri ayırır.",
                  bedel=1, kritik=True),
            Kanit("Tuz tanecikleri",
                  "Çözünen tuz, su tanecikleri arasına dağılmış iyonlar hâlinde; süzgeç "
                  "kâğıdının gözeneklerinden çok küçük.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Ayırma yöntemi nasıl seçilir?",
                dogru=("Bileşenlerin farklı bir özelliğine göre; süzme yalnız "
                       "çözünmeyen katıyı ayırır"),
                yanlislar={
                    ("Her karışım süzülerek ayrılabilir; süzgeç kâğıdı yeterlidir, "
                     "çözünen madde de kâğıtta kalır"):
                        "Her karışımı süzerek ayırabileceğini sandın. Çözünmüş tuz "
                        "süzgeçten geçer.",
                    "Yöntem karışımın rengine göre seçilir":
                        "Renk bir ayırma ölçütü değil; bileşenlerin fiziksel özellik "
                        "farkı gerekir.",
                    "Karışımlar ayrılamaz; bileşenler birbirine dönüşmüştür":
                        "Karışımda bileşenler özelliklerini korur; fiziksel yollarla ayrılır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Her ayırma yöntemi bir farktan yararlanır: tanecik boyutu (süzme), "
                    "uçuculuk (buharlaştırma, damıtma), manyetiklik, yoğunluk ve "
                    "çözünmezlik (ayırma hunisi), çözücüdeki hız (kromatografi)."
                ),
                ipuclari=[
                    "Tuz suda çözünmüşse süzgeçte kalabilir mi?",
                    "Yöntem notunda her yöntemin yararlandığı fark ne?",
                ],
                cozum="Yöntem = bileşenler arasındaki özellik farkı",
            ),
            sayi_adimi(
                soru="Karışım süzülünce süzgeç kâğıdında kaç g katı kalır? (kuru ağırlık)",
                cevap=kum,
                birim="g",
                aciklama="Yalnız çözünmeyen kum kalır: {} g. Tuz çözünmüş hâlde süzüntüye geçer.".format(kum),
                yaygin_yanlislar={
                    kum + tuz:
                        "Her karışımı süzerek ayırabileceğini sandın; çözünmüş tuz "
                        "süzgeçte kalmaz.",
                    kum + tuz + su:
                        "Bütün karışımı yazdın; su da tuz da kâğıttan geçer.",
                },
                ipuclari=["Suda çözünmeyen bileşen hangisi?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Süzüntü tamamen buharlaştırılınca kapta kaç g katı kalır?",
                cevap=tuz,
                birim="g",
                aciklama="Su buharlaşır, çözünmüş tuz geri kalır: {} g.".format(tuz),
                yaygin_yanlislar={
                    0:
                        "Tuzun süzgeçte kaldığını düşündün; tuz süzüntüye geçmişti ve "
                        "buharlaştırmayla geri alınır.",
                },
                ipuclari=["Süzgeçten geçen katı hangisiydi?"],
                puan=10,
            ),
            yontem_adimi(iki[0]),
            yontem_adimi(iki[1]),
        ],
        kapanis=("Plan düzeltildi: süzgeçte {} g kum kaldı, tuz ({} g) buharlaştırmayla "
                 "alındı. {} ve {} için bileşen farkına uygun yöntem seçildi."
                 ).format(kum, tuz, iki[0][0], iki[1][0]),
        odul={"itibar": 4, "cevher": 2, "erzak": 1},
    )


# ==========================================================================
# POLARLIK VE GÖSTERİM: POLAR BAĞ POLAR MOLEKÜL DEMEK DEĞİL (B37.13)
#
# `lewis_polarlik` tek satırlıktı (2026: 9). Bağlam: "Depo bileşik kartlarının
# ad ve gösterimlerini eşleme". `yaygin_yanlis`:
#
#   "Bağ polarlığını doğrudan molekül polarlığı saymak; alt indis ile katsayıyı
#    karıştırmak."
#
# DÜZENEK: depo bileşik kartları: formül, molekül şekli, bağların polar olup
# olmadığı. Simetrik moleküllerde (CO₂, CCl₄, BF₃) bağlar polar olsa da
# kutuplar birbirini götürür: molekül apolar. İkinci kısım: "3H₂O" gibi bir
# gösterimde katsayı molekül sayısını, alt indis molekül başına atom sayısını
# verir; toplam atom = katsayı × alt indis.
#
# YANILGILARIN SAYISAL KARŞILIĞI: polar molekül sayısına polar bağlı bütün
# molekülleri yazmak; toplam atomu katsayı + alt indis ya da yalnız alt indis
# almak.
# ==========================================================================

# (formül, şekil, bağlar polar mı, molekül polar mı)
_POLARLIK_KARTLARI = (
    ("H₂O", "kırık, açılı", True, True),
    ("NH₃", "üçgen piramit", True, True),
    ("HCl", "iki atomlu, doğrusal", True, True),
    ("CO₂", "doğrusal, simetrik", True, False),
    ("CCl₄", "düzgün dörtyüzlü, simetrik", True, False),
    ("BF₃", "düzgün üçgen, simetrik", True, False),
    ("O₂", "iki atomlu, doğrusal", False, False),
)
# (formül, sayılan element, molekül başına atom)
_ATOM_SAYIMLARI = (("H₂O", "H", 2), ("CO₂", "O", 2), ("NH₃", "H", 3),
                   ("CH₄", "H", 4), ("CCl₄", "Cl", 4))


@bulmaca(ders="kimya", konu="lewis_polarlik", kademeler=(9, 13), agirlik=1.3)
def bilesik_kartlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Molekül polarlığı bağ polarlığına ve şekle bağlıdır; katsayı ile alt indis farklı şey sayar."""
    polar = [k for k in _POLARLIK_KARTLARI if k[3]]
    tuzak = [k for k in _POLARLIK_KARTLARI if k[2] and not k[3]]
    apolar_bag = [k for k in _POLARLIK_KARTLARI if not k[2]]
    kartlar = rastgele.sample(polar, 2) + rastgele.sample(tuzak, 2) + apolar_bag
    rastgele.shuffle(kartlar)
    secenekler = ["{} ({}; bağlar {})".format(f, sekil, "polar" if bp else "apolar")
                  for f, sekil, bp, _ in kartlar]
    polar_indeksler = [n for n, k in enumerate(kartlar) if k[3]]
    polar_bagli_sayisi = sum(1 for k in kartlar if k[2])
    simetrik = [k for k in kartlar if k[2] and not k[3]][0]

    formul, element, alt = rastgele.choice(_ATOM_SAYIMLARI)
    katsayi = rastgele.choice((2, 3, 4))
    toplam = katsayi * alt
    atom_yanlislari = {}
    for deger, metin in ((katsayi + alt, "Katsayı ile alt indisi topladın; çarpmalısın: "
                                         "her molekülde {} tane var.".format(alt)),
                         (alt, "Yalnız alt indisi yazdın; bu bir moleküldeki sayı. "
                               "Katsayı molekül sayısını verir."),
                         (katsayi, "Yalnız katsayıyı yazdın; her molekülde {} {} atomu var."
                                   .format(alt, element))):
        if deger != toplam and deger not in atom_yanlislari:
            atom_yanlislari[deger] = metin
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-bilesik-kartlari",
        ders="kimya",
        baslik="Bileşik Kartları",
        kademe=kademe,
        konu="lewis_polarlik",
        kazanim="Polar bağ ile polar molekülü ayırt etme; molekül şeklinin polarlığa "
                "etkisini açıklama; kimyasal gösterimde katsayı ve alt indisin anlamını "
                "ayırarak atom sayısını bulma.",
        dikkat=8,
        brifing=(
            "Depodaki bileşik kartları çözücü rafına göre yeniden dizilecek: polar "
            "moleküller bir rafa, apolar moleküller öteki rafa.\n\n"
            "{} şunu yazdı: \"Bağları polar olan her molekül polardır; {} de polar "
            "rafa. Bir de '{}{}' etiketinde {} + {} = {} tane {} atomu var.\"\n\n"
            "Raflar düzenlenmeden önce kartları doğru okumamız gerekiyor."
        ).format(kisi, simetrik[0], katsayi, formul, katsayi, alt, katsayi + alt, element),
        kanitlar=[
            Kanit("Bileşik kartları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Polarlık notu",
                  "Bağın polarlığı iki atomun elektron çekme farkından gelir. Molekülün "
                  "polarlığı ise bütün bağ kutuplarının toplamıdır: simetrik şekilde "
                  "birbirini götüren kutuplar apolar molekül verir.",
                  bedel=1, kritik=True),
            Kanit("Gösterim notu",
                  "Formülün önündeki büyük sayı katsayıdır: molekül sayısını gösterir. "
                  "Atom simgesinin sağ altındaki küçük sayı alt indistir: bir moleküldeki "
                  "o atomun sayısını gösterir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Polarlık ve kimyasal gösterim için hangisi doğrudur?",
                dogru=("Polar bağlı molekül simetrikse apolar olabilir; katsayı "
                       "molekül, alt indis atom sayısını verir"),
                yanlislar={
                    ("Bağları polar olan her molekül polardır; polar bağların "
                     "toplamı molekülü de polar yapar"):
                        "Bağ polarlığını doğrudan molekül polarlığı saydın. CO₂ gibi "
                        "simetrik moleküllerde bağ kutupları birbirini götürür.",
                    ("Katsayı ile alt indis aynı şeyi gösterir; ikisi toplanır, "
                     "çünkü ikisi de formüldeki atom sayısını söyler"):
                        "Alt indis ile katsayıyı karıştırdın; katsayı molekül sayısı, "
                        "alt indis moleküldeki atom sayısı.",
                    "Apolar bağlı bir molekül her zaman polardır":
                        "Bağları apolar olan molekülde kutup oluşmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Molekül polarlığı, bağ kutuplarının vektör toplamıdır. Doğrusal CO₂ "
                    "ya da dörtyüzlü CCl₄ simetriktir: kutuplar birbirini götürür. "
                    "Kırık H₂O'da götürmez. Gösterimde '3H₂O', üç su molekülü ve toplam "
                    "altı hidrojen demektir."
                ),
                ipuclari=[
                    "Kartlarda 'simetrik' yazan moleküllere dikkat et.",
                    "Gösterim notunda katsayı ne gösteriyor?",
                ],
                cozum="Molekül polarlığı = bağ polarlığı + şekil\nToplam atom = katsayı × alt indis",
            ),
            sayi_adimi(
                soru="Kartlardaki moleküllerden kaç tanesi polar moleküldür?",
                cevap=len(polar_indeksler),
                aciklama="Polar ve simetrik olmayan moleküller: {}.".format(
                    ", ".join(k[0] for k in kartlar if k[3])),
                yaygin_yanlislar={
                    polar_bagli_sayisi:
                        "Bağ polarlığını doğrudan molekül polarlığı saydın; simetrik "
                        "moleküllerde kutuplar birbirini götürüyor.",
                },
                ipuclari=["Bağları polar ama şekli simetrik olanları çıkar."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi kartlar polar rafa gider? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=polar_indeksler,
                aciklama="Polar bağlı ve simetrik olmayan moleküller polar rafa; simetrikler ve O₂ apolar rafa.",
                ipuclari=["Bağlar polar mı ve şekil simetrik mi, ikisine birden bak."],
                puan=12,
            ),
            secim_adimi(
                soru="{} için hangisi doğru?".format(simetrik[0]),
                dogru="Bağları polar ama molekül apolar: {} şekilde bağ kutupları birbirini götürür".format(
                    simetrik[1].split(",")[0]),
                yanlislar={
                    ("Bağları polar olduğu için molekül de polardır; polar "
                     "bağlardan kurulmuş bir molekül apolar olamaz"):
                        "Bağ polarlığını doğrudan molekül polarlığı saydın.",
                    "Bağları apolar olduğu için molekül de apolardır":
                        "Kartta bağların polar olduğu yazıyor; apolarlık şekilden geliyor.",
                },
                rastgele=rastgele,
                aciklama="Simetrik şekil bağ kutuplarını birbirine eşit ve zıt yönde dizer; toplamları sıfır olur.",
                ipuclari=["Kartta molekülün şekli ne yazıyor?"],
                puan=10,
            ),
            sayi_adimi(
                soru="'{}{}' etiketinde toplam kaç {} atomu vardır?".format(katsayi, formul, element),
                cevap=toplam,
                aciklama="{} molekül × molekül başına {} {} atomu = {}.".format(katsayi, alt, element, toplam),
                yaygin_yanlislar=atom_yanlislari,
                ipuclari=["Katsayıyı alt indisle çarp."],
                puan=10,
            ),
        ],
        kapanis=("Raflar düzeltildi: {} polar rafta; {} bağları polar olsa da apolar rafa "
                 "kondu. '{}{}' etiketinde {} {} atomu var."
                 ).format(", ".join(k[0] for k in kartlar if k[3]), simetrik[0],
                          katsayi, formul, toplam, element),
        odul={"itibar": 4, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# YEŞİL KİMYA: AZ MADDE KULLANMAK SIFIR ATIK DEMEK DEĞİL (B37.13)
#
# `yesil_kimya` tek satırlıktı (2026: 10). Bağlam: "İki hazır deney planının
# atık ve kaynak bilançosunu karşılaştırma". `yaygin_yanlis`:
#
#   "Daha az madde kullanımının hiç atık olmadığı anlamına geldiğini sanmak."
#
# DÜZENEK: aynı ürünü veren iki deney planı. Kütle korunur: girenlerden ürüne
# dönüşmeyen ve geri kazanılmayan her gram atıktır. Plan A daha az madde
# kullanır; bazı senaryolarda daha az atık da yapar, bazılarında çözücüsünü
# geri kazanan Plan B daha az atık yapar. E faktörü = atık ÷ ürün.
#
# YANILGILARIN SAYISAL KARŞILIĞI: az madde kullanan planın atığını 0 yazmak;
# geri kazanılan çözücüyü atık saymak.
# ==========================================================================

# (A: reaktif, çözücü, geri kazanılan, ürün), (B: ...)
_YESIL_PLANLAR = (
    ((40, 20, 0, 30), (50, 60, 55, 40)),
    ((40, 10, 0, 36), (50, 60, 50, 40)),
    ((30, 30, 0, 20), (45, 50, 48, 36)),
)


def _atik(plan):
    reaktif, cozucu, geri, urun = plan
    return reaktif + cozucu - geri - urun


@bulmaca(ders="kimya", konu="yesil_kimya", kademeler=(10, 13), agirlik=1.3)
def deney_planlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kütle korunur: ürüne dönüşmeyen ve geri kazanılmayan her madde atıktır."""
    plan_a, plan_b = rastgele.choice(_YESIL_PLANLAR)
    atik_a, atik_b = _atik(plan_a), _atik(plan_b)
    e_a = round(atik_a / float(plan_a[3]), 2)
    e_b = round(atik_b / float(plan_b[3]), 2)
    toplam_a = plan_a[0] + plan_a[1]
    toplam_b = plan_b[0] + plan_b[1]
    b_daha_yesil = e_b < e_a
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    def plan_yazisi(ad, plan):
        return ("{}: {} g reaktif, {} g çözücü kullanılıyor; çözücünün {} g kadarı geri "
                "kazanılıyor; {} g ürün elde ediliyor.").format(ad, *plan)

    return Bulmaca(
        kod="kim-deney-planlari",
        ders="kimya",
        baslik="Deney Planları",
        kademe=kademe,
        konu="yesil_kimya",
        kazanim="Kütle korunumuyla bir deney planının atığını hesaplama; daha az madde "
                "kullanmanın atığı sıfırlamadığını açıklama; iki planı E faktörüyle "
                "(atık ÷ ürün) karşılaştırma.",
        dikkat=8,
        brifing=(
            "Laboratuvar aynı ürün için iki hazır deney planından birini seçecek.\n\n"
            "{} karar vermiş: \"Plan A toplam {} g madde kullanıyor, Plan B {} g. Az "
            "madde kullanan planın atığı olmaz; Plan A sıfır atıklı, onu seçelim.\"\n\n"
            "Plan onaylanmadan önce iki planın atık bilançosunu çıkarmamız gerekiyor."
        ).format(kisi, toplam_a, toplam_b),
        kanitlar=[
            Kanit("Plan kartları",
                  plan_yazisi("Plan A", plan_a) + "\n" + plan_yazisi("Plan B", plan_b),
                  bedel=1, kritik=True),
            Kanit("Bilanço notu",
                  "Kütle korunur: giren kütle = ürün + geri kazanılan + atık. E faktörü = "
                  "atık kütlesi ÷ ürün kütlesi; küçük olan daha yeşildir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir deney planının atığı için hangisi doğrudur?",
                dogru=("Ürüne dönüşmeyen, geri kazanılmayan her madde atıktır; az "
                       "madde atığı azaltabilir, sıfırlamaz"),
                yanlislar={
                    ("Daha az madde kullanan planın hiç atığı olmaz; madde azaldıkça "
                     "atık da tamamen biter"):
                        "Daha az madde kullanımının hiç atık olmadığı anlamına "
                        "geldiğini sandın. Kütle korunur: ürüne geçmeyen kütle bir "
                        "yere gider.",
                    ("Atık yalnız reaktiflerden gelir; çözücü tepkimeye girmediği "
                     "için atık sayılmaz"):
                        "Geri kazanılmayan çözücü de atıktır.",
                    ("Daha çok madde kullanan plan her zaman daha çok atık yapar; "
                     "atık kullanılan maddeyle orantılıdır"):
                        "Geri kazanım ve verim de hesaba girer; karar bilançoyla verilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kimyasal süreçlerde kütle kaybolmaz. Girenlerin ürün olmayan ve "
                    "geri kazanılmayan kısmı atıktır. Yeşil kimya atığı ürün başına "
                    "ölçer ve azaltmaya çalışır; 'az madde' tek başına ölçüt değildir."
                ),
                ipuclari=[
                    "Plan A'da girenlerle ürün arasındaki fark nereye gidiyor?",
                    "Bilanço notundaki eşitliği yaz.",
                ],
                cozum="Atık = reaktif + çözücü − geri kazanılan − ürün\nE = atık ÷ ürün",
            ),
            sayi_adimi(
                soru="Plan A kaç g atık üretir?",
                cevap=atik_a,
                birim="g",
                aciklama="{} + {} − {} − {} = {} g.".format(*plan_a, atik_a),
                yaygin_yanlislar={
                    0:
                        "Daha az madde kullanımının hiç atık olmadığı anlamına geldiğini "
                        "sandın; kütle korunumuna göre fark atık olur.",
                },
                ipuclari=["Girenlerden ürünü ve geri kazanılanı çıkar."],
                puan=12,
            ),
            sayi_adimi(
                soru="Plan B kaç g atık üretir?",
                cevap=atik_b,
                birim="g",
                aciklama="{} + {} − {} − {} = {} g.".format(*plan_b, atik_b),
                yaygin_yanlislar={
                    plan_b[0] + plan_b[1] - plan_b[3]:
                        "Geri kazanılan çözücüyü de atık saydın; geri kazanılan kısım "
                        "yeniden kullanılıyor.",
                },
                ipuclari=["Geri kazanılan çözücüyü de çıkarmayı unutma."],
                puan=12,
            ),
            sayi_adimi(
                soru="Plan A için E faktörü (atık ÷ ürün) kaçtır?",
                cevap=e_a,
                aciklama="{} ÷ {} = {}.".format(atik_a, plan_a[3], sy(e_a)),
                yaygin_yanlislar={
                    0:
                        "Plan A'nın atığını sıfır saydın.",
                },
                ipuclari=["Plan A atığını ürün kütlesine böl."],
                puan=10,
                tolerans=0.01,
            ),
            yorum_adimi(
                soru="Hangi plan seçilmeli?",
                dogru=("Plan B: ürün başına atığı daha az (E = {} < {})".format(sy(e_b), sy(e_a))
                       if b_daha_yesil else
                       "Plan A: ürün başına atığı daha az (E = {} < {}), ama atığı sıfır değil".format(
                           sy(e_a), sy(e_b))),
                yanlislar={
                    ("Plan A: hiç atığı yok; daha az madde harcadığı için temiz"
                     if b_daha_yesil else
                     "Plan A: hiç atığı yok; az madde kullanan planın atığı da olmaz, "
                     "bu yüzden seçilmeli"):
                        "Daha az madde kullanımının hiç atık olmadığı anlamına geldiğini sandın.",
                    ("Plan A: daha az madde kullanıyor, bu yeterli" if b_daha_yesil
                     else "Plan B: daha çok madde kullandığı için daha güvenilir"):
                        "Karar ürün başına atığa (E faktörüne) göre verilir.",
                },
                rastgele=rastgele,
                aciklama="E(A) = {}, E(B) = {}: küçük olan daha yeşil.".format(sy(e_a), sy(e_b)),
                ipuclari=["İki planın E faktörünü karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("Karar düzeltildi: Plan A {} g, Plan B {} g atık üretiyor (E: {} ve {}). "
                 "{} seçildi.").format(atik_a, atik_b, sy(e_a), sy(e_b),
                                       "Plan B" if b_daha_yesil else "Plan A"),
        odul={"itibar": 4, "cevher": 1, "erzak": 2},
    )


# ==========================================================================
# GÜNLÜK HAYAT KİMYASALLARI: DOĞAL OLAN GÜVENLİ DEMEK DEĞİL (B37.13)
#
# `gunluk_kimyasallar` tek satırlıktı (2018: 10). Bağlam: "Üs tedarik
# listesindeki ürünlerin işlev ve etiketlerini yorumlama". `yaygin_yanlis`:
#
#   "Doğal olan her maddeyi koşulsuz güvenli sanmak."
#
# DÜZENEK: tedarik listesindeki temizlik ürünleri, etiketleri ve pH değerleri.
# Doğal kaynaklı sirke asidi derişikken yakıcı; çamaşır suyuyla karıştırılırsa
# klor gazı çıkarır. Güvenlik doğal/sentetik ayrımına değil derişime, doza ve
# birlikte kullanıma bağlıdır. Sayısal kısım: derişik çözeltiden seyreltme.
#
# YANILGILARIN SAYISAL KARŞILIĞI: derişik ürünü seyreltmeden kullanmak
# (gereken hacmi çözeltinin tamamı sanmak); tehlikeli karışımları güvenli
# saymak.
# ==========================================================================

# (karışım, tehlikeli mi, sonuç)
_KARISIM_PLANLARI = (
    ("Çamaşır suyu + tuz ruhu", True, "zehirli klor gazı açığa çıkar"),
    ("Çamaşır suyu + amonyaklı cam temizleyici", True, "zehirli kloramin gazı açığa çıkar"),
    ("Çamaşır suyu + sirke", True, "asit hipokloriti bozar, klor gazı açığa çıkar"),
    ("Sirke + karbonat", False, "köpürerek karbon dioksit çıkar; tehlikeli gaz oluşmaz"),
    ("Karbonat + ılık su", False, "karbonat çözünür; tehlikeli gaz oluşmaz"),
    ("Sıvı sabun + su", False, "seyrelmiş sabun çözeltisi olur"),
)
_URUN_ETIKETLERI = (
    "Sirke asidi (doğal kaynaklı, %80): YAKICI. Cildi ve gözü tahriş eder; seyreltmeden kullanmayın.",
    "Limon tuzu (sitrik asit, doğal): TAHRİŞ EDİCİ. Tozunu solumayın.",
    "Çamaşır suyu (%5 sodyum hipoklorit): YAKICI. Asitli ürünlerle karıştırmayın.",
    "Karbonat (sodyum bikarbonat): zararsız kabul edilir; gözle teması durumunda yıkayın.",
)


@bulmaca(ders="kimya", konu="gunluk_kimyasallar", kademeler=(10, 13), agirlik=1.2)
def tedarik_listesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Güvenlik doğal olup olmamaya değil derişime, doza ve birlikte kullanıma bağlıdır."""
    tehlikeli = rastgele.sample([k for k in _KARISIM_PLANLARI if k[1]], 2)
    guvenli = rastgele.sample([k for k in _KARISIM_PLANLARI if not k[1]], 2)
    planlar = tehlikeli + guvenli
    rastgele.shuffle(planlar)
    secenekler = [p[0] for p in planlar]
    tehlikeli_indeksler = [n for n, p in enumerate(planlar) if p[1]]

    derisik = 80          # %
    hedef = rastgele.choice((5, 10))            # %
    hacim = rastgele.choice((400, 500, 800))    # mL
    gereken = round(hacim * hedef / float(derisik), 2)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="kim-tedarik-listesi",
        ders="kimya",
        baslik="Tedarik Listesi",
        kademe=kademe,
        konu="gunluk_kimyasallar",
        kazanim="Günlük hayat kimyasallarının etiketlerini yorumlama; güvenliğin "
                "doğal-sentetik ayrımına değil derişim, doz ve birlikte kullanıma bağlı "
                "olduğunu açıklama; derişik üründen seyreltme hesabı yapma.",
        dikkat=7,
        brifing=(
            "Üssün temizlik tedarik listesi onaylanacak; kullanım notları da "
            "yazılacak.\n\n"
            "{} listeye şunu ekledi: \"Sirke ve limon tuzu doğal; ne kadar derişik "
            "olursa olsun güvenlidir, seyreltmeye gerek yok. Daha güçlü olsun diye "
            "çamaşır suyuyla karıştıralım.\"\n\n"
            "Liste onaylanmadan önce etiketleri doğru okumamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Ürün etiketleri", "\n".join(_URUN_ETIKETLERI), bedel=1, kritik=True),
            Kanit("Karışım planları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Seyreltme kuralı",
                  "Üs kuralı: temizlikte kullanılan sirke asidi %{} olmalı. Seyreltmede "
                  "çözünen miktarı korunur: derişik hacim × %{} = hedef hacim × %{}."
                  .format(hedef, derisik, hedef),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir temizlik ürününün güvenli olup olmadığını ne belirler?",
                dogru=("Derişimi, dozu ve başka ürünlerle birlikte kullanımı; doğal "
                       "olması tek başına güvenli yapmaz"),
                yanlislar={
                    ("Doğal kaynaklı olması: doğal her madde güvenlidir, çünkü "
                     "doğada zaten bulunur"):
                        "Doğal olan her maddeyi koşulsuz güvenli saydın. Etikete göre "
                        "doğal kaynaklı derişik sirke asidi yakıcı.",
                    ("Sentetik olması: sentetik her madde tehlikelidir; laboratuvarda "
                     "üretilen madde vücuda yabancıdır"):
                        "Karbonat sentetik üretilir ve zararsız kabul edilir; ölçüt "
                        "üretim yolu değil.",
                    "Kokusunun keskinliği: kokusuz ürünler güvenlidir":
                        "Koku güvenlik ölçütü değildir; kokusuz gazlar da zehirli olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı madde seyreltikken güvenli, derişikken yakıcı olabilir. "
                    "Etiketler tehlikeyi ve birlikte kullanılmaması gereken ürünleri "
                    "yazar. Doğal-sentetik ayrımı bir güvenlik ölçütü değildir."
                ),
                ipuclari=[
                    "Sirke asidi etiketinde ne yazıyor?",
                    "Çamaşır suyu etiketi hangi ürünlerle karıştırmayı yasaklıyor?",
                ],
                cozum="Güvenlik = derişim + doz + birlikte kullanım",
            ),
            coklu_adimi(
                soru="Hangi karışım planları tehlikelidir? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=tehlikeli_indeksler,
                aciklama="Çamaşır suyunun asitli ya da amonyaklı ürünlerle karışması zehirli gaz çıkarır.",
                ipuclari=["Çamaşır suyu etiketindeki uyarıyı oku."],
                puan=12,
            ),
            sayi_adimi(
                soru="%{} derişik sirke asidinden {} mL %{} çözelti hazırlamak için kaç mL alınmalı?".format(
                    derisik, hacim, hedef),
                cevap=gereken,
                birim="mL",
                aciklama="{} × {} ÷ {} = {} mL derişik alınır, üstü suyla {} mL tamamlanır.".format(
                    hacim, hedef, derisik, sy(gereken), hacim),
                yaygin_yanlislar={
                    hacim:
                        "Doğal olan her maddeyi koşulsuz güvenli saydın: derişik ürünü "
                        "seyreltmeden, hacmin tamamı kadar kullandın.",
                    round(hacim * derisik / float(hedef), 2):
                        "Oranı ters kurdun; derişikten daha az hacim gerekir.",
                },
                ipuclari=["Çözünen miktarı korunur: derişik hacim × derişim = hedef hacim × hedef derişim."],
                puan=12,
                tolerans=0.01,
            ),
            yorum_adimi(
                soru="Kullanım notu için hangisi doğru?",
                dogru=("Sirke asidi seyreltilerek kullanılmalı ve çamaşır suyuyla "
                       "karıştırılmamalı"),
                yanlislar={
                    ("Doğal ürünler seyreltilmeden kullanılabilir; sirke doğal "
                     "olduğu için karıştırmak da sorun değil"):
                        "Doğal olan her maddeyi koşulsuz güvenli saydın; etiketler tersini "
                        "söylüyor.",
                    "Çamaşır suyu tek başına tehlikeli olduğundan listeden çıkarılmalı":
                        "Etikete uyulduğunda çamaşır suyu kullanılabilir; sorun asitli "
                        "ürünlerle karıştırmakta.",
                },
                rastgele=rastgele,
                aciklama="Derişik sirke asidi yakıcı; çamaşır suyuyla karışınca klor gazı çıkar.",
                ipuclari=["İki etiketi birlikte oku."],
                puan=10,
            ),
        ],
        kapanis=("Liste onaylandı: sirke asidi %{} olacak şekilde seyreltilecek ({} mL için "
                 "{} mL derişik); çamaşır suyu asitli ürünlerden ayrı rafta duracak."
                 ).format(hedef, hacim, sy(gereken)),
        odul={"itibar": 4, "erzak": 2, "cevher": 1},
    )


# ==========================================================================
# SU VE ÇEVRE KİMYASI: HER KİRLETİCİ AYNI YÖNTEMLE GİDERİLMEZ (B37.13)
#
# `su_cevre_kimyasi` tek satırlıktı (2018: 9). Bağlam: "Üssün su kullanım ve
# atık planını değerlendirme". `yaygin_yanlis`:
#
#   "Arıtma ile her tür kirleticinin aynı yöntemle giderildiğini sanmak."
#
# DÜZENEK: üs su arıtma hattı ve giriş suyu ölçümleri. Kum filtresi askıda
# katıyı tutar; çözünmüş tuzu ve bakteriyi tutmaz. Aktif karbon kokuyu ve
# organik maddeyi, ters ozmoz çözünmüş tuzu (%95), UV ya da klorlama
# mikroorganizmayı giderir.
#
# YANILGILARIN SAYISAL KARŞILIĞI: kum filtresinden sonra tuz derişimini 0
# yazmak; ters ozmozu tam (sıfırlayan) arıtma sanmak.
# ==========================================================================

# (kirletici, giderme yöntemi, kum filtresi tutar mı)
_KIRLETICILER = (
    ("askıda kum ve çamur", "kum filtresi", True),
    ("yaprak ve kaba tortu", "kaba ızgara ve çöktürme", True),
    ("çözünmüş tuz", "ters ozmoz", False),
    ("bakteri ve virüs", "UV ya da klorlama", False),
    ("koku ve organik kalıntı", "aktif karbon", False),
    ("çözünmüş ağır metal", "iyon değiştirici", False),
)
_RO_VERIM = 95   # %


@bulmaca(ders="kimya", konu="su_cevre_kimyasi", kademeler=(9, 13), agirlik=1.3)
def su_aritma_hatti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Her kirletici kendi yöntemiyle giderilir; süzme çözünmüş maddeyi tutmaz."""
    kirleticiler = list(_KIRLETICILER)
    rastgele.shuffle(kirleticiler)
    secenekler = [k[0] for k in kirleticiler]
    kum_indeksleri = [n for n, k in enumerate(kirleticiler) if k[2]]
    tuz = rastgele.choice((400, 600, 800))          # mg/L
    bakteri = rastgele.choice((2000, 5000))          # koloni/100 mL
    ro_cikis = round(tuz * (100 - _RO_VERIM) / 100.0, 1)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    ornek = rastgele.choice([k for k in kirleticiler if not k[2]])

    return Bulmaca(
        kod="kim-su-aritma-hatti",
        ders="kimya",
        baslik="Su Arıtma Hattı",
        kademe=kademe,
        konu="su_cevre_kimyasi",
        kazanim="Sudaki farklı kirleticilerin farklı arıtma yöntemleriyle giderildiğini "
                "açıklama; süzmenin çözünmüş maddeyi gidermediğini ölçümle gösterme; "
                "arıtma verimiyle çıkış derişimini hesaplama.",
        dikkat=7,
        brifing=(
            "Üssün su arıtma hattı yeniden planlanacak; kuyudan gelen ham su "
            "ölçüldü.\n\n"
            "{} plana şunu yazdı: \"Suyu kum filtresinden geçirelim, yeter. Filtre "
            "bütün kirleticileri tutar: tuzu da bakteriyi de süzer, su doğrudan "
            "içilebilir.\"\n\n"
            "Hat kurulmadan önce hangi kirleticinin hangi yöntemle gittiğini "
            "belirlememiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Ham su ölçümü",
                  "Askıda katı: var. Çözünmüş tuz: {} mg/L. Bakteri: {} koloni/100 mL. "
                  "Hafif koku var.".format(tuz, bakteri),
                  bedel=1, kritik=True),
            Kanit("Kirletici listesi", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Arıtma notu",
                  "Kum filtresi ve çöktürme: yalnız askıda (çözünmemiş) katıları tutar. "
                  "Aktif karbon: koku ve organik kalıntıyı tutar. Ters ozmoz: çözünmüş "
                  "tuzun yüzde {} kadarını giderir. İyon değiştirici: çözünmüş ağır metali tutar. "
                  "UV ya da klorlama: mikroorganizmayı etkisizleştirir.".format(_RO_VERIM),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Su arıtmada kirleticiler nasıl giderilir?",
                dogru=("Her kirletici kendine uygun yöntemle giderilir; süzme yalnız "
                       "çözünmemiş katıları tutar"),
                yanlislar={
                    ("Tek bir arıtma yöntemi bütün kirleticileri giderir; iyi bir "
                     "filtre her şeyi tutar"):
                        "Arıtma ile her tür kirleticinin aynı yöntemle giderildiğini "
                        "sandın. Kum filtresi çözünmüş tuzu ve bakteriyi tutmaz.",
                    ("Süzme bütün çözünmüş maddeleri de tutar; kum filtresinden "
                     "geçen suda hiç çözünmüş tuz kalmaz"):
                        "Çözünmüş tanecikler filtre gözeneklerinden çok küçüktür.",
                    "Su berraksa temizdir; başka işlem gerekmez":
                        "Berrak su çözünmüş tuz ve bakteri taşıyabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Arıtma bir dizi işlemdir: kaba tortu çöktürmeyle, askıda katı "
                    "filtreyle, koku aktif karbonla, çözünmüş tuz ters ozmozla, "
                    "mikroorganizma UV ya da klorla giderilir. Bir işlem ötekinin "
                    "yerini tutmaz."
                ),
                ipuclari=[
                    "Arıtma notunda kum filtresi neyi tutuyor?",
                    "Çözünmüş tuz süzgeçte kalır mı?",
                ],
                cozum="Askıda katı: filtre.\nKoku: aktif karbon.\nTuz: ters ozmoz.\nMikrop: UV/klor.",
            ),
            coklu_adimi(
                soru="Kum filtresi ve çöktürme hangi kirleticileri giderir? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=kum_indeksleri,
                aciklama="Yalnız çözünmemiş, askıdaki katılar tutulur; çözünmüş maddeler ve mikroplar geçer.",
                ipuclari=["Suda çözünmüş olanlar filtrede kalır mı?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Su yalnız kum filtresinden geçtikten sonra çözünmüş tuz kaç mg/L olur?",
                cevap=tuz,
                birim="mg/L",
                aciklama="Kum filtresi çözünmüş tuzu tutmaz: {} mg/L değişmeden kalır.".format(tuz),
                yaygin_yanlislar={
                    0:
                        "Arıtma ile her tür kirleticinin aynı yöntemle giderildiğini "
                        "sandın; filtre çözünmüş tuzu tutmaz.",
                },
                ipuclari=["Filtre neyi tutuyor?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Ters ozmozdan sonra çözünmüş tuz kaç mg/L olur?",
                cevap=ro_cikis,
                birim="mg/L",
                aciklama="Ters ozmoz tuzun yüzde {} kadarını giderir: {} × {} ÷ 100 = {} mg/L kalır.".format(
                    _RO_VERIM, tuz, 100 - _RO_VERIM, sy(ro_cikis)),
                yaygin_yanlislar={
                    0:
                        "Ters ozmozu tam arıtma saydın; verim %{}, az da olsa tuz kalır.".format(_RO_VERIM),
                    tuz:
                        "Ters ozmozun tuzu gidermediğini düşündün; asıl işi bu.",
                },
                ipuclari=["Giderilmeyen yüzde kaç?"],
                puan=12,
                tolerans=0.1,
            ),
            secim_adimi(
                soru="{} için hangi işlem gerekir?".format(ornek[0][:1].upper() + ornek[0][1:]),
                dogru=ornek[1][:1].replace("i", "İ").upper() + ornek[1][1:],
                yanlislar={
                    "Kum filtresi: bütün kirleticileri tutar":
                        "Arıtma ile her tür kirleticinin aynı yöntemle giderildiğini "
                        "sandın; kum filtresi yalnız askıda katıyı tutar.",
                    "Hiçbiri: su berraksa işlem gerekmez":
                        "Berraklık çözünmüş madde ya da mikrop olmadığını göstermez.",
                },
                rastgele=rastgele,
                aciklama="{}: {} ile giderilir.".format(
                    ornek[0][:1].replace("i", "İ").upper() + ornek[0][1:], ornek[1]),
                ipuclari=["Arıtma notunda bu kirleticinin satırını bul."],
                puan=10,
            ),
        ],
        kapanis=("Plan düzeltildi: kum filtresi tek başına yetmiyor. Tuz ters ozmozla "
                 "{} mg/L düzeyine indi, mikroplar UV ile etkisizleştirildi, koku aktif "
                 "karbonla alındı.").format(sy(ro_cikis)),
        odul={"itibar": 4, "erzak": 2, "enerji": 1},
    )
