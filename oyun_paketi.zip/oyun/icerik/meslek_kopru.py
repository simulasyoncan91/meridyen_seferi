# -*- coding: utf-8 -*-
"""
Çekirdek köprüleri.

Buradaki görevler, başka bir dalda zaten yazılmış bir ÇEKİRDEĞİ ikinci bir
dala taşımak için yazıldı. Tek dalda kalan çekirdek hiçbir ittifak köprüsü
kurmaz; ikinci dala geçtiği anda "aynı çekirdeği paylaşan farklı dal" kuralı
işlemeye başlar (`oyun/motor/ittifak.py`).

  - `kablo_firesi`  : marangozun kereste firesini elektrikçiye taşır
  - `olcu_cevirme`  : bilişimin birim çevirme çekirdeğini makineye taşır
  - `parca_listesi` : mobilya ve makineye BİRDEN kayıtlı (oran çekirdeği)
  - `atolye_guvenligi` : mobilya ve elektriğe birden kayıtlı (sıra çekirdeği)

Ayrıntı: TASARIM_NOTLARI.md §5

Kademe ölçeği: 1-4 ilkokul, 5-8 ortaokul, 9-12 lise, 13 üniversite.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, model_adimi, sayi_adimi, sirala_adimi,
    sy, yorum_adimi,
)

# (fire oranı, alınacak makara m, işe yarayan net m)
KABLO_UCLULERI = [
    (0.20, 25, 20),
    (0.20, 50, 40),
    (0.25, 32, 24),
    (0.10, 30, 27),
    (0.10, 60, 54),
]

# (tambur çapı mm, devir/dak, dakikada alınan yol m) - PI 3,14 ile tam çıkar.
BANT_UCLULERI = [
    (500, 100, 157.0),
    (500, 200, 314.0),
    (1000, 50, 157.0),
    (1000, 100, 314.0),
]

# (sabit kalıp/ayar bedeli, prototip adedi, adet başı malzeme, seri adedi)
SERI_DORTLULERI = [
    (40, 5, 12, 20),
    (30, 4, 15, 24),
    (60, 6, 10, 30),
]

PI = 3.14


# ==========================================================================
# KABLO FİRESİ  (maliyet_fire -> elektrik)
# ==========================================================================

@bulmaca(ders="elektrik", konu="kablo_firesi", kademeler=(9, 12),
         etiketler=("maliyet_fire",))
def kablo_firesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Marangozun kereste firesiyle birebir aynı bağıntı, başka kılıfta.

    Fire ALINAN miktardan gider: makara = net ÷ (1 - fire). Netin üstüne fire
    eklemek burada da yetmez.
    """
    fire, makara, net = rastgele.choice(KABLO_UCLULERI)
    metre_fiyati = rastgele.choice([12, 15, 20])
    maliyet = makara * metre_fiyati
    yanlis_ekleme = net * (1 + fire)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="elk-kablo-firesi",
        ders="elektrik",
        baslik="Yarım Kalan Hat",
        kademe=kademe,
        konu="kablo_firesi",
        kazanim="Fire oranı ve malzeme siparişi; net ile alınan miktar "
                "arasındaki bağıntı.",
        dikkat=6,
        brifing=(
            "{} mevkiine yeni bir aydınlatma hattı çekilecek. Kroki üzerinden "
            "ölçülen net kablo uzunluğu {} metre.\n\n"
            "{} sipariş verecek ama tesisatta her dönüşte, her buatta ve her "
            "uçta pay bırakılıyor; bu atölyede kablo firesi %{}.\n\n"
            "Geçen ay aynı hesap eksik yapıldı, kablo yarı yolda bitti ve ek "
            "yapmak zorunda kalındı. Ek yerleri hattın en zayıf noktası."
        ).format(mevki, sy(net), kisi, int(round(fire * 100))),
        kanitlar=[
            Kanit("Kroki ölçümü",
                  "Net çekilecek uzunluk: {} metre.".format(sy(net)),
                  bedel=1, kritik=True),
            Kanit("Atölye kaydı",
                  "Kablo firesi %{}. Alınan makaranın işe yarayan payı %{}."
                  .format(int(round(fire * 100)),
                          int(round((1 - fire) * 100))),
                  bedel=2, kritik=True),
            Kanit("Fiyat listesi",
                  "Kablo metre fiyatı: {} birim.".format(metre_fiyati),
                  bedel=1, kritik=True),
            Kanit("Geçen ayın notu",
                  "\"Net uzunluğun üstüne fire kadar ekledik, yine yetmedi.\"",
                  bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="Sipariş edilecek makara uzunluğunu hangi bağıntı verir?",
                dogru="Net uzunluğu, kalan orana (1 - fire) böleriz.",
                yanlislar={
                    "Net uzunluğun üstüne fire oranı kadar ekleriz.":
                        "Geçen ayki hata bu. Fire ALINAN makaradan gider; "
                        "netin üstüne eklenmez. Bu yüzden kablo yarı yolda "
                        "bitiyor.",
                    "Net uzunluğu fire oranıyla çarparız.":
                        "Bu çarpım atılacak payı verir, alınacak makarayı "
                        "değil; üstelik sonuç netten küçük çıkar.",
                    "Net uzunluğu fire oranına böleriz.":
                        "Payda yanlış. Bölen atılan oran değil, KALAN orandır: "
                        "1 - fire.",
                    "Net uzunluk yeterlidir; pay zaten krokide var.":
                        "Kroki hattın gideceği yolu verir. Buatlarda ve "
                        "uçlarda bırakılan pay krokide görünmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Makaranın işe yarayan payı %{}: net = makara × {}. Buradan "
                    "makara = net ÷ {} = {} ÷ {} = {} metre.".format(
                        int(round((1 - fire) * 100)), sy(1 - fire),
                        sy(1 - fire), sy(net), sy(1 - fire), sy(makara))),
                ipuclari=[
                    "Fire hangi miktardan gidiyor: aldığından mı, "
                    "çektiğinden mi?",
                    "Aldığın makaranın yüzde kaçı hatta kalıyor?",
                ],
                cozum=(
                    "1) Kalan oran = 1 - {} = {}\n"
                    "2) Makara = {} ÷ {} = {} metre\n"
                    "3) Maliyet = {} × {} = {} birim".format(
                        sy(fire), sy(1 - fire), sy(net), sy(1 - fire),
                        sy(makara), sy(makara), metre_fiyati, maliyet)),
            ),
            sayi_adimi(
                soru="Kaç metre kablo sipariş edilmeli?",
                cevap=makara,
                birim="metre",
                aciklama="{} ÷ {} = {} metre".format(
                    sy(net), sy(1 - fire), sy(makara)),
                yaygin_yanlislar={
                    round(yanlis_ekleme, 4):
                        "Netin üstüne fire kadar ekledin. Bu makaradan "
                        "yalnızca {} metre işe yarar; hat yine yarım "
                        "kalır.".format(
                            sy(round(yanlis_ekleme * (1 - fire), 2))),
                    net:
                        "Net uzunluğu yazdın; fireyi hiç hesaba katmadın.",
                },
                puan=14,
            ),
            sayi_adimi(
                soru="Siparişin toplam bedeli kaç birim?",
                cevap=maliyet,
                birim="birim",
                aciklama="{} metre × {} = {} birim".format(
                    sy(makara), metre_fiyati, maliyet),
                yaygin_yanlislar={
                    net * metre_fiyati:
                        "Net uzunluğun bedelini hesapladın. Fatura alınan "
                        "makaraya kesilir, hatta kalan kısma değil.",
                    metre_fiyati:
                        "Metre fiyatını yazdın; toplam için uzunlukla çarpman "
                        "gerekiyor.",
                },
                puan=12,
            ),
            yorum_adimi(
                soru="Marangozhanedeki kereste firesi hesabıyla bu hesabın "
                     "ilişkisi nedir?",
                dogru="İkisi aynı bağıntı; yalnızca malzeme değişiyor.",
                yanlislar={
                    "İlgisiz; kablo metreyle, kereste metrekareyle ölçülür.":
                        "Ölçü birimi farklı ama bağıntı aynı: her ikisinde de "
                        "alınan miktarın bir oranı atılıyor.",
                    "Keresteye fire eklenir, kabloda çıkarılır.":
                        "İkisinde de fire alınandan gider; işlem yönü aynı.",
                    "Kabloda fire yoktur, yalnızca ek yapılır.":
                        "Uçlarda ve buatlarda bırakılan pay tam olarak firedir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Fire hesabı bir meslek bilgisi değil, bir bağıntıdır. "
                    "Marangoz kereste, elektrikçi kablo, terzi kumaş der; "
                    "hesap üçünde de net ÷ (1 - fire)."),
            ),
        ],
        kapanis=("Makara {} metre olarak ısmarlandı; hat tek parça çekildi, "
                 "hiç ek yapılmadı.".format(sy(makara))),
        odul={"cevher": 2, "enerji": 1, "itibar": 2},
    )


# ==========================================================================
# ÖLÇÜ ÇEVİRME  (birim_cevirme -> makine)
# ==========================================================================

@bulmaca(ders="makine", konu="olcu_cevirme", kademeler=(9, 12),
         etiketler=("birim_cevirme",))
def olcu_cevirme(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Çevre hesabında iki tuzak: çapı metreye çevirmeyi unutmak (bin kat büyük
    sonuç) ve çap yerine yarıçap kullanmak (yarı sonuç).
    """
    cap_mm, devir, yol_m = rastgele.choice(BANT_UCLULERI)
    cevre_m = round(PI * cap_mm / 1000.0, 4)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mak-olcu-cevirme",
        ders="makine",
        baslik="Kaçan Bant",
        kademe=kademe,
        konu="olcu_cevirme",
        kazanim="Uzunluk birimi çevirme (mm ↔ m) ve dönen tamburda çevre "
                "yolu hesabı.",
        dikkat=6,
        brifing=(
            "Cevher taşıma bandı yeniden ayarlanacak. Bandın ne kadar hızlı "
            "ilerlediğini kimse bilmiyor; yalnızca tamburun ölçüleri var.\n\n"
            "{} tamburun çapını ölçtü: {} mm. Sayaç tamburun dakikada {} "
            "devir döndüğünü gösteriyor.\n\n"
            "Depo, bandın dakikada kaç METRE malzeme taşıdığını soruyor. "
            "Ölçüler milimetre, cevap metre isteniyor."
        ).format(kisi, cap_mm, devir),
        kanitlar=[
            Kanit("Tambur ölçümü",
                  "Çap: {} mm. (Yarıçap değil, çap ölçüldü.)".format(cap_mm),
                  bedel=1, kritik=True),
            Kanit("Devir sayacı",
                  "Tambur dakikada {} devir dönüyor.".format(devir),
                  bedel=1, kritik=True),
            Kanit("El kitabı",
                  "\"Bir turda alınan yol tamburun ÇEVRESİ kadardır: "
                  "çevre = π × çap. Hesapta π yerine 3,14 kullanılır.\"",
                  bedel=2, kritik=True),
            Kanit("Bant kaydı",
                  "Bant kaymıyor, tamburla birlikte dönüyor.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bandın dakikada aldığı yolu hangi bağıntı verir?",
                dogru="Çapı metreye çevirip π ile, sonra devirle çarparız.",
                yanlislar={
                    "Çapı milimetre olarak π ile çarpıp devirle çarparız.":
                        "Birimi çevirmedin. Sonuç milimetre cinsinden çıkar ve "
                        "metre sanıldığında bin kat büyük görünür.",
                    "Yarıçapı π ile çarpıp devirle çarparız, çünkü çevre π × "
                    "yarıçaptır.":
                        "Çevre π × ÇAP'tır. Yarıçapla çarparsan sonucun "
                        "yarısını bulursun; ölçülen zaten çaptı.",
                    "Çapı devir sayısına böleriz.":
                        "Bölme burada bir yol vermez. Her tur bir çevre kadar "
                        "yol demek; turlar toplanır, yani çarpılır.",
                    "Çevreyi bulup 60'a böleriz, çünkü hız saniyelik olmalı.":
                        "60'a bölmek dakikayı saniyeye çevirir. Soru zaten "
                        "dakikada alınan yolu istiyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir tur = π × çap = 3,14 × {} m = {} m. Dakikada {} tur "
                    "atıyor: {} × {} = {} m.".format(
                        sy(cap_mm / 1000.0), sy(cevre_m), devir, sy(cevre_m),
                        devir, sy(yol_m))),
                ipuclari=[
                    "Cevap metre isteniyor; ölçü hangi birimde?",
                    "Ölçülen çap mı yarıçap mı?",
                ],
                cozum=(
                    "1) Çap = {} mm = {} m\n"
                    "2) Bir turun yolu = 3,14 × {} = {} m\n"
                    "3) Dakikada = {} × {} = {} m".format(
                        cap_mm, sy(cap_mm / 1000.0), sy(cap_mm / 1000.0),
                        sy(cevre_m), sy(cevre_m), devir, sy(yol_m))),
            ),
            sayi_adimi(
                soru="Tamburun bir turunda bant kaç metre ilerler?",
                cevap=cevre_m,
                birim="metre",
                aciklama="3,14 × {} m = {} m".format(
                    sy(cap_mm / 1000.0), sy(cevre_m)),
                yaygin_yanlislar={
                    round(PI * cap_mm, 4):
                        "Çapı metreye çevirmedin; bu sayı milimetre "
                        "cinsinden. Bin kat büyük görünüyor.",
                    round(PI * cap_mm / 2000.0, 4):
                        "Yarıçapla hesapladın. Çevre π × çap; ölçülen zaten "
                        "çaptı.",
                },
                puan=12,
            ),
            sayi_adimi(
                soru="Bant dakikada kaç metre ilerler?",
                cevap=yol_m,
                birim="metre",
                aciklama="{} m × {} tur = {} m".format(
                    sy(cevre_m), devir, sy(yol_m)),
                yaygin_yanlislar={
                    round(PI * cap_mm * devir, 4):
                        "Birim çevirme atlandığı için sonuç bin kat büyük.",
                    cevre_m:
                        "Bir turun yolunu yazdın; dakikada {} tur "
                        "atıyor.".format(devir),
                },
                ipuclari=["Bir turun yolunu bulduysan devirle çarp."],
                puan=14,
            ),
            yorum_adimi(
                soru="Aynı devirde daha büyük çaplı tambur takılırsa ne olur?",
                dogru="Bant hızlanır; bir turda daha çok yol alınır.",
                yanlislar={
                    "Bant yavaşlar, büyük tamburu döndürmek daha zordur.":
                        "Çap büyüdükçe çevre büyür; aynı devirde daha çok yol "
                        "alınır.",
                    "Değişmez; devir aynı kaldığı için hız da aynı kalır.":
                        "Devir tur sayısını verir, turun uzunluğunu değil. "
                        "Çevre büyüyünce yol da büyür.",
                    "Bant kayar ve yol hesaplanamaz.":
                        "Kayma ayrı bir sorun; kayıtta bandın kaymadığı "
                        "yazıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yol = çevre × devir. Devir sabitken çevre büyürse yol da "
                    "orantılı büyür."),
            ),
        ],
        kapanis=("Depo bandın hızını öğrendi; sayaç değerinin yanına metre "
                 "karşılığı da yazıldı."),
        odul={"cevher": 3, "itibar": 2},
    )


# ==========================================================================
# SERİ ÜRETİM HESABI  (oran_olcek -> mobilya + makine)
# ==========================================================================

@bulmaca(ders="mobilya", konu="parca_listesi", kademeler=(9, 12),
         etiketler=("oran_olcek",))
@bulmaca(ders="makine", konu="parca_listesi", kademeler=(9, 12),
         etiketler=("oran_olcek",))
def parca_listesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Her şey adetle artmaz.

    Kalıp/ayar için harcanan sabit miktar her üretim işinde bir kez ödenir.
    Onu da adetle çarpan öğrenci fazla malzeme ister; hiç saymayan eksik
    ister. Deneme kalıbı seride kullanılmaz: seri, kendi kalıbını ve ayarını
    aynı miktarla bir kez daha ister. Metin bunu açıkça söylemeli; "kalıp
    hazır, tekrar harcanmayacak" denirse "payı hiç eklemeyiz" savunulabilir.
    """
    sabit, prototip_adet, birim, seri_adet = rastgele.choice(SERI_DORTLULERI)
    prototip_toplam = sabit + prototip_adet * birim
    seri_toplam = sabit + seri_adet * birim
    hepsi_carpim = seri_adet * (prototip_toplam / float(prototip_adet))
    sabitsiz = seri_adet * birim
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mob-parca-listesi",
        ders="mobilya",
        baslik="Prototipten Seriye",
        kademe=kademe,
        konu="parca_listesi",
        kazanim="Sabit gider ile değişken gideri ayırma; doğru orantının "
                "yalnızca değişken kısma uygulanması.",
        dikkat=6,
        brifing=(
            "Üsse yeni sandık tipi geliyor. Önce {} adetlik bir deneme "
            "yapıldı ve toplam {} birim malzeme harcandı.\n\n"
            "{} deftere bir not düşmüş: bu miktarın {} birimi kalıp ve tezgâh "
            "ayarı içindi. Deneme kalıbı seride kullanılamıyor; seri başlarken "
            "kalıp ve ayar aynı miktarla bir kez daha yapılacak.\n\n"
            "Şimdi {} adetlik seri istendi. Depo tek bir sayı bekliyor: "
            "toplam kaç birim malzeme ayrılacak?"
        ).format(prototip_adet, prototip_toplam, kisi, sabit, seri_adet),
        kanitlar=[
            Kanit("Deneme kaydı",
                  "{} adet için toplam {} birim harcandı.".format(
                      prototip_adet, prototip_toplam),
                  bedel=1, kritik=True),
            Kanit("Kalıp notu",
                  "Bu toplamın {} birimi kalıp ve ayar içindi. Seri için "
                  "kalıp ve ayar bir kez, aynı miktarla yeniden yapılacak; "
                  "sandık başına tekrarlanmaz.".format(sabit),
                  bedel=2, kritik=True),
            Kanit("Seri siparişi",
                  "İstenen adet: {}.".format(seri_adet), bedel=1, kritik=True),
            Kanit("Atölye şefi",
                  "\"Deneme sırasında iki parça bozuldu ama onlar kalıp "
                  "payının içinde sayıldı.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Seri üretimin malzemesini hangi yol verir?",
                dogru=("Kalıp payını çıkarıp adede böler, seri adediyle çarpar, "
                       "payı bir kez ekleriz."),
                yanlislar={
                    "Deneme toplamını adede bölüp seri adediyle çarparız, sandık "
                    "başı ortalama her şeyi kapsar.":
                        "Kalıp payını da adetle çarpmış oldun. Kalıp bir kez "
                        "hazırlandı; her sandık için yeniden hazırlanmıyor.",
                    "Bir sandığa düşen malzemeyi seri adediyle çarparız, "
                    "başka bir şey eklemeyiz.":
                        "Bu kez kalıp payını hiç saymadın. Seri için kalıp ve "
                        "ayar bir kez yeniden yapılacak; o pay toplamda yer "
                        "alır.",
                    "Deneme toplamını seri adediyle çarparız, çünkü deneme bir "
                    "sandığın ölçüsüdür.":
                        "Deneme toplamı {} sandığın malzemesi; onu adetle "
                        "çarpmak {} katı büyük bir sayı "
                        "verir.".format(prototip_adet, prototip_adet),
                    "Seri adedini deneme adedine böler, deneme toplamını "
                    "onunla çarparız.":
                        "Bu da bütün toplamı orantılıyor; kalıp payı yine "
                        "adetle büyümüş oluyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Toplam iki parçadan oluşur: adetle ARTAN kısım ve SABİT "
                    "kısım. Bir sandık = ({} - {}) ÷ {} = {} birim. Seri = {} "
                    "+ {} × {} = {} birim.".format(
                        prototip_toplam, sabit, prototip_adet, birim,
                        sabit, seri_adet, birim, seri_toplam)),
                ipuclari=[
                    "Deneme toplamının hepsi sandıklara mı gitti?",
                    "Kalıp kaç kez hazırlanacak: her sandıkta mı, bir kez mi?",
                ],
                cozum=(
                    "1) Sandıklara giden = {} - {} = {} birim\n"
                    "2) Bir sandık = {} ÷ {} = {} birim\n"
                    "3) Seri = {} × {} + {} = {} birim".format(
                        prototip_toplam, sabit, prototip_toplam - sabit,
                        prototip_toplam - sabit, prototip_adet, birim,
                        seri_adet, birim, sabit, seri_toplam)),
            ),
            sayi_adimi(
                soru="Bir sandık için kaç birim malzeme gerekiyor?",
                cevap=birim,
                birim="birim",
                aciklama="({} - {}) ÷ {} = {} birim".format(
                    prototip_toplam, sabit, prototip_adet, birim),
                yaygin_yanlislar={
                    round(prototip_toplam / float(prototip_adet), 4):
                        "Kalıp payını çıkarmadan böldün. O pay tek bir "
                        "sandığa değil, bütün işe aitti.",
                    sabit:
                        "Kalıp payını yazdın; sorulan bir sandığın malzemesi.",
                },
                puan=12,
            ),
            sayi_adimi(
                soru="{} adetlik seri için toplam kaç birim ayrılmalı?".format(
                    seri_adet),
                cevap=seri_toplam,
                birim="birim",
                aciklama="{} × {} + {} = {} birim".format(
                    seri_adet, birim, sabit, seri_toplam),
                yaygin_yanlislar={
                    round(hepsi_carpim, 4):
                        "Kalıp payını da adetle çarptın; fazla malzeme "
                        "istemiş olursun.",
                    sabitsiz:
                        "Seri kalıbının payını hiç saymadın; eksik kalır.",
                },
                puan=14,
            ),
            yorum_adimi(
                soru="Seri adedi büyüdükçe bir sandığın ortalama maliyeti ne "
                     "olur?",
                dogru="Düşer; kalıp payı daha çok sandığa bölünür.",
                yanlislar={
                    "Artar, çünkü seri büyüdükçe toplam malzeme de büyür.":
                        "Toplam büyür ama sandık BAŞINA düşen küçülür: sabit "
                        "pay aynı kalıp daha çok parçaya yayılır.",
                    "Değişmez; her sandık aynı malzemeyi kullanır.":
                        "Değişken kısım aynı kalır, ama sabit payın sandık "
                        "başına düşen kısmı küçülür.",
                    "Önce düşer sonra artar.":
                        "Sabit pay bölündükçe azalır; geri yükselmesi için bir "
                        "sebep yok.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sandık başına maliyet = birim + sabit ÷ adet. Adet "
                    "büyüdükçe ikinci terim küçülür. Seri üretimin ucuzluğu "
                    "buradan gelir."),
            ),
        ],
        kapanis=("Depoya {} birim yazıldı. Şef kalıp notunun altını çizdi: "
                 "\"Bu bir kez.\"".format(seri_toplam)),
        odul={"cevher": 3, "erzak": 1, "itibar": 2},
    )


# ==========================================================================
# ATÖLYE GÜVENLİĞİ  (sira_prosedur -> mobilya + elektrik)
# ==========================================================================

@bulmaca(ders="mobilya", konu="atolye_guvenligi", kademeler=(8, 12),
         etiketler=("sira_prosedur",))
@bulmaca(ders="elektrik", konu="atolye_guvenligi", kademeler=(8, 12),
         etiketler=("sira_prosedur",))
def atolye_guvenligi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    İş bitiminde sıra: önce tehlikeyi durdur, sonra ortamı güvene al, en son
    düzen ve kayıt.

    Temizliğe enerji kesilmeden başlamak, bu listedeki tek ölümcül hatadır.
    """
    adimlar_dogru = [
        "Makineyi durdur ve enerjisini kes",
        "Kesici takımı ve sıcak parçaları emniyete al",
        "Talaşı ve kablo uçlarını topla",
        "Aletleri sayıp yerine koy",
        "İş bitiş kaydını deftere yaz",
    ]
    karisik = list(adimlar_dogru)
    rastgele.shuffle(karisik)
    sirali = [karisik.index(a) for a in adimlar_dogru]
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="mob-atolye-guvenligi",
        ders="mobilya",
        baslik="Vardiya Sonu",
        kademe=kademe,
        konu="atolye_guvenligi",
        kazanim="İş bitiminde güvenlik sırası; tehlikeyi durdurmanın "
                "düzenden ve kayıttan önce gelmesi.",
        dikkat=5,
        brifing=(
            "{} atölyesinde vardiya bitiyor. Tezgâhın etrafı talaş dolu, "
            "kesici takım hâlâ takılı, uzatma kablosu yerde.\n\n"
            "Çırak süpürgeyi almış temizliğe başlıyor; ustabaşı önce deftere "
            "yazılmasını istiyor. İkisi de sıranın başında olduğunu "
            "düşünüyor.\n\n"
            "Beş iş var ve hangisinin önce geleceği yazılı değil. Geçen yıl "
            "aynı atölyede bir el yaralanması bu yüzden olmuş."
        ).format(mevki),
        kanitlar=[
            Kanit("Güvenlik levhası",
                  "\"Hiçbir temizlik, ayar ya da kontrol işine makinenin "
                  "enerjisi kesilmeden başlanmaz.\"",
                  bedel=1, kritik=True),
            Kanit("Kaza kaydı",
                  "Geçen yılki yaralanma, dönen tezgâhın yanında talaş "
                  "toplanırken olmuş.", bedel=2, kritik=True),
            Kanit("Takım kuralı",
                  "Kesici takım ve sıcak parçalar, ortalık toplanmadan önce "
                  "emniyete alınır; sonra el ile çalışmak güvenli olur.",
                  bedel=2, kritik=True),
            Kanit("Defter kuralı",
                  "Vardiya kaydı, yapılan bütün işler bittikten sonra "
                  "yazılır; eksik yazılan kayıt işe yaramaz.", bedel=1),
            Kanit("Alet dolabı",
                  "Dolapta her aletin yeri işaretli.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu beş işin sırasını ne belirler?",
                dogru=("Önce tehlikeyi durdurmak, sonra emniyete almak, en son "
                       "düzen ve kayıt."),
                yanlislar={
                    "Önce ortalığı toplamak; temiz ve düzenli ortamda her iş "
                    "daha güvenli olur.":
                        "Toplama işinin kendisi tehlikeli olan adım. Dönen "
                        "tezgâhın yanında talaş toplamak geçen yılki "
                        "yaralanmanın sebebi.",
                    "Önce deftere yazmak; kayıt tutulmayan iş yapılmamış "
                    "sayılır.":
                        "Kayıt önemlidir ama tehlikeyi durdurmaz. Üstelik "
                        "yapılmamış işler daha yazılamaz.",
                    "Önce aletleri toplamak, çünkü kaybolan alet işi en çok aksatır.":
                        "Alet toplamak da makine dururken yapılacak bir iş. "
                        "Sıranın başında enerji kesme var.",
                    "Sıra önemli değil; hepsi vardiya sonunda yapılıyor.":
                        "Sıra tam olarak önemli olan şey. Aynı beş iş, farklı "
                        "sırada yapıldığında birinin eli kesilebiliyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Güvenlik adımları maliyet ya da kolaylık sıralamasına "
                    "girmez; onların üstündedir. Enerji kesilmeden yapılan "
                    "her iş, ne kadar basit olursa olsun risklidir."),
                ipuclari=[
                    "Hangi iş yapılmadan diğerlerine başlamak tehlikeli?",
                    "Defter en başa mı yoksa en sona mı yazılır?",
                ],
            ),
            sirala_adimi(
                soru="İşleri yapılacakları sıraya diz (numaraları sırayla yaz):",
                secenekler=karisik,
                dogru_sira=sirali,
                aciklama=(
                    "Doğru sıra: enerjiyi kes → kesici ve sıcak parçaları "
                    "emniyete al → talaşı ve kabloları topla → aletleri yerine "
                    "koy → deftere yaz. İlk ikisi güvenlik, sonraki ikisi "
                    "düzen, sonuncusu kayıt."),
                ipuclari=[
                    "İlk adım her zaman tehlikeyi durdurmaktır.",
                    "Kayıt, yapılanların tamamını yazdığı için en sonda olur.",
                ],
                puan=20,
            ),
            yorum_adimi(
                soru="Çırağın süpürgeyle başlaması neden tehlikeliydi?",
                dogru=("Makine hâlâ enerjiliydi; dönen parçanın yanında elle "
                       "çalışılmaz."),
                yanlislar={
                    "Tehlikeli değildi; süpürmek zararsız bir iştir.":
                        "Süpürmek zararsız, süpürülen YER zararlı. Kaza kaydı "
                        "tam olarak bunu anlatıyor.",
                    "Tehlikeliydi çünkü talaş kaygandır; makine dursa da asıl risk "
                    "budur.":
                        "Kayma ayrı bir risk ama buradaki asıl tehlike "
                        "makinenin enerjili olması.",
                    "Tehlikeliydi çünkü aletler henüz toplanmamıştı.":
                        "Dağınık alet düzen sorunudur; can güvenliğini "
                        "belirleyen enerjinin kesilmiş olmasıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir işin kendisi basit olabilir; onu tehlikeli yapan, "
                    "yapıldığı andaki ortamdır."),
            ),
        ],
        kapanis=("Levha tezgâhın üstüne asıldı: \"Önce enerji, sonra el.\" "
                 "Vardiya kaydı beş satır olarak dolduruldu."),
        odul={"itibar": 3, "erzak": 1},
    )
