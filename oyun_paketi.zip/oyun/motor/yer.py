# -*- coding: utf-8 -*-
"""
Üssün gerçek yeri: Türkiye'de bir koordinat ve oradan gelen şartlar.

Kullanıcı (5 Kasım 2026): "İlk başta üssün kurulacağı yeri seçmek başta
güzel olsa da çok kafa karıştırıyor. Başlangıçta varsayılan olarak bir yer
seçilsin fakat herkesinki aynı olmasın. Mesela biri kuzey 32,30 - doğu 40,10
gibi bir koordinatta üs kurar (sistem orayı seçer) ve o konumun coğrafi
şartlarına göre ilerler." Kapsam kararı: Türkiye ve sınır kapıları;
"sınırlardan gelen şeyler oralarda yazar."

NE YAPAR
--------
* Yeni seferde öğrenciye SORU SORMADAN bir nokta atar. Nokta kaydın
  kimliğinden türetilir: aynı öğrenci her açılışta aynı yerde, sınıf
  arkadaşları farklı yerlerde. Önce il (81'i eşit olasılıkla), sonra o ilin
  sınırları İÇİNDEN önceden örneklenmiş noktalardan biri
  (`veri/yer_noktalari.csv`, atlas/turkiye.json il sınırlarından).
* Arazi o ilin tablosundan gelir (`veri/yer_iller.csv`): jeotermal saha,
  1200 m üstü dağ eteği, Karadeniz iklimi orman, büyük nehir kıyısı, kalanı
  düzlük. Kuşak her zaman yeryüzü; konum.py'nin ekonomisi aynen işler.
* Bölgede yatağı olan madenler işlemede daha verimli (YEREL_TENOR_CARPANI).
  Yatağı olmayan maden YİNE işlenir, sadece normal verimle: KİLİT YOK
  (TASARIM_NOTLARI §0). Yanlış yere düştüğü için kilitlenen öğrenci olmamalı.
* En yakın açık sınır kapısı ve oradan gelen madde gösterilir
  (`veri/yer_kapilar.csv`).

VERİNİN DOĞRULUĞU
-----------------
İl merkezi koordinatları atlas/merkezler.json ile aynı. Rakımlar il merkezinin
YAKLAŞIK rakımıdır. Maden listesi MEB coğrafya müfredatındaki "Türkiye'nin yer
altı kaynakları" özetinden. Sınır kapıları kara kapılarıdır; "durum" sütunu
Kasım 2026 itibarıyladır. `oyunda_gelen_maden` GERÇEK TİCARET VERİSİ DEĞİL,
oyun kararıdır: Türkiye'de olmayan ya da az olan madenler kapıdan gelir.

ESKİ KAYITLAR
-------------
`Durum.yer` boşsa hiçbir şey değişmez: konum eskisi gibi kuşak/arazi kodu.
Yer yalnızca kurulumun "konum" adımında (yeni sefer) atanır.
"""
from __future__ import annotations

import csv
import hashlib
import io
import math
import os
from typing import Any, Dict, List, Optional, Tuple

YEREL_TENOR_CARPANI = 1.25     # bölgede yatağı olan madenin işleme verimi

_IKLIM_ADI = {
    "karadeniz": "Karadeniz iklimi",
    "akdeniz": "Akdeniz iklimi",
    "akdeniz_gecis": "Akdeniz ile karasal arası",
    "gecis": "Marmara (geçiş) iklimi",
    "karasal": "Karasal iklim",
}

_ILLER: Optional[Dict[int, Dict[str, Any]]] = None
_NOKTALAR: Optional[Dict[int, List[Tuple[float, float]]]] = None
_KAPILAR: Optional[List[Dict[str, Any]]] = None


def _veri(ad: str) -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "veri", ad)


def _oku(ad: str) -> List[Dict[str, str]]:
    with io.open(_veri(ad), encoding="utf-8-sig", newline="") as dosya:
        return list(csv.DictReader(dosya))


def _yukle() -> None:
    global _ILLER, _NOKTALAR, _KAPILAR
    if _ILLER is not None:
        return
    iller = {}
    for s in _oku("yer_iller.csv"):
        p = int(s["plaka"])
        iller[p] = {
            "plaka": p, "il": s["il"], "bolge": s["bolge"],
            "enlem": float(s["enlem"]), "boylam": float(s["boylam"]),
            "rakim": int(s["rakim_m_yaklasik"]),
            "kiyi": [k for k in s["kiyi"].split(";") if k],
            "iklim": s["iklim"], "arazi": s["arazi"],
            "su_arazisi": s["su_arazisi"],
            "madenler": [m for m in s["madenler"].split(";") if m],
            "maden_notu": s["maden_notu"],
        }
    noktalar: Dict[int, List[Tuple[float, float]]] = {}
    for s in _oku("yer_noktalari.csv"):
        noktalar.setdefault(int(s["plaka"]), []).append(
            (float(s["enlem"]), float(s["boylam"])))
    kapilar = []
    for s in _oku("yer_kapilar.csv"):
        kapilar.append({
            "kapi": s["kapi"], "plaka": int(s["plaka"]), "il": s["il"],
            "ulke": s["komsu_ulke"], "karsi": s["karsi_kapi"],
            "durum": s["durum"], "gelen": s["oyunda_gelen_maden"],
            "enlem": float(s["enlem_yaklasik"]), "boylam": float(s["boylam_yaklasik"]),
        })
    _ILLER, _NOKTALAR, _KAPILAR = iller, noktalar, kapilar


def iller() -> Dict[int, Dict[str, Any]]:
    _yukle()
    return dict(_ILLER or {})


def _tohum(metin: str) -> int:
    return int(hashlib.sha256(metin.encode("utf-8")).hexdigest()[:12], 16)


def nokta_sec(tohum_metni: str) -> Dict[str, Any]:
    """Tohumdan (kayıt kimliği) bir il ve o ilin içinden bir nokta.

    Aynı tohum hep aynı noktayı verir. `random` kullanılmıyor: Python
    sürümleri arasında aynı tohumun aynı sayıyı vermesi garanti değil.
    """
    _yukle()
    n = _tohum(tohum_metni or "meridyen")
    plakalar = sorted(_NOKTALAR or {})
    plaka = plakalar[n % len(plakalar)]
    adaylar = _NOKTALAR[plaka]
    enlem, boylam = adaylar[(n // len(plakalar)) % len(adaylar)]
    return {"plaka": plaka, "enlem": enlem, "boylam": boylam}


def yer_ata(durum) -> Dict[str, Any]:
    """Yeni sefere yer atar: `durum.yer` ve `durum.konum` yazılır."""
    tohum = durum.kimlik() if hasattr(durum, "kimlik") else ""
    secim = nokta_sec(tohum)
    durum.yer = secim
    durum.konum = "yeryuzu:" + il_bilgisi(secim["plaka"])["arazi"]
    return secim


def il_bilgisi(plaka: int) -> Dict[str, Any]:
    _yukle()
    return dict((_ILLER or {})[int(plaka)])


def var_mi(durum) -> bool:
    yer = getattr(durum, "yer", None) or {}
    return bool(yer.get("plaka"))


def koordinat_metni(enlem: float, boylam: float) -> str:
    """39.75, 37.02 -> "39,75° K  37,02° D" (Türkçe ondalık virgül)."""
    def yaz(x):
        return "{:.2f}".format(abs(x)).replace(".", ",")
    return "{}° {}  {}° {}".format(yaz(enlem), "K" if enlem >= 0 else "G",
                                   yaz(boylam), "D" if boylam >= 0 else "B")


def _mesafe_km(e1, b1, e2, b2) -> float:
    r = 6371.0
    f1, f2 = math.radians(e1), math.radians(e2)
    df, dl = f2 - f1, math.radians(b2 - b1)
    a = math.sin(df / 2) ** 2 + math.cos(f1) * math.cos(f2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def en_yakin_kapi(durum) -> Optional[Dict[str, Any]]:
    """Açık (ya da kısıtlı) en yakın kara sınır kapısı. Kapı koordinatları
    yaklaşıktır (~10 km); mesafe kuş uçuşudur."""
    if not var_mi(durum):
        return None
    _yukle()
    e, b = durum.yer["enlem"], durum.yer["boylam"]
    en_iyi = None
    for k in _KAPILAR or []:
        if k["durum"] == "kapalı":
            continue
        km = _mesafe_km(e, b, k["enlem"], k["boylam"])
        if en_iyi is None or km < en_iyi["km"]:
            en_iyi = dict(k, km=int(round(km)))
    return en_iyi


def yerel_madenler(durum) -> List[str]:
    """Bölgede yatağı olan ve oyunda karşılığı olan maden kodları."""
    if not var_mi(durum):
        return []
    return [m for m in il_bilgisi(durum.yer["plaka"])["madenler"]
            if not m.startswith("+")]


def tenor_carpani(durum, kod: str) -> float:
    if durum is not None and kod in yerel_madenler(durum):
        return YEREL_TENOR_CARPANI
    return 1.0


def ozet(durum) -> Dict[str, Any]:
    """Ekranda gösterilecek her şey; ekran kodu hesap yapmasın."""
    if not var_mi(durum):
        return {}
    il = il_bilgisi(durum.yer["plaka"])
    kapi = en_yakin_kapi(durum)
    return {
        "koordinat": koordinat_metni(durum.yer["enlem"], durum.yer["boylam"]),
        "il": il["il"], "bolge": il["bolge"],
        "iklim": _IKLIM_ADI.get(il["iklim"], il["iklim"]),
        "rakim": il["rakim"], "kiyi": il["kiyi"],
        "maden_notu": il["maden_notu"],
        "yerel_madenler": yerel_madenler(durum),
        "kapi": kapi,
    }
