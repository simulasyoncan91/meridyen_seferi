# -*- coding: utf-8 -*-
"""
Sınıf sunucusu.

    python araclar/sinif_sunucusu.py

NE YAPAR, NE YAPMAZ
-------------------
YAPAR   : sınıf kodunu doğrular, sessiz el kaldırma bildirilerini sayar.
YAPMAZ  : oyunu çalıştırmaz, soru üretmez, kayıt tutmaz, not vermez.

Bu ayrım kasıtlı ve sunucunun en önemli özelliği. Oyun TELEFONDA çalışıyor
(bkz. mobil/OKU.md). Sunucu düşerse ders durmaz: öğrenci oynamaya devam
eder, yalnızca el kaldıramaz. Sunucuya oyun mantığı taşıyan biri bu
güvenceyi kaybeder.

NEDEN SUNUCU GEREKİYOR
----------------------
Öğrenciler kendi hücresel verileriyle bağlanıyor; hepsi ayrı ağda. Ortak
bir klasör yok, birbirlerini göremiyorlar. Sınıfı birbirine bağlayan tek
şey öğretmenin verdiği kod ve o kodu tanıyan bir buluşma noktası.

Aynı ağdaysanız (okul kablosuzu, paylaşılan klasör) buna gerek YOK --
`araclar/el_kaldirma.py` dosya üzerinden zaten çalışır.

VERİ
----
Sunucu öğrenci kimliği TUTMAZ. Tuttuğu her şey şu: sınıf kodu, soru
metni, o soruda kaç kişinin takıldığı. İsim, numara, cihaz kimliği, IP
kaydı yok. Sızdırılacak bir şey olmasın diye böyle -- bkz.
TASARIM_NOTLARI §10.

YETKİ
-----
Öğrencinin yapabildiği tek şey bildiri göndermek; sınıf koduyla yapılır,
kod zaten tahtada yazılı.

Öğretmenin işleri (listeyi görmek, satır düşürmek, temizlemek) ayrı bir
anahtar ister. Anahtar sınıf açılırken üretilir ve YALNIZCA öğretmenin
ekranında görünür. Olmasaydı sınıftaki herkes listeyi okur, silerdi.

Bu anahtar bir parola değil, bir sınıf oturumunun kapı kolu. Kaybolursa
öğretmen YENİ bir sınıf kodu açar: var olan bir kodu başka bir anahtarla
yeniden açmak reddedilir. Reddedilmeseydi kodu bilen herkes -- yani bütün
sınıf -- öğretmenin yerine geçebilirdi (GOREVLER B36).
Ciddi bir kimlik doğrulaması gerekiyorsa
(okul çapında dağıtım) bu dosya o iş için yeterli değildir ve öyle
sunulmamalıdır.
"""
from __future__ import annotations

import io
import json
import os
import sys
import threading
import time
from urllib.parse import urlsplit
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Optional, Tuple

# Betik olarak calisinca (python araclar/sinif_sunucusu.py) proje koku yolda
# degildir; Telsiz suzgeci oyun/motor altinda oldugu icin eklenir.
_KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _KOK not in sys.path:
    sys.path.insert(0, _KOK)
try:
    from araclar import telsiz as _telsiz       # /telsiz/... uclari
except Exception:                               # noqa: BLE001
    # Suzgec yuklenemezse Telsiz KAPALI kalir (suzgecsiz mesajlasma olmaz);
    # el kaldirma ve sinif kodu etkilenmez.
    _telsiz = None

BAGLANTI_NOKTASI = 8710

# Ogretmen anahtari GET sorgusunda DEGIL bu basliktadir (sorgu dizesi
# vekil/erisim kayitlarina duz yazilir). Eski istemciler bir surum boyunca
# hala `?anahtar=` gonderebilir: kabul edilir, sunucu konsoluna uyari yazilir.
ANAHTAR_BASLIGI = "X-Ogretmen-Anahtari"
_SORGU_UYARISI_VERILDI = False

# Tarayicidan gelen isteklerde yalniz bu kokenler CORS izni alir. Her zaman
# izinli: bu makine (localhost/127.0.0.1 -- `main.py --web`) ve istegin
# gittigi Host ile ayni koken. Oyun baska bir adreste yayindaysa (yayin/) o
# adres `--koken https://oyun.okul.k12.tr` ile ya da MERIDYEN_SINIF_KOKENLER
# (virgulle ayrilmis) ile eklenir. Origin basligi olmayan istekler
# (tarayici disi istemciler) etkilenmez.
_IZINLI_KOKENLER = set()
_YEREL_ADLAR = ("localhost", "127.0.0.1", "::1")

# /kod ucunda bir istemci adresinden dakikada bu kadar BULUNAMAYAN kod
# denemesi olur; fazlasi 429 alir. Dogru kodu giren ogrenci sayilmaz.
KOD_DAKIKADA_AZAMI_YANLIS = 20
_KOD_YANLIS = {}
_SIMDI = time.time

# Bir sınıf bir dakikada en çok kaç bildiri gönderebilir. Otuz kişilik bir
# sınıfta herkesin aynı anda el kaldırması bile bunun altında kalır; üstü
# ya bir hata ya da bir oyun oynamadır. Sınır aşılınca istek sessizce
# yutulur -- öğrenciye hata göstermenin bir anlamı yok.
DAKIKADA_AZAMI_BILDIRI = 120

# Sunucunun bellekte tuttuğu sınıf sayısı. Sınırsız olsaydı rastgele kod
# üreten biri belleği şişirebilirdi.
AZAMI_SINIF = 500

_KILIT = threading.Lock()
_VERI: Dict[str, Dict[str, Any]] = {}
_DOSYA = ""


# --------------------------------------------------------------- kalıcılık
def _yukle() -> None:
    """Sunucu yeniden başlarsa açık sınıflar kaybolmasın."""
    global _VERI
    if not _DOSYA or not os.path.exists(_DOSYA):
        return
    try:
        with io.open(_DOSYA, encoding="utf-8") as d:
            _VERI = json.load(d)
    except (OSError, ValueError):
        _VERI = {}


def _kaydet() -> None:
    if not _DOSYA:
        return
    gecici = _DOSYA + ".tmp"
    try:
        with io.open(gecici, "w", encoding="utf-8") as d:
            json.dump(_VERI, d, ensure_ascii=False)
        os.replace(gecici, _DOSYA)
    except OSError:
        pass          # kalıcılık iyi olur, şart değil; ders durmamalı


def _sinif(kod: str, olustur: bool = False) -> Optional[Dict[str, Any]]:
    kod = (kod or "").strip().upper()
    if not kod:
        return None
    kayit = _VERI.get(kod)
    if kayit is None and olustur:
        if len(_VERI) >= AZAMI_SINIF:
            return None
        kayit = {"ad": "", "okul": "", "anahtar": "", "bekleyen": {},
                 "acilma": time.time(), "sayac": [0.0, 0]}
        _VERI[kod] = kayit
    return kayit


def kokenleri_ayarla(kokenler=()) -> None:
    """CORS'a izin verilen ek kokenleri belirler (ortam degiskeni dahil)."""
    ham = list(kokenler or []) + (os.environ.get("MERIDYEN_SINIF_KOKENLER") or "").split(",")
    _IZINLI_KOKENLER.clear()
    _IZINLI_KOKENLER.update(k.strip().rstrip("/").lower() for k in ham if k.strip())


def _koken_izinli(origin: str, host: str) -> bool:
    """Origin yoksa True (tarayici disi). Varsa izin listesinde olmali."""
    if not origin:
        return True
    parca = urlsplit(origin)
    if parca.scheme not in ("http", "https") or not parca.hostname:
        return False
    if origin.rstrip("/").lower() in _IZINLI_KOKENLER:
        return True
    return parca.hostname in _YEREL_ADLAR or (
        bool(host) and parca.netloc.lower() == host.strip().lower())


def _kod_hiz_asildi(istemci: str) -> bool:
    """Bu istemci adresi dakikada cok fazla yanlis sinif kodu denedi mi?"""
    simdi = _SIMDI()
    pencere, sayi = _KOD_YANLIS.get(istemci, (simdi, 0))
    if simdi - pencere > 60:
        return False
    return sayi >= KOD_DAKIKADA_AZAMI_YANLIS


def _kod_yanlis_say(istemci: str) -> None:
    simdi = _SIMDI()
    if len(_KOD_YANLIS) > 2000:                   # bellek sisemesin
        for a in [a for a, (p, _) in _KOD_YANLIS.items() if simdi - p > 60]:
            del _KOD_YANLIS[a]
        if len(_KOD_YANLIS) > 2000:
            _KOD_YANLIS.clear()
    pencere, sayi = _KOD_YANLIS.get(istemci, (simdi, 0))
    if simdi - pencere > 60:
        pencere, sayi = simdi, 0
    _KOD_YANLIS[istemci] = (pencere, sayi + 1)


# ------------------------------------------------------------------ işler
def sinif_ac(kod: str, ad: str, okul: str, anahtar: str) -> bool:
    """Öğretmen sınıfı sunucuya tanıtır. Anahtarı öğretmen belirler.

    VAR OLAN SINIF DEVRALINAMAZ. Sınıf kodu tahtada yazılı; ikinci bir
    açılış eski anahtarı sessizce ezseydi kodu bilen herkes öğretmenin
    listesini okuyup silebilir, asıl öğretmeni dışarıda bırakabilirdi
    (ChatGPT incelemesi, 11 Eylül 2026). Aynı anahtarla yeniden açmak
    serbest (ör. sunucu yeniden başladı); farklı anahtarla reddedilir.
    """
    with _KILIT:
        kayit = _sinif(kod, olustur=True)
        if kayit is None:
            return False
        if (kayit.get("anahtar") or "") and not _yetkili(kayit, anahtar):
            return False
        kayit["ad"] = (ad or "")[:60]
        kayit["okul"] = (okul or "")[:60]
        kayit["anahtar"] = anahtar or ""
        _kaydet()
    return True


def kod_dogrula(kod: str) -> Optional[Dict[str, Any]]:
    """Öğrenci kodu girdi: sınıf var mı? Anahtar DÖNMEZ."""
    with _KILIT:
        kayit = _sinif(kod)
        if kayit is None:
            return None
        return {"kod": kod.upper(), "ad": kayit["ad"], "okul": kayit["okul"]}


def _sayac_gecti(kayit: Dict[str, Any]) -> bool:
    """Dakikalık bildiri sınırı aşıldı mı?"""
    simdi = time.time()
    pencere, sayi = kayit.get("sayac", [0.0, 0])
    if simdi - pencere > 60:
        kayit["sayac"] = [simdi, 1]
        return False
    if sayi >= DAKIKADA_AZAMI_BILDIRI:
        return True
    kayit["sayac"] = [pencere, sayi + 1]
    return False


def el_kaldir(kod: str, konu: str, baslik: str) -> bool:
    with _KILIT:
        kayit = _sinif(kod)
        if kayit is None or _sayac_gecti(kayit):
            return False
        anahtar = "{}|{}".format((konu or "?").strip(),
                                 (baslik or "").strip())[:200]
        satir = kayit["bekleyen"].get(anahtar)
        if satir is None:
            satir = {"konu": (konu or "")[:80], "baslik": (baslik or "")[:200],
                     "sayi": 0, "ilk": time.time()}
            kayit["bekleyen"][anahtar] = satir
        satir["sayi"] += 1
        satir["son"] = time.time()
        # Öğretmenin yapabileceği kadar madde kalsın.
        if len(kayit["bekleyen"]) > 12:
            dusen = sorted(kayit["bekleyen"].items(),
                           key=lambda ç: (ç[1]["sayi"], ç[1]["son"]))
            for a, _ in dusen[:len(kayit["bekleyen"]) - 12]:
                if a != anahtar:
                    kayit["bekleyen"].pop(a, None)
        _kaydet()
    return True


def bekleyenler(kod: str, anahtar: str) -> Optional[list]:
    with _KILIT:
        kayit = _sinif(kod)
        if kayit is None or not _yetkili(kayit, anahtar):
            return None
        liste = [dict(s, anahtar=a) for a, s in kayit["bekleyen"].items()]
    liste.sort(key=lambda s: (-s["sayi"], -s.get("son", 0)))
    return liste


def anlatildi(kod: str, anahtar: str, satir_anahtari: str) -> bool:
    with _KILIT:
        kayit = _sinif(kod)
        if kayit is None or not _yetkili(kayit, anahtar):
            return False
        dustu = kayit["bekleyen"].pop(satir_anahtari, None) is not None
        _kaydet()
    return dustu


def temizle(kod: str, anahtar: str) -> bool:
    with _KILIT:
        kayit = _sinif(kod)
        if kayit is None or not _yetkili(kayit, anahtar):
            return False
        kayit["bekleyen"] = {}
        _kaydet()
    return True


def sinif_sil(kod: str, anahtar: str) -> bool:
    """Öğretmen sınıfı kapatır (yıl sonu, B36.16): sınıf sunucudan silinir.

    Sunucuda öğrenci verisi yok; giden sınıf adı, okul adı, anahtar ve
    anonim sayılar. Yetki yine anahtarla: kod tahtada yazılı, kodu bilen
    her öğrenci sınıfı kapatabilseydi el kaldırma bir derste yok edilirdi.
    """
    with _KILIT:
        kayit = _sinif(kod)
        if kayit is None or not _yetkili(kayit, anahtar):
            return False
        _VERI.pop((kod or "").strip().upper(), None)
        _kaydet()
    return True


def _yetkili(kayit: Dict[str, Any], anahtar: str) -> bool:
    beklenen = kayit.get("anahtar") or ""
    if not beklenen:
        return False
    # Sabit süreli karşılaştırma: anahtar tahmin edilirken harf harf
    # sızmasın. Küçük bir önlem ama bedeli de yok.
    import hmac
    return hmac.compare_digest(str(anahtar or ""), str(beklenen))


# ------------------------------------------------------------------- HTTP
class Istek(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "MeridyenSinif/1"
    timeout = 30             # yarim kalan istek is parcacigini sonsuza dek tutmasin

    def _koken(self) -> str:
        return self.headers.get("Origin") or ""

    def _yanitla(self, veri: Any, kod: int = 200) -> None:
        govde = json.dumps(veri, ensure_ascii=False).encode("utf-8")
        self.send_response(kod)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(govde)))
        # Oyun sayfası başka bir adreste duruyor; tarayıcı izin istiyor --
        # ama yalnız izinli kökene (bkz. _IZINLI_KOKENLER), herkese değil.
        koken = self._koken()
        if koken and _koken_izinli(koken, self.headers.get("Host") or ""):
            self.send_header("Access-Control-Allow-Origin", koken)
            self.send_header("Access-Control-Allow-Headers",
                             "Content-Type, " + ANAHTAR_BASLIGI)
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Vary", "Origin")
        uyari, self._uyari = getattr(self, "_uyari", ""), ""      # baglanti tekrar kullanilir
        if uyari:
            self.send_header("X-Meridyen-Uyari", uyari)
        self.end_headers()
        self.wfile.write(govde)

    def _koken_reddi(self) -> bool:
        """Tarayicidan gelen, izinli olmayan kokenli istege 403 yazar."""
        if _koken_izinli(self._koken(), self.headers.get("Host") or ""):
            return False
        self._yanitla({"tamam": False, "neden": "koken"}, 403)
        return True

    def _anahtari_al(self, sorgu: Dict[str, str]) -> None:
        """Ogretmen anahtarini basliktan `sorgu["anahtar"]`a tasir (yeni bicim).

        Baslik varsa o gecerlidir. Yoksa eski `?anahtar=` bicimi kabul edilir
        ama uyarilir (anahtar sorgu dizesinde vekil kayitlarina yazilir).
        """
        global _SORGU_UYARISI_VERILDI
        baslik = self.headers.get(ANAHTAR_BASLIGI)
        if baslik is not None:
            sorgu["anahtar"] = baslik
        elif "anahtar" in sorgu:
            self._uyari = "anahtar-sorguda-eski-bicim"
            if not _SORGU_UYARISI_VERILDI:
                _SORGU_UYARISI_VERILDI = True
                print("  UYARI: ogretmen anahtari GET sorgusunda geldi (eski istemci). "
                      "Yeni bicim: {} basligi. Eski bicim bir sonraki surumde kalkacak."
                      .format(ANAHTAR_BASLIGI), flush=True)

    def _govde(self) -> Dict[str, Any]:
        try:
            uzunluk = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return {}
        if uzunluk <= 0 or uzunluk > 8192:
            return {}
        try:
            return json.loads(self.rfile.read(uzunluk).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    def do_OPTIONS(self) -> None:            # noqa: N802
        if self._koken_reddi():
            return
        self._yanitla({"tamam": True})

    def _telsiz(self, yontem: str, yol: str, sorgu: Dict[str, str],
                govde: Dict[str, Any]) -> None:
        if _telsiz is None:
            self._yanitla({"tamam": False, "neden": "telsiz_kapali"}, 404)
            return
        kod, cikti = _telsiz.dispatch(sys.modules[__name__], yontem, yol, sorgu, govde)
        self._yanitla(cikti, kod)

    def _bekleyen(self, kod: str, anahtar: str) -> None:
        liste = bekleyenler(kod, anahtar)
        if liste is None:
            self._yanitla({"tamam": False}, 403)
        else:
            self._yanitla({"tamam": True, "bekleyen": liste})

    def do_GET(self) -> None:                # noqa: N802
        yol, sorgu = _yolu_ayir(self.path)
        self._anahtari_al(sorgu)
        if yol.startswith("/telsiz/"):
            self._telsiz("GET", yol, sorgu, {})
        elif yol == "/durum":
            self._yanitla({"tamam": True, "surum": 1})
        elif yol == "/kod":
            istemci = self.client_address[0]
            if _kod_hiz_asildi(istemci):
                self._yanitla({"tamam": False, "neden": "cok_deneme"}, 429)
                return
            bulunan = kod_dogrula(sorgu.get("kod", ""))
            if not bulunan:
                _kod_yanlis_say(istemci)
            self._yanitla(bulunan or {"tamam": False}, 200 if bulunan else 404)
        elif yol == "/bekleyen":
            self._bekleyen(sorgu.get("kod", ""), sorgu.get("anahtar", ""))
        else:
            self._yanitla({"tamam": False}, 404)

    def do_POST(self) -> None:               # noqa: N802
        if self._koken_reddi():
            return
        yol, _ = _yolu_ayir(self.path)
        veri = self._govde()
        self._anahtari_al(veri)
        if yol.startswith("/telsiz/"):
            self._telsiz("POST", yol, {}, veri)
        elif yol == "/bekleyen":
            self._bekleyen(veri.get("kod", ""), veri.get("anahtar", ""))
        elif yol == "/sinif":
            ok = sinif_ac(veri.get("kod", ""), veri.get("ad", ""),
                          veri.get("okul", ""), veri.get("anahtar", ""))
            # Ret de 200 ile doner. Ag katmani 2xx disini None yapiyor
            # (telefonda da); 400 donseydik istemci "reddedildi"yi "ag yok"
            # sanir ve sinifi sessizce yalnizca yerelde acardi (B36.19).
            self._yanitla({"tamam": ok})
        elif yol == "/el":
            ok = el_kaldir(veri.get("kod", ""), veri.get("konu", ""),
                           veri.get("baslik", ""))
            # Sınır aşıldığında da 200 dönüyoruz: öğrenciye "çok istek"
            # demenin bir karşılığı yok, üstelik sınırı keşfetmeye davet eder.
            self._yanitla({"tamam": ok})
        elif yol == "/anlatildi":
            ok = anlatildi(veri.get("kod", ""), veri.get("anahtar", ""),
                           veri.get("satir", ""))
            self._yanitla({"tamam": ok}, 200 if ok else 403)
        elif yol == "/temizle":
            ok = temizle(veri.get("kod", ""), veri.get("anahtar", ""))
            self._yanitla({"tamam": ok}, 200 if ok else 403)
        elif yol == "/sinif_sil":
            ok = sinif_sil(veri.get("kod", ""), veri.get("anahtar", ""))
            # Ret de 200 (bkz. /sinif): istemci "reddedildi" ile "ağ yok"u
            # ayırabilsin; öğretmene doğru cümle söylenecek.
            self._yanitla({"tamam": ok})
        else:
            self._yanitla({"tamam": False}, 404)

    def log_message(self, bicim, *args):     # noqa: A002
        # Sessiz: erişim kaydı tutmak IP toplamaktır, tutmuyoruz.
        pass


def _yolu_ayir(ham: str) -> Tuple[str, Dict[str, str]]:
    from urllib.parse import parse_qs, urlparse
    bolum = urlparse(ham)
    sorgu = {a: (d[0] if d else "") for a, d in parse_qs(bolum.query).items()}
    return bolum.path.rstrip("/") or "/", sorgu


def sunucu_kur(baglanti_noktasi: int = BAGLANTI_NOKTASI,
               dosya: str = "", kokenler=()) -> ThreadingHTTPServer:
    global _DOSYA
    _DOSYA = dosya
    _yukle()
    kokenleri_ayarla(kokenler)
    ThreadingHTTPServer.allow_reuse_address = True
    return ThreadingHTTPServer(("0.0.0.0", baglanti_noktasi), Istek)


def main() -> int:
    kok = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    dosya = os.path.join(kok, "kayitlar", "sinif_sunucusu.json")
    os.makedirs(os.path.dirname(dosya), exist_ok=True)
    nokta = BAGLANTI_NOKTASI
    kokenler = []
    argumanlar = sys.argv[1:]
    while argumanlar:
        arg = argumanlar.pop(0)
        if arg.isdecimal():
            nokta = int(arg)
        elif arg == "--koken" and argumanlar:
            kokenler.append(argumanlar.pop(0))
    sunucu = sunucu_kur(nokta, dosya, kokenler)
    print("=" * 60)
    print("  Meridyen Seferi - sınıf sunucusu")
    print("=" * 60)
    print("  Dinlenen kapı : {}".format(nokta))
    print("  Veri dosyası  : {}".format(dosya))
    print()
    print("  Bu sunucu OYUNU ÇALIŞTIRMAZ. Oyun telefonda çalışır.")
    print("  Buradaki tek iş: sınıf kodunu doğrulamak ve el kaldırma")
    print("  bildirilerini SAYMAK. Öğrenci adı tutulmaz.")
    print("  Telsiz (mesajlaşma): {}.".format(
        "AÇIK (süzgeçli, öğretmen denetimli)" if _telsiz else "KAPALI (süzgeç yüklenemedi)"))
    print()
    print("  Öğrenciler kendi hücresel verileriyle bağlanacaksa bu")
    print("  adresin dışarıdan erişilebilir olması gerekir.")
    print("  Oyun başka bir adreste yayındaysa o adresi tarayıcıya tanıt:")
    print("    python araclar/sinif_sunucusu.py 8710 --koken https://oyun.okul.k12.tr")
    print("  Durdurmak için Ctrl+C.")
    print("=" * 60)
    try:
        sunucu.serve_forever()
    except KeyboardInterrupt:
        print()
    finally:
        sunucu.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
