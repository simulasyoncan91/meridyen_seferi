# -*- coding: utf-8 -*-
"""
Terminal katmanı.

Tek işi var: metni ekrana *güvenle* basmak. Windows konsolu varsayılan olarak
cp1254 kullanır; kutu çizgileri ve tipografik tire gibi karakterler orada
çökme (UnicodeEncodeError) üretir. Burası önce konsolu UTF-8'e çekmeyi dener,
beceremezse ASCII yedek karakter setine düşer. Böylece oyun her makinede açılır.
"""
from __future__ import annotations

import os
import shutil
import sys
import textwrap
import time

# --------------------------------------------------------------------------
# Konsol hazırlığı
# --------------------------------------------------------------------------

_ANSI_ACIK = False


def _konsolu_hazirla() -> None:
    """Windows'ta UTF-8 kod sayfasını ve ANSI renk desteğini açmayı dener."""
    global _ANSI_ACIK

    if os.name == "nt":
        try:
            import ctypes

            cekirdek = ctypes.windll.kernel32
            cekirdek.SetConsoleOutputCP(65001)
            cekirdek.SetConsoleCP(65001)
            tutamac = cekirdek.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
            kip = ctypes.c_uint32()
            if cekirdek.GetConsoleMode(tutamac, ctypes.byref(kip)):
                # ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
                cekirdek.SetConsoleMode(tutamac, kip.value | 0x0004)
                _ANSI_ACIK = True
        except Exception:
            pass
    else:
        _ANSI_ACIK = True

    # Ne olursa olsun çökmeyelim: errors="replace" son emniyet kemeri.
    for akis in (sys.stdout, sys.stderr):
        try:
            akis.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass

    if os.environ.get("NO_COLOR") is not None:
        _ANSI_ACIK = False
    elif os.environ.get("PYCHARM_HOSTED") == "1":
        _ANSI_ACIK = True
    elif not sys.stdout.isatty():
        _ANSI_ACIK = False


def _kodlanabilir(ornek: str) -> bool:
    kodlama = getattr(sys.stdout, "encoding", None) or "ascii"
    try:
        ornek.encode(kodlama)
        return True
    except Exception:
        return False


_konsolu_hazirla()
ZENGIN = _kodlanabilir("─│┌┐└┘•→✔")

# --------------------------------------------------------------------------
# Karakter setleri
# --------------------------------------------------------------------------

_ZENGIN_SET = {
    "yatay": "─", "dikey": "│",
    "sol_ust": "┌", "sag_ust": "┐", "sol_alt": "└", "sag_alt": "┘",
    "kalin_yatay": "━",
    "madde": "•", "ok": "→", "onay": "✔", "carpi": "✘",
    "dolu": "█", "bos": "░", "yildiz": "★", "bos_yildiz": "☆",
}
_SADE_SET = {
    "yatay": "-", "dikey": "|",
    "sol_ust": "+", "sag_ust": "+", "sol_alt": "+", "sag_alt": "+",
    "kalin_yatay": "=",
    "madde": "*", "ok": ">", "onay": "[+]", "carpi": "[x]",
    "dolu": "#", "bos": ".", "yildiz": "*", "bos_yildiz": "-",
}
S = _ZENGIN_SET if ZENGIN else _SADE_SET

RENKLER = {
    "sifirla": "\033[0m", "kalin": "\033[1m", "soluk": "\033[2m",
    "kirmizi": "\033[31m", "yesil": "\033[32m", "sari": "\033[33m",
    "mavi": "\033[34m", "mor": "\033[35m", "camgobegi": "\033[36m",
    "beyaz": "\033[37m", "gri": "\033[90m",
    "acik_yesil": "\033[92m", "acik_sari": "\033[93m", "acik_mavi": "\033[94m",
    "acik_mor": "\033[95m", "acik_cam": "\033[96m",
}

# Hangi alanın hangi rengi kullandığı burada değil, modeller.ALAN_TANIMLARI
# içindedir: yeni bir ders eklerken tek bir tabloya bakmak yeter. Bu dosya
# yalnızca renklerin kendisini (RENKLER) tanır.


def renkli(metin: str, *renk_adlari: str) -> str:
    if not _ANSI_ACIK or not renk_adlari:
        return metin
    on = "".join(RENKLER.get(ad, "") for ad in renk_adlari)
    if not on:
        return metin
    return on + metin + RENKLER["sifirla"]


def gorunur_uzunluk(metin: str) -> int:
    """ANSI kodlarını saymadan gerçek karakter sayısı."""
    uzunluk, i = 0, 0
    while i < len(metin):
        if metin[i] == "\033":
            while i < len(metin) and metin[i] != "m":
                i += 1
            i += 1
            continue
        uzunluk += 1
        i += 1
    return uzunluk


# --------------------------------------------------------------------------
# Genişlik ve yazım
# --------------------------------------------------------------------------

# Telefon icin dusuruldu. 54 terminal icin secilmis bir tabandi; 375 px
# ekranda 14 px tek aralikli yazi ~41 karakter sigdiriyor, yani 54 istemek
# kutulari tasiriyor ve satirlar sarip cizimi bozuyordu (8 Eylul, gercek
# telefon boyutunda ekran goruntusuyle gorüldü). Kabuk kendi olcusunu
# bildiriyor; taban yalnizca ona guvenilemeyen durumlar icin.
EN_AZ_GENISLIK = 32
EN_COK_GENISLIK = 92


def genislik() -> int:
    """Satir genisligi. Once KABUGA sorulur.

    Eskiden yalnizca `shutil.get_terminal_size()` kullaniliyordu ve
    varsayilani 80 idi. Telefonda bu yanlis: 375 px ekranda 76
    karakterlik bir kutu tasar ve okunmaz hale gelir. Genisligi bilen
    tek yer kabuktur -- terminal kendi boyutunu bilir, tarayici kendi
    ekranini. Bu yuzden once ona soruluyor.
    """
    kabuk_genislik = getattr(_KABUK, "genislik", None)
    if kabuk_genislik:
        try:
            return max(EN_AZ_GENISLIK,
                       min(EN_COK_GENISLIK, int(kabuk_genislik())))
        except Exception:          # noqa: BLE001 - kabuk bozuksa terminale dus
            pass
    try:
        sutun = shutil.get_terminal_size(fallback=(80, 24)).columns
    except Exception:              # noqa: BLE001
        sutun = 80
    return max(EN_AZ_GENISLIK, min(EN_COK_GENISLIK, sutun - 2))


_YAZIM_HIZI = 0.0  # 0 => anında bas. Ayarlardan değiştirilebilir.


def yazim_hizi_ayarla(saniye: float) -> None:
    global _YAZIM_HIZI
    _YAZIM_HIZI = max(0.0, min(0.05, saniye))


def yazim_hizi() -> float:
    return _YAZIM_HIZI


# --------------------------------------------------------------------------
# Kabuk katmani
# --------------------------------------------------------------------------
#
# NEDEN VAR: TASARIM_NOTLARI §8 "motor kalir, kabuk degisir" diyor. Oyunun
# butun cikti ve girdisi bu dosyadan gecer ve disariya acilan yuzey yalnizca
# 16 fonksiyon. Cikti/girdi TEK NOKTADAN (_bas, _oku, temizle) gectigi icin
# oraya takilabilir bir kabuk konursa, oyun kendini terminalde sanmaya devam
# ederken ekran baska bir yere gidebilir.
#
# Mobil icin en ucuz yol bu: oturum.py (998 satir) ve oyun.py (1526 satir)
# HIC DEGISMEDEN telefonda calisabilir. §8 "oturum.py'yi olay tabanliya
# cevir" diyor; o duyarli bir web uygulamasi icin dogru ama "telefondan
# oynanabilsin" icin gerekli degil.
#
# Varsayilan kabuk bugunku davranistir. Kabuk degistirilmezse hicbir sey
# degismez.


class MetinKabugu:
    """Varsayilan kabuk: dogrudan konsola yazar, konsoldan okur."""

    yazim_hizi_destekli = True

    def bas(self, satir):
        print(satir)

    def oku(self, istem):
        return input(istem)

    def temizle(self):
        # Karar KABUGUN. Eskiden `temizle()` icinde `sys.stdout.isatty()`
        # sorulyordu; ozel bir kabukta stdout zaten cikti degil, o yuzden
        # o kontrol yanlis yerdeydi ve mobil kabukta ekran hic
        # temizlenmezdi. Test yakaladi.
        if os.environ.get("OYUN_TEMIZLEME") == "0" or not sys.stdout.isatty():
            return False          # temizlenemedi; cagiran ayrac cizsin
        try:
            os.system("cls" if os.name == "nt" else "clear")
        except Exception:          # noqa: BLE001
            return False
        return True


_KABUK = MetinKabugu()


def kabuk_ata(yeni_kabuk):
    """Cikti/girdi kabugunu degistirir. Mobil kabuk buradan takilir."""
    global _KABUK
    _KABUK = yeni_kabuk


def kabuk():
    return _KABUK


def _bas(satir: str) -> None:
    if _YAZIM_HIZI > 0 and getattr(_KABUK, "yazim_hizi_destekli", False):
        for harf in satir:
            sys.stdout.write(harf)
            sys.stdout.flush()
            if harf not in " \t":
                time.sleep(_YAZIM_HIZI)
        sys.stdout.write("\n")
        sys.stdout.flush()
    else:
        _KABUK.bas(satir)


def yaz(metin: str = "", *renk_adlari: str, sar: bool = True, girinti: str = "") -> None:
    """Metni satır genişliğine sararak basar."""
    if metin == "":
        _KABUK.bas("")
        return
    if sar:
        satirlar = []
        for parca in metin.split("\n"):
            if not parca.strip():
                satirlar.append("")
                continue
            sarilmis = textwrap.wrap(
                parca,
                width=max(20, genislik() - len(girinti)),
                break_long_words=False,
                break_on_hyphens=False,
            )
            satirlar.extend(sarilmis or [""])
    else:
        satirlar = metin.split("\n")

    for satir in satirlar:
        _bas(girinti + renkli(satir, *renk_adlari))


def ham_yaz(satir: str = "") -> None:
    """Sarmadan, girintisiz, oldugu gibi basar.

    Hizalanmis durum cubuklari icin var (ust pano, kanit listesi): oralarda
    metin elle hizalaniyor ve `yaz()`in satir sarmasi hizayi bozar.
    Dogrudan `print` KULLANILMAMALI -- kabugu atlar ve mobilde ekrana hic
    ulasmaz (bkz. kabuk katmani).
    """
    _KABUK.bas(satir)


def ayrac(karakter: str = "", *renk_adlari: str) -> None:
    karakter = karakter or S["yatay"]
    _KABUK.bas(renkli(karakter * genislik(), *(renk_adlari or ("gri",))))


def baslik(metin: str, *renk_adlari: str) -> None:
    """Üstte çerçeveli başlık."""
    g = genislik()
    ic = g - 2
    renk_adlari = renk_adlari or ("kalin", "acik_cam")
    _KABUK.bas(renkli(S["sol_ust"] + S["yatay"] * ic + S["sag_ust"], "gri"))
    for satir in textwrap.wrap(metin, width=ic - 2) or [""]:
        bosluk = ic - 2 - len(satir)
        sol = bosluk // 2
        sag = bosluk - sol
        _KABUK.bas(
            renkli(S["dikey"], "gri") + " " * (sol + 1)
            + renkli(satir, *renk_adlari) + " " * (sag + 1)
            + renkli(S["dikey"], "gri")
        )
    _KABUK.bas(renkli(S["sol_alt"] + S["yatay"] * ic + S["sag_alt"], "gri"))


def kutu(metin: str, etiket: str = "", *renk_adlari: str) -> None:
    """Metni çerçeve içinde basar. Uzun anlatı blokları için."""
    g = genislik()
    ic = g - 4
    if etiket:
        etiketli = S["sol_ust"] + S["yatay"] + " " + etiket + " "
        kalan = g - len(etiketli) - 1
        ust = etiketli + S["yatay"] * max(0, kalan) + S["sag_ust"]
    else:
        ust = S["sol_ust"] + S["yatay"] * (g - 2) + S["sag_ust"]
    _KABUK.bas(renkli(ust, "gri"))
    for ham in metin.split("\n"):
        parcalar = textwrap.wrap(ham, width=ic, break_long_words=False) if ham.strip() else [""]
        for satir in parcalar:
            dolgu = " " * max(0, ic - gorunur_uzunluk(satir))
            _bas(
                renkli(S["dikey"], "gri") + " " + renkli(satir, *renk_adlari)
                + dolgu + " " + renkli(S["dikey"], "gri")
            )
    _KABUK.bas(renkli(S["sol_alt"] + S["yatay"] * (g - 2) + S["sag_alt"], "gri"))


def madde(metin: str, *renk_adlari: str, isaret: str = "") -> None:
    isaret = isaret or S["madde"]
    yaz(isaret + " " + metin, *renk_adlari, girinti="   ")


def asili_yaz(onek: str, metin: str, *renk_adlari: str, onek_renkleri=()) -> None:
    """
    Asılı girintili yazım: ilk satır önekle başlar, devam satırları önek
    genişliği kadar içeriden hizalanır. Uzun şıkların okunaklı kalması için.
    """
    onek_uzunlugu = gorunur_uzunluk(onek)
    kalan = max(20, genislik() - onek_uzunlugu)
    satirlar = textwrap.wrap(metin, width=kalan, break_long_words=False,
                             break_on_hyphens=False) or [""]
    boyali_onek = renkli(onek, *onek_renkleri) if onek_renkleri else onek
    _bas(boyali_onek + renkli(satirlar[0], *renk_adlari))
    for satir in satirlar[1:]:
        _bas(" " * onek_uzunlugu + renkli(satir, *renk_adlari))


_TR_KUCUK_BUYUK = str.maketrans({"i": "İ", "ı": "I", "ş": "Ş", "ğ": "Ğ",
                                 "ü": "Ü", "ö": "Ö", "ç": "Ç"})


def tr_buyuk(metin: str) -> str:
    """
    Türkçe kurallarına göre büyük harfe çevirir.

    Python'un upper() metodu "i" harfini "I" yapar; Türkçede doğrusu "İ"dir.
    Başlıkta "İki İstasyon" yazan bir görev, upper() ile "İKI İSTASYON" olur.
    """
    return metin.translate(_TR_KUCUK_BUYUK).upper()


def basari(metin: str) -> None:
    yaz(S["onay"] + " " + metin, "acik_yesil", "kalin")


def hata(metin: str) -> None:
    yaz(S["carpi"] + " " + metin, "kirmizi")


def bilgi(metin: str) -> None:
    yaz(S["ok"] + " " + metin, "acik_sari")


def cubuk(deger: float, azami: float, uzunluk: int = 18) -> str:
    """Metinsel ilerleme çubuğu."""
    oran = 0.0 if azami <= 0 else max(0.0, min(1.0, float(deger) / float(azami)))
    dolu = int(round(oran * uzunluk))
    return S["dolu"] * dolu + S["bos"] * (uzunluk - dolu)


def yildizlar(sayi: int, azami: int = 3) -> str:
    sayi = max(0, min(azami, int(sayi)))
    return S["yildiz"] * sayi + S["bos_yildiz"] * (azami - sayi)


def temizle() -> None:
    """Ekrani temizler. Temizleyemezse gorsel bir ayrac cizer."""
    if _KABUK.temizle():
        return
    _KABUK.bas("")
    ayrac(S["kalin_yatay"])


# --------------------------------------------------------------------------
# Girdi
# --------------------------------------------------------------------------

class OyunuBirak(Exception):
    """Oyuncu her yerden çıkabilsin diye kullanılan kontrol istisnası."""


def _oku(istem: str) -> str:
    try:
        return _KABUK.oku(istem)
    except (EOFError, KeyboardInterrupt):
        _KABUK.bas("")
        raise OyunuBirak()


def sor(istem: str = "", varsayilan: str = "") -> str:
    ok = renkli(S["ok"], "acik_cam", "kalin")
    cevap = _oku("\n" + ok + " " + istem + " ").strip()
    if not cevap and varsayilan:
        return varsayilan
    return cevap


def bekle(istem: str = "Devam etmek için Enter...") -> None:
    _oku("\n" + renkli("   " + istem, "gri"))


def onayla(istem: str, varsayilan: bool = True) -> bool:
    ipucu = "[E/h]" if varsayilan else "[e/H]"
    while True:
        cevap = sor(istem + " " + ipucu).lower()
        if not cevap:
            return varsayilan
        if cevap[0] in "ey1":
            return True
        if cevap[0] in "hn0":
            return False


def menu(baslik_metni: str, secenekler, ipucu: str = "") -> int:
    """
    Numaralı menü gösterir, seçilen öğenin indeksini döndürür.
    'secenekler' bir dizi metin ya da (metin, açıklama) çiftidir.
    """
    if baslik_metni:
        yaz()
        yaz(baslik_metni, "kalin", "acik_cam")
    for sira, oge in enumerate(secenekler, start=1):
        if isinstance(oge, (tuple, list)):
            metin, aciklama = oge[0], oge[1]
        else:
            metin, aciklama = oge, ""
        numara = renkli("[{}]".format(sira), "acik_sari", "kalin")
        _KABUK.bas("  " + numara + " " + metin)
        if aciklama:
            yaz(aciklama, "gri", girinti="      ")
    if ipucu:
        yaz(ipucu, "gri", girinti="  ")
    while True:
        cevap = sor("Seçim:")
        # isdigit() DEGIL isdecimal(). Fark oldurucu: "²" (ustsimge iki)
        # icin isdigit() True doner ama int() ValueError atar. Bagimsiz bir
        # oyun testi (8 Eylul 2026) bunu buldu -- herhangi bir menude "²"
        # yazmak oyunu cokertiyordu ve BU FONKSIYONU HER MENU KULLANIYOR.
        # Ayni kalip degerlendirme.py, oturum.py ve rapor.py'de de vardi.
        if cevap.isdecimal() and 1 <= int(cevap) <= len(secenekler):
            return int(cevap) - 1
        hata("1 ile {} arasında bir sayı gir.".format(len(secenekler)))
