# -*- coding: utf-8 -*-
"""
Coğrafya lise görevleri (9-12. sınıf) -- MEB konu haritasındaki içerik boşları.

Bu dosyadaki görevlerin hiçbiri gerçek bir Türkiye istatistiği kullanmaz:
sayılar üssün kurgusundan gelir ve tohumla değişir. Gerçek veri kullanılacaksa
yıl ve kaynak metinde yazılmalıdır (ICERIK_EKLEME.md).

Her görevin bir YANILGISI var; yanlış şıklar o yanılgının farklı yüzleridir ve
her şık "sonuç, çünkü gerekçe" biçiminde yazılır (şık sızıntısı denetimi:
doğru şık uzunluk ya da ek bakımından ayrışmamalı).
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi, secim_adimi, sy,
)


# ==========================================================================
# NÜFUS PROJEKSİYONU: KOŞULLU HESAP, KESİN TAHMİN DEĞİL
#
# Satır (11. sınıf): "Nüfus artışının her koşulda aynı sonucu verdiğini
# sanmak; projeksiyonu kesin gelecek saymak."
# Bir yıllık nüfus = başlangıç + doğum - ölüm + gelen göç - giden göç.
# Teşhis sayıları: göçü unutan, giden göçü unutan, senaryo A'yı B diye yazan;
# net göç hep > 0 olduğundan üçü de doğru cevaptan ve birbirinden farklıdır.
# ==========================================================================

_NUFUS_USLERI = ("Gökdere", "Akliman", "Taşocağı", "Demirkapı")
_GOC_KESILMELERI = (
    "cevher ocağı kapanırsa",
    "yeni sera kurulmazsa",
    "liman işleri azalırsa",
)


@bulmaca(ders="cografya", konu="nufus_projeksiyonu", kademeler=(10, 13), agirlik=1.3)
def nufus_senaryolari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Projeksiyon varsayıma bağlıdır; göç varsayımı değişince sonuç da değişir."""
    us = rastgele.choice(_NUFUS_USLERI)
    kesilme = rastgele.choice(_GOC_KESILMELERI)
    nufus = rastgele.randrange(24, 49) * 100
    dogum = rastgele.randrange(60, 111)
    olum = rastgele.randrange(20, 56)
    gelen = rastgele.randrange(80, 161)
    giden = rastgele.randrange(30, 71)
    net_goc = gelen - giden
    a_sonuc = nufus + dogum - olum + gelen - giden
    b_sonuc = nufus + dogum - olum - giden
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    ilk_ort = rastgele.choice((5, 10))

    return Bulmaca(
        kod="cog-nufus-senaryolari",
        ders="cografya",
        baslik="Nüfus Senaryoları",
        kademe=kademe,
        konu="nufus_projeksiyonu",
        kazanim="Nüfus değişimini doğum, ölüm ve göçle hesaplama; projeksiyonu "
                "varsayıma bağlı koşullu hesap olarak okuma; göç varsayımı "
                "değişince sonucun değiştiğini gerekçelendirme.",
        dikkat=7,
        brifing=(
            "{} üssünün konut planı için gelecek nüfus isteniyor.\n\n"
            "{} defterin son satırına bakıp yazdı: \"Geçen yıl nüfus arttı, "
            "demek ki her yıl aynı hızla artacak. {} yıl sonrasını kesin "
            "olarak yazalım, plan buna göre yapılsın.\"\n\n"
            "Rakam kurula gitmeden önce defterin ayrıntısına bakmamız "
            "gerekiyor."
        ).format(us, kisi, ilk_ort),
        kanitlar=[
            Kanit("Son yılın nüfus defteri",
                  "{} üssünde yıl başında nüfus {} kişiydi.\n"
                  "Doğum: {} kişi. Ölüm: {} kişi.\n"
                  "Gelen göç: {} kişi. Giden göç: {} kişi."
                  .format(us, nufus, dogum, olum, gelen, giden),
                  bedel=2, kritik=True),
            Kanit("Göç notu",
                  "Gelen göçün kaynağı iş fırsatıdır; {} gelen göç durur, "
                  "giden göç ise aynı kalır.".format(kesilme),
                  bedel=1, kritik=True),
            Kanit("Nüfus el kitabı",
                  "Nüfus değişimi doğum, ölüm ve göçle olur. Yıl sonu nüfusu = "
                  "yıl başı nüfusu + doğum - ölüm + gelen göç - giden göç. "
                  "Projeksiyon, bu bileşenler için yapılan varsayımlarla "
                  "kurulan koşullu bir hesaptır: varsayım değişirse sonuç da "
                  "değişir. Birkaç senaryo kurulur; hiçbiri kesin gelecek "
                  "değildir.",
                  bedel=1, kritik=True),
            Kanit("Planlama tutanağı",
                  "Konut sayısı gelecek nüfusa göre belirlenecek; nüfus "
                  "yazarken hangi varsayıma dayanıldığı da yazılacak.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Nüfus projeksiyonu nasıl bir hesaptır?",
                dogru="Koşullu bir hesaptır, çünkü doğum, ölüm ve göç "
                      "varsayımı değişince sonuç değişir",
                yanlislar={
                    "Kesin bir tahmindir, çünkü geçen yılın artışı her yıl "
                    "aynen tekrarlanır ve varsayıma gerek kalmaz":
                        "Geçmiş artışı kesin geleceğe çevirdin. Projeksiyon "
                        "varsayımlara bağlıdır; varsayım değişirse sonuç da "
                        "değişir.",
                    "Yalnız doğuma bağlıdır, çünkü nüfusu artıran tek etken "
                    "yeni doğan bebeklerdir":
                        "Ölüm ve göç de nüfusu değiştirir; defterde gelen ve "
                        "giden göç ayrı satırlarda yazılı.",
                    "Göçü hesaba katmaz, çünkü göç nüfusa kalıcı bir ekleme "
                    "sayılmaz, geçici bir hareket sayılır":
                        "Göç nüfus değişiminin üç bileşeninden biridir; el "
                        "kitabı formülünde gelen ve giden göç yer alıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Projeksiyon, bileşenlere (doğum, ölüm, göç) konan "
                    "varsayımlarla kurulur. Varsayım değişince sonuç değişir; "
                    "bu yüzden senaryo kurulur, kesin gelecek yazılmaz."
                ),
                ipuclari=[
                    "Hava tahmini gibi düşün: rüzgârın yönü değişirse tahmin de değişir.",
                    "El kitabı projeksiyonu nasıl tanımlıyor?",
                ],
                cozum="Projeksiyon = varsayima bagli kosullu hesap; kesin gelecek degil",
            ),
            sayi_adimi(
                soru="Senaryo A: her şey defterdeki gibi sürerse bir yıl sonra "
                     "{} üssünün nüfusu kaç kişi olur?".format(us),
                cevap=a_sonuc,
                birim="kişi",
                aciklama=("{} + {} - {} + {} - {} = {}. Net göç {} kişi artı, "
                          "doğal artış {} kişi.").format(
                    nufus, dogum, olum, gelen, giden, a_sonuc, net_goc,
                    dogum - olum),
                yaygin_yanlislar={
                    nufus + dogum - olum:
                        "Göçü hiç hesaba katmadın; defterde gelen ve giden göç "
                        "ayrı satırlarda yazılı.",
                    nufus + dogum - olum + gelen:
                        "Gelen göçü ekledin ama giden göçü çıkarmayı unuttun; "
                        "net göç, gelenden gidenin farkıdır.",
                },
                ipuclari=[
                    "Küveti düşün: musluk doğum ve gelen göç, tıkaç ölüm ve giden göçtür.",
                    "Başlangıca ekleyeceklerini ve çıkaracaklarını ayrı ayrı yaz.",
                ],
                puan=14,
                cozum="baslangic + dogum - olum + gelen - giden",
            ),
            sayi_adimi(
                soru="Senaryo B: {} gelen göç durur, giden göç aynı kalırsa bir yıl "
                     "sonra nüfus kaç kişi olur?".format(kesilme),
                cevap=b_sonuc,
                birim="kişi",
                aciklama=("Gelen göç sıfır: {} + {} - {} - {} = {}. Aynı üste "
                          "iki senaryo, {} kişi fark.").format(
                    nufus, dogum, olum, giden, b_sonuc, a_sonuc - b_sonuc),
                yaygin_yanlislar={
                    a_sonuc:
                        "Senaryo A'nın sonucunu yazdın; bu senaryoda gelen göç "
                        "sıfır, o satırı çıkarman gerekiyor.",
                    nufus + dogum - olum:
                        "Giden göçü de sildin; yalnız gelen göç durdu, giden "
                        "göç aynı kaldı.",
                },
                ipuclari=["Gelen göç satırı sıfır olunca formülün geri kalanı değişmez."],
                puan=14,
                cozum="baslangic + dogum - olum - giden",
            ),
            secim_adimi(
                soru="İki senaryonun sonucu farklı çıktı. Kurula nüfus nasıl yazılmalı?",
                dogru="İki sonuç da varsayımıyla yazılır, çünkü hangisinin "
                      "gerçekleşeceği göç kararlarına bağlıdır",
                yanlislar={
                    "Büyük olan sonuç yazılır, çünkü planlamada en iyimser "
                    "senaryo her zaman doğru çıkar, plan ona göre kurulur":
                        "Senaryolardan birini seçmek varsayımı gizler. İyimser "
                        "senaryo da bir varsayımdır, garanti değil.",
                    "Senaryolardan biri hatalıdır, çünkü doğru hesapta iki "
                    "farklı sonuç çıkmaz":
                        "İkisi de doğru hesaplandı; fark, göç varsayımından "
                        "geliyor. Hata yok, varsayım farkı var.",
                    "İkisinin ortalaması yazılır, çünkü ortalama iki varsayımı "
                    "da aynı oranda karşılar ve tek rakam verir":
                        "Ortalama ne A'yı ne B'yi anlatır; hangi varsayıma "
                        "dayandığı belli olmayan bir sayı üretir.",
                },
                rastgele=rastgele,
                aciklama=("Konut planı için iki senaryo, {} ve {} kişi, "
                          "varsayımlarıyla birlikte yazılır; plan bu aralığa "
                          "göre esnek kurulur.").format(b_sonuc, a_sonuc),
                ipuclari=["Sonuçların neden farklı çıktığına bak: hangi satır değişti?"],
                puan=12,
            ),
        ],
        kapanis=("Kurula tek rakam yerine iki senaryo gitti: {} ve {} kişi, "
                 "göç varsayımlarıyla birlikte. Konut planı bu aralığa göre "
                 "yapıldı.").format(b_sonuc, a_sonuc),
        odul={"itibar": 5, "erzak": 1},
    )


# ==========================================================================
# ŞEHİR İŞLEVLERİ VE ETKİ ALANI
#
# Satır (11. sınıf): "Bir şehrin tek işlevi olduğunu sanmak; nüfus büyüklüğü
# ile etki alanını eşitlemek."
# Üç yerleşim: biri en kalabalık ama tek işlevli (az köye hizmet veriyor), biri
# küçük ama çok işlevli (geniş etki alanı), biri orta. Etki alanı = hizmet
# verilen köy sayısı; aralıklar ayrık olduğundan sıralama her tohumda aynıdır
# (nüfus sıralaması ile etki sıralaması ters).
# ==========================================================================

_MERKEZ_ISLEVLERI = (
    # (işlev, hizmet mi)
    ("revir ve sağlık hizmeti", True),
    ("haftalık pazar ve ticaret", True),
    ("okul ve okuma kursu", True),
    ("nakliye ve konaklama", True),
    ("cevher çıkarma", False),
    ("kereste üretimi", False),
    ("tuz üretimi", False),
)
_YERLESIM_ADLARI = ("Karataş", "Akpınar", "Yelkaya", "Çamdibi", "Susuzkuyu",
                    "Boğazderesi", "Kızılyar", "Serinova", "Taşköprü", "Gökbayır")


@bulmaca(ders="cografya", konu="sehir_fonksiyonlari", kademeler=(10, 13), agirlik=1.3)
def yerlesme_islevleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Nüfus büyüklüğü etki alanı değildir; etki alanı sunulan işlevlerle büyür."""
    adlar = ad_sec(rastgele, _YERLESIM_ADLARI, 3)
    kalabalik, kucuk, orta = adlar
    hizmetler = [i for i in _MERKEZ_ISLEVLERI if i[1]]
    uretimler = [i for i in _MERKEZ_ISLEVLERI if not i[1]]
    k_nufus = rastgele.randrange(60, 91) * 100
    c_nufus = rastgele.randrange(25, 41) * 100
    o_nufus = rastgele.randrange(40, 56) * 100
    k_koy, o_koy, c_koy = (rastgele.randrange(2, 5), rastgele.randrange(5, 9),
                           rastgele.randrange(11, 17))
    koy_nufus = rastgele.choice((150, 200, 250, 300))
    c_isler = rastgele.sample(hizmetler, 3) + rastgele.sample(uretimler, 1)
    rastgele.shuffle(c_isler)
    c_hizmet_indeks = [n for n, i in enumerate(c_isler) if i[1]]
    k_isler = rastgele.sample(uretimler, 1)
    o_isler = rastgele.sample(hizmetler, 1) + rastgele.sample(uretimler, 1)
    toplam_kisi = c_nufus + c_koy * koy_nufus
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-yerlesme-islevleri",
        ders="cografya",
        baslik="Yerleşme İşlevleri",
        kademe=kademe,
        konu="sehir_fonksiyonlari",
        kazanim="Yerleşmenin işlevlerini ayırma; etki alanını nüfus büyüklüğüyle "
                "değil sunduğu hizmet çeşidiyle ilişkilendirme; bir yerleşmenin "
                "birden çok işlevi olabileceğini gösterme.",
        dikkat=7,
        brifing=(
            "Yeni hizmet merkezi için üç yerleşim aday: {}, {} ve {}.\n\n"
            "{} kısa bir not bıraktı: \"Merkez en kalabalık yerleşim olmalı. "
            "Nüfusu büyük olan yerin işlevi de etki alanı da büyüktür; "
            "kalabalığa bakmak yeter.\"\n\n"
            "Karar yazılmadan önce yerleşimlerin neler yaptığına ve kimlere "
            "hizmet verdiğine bakmamız gerekiyor."
        ).format(kalabalik, kucuk, orta, kisi),
        kanitlar=[
            Kanit("Yerleşim kartları",
                  "\n".join("{}: nüfus {}; işlevleri: {}.".format(
                      ad, nf, ", ".join(i[0] for i in isler))
                      for ad, nf, isler in (
                          (kalabalik, k_nufus, k_isler),
                          (kucuk, c_nufus, c_isler),
                          (orta, o_nufus, o_isler))),
                  bedel=2, kritik=True),
            Kanit("Köy ziyaret kaydı",
                  "Haftalık işleri için köylerin başvurduğu yerleşimler:\n"
                  "{}:{} köy. {}: {} köy. {}: {} köy."
                  .format(kalabalik, k_koy, orta, o_koy, kucuk, c_koy),
                  bedel=2, kritik=True),
            Kanit("Köy nüfusu",
                  "Köylerin her birinde yaklaşık {} kişi yaşıyor.".format(koy_nufus),
                  bedel=1, kritik=True),
            Kanit("Yerleşme el kitabı",
                  "Yerleşmelerin işlevleri vardır: üretim, ticaret, sağlık, "
                  "eğitim, ulaşım gibi. Bir yerleşme birden çok işleve sahip "
                  "olabilir. Etki alanı, yerleşmenin hizmet verdiği çevredir; "
                  "nüfusun büyüklüğüne değil, sunulan hizmetin çeşidine ve "
                  "erişim kolaylığına bağlıdır. Nüfusu küçük bir yerleşmenin "
                  "etki alanı büyük olabilir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir yerleşmenin etki alanını ne belirler?",
                dogru="Sunduğu hizmetin çeşidi ve erişim kolaylığı, çünkü "
                      "insanlar hizmet için oraya gider",
                yanlislar={
                    "Nüfusunun büyüklüğü, çünkü kalabalık yerleşme her yerden "
                    "daha çok insan çeker":
                        "Nüfus büyüklüğünü etki alanıyla eşitledin. Kartlarda "
                        "en kalabalık yerleşimin köy sayısı küçük kaldı.",
                    "Tek bir üretim işlevi, çünkü üretim yapan yerleşme bütün "
                    "çevreyi besler ve hizmet gerekmez":
                        "Üretim işlevi tek başına çevreye hizmet götürmez; köyler "
                        "sağlık, pazar ve okul için başvuruyor.",
                    "Kuruluş yılı, çünkü yerleşmenin yaşı büyüdükçe çevresindeki "
                    "köy sayısı kendiliğinden artar":
                        "Yaş, etki alanını belirlemez; belirleyen sunulan hizmet "
                        "ve ulaşımdır.",
                },
                rastgele=rastgele,
                aciklama=("Etki alanı sunulan hizmetle büyür: sağlık, pazar, okul "
                          "gibi işlevler çevreden insan çeker. Nüfus yalnız "
                          "yerleşmenin kendi büyüklüğünü gösterir."),
                ipuclari=[
                    "Okula ya da revire gitmen gerekse en kalabalık yeri mi seçerdin, işini görecek yeri mi?",
                    "El kitabı etki alanını neye bağlıyor?",
                ],
                cozum="Etki alani = hizmet cesidi ve erisim; nufus degil",
            ),
            coklu_adimi(
                soru="{} yerleşiminin kartındaki işlevlerden hangileri hizmet "
                     "işlevidir? (numaraları virgülle yaz)".format(kucuk),
                secenekler=[i[0] for i in c_isler],
                dogru_indeksler=c_hizmet_indeks,
                aciklama=("Hizmet işlevi mal üretmez, ihtiyaç karşılar: sağlık, "
                          "ticaret, eğitim, konaklama. Cevher, kereste ve tuz "
                          "üretim işlevidir. Bir yerleşme ikisini birlikte "
                          "taşıyabilir."),
                ipuclari=["İşlev bir mal çıkarıyor mu, yoksa insanların bir ihtiyacını mı karşılıyor?"],
                puan=12,
            ),
            sayi_adimi(
                soru="{} yerleşimi kaç kişiye hizmet veriyor? (kendi nüfusu "
                     "ve hizmet verdiği köylerin nüfusu birlikte)".format(kucuk),
                cevap=toplam_kisi,
                birim="kişi",
                aciklama="{} köy x {} kişi = {} kişi; yerleşimin kendi nüfusu {} "
                         "kişi. Toplam {}.".format(c_koy, koy_nufus, c_koy * koy_nufus,
                                                   c_nufus, toplam_kisi),
                yaygin_yanlislar={
                    c_nufus:
                        "Yalnız yerleşimin kendi nüfusunu yazdın; etki alanındaki "
                        "köylerin nüfusu da eklenir.",
                    c_koy * koy_nufus:
                        "Yalnız köylerin nüfusunu yazdın; yerleşimin kendi "
                        "nüfusunu da eklemelisin.",
                },
                ipuclari=["Köy sayısını köy nüfusuyla çarp, merkezin kendi nüfusunu ekle."],
                puan=12,
                cozum="koy sayisi x koy nufusu + kendi nufusu",
            ),
            secim_adimi(
                soru="Yeni hizmet merkezi hangi yerleşim olmalı?",
                dogru="{}, çünkü çok işlevli ve nüfusu küçük olsa da çevre "
                      "köylere çok çeşitli hizmet ve erişim sunuyor".format(kucuk),
                yanlislar={
                    "{}, çünkü en kalabalık yerleşim olduğu için etki alanı da "
                    "büyük olmak zorundadır ve başka kanıt aramaya gerek yoktur"
                    .format(kalabalik):
                        "Nüfus büyüklüğünü etki alanı saydın. Yalnız {} köy ona "
                        "gidiyor; tek üretim işlevi var.".format(k_koy),
                    "{}, çünkü nüfusu ve hizmeti birbirine yakın olduğu için "
                    "dengeli bir seçimdir, uçlar ise risklidir".format(orta):
                        "{} için hizmet işlevi ve köy sayısı ({}) daha az; ölçüt "
                        "denge değil, hizmet çeşidi ve erişimdir.".format(orta, o_koy),
                },
                rastgele=rastgele,
                aciklama=("{}: {} köy ve {} hizmet işlevi. {}: yalnız {} köy. "
                          "Merkez, nüfusa göre değil işleve ve erişime göre "
                          "seçilir.").format(kucuk, c_koy, len(c_hizmet_indeks),
                                             kalabalik, k_koy),
                ipuclari=["Köy ziyaret kaydına bak: hangi yerleşime kaç köy başvuruyor?"],
                puan=12,
            ),
        ],
        kapanis=("Hizmet merkezi {} oldu: {} kişilik etki alanıyla köylerin "
                 "başvurduğu yer. Nüfus sıralaması değil, işlev ve erişim "
                 "kayda geçti.").format(kucuk, toplam_kisi),
        odul={"itibar": 5, "erzak": 1},
    )
