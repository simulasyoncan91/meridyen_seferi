# -*- coding: utf-8 -*-
"""
Meridyen OS örnek olay kaydı.

    python main.py --olay-kaydi [yol]         # varsayılan: os/ornek_olaylar.json

Gerçek motoru bir `OlayKabugu` ile sürer: yeni kayıt -> ilk görev -> kurulum
-> ana menü -> Komuta Masası'ndan bir görev -> Nöbeti Devret. Her olay ve
motorun istediği her girdi sırayla JSON'a yazılır:

    [{"olay": {...}}, {"girdi": "..."}, ...]

Arayüz bu dosyayı motor olmadan oynatabilir (`os/index.html?ornek`).
Görev adımlarına doğru cevabı yazmak için otomatik oyuncunun `dogru_girdi`
işlevi kullanılır.
"""
from __future__ import annotations

import json
import os
import random
import re
import shutil
import tempfile
from contextlib import contextmanager

VARSAYILAN_YOL = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "os", "ornek_olaylar.json")
SINIR = 3000
SABIT_DAMGA = "13.10 09:00"
_DAMGA = re.compile(r'(\[|"tarih": ")\d\d\.\d\d \d\d:\d\d')

ANA_MENU = "ÜSTE NEREYE GİDECEKSİN?"


class Oyuncu:
    """Olay kabuğunun sürücüsü: son girdi isteğine bakıp cevabı seçer."""

    def __init__(self, ana_menu_plani, sinir: int = SINIR):
        self.plan = list(ana_menu_plani)
        self.sinir = sinir
        self.yigin = []         # oynanan görev adımları
        self.sayac = 0
        self.incelenen = set()  # kaynağına bakılan görevler (gorev_basla sırası)

    def __call__(self, kabuk, istem) -> str:
        from araclar.otomatik_oyuncu import dogru_girdi
        self.sayac += 1
        if self.sayac > self.sinir:
            raise AssertionError("akış {} girdide bitmedi".format(self.sinir))
        girdi = kabuk.son("girdi") or {}
        bicim = girdi.get("bicim", "metin")
        if bicim == "bekle":
            return ""
        if bicim == "onay":
            if "yazdırılabilir" in girdi.get("istem", ""):
                return "h"              # dosya yazmasın
            return girdi.get("varsayilan") or "e"
        if bicim == "coklu":
            return "1"
        if bicim == "menu":
            menu = kabuk.son("menu") or {}
            adlar = [s["metin"] for s in menu.get("secenekler", [])]
            if menu.get("baslik") == ANA_MENU:
                hedef = self.plan.pop(0) if self.plan else "Nöbeti Devret"
                return str(adlar.index(hedef) + 1)
            return "1"
        if self.yigin:
            return dogru_girdi(self.yigin[-1])
        if girdi.get("istem", "").startswith("İncele"):
            # Her görevde bir kaynağa bak: `kanit` bağlamı kayıtta bulunsun.
            basla = kabuk.baglamlar("gorev_basla")
            sira = len(basla)
            if sira and sira not in self.incelenen and basla[-1]["kanitlar"]:
                self.incelenen.add(sira)
                return "1"
            return ""
        if "Ad" in girdi.get("istem", ""):
            return "Ada"
        return ""


@contextmanager
def _adim_izleme(oyuncu):
    """Oturum adımlarını oyuncunun yığınına yazar (doğru cevap için)."""
    from oyun.motor.oturum import Oturum

    eski_adim, eski_birlikte = Oturum._adimi_oyna, Oturum._birlikte_adim

    def sarmala(asil):
        def sarili(oturum, adim, sira, toplam):
            oyuncu.yigin.append(adim)
            try:
                return asil(oturum, adim, sira, toplam)
            finally:
                oyuncu.yigin.pop()
        return sarili

    Oturum._adimi_oyna = sarmala(eski_adim)
    Oturum._birlikte_adim = sarmala(eski_birlikte)
    try:
        yield
    finally:
        Oturum._adimi_oyna, Oturum._birlikte_adim = eski_adim, eski_birlikte


def kaydet_akis(ana_menu_plani=("Komuta Masası", "Nöbeti Devret"),
                tohum: int = 7):
    """Akışı oynatır, `OlayKabugu` döner (kayit/olaylar dolu)."""
    from oyun.motor import durum as durum_modulu, oyun as oyun_modulu
    from oyun.motor import terminal
    from oyun.motor.olay_kabugu import OlayKabugu

    klasor = tempfile.mkdtemp(prefix="olay_kaydi_")
    eski_klasor = durum_modulu.KAYIT_KLASORU
    eski_kabuk = terminal.kabuk()
    durum_modulu.KAYIT_KLASORU = klasor
    oyuncu = Oyuncu(ana_menu_plani)
    kabuk = OlayKabugu(oyuncu, sinir=SINIR)
    terminal.kabuk_ata(kabuk)
    random.seed(tohum)
    try:
        with _adim_izleme(oyuncu):
            durum = oyun_modulu._yeni_oyun()
            oyun_modulu.Oyun(durum).calistir()
    finally:
        kabuk.gecici_klasor = klasor
        terminal.kabuk_ata(eski_kabuk)
        durum_modulu.KAYIT_KLASORU = eski_klasor
        shutil.rmtree(klasor, ignore_errors=True)
    return kabuk


def yaz(kabuk, yol: str) -> int:
    klasor = os.path.dirname(os.path.abspath(yol))
    os.makedirs(klasor, exist_ok=True)
    satirlar = [json.dumps(oge, ensure_ascii=False) for oge in kabuk.kayit]
    # Geçici kayıt klasörünün gerçek yolu (kullanıcı adı, rastgele ad) dosyaya
    # girmesin: kayıt her üretildiğinde aynı çıksın.
    gecici = getattr(kabuk, "gecici_klasor", "")
    if gecici:
        kacisli = json.dumps(gecici, ensure_ascii=False)[1:-1]
        satirlar = [s.replace(kacisli, "kayitlar") for s in satirlar]
    # Saat damgaları (günlük satırları, arşiv "tarih" alanı) her çalıştırmada
    # değişir; kayıt aynı çıksın diye sabit bir tarihe çevrilir.
    satirlar = [_DAMGA.sub(r"\g<1>" + SABIT_DAMGA, s) for s in satirlar]
    with open(yol, "w", encoding="utf-8", newline="\n") as f:
        f.write("[\n" + ",\n".join(satirlar) + "\n]\n")
    return len(satirlar)


def main(yol: str = "") -> int:
    yol = yol or VARSAYILAN_YOL
    kabuk = kaydet_akis()
    adet = yaz(kabuk, yol)
    baglamlar = sorted({o["ad"] for o in kabuk.baglamlar()})
    print("{} öğe yazıldı ({} olay, {} girdi): {}".format(
        adet, len(kabuk.olaylar), len(kabuk.girdiler), yol))
    print("Bağlamlar: " + ", ".join(baglamlar))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
