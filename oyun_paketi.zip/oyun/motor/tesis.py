# -*- coding: utf-8 -*-
"""
Üretim tesisleri: maden, tarla, atölye.

NE İŞE YARAR
------------
Kaynaklar bugüne kadar kazanılıyor ama harcanmıyordu -- ölçüldü: 40 görev
sonunda itibar 0'dan 168'e çıkmış, hiç harcanmamıştı. Bir sayının yalnızca
büyümesi onu anlamsız kılar.

Bu modül döngünün ikinci yarısını kuruyor: kaynak HARCANIR (onarım,
kurulum) ve ZAMANLA ÜRETİLİR.

"ZAMAN" DUVAR SAATİ DEĞİL, TAMAMLANAN GÖREVDİR
----------------------------------------------
TASARIM_NOTLARI §3: kaynak yalnızca öğrenerek kazanılır. Duvar saatine
bağlı üretim bunu bozardı -- oyunu açık bırakan ya da ertesi gün girip
hiçbir şey yapmadan toplayan öğrenci ödüllenirdi. Üretim göreve bağlıyken
beklemenin hiçbir getirisi yok.

TESİSLER BİR EK KATMANDIR, KAPI DEĞİL
-------------------------------------
Bütün tesisler arızalı ve öğrencinin sıfır kaynağı olsa bile oyun bugünkü
gibi oynanabilir. Tesisler yalnızca hızlandırır.

Bu, sistemin en önemli güvenlik özelliği ve teste bağlı. 8 Eylül'de tam bu
ilke çiğnenmişti: sefer bedeli + yıldız çarpanı 0-1 yıldızlı öğrencinin
net enerjisini eksiye düşürüp onu kalıcı olarak kilitlemişti. Aynı hata
burada daha kolay yapılır -- kaynağı üreten tesis arızalıysa öğrenci kendi
kilidinin anahtarını üretemez.

Bu yüzden: **onarım bedeli görev ödülünden küçük** ve **arızalı tesis
sayısı arttıkça onarım ucuzlar.** Zorlanan öğrencinin arızası kolaylaşır.
"""
from __future__ import annotations

import random
from typing import Dict, List, Optional

from . import konum

# (kod, ad, ürettiği kaynak, görev başına üretim, kuruluş hikâyesi)
TESISLER = [
    ("maden", "Kuzey Madeni", "cevher", 2,
     "Üssün taş ve metal ihtiyacı buradan çıkıyor."),
    ("tarla", "Vadi Tarlası", "erzak", 2,
     "Kışlık erzağın çoğu bu tarladan geliyor."),
    ("atolye", "Onarım Atölyesi", "enerji", 1,
     "Aygıtların bakımı ve yakıt hazırlığı burada yapılıyor."),
]

TESIS_KODLARI = [t[0] for t in TESISLER]

# Kaç görevde bir arıza denenir. Her görevde denemek arızayı sıradan bir
# vergiye çevirir; çok seyrek denemek de tesisleri unutturur.
ARIZA_ARALIGI = 5

# Arıza denemesinde arıza çıkma olasılığı.
ARIZA_OLASILIGI = 0.45

# Onarımın temel bedeli. GÖREV ÖDÜLÜNDEN KÜÇÜK tutuluyor: bir görev
# ortalama 6-12 kaynak veriyor (bkz. oyun._odulu_hesapla), onarım 4.
# Öğrenci bir görevle onarımını karşılayabilmeli, yoksa tesis kapıya döner.
ONARIM_BEDELI = 4

# Kaç tesis arızalıysa onarım o kadar ucuzlar. Üçü birden arızalıysa
# öğrenci zaten üretimsiz kalmış demektir; onu bir de pahalı onarımla
# cezalandırmak §0'a aykırı.
ONARIM_INDIRIMI = 1


def varsayilan_durum() -> Dict[str, Dict]:
    """Yeni bir oyuncunun tesisleri: hepsi çalışır durumda.

    Tesisler KURULMUŞ olarak başlıyor, kurulmayı beklemiyor. Sebep §0:
    oyunun ilk yarım saati zaten yeni; üstüne bir de kurulum ekonomisi
    öğretmek, öğrenmenin önüne başka bir öğrenme koymak olur.
    """
    return {kod: {"calisiyor": True, "uretilen": 0, "seviye": 1}
            for kod in TESIS_KODLARI}


def tesisleri_al(durum) -> Dict[str, Dict]:
    """Durumdaki tesis tablosu; yoksa kurar. Eski kayıtlar bozulmaz."""
    mevcut = getattr(durum, "tesisler", None)
    if not isinstance(mevcut, dict) or not mevcut:
        durum.tesisler = varsayilan_durum()
        return durum.tesisler
    # Sonradan tesis eklenirse eski kayıtta olmayanı tamamla.
    for kod in TESIS_KODLARI:
        mevcut.setdefault(kod, {"calisiyor": True, "uretilen": 0, "seviye": 1})
        mevcut[kod].setdefault("seviye", 1)
    return mevcut


def _tanim(kod: str):
    return next(t for t in TESISLER if t[0] == kod)


def calisan_sayisi(durum) -> int:
    return sum(1 for t in tesisleri_al(durum).values() if t.get("calisiyor"))


def arizali_kodlar(durum) -> List[str]:
    return [k for k, t in tesisleri_al(durum).items() if not t.get("calisiyor")]


# Onarımda hangi kaynak harcanır. İTİBAR BİLEREK YOK.
#
# İlk yazımda bedel itibardı ve 120 görevlik bir benzetim tam da bu
# dosyanın uyardığı tuzağı gösterdi: hiçbir tesis itibar üretmiyor, yani
# üretimden gelen kaynakla onarım YAPILAMIYOR. Sıfır kaynakla başlayan
# öğrenci 120 turun 116'sında onaramadı; elinde 240 cevher birikmişken
# iki tesis kalıcı olarak durdu.
#
# Üstelik itibar başarı ölçüsü: bedelini itibarla ödetmek, düşük puan
# alan öğrenciyi onarımdan da mahrum bırakır. §0'a aykırı.
ONARIM_KAYNAKLARI = ("cevher", "erzak", "enerji")


def onarim_kaynagi(durum) -> str:
    """Bedelin ödeneceği kaynak: öğrencinin EN ÇOK sahip olduğu.

    Tek bir kaynağa bağlamak (ör. hep cevher) madeni arızalanan öğrenciyi
    kilitler. Elindekinden almak bunu yapısal olarak imkânsız kılıyor:
    bir şeyi varsa onarabilir.

    Anlatı da tutuyor -- üs onarımı için malzeme lazım ve depoda ne varsa
    o kullanılır.
    """
    return max(ONARIM_KAYNAKLARI,
               key=lambda k: durum.kaynaklar.get(k, 0))


def onarim_bedeli(durum) -> Dict[str, int]:
    """Onarımın kaynak bedeli. Arızalı tesis çoğaldıkça UCUZLAR.

    Ters yönlü bir ölçek: normalde "çok bozuksa çok öde" beklenir, ama
    burada çok bozuk olmak öğrencinin üretimsiz kaldığı anlamına geliyor.
    Onu bir de pahalı onarımla cezalandırmak, en çok desteğe ihtiyacı olan
    öğrenciyi en çok zorlamak olurdu.
    """
    indirim = ONARIM_INDIRIMI * max(0, len(arizali_kodlar(durum)) - 1)
    return {onarim_kaynagi(durum): max(1, ONARIM_BEDELI - indirim)}


# ---------------------------------------------------------------- gelistirme
#
# NEDEN VAR: onarim tek basina yeterli bir gider degil. Olculdu -- 40 gorev
# sonunda zorlanan ogrencinin elinde 58 erzak, 61 cevher birikiyordu. Zaman
# seferinin baglayici kaynagi itibar oldugu icin MALZEMEYE hic dokunmuyor.
# Kullanici zaten bunu istedi: "materyalleri, erzaklari falan harcanabilir
# yapmamiz lazim."
#
# TESIS KENDI URETTIGI KAYNAKLA GELISIR. Maden cevherle, tarla erzakla.
# Boylece her malzemenin kendi giderleri olur; hicbiri "sadece buyuyen bir
# sayi" olarak kalmaz.
#
# KAPI DEGIL: hicbir sey almayan ogrenci hicbir sey kaybetmez. Gelistirme
# yalnizca hizlandirir, ve bedeli katlanarak arttigi icin sonsuz bir
# hizlanma da olmuyor.
AZAMI_SEVIYE = 4
GELISTIRME_TABANI = 20


def seviye(durum, kod: str) -> int:
    return int(tesisleri_al(durum).get(kod, {}).get("seviye", 1))


def uretim_miktari(durum, kod: str) -> int:
    """Tesisin su anki gorev basina uretimi: taban + (seviye - 1)."""
    return _tanim(kod)[3] + seviye(durum, kod) - 1


def azami_seviye(durum) -> int:
    """Konumun izin verdigi en yuksek seviye.

    Yeraltinda ve uzayda yer daha bol: bir seviye daha (konum.seviye_farki).
    """
    return AZAMI_SEVIYE + konum.seviye_farki(konum.konum_kodu(durum))


def gelistirme_bedeli(durum, kod: str) -> Optional[Dict[str, int]]:
    """Bir sonraki seviyenin bedeli; azami seviyedeyse None.

    Bedel KATLANARAK artiyor (20, 40, 80). Sabit bedel olsaydi uretim
    arttikca gelistirme ucuzlar, gider birkac gorevde anlamsizlasirdi.

    Konum carpani burada uygulanir: yeryuzunde kazi yok, yeraltinda once
    kazi gerekir, uzaya her modul tasinir (bkz. oyun/motor/konum.py).
    """
    kademe = seviye(durum, kod)
    if kademe >= azami_seviye(durum):
        return None
    if bekleyen_gorev(durum, kod):
        return None                  # zaten yapim halinde
    taban = GELISTIRME_TABANI * (2 ** (kademe - 1))
    carpan = konum.genisleme_carpani(konum.konum_kodu(durum))
    return {_tanim(kod)[2]: int(round(taban * carpan))}


def bekleyen_gorev(durum, kod: str) -> int:
    """Suren genislemenin kac gorev sonra bitecegi. 0 = bekleyen yok."""
    return int(tesisleri_al(durum).get(kod, {}).get("bekleyen", 0) or 0)


def gelistir(durum, kod: str) -> bool:
    """Genislemeyi baslatir. Kaynak DUSMEZ; cagiran taraf odemis olmali.

    Konumda kazi suresi varsa seviye HEMEN artmaz: `bekleyen` sayaci konur
    ve her tamamlanan gorevde bir azalir (bkz. uretimi_isle). Kullanicinin
    istedigi ayrim bu: "once kazi sonra yerlestirme olur".
    """
    if gelistirme_bedeli(durum, kod) is None:
        return False
    sure = konum.kazi_gorevi(konum.konum_kodu(durum))
    if sure > 0:
        tesisleri_al(durum)[kod]["bekleyen"] = sure
        return True
    tesisleri_al(durum)[kod]["seviye"] = seviye(durum, kod) + 1
    return True


def uretimi_isle(durum) -> Dict[str, int]:
    """Bir görev tamamlandı: çalışan tesisler üretsin.

    Dönüş: eklenen kaynaklar (boşsa hiçbir tesis çalışmıyor demektir).
    Kaynağı EKLEMİYOR; çağıran taraf ekliyor ki ekranda tek yerden
    gösterilebilsin.
    """
    tesisler = tesisleri_al(durum)
    fark = konum.uretim_farki(konum.konum_kodu(durum))
    kazanc: Dict[str, int] = {}
    for kod, ad, kaynak, _taban, _ in TESISLER:
        kayit = tesisler.get(kod, {})
        if not kayit.get("calisiyor"):
            continue
        # Konum farki EKSI olabilir (colde erzak -1). Uretim sifirin altina
        # inmesin: eksi uretim kaynagi GERI ALMAK olurdu, o da §0'a aykiri.
        miktar = max(0, uretim_miktari(durum, kod) + fark.get(kaynak, 0))
        kazanc[kaynak] = kazanc.get(kaynak, 0) + miktar
        kayit["uretilen"] = int(kayit.get("uretilen", 0)) + miktar
    return kazanc


def genislemeleri_ilerlet(durum) -> List[str]:
    """Suren genislemeleri bir gorev ilerletir; BITENLERIN kodunu doner.

    Arizali tesiste de ilerler: kazi ekibi ayri calisir ve arizanin
    genislemeyi de durdurmasi ogrenciyi iki kez cezalandirirdi.
    """
    bitenler = []
    for kod, kayit in tesisleri_al(durum).items():
        kalan = int(kayit.get("bekleyen", 0) or 0)
        if kalan <= 0:
            continue
        kalan -= 1
        if kalan <= 0:
            kayit["bekleyen"] = 0
            kayit["seviye"] = int(kayit.get("seviye", 1)) + 1
            bitenler.append(kod)
        else:
            kayit["bekleyen"] = kalan
    return bitenler


# Arıza olasılığının inebileceği ve çıkabileceği sınır. Konum farkı ne olursa
# olsun ne "hiç bozulmaz" ne de "her denemede bozulur" olsun: ilki tesisleri
# anlamsızlaştırır, ikincisi öğrenciyi onarım koşusuna sokar.
ARIZA_ALT_SINIR = 0.20
ARIZA_UST_SINIR = 0.70


def ariza_olasiligi(durum) -> float:
    """Konumun etkisiyle arıza olasılığı (yeryüzü taban sayılır)."""
    ham = ARIZA_OLASILIGI + konum.tehlike_farki(konum.konum_kodu(durum))
    return max(ARIZA_ALT_SINIR, min(ARIZA_UST_SINIR, ham))


def ariza_dene(durum, rastgele: Optional[random.Random] = None) -> Optional[str]:
    """Sırası geldiyse bir tesisi arızalandırır; arızalanan tesisin kodu.

    ÜÇÜ BİRDEN ARIZALANMAZ. En az bir tesis hep çalışır -- öğrenci
    üretimsiz kalmasın diye. Bu, "tesisler kapı değil" ilkesinin
    somutlaşmış hâli: onarım için gereken kaynağı üretecek bir şey her
    zaman ayakta kalır.
    """
    rnd = rastgele or random.Random()
    if durum.oynanan_gorev % ARIZA_ARALIGI != 0:
        return None
    if rnd.random() >= ariza_olasiligi(durum):
        return None
    calisanlar = [k for k, t in tesisleri_al(durum).items() if t.get("calisiyor")]
    if len(calisanlar) <= 1:
        return None
    kod = rnd.choice(calisanlar)
    tesisleri_al(durum)[kod]["calisiyor"] = False
    return kod


def onar(durum, kod: str) -> bool:
    """Tesisi onarır. Kaynak DÜŞMEZ; çağıran taraf bedeli ödemiş olmalı."""
    tesisler = tesisleri_al(durum)
    if kod not in tesisler or tesisler[kod].get("calisiyor"):
        return False
    tesisler[kod]["calisiyor"] = True
    return True


def ad(kod: str) -> str:
    return _tanim(kod)[1]


def uretim_ozeti(durum) -> List[Dict]:
    """Ekranda gösterilecek satırlar."""
    tesisler = tesisleri_al(durum)
    satirlar = []
    for kod, tesis_adi, kaynak, _taban, hikaye in TESISLER:
        kayit = tesisler.get(kod, {})
        satirlar.append({
            "kod": kod,
            "ad": tesis_adi,
            "kaynak": kaynak,
            "miktar": (uretim_miktari(durum, kod)
                       + konum.uretim_farki(konum.konum_kodu(durum)).get(kaynak, 0)),
            "seviye": seviye(durum, kod),
            "gelistirme": gelistirme_bedeli(durum, kod),
            "bekleyen": bekleyen_gorev(durum, kod),
            "calisiyor": bool(kayit.get("calisiyor")),
            "uretilen": int(kayit.get("uretilen", 0)),
            "hikaye": hikaye,
        })
    return satirlar


def zincir_ozeti(durum) -> Dict:
    """Stoklar, zincir adimlari ve darbogaz (bkz. zincir.py, B28.9-B28.12)."""
    from . import zincir
    return zincir.zincir_ozeti(durum)
