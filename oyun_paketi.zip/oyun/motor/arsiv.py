# -*- coding: utf-8 -*-
"""
Meridyen OS: Arşiv (dosya gezgini) ve Posta için kalıcı kayıtlar.

İKİSİ DE AYNI LİSTEDE: `Durum.arsiv`, kayıt dosyasında düz bir liste.
Arşiv uygulaması `kanit`, `rapor`, `karne` türlerini klasörlerde gösterir
(günlük zaten `Durum.gunluk`ta durur, tekrar saklanmaz); Posta uygulaması
`posta` türünü gösterir. Kayıt biçimi (B47 ilkesi):

    {"tur": "kanit"|"rapor"|"karne"|"posta", "ders": ..., "baslik": ...,
     "etiket": ..., "metin": ..., "tarih": "13.10 18:42"}

* Geriye uyum: alan eski kayıtta yoktur, boş liste olarak açılır.
* İleriye uyum: yeni sürümün eklediği alanlar kayıtta olduğu gibi durur
  (`ekle` var olan kaydı yalnız bilinen alanlarda günceller, tanımadığı
  anahtarlara dokunmaz); tanımadığımız türler de silinmez.
* Aynı (tur, ders, baslik, etiket) ikinci kez eklenmez (kanıt yeniden
  açılınca arşiv şişmez); metin değiştiyse yerinde güncellenir.
* Sınır: toplam 200 kayıt, türlere payıyla bölünmüş (aşağıdaki KOTA).

Olay: yeni kayıt eklenince `arsiv_ekle` bağlamı, oyun açılırken
`arsiv` bağlamı (hepsi + günlük) gönderilir. Terminalde hiçbir şey
yapılmaz; Arşiv ve Posta yalnız OS'ta görünür.
"""
from __future__ import annotations

import time
from typing import Any, Dict, List

from . import terminal as ekran

AZAMI_KAYIT = 200
KOTA = {"kanit": 100, "rapor": 40, "karne": 10, "posta": 50}
AZAMI_METIN = 2000
TURLER = tuple(KOTA)
_ANAHTAR = ("tur", "ders", "baslik", "etiket")


def _kes(metin: Any, sinir: int) -> str:
    metin = "" if metin is None else str(metin)
    return metin if len(metin) <= sinir else metin[:sinir - 1].rstrip() + "…"


def _kopya(kayit: Dict[str, Any]) -> Dict[str, Any]:
    return dict(kayit)


def _sinirla(liste: List[Dict[str, Any]]) -> None:
    """Her türü kendi kotasına, sonra toplamı AZAMI_KAYIT'a indirir (eskiden)."""
    for tur, kota in KOTA.items():
        indeksler = [i for i, k in enumerate(liste) if k.get("tur") == tur]
        for i in reversed(indeksler[:-kota] if len(indeksler) > kota else []):
            del liste[i]
    del liste[:-AZAMI_KAYIT]


def ekle(durum, tur: str, baslik: str, metin: str = "", ders: str = "",
         etiket: str = "") -> Dict[str, Any]:
    """Kaydı ekler ya da günceller; `arsiv_ekle` bağlamını gönderir.

    Dönen sözlük kaydın kendisidir. `durum` None ise (oturum durumsuz
    açılmışsa) kayıt tutulmaz ama olay yine gider.
    """
    kayit = {"tur": tur, "ders": _kes(ders, 80), "baslik": _kes(baslik, 160),
             "etiket": _kes(etiket, 160), "metin": _kes(metin, AZAMI_METIN),
             "tarih": time.strftime("%d.%m %H:%M")}
    yeni = True
    if durum is not None:
        liste = durum.arsiv
        for eski in liste:
            if all(eski.get(a) == kayit[a] for a in _ANAHTAR):
                yeni = eski.get("metin") != kayit["metin"]
                eski["metin"] = kayit["metin"]
                eski["tarih"] = kayit["tarih"]
                kayit = eski
                break
        else:
            liste.append(kayit)
            _sinirla(liste)
    if yeni:
        ekran.baglam("arsiv_ekle", **_kopya(kayit))
    return kayit


def ac(durum) -> None:
    """Oyun açılırken: kayıtlı arşiv + günlük OS'a gider."""
    if ekran.olayli():
        ekran.baglam("arsiv", kayitlar=[_kopya(k) for k in durum.arsiv
                                        if isinstance(k, dict)],
                     gunluk=list(durum.gunluk))


def karne_ozeti(veri: Dict[str, Any]) -> str:
    """Karne verisinden kısa düz metin (arşivde okunur)."""
    satirlar = [
        "Rütbe: {}   Raporlanan görev: {}".format(veri.get("rutbe", ""), veri.get("gorev", 0)),
        "Ele alınan konu: {}   Oturan konu: {}   Genel: %{} ({})".format(
            veri.get("ele_alinan", 0), veri.get("oturan", 0),
            veri.get("genel_yuzde", 0), veri.get("genel_seviye", "")),
    ]
    for yol in veri.get("yollar") or []:
        satirlar.append("- {}: {}/{} konu oturdu ({})".format(
            yol.get("ad", ""), yol.get("oturan", 0), yol.get("ele_alinan", 0),
            yol.get("seviye", "")))
    guclu = [k.get("konu", "") for k in veri.get("guclu") or []]
    tekrar = [k.get("konu", "") for k in veri.get("tekrar") or []]
    if guclu:
        satirlar.append("Güçlü: " + ", ".join(guclu))
    if tekrar:
        satirlar.append("Tekrar edilecek: " + ", ".join(tekrar))
    if veri.get("degerlendirme"):
        satirlar.append("")
        satirlar.append(veri["degerlendirme"])
    if veri.get("oneri"):
        satirlar.append(veri["oneri"])
    return "\n".join(satirlar)


def posta(durum, gonderen: str, konu: str, metin: str, kimlik: str) -> None:
    """Posta iletisi: kimlik kararlı olmalı (aynı ileti iki kez gelmez)."""
    ekle(durum, "posta", konu, metin, ders=gonderen, etiket=kimlik)
