# -*- coding: utf-8 -*-
"""
Görev oturumu: bir bulmacanın oynanışı.

Aynı görev ÜÇ FARKLI DESTEK DÜZEYİNDE oynanabilir. Bu, oyunun öğretme
biçimidir; öğrenciyi sınamak değil, adım adım yalnız bırakmak için kurulmuştur:

  1) ANLATIM  - Görev çözülmüş hâlde gösterilir. Öğrenci cevap vermez; olayı,
                kanıtları, kurulan bağıntıyı ve çözümü okur. Puan yoktur.
  2) BİRLİKTE - Aynı görev, YENİ SAYILARLA. Her adımda yol gösterilir ama
                kararı öğrenci verir. Yanlışın bedeli yoktur; doğru bulunana
                kadar yardım artar. Puan yoktur.
  3) SERBEST  - Öğrenci tek başına çözer. İpucu ve tam çözüm vardır ama
                istemek gerekir. Puan burada anlam kazanır.

Serbest aşamadaki puanlama tek kurala dayanır: ilk denemede, ipucusuz bulmak
tam puandır. Sonraki her deneme ve her ipucu puanı düşürür ama görevi
bitirmeni engellemez.
"""
from __future__ import annotations

import hashlib
import random

from typing import List, Optional

from . import terminal as ekran
from .degerlendirme import degerlendir, dogru_cevap_metni, teshis
from .modeller import (
    Adim, AdimSonucu, ANLATIM, ASAMA_ACIKLAMALARI, ASAMA_ADLARI, BIRLIKTE,
    Bulmaca, BulmacaSonucu, COKLU, ESLESTIR, METIN, MODEL, ROL_ETIKETI, SAYI,
    SECIM, SERBEST, SIRALA, ZORLUK_ADLARI, DERS_RENGI, kademe_zorlugu,
)
from . import degerlendirme
from . import oyuncu
from .terminal import S

# Deneme sayısına göre puan çarpanı. Şıklı sorularda daha az deneme hakkı var.
CARPANLAR = [1.0, 0.6, 0.3]
SIKLI_TURLER = (SECIM, COKLU, SIRALA, ESLESTIR)

# "Yanindayim" (BIRLIKTE) asamasinda gecerli komutlar. Serbest asamadan
# FARKLI: ipucu ve cozum burada zaten bedelsiz ve baştan aciktir, o yuzden
# ayrica istenmez. Ogrenci yine de o tuslara basabilir; ceza verilmez,
# neden gerekmedigi soylenir.
BIRLIKTE_KOMUTLARI = [
    ("b", "brifingi tekrar oku"),
    ("d", "bütün kanıtları gör"),
    ("e", "el kaldır - öğretmene sessizce bildir"),
    ("x", "bu görevden çık"),
    ("?", "bu listeyi göster"),
]

BIRLIKTE_KOMUT_ACIKLAMA = {
    "i": "Bu aşamada yol gösterme zaten açık; ayrıca ipucu istemene gerek yok.",
    "c": "Bu aşamada çözüm adım adım birlikte kuruluyor; ayrı bir tam çözüm yok.",
    "k": "Kanıtların hepsi açık. Görmek için \"d\" yaz.",
    "o": "Basit örnek kendi başına çalışırken var; burada zaten yanındayım.",
}

KOMUT_YARDIMI = [
    ("k", "kanıtları incele"),
    ("i", "ipucu iste (puandan düşer)"),
    ("c", "tam çözümü aç (dikkat harcar, puanı düşürür)"),
    ("o", "basit bir örnek göster (yanlıştan sonra açılır)"),
    ("b", "brifingi tekrar oku"),
    ("d", "defterim - açtığım kanıtlar"),
    ("e", "el kaldır - öğretmene sessizce bildir"),
    ("x", "görevden çekil"),
]

# Yalnızca yanlıştan sonra açılan komutlar. "?" listesinde ve adım başındaki
# komut satırında, öğrenci o adımda en az bir kez yanlış yapmadan görünmezler.
YANLIS_SONRASI_KOMUTLAR = ("o",)

# Yalnizca ogretmenin actigi bir sinifa bagliyken gorunen komutlar. Evde
# oynayan icin "el kaldir" diye bir sey yok; bildirinin gidecegi kimse yok
# ve gorunmesi bos bir vaat olurdu.
SINIF_KOMUTLARI = ("e",)

# Tam çözüm açıldığında adımdan alınabilecek en yüksek puan oranı.
# Sıfır yapmıyoruz: çözümü okuyup anlayan öğrenci de bir şey kazanmalı,
# ama denemeden okuyan tam puan almamalı.
COZUM_TAVANI = 0.3

# Kutu basligi -> cumle icinde kullanilacak ad.
# `.capitalize()` KULLANILMIYOR: Turkcede "NASIL".capitalize() "Nasil"
# veriyor (I harfi i'ye dusuyor). Acik esleme hem dogru hem okunakli.
COZUM_ADLARI = {
    "TAM ÇÖZÜM": "Tam çözüm",
    "NASIL DÜŞÜNÜLÜR": "Çözüm açıklaması",
}

# "Basit örnek" (o) komutu: aynı konudan, KAÇ kademe aşağıda bir bulmaca
# aranacak. Sırayla denenir; önce en kolayı. Alt sınır 1'dir ve bulunan
# örnek mevcut kademeden yüksekse gösterilmez (bkz. _ornek_uret).
ORNEK_KADEME_DUSUSU = (3, 2)

# ÖRNEĞİN BEDELİ - karar ve gerekçesi (TASARIM_NOTLARI.md §0)
#
# Örnek DİKKAT HARCAMAZ. Dikkat havuzu kalıcıdır ve görevler arasında
# taşınır; örneğe dikkat yazsaydık, zorlanan öğrenci sonraki görevlerde
# kanıt açamaz hâle gelirdi. Yani bedel, hatanın yapıldığı adımda kalmaz,
# oyunun geri kalanına yayılırdı. "Zorlanmanın bedeli ceza değil, desteğin
# artmasıdır" ilkesinin tam tersi olurdu; üstelik örnek zaten YALNIZCA
# yanlış yapmış öğrenciye açılıyor, yani aynı öğrenci ikinci kez
# cezalandırılmış olurdu.
#
# Bedelsiz de bırakmadık: örnek, o adımın puanından BİR İPUCU kadar düşer
# (adim.ipucu_bedeli). Sebebi ceza değil, tutarlılık: çözülmüş bir örnek
# ipucundan daha çok yardımdır, bedava olsaydı ipucu istemenin hiçbir
# anlamı kalmazdı ve "tek başına çözdüm" ölçüsü boşalırdı. Bu düşüş
# görevi bitirmeyi engellemez; _puan_hesapla'daki taban (en az 1 puan)
# burada da geçerlidir. Örnek kaç kez okunursa okunsun bedel bir kezdir.


class Oturum:
    """Tek bir bulmacayı baştan sona oynatır."""

    def __init__(self, bulmaca: Bulmaca, oyuncu_adi: str = "Kâşif",
                 ipucu_acik: bool = True, asama: str = SERBEST, durum=None):
        self.bulmaca = bulmaca
        self.oyuncu_adi = oyuncu_adi
        self.ipucu_acik = ipucu_acik
        self.asama = asama
        self.acilan: List[int] = []
        self._baslangic_kanitlarini_ac()
        # Dikkat artik KALICI: gorevler arasi tasiniyor ve tavani ogrencinin
        # ustaligiyla TERS orantili (yeni ogrenci 100, her seyi oturtmus 10).
        # `durum` verilmezse (demo, test, tek gorev) eski davranis surer:
        # bulmacanin kendi dikkati kullanilir ve hicbir yere yazilmaz.
        self.durum = durum
        if durum is not None:
            self.kalan_dikkat = durum.dikkati_hazirla()
            self.dikkat_tavani = durum.dikkat_tavani()
        else:
            self.kalan_dikkat = bulmaca.dikkat
            self.dikkat_tavani = bulmaca.dikkat
        self.renk = DERS_RENGI.get(bulmaca.ders, "acik_cam")
        # Bu görevde öğrenciye gösterilen yanlış teşhisleri; sonuca aktarılıp
        # karnede "tekrarlayan hata" olarak birikir.
        self.gorulen_teshisler: List[str] = []

    # Kademeye gore baslangicta bedava acilan kanit orani. Kucuk kademede
    # ogrenci once "ne biliyorum" gormeli; ust kademede ise bilginin
    # eksikligi sorunun kendisidir.
    BASLANGIC_ACIK_ORANI = ((4, 0.60), (8, 0.40), (12, 0.25), (99, 0.10))

    def _baslangic_kanitlarini_ac(self) -> None:
        """Kanitlarin bir kismini gorev basinda BEDAVA acar.

        Kullanicinin istegi: "derslerin zorluguna gore o bilgilerden
        hangileri soru ilk soruldugunda soylenip soylenmeyecegi rastgele
        sekilde belirsin... bir soruda depo sayisi soylenirken baska bir
        soruda depolarin kac oldugunu bilemeyiz."

        Iki kural var:
        1) Secim RASTGELE ama TOHUMU SABIT. Ayni bulmaca metni her zaman
           ayni kanitlari acar; yoksa `--denetle` tekrarlanabilir olmaz ve
           ogrenci oyunu kapatip acarak kanit devsirir. Tohum brifing
           metninden turetiliyor: ayni uretici farkli tohumda farkli metin
           urettigi icin acilan kanit da degisiyor -- istenen cesitlilik
           buradan geliyor.
        2) KRITIK kanitlarin hepsi birden acilmaz. Kritik kanit olmadan
           bulmaca cozulemez; hepsini bedava vermek gorevi ortadan kaldirir.
           Ust kademede (9+) hic kritik acilmaz.
        """
        kanitlar = self.bulmaca.kanitlar
        if not kanitlar:
            return
        kademe = getattr(self.bulmaca, "kademe", 5)
        oran = next(o for esik, o in self.BASLANGIC_ACIK_ORANI if kademe <= esik)
        adet = int(len(kanitlar) * oran)
        if adet <= 0:
            return

        tohum = int(hashlib.sha256(
            (self.bulmaca.brifing or self.bulmaca.kod or "").encode("utf-8")
        ).hexdigest()[:12], 16)
        karistirici = random.Random(tohum)

        adaylar = list(range(len(kanitlar)))
        karistirici.shuffle(adaylar)

        kritik_toplam = sum(1 for k in kanitlar if k.kritik)
        acilan_kritik = 0
        for indeks in adaylar:
            if len(self.acilan) >= adet:
                break
            if kanitlar[indeks].kritik:
                if kademe > 8:
                    continue
                if acilan_kritik + 1 >= kritik_toplam:
                    continue
                acilan_kritik += 1
            self.acilan.append(indeks)
        self.acilan.sort()

    def _dikkat_harca(self, bedel: int) -> None:
        """Oturumdan DUSER ve kalici havuza da yazar.

        Ikisi ayri tutulmuyor: havuz kalici oldugu icin gorev yarida
        birakilsa bile harcanan dikkat geri gelmemeli -- yoksa ogrenci
        kaniti acip cikarak bedava bilgi toplar.
        """
        self.kalan_dikkat -= bedel
        if self.durum is not None:
            self.durum.dikkat_harca(bedel)

    # ------------------------------------------------------------------ ekran
    def _ust_bilgi(self) -> None:
        b = self.bulmaca
        ekran.temizle()
        ekran.baslik(ekran.tr_buyuk(b.baslik), "kalin", self.renk)
        zorluk = kademe_zorlugu(b.kademe)
        sol = "Zorluk {} - {} {} {}".format(
            zorluk,
            ZORLUK_ADLARI[zorluk], S["dikey"], ASAMA_ADLARI.get(self.asama, ""))
        if self.asama == SERBEST:
            sag = "Dikkat: {}/{}".format(self.kalan_dikkat, self.dikkat_tavani)
        else:
            sag = "Adım {}/3".format(
                {ANLATIM: 1, BIRLIKTE: 2}.get(self.asama, 3))
        ekran.iki_sutun(sol, sag, self.renk, "gri")
        ekran.ayrac()

    def _brifing_goster(self) -> None:
        from .anlati import giris_metni
        ekran.yaz()
        giris = giris_metni(self.durum)
        if giris:
            ekran.yaz(giris, "acik_cam")
        ekran.kutu(self.bulmaca.brifing, "BRİFİNG", "beyaz")

    def _kanit_listesi(self) -> None:
        b = self.bulmaca
        if not b.kanitlar:
            ekran.bilgi("Bu görevde incelenecek ayrı bir kaynak yok; her şey brifingte.")
            return
        ekran.yaz()
        ekran.yaz("İNCELENEBİLİR KAYNAKLAR", "kalin", self.renk)
        for sira, kanit in enumerate(b.kanitlar, 1):
            acik = (sira - 1) in self.acilan
            isaret = ekran.renkli(S["onay"], "acik_yesil") if acik else ekran.renkli("?", "gri")
            bedel = "" if acik else ekran.renkli(" ({} dikkat)".format(kanit.bedel), "gri")
            ekran.ham_yaz("  {} {} {}{}".format(
                ekran.renkli("[{}]".format(sira), "acik_sari"), isaret, kanit.etiket, bedel))

    # ------------------------------------------------ Meridyen OS bağlamları
    def _kanit_goster(self, sira0: int) -> None:
        """Bir kanıtı kutuda gösterir (`kanit` bağlamı: sıra 1 den başlar)."""
        kanit = self.bulmaca.kanitlar[sira0]
        ekran.baglam("kanit", sira=sira0 + 1, etiket=kanit.etiket,
                     icerik=kanit.icerik)
        self._arsive_yaz("kanit", kanit.etiket, kanit.icerik)
        ekran.kutu(kanit.icerik, kanit.etiket, "beyaz")

    def _arsive_yaz(self, tur: str, etiket: str, metin: str) -> None:
        """Meridyen OS Arşivi (bkz. arsiv.py); arşiv yüzünden görev durmasın."""
        if self.durum is None:
            return
        try:
            from . import arsiv
            arsiv.ekle(self.durum, tur, self.bulmaca.baslik, metin,
                       ders=self.bulmaca.ders_adi or self.bulmaca.ders,
                       etiket=etiket)
        except Exception:  # noqa: BLE001
            pass

    def _adim_sonuc_olayi(self, sira: int, sonuc: AdimSonucu) -> None:
        ekran.baglam("adim_sonuc", sira=sira, dogru=sonuc.dogru,
                     deneme=sonuc.deneme, puan=sonuc.puan)

    def _gorev_basla_olayi(self) -> None:
        b = self.bulmaca
        acik_hepsi = self.asama != SERBEST     # anlatım/birlikte: bedelsiz açık
        konu = ""
        if self.durum is not None:
            from .anlati import konu_kimligi
            if konu_kimligi(b.ders, b.konu) in self.durum.kesfedilen_konular:
                konu = b.konu
        ekran.baglam(
            "gorev_basla", kod=b.kod, baslik=b.baslik, ders=b.ders,
            ders_adi=b.ders_adi, konu=konu, kademe=b.kademe, asama=self.asama,
            brifing=b.brifing,
            kanitlar=[{"sira": i, "etiket": k.etiket,
                       "bedel": 0 if acik_hepsi else k.bedel,
                       "acik": acik_hepsi or (i - 1) in self.acilan}
                      for i, k in enumerate(b.kanitlar, 1)],
            adim_sayisi=len(b.adimlar),
            dikkat={"kalan": self.kalan_dikkat, "tavan": self.dikkat_tavani})

    def _adim_olayi(self, adim: Adim, sira: int, toplam: int,
                    komutlar: list, deneme: int = 0) -> None:
        ekran.baglam(
            "adim", sira=sira, toplam=toplam, soru=adim.soru, tur=adim.tur,
            rol=adim.rol, secenekler=list(adim.secenekler), birim=adim.birim,
            komutlar=[{"tus": t, "ad": a} for t, a in komutlar],
            kalan_dikkat=self.kalan_dikkat, deneme=deneme)

    def _serbest_komutlar(self, adim: Adim, yanlis_yapildi: bool = False,
                          kullanilan_ipucu: int = 0,
                          cozum_acildi: bool = False) -> list:
        """Serbest aşamada o an geçerli komutlar (komut satırıyla aynı kaynak)."""
        etiketler = {"i": "ipucu", "c": "çözüm", "o": "örnek", "k": "kaynaklar"}
        komutlar = [(h, etiketler.get(h, e)) for h, e in self._mevcut_yardimlar(
            adim, yanlis_yapildi, kullanilan_ipucu, cozum_acildi)]
        komutlar += [("b", "brifing"), ("d", "defter")]
        if self._sinifta_mi():
            komutlar.append(("e", "el kaldır"))
        komutlar += [("x", "çıkış"), ("?", "tümü")]
        return komutlar

    def _defter(self) -> None:
        if not self.acilan:
            ekran.bilgi("Defterin boş. Henüz hiçbir kaynağı incelemedin.")
            return
        ekran.yaz()
        for indeks in self.acilan:
            self._kanit_goster(indeks)

    def _kanit_ac(self) -> None:
        b = self.bulmaca
        if not b.kanitlar:
            ekran.bilgi("Bu görevde ayrı kaynak yok.")
            return
        self._kanit_listesi()
        cevap = ekran.sor("Hangi kaynağı inceleyeyim? (numara / boş: vazgeç)")
        if not cevap.strip():
            return
        if not cevap.strip().isdecimal():
            ekran.hata("Numara yaz.")
            return
        sira = int(cevap.strip()) - 1
        if not (0 <= sira < len(b.kanitlar)):
            ekran.hata("Öyle bir kaynak yok.")
            return
        kanit = b.kanitlar[sira]
        if sira in self.acilan:
            self._kanit_goster(sira)
            return
        if self.kalan_dikkat < kanit.bedel:
            ekran.hata("Dikkatin kalmadı. Elindekilerle çözmeyi dene.")
            return
        self._dikkat_harca(kanit.bedel)
        self.acilan.append(sira)
        ekran.yaz()
        self._kanit_goster(sira)

    def _sinifta_mi(self) -> bool:
        """Öğretmenin açtığı bir sınıfa bağlı mıyız?"""
        return bool(getattr(self.durum, "sinif_kodu", "") or "")

    def _el_kaldir(self, adim) -> None:
        """Sessiz el kaldırma. Bkz. araclar/el_kaldirma.py -- orada NEDEN'i var.

        Buradaki tek incelik EKRANDA OLAN: bildiri sessiz olmalı. Büyük bir
        kutu, ses ya da "bildirildi!" kutlaması, öğrenciyi yardım istemekten
        caydırır -- utandığı için sormayan öğrenci için yapıldı bu.
        """
        from araclar import el_kaldirma

        konu = getattr(self.bulmaca, "konu", "") or getattr(self.bulmaca, "ders", "")
        baslik = (getattr(adim, "soru", "") or "").strip()
        if el_kaldirma.zaten_bildirdi(self.durum, konu, baslik):
            ekran.yaz("   Bu soruyu zaten bildirdin; öğretmen listesinde "
                      "duruyor.", "gri")
            return
        if not ekran.onayla("Bu soruyu öğretmene bildirelim mi? "
                            "(Adın gitmez, sınıf görmez)", True):
            return
        try:
            el_kaldirma.el_kaldir(self.durum.sinif_kodu, konu, baslik)
        except OSError:
            # Ortak klasör yoksa ya da yazılamıyorsa oyun DURMASIN.
            ekran.yaz("   Şu an bildirilemedi; öğretmene sözlü söyleyebilirsin.",
                      "gri")
            return
        el_kaldirma.bildirildi_isaretle(self.durum, konu, baslik)
        ekran.yaz("   Bildirildi. Öğretmen bu soruyu tahtaya yazıp anlatacak.",
                  "gri")
        ekran.yaz("   Sen istersen çözmeyi denemeye devam et.", "gri")

    def _yardim(self, yanlis_yapildi: bool = False) -> None:
        ekran.yaz()
        ekran.yaz("KOMUTLAR", "kalin", "acik_sari")
        for harf, aciklama in KOMUT_YARDIMI:
            # Örnek isteme komutu, henüz denemeyen öğrenciye gösterilmez:
            # baştan çözülmüş örnek istemek soruyu çözmek değil, kopyalamaktır.
            if harf in YANLIS_SONRASI_KOMUTLAR and not yanlis_yapildi:
                continue
            if harf in SINIF_KOMUTLARI and not self._sinifta_mi():
                continue
            ekran.madde("{} = {}".format(ekran.renkli(harf, "acik_sari", "kalin"), aciklama))
        ekran.madde("Diğer her şey cevap olarak okunur.")

    # ------------------------------------------------------------------ akış
    def oyna(self) -> BulmacaSonucu:
        """Aşamaya göre uygun oynanışı çalıştırır."""
        if ekran.olayli():
            self._gorev_basla_olayi()
        if self.asama == ANLATIM:
            sonuc = self._anlatim_oyna()
        elif self.asama == BIRLIKTE:
            sonuc = self._birlikte_oyna()
        else:
            sonuc = self._serbest_oyna()
        # Görevden çekilse bile gördüğü teşhisler sayılır: yarıda bırakılan
        # görev de "burada takıldı" bilgisidir. Aynı teşhis tek görevde birkaç
        # kez çıkabilir; teke indiriyoruz ki karnedeki sayı "kaç GÖREVDE bu
        # hataya düştü" anlamına gelsin - tek görevde kaç kez denediğine değil.
        sonuc.teshisler = list(dict.fromkeys(self.gorulen_teshisler))
        from .anlati import kesif_metni, konu_kimligi, kapanis_metni
        kesif = kesif_metni(self.bulmaca, sonuc)
        if kesif:
            ekran.kutu(kesif, "DOSYANIN ARDINDAKİ BECERİ", "acik_cam")
            if self.durum is not None:
                kimlik = konu_kimligi(self.bulmaca.ders, self.bulmaca.konu)
                if kimlik not in self.durum.kesfedilen_konular:
                    self.durum.kesfedilen_konular.append(kimlik)
            kapanis = kapanis_metni(self.durum)
            if kapanis:
                ekran.yaz(kapanis, "gri")
        self._arsive_yaz("rapor", self.bulmaca.kod, self._rapor_metni(sonuc))
        ekran.baglam("gorev_bitti", puan=sonuc.puan, azami_puan=sonuc.azami_puan,
                     tamamlandi=sonuc.tamamlandi, birakildi=sonuc.birakildi,
                     yildiz=sonuc.yildiz)
        return sonuc

    @staticmethod
    def _rapor_metni(sonuc) -> str:
        durum = ("Bırakıldı" if sonuc.birakildi
                 else "Tamamlandı" if sonuc.tamamlandi else "Bitti")
        return "{}\nPuan: {} / {}\nYıldız: {}{}".format(
            durum, sonuc.puan, sonuc.azami_puan,
            "★" * int(sonuc.yildiz or 0), "☆" * max(0, 3 - int(sonuc.yildiz or 0)))

    # ------------------------------------------------------- 1) ANLATIM
    def _tum_kanitlari_goster(self, baslik: str = "") -> None:
        """Anlatım ve birlikte aşamalarında kanıtlar bedelsiz açıktır."""
        b = self.bulmaca
        if not b.kanitlar:
            return
        ekran.yaz()
        ekran.yaz(baslik or "ELİMİZDEKİ KAYNAKLAR", "kalin", self.renk)
        for sira0 in range(len(b.kanitlar)):
            self._kanit_goster(sira0)
        self.acilan = list(range(len(b.kanitlar)))

    def _anlatim_oyna(self) -> BulmacaSonucu:
        """
        Çözülmüş örnek. Öğrenci cevap vermez; okur.

        Amaç, öğrencinin konuyla ilk karşılaşmasının bir sınav olmaması.
        Önce nasıl düşünüldüğünü görür, sonra kendi denemesi istenir.
        """
        b = self.bulmaca
        self._ust_bilgi()
        ekran.kutu(ASAMA_ACIKLAMALARI[ANLATIM], "DEVİR TESLİM", "acik_yesil")
        self._brifing_goster()
        ekran.bekle("Kaynaklara bakalım - Enter")

        self._tum_kanitlari_goster()
        ekran.yaz()
        ekran.yaz("Bunlar elimizdeki bütün bilgiler. Şimdi nasıl düşünüldüğüne "
                  "bakalım.", "gri")
        ekran.bekle()

        for sira, adim in enumerate(b.adimlar, 1):
            ekran.yaz()
            ekran.ayrac()
            etiket = ROL_ETIKETI.get(adim.rol, "SORU")
            renk = "acik_mor" if adim.rol == MODEL else self.renk
            self._adim_olayi(adim, sira, len(b.adimlar), [])
            ekran.yaz("{}  ({}/{})".format(etiket, sira, len(b.adimlar)), "kalin", renk)
            ekran.yaz()
            ekran.yaz(adim.soru, "beyaz")

            if adim.secenekler:
                ekran.yaz()
                for i, secenek in enumerate(adim.secenekler, 1):
                    isaret = "->" if self._dogru_sik_mi(adim, i - 1) else "  "
                    ekran.asili_yaz("  {} {}) ".format(isaret, i), secenek,
                                    onek_renkleri=("acik_yesil",)
                                    if isaret.strip() else ("gri",))

            ekran.yaz()
            ekran.basari("Cevap: " + dogru_cevap_metni(adim))

            if adim.cozum:
                ekran.yaz()
                ekran.kutu(adim.cozum, "NASIL BULUNDU", "acik_yesil")
            if adim.aciklama:
                ekran.yaz()
                ekran.kutu(adim.aciklama, "NEDEN", "gri")

            if sira < len(b.adimlar):
                ekran.bekle("Sonraki adım - Enter")

        if b.kapanis:
            ekran.yaz()
            ekran.kutu(b.kapanis, "SONRASI", "beyaz")

        ekran.yaz()
        ekran.kutu(
            "Anlatım bitti. Şimdi aynı işi birlikte yapacağız: olay aynı olacak "
            "ama sayılar değişecek. Ezberlemene gerek yok, nasıl düşünüldüğünü "
            "hatırlaman yeterli.",
            "SIRA SENDE", "acik_sari")
        ekran.bekle()

        return BulmacaSonucu(
            bulmaca_kodu=b.kod, ders=b.ders, kademe=b.kademe, konu=b.konu,
            puan=0, azami_puan=0, tamamlandi=True, asama=ANLATIM,
        )

    def _dogru_sik_mi(self, adim: Adim, indeks: int) -> bool:
        if adim.tur == SECIM:
            return indeks == int(adim.cevap)
        if adim.tur in (COKLU, SIRALA):
            try:
                return indeks in [int(x) for x in adim.cevap]
            except (TypeError, ValueError):
                return False
        return False

    # ------------------------------------------------------- 2) BİRLİKTE
    def _birlikte_oyna(self) -> BulmacaSonucu:
        """
        Yol gösterilir, kararı öğrenci verir.

        Yanlış cevabın bedeli yoktur: her yanlıştan sonra yardım bir kademe
        artar ve sonunda cevap gösterilip devam edilir. Amaç öğrenciyi
        durdurmak değil, bir sonraki adıma taşımak.
        """
        b = self.bulmaca
        sonuc = BulmacaSonucu(
            bulmaca_kodu=b.kod, ders=b.ders, kademe=b.kademe, konu=b.konu,
            puan=0, azami_puan=0, asama=BIRLIKTE,
        )

        self._ust_bilgi()
        ekran.kutu(ASAMA_ACIKLAMALARI[BIRLIKTE], "YANINDAYIM", "acik_sari")
        self._brifing_goster()
        self._tum_kanitlari_goster()
        ekran.yaz()
        ekran.yaz("Sayılar anlatımdakinden farklı; kaynakları yeniden oku.", "gri")
        ekran.bekle()

        for sira, adim in enumerate(b.adimlar, 1):
            adim_sonucu = self._birlikte_adim(adim, sira, len(b.adimlar))
            if adim_sonucu is None:
                sonuc.birakildi = True
                return sonuc
            self._adim_sonuc_olayi(sira, adim_sonucu)
            sonuc.adim_sonuclari.append(adim_sonucu)

        sonuc.tamamlandi = True
        if b.kapanis:
            ekran.yaz()
            ekran.kutu(b.kapanis, "SONRASI", "beyaz")
        return sonuc

    def _birlikte_yardim(self) -> None:
        ekran.yaz()
        ekran.yaz("BU AŞAMADA", "kalin", "acik_sari")
        for harf, aciklama in BIRLIKTE_KOMUTLARI:
            ekran.asili_yaz("  {}  ".format(harf), aciklama,
                            onek_renkleri=("acik_sari",))
        ekran.yaz()
        ekran.yaz("Yol gösterme zaten açık ve bedelsiz; ipucu istemene "
                  "gerek yok.", "gri")

    def _birlikte_adim(self, adim: Adim, sira: int, toplam: int) -> Optional[AdimSonucu]:
        if ekran.olayli():
            komutlar = [("b", "brifing"), ("d", "kanıtlar")]
            if self._sinifta_mi():
                komutlar.append(("e", "el kaldır"))
            komutlar += [("x", "çıkış"), ("?", "yardım")]
            self._adim_olayi(adim, sira, toplam, komutlar)
        ekran.yaz()
        ekran.ayrac()
        etiket = ROL_ETIKETI.get(adim.rol, "SORU")
        renk = "acik_mor" if adim.rol == MODEL else self.renk
        ekran.yaz("{}  ({}/{})".format(etiket, sira, toplam), "kalin", renk)
        if adim.rol == MODEL:
            ekran.yaz("Burada hesap yok; nasıl ilerleyeceğimizi söylemen yeterli.",
                      "gri")
        ekran.yaz()
        ekran.yaz(adim.soru, "beyaz")

        if adim.secenekler:
            ekran.yaz()
            for i, secenek in enumerate(adim.secenekler, 1):
                ekran.asili_yaz("  {:>2}) ".format(i), secenek,
                                onek_renkleri=("acik_sari",))

        # Yol gösterme bedelsiz ve baştan verilir: bu aşamanın tamamı yardımdır.
        if adim.ipuclari:
            ekran.yaz()
            ekran.kutu(adim.ipuclari[0], "YOL GÖSTERME", "acik_sari")

        # Bu asamada da komut satiri gorunsun. Bagimsiz bir oyun testi
        # (8 Eylul 2026) sunu buldu: ogrenci serbest asamada ogrendigi
        # i/c/k/o/? tuslarini DESTEK asamasinda kullanamiyor ve tuslar
        # CEVAP sayilip deneme hakkini yiyordu -- ustelik uydurma bir
        # teshis uretiliyordu. Yardim tusuna basmanin hata sayilmasi
        # §0'in tam tersi.
        ekran.yaz()
        # Serbest asamadaki gibi tek satirda; "el kaldir" yalnizca sinifa
        # bagli ogrencide. Elle yazilmis sabit satir DEGIL: 50 sutunluk
        # telefonda sabit satir ortasindan kiriliyordu.
        parcalar = ["b brifing", "d kanıtlar"]
        if self._sinifta_mi():
            parcalar.append("e el kaldır")
        parcalar += ["x çıkış", "? yardım"]
        for satir in ekran.komut_satirlari(parcalar):
            ekran.yaz(satir, "gri")

        istem = self._istem_metni(adim)
        deneme = 0
        gosterilen_ipucu = 1 if adim.ipuclari else 0

        bos_uyarildi = False
        while True:
            ham = ekran.sor(istem).strip()

            if not ham:
                # Uyari YALNIZCA ilk bos gonderimde. Telefonda "Gonder"e
                # yanlislikla iki kez dokunmak cok kolay ve ayni satir
                # ust uste yazilinca ekranin yarisini dolduruyordu
                # (9 Eylul 2026, 375 px ekranda goruldu). Dikey yer
                # telefonda kittir; ayni cumleyi tekrarlamak bilgi vermiyor.
                if not bos_uyarildi:
                    ekran.yaz("Bir şey yaz; yanlış olursa da devam ederiz.",
                              "gri")
                    bos_uyarildi = True
                continue
            bos_uyarildi = False
            komut = ham.lower()
            if komut == "x":
                if ekran.onayla("Bu görevden çıkmak istiyor musun?", False):
                    return None
                continue
            if komut == "b":
                self._brifing_goster()
                continue
            if komut == "d":
                self._tum_kanitlari_goster()
                continue
            if komut in ("?", "y"):
                self._birlikte_yardim()
                continue
            if komut == "e" and self._sinifta_mi():
                # Yaninda birisi varken bile takilabilir; "yanindayim"
                # asamasi el kaldirmayi gereksiz kilmaz.
                self._el_kaldir(adim)
                continue
            # Serbest asamanin tuslari burada YOK ama basana ceza da yok:
            # deneme hakki yenmiyor, uydurma teshis uretilmiyor. Neden
            # olmadigi soyleniyor ve devam ediliyor.
            if komut in ("i", "c", "k", "o"):
                ekran.yaz()
                ekran.bilgi(BIRLIKTE_KOMUT_ACIKLAMA.get(komut, ""))
                continue

            deneme += 1
            dogru, geri_bildirim = degerlendir(adim, ham)

            if dogru:
                ekran.yaz()
                ekran.basari("Doğru. Böyle devam.")
                self._aciklama_goster(adim)
                return AdimSonucu(True, 0, deneme, 0, adim.rol, ham)

            ekran.yaz()
            if geri_bildirim:
                ekran.hata("Olmadı. " + geri_bildirim)
            else:
                ekran.hata("Olmadı.")
            self._teshis_goster(adim, ham)

            # Yardım kademe kademe artar
            if gosterilen_ipucu < len(adim.ipuclari):
                ekran.yaz()
                ekran.kutu(adim.ipuclari[gosterilen_ipucu], "BİR İPUCU DAHA", "acik_sari")
                gosterilen_ipucu += 1
                continue

            if adim.cozum and deneme >= 2:
                ekran.yaz()
                ekran.kutu(adim.cozum, "BİRLİKTE ÇÖZELİM", "acik_yesil")
                ekran.yaz("Çözümü okudun; cevabı şimdi sen yaz.", "gri")
                if deneme >= 3:
                    ekran.yaz()
                    ekran.yaz("Cevap: " + dogru_cevap_metni(adim), "acik_sari", "kalin")
                    self._aciklama_goster(adim)
                    ekran.bekle("Bir sonraki adıma geçiyoruz - Enter")
                    return AdimSonucu(False, 0, deneme, gosterilen_ipucu, adim.rol, ham)
                continue

            if deneme >= 3:
                ekran.yaz()
                ekran.yaz("Cevap: " + dogru_cevap_metni(adim), "acik_sari", "kalin")
                self._aciklama_goster(adim)
                ekran.bekle("Bir sonraki adıma geçiyoruz - Enter")
                return AdimSonucu(False, 0, deneme, gosterilen_ipucu, adim.rol, ham)

    # ------------------------------------------------------- 3) SERBEST
    def _serbest_oyna(self) -> BulmacaSonucu:
        b = self.bulmaca
        sonuc = BulmacaSonucu(
            bulmaca_kodu=b.kod, ders=b.ders, kademe=b.kademe, konu=b.konu,
            puan=0, azami_puan=b.azami_puan, asama=SERBEST,
        )

        self._ust_bilgi()
        self._brifing_goster()
        self._kanit_listesi()
        ekran.yaz()
        ekran.yaz("Kaynakları şimdi ya da soruların arasında inceleyebilirsin. "
                  "Komut listesi için ? yaz.", "gri")

        # Serbest inceleme aşaması
        while True:
            cevap = ekran.sor("İncele (numara), başla (Enter), yardım (?):").strip()
            if not cevap:
                break
            if cevap in ("?", "y"):
                self._yardim()
                continue
            if cevap.lower() == "x":
                sonuc.birakildi = True
                return sonuc
            if cevap.lower() == "b":
                self._brifing_goster()
                continue
            if cevap.lower() == "d":
                self._defter()
                continue
            if cevap.isdecimal():
                sira = int(cevap) - 1
                if 0 <= sira < len(b.kanitlar):
                    kanit = b.kanitlar[sira]
                    if sira not in self.acilan:
                        if self.kalan_dikkat < kanit.bedel:
                            ekran.hata("Dikkatin kalmadı.")
                            continue
                        self._dikkat_harca(kanit.bedel)
                        self.acilan.append(sira)
                    ekran.yaz()
                    self._kanit_goster(sira)
                    self._kanit_listesi()
                    continue
            ekran.hata("Anlamadım. Kaynak numarası yaz ya da başlamak için Enter'a bas.")

        # Adımlar
        for sira, adim in enumerate(b.adimlar, 1):
            adim_sonucu = self._adimi_oyna(adim, sira, len(b.adimlar))
            if adim_sonucu is None:
                sonuc.birakildi = True
                sonuc.acilan_kanit = len(self.acilan)
                return sonuc
            self._adim_sonuc_olayi(sira, adim_sonucu)
            sonuc.adim_sonuclari.append(adim_sonucu)
            sonuc.puan += adim_sonucu.puan

        sonuc.tamamlandi = True
        sonuc.acilan_kanit = len(self.acilan)
        return sonuc

    def _adimi_oyna(self, adim: Adim, sira: int, toplam: int) -> Optional[AdimSonucu]:
        """Tek adımı oynatır. Oyuncu çekilirse None döner."""
        azami_deneme = 2 if adim.tur in SIKLI_TURLER else 3
        kullanilan_ipucu = 0
        deneme = 0
        cozum_acildi = False
        # Örnek (o) komutunun durumu. `yanlis_var` komutun kapısıdır;
        # `ornek_arandi` üretimi tek sefere indirir (bulunamadıysa her
        # istekte içeriği yeniden taramanın anlamı yok); `ornek_acildi`
        # puan etkisinin bir kez uygulanmasını sağlar.
        yanlis_var = False
        ornek_arandi = False
        ornek_bulmaca: Optional[Bulmaca] = None
        ornek_acildi = False
        # Bu adımda zaten başvurulan yardımlar. Takılan öğrenciye yapılan
        # öneri (oyuncu.yardim_onerisi) bunları geçip bir sonrakine iner:
        # zorlanma sürdükçe destek de bir basamak artar (§0, B35.10).
        basvurulan = set()

        if ekran.olayli():
            self._adim_olayi(adim, sira, toplam, self._serbest_komutlar(adim))
        ekran.yaz()
        ekran.ayrac()
        etiket = ROL_ETIKETI.get(adim.rol, "SORU")
        renk = "acik_mor" if adim.rol == MODEL else self.renk
        ekran.yaz("{}  ({}/{})".format(etiket, sira, toplam), "kalin", renk)
        if adim.rol == MODEL:
            ekran.yaz("Önce nasıl ilerleyeceğimize karar ver.", "gri")
        self._soru_govdesi(adim)

        # Komutlar HER SORUDA gorunur. Onceden yalnizca "?" yazan ogrenci
        # bunlari bilirdi; takilan ogrenci ise cikis oldugunu bilmedigi icin
        # rastgele cevap veriyordu. §0 geregi cikmak mesru bir secenek:
        # yapamadigini kabul edip birakmak, tahmin etmekten iyidir.
        ekran.yaz()
        ekran.yaz(self._komut_satiri(adim), "gri")

        istem = self._istem_metni(adim)

        bos_uyarildi = False
        while deneme < azami_deneme:
            ham = ekran.sor(istem).strip()

            if not ham:
                # Bkz. yukaridaki ayni gerekce: tekrar eden uyari ekrani
                # doldurup asil soruyu yukari itiyor.
                if not bos_uyarildi:
                    ekran.hata("Bir şeyler yaz. Emin değilsen i ile ipucu "
                               "isteyebilirsin.")
                    bos_uyarildi = True
                continue
            bos_uyarildi = False

            komut = ham.lower()
            if komut == "?":
                self._yardim(yanlis_yapildi=yanlis_var)
                continue
            if komut == "o":
                if not yanlis_var:
                    # Baştan örnek istemek soruyu çözmek değil, kopyalamaktır.
                    ekran.bilgi("Örnek, bir kez denedikten sonra açılır. "
                                "Önce kendi cevabını yaz; tutmazsa basit bir "
                                "örneğe birlikte bakarız.")
                    continue
                basvurulan.add("o")
                if not ornek_arandi:
                    ornek_arandi = True
                    ornek_bulmaca = self._ornek_uret()
                if ornek_bulmaca is None:
                    if self._basit_calisma_teklif_et(adim):
                        self._soru_govdesi(adim)
                    continue
                if not ornek_acildi:
                    ornek_acildi = True
                    ekran.bilgi("Örnek, bu adımın puanından bir ipucu kadar "
                                "düşer. Dikkat harcamaz.")
                self._ornek_goster(ornek_bulmaca)
                ekran.bekle("Kendi sorumuza dönelim - Enter")
                self._soru_govdesi(adim)
                continue
            if komut == "k":
                basvurulan.add("k")
                self._kanit_ac()
                continue
            if komut == "d":
                self._defter()
                continue
            if komut == "e" and self._sinifta_mi():
                basvurulan.add("e")
                self._el_kaldir(adim)
                continue
            if komut == "b":
                self._brifing_goster()
                continue
            if komut == "x":
                if ekran.onayla("Bu görevi şimdilik bırakalım mı? "
                                "(İstediğin zaman yenisini alabilirsin)", False):
                    return None
                continue
            if komut == "i":
                if not self.ipucu_acik:
                    ekran.bilgi("Bu oyunda ipuçları kapalı.")
                    continue
                if kullanilan_ipucu >= len(adim.ipuclari):
                    ekran.bilgi("Bu soru için başka ipucu yok.")
                    continue
                ekran.yaz()
                ekran.kutu(adim.ipuclari[kullanilan_ipucu],
                           "İPUCU {}/{}".format(kullanilan_ipucu + 1, len(adim.ipuclari)),
                           "acik_sari")
                kullanilan_ipucu += 1
                continue

            if komut in ("c", "ç"):
                cozum_metni, cozum_basligi = self._cozum_metni(adim)
                if cozum_metni is None:
                    ekran.bilgi("Bu adım için yazılmış bir çözüm yok.")
                    self._basit_calisma_teklif_et(adim)
                    self._soru_govdesi(adim)
                    continue
                if cozum_acildi:
                    ekran.yaz()
                    ekran.kutu(cozum_metni, cozum_basligi, "acik_yesil")
                    continue
                if self.kalan_dikkat < adim.cozum_bedeli:
                    ekran.hata("Çözümü açmak {} dikkat ister, o kadar kalmadı. "
                               "Elindekilerle dene.".format(adim.cozum_bedeli))
                    continue
                if not ekran.onayla(
                        "{} {} dikkat harcar ve bu adımdan alabileceğin puanın "
                        "tavanını %{} yapar. Açılsın mı?".format(
                            COZUM_ADLARI.get(cozum_basligi, "Çözüm"),
                            adim.cozum_bedeli,
                            int(COZUM_TAVANI * 100)), False):
                    continue
                self._dikkat_harca(adim.cozum_bedeli)
                cozum_acildi = True
                ekran.yaz()
                ekran.kutu(cozum_metni, cozum_basligi, "acik_yesil")
                ekran.yaz("Çözümü okudun. Şimdi cevabı kendin yaz.", "gri")
                continue

            deneme += 1
            dogru, geri_bildirim = degerlendir(adim, ham)

            if dogru:
                puan = self._puan_hesapla(adim, deneme, kullanilan_ipucu,
                                          cozum_acildi, ornek_acildi)
                ekran.yaz()
                ekran.basari("Doğru. +{} puan".format(puan))
                self._aciklama_goster(adim)
                return AdimSonucu(True, puan, deneme, kullanilan_ipucu, adim.rol, ham,
                                  cozum_gordu=cozum_acildi, ornek_gordu=ornek_acildi)

            yanlis_var = True
            kalan = azami_deneme - deneme
            ekran.yaz()
            if geri_bildirim:
                ekran.hata("Olmadı. " + geri_bildirim)
            else:
                ekran.hata("Olmadı.")
            self._teshis_goster(adim, ham)
            if kalan > 0:
                # Örnek yalnızca buradan sonra anlamlı: bir kez denendi.
                # Liste `_mevcut_yardimlar`dan geliyor -- adım başındaki
                # komut satırıyla AYNI kaynak. Ayrı yazıldıklarında biri
                # düzeltilip diğeri yalan söylemeye devam ediyordu.
                mevcut = self._mevcut_yardimlar(
                    adim, yanlis_yapildi=True,
                    kullanilan_ipucu=kullanilan_ipucu,
                    cozum_acildi=cozum_acildi)
                # Ankette "zorlanınca ne yaparsın" cevabı varsa o yardım
                # öne gelir. Hiçbiri düşmez; cevap yoksa sıra aynen kalır.
                if ekran.olayli():
                    self._adim_olayi(
                        adim, sira, toplam,
                        self._serbest_komutlar(adim, True, kullanilan_ipucu,
                                               cozum_acildi), deneme)
                mevcut = oyuncu.yardim_sirala(self.durum, mevcut)
                # "tam çözüm" DEME: adımların %87'sinde açılan şey adıma
                # özel bir çözüm değil, "nasıl düşünülür" açıklaması. İkisi
                # de işe yarar ama söz büyük olursa öğrenci başka bir şey
                # bekler. Olmayanı vaat etmemek E01'in tam konusu.
                etiketler = {"i": "ipucu", "c": "çözüm",
                             "o": "basit örnek", "k": "kanıtlar"}
                yardim = ", ".join("{} = {}".format(h, etiketler.get(h, e))
                                   for h, e in mevcut)
                if yardim:
                    ekran.yaz("{} hakkın kaldı. ({})".format(kalan, yardim),
                              "gri")
                else:
                    # Bu adimda ipucu da cozum de kaynak da YOK. Olcumde
                    # adimlarin %5,6'si boyle. Eskiden yine de "i = ipucu,
                    # k = kanitlar" yaziyordu ve ogrenci deneme hakkini
                    # olmayan yardimi ararken harciyordu. (E01)
                    ekran.yaz("{} hakkın kaldı. Bu adımda hazır bir yardım "
                              "yok.".format(kalan), "gri")
                adaylar = list(mevcut)
                if self._sinifta_mi():
                    adaylar.append(("e", "el kaldır"))
                atla = set(basvurulan)
                if not cozum_acildi and self.kalan_dikkat < adim.cozum_bedeli:
                    # Açılamayacak çözümü önermek, olmayan yardımı ilan
                    # etmekle aynı şey (E01).
                    atla.add("c")
                oneri = oyuncu.yardim_onerisi(self.durum, adaylar, atla)
                if oneri:
                    ekran.yaz(oneri, "acik_cam")

        # Hakkı bitti
        ekran.yaz()
        ekran.yaz("Doğru cevap: " + dogru_cevap_metni(adim), "acik_sari", "kalin")
        if adim.cozum:
            # Hakkı bitince çözüm bedelsiz gösterilir: amaç ceza değil öğrenmek.
            ekran.yaz()
            ekran.kutu(adim.cozum, "TAM ÇÖZÜM", "acik_yesil")
        # Açıklama "c" ile zaten açıldıysa tekrar basma: aynı metni iki kez
        # göstermek öğrenciye yeni bir şey vermez, ekranı doldurur.
        # (`cozum` varsa "c" onu açmıştı, açıklama yine de yeni bilgidir.)
        if not (cozum_acildi and not adim.cozum):
            self._aciklama_goster(adim)
        return AdimSonucu(False, 0, azami_deneme, kullanilan_ipucu, adim.rol, "",
                          cozum_gordu=cozum_acildi, ornek_gordu=ornek_acildi)

    def _basit_calisma_teklif_et(self, adim: Adim) -> bool:
        """Basit örnek yokken çıkmaz sokak yerine merdiveni önerir.

        NEDEN
        -----
        Öğrenci takıldı ve "o" yazdı. Eskiden cevap şuydu: "Bu konu için
        daha basit bir örnek yok. İpucu (i) ya da tam çözüm (c)
        deneyebilirsin." -- ikisi de çoğu adımda YOK olduğu için bu bir
        çıkmaz sokaktı. Üstelik B9.6c'de "örnek bulunamazsa dürüstçe
        söyle" demiştim ama dürüst olmak yetmiyor; alternatif lazım. (E01)

        Merdiven zaten vardı ama YALNIZCA görev bittikten sonra
        öneriliyordu (`oyun.py::_merdiven_teklif_et`). Yani öğrenci
        takıldığı ANDA değil, takılmayı bitirdikten sonra. Asıl ihtiyaç
        duyduğu yer burası.

        Dönüş: merdiven oynandıysa True (soru yeniden çizilmeli).
        """
        konu = getattr(self.bulmaca, "konu", "")
        ders = getattr(self.bulmaca, "ders", "")
        if not konu or self.durum is None:
            self._son_care_metni(adim)
            return False

        from . import merdiven
        # Merdiven ÜRETİLEBİLİYOR mu? Üretmeden teklif etmek, öğrenciyi
        # "evet" dedirtip boş ekrana götürmek olurdu.
        try:
            basamaklar = merdiven.merdiven_uret(
                ders, konu, self.bulmaca.kademe,
                self.durum.rastgele("merdiven"))
        except Exception:              # noqa: BLE001 - destek yolu oyunu durduramaz
            basamaklar = []
        if not basamaklar:
            self._son_care_metni(adim)
            return False

        ekran.yaz()
        ekran.bilgi("Bu soru için hazır bir örnek yok. Ama aynı konuyu "
                    "basitten başlayarak birlikte çalışabiliriz.")
        if not ekran.onayla("Basit alıştırmalara geçelim mi? "
                            "(Sonra bu soruya dönersin)", True):
            return False
        merdiven.merdiveni_oyna(self.durum, ders, konu, self.bulmaca.kademe)
        ekran.temizle()
        return True

    def _son_care_metni(self, adim: Adim) -> None:
        """Gerçekten hiçbir destek kalmadığında ne diyeceğiz.

        Olmayan yardımı önermek yerine elde NE olduğunu söylüyoruz. Boş
        bir vaat, öğrencinin deneme hakkını arama yaparak harcamasına yol
        açıyordu.
        """
        kalanlar = [e for _, e in self._mevcut_yardimlar(adim,
                                                         yanlis_yapildi=False)]
        if kalanlar:
            ekran.bilgi("Bu konu için daha basit bir örnek yok. "
                        "Elinde şunlar var: " + ", ".join(kalanlar) + ".")
        else:
            ekran.bilgi("Bu soru için hazır bir yardım yok. Denemeye devam "
                        "et; hakkın bitince doğru cevabı ve açıklamasını "
                        "birlikte göreceğiz.")

    def _cozum_metni(self, adim: Adim):
        """"c" komutunun gosterecegi metin ve basligi. Yoksa (None, None).

        IKI KAYNAK VAR VE BU BILEREK BOYLE
        ----------------------------------
        `cozum` adima ozel yazilmis tam cozum. `aciklama` ise "neden boyle"
        metni -- hakki bitince zaten gosteriliyor.

        9 Eylul 2026 olcumu (`main.py --yardim-kapsamasi`):
            cozum metni olmayan adim : 6036 / 6915  (%87,3)
            aciklamasi olmayan adim  :    0 / 6915  (%0,0)

        Yani icerik ZATEN VARDI; yalnizca "hakkini tuket, sonra gor" diye
        kilitliydi. Takilan ogrenci istedigi anda alamiyordu. 6000 metin
        yazmak yerine var olani ise kostuk: `cozum` yoksa `aciklama`
        gosteriliyor, AYNI bedelle ve AYNI puan taviniyla (COZUM_TAVANI).
        Sozlesme degismedi, yalnizca kaynak genisledi.

        Aciklamalar bunu kaldiriyor: cevabi soylemiyorlar, nasil
        dusunulecegini anlatiyorlar -- yani zaten bir cozum metni gibi
        yazilmislar. (E01)
        """
        ozel = (getattr(adim, "cozum", "") or "").strip()
        if ozel:
            return ozel, "TAM ÇÖZÜM"
        genel = (getattr(adim, "aciklama", "") or "").strip()
        if genel:
            return genel, "NASIL DÜŞÜNÜLÜR"
        return None, None

    def _cozum_var_mi(self, adim: Adim) -> bool:
        """Bu adimda GERCEKTEN okunacak bir cozum metni var mi?

        DIKKAT: `cozum_bedeli` ile gosterilecek metin AYRI seylerdir. Bedel
        neredeyse her adimda tanimli; bedele bakip "c cozum" yazmak olmayan
        bir yardimi ilan etmek demekti -- ogrenci deneme hakkini o yardimi
        ARAMAKLA harciyordu. (E01)
        """
        return self._cozum_metni(adim)[0] is not None

    def _mevcut_yardimlar(self, adim: Adim, yanlis_yapildi: bool = False,
                          kullanilan_ipucu: int = 0,
                          cozum_acildi: bool = False) -> list:
        """Su AN kullanilabilir yardimlarin (harf, etiket) listesi.

        Tek kaynak: hem adim basindaki komut satiri hem yanlistan sonraki
        oneri buradan besleniyor. Ikisi ayri yazildiginda biri duzeltilip
        digeri yalan soylemeye devam ediyordu.
        """
        yardimlar = []
        if self.ipucu_acik and len(adim.ipuclari) > kullanilan_ipucu:
            yardimlar.append(("i", "ipucu"))
        if self._cozum_var_mi(adim) and not cozum_acildi:
            yardimlar.append(("c", "çözüm"))
        if yanlis_yapildi:
            yardimlar.append(("o", "örnek"))
        if self.bulmaca.kanitlar:
            yardimlar.append(("k", "kaynaklar"))
        return yardimlar

    def _komut_satiri(self, adim: Adim, yanlis_yapildi: bool = False) -> str:
        """Bu adimda gercekten kullanilabilir komutlari tek satirda yazar.

        Kullanilamayacak komut gosterilmez: ipucu kapaliysa ya da bu adimda
        ipucu yoksa "i" yazmak yaniltir. Ayni sebeple "o" (basit ornek)
        yalnizca ogrenci bu adimda en az bir kez yanlis yaptiysa gorunur.
        """
        parcalar = ["{} {}".format(h, e)
                    for h, e in self._mevcut_yardimlar(adim, yanlis_yapildi)]
        if self._sinifta_mi():
            parcalar.append("e el kaldır")
        parcalar.append("x çıkış")
        parcalar.append("? tümü")
        # Kirilma madde sinirinda olsun diye; bkz. terminal.komut_satirlari.
        return chr(10).join(ekran.komut_satirlari(parcalar))

    # ------------------------------------------------------- basit örnek
    def _soru_govdesi(self, adim: Adim) -> None:
        """Sorunun metni ve şıkları.

        Ayrı bir yordam çünkü uzun bir yardım metninden (örnek, çözüm)
        sonra soru ekrandan kayıyor; öğrenci neye cevap verdiğini
        kaybetmesin diye aynı gövde yeniden basılıyor.
        """
        ekran.yaz()
        ekran.yaz(adim.soru, "beyaz")
        if adim.secenekler:
            ekran.yaz()
            for i, secenek in enumerate(adim.secenekler, 1):
                ekran.asili_yaz("  {:>2}) ".format(i), secenek,
                                onek_renkleri=("acik_sari",))

    def _ornek_uret(self) -> Optional[Bulmaca]:
        """Aynı konudan, DAHA BASİT ve çözülmüş bir örnek bulmaca üretir.

        İçerik üreticilerine hiç dokunmadan çalışır: mevcut kayıt defteri
        aynı ders/konu için alt kademede zaten görev üretebiliyor. Örnek
        yazdırmak 125 üreticiye ayrı iş açardı; kademe düşürmek bedava.

        Bulunamazsa None döner - sessizce yanlış bir şey göstermez.
        """
        b = self.bulmaca
        try:
            from .kayit_defteri import uret
        except Exception:
            return None

        # Tohum sabit: aynı görevde örnek istemek her seferinde aynı örneği
        # versin, öğrenci komutu tekrarlayarak örnek devşirmesin.
        tohum = int(hashlib.sha256(
            ("ornek:" + (b.kod or "") + (b.konu or "")).encode("utf-8")
        ).hexdigest()[:12], 16)

        denenen = set()
        for dusus in ORNEK_KADEME_DUSUSU:
            hedef = max(1, b.kademe - dusus)
            if hedef >= b.kademe or hedef in denenen:
                continue
            denenen.add(hedef)
            try:
                ornek = uret(ders=b.ders, konu=b.konu, kademe=hedef,
                             rastgele=random.Random(tohum + hedef))
            except Exception:
                # Üretici içeriği oyunun geri kalanından bağımsız yazılıyor;
                # yarım kalmış bir üretici yüzünden oynanan görev çökmemeli.
                continue
            if ornek is None or not ornek.adimlar:
                continue
            # `uret` istenen kademede içerik bulamazsa en yakın kademeye,
            # oradan da bulamazsa DERSİN GENELİNE düşer. O zaman elimizdeki
            # şey "aynı konunun daha basiti" değildir: başka konudan ya da
            # aynı/daha üst kademeden bir soru olur. Bunu örnek diye
            # göstermek, zaten yanlış yapmış öğrenciyi ikinci kez yanıltır.
            if ornek.konu != b.konu or ornek.kademe >= b.kademe:
                continue
            return ornek
        return None

    def _ornek_goster(self, ornek: Bulmaca) -> None:
        """Örnek bulmacayı ÇÖZÜMÜYLE gösterir. Cevap istenmez."""
        ekran.yaz()
        ekran.kutu(
            "Bu bir soru değil, çözülmüş bir örnek: aynı konunun daha kolay "
            "hâli, cevaplarıyla birlikte. Senden bir şey beklemiyorum; oku, "
            "sonra kendi sorumuza döneriz.",
            "BASİT ÖRNEK", "acik_yesil")
        ekran.yaz()
        ekran.kutu(ornek.brifing, ekran.tr_buyuk(ornek.baslik or "ÖRNEK"), "beyaz")

        for kanit in ornek.kanitlar:
            ekran.kutu(kanit.icerik, kanit.etiket, "beyaz")

        for sira, adim in enumerate(ornek.adimlar, 1):
            ekran.yaz()
            ekran.yaz("ÖRNEK ADIM {}/{}".format(sira, len(ornek.adimlar)),
                      "kalin", "acik_yesil")
            ekran.yaz()
            ekran.yaz(adim.soru, "beyaz")
            if adim.secenekler:
                ekran.yaz()
                for i, secenek in enumerate(adim.secenekler, 1):
                    isaret = "->" if self._dogru_sik_mi(adim, i - 1) else "  "
                    ekran.asili_yaz(
                        "  {} {}) ".format(isaret, i), secenek,
                        onek_renkleri=("acik_yesil",) if isaret.strip() else ("gri",))
            ekran.yaz()
            try:
                ekran.basari("Cevap: " + dogru_cevap_metni(adim))
            except Exception:
                ekran.basari("Cevap yukarıda işaretli.")
            if adim.cozum:
                ekran.kutu(adim.cozum, "NASIL BULUNDU", "acik_yesil")
            if adim.aciklama:
                ekran.kutu(adim.aciklama, "NEDEN", "gri")

        ekran.yaz()
        ekran.yaz("Örnek bitti. Kendi sorumuzda sayılar farklı; aynı yolu "
                  "izlemen yeterli.", "gri")

    def _istem_metni(self, adim: Adim) -> str:
        if adim.tur == SECIM:
            return "Şık numarası:"
        if adim.tur == COKLU:
            return "Numaralar (örn. 1,3,5 / yoksa: yok):"
        if adim.tur == SIRALA:
            return "Sıra (örn. 3,1,4,2):"
        if adim.tur == ESLESTIR:
            return "Eşleşmeler (örn. 1a,2c,3b):"
        if adim.tur == SAYI:
            return "Cevap{}:".format(" (" + adim.birim + ")" if adim.birim else "")
        if adim.tur == "ifade":
            return "İşlem (örn. (3+5)×2):"
        return "Cevap:"

    # Ipucu bedeli kademeye gore olceklenir. Olcum (5 Eylul 2026): ipucu
    # yogunlugu ve uzunlugu kademeyle NEREDEYSE HIC degismiyor (0,87-1,36
    # ipucu/adim, 6,4-7,7 kelime), brifing ise 1'den 13'e yalnizca %25
    # uzuyor (39 -> 49 kelime). Yani 1. sinif ogrencisi ile universite
    # ogrencisi ayni destegi aliyor -- oysa okuma yuku kucukte cok daha agir.
    #
    # Icerigi 128 uretici boyunca yeniden yazmadan yapilabilecek sey bu:
    # kucuk kademede ipucu UCUZLASIR. §0'in dogrudan uygulamasi -- destek,
    # ihtiyac buyudukce artar. Ust kademede bedel aynen kaliyor.
    IPUCU_BEDEL_CARPANI = ((4, 0.34), (8, 0.67), (99, 1.0))

    def _ipucu_bedeli(self, adim: Adim) -> int:
        kademe = getattr(self.bulmaca, "kademe", 5)
        carpan = next(c for esik, c in self.IPUCU_BEDEL_CARPANI if kademe <= esik)
        return max(1, int(round(adim.ipucu_bedeli * carpan)))

    def _puan_hesapla(self, adim: Adim, deneme: int, ipucu: int,
                      cozum_acildi: bool = False,
                      ornek_acildi: bool = False) -> int:
        carpan = CARPANLAR[min(deneme, len(CARPANLAR)) - 1]
        if cozum_acildi:
            carpan = min(carpan, COZUM_TAVANI)
        puan = adim.puan * carpan - ipucu * self._ipucu_bedeli(adim)
        if ornek_acildi:
            # Basit örnek bir ipucu kadar düşer; kaç kez okunduğu değişmez.
            # Dikkat harcamaz - gerekçe için dosya başındaki nota bak.
            puan -= self._ipucu_bedeli(adim)
        return max(1, int(round(puan)))

    def _teshis_goster(self, adim: Adim, ham: str) -> None:
        """
        Yanlışın teşhisi: "bilmiyorsun" değil, "şunu karıştırdın".

        Öğrenciyi doğru cevaba itmez; hatanın adını koyar. Doğru cevabı
        söylemek yerine yanlışın nereden geldiğini göstermek, aynı hatanın
        bir sonraki görevde tekrarlanmasını engelleyen tek geri bildirimdir.
        """
        metin = teshis(adim, ham)
        if not metin:
            return
        ekran.yaz()
        ekran.kutu(metin, "NEREDE AYRILDIK", "acik_sari")
        self.gorulen_teshisler.append(metin)

    def _aciklama_goster(self, adim: Adim) -> None:
        if adim.aciklama:
            ekran.yaz()
            ekran.kutu(adim.aciklama, "NEDEN", "gri")


def sonucu_ozetle(bulmaca: Bulmaca, sonuc: BulmacaSonucu) -> None:
    """Görev bitiminde kapanış ekranı."""
    ekran.yaz()
    ekran.ayrac(S["kalin_yatay"])
    if sonuc.birakildi:
        # §0: birakmak ceza degil. Eski metin ("Us tahminlerle idare edecek")
        # sucluluk uretiyordu; oysa yapamadigini kabul edip birakmak, rastgele
        # tahmin etmekten daha iyi bir ogrenci davranisi.
        ekran.yaz("DOSYA AÇIK KALDI", "kalin", "acik_sari")
        ekran.yaz("Bu görev seni bekliyor. Başka bir gün, başka bir gözle "
                  "bakınca daha kolay gelir.", "gri")
        return

    ekran.yaz("İŞ TAMAM", "kalin", "acik_yesil")
    ekran.yaz()
    ekran.yaz("{}  {}/{} puan".format(
        ekran.yildizlar(sonuc.yildiz), sonuc.puan, sonuc.azami_puan), "kalin")
    ekran.yaz(ekran.cubuk(sonuc.puan, sonuc.azami_puan, 30), "acik_yesil")

    model = sonuc.model_basarisi()
    if model is True:
        ekran.yaz("Bilinmeyeni ilk denemede doğru kurdun. Asıl iş buydu.", "acik_mor")
    elif model is False:
        ekran.yaz("Olayın içindeki ana ilişkiyi kurarken zorlandın. Bir sonraki "
                  "görevde önce kanıtların birbirine nasıl bağlandığına bak.",
                  "acik_sari")

    # Ogrenci puani gorur ama NEYI calisacagini ogrenmez. Oyunun asil birimi
    # konudur; zorlanildiysa onu adiyla soyluyoruz.
    gb = degerlendirme.gorev_geri_bildirimi(bulmaca, sonuc)
    if gb.get("zorlandi"):
        ekran.yaz()
        ekran.yaz(gb["ozet"], "acik_sari")
        # Konu, Oturum.oyna sonunda gözlenen başarıyla birlikte açıklandı.
        # Aynı kapanışta ikinci bir "çalışılacak konu" kutusu göstermeyiz.
        if gb["tekrarlayan_hatalar"]:
            ekran.yaz("Aynı hatayı birden çok kez yaptın:", "kalin")
            for hata in gb["tekrarlayan_hatalar"]:
                ekran.madde(hata, "acik_sari")

    if bulmaca.kapanis:
        ekran.yaz()
        ekran.kutu(bulmaca.kapanis, "SONRASI", "beyaz")
