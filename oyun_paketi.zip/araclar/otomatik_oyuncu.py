# -*- coding: utf-8 -*-
"""
Otomatik oyuncu (B46.5a): görevleri GERÇEK oturum akışıyla, öğrenci yerine
bir betiğe oynatır.

    python main.py --otomatik-oyuncu            # lise (9-12), bütün dersler
    python main.py --otomatik-oyuncu kimya      # tek ders

NEDEN VAR
---------
`--denetle` görevin VERİSİNE bakar (ek uyumu, teşhis = cevap, havuz). Öğrenci
ise veriyi değil OYUNU oynar: brifing, kaynak açma, ipucu, deneme hakkı, puan,
dikkat. Veri doğru olup akış bozuk olabilir -- doğru cevabı yazan öğrencinin
"yanlış" görmesi (11 Eylül'de üslü sayıda yaşandı), bitmeyen bir soru döngüsü,
eksiye düşen dikkat. Bunlar ancak oynanınca görülür. Pilottan (B31.7) önce bir
makinenin binlerce kez oynaması, bir öğrencinin tek kez takılmasından ucuzdur.

NASIL OYNAR
-----------
Her üretici, 9-12. sınıf kademelerinden kapsadıklarında, birkaç tohumla
üretilir ve üç aşamada oynanır: "Nasıl yapılıyor" (yalnız izler), "Yanındayım"
(doğru ve rastgele tavırla) ve "Sen hallet" (doğru, yanlış, rastgele):

* dogru    : her adıma ilk denemede doğru cevabı yazar; önce kaynakları açar.
             Beklenen: görev biter, tam puan, her adım ilk denemede doğru.
* yanlis   : her adıma yanlış cevap yazar. Beklenen: görev yine biter
             (ölü uç yok), puan 0, doğru cevap gösterilir.
* rastgele : komutları (ipucu, çözüm, kaynak, örnek, yardım...), anlaşılmaz
             girdileri ve cevapları karıştırır; onay sorularına yazı turayla
             cevap verir. Beklenen: görev biter, puan ve dikkat sınırlarda.

"Sen hallet" gerçek bir öğrenci kaydıyla (`Durum`) oynanır: dikkat havuzu,
basit örnek ve alıştırma merdiveni öğrencideki gibi çalışır.

NE YAKALAR
----------
* istisna        : üretim ya da oynanış sırasında hata.
* olu_uc         : görev bitirilemiyor ya da doğru cevap doğru sayılmıyor.
* sonsuz_dongu   : oyun, görev bitmeden girdi istemeye devam ediyor ya da
                   üretim/oynanış zaman sınırını aşıyor.
* kaynak_tasmasi : puan ya da dikkat sınırın dışına çıkıyor.
* veri           : `Bulmaca.dogrula()` sorunları, aynı metinli iki şık,
                   sonlu olmayan sayısal cevap.
* yanlis_kabul   : "yanlış" tavrının cevabı doğru sayıldı (tolerans geniş).

Otomatik oyuncu ZORLUĞU ölçmez; ilk ekranın yüksekliği için `--duvar`, şık
sızıntısı için `--sizinti` var. Bu araç "oynanabiliyor mu" sorusunu cevaplar.
"""
from __future__ import annotations

import _thread
import collections
import math
import random
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from decimal import Decimal
from typing import Dict, Iterable, List, Optional, Tuple

from oyun.motor import kayit_defteri, terminal
from oyun.motor.degerlendirme import tr_kucuk
from oyun.motor.modeller import (
    ANLATIM, BIRLIKTE, COKLU, ESLESTIR, METIN, SAYI, SECIM, SERBEST, SIRALA,
)

LISE = (9, 12)
TOHUM_SAYISI = 3
ZAMAN_SINIRI = 10.0          # saniye: tek üretim ya da tek oynanış
ADIM_BASINA_KOMUT = 6        # rastgele tavır bir cevaptan önce en çok bu kadar komut yazar
HATA_TURLERI = ("istisna", "olu_uc", "sonsuz_dongu", "kaynak_tasmasi", "veri",
                "yanlis_kabul")
# (aşama, tavır) -- oynanış sırası
OYUNLAR = ((ANLATIM, "izle"), (BIRLIKTE, "dogru"), (BIRLIKTE, "rastgele"),
           (SERBEST, "dogru"), (SERBEST, "yanlis"), (SERBEST, "rastgele"))

# "x" (çıkış) bilerek yok: çekilmek meşru bir seçim ama ölü uç ölçüsünü bozar.
_SERBEST_KOMUTLARI = ("i", "i", "c", "k", "o", "?", "b", "d", "e", "")
_BIRLIKTE_KOMUTLARI = ("i", "c", "k", "o", "?", "y", "b", "d", "")
_ANLASILMAZ = ("abc", "99", "-1", "1,2,3", "½", "on iki", "0")


@dataclass
class Bulgu:
    tur: str
    ders: str
    ad: str
    kademe: int
    tohum: int
    oyun: str          # "serbest/dogru" gibi; üretim için "uretim"
    ayrinti: str


class SonsuzDongu(Exception):
    """Oyun, görev bitmeden girdi istemeye devam etti."""


class ZamanAsimi(Exception):
    """Üretim ya da oynanış zaman sınırını aştı."""


# --------------------------------------------------------------------------
# Cevap üretimi
# --------------------------------------------------------------------------

def _sayi_metni(deger: float) -> str:
    """Tam değer, bilimsel gösterimsiz, Türkçe ondalık virgülüyle."""
    metin = format(Decimal(repr(float(deger))), "f")
    if "." in metin:
        metin = metin.rstrip("0").rstrip(".")
    return metin.replace(".", ",")


def dogru_girdi(adim) -> str:
    """Öğrencinin doğru cevap için klavyeden yazacağı metin."""
    if adim.tur == SECIM:
        return str(int(adim.cevap) + 1)
    if adim.tur == COKLU:
        secilen = sorted(int(i) + 1 for i in adim.cevap)
        return ",".join(str(i) for i in secilen) if secilen else "yok"
    if adim.tur == SIRALA:
        return ",".join(str(int(i) + 1) for i in adim.cevap)
    if adim.tur == METIN:
        cevap = adim.cevap[0] if isinstance(adim.cevap, (list, tuple)) else adim.cevap
        return str(cevap)
    if adim.tur == ESLESTIR:
        return " ".join("{}{}".format(i + 1, h) for i, h in enumerate(adim.cevap))
    if adim.tur == "ifade":
        return str(adim.cevap["ornek"])
    return _sayi_metni(float(adim.cevap))


def yanlis_girdi(adim, rastgele: random.Random) -> Optional[str]:
    """Kesin yanlış bir cevap; yazılamıyorsa (tek şık gibi) None."""
    n = len(adim.secenekler)
    if adim.tur == SECIM:
        adaylar = [i for i in range(n) if i != int(adim.cevap)]
        return str(rastgele.choice(adaylar) + 1) if adaylar else None
    if adim.tur == COKLU:
        if not n:
            return None
        secilen = set(int(i) for i in adim.cevap) ^ {rastgele.randrange(n)}
        return ",".join(str(i + 1) for i in sorted(secilen)) if secilen else "yok"
    if adim.tur == SIRALA:
        sira = [int(i) for i in adim.cevap]
        if len(sira) < 2:
            return None
        sira[0], sira[1] = sira[1], sira[0]
        return ",".join(str(i + 1) for i in sira)
    if adim.tur == METIN:
        return "zqzqzq"
    if adim.tur == "ifade":
        return "+".join(str(x) for x in adim.cevap["sayilar"]) + "+1"
    if adim.tur == ESLESTIR:
        harfler = [str(h) for h in adim.cevap]
        if len(set(harfler)) < 2:
            return None
        kaydir = harfler[1:] + harfler[:1]
        return " ".join("{}{}".format(i + 1, h) for i, h in enumerate(kaydir))
    beklenen = float(adim.cevap)
    pay = 10.0 * max(1.0, abs(adim.tolerans), abs(beklenen))
    return _sayi_metni(beklenen + pay)


def _rastgele_cevap(adim, rastgele: random.Random) -> str:
    zar = rastgele.random()
    if zar < 0.15:
        return rastgele.choice(_ANLASILMAZ)
    if zar < 0.45:
        return dogru_girdi(adim)
    return yanlis_girdi(adim, rastgele) or dogru_girdi(adim)


# --------------------------------------------------------------------------
# Sürücü: terminal.sor / bekle / onayla yerine geçer
# --------------------------------------------------------------------------

class _SessizKabuk:
    """Ekrana hiçbir şey basmaz; oyun kendini terminalde sanır."""
    yazim_hizi_destekli = False

    def bas(self, satir):
        pass

    def oku(self, istem):        # sor/bekle/onayla sürücüye bağlı; buraya düşmez
        raise SonsuzDongu("beklenmeyen doğrudan okuma: " + str(istem)[:60])

    def temizle(self):
        return True

    def genislik(self):
        return 60


class _Surucu:
    def __init__(self, tavir: str, rastgele: random.Random, kanit_sayisi: int,
                 sinir: int, birlikte: bool):
        self.tavir = tavir
        self.rastgele = rastgele
        self.kanit_sayisi = kanit_sayisi
        self.sinir = sinir
        self.komutlar = _BIRLIKTE_KOMUTLARI if birlikte else _SERBEST_KOMUTLARI
        self.yigin: List[object] = []      # iç içe oturum (merdiven) için adım yığını
        self.komut_sayisi = 0
        self.inceleme = 0
        self.cagri = 0

    # -- adım izleme
    def adima_gir(self, adim) -> None:
        self.yigin.append(adim)
        self.komut_sayisi = 0

    def adimdan_cik(self) -> None:
        if self.yigin:
            self.yigin.pop()
        self.komut_sayisi = 0

    def _say(self) -> None:
        self.cagri += 1
        if self.cagri > self.sinir:
            raise SonsuzDongu("{} girdiden sonra görev hâlâ bitmedi".format(self.sinir))

    # -- terminal yerine geçenler
    def sor(self, istem: str = "", varsayilan: str = "") -> str:
        self._say()
        if not self.yigin:
            return self._inceleme()
        adim = self.yigin[-1]
        if self.tavir == "dogru":
            return dogru_girdi(adim)
        if self.tavir == "yanlis":
            return yanlis_girdi(adim, self.rastgele) or dogru_girdi(adim)
        if self.komut_sayisi < ADIM_BASINA_KOMUT and self.rastgele.random() < 0.35:
            self.komut_sayisi += 1
            return self.rastgele.choice(self.komutlar)
        return _rastgele_cevap(adim, self.rastgele)

    def bekle(self, istem: str = "") -> None:
        self._say()

    def onayla(self, istem: str, varsayilan: bool = True) -> bool:
        self._say()
        return self.tavir == "rastgele" and self.rastgele.random() < 0.5

    def _inceleme(self) -> str:
        """"Sen hallet" başındaki kaynak inceleme istemi."""
        self.inceleme += 1
        if self.tavir == "dogru":
            # Doğru oyuncu kaynakları sırayla açar, sonra başlar.
            return str(self.inceleme) if self.inceleme <= self.kanit_sayisi else ""
        if self.tavir == "rastgele" and self.inceleme <= ADIM_BASINA_KOMUT:
            secenekler = [str(i) for i in range(1, self.kanit_sayisi + 2)]
            secenekler += ["?", "b", "d", "zz", ""]
            return self.rastgele.choice(secenekler)
        return ""


@contextmanager
def _surucuyu_tak(surucu: _Surucu):
    """Terminal girdisini ve adım izlemeyi sürücüye bağlar, sonra geri alır.

    Adım izleme SINIF düzeyinde: alıştırma merdiveni kendi `Oturum`unu açar,
    iç içe oturumlar da aynı yığına yazsın diye.
    """
    from oyun.motor.oturum import Oturum

    eski_giris = (terminal.sor, terminal.bekle, terminal.onayla)
    eski_kabuk = terminal.kabuk()
    eski_adim, eski_birlikte = Oturum._adimi_oyna, Oturum._birlikte_adim

    def adimi_oyna(self, adim, sira, toplam):
        surucu.adima_gir(adim)
        try:
            return eski_adim(self, adim, sira, toplam)
        finally:
            surucu.adimdan_cik()

    def birlikte_adim(self, adim, sira, toplam):
        surucu.adima_gir(adim)
        try:
            return eski_birlikte(self, adim, sira, toplam)
        finally:
            surucu.adimdan_cik()

    terminal.sor, terminal.bekle, terminal.onayla = (
        surucu.sor, surucu.bekle, surucu.onayla)
    terminal.kabuk_ata(_SessizKabuk())
    Oturum._adimi_oyna, Oturum._birlikte_adim = adimi_oyna, birlikte_adim
    try:
        yield surucu
    finally:
        terminal.sor, terminal.bekle, terminal.onayla = eski_giris
        terminal.kabuk_ata(eski_kabuk)
        Oturum._adimi_oyna, Oturum._birlikte_adim = eski_adim, eski_birlikte


def _sinirli(fonksiyon, saniye: Optional[float] = None):
    """`fonksiyon`u zaman sınırıyla çalıştırır; aşılırsa ZamanAsimi.

    Sonsuz bir üretim döngüsü (ör. koşulu hiç sağlanmayan "şunu seçene kadar
    dene") girdi istemez; sürücü sayacı onu göremez. Bekçi iş parçacığı süre
    dolunca ana iş parçacığını keser. Yalnız ana iş parçacığında çalışır;
    başka yerden çağrılırsa sınırsız çalıştırır.
    """
    if threading.current_thread() is not threading.main_thread():
        return fonksiyon()
    saniye = ZAMAN_SINIRI if saniye is None else saniye
    kilit = threading.Lock()
    durum = {"aktif": True, "kesildi": False}

    def kes():
        with kilit:
            if durum["aktif"]:
                durum["kesildi"] = True
                _thread.interrupt_main()

    bekci = threading.Timer(saniye, kes)
    bekci.daemon = True
    bekci.start()
    try:
        try:
            return fonksiyon()
        finally:
            with kilit:
                durum["aktif"] = False
            bekci.cancel()
    except KeyboardInterrupt:
        if durum["kesildi"]:
            raise ZamanAsimi("{:.0f} saniyede bitmedi".format(saniye))
        raise


# --------------------------------------------------------------------------
# Tek bulmacanın denetimi
# --------------------------------------------------------------------------

def veri_sorunlari(bulmaca) -> List[str]:
    sorunlar = list(bulmaca.dogrula())
    for sira, adim in enumerate(bulmaca.adimlar, 1):
        if adim.secenekler:
            # sadelestir() KULLANILMAZ: işaretleri siler, "2 × (d + 25)" ile
            # "2d + 25" ya da "Genç, nöbetçiyi" ile "Genç; nöbetçiyi" aynı çıkar.
            sade = [" ".join(tr_kucuk(s).split()) for s in adim.secenekler]
            if len(set(sade)) != len(sade):
                sorunlar.append("adım {}: aynı metinli iki şık".format(sira))
        if adim.tur == SAYI:
            try:
                sonlu = math.isfinite(float(adim.cevap))
            except (TypeError, ValueError):
                sonlu = False
            if not sonlu:
                sorunlar.append("adım {}: sayısal cevap sonlu değil".format(sira))
    return sorunlar


def _oyna(bulmaca, asama: str, tavir: str, tohum: int) -> List[Tuple[str, str]]:
    """Bulmacayı bir kez oynatır; (tür, ayrıntı) listesi döner."""
    from oyun.motor.durum import Durum
    from oyun.motor.oturum import Oturum

    rastgele = random.Random("{}|{}|{}|{}".format(bulmaca.kod, asama, tavir, tohum))
    adim_sayisi = len(bulmaca.adimlar)
    surucu = _Surucu(tavir, rastgele, len(bulmaca.kanitlar),
                     sinir=200 + 80 * adim_sayisi, birlikte=(asama == BIRLIKTE))
    durum = Durum(tohum=tohum) if asama == SERBEST else None
    bulgular: List[Tuple[str, str]] = []
    with _surucuyu_tak(surucu):
        oturum = Oturum(bulmaca, asama=asama, durum=durum)
        tavan = oturum.dikkat_tavani
        try:
            sonuc = _sinirli(oturum.oyna)
        except SonsuzDongu as hata:
            return [("sonsuz_dongu", str(hata))]
        except ZamanAsimi as hata:
            return [("sonsuz_dongu", "oynanış " + str(hata))]
        except Exception as hata:          # noqa: BLE001 -- bulgu olarak raporlanır
            return [("istisna", "{}: {}".format(type(hata).__name__, hata)[:160])]

    if sonuc.birakildi or not sonuc.tamamlandi:
        bulgular.append(("olu_uc", "görev bitmedi (bırakıldı={})".format(sonuc.birakildi)))
    if asama == ANLATIM:
        return bulgular

    if len(sonuc.adim_sonuclari) != adim_sayisi:
        bulgular.append(("olu_uc", "{} adımın {} tanesi oynandı".format(
            adim_sayisi, len(sonuc.adim_sonuclari))))
    for sira, (adim, adim_sonucu) in enumerate(
            zip(bulmaca.adimlar, sonuc.adim_sonuclari), 1):
        if tavir == "dogru" and not (adim_sonucu.dogru and adim_sonucu.deneme == 1):
            bulgular.append(("olu_uc", "adım {}: doğru cevap ({}) ilk denemede doğru "
                                       "sayılmadı".format(sira, dogru_girdi(adim))))
        if (tavir == "yanlis" and adim_sonucu.dogru
                and yanlis_girdi(adim, random.Random(0)) is not None):
            bulgular.append(("yanlis_kabul", "adım {}: yanlış cevap doğru sayıldı"
                             .format(sira)))
        if asama == SERBEST and not (0 <= adim_sonucu.puan <= adim.puan):
            bulgular.append(("kaynak_tasmasi", "adım {}: puan {} (azami {})".format(
                sira, adim_sonucu.puan, adim.puan)))

    if asama == SERBEST:
        if not (0 <= sonuc.puan <= sonuc.azami_puan):
            bulgular.append(("kaynak_tasmasi", "puan {} / azami {}".format(
                sonuc.puan, sonuc.azami_puan)))
        if tavir == "dogru" and sonuc.puan != sonuc.azami_puan:
            bulgular.append(("olu_uc", "hatasız oyunda puan {} / {}".format(
                sonuc.puan, sonuc.azami_puan)))
        if not (0 <= oturum.kalan_dikkat <= tavan):
            bulgular.append(("kaynak_tasmasi", "oturum dikkati {} (tavan {})".format(
                oturum.kalan_dikkat, tavan)))
        if durum is not None and not (0 <= durum.dikkat <= durum.dikkat_tavani()):
            bulgular.append(("kaynak_tasmasi", "dikkat havuzu {} (tavan {})".format(
                durum.dikkat, durum.dikkat_tavani())))
    return bulgular


def uretici_oyna(kayit, kademe: int, tohum: int,
                 oyunlar: Iterable[Tuple[str, str]] = OYUNLAR) -> List[Bulgu]:
    """Bir üreticiyi bir kademe ve tohumda üretir, bütün oyunlarla oynatır."""
    ad = kayit.fonksiyon.__name__

    def bulgu(tur, oyun, ayrinti):
        return Bulgu(tur, kayit.ders, ad, kademe, tohum, oyun, ayrinti)

    try:
        bulmaca = _sinirli(lambda: kayit.fonksiyon(random.Random(tohum), kademe))
    except ZamanAsimi as hata:
        return [bulgu("sonsuz_dongu", "uretim", "üretim " + str(hata))]
    except Exception as hata:              # noqa: BLE001
        return [bulgu("istisna", "uretim", "{}: {}".format(type(hata).__name__, hata)[:160])]

    bulgular = [bulgu("veri", "uretim", s) for s in veri_sorunlari(bulmaca)]
    for asama, tavir in oyunlar:
        for tur, ayrinti in _oyna(bulmaca, asama, tavir, tohum):
            bulgular.append(bulgu(tur, "{}/{}".format(asama, tavir), ayrinti))
    return bulgular


def lise_kademeleri(kayit, aralik: Tuple[int, int] = LISE) -> List[int]:
    return [k for k in range(aralik[0], aralik[1] + 1) if kayit.kapsar(k)]


def tarama(ders: Optional[str] = None, tohum_sayisi: int = TOHUM_SAYISI,
           aralik: Tuple[int, int] = LISE, kademe_basina: Optional[int] = None,
           oyunlar: Iterable[Tuple[str, str]] = OYUNLAR) -> Dict:
    """Lise kademelerindeki üreticileri oynatır.

    `kademe_basina` verilirse her üretici yalnız ilk bu kadar kademesinde
    oynanır (hızlı test için).
    """
    kayit_defteri.icerigi_yukle()
    oyunlar = tuple(oyunlar)
    bulgular: List[Bulgu] = []
    ureticiler = collections.defaultdict(set)
    oynanis = collections.Counter()
    for kayit in kayit_defteri.tum_kayitlar():
        if ders and kayit.ders != ders:
            continue
        kademeler = lise_kademeleri(kayit, aralik)
        if kademe_basina:
            kademeler = kademeler[:kademe_basina]
        if not kademeler:
            continue
        ureticiler[kayit.ders].add(kayit.fonksiyon.__name__)
        for kademe in kademeler:
            for tohum in range(tohum_sayisi):
                bulgular.extend(uretici_oyna(kayit, kademe, tohum, oyunlar))
                oynanis[kayit.ders] += len(oyunlar)
    return {"bulgular": bulgular, "ureticiler": dict(ureticiler),
            "oynanis": dict(oynanis)}


def ders_ozeti(sonuc: Dict) -> Dict[str, Dict]:
    """Ders başına üretici, oynanış, bulgu sayısı ve hatalı üretici sayısı."""
    ozet = {}
    for ders, adlar in sonuc["ureticiler"].items():
        dersin = [b for b in sonuc["bulgular"] if b.ders == ders]
        ozet[ders] = {
            "uretici": len(adlar),
            "oynanis": sonuc["oynanis"].get(ders, 0),
            "bulgu": len(dersin),
            "hatali_uretici": len({b.ad for b in dersin}),
            "turler": collections.Counter(b.tur for b in dersin),
        }
    return ozet


def yazdir(ders: str = "", tohum_sayisi: int = TOHUM_SAYISI, adet: int = 30) -> int:
    sonuc = tarama(ders or None, tohum_sayisi)
    ozet = ders_ozeti(sonuc)
    toplam_oynanis = sum(o["oynanis"] for o in ozet.values())
    print("OTOMATİK OYUNCU -- {} üretici, {} oynanış (9-12. sınıf, {} tohum)".format(
        sum(o["uretici"] for o in ozet.values()), toplam_oynanis, tohum_sayisi))
    print("Oyunlar: " + ", ".join("{}/{}".format(a, t) for a, t in OYUNLAR))
    print()
    print("{:<14}{:>9}{:>10}{:>7}{:>9}  {}".format(
        "ders", "üretici", "oynanış", "bulgu", "hatalı", "türler"))
    for ad in sorted(ozet):
        o = ozet[ad]
        turler = ", ".join("{} {}".format(t, n) for t, n in o["turler"].most_common())
        print("{:<14}{:>9}{:>10}{:>7}{:>9}  {}".format(
            ad, o["uretici"], o["oynanis"], o["bulgu"], o["hatali_uretici"], turler or "-"))
    bulgular = sonuc["bulgular"]
    if bulgular:
        print()
        print("İLK {} BULGU (aynı üretici + tür + ayrıntı tek satır)".format(adet))
        gruplar = collections.OrderedDict()
        for b in bulgular:
            anahtar = (b.tur, b.ders, b.ad, b.ayrinti)
            gruplar.setdefault(anahtar, []).append(b)
        for (tur, d, ad, ayrinti), liste in list(gruplar.items())[:adet]:
            ilk = liste[0]
            print("  [{}] {}.{} k{} tohum {} {} ({} kez): {}".format(
                tur, d, ad, ilk.kademe, ilk.tohum, ilk.oyun, len(liste), ayrinti))
    else:
        print()
        print("Bulgu yok: her görev her tavırla sonuna kadar oynandı.")
    return 1 if bulgular else 0
