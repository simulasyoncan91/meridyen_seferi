# -*- coding: utf-8 -*-
"""
Zorluk duvarı ölçümü (B46.2): öğrencinin İLK EKRANDA ne kadar yüksek bir
girişle karşılaştığı.

    python main.py --duvar          # en duvarlı 20 görev
    python main.py --duvar 40       # ilk 40

NEDEN VAR
---------
22 Eylül 2026'da kullanıcı kimyadaki mol görevine (`numune_kavanozu`) denk
geldi ve oyunu İLK EKRANDA kapattı: kimyasal denklem, beş formül, "264 mol /
264 g" ve × 10²³ aynı anda geliyordu. B30'un "ben bunu anlayamıyorum" duvarı.
Yumuşatma (B46.3) buradan sırayla ilerler; ölçmeden yumuşatmak, en çok
korkutan görev yerine akla ilk geleni düzeltmek olur (KAPSAM KURALI 5).

NE ÖLÇER
--------
İlk ekran = brifing + kanıtlar + ilk adımın sorusu (öğrenci ilk cevabı
vermeden önce gördüğü her şey). Görev başına birkaç tohumun ortalaması:

* simge   : 100 sözcük başına formül/gösterim işareti (alt-üst simge rakam,
            ×, ÷, →, √, ^, = ...). Derece işareti sayılmaz.
* üs      : bilimsel gösterim (10²³, 10^5) var mı
* sözcük  : ilk ekranın uzunluğu
* ilk adım: sayı mı yazdırıyor (boş kutu), yoksa seçenek mi sunuyor
* adım    : toplam adım sayısı

PUAN BİR SIRALAMA ARACIDIR, ZORLUK ÖLÇÜSÜ DEĞİL: görevin ölçtüğü şeyin
zorluğunu değil, girişin yüksekliğini tahmin eder. Ağırlıklar elle seçildi
ve kullanıcının gerçek deneyimiyle sınandı: mol görevinin 22 Eylül'deki ilk
ekranı (dondurulmuş örnek) ilk 20'ye girmeli; 30 Eylül'de yumuşatılan görev
(B46.1: 33,9 -> 5,9 puan) ise ilk 20'den çıkmış olmalı (`testler/test_duvar.py`).

    python main.py --duvar 40 --lise   # pilot: yalnız 9-12, lisedeki ilk kademe
"""
from __future__ import annotations

import random
import re
from typing import Dict, List, Optional, Tuple

from oyun.motor import kayit_defteri
from oyun.motor.modeller import SAYI

TOHUM_SAYISI = 6
_SIMGELER = set("₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺×÷→←↔√∑∆≈≤≥±∫π=^")
_OK = re.compile(r"->|<-")
_US = re.compile(r"10[⁰¹²³⁴⁵⁶⁷⁸⁹⁻]|10\^")      # "× 100 cm" üs değildir
_SOZCUK = re.compile(r"\w+")


def simge_say(metin: str) -> int:
    """Formül/gösterim işareti sayısı ("->" tek işaret sayılır)."""
    return sum(1 for c in metin if c in _SIMGELER) + len(_OK.findall(metin))


def ilk_ekran(bulmaca) -> str:
    parcalar = [bulmaca.brifing] + [k.icerik for k in bulmaca.kanitlar]
    if bulmaca.adimlar:
        parcalar.append(bulmaca.adimlar[0].soru)
    return "\n".join(p or "" for p in parcalar)


def olc(bulmaca) -> Dict[str, float]:
    metin = ilk_ekran(bulmaca)
    sozcuk = len(_SOZCUK.findall(metin))
    simge = simge_say(metin)
    olcu = {
        "simge": 100.0 * simge / max(1, sozcuk),
        "us": 1.0 if _US.search(metin) else 0.0,
        "sozcuk": float(sozcuk),
        "ilk_sayi": 1.0 if bulmaca.adimlar and bulmaca.adimlar[0].tur == SAYI else 0.0,
        "adim": float(len(bulmaca.adimlar)),
    }
    olcu["puan"] = (olcu["simge"] + 8 * olcu["us"] + olcu["sozcuk"] / 40.0
                    + 4 * olcu["ilk_sayi"] + 0.5 * olcu["adim"])
    return olcu


def ilk_kademe(kayit, aralik: Optional[Tuple[int, int]] = None) -> Optional[int]:
    """Öğrencinin bu üreticiyle ilk karşılaştığı kademe.

    `aralik` verilirse (ör. lise 9-12) o aralıktaki en düşük kademe; üretici
    aralığa hiç girmiyorsa None. Pilot lise olduğu için (B46.6, 26 Eylül)
    7-12 aralığındaki bir görevin lise öğrencisine görünen ilk ekranı
    9. sınıf sürümüdür, 7. sınıf sürümü değil.
    """
    alt, ust = kayit.kademeler
    if aralik is None:
        return alt
    if ust < aralik[0] or alt > aralik[1]:
        return None
    return max(alt, aralik[0])


def tarama(tohum_sayisi: int = TOHUM_SAYISI,
           aralik: Optional[Tuple[int, int]] = None) -> List[Dict]:
    """Her üreticiyi en düşük kademesinde ölçer (öğrencinin ilk karşılaştığı).

    `aralik` verilirse yalnız o aralığa giren üreticiler, aralıktaki en düşük
    kademelerinde ölçülür (`--duvar ADET lise`).
    """
    kayit_defteri.icerigi_yukle()
    sonuc = []
    for kayit in kayit_defteri.tum_kayitlar():
        kademe = ilk_kademe(kayit, aralik)
        if kademe is None:
            continue
        olculer = []
        for tohum in range(tohum_sayisi):
            try:
                olculer.append(olc(kayit.fonksiyon(random.Random(tohum), kademe)))
            except Exception:          # noqa: BLE001 -- denetim ayrı araçta
                continue
        if not olculer:
            continue
        ort = {k: sum(o[k] for o in olculer) / len(olculer) for k in olculer[0]}
        ort.update(ders=kayit.ders, ad=kayit.fonksiyon.__name__, kademe=kademe)
        sonuc.append(ort)
    sonuc.sort(key=lambda o: -o["puan"])
    return sonuc


def yazdir(adet: int = 20, aralik: Optional[Tuple[int, int]] = None) -> None:
    satirlar = tarama(aralik=aralik)
    print("ZORLUK DUVARI -- ilk ekranı en yüksek {} görev ({} görev tarandı{})"
          .format(adet, len(satirlar),
                  "" if aralik is None else ", {}-{}. sınıf".format(*aralik)))
    print("Puan sıralama içindir, zorluk ölçüsü değildir. Bkz. araclar/duvar.py")
    print()
    print("{:>3}  {:<34}{:>6}{:>7}{:>4}{:>7}{:>5}{:>6}".format(
        "", "görev", "puan", "simge", "üs", "sözcük", "sayı", "adım"))
    for sira, o in enumerate(satirlar[:adet], start=1):
        print("{:>3}  {:<34}{:>6.1f}{:>7.1f}{:>4}{:>7.0f}{:>5}{:>6.0f}".format(
            sira, "{}.{} (k{})".format(o["ders"], o["ad"], o["kademe"])[:33],
            o["puan"], o["simge"], "var" if o["us"] >= 0.5 else "-",
            o["sozcuk"], "evet" if o["ilk_sayi"] >= 0.5 else "-", o["adim"]))
