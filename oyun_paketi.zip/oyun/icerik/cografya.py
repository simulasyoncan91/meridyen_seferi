# -*- coding: utf-8 -*-
"""
Coğrafya görevleri.

Bu derste coğrafya bilgisi ezber olarak değil, BİR KARARIN GEREKÇESİ olarak
sorulur. Öğrenci "eğim nedir" sorusuna cevap vermez; kampın nereye kurulacağına
karar verir ve o kararı eğimle savunur.

Üssün coğrafya işleri: ikinci kampın yeri, haritanın ölçeği, arazinin eğimi,
suyun ne kadar dayanacağı, saat farkı, yön bulma.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi,
    secim_adimi, sy, yorum_adimi,
)


# ==========================================================================
# YERLEŞME VE ARAZİ
# ==========================================================================

@bulmaca(ders="cografya", konu="yerlesme_secimi", kademeler=(4, 10), agirlik=1.5)
def kamp_yeri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Dört aday mevki, ölçüm kartları ve bir yönetmelik.

    Tuzak şu: en düz ve suya en yakın mevki, dere yatağının içindedir. Öğrenci
    "en iyi sayıyı" değil, "eleyici ölçütü" aramayı öğrenir.
    """
    adlar = ad_sec(rastgele, MEVKI_ADLARI, 4)
    azami_egim = rastgele.choice([12, 15, 18])
    azami_su = rastgele.choice([400, 500, 600])

    # Dört aday: biri uygun, üçü birer kuralı ihlal ediyor.
    dogru = {
        "ad": adlar[0],
        "egim": rastgele.randrange(4, azami_egim - 2),
        "su": rastgele.randrange(120, azami_su - 80),
        "dere": False,
        "kusur": None,
    }
    tuzak = {  # en düz, suya en yakın - ama dere yatağında
        "ad": adlar[1],
        "egim": rastgele.randrange(1, 4),
        "su": rastgele.randrange(20, 80),
        "dere": True,
        "kusur": "dere yatağının içinde",
    }
    dik = {
        "ad": adlar[2],
        "egim": azami_egim + rastgele.randrange(6, 18),
        "su": rastgele.randrange(150, azami_su - 50),
        "dere": False,
        "kusur": "eğim sınırın üstünde",
    }
    uzak = {
        "ad": adlar[3],
        "egim": rastgele.randrange(3, azami_egim - 3),
        "su": azami_su + rastgele.randrange(200, 700),
        "dere": False,
        "kusur": "suya uzaklık sınırın üstünde",
    }

    # Elenen her mevki için, o kusuru gözden kaçıran öğrenciye söylenecek söz.
    kusur_teshisleri = {
        "dere yatağının içinde":
            "Ölçüm sayılarına bakıp zemin notunu atladın. Bu mevki en düz ve "
            "suya en yakın olan; yönetmeliğin üçüncü maddesi ise dere "
            "yatağını sayı tartışmasına hiç sokmadan eliyor.",
        "eğim sınırın üstünde":
            "Bu mevkinin eğimi yönetmeliğin koyduğu tavanın üstünde. Suya "
            "uzaklığı ve zemini uygun olsa da tek bir madde ihlali elemeye "
            "yeter.",
        "suya uzaklık sınırın üstünde":
            "Bu mevkinin zemini ve eğimi uygun, ama en yakın su kaynağı "
            "yönetmeliğin izin verdiğinden daha uzakta. Ölçütler tek tek "
            "uygulanır; birinden kalan mevki listeden çıkar.",
    }

    mevkiler = [dogru, tuzak, dik, uzak]
    rastgele.shuffle(mevkiler)
    secenekler = [m["ad"] for m in mevkiler]
    dogru_indeks = secenekler.index(dogru["ad"])
    elenecekler = sorted(i for i, m in enumerate(mevkiler) if m["kusur"])

    olcum_kartlari = []
    for m in mevkiler:
        olcum_kartlari.append(Kanit(
            "Ölçüm kartı - {}".format(m["ad"]),
            "Ortalama eğim: %{}\nEn yakın suya uzaklık: {} m\nZemin: {}".format(
                m["egim"], m["su"],
                "dere yatağı tabanı, ince kum ve çakıl" if m["dere"]
                else "sıkı toprak, taşlı"),
            bedel=1,
            kritik=True,
        ))

    return Bulmaca(
        kod="cog-kamp-yeri",
        ders="cografya",
        baslik="İkinci Kamp",
        kademe=kademe,
        konu="yerlesme_secimi",
        kazanim="Yerleşme yeri seçiminde doğal etmenler; ölçütleri sıralayarak karar verme.",
        dikkat=7,
        brifing=(
            "Üs küçük geliyor; komutan ikinci bir kamp kurmak istiyor ve yer "
            "seçimini sana bırakıyor.\n\n"
            "Keşif ekibi dört mevki gezmiş: {}. Her mevki için eğim ve suya "
            "uzaklık ölçmüşler, zemin notu düşmüşler. Ama hangisinin uygun "
            "olduğuna karar vermemişler; \"sayılar burada, kararı sen ver\" "
            "demişler.\n\n"
            "Yanlış yer seçilirse bunu ilk yağmurda ya da ilk kışta anlarız."
        ).format(", ".join(secenekler)),
        kanitlar=olcum_kartlari + [
            Kanit("Kamp yönetmeliği",
                  "1) Ortalama eğim en fazla %{} olacak.\n"
                  "2) En yakın su kaynağı {} metreden uzak olmayacak.\n"
                  "3) Kamp DERE YATAĞINA kurulmaz. Yatak kuru görünse de "
                  "kurulmaz.".format(azami_egim, azami_su),
                  bedel=2, kritik=True),
            Kanit("Bölge yağış kaydı",
                  "İlkbaharda kar erimesiyle dereler birkaç saat içinde "
                  "kabarır. Kuru yataklar bu saatlerde tamamen dolar.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu dört mevkiyi değerlendirirken hangi yaklaşım doğru?",
                dogru="Önce yönetmeliği ihlal eden mevkiler elenir, sonra kalanlardan seçilir.",
                yanlislar={
                    "Eğimi en küçük olan mevki seçilir; en düz yer en güvenli yerdir.":
                        "Tek bir ölçüte bakıp karar verdin. Eğim, "
                        "yönetmeliğin üç maddesinden yalnızca biri; en düz "
                        "yer pekâlâ dere yatağının tabanı olabilir.",
                    "Suya en yakın mevki seçilir; su ne kadar yakınsa o kadar iyidir.":
                        "Yönetmeliği bir yarışma ölçütü gibi okudun. Madde "
                        "\"en yakını seç\" demiyor, bir ÜST SINIR koyuyor; "
                        "sınırın içinde kalan her mevki bu maddeden geçer.",
                    "Dört mevkinin eğim ve uzaklık ortalaması alınır, ortalamaya "
                    "en yakın mevki seçilir.":
                        "Ortalama, kural çiğneyen mevkileri de hesaba katar "
                        "ve onların kusurunu diğerlerinin içinde eritir. "
                        "Eleyici bir ölçüt ortalamayla yumuşatılamaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yerleşme kararı bir 'en iyi sayıyı bulma' işi değildir. Önce "
                    "ELEYİCİ ölçütler uygulanır: bir mevki tek bir kuralı bile "
                    "çiğniyorsa, diğer özellikleri ne kadar iyi olursa olsun listeden "
                    "çıkar. Ancak kalanlar arasında 'daha iyi/daha kötü' tartışılır."
                ),
                ipuclari=[
                    "Yönetmelikteki maddeler tavsiye mi, şart mı?",
                    "Bir mevki tek bir kuralı çiğniyorsa diğer üstünlükleri onu kurtarır mı?",
                ],
                puan=18,
            ),
            coklu_adimi(
                soru="Hangi mevkiler yönetmeliğe göre elenmeli? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=elenecekler,
                aciklama=(
                    "Elenenler ve gerekçeleri: " + "; ".join(
                        "{} ({})".format(m["ad"], m["kusur"]) for m in mevkiler if m["kusur"]
                    ) + ". Geriye tek uygun mevki kalır: " + dogru["ad"] + "."
                ),
                ipuclari=[
                    "Üç maddeyi dört karta tek tek uygula.",
                    "Zemin notunu okumayı unutma; sayılar iyi görünse de zemin eleyebilir.",
                ],
                puan=18,
            ),
            secim_adimi(
                soru="Kamp nereye kurulacak?",
                dogru=dogru["ad"],
                yanlislar={m["ad"]: kusur_teshisleri[m["kusur"]]
                           for m in mevkiler if m["kusur"]},
                rastgele=rastgele,
                aciklama=(
                    "{}: eğim %{} (sınır %{}), suya uzaklık {} m (sınır {} m), zemin "
                    "sıkı toprak. Üç maddeyi de sağlayan tek mevki."
                ).format(dogru["ad"], dogru["egim"], azami_egim, dogru["su"], azami_su),
                ipuclari=["Elemeden sonra geriye kaç mevki kaldı?"],
                puan=14,
            ),
            yorum_adimi(
                soru=("{} en düz zemine ve en yakın suya sahipti. Neden "
                      "seçilmedi?").format(tuzak["ad"]),
                dogru="Dere yatağında olduğu için; kar eriyince yatak suyla dolar.",
                yanlislar={
                    "Eğimi fazla olduğu için; dik zeminde çadır durmaz.":
                        "Ölçüm kartlarını karıştırdın. Bu mevkinin eğimi "
                        "tam tersine dördü arasındaki en küçüğüydü; onu "
                        "eleyen şey eğim değil, üstünde durduğu zemin.",
                    "Suya çok yakın olmak her zaman kötüdür; nem yapar, hasta eder.":
                        "Suya yakınlık bir kusur değil, yönetmeliğin aradığı "
                        "şart. Eleyen şey suyun yakın olması değil, kampın "
                        "suyun GEÇTİĞİ yatağa kurulacak olması.",
                    "Ölçümü yapılmadığı için; bilinmeyen yer seçilmez.":
                        "Bu mevkinin ölçüm kartı da var ve okundu. Mevki "
                        "bilgi eksikliğinden değil, okunan zemin notunun "
                        "kendisi yüzünden elendi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Dere yatağı tam da düz ve suya yakın OLDUĞU için caziptir; "
                    "tehlikesi de buradan gelir. Yatağı düzleştiren şey, yıllar "
                    "boyunca oradan geçen sudur. Kuru görünmesi, suyun bir daha "
                    "gelmeyeceği anlamına gelmez."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Kamp {} mevkiine kuruldu. İlkbaharda dere kabardığında {} "
            "mevkiindeki eski ocak taşları suyun altında kaldı; kimse orada değildi."
        ).format(dogru["ad"], tuzak["ad"]),
        odul={"erzak": 6, "cevher": 6, "itibar": 6},
    )


@bulmaca(ders="cografya", konu="harita_olcek", kademeler=(5, 10))
def harita_olcegi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Haritanın ölçeği yazmıyor; bilinen bir mesafeden çıkarılacak."""
    olcek_km = rastgele.choice([2, 4, 5, 10])          # 1 cm kaç km
    bilinen_cm = rastgele.choice([3, 4, 5, 6])
    bilinen_km = bilinen_cm * olcek_km
    olculen_cm = rastgele.choice([7, 8, 9, 11, 12])
    hedef_km = olculen_cm * olcek_km
    payda = olcek_km * 100000
    mevkiler = ad_sec(rastgele, MEVKI_ADLARI, 3)

    return Bulmaca(
        kod="cog-harita-olcek",
        ders="cografya",
        baslik="Ölçeksiz Harita",
        kademe=kademe,
        konu="harita_olcek",
        kazanim="Harita ölçeği; harita uzunluğundan gerçek uzunluğa geçiş.",
        dikkat=5,
        brifing=(
            "Arşivde bulunan bölge haritasının alt kenarı yırtılmış; ölçek "
            "tam oradaymış.\n\n"
            "Harita işe yarar durumda: yollar, dereler, mevkiler okunuyor. "
            "Sefer ekibi {} ile {} arası mesafeyi soruyor ve cetvelle "
            "haritada ölçtükleri {} santimetreden başka bilgileri yok.\n\n"
            "Neyse ki üs ile {} arasındaki gerçek mesafeyi biliyoruz."
        ).format(mevkiler[0], mevkiler[1], olculen_cm, mevkiler[2]),
        kanitlar=[
            Kanit("Eski yol kaydı",
                  "Üs ile {} arası kara yoluyla değil, kuş uçuşu {} "
                  "kilometredir.".format(mevkiler[2], bilinen_km),
                  bedel=2, kritik=True),
            Kanit("Cetvel ölçümü - 1",
                  "Haritada üs ile {} arası: {} cm".format(mevkiler[2], bilinen_cm),
                  bedel=1, kritik=True),
            Kanit("Cetvel ölçümü - 2",
                  "Haritada {} ile {} arası: {} cm".format(
                      mevkiler[0], mevkiler[1], olculen_cm),
                  bedel=1, kritik=True),
            Kanit("Harita kenarı",
                  "Ölçek yazan şerit yırtılmış. Kuzey oku ve lejant sağlam.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Haritanın ölçeğini nasıl buluruz?",
                dogru="Gerçek mesafeyi haritadaki uzunluğa böleriz; 1 cm'nin karşılığı çıkar.",
                yanlislar={
                    "Haritadaki uzunluğu gerçek mesafeye böleriz; çıkan sayı 1 cm'nin karşılığıdır.":
                        "Bölmeyi ters kurdun. Bu bölme, gerçekteki 1 "
                        "kilometrenin haritada kaç santimetre olduğunu "
                        "verir; sorulan ise haritadaki 1 santimetrenin "
                        "gerçekte ne kadar ettiği.",
                    "Gerçek mesafe ile haritadaki uzunluğu çarparız.":
                        "Çarpma iki uzunluğu birleştirir, birini diğerine "
                        "oranlamaz. Ölçek bir orandır; oran bölmeyle kurulur.",
                    "İki mesafenin farkını alırız.":
                        "Fark, farklı birimdeki iki sayıyı çıkarmak olurdu: "
                        "kilometreden santimetre. Ölçek, aradaki eksikliği "
                        "değil, birinin diğerinin kaç katı olduğunu söyler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ölçek, 'haritadaki 1 birim gerçekte kaç birimdir' sorusunun "
                    "cevabıdır. Bunu bulmak için gerçek uzunluğu harita uzunluğuna "
                    "böleriz. Ters bölme, gerçekte 1 km'nin haritada kaç cm olduğunu "
                    "verir; bu da kullanılabilir ama sonra ters çevirmeyi unutturur."
                ),
                ipuclari=[
                    "Ölçek bir ORANDIR: harita üzerindeki 1 cm neye karşılık geliyor?",
                    "Bilinen çifti kullan: {} cm kaç km ediyorsa, 1 cm onun "
                    "bölünmüşü eder.".format(bilinen_cm),
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Haritada 1 santimetre kaç kilometreye karşılık geliyor?",
                cevap=olcek_km,
                birim="km",
                aciklama="{} km ÷ {} cm = {} km/cm.".format(bilinen_km, bilinen_cm, olcek_km),
                yaygin_yanlislar={
                    bilinen_km:
                        "Bilinen gerçek mesafeyi olduğu gibi yazdın. O sayı "
                        "haritadaki {} santimetrenin karşılığı; sorulan ise "
                        "tek bir santimetrenin karşılığı.".format(bilinen_cm),
                    bilinen_cm / float(bilinen_km):
                        "Bölmeyi ters kurdun; haritadaki uzunluğu gerçek "
                        "mesafeye böldün. Bu sana 1 kilometrenin haritada "
                        "kaç santimetre olduğunu verir.",
                },
                ipuclari=["Bilinen gerçek mesafeyi, haritadaki uzunluğuna böl."],
                puan=12,
            ),
            sayi_adimi(
                soru="{} ile {} arası gerçekte kaç kilometre?".format(mevkiler[0], mevkiler[1]),
                cevap=hedef_km,
                birim="km",
                aciklama="{} cm × {} km/cm = {} km.".format(olculen_cm, olcek_km, hedef_km),
                yaygin_yanlislar={
                    olculen_cm:
                        "Haritada ölçülen uzunluğu yazdın. O sayı santimetre "
                        "cinsinden; gerçeğe geçmek için 1 cm'nin karşılığıyla "
                        "çarpman gerekiyor.",
                    olculen_cm / float(olcek_km):
                        "Çarpmak yerine böldün. Harita gerçeği küçültür; "
                        "haritadan gerçeğe giderken sayı büyümeli.",
                },
                ipuclari=["Ölçülen uzunluğu, 1 cm'nin karşılığıyla çarp."],
                puan=12,
            ),
            secim_adimi(
                soru="Bu haritanın kesir ölçeği aşağıdakilerden hangisidir?",
                dogru="1 / {}".format(payda),
                yanlislar={
                    "1 / {}".format(olcek_km * 1000):
                        "Kilometreyi metreye çevirip orada durdun. Kesir "
                        "ölçekte payda santimetre cinsindendir; metrede "
                        "bırakırsan ölçek yüz kat küçük görünür.",
                    "1 / {}".format(olcek_km * 10000):
                        "Çevrimin bir basamağını atladın. 1 metre 100 "
                        "santimetre, 1 kilometre 1.000 metre; ikisini "
                        "birlikte uygularsan sondaki sıfır sayısı değişir.",
                    "1 / {}".format(payda * 10):
                        "Bir sıfır fazla saydın. 1 kilometre 100.000 "
                        "santimetredir; oradaki sıfırları tek tek say.",
                },
                rastgele=rastgele,
                aciklama=(
                    "1 cm = {} km demek, 1 cm = {} cm demektir (1 km = 100.000 cm). "
                    "Kesir ölçek birimsizdir: pay ve payda aynı birimde olmalıdır."
                ).format(olcek_km, payda),
                ipuclari=[
                    "Kesir ölçekte pay ve payda AYNI birimdedir; km'yi cm'ye çevir.",
                    "1 km kaç santimetredir?",
                ],
                puan=12,
            ),
        ],
        kapanis=(
            "Haritanın kenarına ölçek elle yazıldı: 1 / {}. Bir daha kimsenin "
            "cetvelle uğraşması gerekmeyecek."
        ).format(payda),
        odul={"itibar": 5, "enerji": 3},
    )


@bulmaca(ders="cografya", konu="iklim", kademeler=(6, 11))
def yukselti_sicaklik(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki istasyon arasındaki sıcaklık farkından yükselti farkı çıkarılacak."""
    alt_yukselti = rastgele.choice([200, 300, 400, 500])
    fark_yukselti = rastgele.choice([600, 800, 1000, 1200, 1400])
    ust_yukselti = alt_yukselti + fark_yukselti
    alt_sicaklik = rastgele.choice([18, 20, 22, 24])
    sicaklik_farki = fark_yukselti / 100.0 * 0.5
    ust_sicaklik = alt_sicaklik - sicaklik_farki
    mevkiler = ad_sec(rastgele, MEVKI_ADLARI, 2)

    return Bulmaca(
        kod="cog-yukselti-sicaklik",
        ders="cografya",
        baslik="İki İstasyon",
        kademe=kademe,
        konu="iklim",
        kazanim="Yükseltiye bağlı sıcaklık değişimi; sıcaklık farkından yükselti çıkarma.",
        dikkat=6,
        brifing=(
            "Üssün iki hava istasyonu var: biri {} mevkiinde vadi tabanında, "
            "diğeri {} mevkiinde yamaçta.\n\n"
            "Vadi istasyonunun yükseltisi biliniyor: {} metre. Yamaç "
            "istasyonunun yükseltisi ise kayıtlarda yok - kuran ekip yazmayı "
            "unutmuş.\n\n"
            "Yamaç istasyonuna kışın erzak taşınacak; hangi yükseltide olduğunu "
            "bilmemiz gerekiyor, kar sınırı hesabı buna bağlı."
        ).format(mevkiler[0], mevkiler[1], alt_yukselti),
        kanitlar=[
            Kanit("Vadi istasyonu kaydı",
                  "Yükselti: {} m\nAynı gün, aynı saat sıcaklık: {} °C".format(
                      alt_yukselti, sy(alt_sicaklik)),
                  bedel=1, kritik=True),
            Kanit("Yamaç istasyonu kaydı",
                  "Yükselti: (yazılmamış)\nAynı gün, aynı saat sıcaklık: {} °C".format(
                      sy(ust_sicaklik)),
                  bedel=1, kritik=True),
            Kanit("Meteoroloji el kitabı",
                  "\"Troposferde hava, yükseldikçe her 100 metrede ortalama "
                  "0,5 °C soğur. Hesaplarda bu değer kullanılır.\"",
                  bedel=2, kritik=True),
            Kanit("Gözlem notu",
                  "İki ölçüm aynı gün, aynı saatte alınmış. Hava açık, iki "
                  "istasyon da aynı yamaçta ve aynı bakıda.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Yamaç istasyonunun yükseltisini bulmak için hangi yol doğru?",
                dogru="Sıcaklık farkı 0,5'e bölünür, bulunan sayı 100 ile çarpılır.",
                yanlislar={
                    "Sıcaklık farkı doğrudan 100 ile çarpılır; her derece 100 metredir.":
                        "Bir adımı atladın: her 100 metrede düşen 1 °C değil, "
                        "0,5 °C. Farkı doğrudan 100 ile çarparsan yükseltiyi "
                        "olması gerekenin yarısı bulursun.",
                    "Sıcaklık farkı 0,5 ile çarpılıp 100 ile çarpılır; kuraldaki sayılar çarpılır.":
                        "Bölmen gereken yerde çarptın. 0,5 ile çarpmak farkı "
                        "küçültür; oysa her yarım derecelik düşüş için bir "
                        "100 metre saymalısın.",
                    "İki sıcaklığın ortalaması alınıp vadi yükseltisine eklenir.":
                        "Ortalama iki ölçümün ortasını verir, aralarındaki "
                        "farkı değil. Yükseltiyi belirleyen şey sıcaklıkların "
                        "ortası değil, aradaki düşüş miktarı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kural şu: 100 metre çıkınca 0,5 °C düşer. O hâlde 1 °C düşüş "
                    "200 metreye karşılık gelir. Sıcaklık farkını önce 0,5'e bölüp "
                    "kaç tane '100 metrelik basamak' olduğunu buluyoruz, sonra 100 "
                    "ile çarpıyoruz. Doğrudan 100 ile çarpmak sonucu yarıya düşürür."
                ),
                ipuclari=[
                    "1 °C sıcaklık düşüşü kaç metreye karşılık gelir?",
                    "Önce kaç tane 0,5 °C'lik basamak olduğunu bul.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="İki istasyon arasındaki sıcaklık farkı kaç °C?",
                cevap=sicaklik_farki,
                birim="°C",
                aciklama="{} − {} = {} °C.".format(
                    sy(alt_sicaklik), sy(ust_sicaklik), sy(sicaklik_farki)),
                yaygin_yanlislar={
                    -sicaklik_farki:
                        "Çıkarmayı ters kurdun ve eksi bir fark yazdın. "
                        "Yamaç istasyonu vadiden daha soğuk; büyük olandan "
                        "küçüğü çıkarmalısın.",
                    alt_sicaklik + ust_sicaklik:
                        "İki sıcaklığı topladın. Fark bir toplam değil, iki "
                        "ölçümün arasındaki açıklıktır.",
                },
                ipuclari=["Vadi sıcaklığından yamaç sıcaklığını çıkar."],
                tolerans=0.05,
                puan=10,
            ),
            sayi_adimi(
                soru="Yamaç istasyonu, vadiden kaç metre yüksekte?",
                cevap=fark_yukselti,
                birim="m",
                aciklama="{} ÷ 0,5 = {} basamak; {} × 100 = {} metre.".format(
                    sy(sicaklik_farki), sy(sicaklik_farki / 0.5),
                    sy(sicaklik_farki / 0.5), fark_yukselti),
                yaygin_yanlislar={
                    sicaklik_farki * 100:
                        "0,5'e bölme adımını atladın. Her 100 metrede "
                        "sıcaklık 0,5 °C düşüyor; farkı doğrudan 100 ile "
                        "çarpınca gerçek yükseltinin yarısı çıkar.",
                    sicaklik_farki * 0.5 * 100:
                        "0,5 ile çarptın, oysa ona bölmen gerekiyordu. "
                        "Çarpma basamak sayısını azaltır; sen kaç tane yarım "
                        "derecelik basamak olduğunu arıyorsun.",
                },
                ipuclari=["Farkı 0,5'e böl, çıkanı 100 ile çarp."],
                tolerans=1.0,
                puan=14,
            ),
            sayi_adimi(
                soru="Yamaç istasyonunun deniz seviyesinden yükseltisi kaç metre?",
                cevap=ust_yukselti,
                birim="m",
                aciklama="{} + {} = {} metre.".format(
                    alt_yukselti, fark_yukselti, ust_yukselti),
                yaygin_yanlislar={
                    fark_yukselti:
                        "İki istasyon arasındaki farkı yazdın. Sorulan, "
                        "deniz seviyesinden ölçülen yükselti; vadinin kendi "
                        "yükseltisi de bu sayının içinde olmalı.",
                    alt_yukselti - fark_yukselti:
                        "Farkı çıkardın. Yamaç istasyonu vadiden YÜKSEKTE "
                        "olduğu için bulduğun farkı vadi yükseltisine "
                        "eklemelisin.",
                },
                ipuclari=["Vadi yükseltisine, bulduğun farkı ekle."],
                tolerans=1.0,
                puan=10,
            ),
        ],
        kapanis=(
            "Yamaç istasyonunun künyesine {} metre yazıldı. Kış erzak planı "
            "buna göre yeniden yapıldı."
        ).format(ust_yukselti),
        odul={"enerji": 5, "itibar": 5},
    )


@bulmaca(ders="cografya", konu="yer_sekilleri", kademeler=(7, 12))
def izohips_okuma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Eş yükselti eğrilerinin sıklığından eğim ve akış yönü okunacak."""
    aralik = rastgele.choice([25, 50, 100])
    dar_mesafe = rastgele.choice([100, 150, 200])       # metre, yatayda
    genis_mesafe = dar_mesafe * rastgele.choice([3, 4, 5])
    egri_sayisi = rastgele.choice([4, 5, 6])
    yukselti_farki = aralik * egri_sayisi
    dar_egim = yukselti_farki / (dar_mesafe * egri_sayisi) * 100
    yamaclar = ad_sec(rastgele, MEVKI_ADLARI, 2)

    return Bulmaca(
        kod="cog-izohips",
        ders="cografya",
        baslik="Eğrilerin Dili",
        kademe=kademe,
        konu="yer_sekilleri",
        kazanim="Eş yükselti eğrileri; eğri sıklığından eğimi ve akış yönünü okuma.",
        dikkat=6,
        brifing=(
            "Su borusu hattı için iki yamaçtan biri seçilecek: {} ya da {}.\n\n"
            "Elimizdeki topografya haritasında yamaçlar eş yükselti eğrileriyle "
            "gösterilmiş. Eğriler arasındaki yükselti farkı {} metre. Ama "
            "haritada hiçbir yere \"eğim\" yazmıyor; ekip \"gözle bakınca ikisi "
            "de yamaç işte\" diyor.\n\n"
            "Boru kendi ağırlığıyla akacak, pompa kullanmayacağız. Yanlış yamaç "
            "seçilirse ya su akmaz ya da basınç boruyu patlatır."
        ).format(yamaclar[0], yamaclar[1], aralik),
        kanitlar=[
            Kanit("Harita kesiti - {}".format(yamaclar[0]),
                  "{} eş yükselti eğrisi, yatayda toplam {} metrelik şeride "
                  "sıkışmış.".format(egri_sayisi, dar_mesafe * egri_sayisi),
                  bedel=1, kritik=True),
            Kanit("Harita kesiti - {}".format(yamaclar[1]),
                  "{} eş yükselti eğrisi, yatayda {} metreye yayılmış.".format(
                      egri_sayisi, genis_mesafe * egri_sayisi),
                  bedel=1, kritik=True),
            Kanit("Harita lejantı",
                  "Eş yükselti eğrileri arası fark: {} m. Eğriler aynı "
                  "yükseltideki noktaları birleştirir.".format(aralik),
                  bedel=1, kritik=True),
            Kanit("Mühendis notu",
                  "\"Boru kendi ağırlığıyla akacaksa eğim gerekir, ama fazla "
                  "eğim basıncı aşırı artırır. Orta eğimli yamaç istiyoruz.\"",
                  bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="Eş yükselti eğrileri arasındaki mesafe neyi gösterir?",
                dogru="Eğriler birbirine ne kadar yakınsa eğim o kadar diktir.",
                yanlislar={
                    "Eğriler birbirine ne kadar yakınsa eğim o kadar azdır.":
                        "İlişkiyi ters kurdun. Eğriler arasındaki yükselti "
                        "farkı her yerde aynı; aynı farkı daha KISA yatay "
                        "mesafede aşmak yamacı dikleştirir.",
                    "Eğriler arası mesafe yükseltiyi gösterir, eğimle ilgisi yoktur.":
                        "Yükseltiyi eğrinin kendi değeri söyler, aralarındaki "
                        "boşluk değil. O boşluk yatayda ölçülür ve dikey "
                        "farkla birlikte eğimi verir.",
                    "Eğri sayısı arttıkça eğim azalır; çok eğri düz arazi demektir.":
                        "Eğri sayısı tek başına eğimi belirlemez. Aynı sayıda "
                        "eğri geniş bir şeride yayılırsa yamaç yumuşak, dar "
                        "bir şeride sıkışırsa diktir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki eğri arasındaki yükselti farkı sabittir ({} m). Değişen tek "
                    "şey, bu farkı aşmak için gereken YATAY mesafedir. Aynı çıkışı "
                    "daha kısa yolda yapmak, daha dik bir yamaç demektir - tıpkı "
                    "merdiven basamaklarının sıklaşması gibi."
                ).format(aralik),
                ipuclari=[
                    "Eğriler arasındaki yükselti farkı her yerde aynı. Değişen ne?",
                    "Aynı yüksekliğe kısa mesafede çıkmak mı zordur, uzun mesafede mi?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="{} yamacında toplam kaç metre yükselti aşılıyor?".format(yamaclar[0]),
                cevap=yukselti_farki,
                birim="m",
                aciklama="{} eğri × {} m = {} m.".format(egri_sayisi, aralik, yukselti_farki),
                yaygin_yanlislar={
                    aralik:
                        "Tek bir eğri aralığını yazdın. Yamaçta bu aralıktan "
                        "birden çok kez geçiliyor; hepsini saymalısın.",
                    # dar_mesafe ile aralık aynı sayı çıkarsa bu yanlış,
                    # doğru cevapla çakışır; o tohumlarda eklenmiyor.
                    **({dar_mesafe * egri_sayisi:
                        "Yatay mesafeyi yazdın. Sorulan, yamacın yerde "
                        "kapladığı uzunluk değil, tırmanılan DİKEY yükselti."}
                       if dar_mesafe != aralik else {}),
                },
                ipuclari=["Eğri sayısını, eğriler arası farkla çarp."],
                puan=10,
            ),
            sayi_adimi(
                soru=("{} yamacının ortalama eğimi yüzde kaçtır? "
                      "(yükselti farkı ÷ yatay mesafe × 100)").format(yamaclar[0]),
                cevap=dar_egim,
                birim="%",
                aciklama="{} ÷ {} × 100 = %{}.".format(
                    yukselti_farki, dar_mesafe * egri_sayisi, sy(round(dar_egim, 2))),
                yaygin_yanlislar={
                    dar_egim / 100.0:
                        "Yüzle çarpmayı unuttun. Bulduğun oran doğru ama "
                        "ondalık biçimde kaldı; soru eğimi yüzde cinsinden "
                        "istiyor.",
                    # Yatay mesafe ile dikey fark eşitse ters bölme de aynı
                    # sayıyı verir; o tohumlarda bu teşhis eklenmiyor.
                    **({dar_mesafe * egri_sayisi / float(yukselti_farki) * 100:
                        "Bölmeyi ters kurdun: yatay mesafeyi dikey yükseltiye "
                        "böldün. Eğim, dikey yükselmenin yatay mesafeye "
                        "oranıdır."}
                       if dar_mesafe != aralik else {}),
                },
                ipuclari=["Dikey yükselmeyi yatay mesafeye böl, yüzle çarp."],
                tolerans=0.2,
                puan=14,
            ),
            yorum_adimi(
                soru="Boru hattı için hangi yamaç daha uygun?",
                dogru="{}; eğrileri seyrek, eğimi daha yumuşak.".format(yamaclar[1]),
                yanlislar={
                    "{}; eğrileri sık olduğu için su daha hızlı akar.".format(yamaclar[0]):
                        "Sıklığı doğru okudun ama istenen şeyi değil. "
                        "Mühendis en hızlı akışı değil orta eğimi istiyor; "
                        "dik yamaçta hızlanan su boruyu basınçla zorlar.",
                    "İkisi de aynıdır; eğri sıklığı boruyu etkilemez.":
                        "Eğri sıklığı eğimi, eğim de borudaki basıncı "
                        "belirler. İki yamaçta aynı yükselti aşılıyor ama "
                        "aynı diklikte değiller.",
                    "{}; eğriler sıksa yükselti farkı azdır.".format(yamaclar[0]):
                        "Sıklık, aşılan yükselti farkını değiştirmez. İki "
                        "yamaçta da aynı sayıda eğri geçiliyor; değişen tek "
                        "şey bunun kaç metrelik yatay mesafeye yayıldığı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki yamaçta da aynı yükselti farkı aşılıyor, ama {} bunu çok "
                    "daha uzun yatay mesafede yapıyor; yani eğimi yumuşak. Mühendis "
                    "'orta eğim' istedi: dik yamaçta su hızlanır ve basınç boruyu zorlar."
                ).format(yamaclar[1]),
                puan=12,
            ),
        ],
        kapanis=(
            "Hat {} yamacından geçirildi. Su pompasız aktı, basınç ölçümü "
            "sınırların içinde kaldı."
        ).format(yamaclar[1]),
        odul={"cevher": 6, "enerji": 5},
    )


# ==========================================================================
# KONUM, NÜFUS, KAYNAK
# ==========================================================================

@bulmaca(ders="cografya", konu="koordinat_saat", kademeler=(6, 12))
def boylam_saati(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Telsiz kayıtlarındaki yerel saat farkından boylam farkı çıkarılacak."""
    boylam_farki = rastgele.choice([5, 10, 15, 20, 25, 30])
    dakika_farki = boylam_farki * 4
    us_boylami = rastgele.choice([30, 35, 40, 45])
    dogu_mu = rastgele.choice([True, False])
    karakol_boylami = us_boylami + boylam_farki if dogu_mu else us_boylami - boylam_farki
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="cog-boylam-saat",
        ders="cografya",
        baslik="Telsizdeki Saat",
        kademe=kademe,
        konu="koordinat_saat",
        kazanim="Boylam ve yerel saat ilişkisi; 15 boylam farkı = 1 saat.",
        dikkat=6,
        brifing=(
            "{} karakolu her gün, kendi yerel saatiyle tam öğlen (güneş en "
            "tepedeyken) telsizle bildirim geçiyor.\n\n"
            "Üssümüzde bu bildirim, bizim yerel saatimizle öğlenden {} dakika "
            "{} geliyor. Telsiz anlıktır; gecikme yok.\n\n"
            "Karakolun boylamı haritada okunamıyor - o köşe yanmış. Üssün "
            "boylamı ise {} derece."
        ).format(mevki, dakika_farki, "önce" if dogu_mu else "sonra", us_boylami),
        kanitlar=[
            Kanit("Telsiz kaydı",
                  "Karakol bildirimi, üssün yerel saatiyle öğlenden {} dakika "
                  "{} alınıyor. Her gün aynı.".format(
                      dakika_farki, "önce" if dogu_mu else "sonra"),
                  bedel=1, kritik=True),
            Kanit("Üs künyesi", "Üssün boylamı: {}° {}".format(
                us_boylami, "Doğu"), bedel=1, kritik=True),
            Kanit("Seyir el kitabı",
                  "\"Dünya 24 saatte 360° döner. Buradan: 15 boylam = 1 saat, "
                  "1 boylam = 4 dakika. Doğudaki yer yerel öğleni ÖNCE yaşar.\"",
                  bedel=2, kritik=True),
            Kanit("Telsizci notu",
                  "\"Bildirim karakolun kendi öğleninde gönderiliyor, bizim "
                  "saatimize göre değil. Sinyal gecikmesi ölçülemeyecek kadar az.\"",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bu saat farkı neyi gösteriyor?",
                dogru="İki yerin farklı boylamda, yerel öğlenlerinin ayrı anlarda olduğunu.",
                yanlislar={
                    "Karakolun daha yüksek bir enlemde olduğunu.":
                        "Enlemle boylamı karıştırdın. Yerel saat farkını "
                        "yaratan şey kuzey-güney değil, DOĞU-BATI konumudur.",
                    "Telsiz sinyalinin yolda geciktiğini.":
                        "Farkı iletişim gecikmesine bağladın. Telsiz sinyali "
                        "neredeyse anında ulaşır; buradaki fark saatlerle "
                        "ölçülüyor.",
                    "İki yerin farklı saat dilimi seçtiğini; bu coğrafi değil idari bir farktır.":
                        "Saat dilimleri gerçekten idaridir ama burada "
                        "ölçülen şey yerel öğle vakti - yani güneşin "
                        "gerçek konumu.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yerel öğlen, güneşin o boylam için en tepede olduğu andır. "
                    "İki yer aynı anda öğleni yaşamıyorsa, boylamları farklıdır. "
                    "Enlem farkı gündüz UZUNLUĞUNU değiştirir, öğlen ANINI değil."
                ),
                ipuclari=[
                    "Öğlen, güneşin o yer için en tepede olduğu andır. Neye bağlı?",
                    "Enlem mi boylam mı yerel saati belirler?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="İki yer arasında kaç derecelik boylam farkı var?",
                cevap=boylam_farki,
                birim="derece",
                aciklama="{} dakika ÷ 4 dakika/derece = {}°.".format(
                    dakika_farki, boylam_farki),
                ipuclari=[
                    "1 boylam farkı kaç dakika eder?",
                    "Dakika farkını, bir boylamın karşılığı olan dakikaya böl.",
                ],
                puan=14,
            ),
            secim_adimi(
                soru="Karakol üssün doğusunda mı, batısında mı?",
                dogru="Üssün doğusunda" if dogu_mu else "Üssün batısında",
                yanlislar={
                    ("Üssün batısında" if dogu_mu else "Üssün doğusunda"):
                        "Yönü ters aldın. Güneş doğudan doğar: doğudaki yerde "
                        "öğle vakti DAHA ERKEN olur.",
                    "Aynı boylamda; yalnızca enlemi farklı":
                        "Aynı boylamda olsalardı yerel öğle vakitleri de aynı "
                        "olurdu. Saat farkının kendisi boylam farkının kanıtı.",
                    "Belirlenemez; saat farkı yön hakkında bilgi vermez":
                        "Saat farkı tam da yön bilgisi verir: hangi tarafta "
                        "öğlenin daha erken olduğu, o yerin doğuda mı batıda "
                        "mı olduğunu söyler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Doğudaki yer güneşi önce görür, yerel öğlenini önce yaşar. "
                    "Karakolun bildirimi kendi öğleninde gönderiliyor ve bize bizim "
                    "öğlenimizden {} ulaşıyor; demek ki karakol {}mızdadır."
                ).format("önce" if dogu_mu else "sonra", "doğu" if dogu_mu else "batı"),
                ipuclari=["Güneş hangi yönden doğar? Öğleni önce kim yaşar?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Karakolun boylamı kaç derecedir?",
                cevap=karakol_boylami,
                birim="derece",
                aciklama="{}° {} {}° = {}°.".format(
                    us_boylami, "+" if dogu_mu else "−", boylam_farki, karakol_boylami),
                ipuclari=["Üssün boylamına, bulduğun farkı doğru yönde uygula."],
                puan=12,
            ),
        ],
        kapanis=(
            "Karakolun boylamı {}° olarak haritaya işlendi. Yanmış köşe artık "
            "sorun değil."
        ).format(karakol_boylami),
        odul={"itibar": 6, "enerji": 4},
    )


@bulmaca(ders="cografya", konu="nufus", kademeler=(5, 10))
def nufus_yogunlugu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kalabalık bölge ile yoğun bölge aynı şey değil."""
    a_nufus = rastgele.randrange(24, 60) * 100
    a_alan = rastgele.choice([200, 300, 400])
    b_alan = rastgele.choice([40, 50, 60])
    b_nufus = rastgele.randrange(10, 20) * 100
    a_yogunluk = a_nufus / a_alan
    b_yogunluk = b_nufus / b_alan
    # B daha az nüfuslu ama daha yoğun olsun
    while b_nufus >= a_nufus or b_yogunluk <= a_yogunluk:
        b_nufus = rastgele.randrange(10, 20) * 100
        b_alan = rastgele.choice([30, 40, 50])
        b_yogunluk = b_nufus / b_alan
        a_yogunluk = a_nufus / a_alan
    bolgeler = ad_sec(rastgele, MEVKI_ADLARI, 2)

    return Bulmaca(
        kod="cog-nufus-yogunlugu",
        ders="cografya",
        baslik="Kalabalık mı, Sıkışık mı?",
        kademe=kademe,
        konu="nufus",
        kazanim="Nüfus yoğunluğu kavramı; nüfus ile yoğunluğu ayırt etme.",
        dikkat=5,
        brifing=(
            "Merkez, iki yerleşim bölgesinden birine sağlık ekibi gönderecek. "
            "Ekip, insanların en sıkışık yaşadığı yere gitmeli: bulaşıcı "
            "hastalık riski orada yüksek.\n\n"
            "{} bölgesinde {} kişi, {} bölgesinde {} kişi yaşıyor. Merkez "
            "\"nüfusu fazla olana gönderin\" diye yazmış.\n\n"
            "Ama sen alanları da görüyorsun ve bir şey dikkatini çekiyor."
        ).format(bolgeler[0], a_nufus, bolgeler[1], b_nufus),
        kanitlar=[
            Kanit("{} sayımı".format(bolgeler[0]),
                  "Nüfus: {} kişi\nYüzölçümü: {} km²".format(a_nufus, a_alan),
                  bedel=1, kritik=True),
            Kanit("{} sayımı".format(bolgeler[1]),
                  "Nüfus: {} kişi\nYüzölçümü: {} km²".format(b_nufus, b_alan),
                  bedel=1, kritik=True),
            Kanit("Sağlık ekibi talimatı",
                  "\"Bulaş riski, kişi SAYISIYLA değil, birim alandaki kişi "
                  "sayısıyla artar. Yoğunluğu yüksek yere öncelik verin.\"",
                  bedel=2, kritik=True),
            Kanit("Merkez yazısı",
                  "\"Nüfusu fazla olan bölgeye gidilsin.\" (alan bilgisi "
                  "merkeze ulaşmamış)", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="\"İnsanların en sıkışık yaşadığı yer\" hangi hesapla bulunur?",
                dogru="Nüfus ÷ yüzölçümü (kişi/km²)",
                yanlislar={
                    "Yüzölçümü ÷ nüfus (km²/kişi)":
                        "Bölmeyi ters kurdun. Bu, kişi başına düşen ALANı "
                        "verir; sıkışıklık ise birim alana düşen KİŞİ "
                        "sayısıdır.",
                    "Nüfus × yüzölçümü (kişi·km²)":
                        "Çarptın. Çarpım geniş ve kalabalık bölgeyi en üste "
                        "çıkarır; oysa geniş alan sıkışıklığı azaltır.",
                    "En büyük nüfusa sahip bölge doğrudan seçilir":
                        "Yalnızca nüfusa baktın. Kalabalık bir bölge çok "
                        "genişse insanlar sıkışık yaşamıyor olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Nüfus yoğunluğu = nüfus ÷ alan. Bu, 1 km²'ye kaç kişi düştüğünü "
                    "söyler. Toplam nüfus 'kaç kişi var' sorusunu yanıtlar; sıkışıklığı "
                    "değil. Geniş bir bölgeye yayılmış kalabalık, dar bir alana "
                    "sıkışmış daha küçük bir topluluktan daha seyrek olabilir."
                ),
                ipuclari=[
                    "Sıkışıklık, kişi sayısına mı yoksa kişi başına düşen yere mi bağlı?",
                    "Aynı sayıda insan iki kat geniş alana yayılırsa ne değişir?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="{} bölgesinin nüfus yoğunluğu kaç kişi/km²?".format(bolgeler[0]),
                cevap=a_yogunluk,
                birim="kişi/km²",
                aciklama="{} ÷ {} = {} kişi/km².".format(
                    a_nufus, a_alan, sy(round(a_yogunluk, 2))),
                ipuclari=["Nüfusu alana böl."],
                tolerans=0.5,
                puan=10,
            ),
            sayi_adimi(
                soru="{} bölgesinin nüfus yoğunluğu kaç kişi/km²?".format(bolgeler[1]),
                cevap=b_yogunluk,
                birim="kişi/km²",
                aciklama="{} ÷ {} = {} kişi/km².".format(
                    b_nufus, b_alan, sy(round(b_yogunluk, 2))),
                ipuclari=["Aynı işlemi ikinci bölge için yap."],
                tolerans=0.5,
                puan=10,
            ),
            yorum_adimi(
                soru="Sağlık ekibi nereye gitmeli ve merkezin yazısı neden yanılıyor?",
                dogru="{} bölgesine; nüfusu az olsa da yoğunluğu çok yüksek.".format(bolgeler[1]),
                yanlislar={
                    "{} bölgesine; nüfusu fazla olduğu için risk oradadır.".format(bolgeler[0]):
                        "Yine yalnızca nüfusa baktın - merkezin yazısını "
                        "yanıltan tam olarak bu. Bulaş riskini belirleyen "
                        "insanların ne kadar SIKIŞIK yaşadığı.",
                    "İki bölgeye de eşit ekip gönderilmeli; yoğunluk fark etmez.":
                        "Yoğunluğu önemsiz saydın. Aynı sayıda insan, dar bir "
                        "alanda çok daha sık temas eder.",
                    "{} bölgesine; geniş alan hastalığı daha hızlı yayar.".format(bolgeler[0]):
                        "İlişkiyi ters kurdun. Geniş alan teması azaltır; "
                        "yayılmayı hızlandıran şey darlık.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{} bölgesi {} kişiyle daha kalabalık ama {} km²'ye yayılmış "
                    "(≈{} kişi/km²). {} ise {} kişiyi {} km²'ye sığdırmış "
                    "(≈{} kişi/km²). Merkez alan bilgisini görmediği için 'kalabalık' "
                    "ile 'yoğun' kavramlarını karıştırmış."
                ).format(bolgeler[0], a_nufus, a_alan, sy(round(a_yogunluk, 1)),
                         bolgeler[1], b_nufus, b_alan, sy(round(b_yogunluk, 1))),
                puan=14,
            ),
        ],
        kapanis=(
            "Ekip {} bölgesine gönderildi. Merkeze de kısa bir not düşüldü: "
            "\"Nüfus verisi alan bilgisi olmadan yorumlanamaz.\""
        ).format(bolgeler[1]),
        odul={"itibar": 6, "erzak": 3},
    )


@bulmaca(ders="cografya", konu="kaynak_yonetimi", kademeler=(8, 13))
def su_butcesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yenilenme hızı ile tüketim hızı; sürdürülebilir sınır."""
    yenilenme = rastgele.choice([120, 150, 180, 200])   # m³/gün
    kisi_basi = rastgele.choice([40, 50, 60])           # litre/gün
    mevcut_kisi = rastgele.randrange(120, 220, 10)
    tuketim = mevcut_kisi * kisi_basi / 1000.0          # m³/gün
    azami_kisi = int(yenilenme * 1000 // kisi_basi)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="cog-su-butcesi",
        ders="cografya",
        baslik="Su Bütçesi",
        kademe=kademe,
        konu="kaynak_yonetimi",
        kazanim="Yenilenebilir kaynakta yenilenme hızı - tüketim dengesi; taşıma kapasitesi.",
        dikkat=6,
        brifing=(
            "Üssün suyu {} kaynağından geliyor. Kaynak kurumuyor ama sonsuz "
            "da değil: yer altı haznesi belli bir hızda doluyor.\n\n"
            "Komutan üsse yeni personel almak istiyor ve \"kaynak var, su "
            "sorunumuz yok\" diyor. Hidroloji ekibi ise itiraz ediyor ama "
            "itirazlarını sayıya dökmemişler.\n\n"
            "Şu an üste {} kişi var. Üssün su bakımından kaç kişiyi "
            "taşıyabileceğini bulmamız gerekiyor."
        ).format(mevki, mevcut_kisi),
        kanitlar=[
            Kanit("Hidroloji raporu",
                  "Haznenin günlük yenilenme miktarı: {} m³/gün. Bu, yağış ve "
                  "kar erimesiyle hazneye giren ortalama miktardır.".format(yenilenme),
                  bedel=2, kritik=True),
            Kanit("Tüketim kaydı",
                  "Kişi başı günlük su kullanımı: {} litre (içme, yemek, "
                  "temizlik dahil).".format(kisi_basi), bedel=1, kritik=True),
            Kanit("Personel listesi", "Üstteki toplam kişi: {}".format(mevcut_kisi),
                  bedel=1, kritik=True),
            Kanit("Hazne ölçümü",
                  "Haznede şu an yaklaşık 4.000 m³ su birikmiş durumda. "
                  "Seviye son aylarda sabit.", bedel=1),
            Kanit("Birim tablosu", "1 m³ = 1.000 litre", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Üssün su bakımından taşıyabileceği kişi sayısını ne belirler?",
                dogru="Günlük yenilenme; birikim tükenir, yenilenme sürer.",
                yanlislar={
                    "Haznede şu an biriken toplam su; büyük hazne büyük nüfus taşır.":
                        "Stoğa baktın. Birikmiş su bir kez tüketilir ve "
                        "biter; sürekli kaç kişinin yaşayabileceğini belirleyen "
                        "şey her gün YENİLENEN miktar.",
                    "Haznedeki birikim ile günlük yenilenmenin toplamı.":
                        "Bir kerelik stoğu sürekli gelirle topladın. Toplam "
                        "ilk günler için doğru olabilir ama uzun vadede "
                        "yalnızca yenilenme sayılır.",
                    "Mevcut kişi sayısı; kaynak kendini ona göre ayarlar.":
                        "Kaynağın talebe uyduğunu varsaydın. Yağış ve kaynak "
                        "debisi üssün nüfusuna bakmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Haznedeki 4.000 m³ bir kerelik stoktur: tüketim yenilenmeyi "
                    "aşarsa er ya da geç biter. Sürekli olarak taşınabilecek nüfusu "
                    "belirleyen şey akış hızıdır - yani günlük yenilenme. Stok yalnızca "
                    "kuraklık gibi geçici dönemlerde tampon görevi görür."
                ),
                ipuclari=[
                    "Bir kaynağın 'sürdürülebilir' sınırı, birikmiş miktara mı yoksa "
                    "yenilenme hızına mı bağlıdır?",
                    "Haznedeki su tüketilirse yerine ne koyacak?",
                ],
                puan=20,
            ),
            sayi_adimi(
                soru="Üssün şu anki günlük su tüketimi kaç m³?",
                cevap=tuketim,
                birim="m³/gün",
                aciklama="{} kişi × {} litre = {} litre = {} m³/gün.".format(
                    mevcut_kisi, kisi_basi, mevcut_kisi * kisi_basi, sy(tuketim)),
                ipuclari=[
                    "Kişi sayısını kişi başı kullanımla çarp.",
                    "Litreyi m³'e çevirmeyi unutma.",
                ],
                tolerans=0.05,
                puan=14,
            ),
            sayi_adimi(
                soru="Üs, su bakımından en fazla kaç kişiyi sürekli taşıyabilir?",
                cevap=azami_kisi,
                birim="kişi",
                aciklama="{} m³ = {} litre; {} ÷ {} = {} kişi.".format(
                    yenilenme, yenilenme * 1000, yenilenme * 1000, kisi_basi, azami_kisi),
                ipuclari=[
                    "Günlük yenilenmeyi litreye çevir.",
                    "Sonra kişi başı kullanıma böl.",
                ],
                tolerans=1.0,
                puan=16,
            ),
            yorum_adimi(
                soru="Komutanın \"su sorunumuz yok\" değerlendirmesi doğru mu?",
                dogru="Şu an doğru ama sınırlı; {} kişiden sonra hazne boşalır.".format(azami_kisi),
                yanlislar={
                    "Tamamen doğru; kaynak kurumadığı sürece hiçbir sınır yoktur.":
                        "Sınırsızlık varsaydın. Kaynak kurumasa da günlük "
                        "yenilenme belirli; o miktar belirli sayıda kişiyi "
                        "taşır.",
                    "Tamamen yanlış; üs zaten kapasitesinin üzerindedir.":
                        "Ters uca gittin. Hesabı yap: bugünkü nüfus "
                        "yenilenmenin taşıyabileceğinin altında.",
                    "Belirlenemez; yenilenme miktarıyla nüfus ilişkilendirilemez.":
                        "Bağı koparttın. Günlük yenilenmeyi kişi başı günlük "
                        "tüketime bölmek doğrudan taşınabilir nüfusu verir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir kaynağın 'bitmemesi' ile 'sınırsız olması' aynı şey değildir. "
                    "Tüketim yenilenmenin altında kaldığı sürece sistem sürdürülebilir; "
                    "üstüne çıktığı gün stok erimeye başlar ve bu genellikle geç fark "
                    "edilir, çünkü ilk aylarda musluktan su akmaya devam eder."
                ),
                puan=14,
            ),
        ],
        kapanis=(
            "Rapor komutana verildi: üssün su tavanı {} kişi. Yeni personel "
            "alımı bu sayıya göre planlandı, ayrıca yağmur suyu toplama "
            "önerisi eklendi."
        ).format(azami_kisi),
        odul={"erzak": 8, "enerji": 6, "itibar": 8},
    )


@bulmaca(ders="cografya", konu="yon_bulma", kademeler=(3, 8))
def golge_yonu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Pusula bozuk; yön gölgeden bulunacak."""
    saat = rastgele.choice(["sabah", "öğlen", "ikindi"])
    golge_yonu_metni = {"sabah": "batıya", "öğlen": "kuzeye", "ikindi": "doğuya"}[saat]
    aciklama_metni = {
        "sabah": "Sabah güneş doğudadır; gölgeler ters yöne, yani batıya uzanır.",
        "öğlen": ("Kuzey yarım kürede öğlen güneş güneydedir; gölgeler kuzeye "
                  "uzanır."),
        "ikindi": "İkindide güneş batıdadır; gölgeler doğuya uzanır.",
    }[saat]
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    yanlis_yonler = [y for y in ["kuzeye", "güneye", "doğuya", "batıya"]
                     if y != golge_yonu_metni]

    return Bulmaca(
        kod="cog-golge-yonu",
        ders="cografya",
        baslik="Pusulasız Keşif",
        kademe=kademe,
        konu="yon_bulma",
        kazanim="Güneşin günlük görünen hareketi ile yön bulma.",
        dikkat=5,
        brifing=(
            "{} keşif ekibinin pusulası düşüp kırılmış. Ekip {} mevkiinde ve "
            "üsse dönmek için kuzeye gitmeleri gerekiyor.\n\n"
            "Telsizden \"yön bulamıyoruz\" diye haber geçtiler. Saat {}; hava "
            "açık, güneş görünüyor ve etrafta uzun direkler var.\n\n"
            "Onlara ne yapacaklarını söylemen gerekiyor."
        ).format(kisi, mevki, saat),
        kanitlar=[
            Kanit("Telsiz konuşması",
                  "\"Pusula kırık. Saat {}. Güneş açık seçik görünüyor, "
                  "direklerin gölgesi net.\"".format(saat), bedel=1, kritik=True),
            Kanit("Seyir el kitabı",
                  "\"Güneş doğudan doğar, batıdan batar. Kuzey yarım kürede "
                  "yerel öğlende güneş güney yönündedir. Gölge, güneşin tam "
                  "ters yönüne uzanır.\"", bedel=2, kritik=True),
            Kanit("Bölge künyesi",
                  "Üs ve çevresi kuzey yarım kürede, orta enlemlerdedir.",
                  bedel=1, kritik=True),
            Kanit("Ekip donanımı",
                  "Yanlarında harita, su ve el feneri var; başka bir yön aleti yok.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Gölgeyle yön bulmanın temel kuralı nedir?",
                dogru="Gölge, güneşin bulunduğu yönün tam tersine uzanır.",
                yanlislar={
                    "Gölge her zaman kuzeye uzanır.":
                        "Ezber bir kural kullandın. Gölgenin yönü gün boyunca "
                        "değişir; sabah ile ikindi gölgesi aynı yönü "
                        "göstermez.",
                    "Gölge, güneşin bulunduğu yöne doğru uzanır.":
                        "Yönü ters aldın. Cisim ışığı keser; gölge güneşin "
                        "TERSİ yöne düşer.",
                    "Gölgenin yönü mevsime göre değişir, günün saatiyle ilgisi yoktur.":
                        "Mevsim gölgenin boyunu etkiler ama yönünü asıl "
                        "belirleyen, güneşin o andaki konumu - yani saat.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Işık düz gider; cisim ışığı keser ve arkasında karanlık bir alan "
                    "bırakır. Bu alan doğal olarak kaynağın ters tarafındadır. "
                    "\"Gölge hep kuzeyi gösterir\" ifadesi yalnızca yerel öğlende ve "
                    "kuzey yarım kürede doğrudur; sabah ve ikindide yanıltır."
                ),
                ipuclari=[
                    "Gölge nasıl oluşur? Işığı kesen cismin hangi tarafında kalır?",
                    "Güneş doğudaysa gölge hangi tarafta olur?",
                ],
            ),
            secim_adimi(
                soru="Saat {} olduğuna göre direklerin gölgesi hangi yöne uzanır?".format(saat),
                dogru=golge_yonu_metni,
                yanlislar=yanlis_yonler,
                rastgele=rastgele,
                aciklama=aciklama_metni,
                ipuclari=["Önce güneşin hangi yönde olduğunu söyle, sonra tersini al."],
                puan=14,
            ),
            yorum_adimi(
                soru="Ekip \"gölge kuzeyi gösterir\" diye ezberleseydi ne olurdu?",
                dogru="Öğlen dışında yanılırlardı; kural yalnız yerel öğlende geçerli.",
                yanlislar={
                    "Hiçbir şey değişmezdi; gölge günün her saatinde kuzeye düşer.":
                        "Kuralı saatten bağımsız saydın. Gölge sabah bir yöne, "
                        "ikindi başka bir yöne uzanır; ezber sabahleyin "
                        "yanıltır.",
                    "Yalnızca güney yarım kürede yanılırlardı; bizde kural hep tutar.":
                        "Hatayı coğrafyaya bağladın. Aynı yarım kürede bile "
                        "günün saati değiştikçe gölge yön değiştirir.",
                    "Yalnızca kışın yanılırlardı, çünkü gölge yönünü mevsim belirler.":
                        "Mevsimi tek etken saydın. Yaz kış fark etmeksizin "
                        "gölgenin yönü gün içinde döner.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ezberlenen kural, hangi koşulda kurulduğu unutulunca yanıltır. "
                    "\"Gölge kuzeye uzanır\" cümlesinin gizli koşulları var: kuzey "
                    "yarım küre ve yerel öğlen. Koşulu bilen kişi sabah da ikindi de "
                    "yönünü bulur; yalnızca sonucu ezberleyen kişi bulamaz."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Ekip gölgeye bakıp yönünü buldu ve gün batmadan üsse döndü. "
            "Yedek pusula talebi de aynı gün yazıldı."
        ),
        odul={"itibar": 4, "erzak": 3},
    )


# ==========================================================================
# İLKOKUL
# ==========================================================================

@bulmaca(ders="cografya", konu="kroki_okuma", kademeler=(1, 5))
def kroki_okuma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Kroki yarım; eksik yapının yeri iki tanığın anlattıklarından çıkacak.

    İlkokul kademesinde de ilke aynı: kimse "kuzey neresi" diye sormaz,
    çocuk iki bilgiyi birleştirip eksik olanı kendisi bulur.
    """
    yapilar = ["mutfak", "revir", "depo", "kule"]
    rastgele.shuffle(yapilar)
    kuzeydeki, guneydeki, dogudaki, batidaki = yapilar
    kayip = rastgele.choice(yapilar)
    yon = {kuzeydeki: "kuzey", guneydeki: "güney",
           dogudaki: "doğu", batidaki: "batı"}[kayip]
    kisi_a, kisi_b = ad_sec(rastgele, PERSONEL, 2)

    return Bulmaca(
        kod="cog-kroki-okuma",
        ders="cografya",
        baslik="Yarım Kroki",
        kademe=kademe,
        konu="kroki_okuma",
        kazanim="Krokide yön bulma; kuzey oku yardımıyla konum belirleme.",
        dikkat=5,
        brifing=(
            "Üssün krokisi çizilmiş ama {} yazılmayı unutulmuş. Kroki kâğıdında "
            "onun yeri boş duruyor.\n\n"
            "Krokinin köşesinde bir kuzey oku var: yukarısı kuzey, aşağısı "
            "güney, sağı doğu, solu batı.\n\n"
            "{} ve {} üste yıllardır çalışıyor; ikisi de yeri biliyor ama tam "
            "olarak söylemek yerine tarif ediyorlar. Krokiyi tamamlamamız gerek."
        ).format(kayip, kisi_a, kisi_b),
        kanitlar=[
            Kanit("Kroki kâğıdı",
                  "Kuzey oku yukarıyı gösteriyor.\n"
                  "Yukarıda: {}\nAşağıda: {}\nSağda: {}\nSolda: {}\n"
                  "(bir yer boş bırakılmış)".format(
                      kuzeydeki if kuzeydeki != kayip else "( ? )",
                      guneydeki if guneydeki != kayip else "( ? )",
                      dogudaki if dogudaki != kayip else "( ? )",
                      batidaki if batidaki != kayip else "( ? )"),
                  bedel=2, kritik=True),
            Kanit("{} anlatıyor".format(kisi_a),
                  "\"Sabah güneş doğduğunda ışık önce {} tarafına vurur.\"".format(
                      dogudaki), bedel=1, kritik=True),
            Kanit("{} anlatıyor".format(kisi_b),
                  "\"{} ile {} tam karşı karşıyadır; biri yukarıda, biri "
                  "aşağıda.\"".format(kuzeydeki, guneydeki), bedel=1, kritik=True),
            Kanit("Yön kartı",
                  "Krokide yukarısı KUZEY, aşağısı GÜNEY, sağı DOĞU, solu BATI "
                  "olarak gösterilir.", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Krokide bir yerin hangi yönde olduğunu ne belirler?",
                dogru="Kuzey okunun gösterdiği yön; öbür yönler ona göre okunur.",
                yanlislar={
                    "Kâğıdı hangi taraftan tuttuğumuz; elimizde üstte kalan kuzeydir.":
                        "Yönü okuyucuya bağladın. Kroki elde döndürülse bile "
                        "yönler değişmez; onları kuzey oku sabitler.",
                    "Yapının büyüklüğü; büyük yapılar kuzeye çizilir.":
                        "Böyle bir çizim kuralı yok. Yapı krokide gerçekte "
                        "nerede duruyorsa oraya çizilir.",
                    "Yapının adının alfabedeki sırası.":
                        "Alfabe sırası listelerde işe yarar; krokide yer, "
                        "gerçek konuma göre belirlenir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kroki ve haritalarda yön, kuzey okuyla belirlenir. Kâğıdı "
                    "çevirsen bile ok da onunla döner; yönler değişmez. Bu yüzden "
                    "her haritanın bir kuzey oku vardır."
                ),
                ipuclari=[
                    "Kroki kâğıdının köşesinde ne var?",
                    "Ok yukarıyı gösteriyorsa yukarısı hangi yöndür?",
                ],
            ),
            secim_adimi(
                soru="Eksik yazılan {} hangi yöndedir?".format(kayip),
                dogru=yon,
                yanlislar={
                    y: "Krokide {} tarafı zaten dolu. Boş kalan tek yeri "
                       "bulmak için dolu olanları tek tek işaretle.".format(y)
                    for y in ["kuzey", "güney", "doğu", "batı"] if y != yon
                },
                rastgele=rastgele,
                aciklama=(
                    "Krokide dolu olan üç yer zaten yazılı; boş kalan tek yer {} "
                    "tarafı. {} oraya yazılır."
                ).format(yon, kayip),
                ipuclari=[
                    "Krokide dolu olanları işaretle; geriye tek yer kalır.",
                    "Boş kalan yer yukarıda mı, aşağıda mı, sağda mı, solda mı?",
                ],
                puan=14,
            ),
            yorum_adimi(
                soru="Kuzey oku olmasaydı krokiyi okuyabilir miydik?",
                dogru="Birbirine göre yerleri görürdük, yönleri bilemezdik.",
                yanlislar={
                    "Hiçbir şey anlaşılmazdı, kroki tamamen işe yaramazdı.":
                        "Krokiyi tümden işe yaramaz saydın. Yapıların "
                        "birbirine göre yerleri yine okunurdu; belirsizleşen "
                        "tek şey hangi tarafın kuzey olduğu.",
                    "Her şey aynı olurdu; kuzey oku sadece süstür.":
                        "Kuzey okunu süs saydın. O ok olmadan kroki "
                        "araziyle eşleştirilemez; hangi yöne yürüneceği "
                        "bilinmez.",
                    "Yönleri yine bilirdik, çünkü yukarısı her zaman kuzeydir.":
                        "Yaygın ama yanlış bir varsayım. Yukarının kuzey "
                        "olması bir alışkanlıktır, kural değil; bu yüzden "
                        "krokilere ok konur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ok olmadan da \"mutfak, deponun karşısında\" diyebiliriz; ama "
                    "\"mutfak kuzeydedir\" diyemeyiz. Kuzey oku, çizimi gerçek "
                    "dünyaya bağlayan işarettir. \"Yukarısı hep kuzeydir\" ise bir "
                    "alışkanlıktır, kural değil; ok başka yöne de bakabilir."
                ),
                puan=10,
            ),
        ],
        kapanis="Kroki tamamlandı ve nöbetçi odasının duvarına asıldı.",
        odul={"itibar": 4, "erzak": 2},
    )


# ==========================================================================
# SU KAYNAKLARINI SINIFLANDIRMA (B37 -- müfredat haritası)
#
# Haritada `su_kaynaklari` kodu hem 2018 (10. sınıf) hem 2026 (11. sınıf)
# programında geçiyor ve üç satır da `kaynak_yonetimi`ne kaba eşlenmişti.
# Hepsinin `yaygin_yanlis` alanı aynı: "Toplam su varlığını erişilebilir ve
# kullanılabilir suyla eşitlemek." Bu görev o yanılgıyı ölçüyor.
#
# `su_butcesi` ile KARIŞTIRILMAMALI: o görev yenilenme hızı ile tüketimi
# (stok/akış) ölçüyor. Bu görev bir su kütlesinin KULLANILABİLİR olup
# olmadığını -- yani sınıflandırmayı -- ölçüyor.
#
# İKİ ÖZELLİK, ÜÇ HATA
# Her kütlenin iki özelliği var: tatlı mı, ulaşılabilir mi. Kullanılabilir
# olması için İKİSİ BİRDEN gerekir. Üç yaygın hata üç çeldirici:
#
#     hepsini topla               -> toplam varlığı kullanılabilir sanmak
#     yalnız tatlılığa bak        -> buzulu ve derin akiferi saymak
#     yalnız ulaşılabilirliğe bak -> tuz gölünü saymak
# ==========================================================================

def _su_havuzu():
    """(kaynak, sig, tuz, buzul, derin) birleşimleri; hepsi bin m³.

    Elle seçilmiyor, aranıyor, çünkü görevin ölçmek istediği ayrımı
    ölçebilmesi şu koşullara bağlı:

      1. Üç çeldirici birbirinden ve doğru cevaptan FARKLI olmalı. Aksi
         hâlde bir hatayı yapan öğrenci doğru cevabı bulmuş sayılır. Tek
         gerçek koşul `buzul + derin != tuz`; diğer farklar tüm değerler
         sıfırdan büyük olduğu için kendiliğinden sağlanır.
      2. Kullanılabilir payın yüzdesi TAM SAYI olmalı.
      3. O pay küçük olmalı (%5-%30). Gerçek dünyada da suyun çok küçük bir
         kısmı kullanılabilir; görevin dersi bu.
    """
    havuz = []
    for kaynak in (40, 60, 80, 100, 120):
        for sig in (20, 40, 60, 80):
            for tuz in (100, 200, 300, 400):
                for buzul in (200, 300, 400, 500):
                    for derin in (60, 100, 140, 180):
                        if buzul + derin == tuz:
                            continue
                        toplam = kaynak + sig + tuz + buzul + derin
                        kullanilir = kaynak + sig
                        if (kullanilir * 100) % toplam:
                            continue
                        yuzde = kullanilir * 100 // toplam
                        if 5 <= yuzde <= 30:
                            havuz.append((kaynak, sig, tuz, buzul, derin))
    return tuple(havuz)


_SU = _su_havuzu()


@bulmaca(ders="cografya", konu="su_kaynaklari", kademeler=(9, 12), agirlik=1.3)
def su_varligi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Toplam su, ulaşılabilir su, kullanılabilir su: iki özelliği birlikte okumak."""
    kaynak, sig, tuz, buzul, derin = rastgele.choice(_SU)
    toplam = kaynak + sig + tuz + buzul + derin
    kullanilir = kaynak + sig
    yuzde = kullanilir * 100 // toplam
    yalniz_tatli = kaynak + sig + buzul + derin          # tuzu atan
    yalniz_ulasilir = kaynak + sig + tuz                 # buzulu/derini atan

    pompa = rastgele.choice([100, 120, 150])
    sig_derinlik = rastgele.randrange(40, pompa - 10, 10)
    derin_derinlik = pompa + rastgele.randrange(150, 400, 50)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-su-varligi",
        ders="cografya",
        baslik="Havzanın Suyu",
        kademe=kademe,
        konu="su_kaynaklari",
        kazanim="Su kaynaklarını tuzluluk ve ulaşılabilirliğe göre sınıflandırma; "
                "toplam su varlığı ile kullanılabilir suyu ayırt etme.",
        dikkat=7,
        brifing=(
            "Keşif ekibi {} yakınında bir havza haritaladı. Raporun ilk "
            "sayfasında büyük harflerle toplam su miktarı yazıyor.\n\n"
            "Komutan rakamı görünce rahatladı: \"Bu kadar suyla yıllarca "
            "susuz kalmayız.\" {} ise raporun geri kalanını okumuş ve aynı "
            "fikirde değil.\n\n"
            "Havzadaki her su kütlesine tek tek bakıp gerçekten "
            "kullanabileceğimiz miktarı bulmamız gerekiyor."
        ).format(mevki, kisi),
        kanitlar=[
            Kanit("Havza raporu -- özet",
                  "Havzadaki toplam su: {} bin m³.".format(toplam),
                  bedel=1, kritik=True),
            Kanit("Su kütleleri listesi",
                  "Kuzey buzulu: {} bin m³, donmuş.\n"
                  "Tuz gölü: {} bin m³, yüzeyde, tuzlu.\n"
                  "Derin akifer: {} bin m³, tatlı, {} m derinde.\n"
                  "Kaynak gölü: {} bin m³, yüzeyde, tatlı.\n"
                  "Sığ akifer: {} bin m³, tatlı, {} m derinde.".format(
                      buzul, tuz, derin, derin_derinlik,
                      kaynak, sig, sig_derinlik),
                  bedel=2, kritik=True),
            Kanit("Ekipman kaydı",
                  "Üssün pompaları en fazla {} m derinden su çekebiliyor. "
                  "Tuzdan arındırma tesisi yok.".format(pompa),
                  bedel=1, kritik=True),
            Kanit("Buzul notu",
                  "Buzul yıl boyunca donmuş kalıyor; eritmek için gereken "
                  "enerji üssün kapasitesinin çok üstünde.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir su kütlesinin üs için KULLANILABİLİR sayılması için ne gerekir?",
                dogru="Hem tatlı hem ulaşılabilir olması gerekir",
                yanlislar={
                    "Havzada bulunması yeterlidir; hepsi üssün suyudur":
                        "Toplam su varlığını kullanılabilir suyla eşitledin. "
                        "Havzada olmak, o suyu kullanabileceğimiz anlamına "
                        "gelmiyor.",
                    "Tatlı olması yeterlidir; tatlı suya bir yolu bulunup ulaşılır":
                        "Yalnız tuzluluğa baktın. Buzul da derin akifer de "
                        "tatlı -- ama birine eritme, ötekine pompa yetmiyor.",
                    "Ulaşılabilir olması yeterlidir":
                        "Yalnız ulaşılabilirliğe baktın. Tuz gölü yüzeyde, "
                        "kolayca ulaşılıyor -- ama arıtma tesisi yok, içilemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bu bir SINIFLANDIRMA sorusu ve iki ayrı ölçüt var. Bir "
                    "kütleyi kullanılabilir saymak için ikisinden de geçmesi "
                    "gerekiyor. Tek ölçüte bakan her yol, kullanılamayan bir "
                    "kütleyi yanlışlıkla içeri alır."
                ),
                ipuclari=[
                    "Her su kütlesi için iki soru sor: tatlı mı, ulaşılabilir mi?",
                    "Donmuş ya da pompanın ulaşamadığı derinlikteki su ulaşılabilir mi?",
                ],
                cozum=(
                    "Kullanılabilir = tatlı VE ulaşılabilir.\n"
                    "Buzul: tatlı ama donmuş -> ulaşılamaz.\n"
                    "Tuz gölü: ulaşılabilir ama tuzlu -> kullanılamaz.\n"
                    "Derin akifer: tatlı ama pompa sınırının altında -> ulaşılamaz."
                ),
            ),
            sayi_adimi(
                soru="Havzada üssün gerçekten kullanabileceği su kaç bin m³?",
                cevap=kullanilir,
                birim="bin m³",
                aciklama=(
                    "Yalnız kaynak gölü ({}) ve sığ akifer ({}) iki ölçütten de "
                    "geçiyor: {} + {} = {} bin m³."
                ).format(kaynak, sig, kaynak, sig, kullanilir),
                yaygin_yanlislar={
                    toplam:
                        "Raporun özetindeki toplamı aldın. O, havzadaki bütün "
                        "su; kullanılabilir olanı değil.",
                    yalniz_tatli:
                        "Yalnız tatlı suları topladın. Buzul donmuş, derin "
                        "akifer pompanın ulaşamayacağı derinlikte.",
                    yalniz_ulasilir:
                        "Ulaşılabilir suları topladın ama tuz gölünü de "
                        "saydın. Arıtma tesisi yok, o su içilemez.",
                },
                ipuclari=["Önce her kütleyi iki ölçüte göre işaretle, sonra topla."],
                puan=14,
            ),
            sayi_adimi(
                soru="Kullanılabilir su, havzadaki toplam suyun yüzde kaçı?",
                cevap=yuzde,
                birim="%",
                aciklama="{} ÷ {} × 100 = %{}.".format(kullanilir, toplam, yuzde),
                yaygin_yanlislar={
                    100 - yuzde:
                        "Kullanılamayan suyun payını hesapladın. Soru "
                        "kullanılabilir olanın payını istiyor.",
                },
                ipuclari=["Parça ÷ bütün × 100."],
                puan=10,
            ),
            yorum_adimi(
                soru=("Komutan \"havzada bu kadar su varken su sıkıntısı "
                      "çekmemiz imkânsız\" diyor. Neden yanılıyor?"),
                dogru="Suyun çoğu tuzlu ya da ulaşılamaz, yani kullanılamaz durumda.",
                yanlislar={
                    "Yanılmıyor: toplam su, üssün ihtiyacının çok üstünde; eksik olamaz.":
                        "Toplamı ihtiyaçla kıyasladın. Kıyaslanması gereken, "
                        "kullanılabilir miktar.",
                    "Yanılıyor, çünkü sıcakta su zamanla buharlaşıp hızla azalacaktır.":
                        "Buharlaşma ayrı bir mesele. Buradaki sorun miktarın "
                        "kendisi değil, suyun büyük kısmının kullanılamaması.",
                    "Yanılıyor, çünkü pompalar yeterince güçlü değil.":
                        "Bu yalnız derin akiferi açıklar. Buzul ve tuz gölü "
                        "pompa gücünden bağımsız olarak kullanılamıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı durum bütün Dünya için geçerli: gezegendeki suyun "
                    "yaklaşık %97'si tuzlu, tatlı suyun da yaklaşık üçte ikisi "
                    "buzul ve kalıcı kar örtüsünde. Su bol olduğu hâlde su "
                    "kıtlığı yaşanmasının sebebi bu. Bir yerin su VARLIĞI ile "
                    "o suyun KULLANILABİLİRLİĞİ ayrı şeylerdir."
                ),
                puan=12,
            ),
        ],
        kapanis=("Rapor: havzada {} bin m³ su var ama üssün kullanabileceği "
                 "yalnız {} bin m³ (%{}).".format(toplam, kullanilir, yuzde)),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# TARIM VE GIDA GÜVENCESİ (B37.14 -- müfredat haritası)
#
# 2026 programı, 11. sınıf: "Tarımsal faaliyetler ve gıda güvencesi". Satırın
# `yaygin_yanlis` alanı İKİ PARÇALI ve görev ikisini de ölçüyor:
#
#   1. "Verim ile toplam üretimi karıştırmak" -- verimi yüksek küçük tarla,
#      verimi düşük büyük tarladan AZ ürün verebilir. Toplam = verim × alan.
#   2. "Gıda güvencesini yalnız ürün miktarına indirgemek" -- çok ürün veren
#      tarlaya yılın birkaç ayı ulaşılamıyorsa, üs o aylarda aç kalır.
#
# `tedarik_bolgesi` (cografya_turkiye.py) ile KARIŞTIRILMAMALI: o görev bir
# ürünün iklime göre HANGİ BÖLGEDEN alınacağını soruyor. Bu görev üretim
# miktarının nasıl hesaplandığını ve miktarın neden yetmediğini soruyor.
#
# KAPATILAN TUZAK: "ürünü depolarız, ulaşım fark etmez" itirazı gerçekten
# geçerli olabilirdi ve doğru cevabı tartışmalı hâle getirirdi. Kanıta ambar
# kapasitesi (1 ay) konuyor; yol en az 3 ay kapalı. Böylece itiraz kanıtla
# çürütülebiliyor, doğru cevap tartışmaya açık kalmıyor.
# ==========================================================================

def _tarla_havuzu():
    """(verim_a, verim_b, alan_a, alan_b): A verimli ve küçük, B verimsiz ve büyük.

    Aranıyor, çünkü görev ancak şu koşullarda ölçmek istediği şeyi ölçer:

      1. A'nın verimi YÜKSEK, B'nin alanı BÜYÜK olmalı -- yanılgının tuzağı bu.
      2. Toplamda B belirgin önde olmalı (en az %30). Fark küçük kalırsa
         "hangisi çok üretir" sorusu hesap hatasına boğulur, ders kaybolur.
      3. "B kaç kg fazla?" sorusunun doğru cevabı, verimleri kıyaslayan
         öğrencinin bulacağı sayıya (verim_a - verim_b) EŞİT OLMAMALI.
    """
    havuz = []
    for verim_a in (500, 600, 700, 800):
        for verim_b in (200, 250, 300):
            for alan_a in (20, 30, 40, 50):
                for alan_b in (100, 120, 150, 180, 200):
                    top_a = verim_a * alan_a
                    top_b = verim_b * alan_b
                    if top_b * 10 < top_a * 13:
                        continue
                    if top_b - top_a == verim_a - verim_b:
                        continue
                    havuz.append((verim_a, verim_b, alan_a, alan_b))
    return tuple(havuz)


_TARLA = _tarla_havuzu()


@bulmaca(ders="cografya", konu="tarim_gida_guvencesi", kademeler=(9, 13), agirlik=1.3)
def iki_tarla(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Verim ile toplam üretim; toplam üretim ile gıda güvencesi."""
    verim_a, verim_b, alan_a, alan_b = rastgele.choice(_TARLA)
    top_a = verim_a * alan_a
    top_b = verim_b * alan_b
    fark = top_b - top_a
    kapali_ay = rastgele.choice([3, 4, 5])
    engel = rastgele.choice([
        ("ırmak taşıyor ve köprü su altında kalıyor", "sel"),
        ("geçit karla kapanıyor", "kar"),
    ])
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-iki-tarla",
        ders="cografya",
        baslik="İki Tarla",
        kademe=kademe,
        konu="tarim_gida_guvencesi",
        kazanim="Verim ile toplam üretimi ayırt etme; gıda güvencesini miktar, "
                "erişim ve süreklilikle birlikte değerlendirme.",
        dikkat=7,
        brifing=(
            "Üssün erzağı için {} çevresinde iki tarla kiralanabilir, ama "
            "bütçe yalnız birine yetiyor.\n\n"
            "Komutan hızlı karar vermek istiyor: \"Verimi yüksek olanı alalım, "
            "o daha çok ürün verir.\" {} ise tarla kayıtlarını okumuş ve "
            "hesabın o kadar kısa olmadığını söylüyor.\n\n"
            "Hangi tarlanın gerçekten daha çok ürün verdiğini ve üssün yıl "
            "boyu doyup doymayacağını bulmamız gerekiyor."
        ).format(mevki, kisi),
        kanitlar=[
            Kanit("Tarla A kaydı",
                  "Üssün hemen yanında. Sulu tarım yapılıyor.\n"
                  "Verim: {} kg/dönüm. Alan: {} dönüm.".format(verim_a, alan_a),
                  bedel=1, kritik=True),
            Kanit("Tarla B kaydı",
                  "Irmağın karşı yakasında. Kuru tarım yapılıyor.\n"
                  "Verim: {} kg/dönüm. Alan: {} dönüm.".format(verim_b, alan_b),
                  bedel=1, kritik=True),
            Kanit("Yol raporu",
                  "Tarla B'ye giden yolda her yıl {} ay boyunca {}; bu sürede "
                  "tarlaya ulaşılamıyor ve ürün taşınamıyor. Tarla A'ya yıl "
                  "boyu ulaşılıyor.".format(kapali_ay, engel[0]),
                  bedel=2, kritik=True),
            Kanit("Ambar kaydı",
                  "Üssün ambarı en fazla 1 aylık erzak alıyor.",
                  bedel=1, kritik=True),
            Kanit("Birim notu",
                  "Verim, bir dönümden alınan ürün miktarıdır. Tarlanın toplam "
                  "ürünü ise bütün alanından alınan miktardır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir tarlanın TOPLAM ürününü ne belirler?",
                dogru="Verim ile alanın çarpımı: dönüm başına ürün × dönüm sayısı",
                yanlislar={
                    "Yalnız verim: verimi yüksek olan tarla daha çok ürün verir":
                        "Verim ile toplam üretimi karıştırdın. Verim dönüm "
                        "başına ürün; küçük bir tarla yüksek verimle bile az "
                        "ürün verebilir.",
                    "Yalnız alan: büyük olan tarla daha çok ürün verir":
                        "Bu kez yalnız alana baktın. Büyük ama çok verimsiz bir "
                        "tarla da az ürün verebilir; ikisi birlikte belirler.",
                    "Verim ile alanın toplamı":
                        "Farklı birimler toplanmaz: kg/dönüm ile dönüm "
                        "toplanınca anlamlı bir büyüklük çıkmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Verim bir ORAN, toplam ürün bir MİKTAR. Oranı miktar "
                    "sanmak, bu konudaki en yaygın hata. Oranın miktara "
                    "dönüşmesi için neyin üzerine uygulandığını -- burada "
                    "alanı -- bilmek gerekir."
                ),
                ipuclari=[
                    "Verimin birimine bak: kg/dönüm. Toplam ürünün birimi ne olmalı?",
                    "kg/dönüm'ü kg'a çevirmek için neyle çarpmak gerekir?",
                ],
                cozum=(
                    "Toplam ürün = verim × alan.\n"
                    "Birim kontrolü: (kg/dönüm) × dönüm = kg."
                ),
            ),
            sayi_adimi(
                soru="Tarla A yılda toplam kaç kg ürün verir?",
                cevap=top_a,
                birim="kg",
                aciklama="{} kg/dönüm × {} dönüm = {} kg.".format(verim_a, alan_a, top_a),
                yaygin_yanlislar={
                    verim_a:
                        "Verimi toplam ürün sandın. {} kg, tarlanın yalnız bir "
                        "dönümünden alınan ürün.".format(verim_a),
                },
                ipuclari=["Verimi alanla çarp."],
                puan=10,
            ),
            sayi_adimi(
                soru="Tarla B, Tarla A'dan yılda kaç kg FAZLA ürün verir?",
                cevap=fark,
                birim="kg",
                aciklama=(
                    "Tarla B: {} × {} = {} kg. Fark: {} - {} = {} kg. Verimi "
                    "düşük olan tarla, alanı büyük olduğu için daha çok "
                    "üretiyor."
                ).format(verim_b, alan_b, top_b, top_b, top_a, fark),
                yaygin_yanlislar={
                    verim_a - verim_b:
                        "Verimleri kıyasladın. Verimde A önde ama soru toplam "
                        "ürünü soruyor; önce iki tarlanın toplamını bul.",
                },
                ipuclari=["Önce Tarla B'nin toplamını bul, sonra iki toplamı kıyasla."],
                puan=14,
            ),
            yorum_adimi(
                soru=("Komutan fikrini değiştirdi: \"Madem B daha çok ürün "
                      "veriyor, B'yi alalım, gıda sorunumuz çözülür.\" "
                      "Haklı mı?"),
                dogru="Hayır: B'ye aylarca ulaşılamıyor ve ambar yetmiyor, süreklilik sağlanamaz.",
                yanlislar={
                    "Evet: yıllık toplam ürünü fazla olan tarla gıda güvencesini de sağlar.":
                        "Gıda güvencesini yalnız ürün miktarına indirgedin. "
                        "Yol kapalıyken toplanamayan ürün o aylarda üssü "
                        "doyurmaz.",
                    "Hayır: A alınmalı, çünkü verimi yüksek olan tarla her zaman daha iyidir.":
                        "Sonuç doğru olabilir ama gerekçe yanlış: bu yine verim "
                        "ile toplam üretimi karıştırmak. B'yi zayıflatan şey "
                        "verimi değil, erişimi.",
                    "Evet: yıllık ihtiyaç karşılandığı sürece ürünün ne zaman toplandığı önemli değil.":
                        "Ambar kaydına bak: üs en fazla 1 aylık erzak "
                        "saklayabiliyor. Yol ondan uzun süre kapalı; aradaki "
                        "aylar karşılanamaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Gıda güvencesi yalnız 'ne kadar ürün var' sorusu değil. "
                    "Ürün gerektiği anda ERİŞİLEBİLİR olmalı ve bu yıl boyu "
                    "SÜRMELİ. Dünyada toplam gıda üretimi yeterli olduğu hâlde "
                    "açlık yaşanmasının başlıca sebeplerinden biri de budur: "
                    "sorun çoğu zaman miktar değil, erişim ve dağıtımdır."
                ),
                puan=12,
            ),
        ],
        kapanis=("Rapor: A {} kg, B {} kg üretiyor; B {} kg önde. Ama B'ye yılda "
                 "{} ay ulaşılamıyor -- yalnız miktara bakan karar üssü "
                 "o aylarda erzaksız bırakır.".format(top_a, top_b, fark, kapali_ay)),
        odul={"itibar": 5, "erzak": 3, "enerji": 1},
    )


# ==========================================================================
# KAYNAĞIN EKONOMİK DEĞERİ (B37.14 -- müfredat haritası)
#
# 2018 programı, 11. sınıf: "Doğal kaynakların ekonomik değerinin değişmesi".
# Haritada iki yakın ama ayrı yanılgı var ve bu görev ikisini birlikte ölçüyor:
#
#   A. "Maden rezervi, üretim ve ekonomik değeri aynı sanmak" -- yerde duran
#      miktar (rezerv) ile bir yılda çıkarılan miktar (üretim) ve onun
#      getirdiği değer üç AYRI büyüklük.
#   B. "Kaynağın varlığını ekonomik olarak işletilebilir olmasıyla
#      eşitlemek" -- çıkarma maliyeti satış fiyatının üstündeyse yatak VAR
#      ama işletilmesi zarar. Fiyat maliyeti geçerse aynı yatak değer kazanır;
#      satırın konusu ("ekonomik değerin DEĞİŞMESİ") tam olarak bu.
#
# Gerçek para birimi yerine üssün "kredi"si kullanılıyor: öğrenciye gerçek
# piyasa fiyatı gibi görünen uydurma rakam verilmiyor. Kural kanıtta.
# ==========================================================================

def _maden_havuzu():
    """(rezerv, uretim, fiyat, maliyet); rezerv ve üretim ton, fiyat kredi/ton.

    Aranıyor, çünkü görev ancak şu koşullarda ölçmek istediği şeyi ölçer:

      1. Maliyet fiyattan YÜKSEK olmalı -- yoksa B yanılgısı sınanmaz, yatak
         zaten kârlıdır ve "var olan işletilebilir" sanan öğrenci doğruya varır.
      2. Zarar sorusunun doğru cevabı, geliri zarar sanan öğrencinin sayısına
         EŞİT OLMAMALI: üretim × (maliyet - fiyat) != üretim × fiyat, yani
         maliyet != 2 × fiyat.
    Rezerv her zaman üretimin en az 25 katı olduğu için rezervi üretim sanan
    çeldiriciler doğru cevaplardan kendiliğinden ayrışıyor.
    """
    havuz = []
    for rezerv in (20000, 30000, 40000, 50000):
        for uretim in (400, 500, 600, 800):
            for fiyat in (60, 70, 80):
                for maliyet in (90, 100, 110, 120):
                    if maliyet <= fiyat:
                        continue
                    if maliyet == 2 * fiyat:
                        continue
                    havuz.append((rezerv, uretim, fiyat, maliyet))
    return tuple(havuz)


_MADEN = _maden_havuzu()


@bulmaca(ders="cografya", konu="kaynak_ekonomi", kademeler=(9, 13), agirlik=1.3)
def cevher_yatagi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Rezerv, üretim ve değer; kaynağın varlığı ile işletilebilirliği."""
    rezerv, uretim, fiyat, maliyet = rastgele.choice(_MADEN)
    gelir = uretim * fiyat
    zarar = uretim * (maliyet - fiyat)
    cevher = rastgele.choice(["bakır", "çinko", "demir", "krom"])
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-cevher-yatagi",
        ders="cografya",
        baslik="Cevher Yatağı",
        kademe=kademe,
        konu="kaynak_ekonomi",
        kazanim="Rezerv, üretim ve ekonomik değeri ayırt etme; bir kaynağın "
                "varlığı ile ekonomik olarak işletilebilirliğini ayırt etme.",
        dikkat=7,
        brifing=(
            "Maden ekibi {} altında bir {} yatağı buldu. Raporun başında "
            "yataktaki cevher miktarı yazıyor.\n\n"
            "Komutan hemen hesap yaptı: \"Bu kadar cevheri satarsak üs "
            "yıllarca rahat eder.\" {} ise çıkarma kayıtlarını da okumuş ve "
            "işin o kadar basit olmadığını söylüyor.\n\n"
            "Yatağın üsse gerçekte ne kazandıracağını bulmamız gerekiyor."
        ).format(mevki, cevher, kisi),
        kanitlar=[
            Kanit("Jeoloji raporu",
                  "Yataktaki toplam cevher (rezerv): {} ton.".format(rezerv),
                  bedel=1, kritik=True),
            Kanit("Çıkarma kapasitesi",
                  "Üssün ekipmanıyla bir yılda en fazla {} ton cevher "
                  "çıkarılabiliyor.".format(uretim),
                  bedel=2, kritik=True),
            Kanit("Pazar kaydı",
                  "Bu cevherin şu anki satış fiyatı: {} kredi/ton.".format(fiyat),
                  bedel=1, kritik=True),
            Kanit("Maliyet hesabı",
                  "Bir ton cevheri çıkarıp işlemenin maliyeti (yakıt, "
                  "ekipman aşınması, işçilik): {} kredi/ton.".format(maliyet),
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Yatağın üsse bir YILDA getireceği satış geliri nasıl bulunur?",
                dogru="Bir yılda çıkarılan cevher miktarı × satış fiyatı",
                yanlislar={
                    "Yataktaki toplam cevher (rezerv) × satış fiyatı":
                        "Rezervi üretimle karıştırdın. Rezerv yerde duran "
                        "miktar; bir yılda çıkarabildiğimiz ise çok daha az.",
                    "Yataktaki toplam cevher miktarı; o zaten üssün serveti":
                        "Miktarı değerle karıştırdın. Cevher satılmadıkça ve "
                        "çıkarılmadıkça gelir getirmez.",
                    "Bir yılda çıkarılan cevher miktarı":
                        "Miktarı buldun ama değere çevirmedin: ton, kredi "
                        "değil. Fiyatla çarpmak gerekiyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Burada üç ayrı büyüklük var ve karıştırılmaları bu konudaki "
                    "en yaygın hata:\n"
                    "  REZERV  -- yerde duran toplam miktar (ton)\n"
                    "  ÜRETİM  -- bir yılda çıkarılabilen miktar (ton/yıl)\n"
                    "  DEĞER   -- üretimin satıştan getirdiği (kredi/yıl)\n"
                    "Rezerv büyük olabilir; ama gelir üretimle sınırlıdır."
                ),
                ipuclari=[
                    "Rezerv mi, bir yılda çıkarılan miktar mı -- hangisi satılabilir?",
                    "Tonu krediye çevirmek için neye ihtiyaç var?",
                ],
                cozum=(
                    "Yıllık gelir = yıllık üretim × fiyat.\n"
                    "Birim kontrolü: (ton/yıl) × (kredi/ton) = kredi/yıl."
                ),
            ),
            sayi_adimi(
                soru="Yatak üsse bir yılda kaç kredi SATIŞ GELİRİ getirir?",
                cevap=gelir,
                birim="kredi",
                aciklama="{} ton × {} kredi/ton = {} kredi.".format(uretim, fiyat, gelir),
                yaygin_yanlislar={
                    rezerv * fiyat:
                        "Rezervin tamamını bir yılda satmışsın gibi hesapladın. "
                        "Bir yılda yalnız {} ton çıkarılabiliyor.".format(uretim),
                    uretim:
                        "Tonu kredi sandın; fiyatla çarpmadın.",
                },
                ipuclari=["Yıllık üretimi fiyatla çarp."],
                puan=10,
            ),
            sayi_adimi(
                soru=("Maliyet hesabına göre yatak şu anki fiyatla işletilirse "
                      "üs bir yılda kaç kredi ZARAR eder?"),
                cevap=zarar,
                birim="kredi",
                aciklama=(
                    "Her ton {} kredi maliyetle çıkıyor ama {} krediye satılıyor: "
                    "ton başına {} kredi zarar. Bir yılda {} ton × {} = {} kredi zarar."
                ).format(maliyet, fiyat, maliyet - fiyat, uretim, maliyet - fiyat, zarar),
                yaygin_yanlislar={
                    gelir:
                        "Satış gelirini yazdın. Zarar, maliyetin gelirden ne "
                        "kadar fazla olduğudur.",
                    rezerv * (maliyet - fiyat):
                        "Ton başına zararı doğru buldun ama yine rezervle "
                        "çarptın; bir yılda yalnız {} ton çıkıyor.".format(uretim),
                },
                ipuclari=["Önce ton başına maliyet ile fiyat arasındaki farkı bul."],
                puan=14,
            ),
            yorum_adimi(
                soru=("Komutan \"bu kadar cevherimiz var, zenginiz\" diyor. "
                      "Haklı mı?"),
                dogru="Hayır: cevher var ama bugünkü fiyatla çıkarmak zarardır.",
                yanlislar={
                    "Evet: rezerv büyük olduğu için yatak değerlidir; cevher servettir.":
                        "Kaynağın varlığını işletilebilirlikle eşitledin. "
                        "Çıkarma maliyeti fiyatı aştıkça rezerv ne kadar büyük "
                        "olursa olsun kazanç getirmez.",
                    "Hayır: çünkü rezerv çok küçük, işletmeye değmez.":
                        "Rezerv küçük değil; sorun miktar değil, maliyet ile "
                        "fiyat arasındaki ilişki.",
                    "Hayır: çünkü bir yılda çıkarılan miktar az; daha çok çıkarmak gerekir.":
                        "Üretim azlığı geliri sınırlar ama asıl sorun o değil: "
                        "daha çok çıkarsak daha çok zarar ederiz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir kaynağın ekonomik değeri sabit değildir. Fiyat {} "
                    "krediden {} kredinin üstüne çıkarsa AYNI yatak, hiçbir şey "
                    "değişmeden kârlı hâle gelir; teknoloji maliyeti düşürürse "
                    "de öyle. Dünyada bilinen pek çok yatağın işletilmemesinin "
                    "sebebi budur: yatak vardır, ama o gün işletmeye değmez."
                ).format(fiyat, maliyet),
                puan=12,
            ),
        ],
        kapanis=("Rapor: yatakta {} ton cevher var, yılda {} ton çıkarılabiliyor. "
                 "Şu anki fiyatla yılda {} kredi zarar -- fiyat {} krediyi "
                 "geçene kadar işletilmemeli.".format(rezerv, uretim, zarar, maliyet)),
        odul={"itibar": 5, "cevher": 3, "enerji": 1},
    )


# ==========================================================================
# GERİ DÖNÜŞÜM VE ATIK HİYERARŞİSİ (B37.14 -- müfredat haritası)
#
# 2018 programı, 11. sınıf: "Geri dönüşümle kaynakların sürdürülebilir
# kullanımı". Satırın `yaygin_yanlis` alanı iki parçalı:
#
#   1. "Geri dönüşümün sınırsız ve kayıpsız olduğunu sanmak" -- her turda
#      malzemenin bir kısmı kaybolur ve kayıp BİLEŞİK işler.
#   2. "Azaltma ve yeniden kullanmayı atlamak" -- atık hiyerarşisinde önce
#      azaltma, sonra yeniden kullanım, en son geri dönüşüm gelir.
#
# ÜÇÜNCÜ BİR HATA DA ÖLÇÜLÜYOR: yüzdelik kaybı DOĞRUSAL sanmak -- her turda
# başlangıç miktarının aynı payını düşmek. %80 geri kazanımla 3 turda:
#
#     bileşik (doğru)  1000 × 0,8 × 0,8 × 0,8 = 512
#     doğrusal         1000 × (1 - 3 × 0,2)   = 400
#     tek tur          1000 × 0,8             = 800
#     kayıpsız         1000
#
# Dört ayrı sayı, dört ayrı teşhis. Havuz bunların hiçbirinin çakışmamasını
# garanti ediyor.
# ==========================================================================

def _geri_donusum_havuzu():
    """(baslangic, oran, tur): baslangic kg, oran yüzde (geri kazanılan).

    Aranıyor, çünkü görev ancak şu koşullarda ölçmek istediği şeyi ölçer:

      1. Tur sayısı en az 2 olmalı -- tek turda bileşik ile tek tur aynıdır
         ve "bileşik kayıp" hiç sınanmaz.
      2. Bileşik sonuç TAM SAYI olmalı (kg).
      3. Doğrusal hesap eksiye düşmemeli -- düşerse o hata zaten saçma bir
         sonuç verir ve öğrenci kendi hatasını fark eder; ölçülecek bir şey
         kalmaz.
      4. Dört sonuç (bileşik, doğrusal, tek tur, kayıpsız) birbirinden
         FARKLI olmalı.
      5. Kayıp görünür olmalı: kalan, başlangıcın en fazla %85'i.
    """
    havuz = []
    for baslangic in (500, 1000, 2000, 4000, 5000, 8000, 10000):
        for oran in (60, 70, 75, 80, 85, 90):
            for tur in (2, 3, 4):
                if (baslangic * oran ** tur) % (100 ** tur):
                    continue
                bilesik = baslangic * oran ** tur // 100 ** tur
                kayip_payi = tur * (100 - oran)
                if kayip_payi >= 100:
                    continue
                dogrusal = baslangic * (100 - kayip_payi) // 100
                tek_tur = baslangic * oran // 100
                if len({bilesik, dogrusal, tek_tur, baslangic}) != 4:
                    continue
                if bilesik * 100 > baslangic * 85:
                    continue
                havuz.append((baslangic, oran, tur))
    return tuple(havuz)


_GERI = _geri_donusum_havuzu()


@bulmaca(ders="cografya", konu="geri_donusum", kademeler=(9, 13), agirlik=1.2)
def atik_akisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Geri dönüşümde bileşik kayıp; azaltma-yeniden kullanım-geri dönüşüm sırası."""
    baslangic, oran, tur = rastgele.choice(_GERI)
    bilesik = baslangic * oran ** tur // 100 ** tur
    dogrusal = baslangic * (100 - tur * (100 - oran)) // 100
    tek_tur = baslangic * oran // 100
    yeni_gerek = baslangic - bilesik
    malzeme = rastgele.choice(["alüminyum", "bakır tel", "çelik levha"])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-atik-akisi",
        ders="cografya",
        baslik="Atık Akışı",
        kademe=kademe,
        konu="geri_donusum",
        kazanim="Geri dönüşümde her turdaki malzeme kaybını bileşik olarak "
                "hesaplama; azaltma, yeniden kullanım ve geri dönüşümü sıralama.",
        dikkat=7,
        brifing=(
            "Üs, onarım işleri için {} {} ile başladı. Kullanılan her "
            "parça eritilip yeniden işleniyor.\n\n"
            "{} bütçe toplantısında şunu söyledi: \"Her şeyi geri "
            "dönüştürüyoruz, bir daha {} satın almamıza gerek yok.\"\n\n"
            "Atölye kayıtlarına bakıp bu iddianın tutup tutmadığını "
            "bulmamız gerekiyor."
        ).format(baslangic, "kg " + malzeme, kisi, malzeme),
        kanitlar=[
            Kanit("Stok kaydı",
                  "Başlangıçtaki {}: {} kg.".format(malzeme, baslangic),
                  bedel=1, kritik=True),
            Kanit("Atölye ölçümü",
                  "Eritme ve yeniden işleme sırasında her turda malzemenin "
                  "yüzde {} kadarı geri kazanılıyor; kalanı cüruf, oksitlenme ve kesim "
                  "artığı olarak kayboluyor.".format(oran),
                  bedel=2, kritik=True),
            Kanit("Kullanım planı",
                  "Malzeme bu yıl {} kez kullanılıp geri dönüştürülecek. Her "
                  "tur, bir önceki turdan KALAN malzemeyle başlıyor.".format(tur),
                  bedel=1, kritik=True),
            Kanit("Tasarım notu",
                  "Mühendislik ekibi, parçaların yeniden tasarlanmasıyla aynı "
                  "işin daha az malzemeyle yapılabileceğini söylüyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Her turda malzemenin bir kısmı kayboluyorsa, birkaç tur sonra kalan miktar nasıl bulunur?",
                dogru="Her tur, önceki turdan kalanı geri kazanım oranıyla çarpar",
                yanlislar={
                    "Hepsi kalır, çünkü geri dönüşüm malzemeyi yok etmez":
                        "Geri dönüşümü kayıpsız sandın. Atölye ölçümü her "
                        "turda bir kısmın cüruf ve artık olarak kaybolduğunu "
                        "gösteriyor.",
                    "Her turda başlangıç miktarının aynı payı düşülür; kayıp her tur eşittir":
                        "Kaybı doğrusal saydın. Her tur BAŞLANGIÇLA değil, bir "
                        "önceki turdan KALANLA başlıyor; kayıp da o kalanın "
                        "payı olarak hesaplanır.",
                    "Geri kazanım oranı yalnız bir kez uygulanır; kayıp bir kere olur":
                        "Tek turu hesapladın. Malzeme birkaç kez işleniyor ve "
                        "her işlemde yeniden kayıp var.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bu bir BİLEŞİK azalma. Faizin tersi gibi düşün: faizde her "
                    "yıl kalan paranın üstüne eklenir, burada her tur kalan "
                    "malzemeden eksilir. Tur sayısı arttıkça kayıp, doğrusal "
                    "hesabın gösterdiğinden farklı bir hızla birikir."
                ),
                ipuclari=[
                    "Kullanım planına bak: her tur neyle başlıyor?",
                    "İlk turdan sonra kalanı bul; ikinci tur o miktarla başlar.",
                ],
                cozum=(
                    "1. tur sonu = başlangıç × oran\n"
                    "2. tur sonu = 1. tur sonu × oran\n"
                    "... her tur bir öncekinin sonucuyla devam eder."
                ),
            ),
            sayi_adimi(
                soru="Yılın sonunda elde kaç kg {} kalır?".format(malzeme),
                cevap=bilesik,
                birim="kg",
                aciklama=(
                    "{} kg ile başlanıyor ve {} tur boyunca her tur kalanın "
                    "yüzde {} kadarı geri kazanılıyor: {} kg kalır."
                ).format(baslangic, tur, oran, bilesik),
                yaygin_yanlislar={
                    baslangic:
                        "Hiç kayıp saymadın. Geri dönüşüm kayıpsız değil.",
                    tek_tur:
                        "Yalnız bir turu hesapladın; malzeme {} kez "
                        "işleniyor.".format(tur),
                    dogrusal:
                        "Kaybı doğrusal saydın: her turda başlangıcın aynı "
                        "payını düştün. Her tur bir önceki turdan KALANLA "
                        "başlıyor.",
                },
                ipuclari=["Turları tek tek hesapla; her tur bir öncekinin sonucunu kullanır."],
                puan=14,
            ),
            sayi_adimi(
                soru=("Yılın sonunda stoku başlangıçtaki miktara geri getirmek "
                      "için kaç kg yeni {} satın almak gerekir?").format(malzeme),
                cevap=yeni_gerek,
                birim="kg",
                aciklama="{} - {} = {} kg yeni malzeme gerekiyor.".format(
                    baslangic, bilesik, yeni_gerek),
                yaygin_yanlislar={
                    0:
                        "Geri dönüşümü kayıpsız sandın; kaybolan malzemenin "
                        "yerine yenisi alınmak zorunda.",
                    baslangic - tek_tur:
                        "Yalnız tek turun kaybını karşıladın; {} turun toplam "
                        "kaybı daha büyük.".format(tur),
                },
                ipuclari=["Başlangıçtaki miktardan elde kalanı çıkar."],
                puan=10,
            ),
            yorum_adimi(
                soru=("{} ikna oldu ama şimdi \"o zaman daha çok geri "
                      "dönüştürelim, sorun çözülür\" diyor. Malzemeyi EN ÇOK "
                      "hangi yol korur?").format(kisi),
                dogru="Önce azaltmak, sonra yeniden kullanmak, en son geri dönüştürmek.",
                yanlislar={
                    "Geri dönüşüm: malzemeyi sürekli döngüde tuttuğu için en iyisidir; döngü kaybı önler.":
                        "Geri dönüşüm her turda kayıp veriyor; ne kadar çok "
                        "tur, o kadar çok kayıp. Döngüde tutmak, kaybı "
                        "önlemek demek değil.",
                    "Hepsi aynı ölçüde korur; yeter ki atık çöpe gitmesin.":
                        "Çöpe gitmemesi önemli ama eşit değiller. Hiç "
                        "kullanılmayan malzeme hiç kaybolmaz; eritilen "
                        "malzeme her seferinde kaybeder.",
                    "Yeniden kullanım: geri dönüşümden kolay olduğu için en iyisidir.":
                        "Yeniden kullanım geri dönüşümden iyi, ama en iyisi "
                        "değil: tasarım notu işin daha az malzemeyle "
                        "yapılabileceğini söylüyor. Hiç kullanılmayan "
                        "malzeme hiç kaybolmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Buna ATIK HİYERARŞİSİ denir: önce önlemek ve azaltmak, "
                    "sonra yeniden kullanmak, sonra geri dönüştürmek. Sıra "
                    "rastgele değil; her basamak bir öncekinden daha çok "
                    "malzeme ve enerji kaybettirir. Geri dönüşüm değerlidir "
                    "ama listenin başında değil, sonlarındadır."
                ),
                puan=12,
            ),
        ],
        kapanis=("Rapor: {} kg ile başlandı, {} tur sonra {} kg kaldı; {} kg yeni "
                 "{} gerekiyor. Asıl tasarruf daha az malzeme kullanmakta."
                 ).format(baslangic, tur, bilesik, yeni_gerek, malzeme),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# ÇEVRE SORUNLARININ YAYILMASI (B37.14 -- müfredat haritası)
#
# 2018 programı, 11. sınıf: "Çevre sorunlarının sınır aşan yayılma
# süreçleri". Aynı `yaygin_yanlis` metni haritada 10 satırda geçiyor (araştırma
# ünitenin bütün satırlarına kopyalamış); konusu buna EN İYİ uyan bu satır.
# Yanılgı iki parçalı ve görev ikisini de ölçüyor:
#
#   1. "Çevresel etkinin kaynak noktasında kaldığını sanmak" -- ırmağa
#      boşaltılan atık akıntıyla aşağı taşınır; derişim azalır ama sıfıra
#      inmez ve aşağıdaki yerleşmelere ulaşır.
#   2. "Kullanım maliyetine çevresel sonuçları katmamak" -- boşaltmak arıtmaktan
#      ucuz GÖRÜNÜR, ta ki aşağıdaki zarar hesaba girene kadar.
#
# KURAL KANITTA: derişimin kaç km'de yarıya indiği üssün kendi ölçümü olarak
# veriliyor. Görev bunu bütün ırmaklar için geçerli bir yasa gibi sunmuyor;
# gerçekte bu mesafe akış hızına, debiye ve kirleticinin türüne bağlı.
# ==========================================================================

def _akinti_havuzu():
    """(baslangic, yari_km, yari_sayisi, sinir): derişim mg/L, mesafe km.

    Aranıyor, çünkü görev ancak şu koşullarda ölçmek istediği şeyi ölçer:

      1. En az iki yarılanma olmalı -- tek yarılanmada "yalnız bir kez
         yarıya indirmek" hatası doğru cevaba eşit düşer.
      2. Çiftlikteki derişim TAM SAYI olmalı.
      3. Çiftlikteki derişim güvenli sınırın ÜSTÜNDE olmalı -- aksi hâlde
         "etki çiftliğe ulaşıyor ama zararsız" olur ve yanılgının sonucu
         (aşağıdakiler zarar görür) ortaya çıkmaz.
    """
    havuz = []
    for baslangic in (320, 640, 960, 1280, 1600):
        for yari_km in (2, 3, 4, 5):
            for yari_sayisi in (2, 3, 4):
                if baslangic % (2 ** yari_sayisi):
                    continue
                ciftlik = baslangic // (2 ** yari_sayisi)
                for sinir in (20, 40, 50, 80):
                    if ciftlik > sinir:
                        havuz.append((baslangic, yari_km, yari_sayisi, sinir))
    return tuple(havuz)


def _maliyet_havuzu():
    """(aritma, zarar): kredi/yıl. Zarar arıtmayı aşmalı ve farkı arıtmaya eşit olmamalı."""
    return tuple((aritma, zarar)
                 for aritma in (200, 300, 400, 500)
                 for zarar in range(500, 1300, 100)
                 if zarar > aritma and zarar != 2 * aritma)


_AKINTI = _akinti_havuzu()
_AKINTI_MALIYET = _maliyet_havuzu()


@bulmaca(ders="cografya", konu="kuresel_cevre_yayilma", kademeler=(9, 13), agirlik=1.2)
def akinti_yonu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kirliliğin akıntıyla yayılması; çevresel maliyetin hesaba katılması."""
    baslangic, yari_km, yari_sayisi, sinir = rastgele.choice(_AKINTI)
    aritma, zarar = rastgele.choice(_AKINTI_MALIYET)
    mesafe = yari_km * yari_sayisi
    ciftlik = baslangic // (2 ** yari_sayisi)
    asim = zarar - aritma
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-akinti-yonu",
        ders="cografya",
        baslik="Akıntı Yönü",
        kademe=kademe,
        konu="kuresel_cevre_yayilma",
        kazanim="Çevre sorunlarının kaynaktan uzağa yayılma sürecini açıklama; "
                "kaynak kullanımının maliyetine çevresel sonuçları katma.",
        dikkat=7,
        brifing=(
            "Atölye, işlem atığını arıtmadan ırmağa boşaltıyor. Arıtma "
            "tesisi kurulması önerildiğinde atölye şefi {} karşı çıktı:\n\n"
            "\"Üs ırmağın yukarısında, boşaltma noktası aşağıda. Atık orada "
            "kalır, bize dokunmaz. Arıtma parasını boşa harcamayalım.\"\n\n"
            "Irmak ölçümlerine ve aşağıdaki yerleşimin kayıtlarına bakıp bu "
            "iddianın doğru olup olmadığını bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Boşaltma noktası ölçümü",
                  "Atığın ırmağa karıştığı noktada kirletici derişimi: {} mg/L."
                  .format(baslangic),
                  bedel=1, kritik=True),
            Kanit("Irmak ölçümleri",
                  "Üssün bu ırmakta yaptığı ölçümlere göre kirletici derişimi, "
                  "akıntı yönünde her {} km'de yaklaşık yarıya iniyor. Akıntının "
                  "yukarısına doğru taşınma yok.".format(yari_km),
                  bedel=2, kritik=True),
            Kanit("Harita",
                  "Boşaltma noktasının {} km aşağısında bir balık çiftliği var. "
                  "Üs, erzağındaki balığı bu çiftlikten alıyor.".format(mesafe),
                  bedel=1, kritik=True),
            Kanit("Çiftlik kaydı",
                  "Balıklar için güvenli kirletici sınırı: {} mg/L. Sınır "
                  "aşıldığından beri çiftliğin yıllık kaybı: {} kredi."
                  .format(sinir, zarar),
                  bedel=2, kritik=True),
            Kanit("Arıtma teklifi",
                  "Atölyeye arıtma tesisi kurmanın ve işletmenin yıllık "
                  "maliyeti: {} kredi.".format(aritma),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Irmağa boşaltılan atığa, boşaltma noktasından sonra ne olur?",
                dogru="Akıntıyla taşınır; azalsa da aşağıdaki yerleşmelere ulaşır",
                yanlislar={
                    "Boşaltma noktasında kalır; ırmak atığı taşımaz, öteye etkisi olmaz":
                        "Çevresel etkinin kaynak noktasında kaldığını sandın. "
                        "Irmak durgun değil: atık akıntıyla birlikte taşınıyor.",
                    "Suda hemen dağılır, kısa mesafede tamamen kaybolur; akan su kendini temizler":
                        "Derişim azalıyor ama ölçümler kaybolmadığını gösteriyor: "
                        "her birkaç km'de yalnız yarıya iniyor.",
                    "Irmak boyunca her iki yöne eşit yayılır":
                        "Irmakta taşınma akıntı yönünde olur. Ölçüm kaydı "
                        "yukarı doğru taşınma olmadığını söylüyor -- üssün "
                        "kendisi bu yüzden etkilenmiyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Atölye şefinin gözden kaçırdığı şey YÖN. Üs yukarıda "
                    "olduğu için gerçekten doğrudan etkilenmiyor -- ama bu, "
                    "etkinin olmadığı anlamına gelmiyor. Etki akıntıyla aşağı "
                    "taşınıyor ve orada yaşayanlara ulaşıyor. Hava kirliliğinde "
                    "rüzgâr, deniz kirliliğinde akıntılar aynı rolü oynar; çevre "
                    "sorunlarının sınır aşmasının sebebi budur."
                ),
                ipuclari=[
                    "Irmak ölçümlerine bak: derişim uzaklıkla ne oluyor?",
                    "Yarıya inen bir şey kaç kez yarıya inerse sıfır olur?",
                ],
                cozum=(
                    "Derişim her yarılanma mesafesinde yarıya iner.\n"
                    "Çiftliğe kadar kaç yarılanma olduğunu bul.\n"
                    "Başlangıç derişimini o sayı kadar yarıya indir."
                ),
            ),
            sayi_adimi(
                soru="Balık çiftliğinin önünden geçen suda kirletici derişimi kaç mg/L?",
                cevap=ciftlik,
                birim="mg/L",
                aciklama=(
                    "Çiftlik {} km aşağıda; derişim her {} km'de yarıya iniyor, "
                    "yani {} kez yarıya iniyor: {} mg/L. Güvenli sınır {} mg/L -- "
                    "sınır aşılmış."
                ).format(mesafe, yari_km, yari_sayisi, ciftlik, sinir),
                yaygin_yanlislar={
                    0:
                        "Atığın çiftliğe hiç ulaşmadığını varsaydın. Ölçümler "
                        "derişimin azaldığını ama sıfıra inmediğini gösteriyor.",
                    baslangic:
                        "Hiç azalma saymadın. Derişim akıntı boyunca yarıya "
                        "iniyor.",
                    baslangic // 2:
                        "Yalnız bir kez yarıya indirdin. Çiftlik {} km aşağıda; "
                        "o mesafede kaç yarılanma olduğunu hesapla.".format(mesafe),
                },
                ipuclari=["Önce mesafeyi yarılanma mesafesine böl."],
                puan=14,
            ),
            sayi_adimi(
                soru=("Boşaltmanın çiftliğe verdiği yıllık zarar, arıtma "
                      "tesisinin yıllık maliyetini kaç kredi AŞIYOR?"),
                cevap=asim,
                birim="kredi",
                aciklama=(
                    "Zarar {} kredi, arıtma {} kredi: {} - {} = {} kredi. "
                    "Çevresel sonuç hesaba katılınca arıtma daha ucuz."
                ).format(zarar, aritma, zarar, aritma, asim),
                yaygin_yanlislar={
                    zarar:
                        "Zararı buldun ama arıtma maliyetiyle kıyaslamadın; "
                        "soru farkı istiyor.",
                    aritma:
                        "Arıtmanın maliyetini yazdın. Soru zararın bu maliyeti "
                        "ne kadar aştığını soruyor.",
                },
                ipuclari=["Çiftlik kaydındaki yıllık kaybı, arıtma teklifindeki maliyetle kıyasla."],
                puan=12,
            ),
            yorum_adimi(
                soru="Atölye şefinin \"atık orada kalır, arıtma boşa para\" iddiası neden yanlış?",
                dogru="İki yönden: atık çiftliğe ulaşıyor ve zararı arıtmadan büyük.",
                yanlislar={
                    "Yanlış değil: üs yukarıda olduğu için üsse bir zararı yok.":
                        "Üs doğrudan etkilenmiyor, doğru -- ama balığını "
                        "zarar gören çiftlikten alıyor. Ayrıca etkinin üsse "
                        "dokunmaması, başkasına dokunmadığı anlamına gelmez.",
                    "Yalnız biri yanlış: atık yayılıyor ama boşaltmak yine de daha ucuz.":
                        "Kullanım maliyetine çevresel sonucu katmadın. Çiftliğin "
                        "kaybı arıtma maliyetinden büyük.",
                    "Yalnız biri yanlış: arıtma daha ucuz ama atık çiftliğe ulaşmıyor.":
                        "İlk hesap bunu çürütüyor: çiftliğin önünde derişim "
                        "güvenli sınırın üstünde.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir faaliyetin maliyeti yalnız onu yapanın ödediği para "
                    "değildir. Kirliliğin başkalarına yüklediği zarar da "
                    "maliyettir -- ekonomide buna DIŞSALLIK denir. Onu hesaba "
                    "katmayan bir karar, pahalı bir yolu ucuz sanabilir."
                ),
                puan=12,
            ),
        ],
        kapanis=("Rapor: çiftliğin önünde derişim {} mg/L (sınır {}). Boşaltma "
                 "yılda {} kredi zarar veriyor, arıtma {} kredi -- arıtma "
                 "{} kredi daha ucuz.").format(ciftlik, sinir, zarar, aritma, asim),
        odul={"itibar": 6, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# COĞRAFYANIN BÖLÜMLERİ: ADLANDIRMA AÇIKLAMA DEĞİLDİR (B45 sonrası, B37.18)
#
# `cografyanin_bolumleri` (2018: 9) tek başına duruyordu; aynı yanılgı ve
# aynı bağlam `cografya_biliminin_gelisimi` ve `cografyanin_gelecegi`
# satırlarında da yazılı. `yaygin_yanlis`:
#
#   "Yeri adlandırmayı coğrafi nedenleri açıklamakla aynı saymak."
#
# DÜZENEK: üs kurma raporu. Personel yerlerin adını, yönünü ve yüksekliğini
# yazmış, "açıklama bitti" diyor. Rapordaki cümlelerin bir kısmı gerçekten
# neden söylüyor, bir kısmı yalnız yer bildiriyor. Ayrıca bir örneğin fiziki
# mi beşerî coğrafyaya mı girdiği ve hangi öngörünün kanıta dayandığı
# soruluyor.
#
# YANILGININ SAYISAL KARŞILIĞI: bütün cümleleri açıklama saymak.
# ==========================================================================

_RAPOR_ADLANDIRMA = (
    "Üssün kurulacağı yer {yer} Düzlüğü.",
    "{yer} Düzlüğünün kuzeyinde Sarp Dağları var.",
    "Yerleşmenin güneyinden {dere} Deresi geçiyor.",
    "Haritada bu alan {yer} Ovası diye adlandırılmış.",
    "Kampın denizden yüksekliği 820 metre.",
)
_RAPOR_ACIKLAMA = (
    "{yer} Düzlüğü, derenin taşıdığı alüvyonla dolduğu için tarıma elverişli.",
    "Kuzeydeki dağlar soğuk rüzgârı kestiği için kış sıcaklığı çevresinden yüksek.",
    "Yol tek geçitten geçtiği için depo bu yamaca kuruldu.",
    "Taban suyu tuzlu olduğu için üs içme suyunu {dere} Deresinden alıyor.",
    "Yamaç güneye baktığı için kar burada daha erken eriyor.",
)
# (örnek, alan, gerekçe)
_ALAN_ORNEKLERI = (
    ("Vadinin dere aşındırmasıyla derinleşmesi", "Fiziki coğrafya",
     "doğal süreç: akarsuyun aşındırması"),
    ("Yamaçtaki toprağın sağanakla taşınması", "Fiziki coğrafya",
     "doğal süreç: erozyon"),
    ("Kış sıcaklığının dağların rüzgârı kesmesiyle yükselmesi", "Fiziki coğrafya",
     "doğal süreç: iklim"),
    ("Deponun geçide yakın kurulması", "Beşerî coğrafya",
     "insan kararı: yerleşme ve ulaşım"),
    ("Kamp nüfusu artınca su tüketiminin yükselmesi", "Beşerî coğrafya",
     "insan etkinliği: nüfus ve tüketim"),
    ("Tarlaların sulama kanalıyla genişlemesi", "Beşerî coğrafya",
     "insan etkinliği: tarım"),
)


@bulmaca(ders="cografya", konu="cografyanin_bolumleri", kademeler=(9, 13), agirlik=1.2)
def rapor_gerekcesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yerin adını yazmak açıklama değildir; açıklama nedenle ve etkileşimle kurulur."""
    yer, dere = ad_sec(rastgele, MEVKI_ADLARI, 2)
    kac_aciklama = rastgele.choice((2, 3))
    cumleler = (rastgele.sample(_RAPOR_ACIKLAMA, kac_aciklama)
                + rastgele.sample(_RAPOR_ADLANDIRMA, 5 - kac_aciklama))
    cumleler = [c.format(yer=yer, dere=dere) for c in cumleler]
    rastgele.shuffle(cumleler)
    acik_kaliplar = [k.format(yer=yer, dere=dere) for k in _RAPOR_ACIKLAMA]
    acik_indeks = [n for n, c in enumerate(cumleler) if c in acik_kaliplar]
    ornek, alan, gerekce = rastgele.choice(_ALAN_ORNEKLERI)
    oteki = "Beşerî coğrafya" if alan == "Fiziki coğrafya" else "Fiziki coğrafya"
    dusus = rastgele.choice((30, 40, 50))
    yil = rastgele.choice((3, 4, 5))
    derinlik = dusus * yil
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-rapor-gerekcesi",
        ders="cografya",
        baslik="Rapor Gerekçesi",
        kademe=kademe,
        konu="cografyanin_bolumleri",
        kazanim="Coğrafi betimleme ile açıklamayı ayırma; fiziki ve beşerî coğrafyanın "
                "çalışma alanlarını örnekten tanıma; öngörüyü ölçüme dayandırma.",
        dikkat=6,
        brifing=(
            "Üs kurma raporu kurula sunulacak; coğrafya bölümünü {} yazdı.\n\n"
            "\"Bitti,\" diyor. \"Yerlerin adını, yönünü ve yüksekliğini yazdım; "
            "coğrafi açıklama dediğiniz budur. Geleceği de yazdım: burası "
            "bereketli olur, çünkü adı Ova.\"\n\n"
            "Rapor kurula gitmeden önce hangi cümlelerin gerçekten bir neden "
            "söylediğine bakmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Rapor taslağı", "\n".join(cumleler), bedel=1, kritik=True),
            Kanit("Coğrafya el kitabı",
                  "Betimleme, bir yerin nerede olduğunu ve neye benzediğini söyler. "
                  "Açıklama, o özelliğin nedenini ve insan ile doğa arasındaki "
                  "etkileşimi kurar. Doğal süreçleri fiziki coğrafya, insan "
                  "etkinliklerini beşerî coğrafya inceler. Coğrafi öngörü ise "
                  "ölçülmüş eğilime dayandırılır; yer adından çıkarılmaz.",
                  bedel=1, kritik=True),
            Kanit("Kuyu ölçüm defteri",
                  "Kamp kuyusunda su seviyesi son üç yılın her birinde {} cm "
                  "düştü. Kuyudaki su sütunu şu an {} cm."
                  .format(dusus, derinlik),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Coğrafi bir açıklama neyi yapar?",
                dogru="Bir özelliğin nedenini doğal süreç ve insan etkinliğiyle kurar",
                yanlislar={
                    "Yerin adını, yönünü ve yüksekliğini eksiksiz yazar; eksiksiz betimleme açıklamadır":
                        "Yeri adlandırmayı coğrafi nedeni açıklamakla aynı saydın. "
                        "Bunlar betimlemedir; neden söylemez.",
                    "Yalnız haritada gösterir, çünkü yeri gören nedenini de görür":
                        "Harita yeri gösterir; nedenini göstermez.",
                    "Olayın tarihini verir; zamanı bilinen olay açıklanmış olur":
                        "Tarih ne zaman olduğunu söyler, niçin olduğunu değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Düzlüğün kuzeyinde dağlar var\" bir betimlemedir. "
                    "\"Kuzeydeki dağlar soğuk rüzgârı kestiği için kış burada "
                    "ılık geçer\" ise açıklamadır: aynı dağdan bir neden çıkarır."
                ),
                ipuclari=[
                    "Cümle \"nerede\" sorusuna mı, \"niçin\" sorusuna mı cevap veriyor?",
                    "El kitabı betimleme ile açıklamayı nasıl ayırıyor?",
                ],
                cozum="Neden bildiren cümle -> açıklama; yer bildiren cümle -> betimleme",
            ),
            coklu_adimi(
                soru="Rapordaki hangi cümleler bir açıklamadır? (numaraları virgülle yaz)",
                secenekler=cumleler,
                dogru_indeksler=acik_indeks,
                aciklama="Açıklama cümleleri bir neden kurar; ötekiler yalnız yer bildirir.",
                ipuclari=["Cümlede bir neden bağlacı var mı, yoksa yalnız ad ve yön mü var?"],
                puan=15,
            ),
            sayi_adimi(
                soru="Raporun beş cümlesinden kaçı coğrafi açıklamadır?",
                cevap=kac_aciklama,
                aciklama="{} cümle neden kuruyor; kalanı betimleme."
                         .format(kac_aciklama),
                yaygin_yanlislar={
                    5: "Bütün cümleleri açıklama saydın; adlandırma açıklama değildir.",
                    0: "Neden bildiren cümleleri de betimleme saydın.",
                },
                ipuclari=["Seçtiğin açıklama cümlelerini say."],
                puan=12,
            ),
            secim_adimi(
                soru="\"{}\" hangi alanın konusudur?".format(ornek),
                dogru="{}: {}".format(alan, gerekce),
                yanlislar={
                    "{}: asıl konusu budur".format(oteki):
                        "Örnekteki süreç öteki alana ait; el kitabındaki ayrıma bak.",
                    "Hiçbiri: bu cümle yalnız yerin adını söylüyor; bir süreç anlatmıyor":
                        "Yeri adlandırmayla nedeni açıklamayı aynı saydın; "
                        "burada bir süreç anlatılıyor.",
                },
                rastgele=rastgele,
                aciklama="{}: {}.".format(ornek, gerekce),
                ipuclari=["Anlatılan şeyi doğa mı yapıyor, insan mı?"],
                puan=12,
            ),
            secim_adimi(
                soru="Rapordaki geleceğe dönük cümle hangisi olmalı?",
                dogru="Kuyu suyu yılda {} cm düşüyor; bu hızla {} yılda tükenir".format(dusus, yil),
                yanlislar={
                    "Burası bereketli olur, çünkü adı Ova; ova toprağı hep verimlidir":
                        "Yer adını coğrafi nedenle karıştırdın; ad bir kanıt değildir.",
                    "Bölge büyük şehirden uzak olduğu için hiç değişmez":
                        "Uzaklık değişimi durdurmaz; ölçülen eğilim değişimi gösteriyor.",
                },
                rastgele=rastgele,
                aciklama=("Ölçüm defteri yılda {} cm düşüş gösteriyor; {} cm su "
                          "sütunu bu hızla {} yılda tükenir. Öngörü buradan "
                          "kurulur.").format(dusus, derinlik, yil),
                ipuclari=["Hangi cümlenin arkasında bir ölçüm var?"],
                puan=12,
            ),
        ],
        kapanis=("Rapor düzeltildi: {} cümle açıklama olarak kaldı, kalanı "
                 "betimleme başlığına taşındı; öngörü kuyu ölçümüne dayandırıldı."
                 ).format(kac_aciklama),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# TOPRAK OLUŞUMU: TOPRAK KIRIK KAYAÇ DEĞİLDİR (B37.18)
#
# `toprak_olusumu` (2018: 10 ve 12) boştu. `yaygin_yanlis`:
#
#   "Toprağın yalnız parçalanmış kayaç olduğunu veya bütün toprakların aynı
#    verimde olduğunu sanmak."
#
# DÜZENEK: üç arazi gözlem kaydı. Kartlarda ana materyal, iklim, kullanım
# biçimi, organik madde oranı ve A horizonu kalınlığı var. Personel hepsini
# "aynı toprak" sayıp ekim planını kura ile dağıtmak istiyor. Ayrıca aynı
# ana materyalden oluşmuş iki toprağın verimi neden farklı, o soruluyor.
#
# YANILGININ SAYISAL KARŞILIĞI: A horizonunu tükenmez sanmak (erozyon
# hesabında yılı sonsuz ya da ölçüm sayısına eşit saymak).
# ==========================================================================

# (mevki, ana materyal, iklim, kullanım, organik madde %, A horizonu cm)
_TOPRAK_KARTLARI = (
    ("Dere tabanı", "akarsu alüvyonu", "ılıman ve yağışlı", "münavebeli ekim", "4,2", 60),
    ("Kireçli sırt", "kalker", "yarı kurak", "aşırı otlatma", "1,1", 15),
    ("Granit yamaç", "granit", "serin ve yağışlı", "orman örtüsü altında", "3,0", 35),
    ("Kumul kenarı", "rüzgârla taşınan kum", "kurak", "nadasa bırakılmış", "0,6", 10),
    ("Volkanik ova", "volkanik kül", "ılıman", "sebze tarımı", "3,8", 50),
)
# (ana materyal, zayıf arazi, verimli arazi, farkı açıklayan etken)
_AYNI_MATERYAL = (
    ("kalker", "aşırı otlatılan sırt", "teraslanıp ağaçlandırılmış sırt",
     "Bitki örtüsü ve eğim: örtü kalkınca A horizonu yağışla taşınıyor"),
    ("volkanik kül", "yıllardır aynı ürünün ekildiği ova", "münavebe yapılan ova",
     "Kullanım biçimi: aynı ürün toprağı aynı besinden yoksun bırakıyor"),
    ("granit", "kurak yamaç", "yağışlı yamaç",
     "İklim: nemli yamaçta ayrışma ve organik madde birikimi hızlanıyor"),
)


@bulmaca(ders="cografya", konu="toprak_olusumu", kademeler=(10, 13), agirlik=1.2)
def toprak_kayitlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Toprak; ana materyal, iklim, canlılar, eğim ve zamanın ortak ürünüdür."""
    kartlar = rastgele.sample(_TOPRAK_KARTLARI, 3)
    rastgele.shuffle(kartlar)
    en_verimli = max(kartlar, key=lambda k: float(k[4].replace(",", ".")))
    en_zayif = min(kartlar, key=lambda k: float(k[4].replace(",", ".")))
    materyal, zayif, verimli, etken = rastgele.choice(_AYNI_MATERYAL)
    kayip = rastgele.choice((2, 3, 5))
    yil = rastgele.choice((30, 40, 60))
    derinlik = kayip * yil // 10
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-toprak-kayitlari",
        ders="cografya",
        baslik="Toprak Kayıtları",
        kademe=kademe,
        konu="toprak_olusumu",
        kazanim="Toprağı ana materyal, iklim, canlılar, eğim ve zamanın ürünü olarak "
                "açıklama; toprak çeşitliliğini gözlem kayıtlarıyla karşılaştırma; "
                "A horizonunun tükenebilirliğini hesapla gösterme.",
        dikkat=6,
        brifing=(
            "Üs, üç mevkiye ekim yapacak; arazi gözlem kayıtları geldi.\n\n"
            "{} planı kurayla dağıtmak istiyor: \"Toprak dediğin kırılmış "
            "kayadır. Üçü de aynı dağın eteğinde; hangisine ne ekersek "
            "ekelim fark etmez.\"\n\n"
            "Tohum dağıtılmadan önce kayıtlardaki farklara bakmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Arazi gözlem kayıtları",
                  "\n".join("{}: ana materyal {}, iklim {}, kullanım {}, "
                            "organik madde %{}, A horizonu {} cm."
                            .format(ad, mat, iklim, kul, org, der)
                            for ad, mat, iklim, kul, org, der in kartlar),
                  bedel=2, kritik=True),
            Kanit("Toprak el kitabı",
                  "Toprak yalnız parçalanmış kayaç değildir: mineral tanelerin "
                  "yanında organik madde, su, hava ve canlılar bulunur. Oluşumunu "
                  "ana materyal, iklim, canlılar, yer şekli (eğim) ve zaman "
                  "birlikte belirler. Üstteki A horizonu organik maddece en "
                  "zengin katmandır ve taşındığında yerine yenisi ancak "
                  "yüzyıllarda gelir.",
                  bedel=1, kritik=True),
            Kanit("Erozyon ölçümü",
                  "Örtüsü kalkmış yamaçta A horizonundan yılda ortalama {} mm "
                  "toprak taşınıyor.".format(kayip),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Toprak nasıl oluşur?",
                dogru="Ana materyal, iklim, canlılar, eğim ve zamanla ayrışıp toprağa dönüşür",
                yanlislar={
                    "Kayanın kırılıp ufalanmasıyla; toprak öğütülmüş kayaçtır":
                        "Toprağı yalnız parçalanmış kayaç saydın. Organik madde, "
                        "su, hava ve canlılar olmadan toprak olmaz.",
                    "Yalnız çürümüş bitkilerin birikmesiyle":
                        "Organik madde tek başına yetmez; mineral ana materyal de gerekir.",
                    "Akarsuyun taşıdığı kumun yığılmasıyla; toprak her yerde taşınmış kumdur":
                        "Taşınan malzeme ana materyal olabilir, ama toprak olması için "
                        "ayrışma ve organik madde birikimi gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı kayaçtan, farklı iklimde ve farklı kullanımda bambaşka "
                    "topraklar oluşur. Kayıtlarda ana materyali aynı olan yerlerin "
                    "organik maddesi bile tutmuyor."
                ),
                ipuclari=[
                    "El kitabı toprağın içinde kayaç dışında ne olduğunu sayıyor.",
                    "Oluşumu belirleyen beş etkene bak.",
                ],
                cozum="Ana materyal + iklim + canlilar + egim + zaman -> toprak",
            ),
            secim_adimi(
                soru="Kayıtlara göre tohumun büyük kısmı hangi mevkiye ayrılmalı?",
                dogru="{}: organik maddesi %{} ve A horizonu {} cm".format(
                    en_verimli[0], en_verimli[4], en_verimli[5]),
                yanlislar={
                    "Fark etmez; üçü de aynı verimde, kurayla dağıtılabilir":
                        "Bütün toprakları aynı verimde saydın; kayıtlar organik "
                        "maddede ve derinlikte açık fark gösteriyor.",
                    "{}: en ince A horizonu en kolay işlenendir".format(en_zayif[0]):
                        "İnce A horizonu kolaylık değil yoksulluk işaretidir.",
                },
                rastgele=rastgele,
                aciklama="{}: {} üzerinde, {} iklimde, {}. Organik madde %{}, "
                         "A horizonu {} cm.".format(
                             en_verimli[0], en_verimli[1], en_verimli[2],
                             en_verimli[3], en_verimli[4], en_verimli[5]),
                ipuclari=["Organik madde oranı ve A horizonu kalınlığı birlikte okunur."],
                puan=12,
            ),
            sayi_adimi(
                soru="Örtüsü kalkmış bir yamaçta {} cm kalınlığındaki A horizonu, "
                     "bu taşınma hızıyla kaç yılda tükenir?".format(derinlik),
                cevap=yil,
                aciklama="{} cm = {} mm; yılda {} mm taşınırsa {} yıl.".format(
                    derinlik, derinlik * 10, kayip, yil),
                birim="yıl",
                yaygin_yanlislar={
                    derinlik: "Santimetreyi milimetreye çevirmedin: 1 cm = 10 mm.",
                    derinlik // kayip: "Santimetre ile milimetreyi bölüştürdün; "
                                       "önce kalınlığı milimetreye çevir.",
                },
                ipuclari=["Önce kalınlığı milimetreye çevir, sonra yıllık kayba böl."],
                puan=12,
                cozum="({} cm x 10) / {} mm/yil".format(derinlik, kayip),
            ),
            secim_adimi(
                soru="Aynı {} ana materyalinden oluşan iki toprakta, {} ile {} "
                     "arasındaki verim farkını ne açıklar?".format(
                         materyal, zayif, verimli),
                dogru=etken,
                yanlislar={
                    "Ana materyal aynıysa topraklar da aynıdır; fark ölçüm hatasıdır":
                        "Bütün toprakları aynı saydın; ana materyal beş etkenden "
                        "yalnız biridir.",
                    "Yalnız atılan gübrenin miktarı belirler, çünkü gübre her eksiği kapatır":
                        "Gübre besini artırır ama horizon kalınlığını ve yapıyı kurmaz.",
                },
                rastgele=rastgele,
                aciklama="{} ana materyali aynı olsa bile toprak farklı gelişir. {}."
                         .format(materyal[:1].upper() + materyal[1:], etken),
                ipuclari=["El kitabındaki beş etkenden hangisi bu iki arazide değişiyor?"],
                puan=12,
            ),
        ],
        kapanis=("Kura iptal edildi: tohumun büyük kısmı {} mevkiine ayrıldı, "
                 "örtüsü kalkmış yamaç için {} yıllık erozyon uyarısı kayda "
                 "geçti.").format(en_verimli[0], yil),
        odul={"itibar": 4, "erzak": 2},
    )


# ==========================================================================
# ÇEVRE ÖRGÜTLERİ VE ANLAŞMALAR: KARAR SONUÇ DEĞİLDİR (B37.18)
#
# `cevre_orgut_anlasma` (2018: 12, dört satır) boştu. `yaygin_yanlis`:
#
#   "Bir örgütün kararını bütün üyelerde aynı biçimde gerçekleşen sonuç
#    sanmak."
#
# DÜZENEK: dört üssün imzaladığı kıyı sözleşmesi. Belgelerde hedef aynı ama
# onay, iç düzenleme, denetim ve kaynak farklı; ölçülen sonuç da farklı.
# Ayrıca sözleşme metninden bir cümlenin amaç mı, araç mı, sonuç mu olduğu
# soruluyor.
#
# YANILGININ SAYISAL KARŞILIĞI: hedefi tutturan üs sayısını üye sayısı
# saymak.
# ==========================================================================

# (üs, onay durumu, ölçülen azalma %, kısa gerekçe)
_SOZLESME_UYELERI = (
    ("Kuzey Feneri", "onayladı, arıtma tesisini kurdu", 34,
     "iç yönetmelik çıkardı ve denetim kurdu"),
    ("Tuzla İskelesi", "onayladı, ödeneği gelmedi", 8,
     "yönetmelik var ama arıtma kurulamadı"),
    ("Derinliman", "imzaladı, kurulu onaylamadı", 3,
     "iç düzenleme yapılmadı, taahhüt bağlayıcı olmadı"),
    ("Akkaya", "üye değil, gönüllü uyguluyor", 29,
     "kendi kararıyla arıtmaya geçti"),
    ("Sarpkıyı", "onayladı, denetim yok", 11,
     "yönetmelik var, uygulama denetlenmiyor"),
    # 25: hedefe TAM EŞİT bir ölçüm; "hedefi tutturdu" sınırı eşitliği de
    # kapsamalı, yoksa sınır hatası hiçbir örnekte görünmez.
    ("Gökliman", "onayladı, kademeli plan yürüyor", 25,
     "üç yıllık planın ikinci yılında"),
)
# (cümle, tür, açıklama)
_BELGE_CUMLELERI = (
    ("Kıyı sularındaki canlı çeşitliliğini korumak", "Amaç",
     "kıyıda ulaşılmak istenen durum"),
    ("Üyeler atık suyu arıtmadan denize vermeyecek", "Araç",
     "amaca ulaşmak için konan kural"),
    ("Her üye yıllık ölçüm raporu gönderecek", "Araç",
     "denetimi sağlayan yükümlülük"),
    ("Kıyı ölçüm noktalarında kirlilik üç yılda dörtte bir azaldı", "Sonuç",
     "uygulamadan sonra ölçülen etki"),
    ("Balıkçı teknesi başına av kaydı tutulmaya başlandı", "Sonuç",
     "uygulamadan sonra gözlenen etki"),
)
# Yanlış şıkta öteki türün genel tanımı: öğrenci cümleyi doğru tanıma oturtmalı.
_BELGE_TUR_TANIMI = {
    "Amaç": "sözleşmenin ulaşmak istediği durum",
    "Araç": "amaca ulaşmak için konan kural",
    "Sonuç": "uygulamanın ölçülmüş etkisi",
}


@bulmaca(ders="cografya", konu="cevre_orgut_anlasma", kademeler=(11, 13), agirlik=1.3)
def sozlesme_dosyasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Ortak karar aynı; sonucu iç düzenleme, denetim ve kaynak belirler."""
    hedef = rastgele.choice((20, 25, 30))
    # En az biri hedefi tutmalı, en az biri tutmamalı: "hepsi aynı sonuç"
    # yanılgısının da, tersinin de yanlış çıkması için.
    tutan_havuz = [u for u in _SOZLESME_UYELERI if u[2] >= hedef]
    kalan_havuz = [u for u in _SOZLESME_UYELERI if u[2] < hedef]
    kac_tutan = min(rastgele.choice((1, 2)), len(tutan_havuz), 3)
    uyeler = (rastgele.sample(tutan_havuz, kac_tutan)
              + rastgele.sample(kalan_havuz, 4 - kac_tutan))
    rastgele.shuffle(uyeler)
    tutan = [u for u in uyeler if u[2] >= hedef]
    kalan = [u for u in uyeler if u[2] < hedef]
    cumle, tur, neden = rastgele.choice(_BELGE_CUMLELERI)
    oteki_turler = [t for t in ("Amaç", "Araç", "Sonuç") if t != tur]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-sozlesme-dosyasi",
        ders="cografya",
        baslik="Sözleşme Dosyası",
        kademe=kademe,
        konu="cevre_orgut_anlasma",
        kazanim="Çevre anlaşmalarının kararı ile üyelerdeki sonucu ayırma; belgelerde "
                "amaç, araç ve sonucu ayırt etme; uygulama farkını iç düzenleme, "
                "denetim ve kaynakla açıklama.",
        dikkat=7,
        brifing=(
            "Kıyı Sözleşmesinin üçüncü yıl dosyası kurula gidecek. Hedef "
            "ortaktı: kıyı kirliliğini yüzde {} azaltmak.\n\n"
            "{} raporun özetini şöyle yazdı: \"Sözleşme imzalandığına göre "
            "dört üste de kirlilik yüzde {} azalmıştır. Ölçümlere bakmaya "
            "gerek yok, karar ortak.\"\n\n"
            "Dosya kapanmadan önce üslerin kendi belgelerine bakmamız "
            "gerekiyor."
        ).format(hedef, kisi, hedef),
        kanitlar=[
            Kanit("Üs belgeleri",
                  "\n".join("{}: {}; ölçülen azalma %{} ({})."
                            .format(ad, durum, azalma, gerekce)
                            for ad, durum, azalma, gerekce in uyeler),
                  bedel=2, kritik=True),
            Kanit("Sözleşme metni",
                  "Sözleşme üyeleri bağlar; ama bir kararın sonuç doğurması için "
                  "üyenin kendi kurulunda onaylanması, iç yönetmeliğe çevrilmesi, "
                  "denetlenmesi ve ödeneğinin ayrılması gerekir. Üye olmayan bir "
                  "taraf da kendi kararıyla aynı kuralı uygulayabilir.",
                  bedel=1, kritik=True),
            Kanit("Ölçüm notu",
                  "Azalma oranları üslerin kendi kıyı ölçüm noktalarından, aynı "
                  "yöntemle alındı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Ortak bir çevre kararı üyelerde nasıl sonuç doğurur?",
                dogru="Onay, iç düzenleme, denetim ve ödenek zincirinden geçerek",
                yanlislar={
                    "Karar alındığı anda bütün üyelerde aynı sonuç doğar; imza yeter":
                        "Bir örgütün kararını bütün üyelerde aynı gerçekleşen sonuç "
                        "saydın. Karar bir taahhüttür; uygulaması üyeye bağlıdır.",
                    "Hiçbir etkisi olmaz, anlaşmalar yalnız törendir":
                        "Belgeler tersini gösteriyor: zinciri tamamlayan üste ölçülen "
                        "azalma hedefin üstünde.",
                    "Yalnız en zengin üyede sonuç doğar; karar ona göre yazılır":
                        "Belirleyici olan zenginlik değil, zincirin tamamlanması; "
                        "üye olmayan bir taraf bile gönüllü uygulayabiliyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı imza, dört üste dört ayrı sonuç verdi: kurulu onaylamayan "
                    "üste taahhüt bağlayıcı bile olmadı, ödeneği gelmeyen üste "
                    "yönetmelik kâğıtta kaldı."
                ),
                ipuclari=[
                    "Sözleşme metni kararın sonuca dönüşmesi için neleri sayıyor?",
                    "Hedefi tutturan üslerde bu adımların hangisi tamam?",
                ],
                cozum="Onay -> ic yonetmelik -> denetim -> odenek -> olculen sonuc",
            ),
            sayi_adimi(
                soru="Dört üsten kaçı yüzde {} hedefini tutturdu?".format(hedef),
                cevap=len(tutan),
                aciklama="; ".join("{} %{}".format(u[0], u[2]) for u in uyeler),
                yaygin_yanlislar={
                    4: "Kararı bütün üyelerde gerçekleşen sonuç saydın; ölçümler "
                       "farklı.",
                    0: "Hedefi tutturan üs var; ölçülen azalmaları hedefle karşılaştır.",
                },
                ipuclari=["Her üssün ölçülen azalmasını hedefle karşılaştır."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi üslerde sözleşme ölçülebilir sonuca dönüşmüş? "
                     "(numaraları virgülle yaz)",
                secenekler=["{} (%{})".format(u[0], u[2]) for u in uyeler],
                dogru_indeksler=[n for n, u in enumerate(uyeler) if u[2] >= hedef],
                aciklama="Sonuç, hedefin tutturulduğu ölçümle gösterilir: %{} ve üstü."
                         .format(hedef),
                ipuclari=["Ölçülen azalma hedefe ulaşan üsleri seç."],
                puan=12,
            ),
            secim_adimi(
                soru="Dosyadaki \"{}\" ifadesi amaç mı, araç mı, sonuç mu?".format(cumle),
                dogru="{}: {}".format(tur, neden),
                yanlislar={
                    "{}: {}".format(oteki_turler[0], _BELGE_TUR_TANIMI[oteki_turler[0]]):
                        "Amaç ulaşılmak isteneni, araç kuralı, sonuç ölçüleni bildirir.",
                    "{}: {}".format(oteki_turler[1], _BELGE_TUR_TANIMI[oteki_turler[1]]):
                        "Amaç ulaşılmak isteneni, araç kuralı, sonuç ölçüleni bildirir.",
                },
                rastgele=rastgele,
                aciklama="{}: {}.".format(cumle, neden),
                ipuclari=["Cümle ne istiyor, ne emrediyor, yoksa neyi ölçüyor?"],
                puan=12,
            ),
        ],
        kapanis=("Dosya düzeltildi: dört üsten {} tanesi hedefi tutturmuş olarak "
                 "kayda geçti; {} tanesi için onay, denetim ve ödenek eksikleri "
                 "ayrı başlık açtı.").format(len(tutan), len(kalan)),
        odul={"itibar": 5, "cevher": 1},
    )


# ==========================================================================
# KÜLTÜR BÖLGELERİ: SINIR ÇİZGİSİ DEĞİL, YAYILIŞ ALANI (B37.18)
#
# Haritada aynı yanılgı ve aynı bağlamla 13 satır duruyor (7 kod, 10-12):
# ilk_kultur_merkezleri, kultur_bolgeleri, kultur_mekan_etkilesim,
# turk_dunyasi_ortak_kultur, turk_kultur_baglari, turk_kulturu_yayilisi,
# turkiye_kulturel_baglar. `yaygin_yanlis`:
#
#   "Kültürel bölgeyi değişmez veya devlet sınırlarıyla özdeş saymak."
#
# DÜZENEK: sefer arşivindeki kültür kartları. Her kartta bir öğe (mimari,
# yaşam biçimi, iletişim, geçim), nerelerde görüldüğü ve yüz yıl içinde
# neyin değiştiği yazılı. Bazı öğeler iki devletin topraklarında birden
# görülüyor; bazıları tek bölgeye özgü. Personel arşivi devlet sınırına
# göre ikiye bölmek istiyor.
#
# YANILGININ SAYISAL KARŞILIĞI: sınırı aşan öğe sayısını 0 saymak.
# ==========================================================================

# (öğe, alan, sınırı aşıyor mu, yüz yıldaki değişim)
_KULTUR_KARTLARI = (
    ("Keçe çadır ve yaylak takvimi", "yaşam biçimi", True,
     "çadır iskeleti artık alüminyum, yaylaya araçla çıkılıyor"),
    ("Ahşap oymalı cumbalı ev", "mimari", True,
     "yeni evler betonarme, oyma süsler yalnız cephede kaldı"),
    ("Aynı destanın iki ağızda söylenişi", "iletişim", True,
     "destan radyoda tek ağızla okunuyor, iki söyleyiş de kayda alındı"),
    ("Kerpiç avlulu ev", "mimari", False,
     "kerpiç yerini tuğlaya bıraktı, avlu planı sürüyor"),
    ("Pamuk dokuma tezgâhı", "geçim", False,
     "tezgâh fabrikaya taşındı, desenler aynı kaldı"),
    ("Kışlık balık tuzlama", "geçim", False,
     "tuzlama soğuk depoya döndü, şenlik günü sürüyor"),
)
_KULTUR_YERLERI = {
    True: "Karaç Devletinin doğusunda ve Örenli Birliğinin kuzey otlaklarında",
    False: "yalnız Karaç Devletinin güney ovasında",
}
# Sınırı aşan her öğenin KENDİ yayılma etkeni: (etken, şıktaki kısa gerekçe,
# açıklamadaki gerekçe). Çadır ve ahşap ev doğal ortama ve geçime bağlı;
# destanı iklim değil, onu söyleyen toplulukların yolu taşır.
_ORTAM = "Doğal ortam ve geçim biçimi"
_YOL = "Göç ve ticaret yolları"
_KULTUR_ETKENLERI = {
    "Keçe çadır ve yaylak takvimi": (
        _ORTAM, "iki yanda aynı otlak ve hayvancılık",
        "iki yandaki otlaklar aynı hayvancılığı besliyor; çadır ve yayla "
        "takvimi bu geçimin parçası"),
    "Ahşap oymalı cumbalı ev": (
        _ORTAM, "iki yan aynı orman kuşağında",
        "iki yan aynı orman kuşağında; evin ahşabı yakındaki ormandan geliyor"),
    "Aynı destanın iki ağızda söylenişi": (
        _YOL, "destan aynı yolla iki yana taşınmış",
        "destanı söyleyen topluluklar aynı göç ve kervan yolu boyunca iki "
        "yana yerleşmiş; bir destanı iklim ya da bitki örtüsü taşımaz"),
}


@bulmaca(ders="cografya", konu="kultur_bolgeleri", kademeler=(10, 13), agirlik=1.4)
def kultur_kartlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kültür bölgesi devlet sınırıyla çakışmaz ve zamanla değişir."""
    asan = [k for k in _KULTUR_KARTLARI if k[2]]
    yerel = [k for k in _KULTUR_KARTLARI if not k[2]]
    kac_asan = rastgele.choice((2, 3))
    kartlar = rastgele.sample(asan, kac_asan) + rastgele.sample(yerel, 5 - kac_asan)
    rastgele.shuffle(kartlar)
    asan_indeks = [n for n, k in enumerate(kartlar) if k[2]]
    # Arşivde her kartın yüz yıllık karşılığı yok: kaç kartta DEĞİŞİM BELGELİ,
    # onu saydırıyoruz. Böylece "kültür değişmez" (0) da, "hepsi değişti" (5)
    # de yanlış çıkar ve cevap sabit kalmaz.
    eksik = rastgele.sample(range(5), rastgele.choice((1, 2)))
    kac_degisen = 5 - len(eksik)
    degisim_satirlari = [
        "{}: yüz yıl önceki kayıt arşivde yok.".format(kartlar[n][0]) if n in eksik
        else "{}: {}.".format(kartlar[n][0], kartlar[n][3])
        for n in range(5)
    ]
    odak = rastgele.choice([k for k in kartlar if k[2]])
    etken, kisa_gerekce, gerekce = _KULTUR_ETKENLERI[odak[0]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-kultur-kartlari",
        ders="cografya",
        baslik="Kültür Kartları",
        kademe=kademe,
        konu="kultur_bolgeleri",
        kazanim="Kültürel öğelerin yayılış alanını devlet sınırından ayırma; kültür "
                "bölgelerinin zamanla değiştiğini örneklerle gösterme; dağılışı doğal "
                "ortam, geçim ve yollarla ilişkilendirme.",
        dikkat=7,
        brifing=(
            "Sefer arşivindeki kültür kartları sergi için gruplanacak.\n\n"
            "{} kartları devlet sınırına göre ikiye ayırdı: \"Kültür bölgesi "
            "dediğin devletin sınırıdır. Sınırın içi tek kültür, dışı başka "
            "kültür. Hem kültür değişmez; kartlar yüz yıl önce neyse bugün de "
            "odur.\"\n\n"
            "Sergi asılmadan önce kartlardaki yayılış ve değişim notlarına "
            "bakmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Kültür kartları",
                  "\n".join("{} ({}): {} görülüyor.".format(
                      ad, alan, _KULTUR_YERLERI[asar])
                      for ad, alan, asar, _ in kartlar),
                  bedel=2, kritik=True),
            Kanit("Yüz yıllık karşılaştırma",
                  "\n".join(degisim_satirlari),
                  bedel=2, kritik=True),
            Kanit("Arşiv notu",
                  "Kültür bölgesi, ortak kültür öğelerinin görüldüğü alandır. "
                  "Sınırları çizgi değil geçiş kuşağıdır: bir öğe iki devletin "
                  "topraklarında birden görülebilir, bir devletin içinde birden "
                  "çok kültür bölgesi bulunabilir. Öğeler doğal ortam, geçim "
                  "biçimi, göç ve ticaret yollarıyla yayılır; zamanla da değişir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Kültür bölgesi neye göre belirlenir?",
                dogru="Ortak öğelerin yayılışına göre; sınırı geçişli ve değişkendir",
                yanlislar={
                    "Devletin siyasi sınırına göre; sınırın içi tek kültürdür":
                        "Kültür bölgesini devlet sınırıyla özdeş saydın. Kartlar "
                        "aynı öğenin iki devlette birden görüldüğünü söylüyor.",
                    "Bir kez kurulur ve değişmez; kültür yüzyıllarca aynı kalır":
                        "Kültürü değişmez saydın; karşılaştırma yüz yılda neyin "
                        "değiştiğini tek tek yazıyor.",
                    "Yalnız konuşulan dile göre; aynı dili konuşan aynı kültürdendir":
                        "Dil önemli bir öğedir ama tek ölçüt değildir; mimari, geçim "
                        "ve yaşam biçimi de bölgeyi belirler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kartlardaki öğelerin bir kısmı sınırda durmuyor, iki devletin "
                    "topraklarında birden yaşıyor. Aynı kartlar yüz "
                    "yılda değişmiş de: kültür bölgesi ne çizgidir ne donmuştur."
                ),
                ipuclari=[
                    "Bir öğe aynı anda iki devlette görülebiliyor mu?",
                    "Karşılaştırma notu değişimi nasıl anlatıyor?",
                ],
                cozum="Yayilis alani + gecis kusagi + zamanla degisim -> kultur bolgesi",
            ),
            coklu_adimi(
                soru="Hangi öğeler devlet sınırını aşıyor? (numaraları virgülle yaz)",
                secenekler=["{} ({})".format(k[0], k[1]) for k in kartlar],
                dogru_indeksler=asan_indeks,
                aciklama="Sınırı aşan öğeler iki devletin topraklarında birden görülüyor.",
                ipuclari=["Kartta kaç yer adı geçiyor?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Kaç kartta yüz yıllık değişim BELGELENMİŞ?",
                cevap=kac_degisen,
                aciklama="{} kartta değişim yazılı; kalanının yüz yıl önceki kaydı "
                         "arşivde yok, yani değişmediği de söylenemez."
                         .format(kac_degisen),
                yaygin_yanlislar={
                    0: "Kültürü değişmez saydın; kartların çoğunda değişim yazılı.",
                    5: "Kaydı bulunmayan kartı da belgelenmiş saydın.",
                },
                ipuclari=["Karşılaştırma notunda 'kayıt arşivde yok' yazan satırları ayır."],
                puan=12,
            ),
            secim_adimi(
                soru="\"{}\" öğesinin iki devlette birden görülmesini ne açıklar?"
                     .format(odak[0]),
                dogru="{}: {}".format(etken, kisa_gerekce),
                yanlislar={
                    "Devlet sınırının yanlış çizilmiş olması; doğru sınırda kültür de biter":
                        "Kültür bölgesini devlet sınırıyla özdeş saydın; sınır doğru "
                        "olsa da kültür öğesi iki yana yayılabilir.",
                    "Kartın arşive yanlış geçmiş olması":
                        "Kayıt hatası değil: öğe iki yanda da yerinde gözlenmiş.",
                },
                rastgele=rastgele,
                aciklama="{}: {}.".format(etken, gerekce),
                ipuclari=["Arşiv notu öğelerin neyle yayıldığını sayıyor."],
                puan=12,
            ),
        ],
        kapanis=("Sergi düzeni değişti: kartlar devlet sınırına göre değil yayılış "
                 "alanına göre dizildi; {} öğe sınır aşan kuşağa gitti, {} kartın "
                 "yüz yıllık değişim notu yanına asıldı.").format(kac_asan, kac_degisen),
        odul={"itibar": 5, "cevher": 1},
    )


# ==========================================================================
# AFET: TEHLİKE, RİSK VE AFET AYNI ŞEY DEĞİLDİR (B37.18)
#
# Haritada aynı yanılgı ve aynı bağlamla 11 satır duruyor (10 kod, 9-12):
# afet_siniflandirma, afet_turleri_nedenleri, afette_iyi_uygulamalar,
# afetten_korunma, butuncul_afet_yonetimi, dunya_afet_dagilisi,
# ekstrem_doga_olaylari, mekana_gore_afet_onlemi ve devamı. `yaygin_yanlis`:
#
#   "Tehlike, risk ve afeti aynı saymak; korunmayı yalnız olay sonrası
#    müdahale sanmak."
#
# DÜZENEK: üç depo için katmanlı risk tablosu. Her depoda tehlike (doğa
# olayının şiddeti ve sıklığı), maruziyet (kaç kişi ve ne kadar yük) ve
# kırılganlık (yapı dayanımı, tatbikat, erken uyarı) ayrı puanlı. Personel
# "tehlike varsa afet var" deyip en yüksek tehlikeli depoyu boşaltmak,
# korunmayı da enkaz kaldırma ekibine indirgemek istiyor.
#
# YANILGININ SAYISAL KARŞILIĞI: güçlendirmeden sonra risk puanını
# değişmemiş saymak (tehlike puanını riskle aynı sanmak).
# ==========================================================================

# Tehlikesi en yüksek (3) ama maruziyeti ve kırılganlığı en düşük depolar.
# Görevin can alıcı yeri burası: en tehlikeli depo, en riskli depo DEĞİL.
# (depo, doğa olayı, tehlike, maruziyet, kırılganlık, kırılganlık gerekçesi)
_AFET_TEHLIKELI = (
    ("Sarp Geçit deposu", "kaya düşmesi", 3, 1, 1,
     "çelik çatı, ayda bir tatbikat, geçitte gözlem noktası"),
    ("Kuzey Gözetleme deposu", "çığ", 3, 1, 1,
     "betonarme sığınak, haftalık tatbikat, kar ölçüm direği"),
)
# Tehlikesi daha düşük ama maruziyeti ve kırılganlığı yüksek depolar.
# Risk çarpımları birbirinden farklı: 18, 12, 8, 6.
_AFET_DEPOLARI = (
    ("Ova deposu", "taşkın", 2, 3, 3,
     "tek katlı kerpiç, tatbikat yok, uyarı sistemi yok"),
    ("Vadi deposu", "taşkın", 2, 2, 3,
     "dere yatağına yakın, tatbikat yok"),
    ("Liman deposu", "fırtına", 2, 2, 2,
     "ahşap hangar, yılda bir tatbikat, telsizle uyarı"),
    ("Kıyı deposu", "kasırga", 1, 3, 2,
     "betonarme, tatbikat var, sığınak uzak"),
)
# (önlem, olay öncesi mi, tür)
_AFET_ONLEMLERI = (
    ("Depo çatısını güçlendirmek", True, "zarar azaltma"),
    ("Yılda iki tatbikat yapmak", True, "hazırlık"),
    ("Erken uyarı telsizini kurmak", True, "hazırlık"),
    ("Tehlike ve maruziyet haritasını güncellemek", True, "zarar azaltma"),
    ("Enkaz kaldırma ekibi çağırmak", False, "müdahale"),
    ("Hasar tespit formu doldurmak", False, "iyileştirme"),
    ("Geçici barınak kurmak", False, "müdahale"),
)


@bulmaca(ders="cografya", konu="afetten_korunma", kademeler=(9, 13), agirlik=1.4)
def risk_katmanlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Risk = tehlike x maruziyet x kırılganlık; korunma olaydan önce başlar."""
    depolar = [rastgele.choice(_AFET_TEHLIKELI)] + rastgele.sample(_AFET_DEPOLARI, 2)
    rastgele.shuffle(depolar)
    riskli = max(depolar, key=lambda d: d[2] * d[3] * d[4])
    en_tehlikeli = max(depolar, key=lambda d: d[2])
    yeni_risk = riskli[2] * riskli[3]
    eski_risk = yeni_risk * riskli[4]
    onlemler = (rastgele.sample([o for o in _AFET_ONLEMLERI if o[1]], 3)
                + rastgele.sample([o for o in _AFET_ONLEMLERI if not o[1]], 2))
    rastgele.shuffle(onlemler)
    onceki_indeks = [n for n, o in enumerate(onlemler) if o[1]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-risk-katmanlari",
        ders="cografya",
        baslik="Risk Katmanları",
        kademe=kademe,
        konu="afetten_korunma",
        kazanim="Tehlike, maruziyet, kırılganlık ve riski ayırma; afeti olayla değil "
                "sonucuyla tanımlama; korunmayı olay öncesi zarar azaltma ve hazırlık "
                "olarak planlama.",
        dikkat=7,
        brifing=(
            "Nakliye ağının üç deposu için katmanlı risk tablosu geldi.\n\n"
            "{} tabloyu tek sütuna indirdi: \"Tehlike varsa afet var. En "
            "yüksek tehlike puanı {} deposunda, orayı boşaltalım. Korunma "
            "dediğiniz de zaten enkaz kaldırma ekibidir; olaydan önce "
            "yapılacak bir şey yok.\"\n\n"
            "Depo boşaltılmadan önce tablonun öteki katmanlarına bakmamız "
            "gerekiyor."
        ).format(kisi, en_tehlikeli[0]),
        kanitlar=[
            Kanit("Katmanlı risk tablosu",
                  "\n".join("{} ({}): tehlike {}, maruziyet {}, kırılganlık {} ({})."
                            .format(ad, olay, teh, mar, kir, gerekce)
                            for ad, olay, teh, mar, kir, gerekce in depolar),
                  bedel=2, kritik=True),
            Kanit("Afet el kitabı",
                  "Tehlike, zarar verme ihtimali olan doğa olayıdır. Maruziyet, o "
                  "alandaki insan ve varlıktır. Kırılganlık, bunların zarar görme "
                  "kolaylığıdır. Risk üçünün birlikte sonucudur: risk = tehlike x "
                  "maruziyet x kırılganlık. Afet ise olay gerçekleşip toplumun kendi "
                  "imkânıyla baş edemeyeceği zarara yol açtığında ortaya çıkar. "
                  "Tehlike azaltılamaz; maruziyet ve kırılganlık azaltılabilir.",
                  bedel=1, kritik=True),
            Kanit("Güçlendirme teklifi",
                  "{} için yapı güçlendirme, tatbikat ve erken uyarı paketi "
                  "kırılganlık puanını {} seviyesinden 1 seviyesine indiriyor."
                  .format(riskli[0], riskli[4]),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir doğa olayı ne zaman afet olur?",
                dogru="Maruz kalanların baş edemeyeceği zarar doğduğunda",
                yanlislar={
                    "Tehlike varsa olay zaten afettir; tehlike ile afet aynı şeydir":
                        "Tehlike, risk ve afeti aynı saydın. Kimsenin olmadığı bir "
                        "çölde aynı sarsıntı afet değildir.",
                    "Yalnız büyüklüğü belli bir eşiği aşarsa":
                        "Büyüklük tek başına belirlemez: aynı büyüklük dayanıklı "
                        "yapıda hasarsız, kırılgan yapıda yıkıcı olur.",
                    "Haberlerde duyurulduğunda":
                        "Afet tanımı duyuruya değil, doğan zarara ve baş edebilme "
                        "gücüne bakar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tabloda en yüksek tehlike ile en yüksek risk aynı depoda "
                    "olmayabilir: tehlikesi yüksek ama kimsenin bulunmadığı, "
                    "sağlam ve tatbikatlı bir depo, tehlikesi orta ama kırılgan "
                    "bir depodan daha az risk taşır."
                ),
                ipuclari=[
                    "El kitabı riski hangi üç çarpanla tanımlıyor?",
                    "Aynı olay iki depoda neden farklı sonuç verir?",
                ],
                cozum="Risk = tehlike x maruziyet x kirilganlik; afet = bas edilemeyen zarar",
            ),
            secim_adimi(
                soru="Tabloya göre hangi depo en yüksek riski taşıyor?",
                dogru="{}: tehlike {}, maruziyet {}, kırılganlık {}; risk {}".format(
                     riskli[0], riskli[2], riskli[3], riskli[4], eski_risk),
                yanlislar={
                    "{}: tehlike puanı en yüksek olan depodur; en tehlikeli, en risklidir"
                    .format(en_tehlikeli[0]):
                        "Tehlikeyi riskle aynı saydın; risk üç katmanın çarpımıdır.",
                    "Üçü de aynı riski taşır; tehlike hepsinde var":
                        "Tehlike hepsinde var ama maruziyet ve kırılganlık farklı.",
                },
                rastgele=rastgele,
                aciklama="{}: üç katmanın çarpımı {} veriyor; tehlikesi daha yüksek "
                         "olan depo daha az risk taşıyabilir."
                         .format(riskli[0], eski_risk),
                ipuclari=["Her depo için üç puanı çarp."],
                puan=12,
            ),
            sayi_adimi(
                soru="Güçlendirme paketinden sonra {} deposunun risk puanı kaç olur?"
                     .format(riskli[0]),
                cevap=yeni_risk,
                aciklama="Tehlike ve maruziyet aynı kalır, kırılganlık 1 olur; "
                         "geriye tehlike ile maruziyetin çarpımı kalır: {}."
                         .format(yeni_risk),
                yaygin_yanlislar={
                    eski_risk: "Risk puanını değişmemiş saydın; kırılganlık azalınca "
                               "risk de azalır.",
                    0: "Tehlike ortadan kalkmaz; güçlendirme yalnız kırılganlığı düşürür.",
                },
                ipuclari=["Kırılganlık 1 olunca çarpımdan ne kalır?"],
                puan=12,
                cozum="tehlike ile maruziyeti çarp, kırılganlığı 1 al",
            ),
            coklu_adimi(
                soru="Hangi önlemler olay OLMADAN önce yapılan korunmadır? "
                     "(numaraları virgülle yaz)",
                secenekler=["{} ({})".format(o[0], o[2]) for o in onlemler],
                dogru_indeksler=onceki_indeks,
                aciklama="Zarar azaltma ve hazırlık olaydan önce yapılır; müdahale ve "
                         "iyileştirme olaydan sonra gelir.",
                ipuclari=["Önlem olayı beklemeden bugün yapılabiliyor mu?"],
                puan=12,
            ),
        ],
        kapanis=("Boşaltma kararı iptal edildi: en yüksek risk {} deposunda çıktı "
                 "({} puan); güçlendirme paketiyle {} puana iniyor ve olay öncesi "
                 "önlemler plana yazıldı.").format(riskli[0], eski_risk, yeni_risk),
        odul={"itibar": 5, "cevher": 1},
    )


# ==========================================================================
# EKONOMİK SEKTÖRLER: PAY TEK BAŞINA GELİŞMİŞLİK DEĞİLDİR (B37.18)
#
# Haritada aynı yanılgı ve aynı bağlamla 11 satır duruyor (7 kod, 9-12):
# ekonomi_cografi_faktor, ekonomi_sosyal_kultur, ekonomik_sektorler,
# hizmet_sektoru, turkiye_ekonomi_politikalari, turkiye_sektor_grafigi,
# turkiye_sektor_payi. `yaygin_yanlis`:
#
#   "Sektör payını tek başına gelişmişlik göstergesi saymak; faaliyet
#    türlerini karıştırmak."
#
# DÜZENEK: iki üssün iş dağılımı. Payların yanında kişi başına katma değer
# ve hizmete erişim de yazılı. Personel "sanayi payı yüksek olan üs daha
# gelişmiştir" diyor; oysa öteki üste kişi başına katma değer ve hizmet
# erişimi daha yüksek. Ayrıca üsteki işler sektörlere ayrılıyor.
#
# YANILGININ SAYISAL KARŞILIĞI: yüzdeyi doğrudan kişi sayısı saymak.
# ==========================================================================

# (iş, sektör)
_SEKTOR_ISLERI = (
    ("Cevher ocağında çıkarma", "birincil"),
    ("Tarlada hasat", "birincil"),
    ("Gölden balık avlama", "birincil"),
    ("Atölyede alet dövme", "ikincil"),
    ("Cevheri külçeye döküm", "ikincil"),
    ("Kereste biçme", "ikincil"),
    ("Nakliye kervanını sürme", "üçüncül"),
    ("Revirde hasta bakımı", "üçüncül"),
    ("Depoda satış kaydı tutma", "üçüncül"),
    ("Ölçüm verilerini çözümleme", "dördüncül"),
    ("Sefer rotasını planlama", "dördüncül"),
    ("Kurulda karar verme", "beşincil"),
)
# (üs, birincil %, ikincil %, üçüncül %, dördüncül+beşincil %,
#  kişi başına katma değer, hizmete erişim)
_SEKTOR_USLERI = (
    ("Demirkapı", 40, 35, 20, 5, 9, "revire üç saat, okuma yazma kursu yok"),
    ("Akliman", 20, 25, 40, 15, 15, "revir üste, kurslar haftalık"),
    ("Taşocağı", 55, 30, 10, 5, 7, "revire iki saat, kurs yok"),
    ("Gökdere", 25, 20, 40, 15, 14, "revir üste, kurslar iki haftada bir"),
)


@bulmaca(ders="cografya", konu="ekonomik_sektorler", kademeler=(9, 13), agirlik=1.4)
def sektor_dagilimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sektör payı yapıyı gösterir; gelişmişliği katma değer ve erişimle birlikte okuruz."""
    sanayili = rastgele.choice([u for u in _SEKTOR_USLERI if u[2] >= 30])
    hizmetli = rastgele.choice([u for u in _SEKTOR_USLERI if u[3] >= 40])
    toplam = rastgele.choice((120, 160, 200))
    hizmet_kisi = hizmetli[3] * toplam // 100
    isler = rastgele.sample(_SEKTOR_ISLERI, 5)
    rastgele.shuffle(isler)
    ucuncul_indeks = [n for n, i in enumerate(isler) if i[1] == "üçüncül"]
    if not ucuncul_indeks:                       # en az bir hizmet işi bulunsun
        isler[0] = rastgele.choice([i for i in _SEKTOR_ISLERI if i[1] == "üçüncül"])
        ucuncul_indeks = [0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-sektor-dagilimi",
        ders="cografya",
        baslik="Sektör Dağılımı",
        kademe=kademe,
        konu="ekonomik_sektorler",
        kazanim="Ekonomik faaliyetleri birincilden beşincile ayırma; sektör payını "
                "katma değer ve hizmete erişimle birlikte okuma; payı tek başına "
                "gelişmişlik göstergesi saymama.",
        dikkat=7,
        brifing=(
            "İki üssün iş dağılımı kurula sunulacak; her ikisinde de {} kişi "
            "çalışıyor.\n\n"
            "{} sıralamayı tek satırda yaptı: \"Sanayi payı yüksek olan üs "
            "gelişmiştir. {} sanayide önde, demek ki daha gelişmiş. Kalan "
            "sütunlara bakmaya gerek yok.\"\n\n"
            "Karar yazılmadan önce tablodaki öteki sütunlara bakmamız gerekiyor."
        ).format(toplam, kisi, sanayili[0]),
        kanitlar=[
            Kanit("Sektör payları",
                  "\n".join("{}: birincil %{}, ikincil %{}, üçüncül %{}, "
                            "dördüncül ve beşincil %{}."
                            .format(u[0], u[1], u[2], u[3], u[4])
                            for u in (sanayili, hizmetli)),
                  bedel=2, kritik=True),
            Kanit("Katma değer ve hizmet",
                  "\n".join("{}: kişi başına katma değer {} kredi; {}."
                            .format(u[0], u[5], u[6])
                            for u in (sanayili, hizmetli)),
                  bedel=2, kritik=True),
            Kanit("Üs iş listesi", "\n".join(i[0] for i in isler), bedel=1, kritik=True),
            Kanit("Ekonomi el kitabı",
                  "Birincil faaliyet doğadan doğrudan üretir (tarım, hayvancılık, "
                  "madencilik, balıkçılık). İkincil işler ham maddeyi işler. Üçüncül "
                  "hizmet sunar (ulaşım, ticaret, sağlık). Dördüncül bilgi üretir ve "
                  "çözümler; beşincil üst düzey karar verir. Sektör payları ekonominin "
                  "yapısını gösterir; gelişmişlik için kişi başına katma değer, "
                  "verimlilik ve hizmete erişim birlikte okunur.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Sektör payları bir yerin gelişmişliğini nasıl gösterir?",
                dogru="Tek başına göstermez; katma değer ve hizmete erişimle birlikte okunur",
                yanlislar={
                    "Sanayi payı yüksekse o yer daha gelişmiştir; fabrika her zaman refah demektir":
                        "Sektör payını tek başına gelişmişlik göstergesi saydın. "
                        "Tabloda sanayi payı yüksek üssün kişi başına katma değeri "
                        "daha düşük.",
                    "Tarım payı yüksekse o yer daha gelişmiştir; gıda üreten yer zengindir":
                        "Pay yalnız yapıyı gösterir; tek başına gelişmişlik demek değildir.",
                    "Yalnız toplam çalışan sayısına bakılır; kalabalık üs gelişmiştir":
                        "İki üste de aynı sayıda kişi çalışıyor; fark payda ve katma "
                        "değerde.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı sayıda çalışanla iki üs: sanayi payı yüksek olanda kişi "
                    "başına katma değer düşük ve revir uzak. Pay yapıyı anlatır, "
                    "refahı değil."
                ),
                ipuclari=[
                    "İki üste kişi başına katma değer nasıl?",
                    "El kitabı gelişmişlik için hangi ölçütleri sayıyor?",
                ],
                cozum="Pay -> yapi; kisi basina katma deger ve erisim -> gelismislik",
            ),
            coklu_adimi(
                soru="İş listesindeki hangi işler üçüncül (hizmet) sektördendir? "
                     "(numaraları virgülle yaz)",
                secenekler=[i[0] for i in isler],
                dogru_indeksler=ucuncul_indeks,
                aciklama="Üçüncül sektör mal üretmez, hizmet sunar: ulaşım, sağlık, ticaret.",
                ipuclari=["İş bir mal mı üretiyor, yoksa bir hizmet mi sunuyor?"],
                puan=12,
            ),
            sayi_adimi(
                soru="{} üssünde kaç kişi üçüncül sektörde çalışıyor?".format(hizmetli[0]),
                cevap=hizmet_kisi,
                aciklama="Toplam {} kişi, üçüncül pay %{}: {} x {} / 100 = {} kişi.".format(
                    toplam, hizmetli[3], toplam, hizmetli[3], hizmet_kisi),
                birim="kişi",
                yaygin_yanlislar={
                    hizmetli[3]: "Yüzdeyi doğrudan kişi sayısı saydın; önce toplamla çarp.",
                },
                ipuclari=["Toplam çalışanı yüzdeyle çarpıp yüze böl."],
                puan=12,
                cozum="{} x {} / 100".format(toplam, hizmetli[3]),
            ),
            secim_adimi(
                soru="Tabloya göre hangi üs daha gelişmiş sayılır?",
                dogru="{}: kişi başına katma değer ve hizmete erişim daha yüksek"
                      .format(hizmetli[0]),
                yanlislar={
                    "{}: sanayi payı daha yüksek, üretim gücü de daha fazla".format(sanayili[0]):
                        "Sektör payını tek başına gelişmişlik göstergesi saydın.",
                    "İkisi eşittir; çalışan sayıları aynı olduğuna göre gelişmişlik de aynı":
                        "Çalışan sayısı aynı olsa da kişi başına üretilen değer farklı.",
                },
                rastgele=rastgele,
                aciklama="{}: kişi başına {} kredi, {}. {}: kişi başına {} kredi, {}."
                         .format(hizmetli[0], hizmetli[5], hizmetli[6],
                                 sanayili[0], sanayili[5], sanayili[6]),
                ipuclari=["Kişi başına katma değer sütununu karşılaştır."],
                puan=12,
            ),
        ],
        kapanis=("Sıralama düzeltildi: pay sütunu yapıyı, katma değer ve erişim "
                 "sütunları gelişmişliği anlatıyor; {} üssü {} kişilik hizmet "
                 "kadrosuyla kayda geçti.").format(hizmetli[0], hizmet_kisi),
        odul={"itibar": 5, "erzak": 1},
    )


# ==========================================================================
# HAVA VE İKLİM: BİR HAFTA İKLİM DEĞİLDİR (B37.18)
#
# Haritada yedi kod (9. sınıf, 2018 ve 2026) aynı yanılgıyı taşıyor ve hepsi
# yükselti-sıcaklık görevine kaba eşlenmişti; o görev bu ayrımı ölçmüyor:
#
#   "Kısa süreli hava gözleminden iklim sonucu çıkarmak; yağış toplamı ile
#    sıcaklık ortalamasını aynı işlemle hesaplamak."
#   (iklim_sistemi_degisim) "Tek bir soğuk günü uzun dönemli ısınmanın
#    çürütülmesi saymak; senaryoyu kesin tahmin sanmak."
#
# DÜZENEK: istasyonun geçen haftalık defteri o ayın 30 yıllık ortalamasından
# belirgin soğuk. Yeni gelen personel haftadan iklim çıkarıyor, dünkü soğuk
# günü de ısınmanın çürütülmesi sayıyor. Yıllık ortalama sıcaklık 12 ayın
# ORTALAMASI, yıllık yağış 12 ayın TOPLAMI; iki işlem ayrı sorularda.
#
# SAYILAR: aylık sıcaklıkların toplamı 12'ye tam bölünür (ortalama tam sayı),
# yağış toplamı da 12'ye tam bölünür ki "ortalamasını aldın" teşhisi tam
# sayıyla eşleşsin. Üç on yılın ortalaması 30 yıllık ortalamaya eşittir.
# ==========================================================================

_AYLAR = ("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz",
          "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık")
# (tür, aylık ortalama sıcaklık °C, aylık yağış mm); sıcaklık toplamları 12'nin katı
_IKLIM_PROFILLERI = (
    ("kıyı", (9, 10, 12, 16, 20, 25, 28, 28, 24, 19, 14, 11),
     (120, 95, 70, 45, 25, 10, 5, 5, 20, 60, 100, 129)),
    ("iç kesim", (-3, -1, 4, 10, 15, 19, 23, 23, 18, 12, 4, -4),
     (35, 30, 35, 45, 50, 30, 10, 8, 12, 25, 30, 38)),
    ("nemli kıyı", (5, 5, 7, 11, 15, 19, 22, 22, 19, 15, 10, 6),
     (110, 90, 75, 60, 55, 50, 40, 45, 75, 115, 120, 125)),
)
_GECIS_AYLARI = (2, 3, 4, 8, 9, 10)          # Mart-Mayıs, Eylül-Kasım
_HAFTA_SAPMALARI = (2, -1, 1, 0, 1, -1)  # dünküyle (-2) toplamı 0: ortalama korunur
_DUN_SAPMASI = -2    # dün haftanın TEK en soğuk günü; yoksa "en düşük değer" anlatısı çelişir


def _iklim_kaydi(rastgele: random.Random):
    """Uyumlu bir kayıt üretir; teşhisler doğru cevaba ya da birbirine düşmez."""
    while True:
        tur, sicaklik, yagis = rastgele.choice(_IKLIM_PROFILLERI)
        kayma = rastgele.choice((-1, 0, 1))
        sicaklik = [t + kayma for t in sicaklik]
        katsayi = rastgele.choice((0.9, 1.0, 1.1, 1.2))
        yagis = [int(round(y * katsayi)) for y in yagis]
        yagis[yagis.index(max(yagis))] -= sum(yagis) % 12
        ay = rastgele.choice(_GECIS_AYLARI)
        sapma = rastgele.choice((5, 6, 7))
        hafta_ort = sicaklik[ay] - sapma
        gunluk = [hafta_ort + s for s in rastgele.sample(_HAFTA_SAPMALARI, 6)]
        gunluk.append(hafta_ort + _DUN_SAPMASI)
        hafta_yagis = [rastgele.choice((4, 6, 8, 10, 12, 14)) for _ in range(7)]
        yillik_ort = sum(sicaklik) // 12
        toplam_yagis = sum(yagis)
        sicaklik_teshisleri = {sum(sicaklik), hafta_ort, sicaklik[ay]}
        yagis_teshisleri = {toplam_yagis // 12, sum(hafta_yagis) * 52}
        if (yillik_ort not in sicaklik_teshisleri and len(sicaklik_teshisleri) == 3
                and toplam_yagis not in yagis_teshisleri):
            return (tur, sicaklik, yagis, ay, sapma, gunluk, hafta_yagis)


@bulmaca(ders="cografya", konu="hava_iklim_farki", kademeler=(9, 13), agirlik=1.4)
def istasyon_defteri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir haftalık hava gözlemi iklim değildir; iklim uzun yılların ortalamasıdır."""
    tur, sicaklik, yagis, ay, sapma, gunluk, hafta_yagis = _iklim_kaydi(rastgele)
    ay_adi = _AYLAR[ay]
    yillik_ort = sum(sicaklik) // 12
    toplam_yagis = sum(yagis)
    hafta_ort = sum(gunluk) // 7
    hafta_toplam = sum(hafta_yagis)
    dun = gunluk[-1]
    artis = rastgele.choice((0.3, 0.4, 0.5, 0.6))
    onyillar = (yillik_ort - artis, yillik_ort, yillik_ort + artis)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-istasyon-defteri",
        ders="cografya",
        baslik="İstasyon Defteri",
        kademe=kademe,
        konu="hava_iklim_farki",
        kazanim="Hava ile iklimi ayırma; yıllık ortalama sıcaklığı ortalamayla, "
                "yıllık yağışı toplamla hesaplama; tek günlük ölçümü uzun dönem "
                "eğilimiyle karıştırmama.",
        dikkat=7,
        brifing=(
            "Üs {} bir bölgede; sera fideleri geçen ay dikildi.\n\n"
            "{} bir hafta önce ekibe katıldı ve bütün haftayı soğuk ve yağmurlu "
            "geçirdi. Kurula şunu yazdı: \"Buranın iklimi soğuk ve yağışlı. "
            "Fideleri sökelim, soğuğa dayanıklı tohum ekelim. Hem dün {} "
            "ayının son yirmi yıldaki en düşük değeri ölçüldü; ısınma dedikleri "
            "şey de böylece çürüdü.\"\n\n"
            "Karar yazılmadan önce istasyonun defterine bakmamız gerekiyor."
        ).format(tur, kisi, ay_adi),
        kanitlar=[
            Kanit("Geçen haftanın defteri ({})".format(ay_adi),
                  "\n".join("{}. gün: ortalama {} °C, yağış {} mm".format(
                      n + 1, t, y) for n, (t, y) in enumerate(zip(gunluk, hafta_yagis)))
                  + "\nDün (7. gün) {} °C: {} ayının son yirmi yıldaki en düşük "
                    "günlük değeri.".format(dun, ay_adi),
                  bedel=1, kritik=True),
            Kanit("İklim kaydı (30 yıllık ortalama)",
                  "\n".join("{}: {} °C, {} mm".format(a, t, y)
                            for a, t, y in zip(_AYLAR, sicaklik, yagis)),
                  bedel=2, kritik=True),
            Kanit("On yıllık ortalamalar",
                  "1-10. yıl: yıllık ortalama {} °C\n11-20. yıl: {} °C\n"
                  "21-30. yıl: {} °C".format(*(sy(o) for o in onyillar)),
                  bedel=1, kritik=True),
            Kanit("Meteoroloji el kitabı",
                  "Hava, kısa süreli (saat, gün, hafta) atmosfer durumudur. İklim, "
                  "bir yerin uzun yıllar (en az 30 yıl) boyunca gözlenen ortalama "
                  "hava koşullarıdır. Yıllık ortalama sıcaklık 12 aylık ortalamaların "
                  "ortalamasıdır; yıllık yağış ise 12 aylık yağışların toplamıdır. "
                  "Tek bir günün ya da haftanın değeri iklim eğilimini ne kanıtlar "
                  "ne de çürütür; geçmiş eğilim de geleceği kesinleştirmez.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Geçen haftanın gözlemi bölgenin iklimi hakkında ne söyler?",
                dogru="Yalnız o haftanın havasını; iklim 30 yılın ortalamasıdır",
                yanlislar={
                    "Bir hafta boyunca soğuk ve yağışlıysa iklim de soğuk ve yağışlıdır":
                        "Kısa süreli hava gözleminden iklim sonucu çıkardın. Geçen "
                        "hafta, {} ayının 30 yıllık ortalamasından {} °C daha "
                        "soğuktu.".format(ay_adi, sapma),
                    "Bir hafta yetmez ama bir aylık gözlem iklimi belirler":
                        "Bir ay da kısa süreli bir gözlemdir; el kitabı iklim için "
                        "en az 30 yılın ortalamasını istiyor.",
                    "Hava ile iklim aynı şeydir; yalnızca adları farklıdır":
                        "Hava kısa süreli durumdur, iklim uzun yılların ortalaması.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Geçen haftanın ortalaması {} °C; iklim kaydında {} ortalaması "
                    "{} °C. Hafta ortalamanın {} °C altında kaldı: bu bir hava "
                    "olayı, iklimin kendisi değil."
                ).format(hafta_ort, ay_adi, sicaklik[ay], sapma),
                ipuclari=[
                    "Haftanın ortalamasını aynı ayın 30 yıllık ortalamasıyla karşılaştır.",
                    "El kitabı iklim için kaç yıllık gözlem istiyor?",
                ],
                cozum="Hafta -> hava; 30 yillik ortalama -> iklim",
            ),
            sayi_adimi(
                soru="İklim kaydına göre yıllık ortalama sıcaklık kaç °C?",
                cevap=yillik_ort,
                birim="°C",
                aciklama="12 ayın toplamı {} °C; 12 ile bölünce {} °C.".format(
                    sum(sicaklik), yillik_ort),
                yaygin_yanlislar={
                    sum(sicaklik): "12 ayı toplayıp bıraktın. Sıcaklık için toplam "
                                   "değil ortalama alınır: toplamı 12 ile böl.",
                    hafta_ort: "Geçen haftanın ortalamasını yazdın; o hava. Yıllık "
                               "ortalama iklim kaydındaki 12 aydan hesaplanır.",
                    sicaklik[ay]: "Yalnız {} ayının ortalamasını yazdın; yıllık "
                                  "ortalama 12 ayın hepsinden hesaplanır."
                                  .format(ay_adi),
                },
                ipuclari=["12 aylık sıcaklığı topla, 12 ile böl."],
                puan=12,
                cozum="toplam / 12",
            ),
            sayi_adimi(
                soru="İklim kaydına göre yıllık toplam yağış kaç mm?",
                cevap=toplam_yagis,
                birim="mm",
                aciklama="Yağış birikir: 12 ayın yağışı toplanır, {} mm.".format(
                    toplam_yagis),
                yaygin_yanlislar={
                    toplam_yagis // 12:
                        "Yağışın ortalamasını aldın; sıcaklıkla aynı işlemi yaptın. "
                        "Yıllık yağış 12 ayın toplamıdır.",
                    hafta_toplam * 52:
                        "Tek haftanın yağışını bütün yıla yaydın; bu kısa süreli "
                        "gözlemden iklim çıkarmak.",
                },
                ipuclari=["Sıcaklıktan farklı olarak yağış bölünmez; aylar toplanır."],
                puan=12,
                cozum="12 ayin toplami",
            ),
            secim_adimi(
                soru="Dünkü soğuk ölçüm, on yıllık ortalamalardaki ısınma için ne "
                     "anlama gelir?",
                dogru=("Tek günlük bir hava olayıdır; on yıllık {} -> {} °C "
                       "artışını çürütmez".format(sy(onyillar[0]), sy(onyillar[2]))),
                yanlislar={
                    "Isınma bitti; dün son yirmi yılın en soğuk günü yaşandı":
                        "Tek bir soğuk günü uzun dönemli ısınmanın çürütülmesi "
                        "saydın. Eğilim tek günle değil, on yıllık ortalamalarla "
                        "okunur.",
                    "Isınma her on yılda tam {} °C sürecek; sonraki on yılın "
                    "ortalaması kesin {} °C olur".format(
                        sy(artis), sy(onyillar[2] + artis)):
                        "Geçmiş eğilim bir kanıttır, kesin tahmin değil. Kayıt "
                        "geleceği kesinleştirmez; senaryolar olasılık verir.",
                    "Dünkü değer ile on yıllık ortalama aynı ağırlıkta; ikisinin "
                    "ortalaması alınmalı":
                        "Bir gün ile on yılın ortalaması aynı ölçekte değildir; "
                        "biri hava, öteki iklim kaydı.",
                },
                rastgele=rastgele,
                aciklama=("Üç on yılın ortalaması {}, {} ve {} °C: her on yılda {} "
                          "°C artış. Dünkü {} °C tek günün havası.").format(
                    sy(onyillar[0]), sy(onyillar[1]), sy(onyillar[2]), sy(artis), dun),
                ipuclari=["Eğilim tek bir günden mi, on yıllık ortalamalardan mı okunur?"],
                puan=12,
            ),
        ],
        kapanis=("Fideler yerinde kaldı: plan bir haftanın havasına değil, 30 "
                 "yıllık kayda göre yapıldı. Kurula yıllık ortalama {} °C ve "
                 "yıllık yağış {} mm yazıldı.").format(yillik_ort, toplam_yagis),
        odul={"itibar": 5, "erzak": 1},
    )
