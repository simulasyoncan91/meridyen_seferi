# -*- coding: utf-8 -*-
"""
Materyal köprüsü görevleri. (GOREVLER B28.15)

Üretim zincirinin çıkışı: elinde bir MATERYAL (titanyum çubuk, bakır tel...)
olan öğrenci, o materyalin değdiği dersin konusundan bir görev açabilir.
Her üretici `kopru:<materyal>` etiketiyle kaydedilir; hangi materyalin hangi
derse/konuya köprü kurduğu `oyun/motor/materyal.py` tablosundadır (teste bağlı).

§0: bunlar o dersin SIRADAN görevleridir -- materyal gerekmez, materyalsiz de
oynanır. Materyal yalnızca konuyu üretimin hikâyesine bağlar ve harcanmaz.

Sayılar tablolara bağlı: pirinç bileşimi madenler.py'den gelir; paslanmaz
çelikteki krom eşiği zincir.ARALIKLAR ile aynı değerdir (testle eşleşir).
"""
from __future__ import annotations

import random

from oyun.motor import madenler as M
from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import model_adimi, sayi_adimi, sy, yorum_adimi

KOPRU_ODUL = {"erzak": 4, "itibar": 3}


# ----------------------------------------------------------------- demir
@bulmaca(ders="fen", konu="yogunluk", kademeler=(5, 10),
         etiketler=("kopru:demir_cubuk",))
def kopru_demir_cubugu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Dökülen demir çubuğun yoğunluğu."""
    hacim = rastgele.choice([20, 25, 40, 50])
    kutle = round(7.8 * hacim, 1)
    return Bulmaca(
        kod="kopru-demir-cubugu", ders="fen", baslik="Dökülen Demir Çubuk",
        kademe=kademe, konu="yogunluk",
        kazanim="Yoğunluk = kütle / hacim; aynı maddenin her parçası aynı yoğunluğu verir.",
        brifing=(
            "Üssün ocağında külçeden ilk demir çubuk döküldü. Çit direği olarak "
            "kullanılacak ama depocu önce çubuğun gerçekten demir olup "
            "olmadığını yoğunluğundan doğrulamak istiyor."
        ),
        kanitlar=[
            Kanit("Terazi", "Çubuğun kütlesi: {} g".format(sy(kutle)), bedel=1, kritik=True),
            Kanit("Ölçü kabı", "Çubuğun hacmi: {} cm³".format(hacim), bedel=1, kritik=True),
            Kanit("Çizelge", "Saf demirin yoğunluğu yaklaşık 7,8 g/cm³.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yoğunluğu bulmak için hangi iki ölçüm gerekir?",
                dogru="Kütle ve hacim; yoğunluk ikisinin oranıdır.",
                yanlislar={
                    "Kütle ve uzunluk; yoğunluk ikisinin çarpımıdır.":
                        "Yoğunluk çarpım değil oran; ayrıca uzunluk tek başına hacim vermez.",
                    "Yalnızca kütle; ağır olan yoğundur.":
                        "Büyük bir tahta parçası küçük bir demir parçasından ağır olabilir; "
                        "kütle hacimle birlikte düşünülmeli.",
                },
                rastgele=rastgele,
                aciklama="Yoğunluk, birim hacmin kütlesidir: kütle ÷ hacim. İki ölçüm de gerekir.",
                ipuclari=["Birim hacimde ne kadar madde var?"], puan=14,
            ),
            sayi_adimi(
                soru="Çubuğun yoğunluğu kaç g/cm³?",
                cevap=7.8, birim="g/cm³", tolerans=0.05,
                aciklama="{} g ÷ {} cm³ = 7,8 g/cm³; saf demirin değeriyle uyuyor.".format(
                    sy(kutle), hacim),
                ipuclari=["Kütleyi hacme böl."], puan=12,
            ),
            yorum_adimi(
                soru="Çubuk ortadan ikiye kesilirse her yarının yoğunluğu ne olur?",
                dogru="Aynı kalır; yoğunluk madde miktarına bağlı değildir.",
                yanlislar={
                    "Yarıya iner; kütle yarıya indiği için yoğunluk da düşer.":
                        "Hacim de aynı oranda yarıya iner; oran değişmez.",
                    "İkiye katlanır; parçalar daha sıkı hale gelir.":
                        "Kesmek maddenin cinsini değiştirmez.",
                },
                rastgele=rastgele,
                aciklama="Kütle ve hacim birlikte yarıya iner; oranları, yani yoğunluk aynı kalır.",
                ipuclari=["Hem kütle hem hacim ne olur?"],
            ),
        ],
        kapanis="Çubuk demir olarak kayda geçti; depocu çit direğini yerine çaktı.",
        odul=dict(KOPRU_ODUL),
    )


# ----------------------------------------------------------------- bakır
@bulmaca(ders="fen", konu="elektrik", kademeler=(8, 13),
         etiketler=("kopru:bakir_tel",))
def kopru_bakir_teli(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bakır telden geçen akım."""
    gerilim = rastgele.choice([6, 12, 24])
    direnc = rastgele.choice([2, 3, 4, 6])
    akim = gerilim / direnc
    return Bulmaca(
        kod="kopru-bakir-teli", ders="fen", baslik="Bakır Telin Sınavı",
        kademe=kademe, konu="elektrik",
        kazanim="Metaller elektriği iletir; akım = gerilim / direnç.",
        brifing=(
            "Ocaktan çekilen bakır tel, atölyeye giden hattın ilk parçası. "
            "Elektrikçi teli bir aküye bağlayıp hattın bir bölümünü sınadı; "
            "ölçümler deftere yazıldı ama akımı kimse hesaplamadı."
        ),
        kanitlar=[
            Kanit("Akü", "Gerilim: {} V".format(gerilim), bedel=1, kritik=True),
            Kanit("Hat", "Hattın toplam direnci: {} Ω".format(direnc), bedel=1, kritik=True),
            Kanit("Not", "Hat bakır telden; plastik kılıf yalnızca dışını sarıyor.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Hat neden bakır telle kuruldu, plastik şeritle değil?",
                dogru="Bakır iyi iletkendir; plastik ise akımı geçirmez.",
                yanlislar={
                    "Bakır yalıtkandır; akımı hattın içinde tutar.":
                        "Yalıtkan akımı geçirmez; hat çalışmazdı.",
                    "Her madde eşit iyi iletir; bakır yalnızca daha ucuzdur.":
                        "Maddeler iletkenlikte çok farklıdır; metaller iyi, plastik kötü iletir.",
                },
                rastgele=rastgele,
                aciklama="Metallerde serbest elektronlar akımı taşır; plastikte böyle elektronlar yoktur.",
                ipuclari=["Hangisi içinden akım geçirir?"], puan=14,
            ),
            sayi_adimi(
                soru="Hattan kaç amper akım geçer?",
                cevap=akim, birim="A", tolerans=0.01,
                aciklama="I = V / R = {} / {} = {} A.".format(gerilim, direnc, sy(akim)),
                ipuclari=["Gerilimi dirence böl."], puan=12,
                cozum="Akım, gerilimin dirence oranıdır.",
            ),
        ],
        kapanis="Hat sağlam çıktı; elektrikçi bağlantıyı yaptı.",
        odul=dict(KOPRU_ODUL),
    )


# ----------------------------------------------------------------- çelik
@bulmaca(ders="fen", konu="basinc", kademeler=(6, 12),
         etiketler=("kopru:celik_kiris",))
def kopru_celik_kirisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Çelik kirişin zemine bindirdiği basınç."""
    kutle = rastgele.choice([400, 600, 800, 1000])      # kg
    alan = rastgele.choice([0.2, 0.4, 0.5])             # m²
    agirlik = kutle * 10
    basinc = agirlik / alan
    return Bulmaca(
        kod="kopru-celik-kirisi", ders="fen", baslik="Çelik Kirişin Ayağı",
        kademe=kademe, konu="basinc",
        kazanim="Basınç = kuvvet / yüzey alanı; yüzey küçülünce basınç artar (g = 10 N/kg).",
        brifing=(
            "Depo çatısının çelik kirişi yerine indirildi. Zemin ekibi kirişin "
            "ayağının altına konacak plakanın zemini ezip ezmeyeceğini bilmek "
            "istiyor; plakanın alanı ve kirişin kütlesi ölçüldü."
        ),
        kanitlar=[
            Kanit("Kiriş", "Kütle: {} kg (g = 10 N/kg alınacak)".format(kutle),
                  bedel=1, kritik=True),
            Kanit("Plaka", "Zemine değen alan: {} m²".format(sy(alan)), bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Zemine binen basıncı hangi bağıntı verir?",
                dogru="Basınç = ağırlık ÷ değen yüzey alanı.",
                yanlislar={
                    "Basınç = ağırlık × değen yüzey alanı.":
                        "Alan büyüdükçe basınç azalır; çarpım bunu göstermez.",
                    "Basınç = kütle ÷ kirişin toplam hacmi.":
                        "Bu yoğunluk; basınç kuvvetle ilgilidir.",
                },
                rastgele=rastgele,
                aciklama="Aynı kuvvet küçük alana yayılırsa basınç artar; bu yüzden bölünür.",
                ipuclari=["Kar ayakkabısı neden geniştir?"], puan=14,
            ),
            sayi_adimi(
                soru="Kirişin ağırlığı kaç newton?",
                cevap=agirlik, birim="N", tolerans=0.5,
                aciklama="W = m × g = {} × 10 = {} N.".format(kutle, agirlik),
                ipuclari=["Kütleyi 10 ile çarp."], puan=10,
            ),
            sayi_adimi(
                soru="Plakanın zemine bindirdiği basınç kaç pascal (N/m²)?",
                cevap=basinc, birim="Pa", tolerans=1,
                aciklama="P = {} ÷ {} = {} Pa.".format(agirlik, sy(alan), sy(basinc)),
                ipuclari=["Ağırlığı alana böl."], puan=12,
            ),
        ],
        kapanis="Plaka seçildi; kiriş zemini ezmeden yerine oturdu.",
        odul=dict(KOPRU_ODUL),
    )


# ------------------------------------------------------------------ tunç
@bulmaca(ders="tarih", konu="tarih_aritmetigi", kademeler=(6, 12),
         etiketler=("kopru:tunc_can",))
def kopru_tunc_cani(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tunç Çağı'nın sırası ve süresi (MÖ yıllarıyla çıkarma)."""
    baslangic = rastgele.choice([3000, 3200])
    bitis = 1200
    dokum = rastgele.choice([1800, 1600, 1500])
    sure = baslangic - bitis
    kalan = dokum - bitis
    return Bulmaca(
        kod="kopru-tunc-cani", ders="tarih", baslik="Tunç Çan ve Çağı",
        kademe=kademe, konu="tarih_aritmetigi",
        kazanim="MÖ yıllarında büyük sayı daha eskidir; iki MÖ yıl arası fark çıkarmayla bulunur.",
        brifing=(
            "Üssün çanı tunçtan döküldü. Tunç, bir çağa adını veren alaşım: "
            "bakıra kalay katılınca çıkan sert metal. Arşivci çanı çağıyla "
            "tanıtan bir levha hazırlıyor, ama yıl hesabı karıştı."
        ),
        kanitlar=[
            Kanit("Çağ tablosu", "Tunç Çağı (Anadolu, yaklaşık): MÖ {} - MÖ {}".format(
                baslangic, bitis), bedel=1, kritik=True),
            Kanit("Levha", "Levhadaki örnek çan yaklaşık MÖ {} yılında dökülmüş.".format(dokum),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="MÖ yıllarında hangi tarih daha eskidir?",
                dogru="Sayısı büyük olan; MÖ yıllar sayılırken geriye doğru azalır.",
                yanlislar={
                    "Sayısı küçük olan; küçük sayı her zaman daha önceye aittir.":
                        "MÖ yıllarda sayı Milat'a yaklaştıkça küçülür; küçük sayı daha yenidir.",
                    "İkisi de aynı zamandır; MÖ yıllar birbiriyle karşılaştırılamaz.":
                        "MÖ yıllar da bir zaman çizgisi oluşturur ve sıralanabilir.",
                },
                rastgele=rastgele,
                aciklama="Zaman çizgisi Milat'a doğru akar; büyük MÖ sayısı daha eski bir tarihtir.",
                ipuclari=["Milat'a doğru ilerlerken sayı büyür mü küçülür mü?"], puan=14,
            ),
            sayi_adimi(
                soru="Tunç Çağı yaklaşık kaç yıl sürmüştür?",
                cevap=sure, birim="yıl",
                aciklama="MÖ {} - MÖ {} = {} yıl (iki MÖ yılın farkı).".format(
                    baslangic, bitis, sure),
                ipuclari=["Büyük MÖ yıldan küçüğünü çıkar."], puan=12,
            ),
            sayi_adimi(
                soru="Çan dökülen yıldan Tunç Çağı'nın sonuna kaç yıl vardı?",
                cevap=kalan, birim="yıl",
                aciklama="MÖ {} - MÖ {} = {} yıl.".format(dokum, bitis, kalan),
                ipuclari=["Çanın yılından çağın bitiş yılını çıkar."], puan=12,
            ),
        ],
        kapanis="Levha yazıldı; çan çağıyla birlikte tanıtılacak.",
        odul=dict(KOPRU_ODUL),
    )


# ---------------------------------------------------------------- pirinç
@bulmaca(ders="matematik", konu="oran_oranti", kademeler=(5, 9),
         etiketler=("kopru:pirinc_musluk",))
def kopru_pirinc_musluk(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Pirinç musluktaki bakır ve çinko payı (tablodaki bileşim)."""
    bilesim = M.alasim("pirinc").bilesim
    cinko_orani = bilesim["cinko"]
    kutle = rastgele.choice([400, 800, 1200, 2000])
    cinko = round(kutle * cinko_orani)
    bakir = kutle - cinko
    bakir_yuzde = round(bilesim["bakir"] * 100)
    cinko_yuzde = round(cinko_orani * 100)
    return Bulmaca(
        kod="kopru-pirinc-musluk", ders="matematik", baslik="Muslukta Ne Kadar Çinko Var?",
        kademe=kademe, konu="oran_oranti",
        kazanim="Bir bütünün yüzde payını bulma; bütün, parçaların toplamıdır.",
        brifing=(
            "Su hattı için pirinçten bir musluk döküldü. Pirinç, bakır ile çinkonun "
            "karışımı. Depocu bir sonraki dökümde ne kadar çinko ayıracağını "
            "bilmek için bu muslukta kaç gram çinko olduğunu öğrenmek istiyor."
        ),
        kanitlar=[
            Kanit("Terazi", "Musluğun kütlesi: {} g".format(kutle), bedel=1, kritik=True),
            Kanit("Alaşım kartı", "Pirinç: kütlece %{} bakır, %{} çinko.".format(
                bakir_yuzde, cinko_yuzde), bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Çinkonun kütlesi nasıl bulunur?",
                dogru="Toplam kütlenin çinko yüzdesi kadarı alınır.",
                yanlislar={
                    "Toplam kütle, çinko yüzdesine bölünerek bulunur.":
                        "Bölme parçayı değil bütünü verir; payı bulmak için yüzdeyle çarpılır.",
                    "Toplam kütleden çinko yüzdesi çıkarılır.":
                        "Gram ile yüzde farklı birimdir; doğrudan çıkarılamaz.",
                },
                rastgele=rastgele,
                aciklama="Yüzde, bütünün yüzde bir parçasıdır; pay = bütün × yüzde ÷ 100.",
                ipuclari=["Bütünün ne kadarı çinko?"], puan=14,
            ),
            sayi_adimi(
                soru="Musluktaki çinko kaç gram?",
                cevap=cinko, birim="g",
                aciklama="{} g × {} ÷ 100 = {} g çinko.".format(kutle, cinko_yuzde, cinko),
                ipuclari=["Kütleyi yüzdeyle çarpıp yüze böl."], puan=12,
            ),
            sayi_adimi(
                soru="Aynı musluktaki bakır kaç gram?",
                cevap=bakir, birim="g",
                aciklama="{} - {} = {} g; yüzdeyle de {} × {} ÷ 100 = {} g.".format(
                    kutle, cinko, bakir, kutle, bakir_yuzde, bakir),
                ipuclari=["Parçaların toplamı bütündür."], puan=10,
            ),
        ],
        kapanis="Depocu çinko payını deftere yazdı.",
        odul=dict(KOPRU_ODUL),
    )


# ------------------------------------------------------------- alüminyum
@bulmaca(ders="fen", konu="yuzme_batma", kademeler=(5, 9),
         etiketler=("kopru:aluminyum_levha",))
def kopru_aluminyum_levha(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Alüminyum levha batar; kutu biçimi verilince yüzebilir."""
    hacim = rastgele.choice([800, 1000, 1500, 2000])        # kutunun dış hacmi, cm³
    kutle = rastgele.choice([300, 400, 500, 600])           # levhanın kütlesi, g
    ort = kutle / hacim
    yuzer = ort < 1.0
    dogru = ("Yüzer; ortalama yoğunluk suyun yoğunluğundan küçük." if yuzer
             else "Batar; ortalama yoğunluk suyunkinden küçük değil.")
    yanlis = ("Batar; alüminyum suyun yoğunluğundan daha büyüktür." if yuzer
              else "Yüzer; kutu biçimi verilen madde her zaman yüzer.")
    return Bulmaca(
        kod="kopru-aluminyum-levha", ders="fen", baslik="Levhadan Tekne",
        kademe=kademe, konu="yuzme_batma",
        kazanim="Ortalama yoğunluğu suyunkinden küçük cisim yüzer; biçim ortalama yoğunluğu değiştirir.",
        brifing=(
            "Ocaktan çıkan alüminyum levha suya atılınca battı. Teknisyen levhayı "
            "içi boş, üstü açık bir kutu biçiminde kıvırırsa yüzüp yüzmeyeceğini "
            "merak ediyor. Kutunun içi hava; havanın kütlesi hesapta yok sayılacak."
        ),
        kanitlar=[
            Kanit("Levha", "Kütle: {} g (kıvırınca değişmez)".format(kutle), bedel=1, kritik=True),
            Kanit("Kutu", "Kıvrılmış kutunun kapladığı toplam hacim: {} cm³".format(hacim),
                  bedel=1, kritik=True),
            Kanit("Çizelge", "Suyun yoğunluğu: 1 g/cm³. Alüminyum: 2,7 g/cm³.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Düz levha neden batar, kutu biçimi ise yüzebilir?",
                dogru="Kutu aynı kütleyi büyük hacme yayar, ortalama yoğunluk düşer.",
                yanlislar={
                    "Kıvırmak levhanın kütlesini azaltır, bu yüzden yoğunluk düşer.":
                        "Biçim vermek kütleyi değiştirmez; değişen hacimdir.",
                    "Alüminyum kıvrılınca kendisi daha az yoğun bir maddeye dönüşür.":
                        "Madde aynı; ama kutu içindeki hava hacme katıldığı için ORTALAMA yoğunluk düşer.",
                },
                rastgele=rastgele,
                aciklama="Gemiler de aynı fikirle yüzer: çelik, içi boş bir gövdeye verilir.",
                ipuclari=["Aynı kütle daha büyük bir hacme dağılırsa oran ne olur?"], puan=14,
            ),
            sayi_adimi(
                soru="Kutunun ortalama yoğunluğu kaç g/cm³?",
                cevap=ort, birim="g/cm³", tolerans=0.005,
                aciklama="{} g ÷ {} cm³ = {} g/cm³.".format(kutle, hacim, sy(ort)),
                ipuclari=["Levhanın kütlesini kutunun toplam hacmine böl."], puan=12,
            ),
            yorum_adimi(
                soru="Bu kutu suda ne yapar?",
                dogru=dogru,
                yanlislar={
                    yanlis: "Karar, ortalama yoğunluğun suyun yoğunluğuyla karşılaştırılmasıyla verilir.",
                    "Askıda kalır; ortalama yoğunluğu suyunkine eşit.":
                        "Askıda kalmak için ortalama yoğunluk suyunkine eşit olmalı; bulduğun değer farklı.",
                },
                rastgele=rastgele,
                aciklama="Ortalama yoğunluk {} g/cm³; suyun yoğunluğu 1 g/cm³ ({}).".format(
                    sy(ort), "daha küçük, kutu yüzer" if yuzer
                    else "daha büyük ya da eşit, kutu batar"),
                ipuclari=["Bulduğun değeri suyun yoğunluğuyla karşılaştır."],
            ),
        ],
        kapanis="Teknisyen levhayı kıvırmadan önce hesabı deftere yazdı.",
        odul=dict(KOPRU_ODUL),
    )


# ------------------------------------------------------ paslanmaz çelik
KROM_ESIGI = 0.105          # zincir.ARALIKLAR["paslanmaz_celik"] ile aynı


@bulmaca(ders="kimya", konu="korozyon", kademeler=(9, 13),
         etiketler=("kopru:paslanmaz_levha",))
def kopru_paslanmaz_levha(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Krom eşiği: neden paslanmıyor, en az ne kadar krom gerekir."""
    kutle = rastgele.choice([40, 80, 120, 200])             # kg alaşım
    en_az = round(kutle * KROM_ESIGI, 2)
    return Bulmaca(
        kod="kopru-paslanmaz-levha", ders="kimya", baslik="Paslanmayan Tezgâh",
        kademe=kademe, konu="korozyon",
        kazanim="Paslanmaz çelik yüzeyde koruyucu bir krom oksit tabakası kurar; bunun için yeterli krom (kütlece en az yaklaşık %10,5) gerekir.",
        brifing=(
            "Laboratuvar tezgâhı için paslanmaz çelik levha dökülecek. Sıradan "
            "çelik nemli ortamda pas tutuyor; levhanın tutmaması için alaşımda "
            "yeterli krom olmalı. Döküm ustası, belirli bir alaşım kütlesi için "
            "en az ne kadar krom katılacağını soruyor."
        ),
        kanitlar=[
            Kanit("Döküm", "Hazırlanacak alaşımın toplam kütlesi: {} kg".format(kutle),
                  bedel=1, kritik=True),
            Kanit("Standart notu", "Paslanmaz sayılmak için kütlece en az %10,5 krom gerekir.",
                  bedel=1, kritik=True),
            Kanit("Bileşim kartı", "Tipik paslanmaz çelik: demir, krom ve nikel karışımı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Krom, çeliğin paslanmasını nasıl önler?",
                dogru="Yüzeyde görünmez bir krom oksit tabakası kurup demiri korur.",
                yanlislar={
                    "Krom, demirle tepkimeye girip demiri tamamen ortadan kaldırır.":
                        "Alaşımda demir yerinde kalır; krom yüzeyde koruyucu katman kurar.",
                    "Krom çeliği sürekli ısıtarak yüzeydeki nemi uzaklaştırır.":
                        "Koruma bir ısıtmadan değil, yüzeyde kendiliğinden oluşan oksit tabakasından gelir.",
                },
                rastgele=rastgele,
                aciklama="Tabaka çizilse bile havadaki oksijenle yeniden oluşur; bu yüzden koruma kalıcıdır.",
                ipuclari=["Pas, oksijenin demire ulaşmasıyla başlar; ulaşamazsa?"], puan=14,
            ),
            sayi_adimi(
                soru="Bu döküm paslanmaz sayılsın diye en az kaç kg krom gerekir?",
                cevap=en_az, birim="kg", tolerans=0.01,
                aciklama="{} kg × 10,5 ÷ 100 = {} kg.".format(kutle, sy(en_az)),
                ipuclari=["Toplam kütlenin eşik yüzdesi kadarı krom olmalı."], puan=12,
            ),
        ],
        kapanis="Usta kromu tarttı; levha tezgâha gitti.",
        odul=dict(KOPRU_ODUL),
    )


# -------------------------------------------------------------- titanyum
@bulmaca(ders="biyoloji", konu="destek_hareket", kademeler=(10, 13),
         etiketler=("kopru:titanyum_cubuk",))
def kopru_titanyum_cubugu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Titanyum implant: biyouyum ve çubuktan kaç parça çıkar."""
    parca = rastgele.choice([6, 10, 12, 15])                # bir implant vidasının kütlesi, g
    cubuk = 300
    adet = cubuk // parca
    return Bulmaca(
        kod="kopru-titanyum-cubugu", ders="biyoloji", baslik="Kemiğe Kaynaşan Metal",
        kademe=kademe, konu="destek_hareket",
        kazanim="Titanyum vücutla uyumludur; kemik dokusu implantın yüzeyine tutunur ve destek sistemi onu taşır.",
        brifing=(
            "Revir, kırık bir kemiği sabitlemek için titanyum çubuktan implant "
            "vidası yontmak istiyor. Doktor neden çelik ya da bakır değil de "
            "titanyum seçildiğini ve çubuktan kaç vida çıkacağını soruyor."
        ),
        kanitlar=[
            Kanit("Çubuk", "Titanyum çubuğun kütlesi: {} g".format(cubuk), bedel=1, kritik=True),
            Kanit("Vida", "Bir implant vidası: {} g titanyum".format(parca), bedel=1, kritik=True),
            Kanit("Doktor notu", "Vida yıllarca kemik içinde kalacak; vücut onu yabancı saldırgan "
                  "saymamalı ve metal vücut sıvısında paslanmamalı.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Titanyum neden implant için iyi bir seçimdir?",
                dogru="Vücutla uyumludur, paslanmaz ve kemik yüzeyine tutunabilir.",
                yanlislar={
                    "Titanyum kemikten daha yumuşaktır, bu yüzden kemik onu emer.":
                        "Kemik metali yemez; seçim, vücutla uyum ve korozyona dayanıklılıktan gelir.",
                    "Titanyum vücut sıvısında hızla çözünüp kemiği besler.":
                        "Çözünseydi implant zayıflardı; titanyum vücut sıvısında dayanıklıdır.",
                },
                rastgele=rastgele,
                aciklama="Kemik hücreleri titanyum yüzeyine yapışıp onunla kaynaşır; "
                         "bu sayede implant destek sisteminin bir parçası gibi yük taşır.",
                ipuclari=["Vücut için hangisi daha önemli: ucuzluk mu, uyum mu?"], puan=14,
            ),
            sayi_adimi(
                soru="Bu çubuktan kaç vida yontulabilir?",
                cevap=adet, birim="vida",
                aciklama="{} g ÷ {} g = {} vida.".format(cubuk, parca, adet),
                ipuclari=["Çubuğun kütlesi vidanın kütlesine kaç kez sığar?"], puan=12,
            ),
        ],
        kapanis="Revir vidaları ayırdı; doktor ameliyat planını yazdı.",
        odul=dict(KOPRU_ODUL),
    )
