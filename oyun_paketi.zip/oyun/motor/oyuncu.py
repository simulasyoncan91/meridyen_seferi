# -*- coding: utf-8 -*-
"""
Oyuncuyu tanımak: takma ad ve oyuncu anketi.

KULLANICININ KARARLARI (10 Eylül 2026)
--------------------------------------
* "Başlangıçta öğrencilere birkaç soru soralım ve öğrencinin hangi tür bir
  oyuncu olduğunu öğrenelim. Ondan sonra seviyeler rütbe olur."
* Anketin biçimini kullanıcı kendisi tasarladı: önce "en çok hangi tür
  oyunları oynarsın?" (otomasyon, hayatta kalma, FPS, simülasyon), sonra
  seçilen türe göre dallanan sorular -- FPS seçene "hangilerini
  oynarsın?", otomasyon seçene "bir üretimde yaptığın şeyleri sırala".
  Hem FPS hem hayatta kalma seçen için ayrı bir birleşim sorusu YOK.
  Toplam beş soru.
* "Bir oyuncu için takma ad kendi kimliğidir."

ANKET ETİKET VERMEZ -- BUNU KULLANICININ KENDİ CEVAPLARI GÖSTERDİ
-----------------------------------------------------------------
İlk taslakta kullanıcıya dört zorunlu seçimli soru soruldu. Dördünde de
seçimi reddetti: "multi ise önce arkadaş sonra sıralama, tek isem keşif
sonra kurulma", "hepsi beni oyunda tutar", "kaç kere zorlandığıma bağlı",
"hepsi". Yani oyuncunun TEK tipi yok, tipi bağlama göre değişiyor ve
tekrar eden zorlanmayla tırmanıyor.

Bu yüzden anket "sen şusun" demez. Katmanlardan (rütbe, rozet, zaman
seferi, tesis) hangisinin ÖNCE gösterileceğine dair bir tohum kurar; oyun
oynandıkça öğrencinin gerçekten nereye gittiğini sayar ve sırayı ona göre
günceller. Zaten okulda yanlış etiketlendiğini düşünen bir çocuğa oyunun
ilk yaptığı şey onu yeniden etiketlemek olamaz.

HİÇBİR ŞEY KİLİTLENMEZ (§0, §3)
-------------------------------
Anket menüdeki katmanların SIRASINI ve üssün açılış satırını değiştirir.
Madde gizlemez, ödül miktarı değiştirmez, içerik açıp kapatmaz.
Sıralamak kişiselleştirmedir; gizlemek kapıdır. Yanlış cevabın bedeli
yoktur, çünkü cevabın kilitlediği bir şey yoktur.

"Sosyal" eğilim sayılır ama ona bir katman VAAT EDİLMEZ: gerçek ittifak
bir ağ servisi istiyor ve 14-15 Eylül pilotunda yok.
"""
from __future__ import annotations

import random
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import terminal as ekran

# ============================================================== takma ad

EN_KISA = 3
EN_UZUN = 16
_IZINLI_ISARETLER = " _-."

# Küfür denetimi için katlama: Türkçe harfler ve rakamla yazılan harfler
# (0 -> o, 3 -> e) aynı sayılır. YALNIZCA DENETİM İÇİN; saklanan ad
# öğrencinin yazdığı gibidir.
_KATLAMA = str.maketrans({
    "ı": "i", "İ": "i", "ş": "s", "Ş": "s", "ç": "c", "Ç": "c",
    "ğ": "g", "Ğ": "g", "ö": "o", "Ö": "o", "ü": "u", "Ü": "u",
    "â": "a", "î": "i", "û": "u",
    "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t",
    "@": "a", "$": "s",
})

# Bitişik yazımda da aranan kökler. BEŞ HARFTEN KISA KÖK BURAYA GİRMEZ:
# "pic" gibi bir kök "Epic" takma adını reddeder ve oyuncular bu tür
# İngilizce adları sıkça seçer.
YASAK_KOKLER = (
    "orospu", "siktir", "sikerim", "sikeyim", "sikis", "yarrak", "amcik",
    "amina", "pezevenk", "kahpe", "gavat", "surtuk", "kaltak", "yavsak",
    "serefsiz", "gotveren", "kerhane",
)
# Yalnızca TEK BAŞINA bir sözcük olarak yazıldığında reddedilenler.
YASAK_SOZCUKLER = frozenset((
    "sik", "am", "amk", "amq", "aq", "oc", "pic", "got", "ibne", "bok",
    "pust",
))

# Bu denetim ilk savunma hattı, tek savunma değil: öğretmen gerçek adı
# her zaman görür, yani takma ad anonim değil PSEUDONİMDİR. Kötüye
# kullanımın bir sahibi vardır.

ONERI_SIFATLARI = ("Sessiz", "Demir", "Çelik", "Kızıl", "Kara", "Gri",
                   "Poyraz", "Yalın")
ONERI_ISIMLERI = ("Kartal", "Şahin", "Atmaca", "Kurt", "Tilki", "Pars",
                  "Kâşif", "İzci")


def _katla(metin: str) -> str:
    return metin.translate(_KATLAMA).lower()


def _sozcukler(metin: str) -> List[str]:
    parcalar, simdiki = [], []
    for harf in metin:
        if harf.isalpha():
            simdiki.append(harf)
        elif simdiki:
            parcalar.append("".join(simdiki))
            simdiki = []
    if simdiki:
        parcalar.append("".join(simdiki))
    return parcalar


def yasakli_mi(metin: str) -> bool:
    katli = _katla(metin)
    bitisik = "".join(h for h in katli if h.isalpha())
    if any(kok in bitisik for kok in YASAK_KOKLER):
        return True
    return any(sozcuk in YASAK_SOZCUKLER for sozcuk in _sozcukler(katli))


def takma_ad_denetle(ham: str) -> Tuple[str, Optional[str]]:
    """(temizlenmiş ad, sorun). Sorun None ise ad kullanılabilir."""
    temiz = " ".join((ham or "").split())
    if len(temiz) < EN_KISA:
        return temiz, "Takma ad en az {} karakter olmalı.".format(EN_KISA)
    if len(temiz) > EN_UZUN:
        return temiz, "Takma ad en fazla {} karakter olabilir.".format(EN_UZUN)
    if any(not (h.isalnum() or h in _IZINLI_ISARETLER) for h in temiz):
        return temiz, "Yalnızca harf, rakam, boşluk ve _ - . kullanılabilir."
    if not any(h.isalpha() for h in temiz):
        return temiz, "Takma adda en az bir harf olmalı."
    if yasakli_mi(temiz):
        return temiz, ("Bu takma ad olmaz; sınıfta herkes görecek. "
                       "Başka bir ad seç.")
    return temiz, None


def oneriler(tohum: int, adet: int = 6) -> List[str]:
    """Oyunun evreninden takma ad önerileri. Aynı tohum aynı öneriler."""
    hepsi = ["{} {}".format(s, i) for s in ONERI_SIFATLARI
             for i in ONERI_ISIMLERI]
    random.Random(tohum).shuffle(hepsi)
    return hepsi[:adet]


def _onerilerden_sec(durum) -> str:
    tur = 0
    while True:
        adlar = oneriler(durum.tohum + tur, 6)
        secenekler = [(ad, "") for ad in adlar]
        secenekler += [("Başka öneriler", ""), ("Kendim yazacağım", "")]
        secim = ekran.menu("ÖNERİLER", secenekler)
        if secim < len(adlar):
            return adlar[secim]
        if secim == len(adlar):
            tur += 1
            continue
        return ""


def takma_ad_sec(durum) -> str:
    """Takma adı sorar, denetler, durum'a yazar. Kaydetmez."""
    ekran.yaz()
    ekran.kutu(
        "Sınıfta seni bu adla tanıyacaklar. Gerçek adını yalnızca "
        "öğretmenin görür; karnende de gerçek adın yazar.\n\n"
        "Öğretmenin takma adını görmek isterse bu sana SÖYLENİR: kim "
        "gördü, hangi dersten, ne zaman.",
        "TAKMA ADIN", "acik_cam")
    ekran.yaz("Kendi oyuncu adın varsa onu yaz. Yoksa Enter'a bas, "
              "öneri getireyim.", "gri")
    for _ in range(5):
        ham = ekran.sor("Takma ad:", "")
        if not ham.strip():
            secilen = _onerilerden_sec(durum)
            if secilen:
                durum.takma_ad = secilen
                ekran.basari("Takma adın: " + secilen)
                return secilen
            continue
        temiz, sorun = takma_ad_denetle(ham)
        if sorun:
            ekran.hata(sorun)
            continue
        if ekran.ayni_ad(temiz, durum.ad) and not ekran.onayla(
                "Bu senin gerçek adın; sınıf seni hemen tanır. "
                "Yine de bu olsun mu?", False):
            continue
        durum.takma_ad = temiz
        ekran.basari("Takma adın: " + temiz)
        return temiz
    # Beş denemede olmadıysa bir öneri ata; öğrenci burada takılıp
    # kalmasın. Ayarlardan her an değiştirebilir.
    durum.takma_ad = oneriler(durum.tohum, 1)[0]
    ekran.bilgi("Şimdilik takma adın: {}. Teçhizat ve Ayarlar'dan "
                "değiştirebilirsin.".format(durum.takma_ad))
    return durum.takma_ad


# ================================================================ anket

EGILIMLER = ("rekabet", "kurma", "kesif", "toplama", "sosyal")

# (kod, ekranda, örnekler)
TURLER = [
    ("otomasyon", "Otomasyon",
     "Factorio, Satisfactory, Minecraft'ta makine kurmak"),
    ("hayatta_kalma", "Hayatta kalma",
     "Minecraft, Rust, Don't Starve, The Forest"),
    ("rekabetci", "FPS / rekabetçi", "Valorant, CS, LoL, PUBG, Fortnite"),
    ("simulasyon", "Simülasyon",
     "şehir kurma, çiftlik, işletme, araç, The Sims"),
]
HICBIRI = ("Pek oyun oynamam", "sorun değil; seni oynarken tanırız")

# Türü seçmek de bir şey söylüyor ama takip sorularından azını.
TUR_AGIRLIGI = {
    "otomasyon": {"kurma": 1.0},
    "hayatta_kalma": {"kesif": 0.5, "kurma": 0.5},
    "rekabetci": {"rekabet": 1.0},
    "simulasyon": {"kurma": 0.5, "toplama": 0.5},
}

# Birinci sorudan sonra kaç takip sorusu. Kullanıcı: "5 soru ile bunu
# belirleyeceğiz" -> 1 tür sorusu + 4 takip.
TAKIP_SORU_SAYISI = 4

# Her seçenek: (ekranda, açıklama, eğilim ağırlıkları, kayıt kodu).
# Tip: "tek" (menü), "coklu" (birden çok), "sirali" (sırayla yaz).
SORULAR: Dict[str, List[Dict[str, Any]]] = {
    "otomasyon": [
        {"kod": "uretim_sirasi", "tip": "sirali",
         "metin": "Bir üretim hattı kurarken ne yaparsın? Önce yaptığından "
                  "başlayarak sırala.",
         "secenekler": [
             ("Kaynak hesaplarım", "dakikada kaç tane lazım, kaç makine eder",
              {"kurma": 2}, "ileri"),
             ("Kaynakları tersten hesaplarım",
              "hedefi koyar, girdileri geriye doğru bulurum",
              {"kurma": 2}, "tersten"),
             ("Girdilere bakıp kafadan belirlerim", "hesap yok, göz kararı",
              {"kurma": 1, "kesif": 1}, "kestirme"),
             ("Doğaçlarım (spagetti)",
              "önce kurarım, çalışmazsa düzeltirim",
              {"kesif": 2}, "dogaclama"),
         ]},
        {"kod": "yavas_fabrika", "tip": "tek",
         "metin": "Fabrikan çalışıyor ama yavaş. İlk ne yaparsın?",
         "secenekler": [
             ("Darboğazı bulurum", "hangi makine bekletiyor, onu çözerim",
              {"kurma": 2}, "darbogaz"),
             ("Yenisini daha büyük kurarım", "eskisiyle uğraşmam",
              {"kurma": 1, "rekabet": 1}, "buyut"),
             ("Haritada yeni kaynak ararım", "sorun hammadde azlığıdır",
              {"kesif": 2}, "kaynak_ara"),
             ("Başkasının tasarımına bakarım",
              "iyi bir çözüm varsa neden baştan icat edeyim",
              {"sosyal": 2}, "bak"),
         ]},
        {"kod": "otomasyon_mutluluk", "tip": "tek",
         "metin": "Bir otomasyon oyununda seni en çok ne mutlu eder?",
         "secenekler": [
             ("Her şeyin kusursuz aktığını izlemek", "",
              {"kurma": 2}, "akis"),
             ("Bütün teknoloji ağacını açmak", "", {"toplama": 2}, "agac"),
             ("En büyük üretimi yapmak", "sayılar büyüdükçe",
              {"rekabet": 2}, "buyuk"),
             ("Yeni bir bölgeye geçmek", "", {"kesif": 2}, "bolge"),
         ]},
        {"kod": "ortak_harita", "tip": "tek",
         "metin": "Arkadaşınla aynı haritada oynuyorsunuz. Sen ne yaparsın?",
         "secenekler": [
             ("Planı ben yaparım", "", {"kurma": 1, "sosyal": 1}, "plan"),
             ("Kaynak toplarım", "", {"toplama": 1, "kesif": 1}, "topla"),
             ("Ondan daha çok üretmeye çalışırım", "",
              {"rekabet": 2}, "yaris"),
             ("Kendi köşemde kendi hattımı kurarım", "",
              {"kurma": 2}, "kose"),
         ]},
    ],
    "hayatta_kalma": [
        {"kod": "ilk_gece", "tip": "tek",
         "metin": "İlk gece geliyor. Ne yaparsın?",
         "secenekler": [
             ("Hemen barınak kurarım", "", {"kurma": 2}, "barinak"),
             ("Karanlık basmadan etrafı keşfederim", "",
              {"kesif": 2}, "kesif"),
             ("Olabildiğince kaynak toplarım", "", {"toplama": 2}, "topla"),
             ("Yakındaki oyunculara katılırım", "", {"sosyal": 2}, "katil"),
         ]},
        {"kod": "oyun_oturdu", "tip": "tek",
         "metin": "Hayatta kaldın, oyun oturdu. Şimdi ne yaparsın?",
         "secenekler": [
             ("Üssümü büyütür, güçlendiririm", "", {"kurma": 2}, "us"),
             ("Haritanın bilinmeyen yerine giderim", "",
              {"kesif": 2}, "bilinmeyen"),
             ("Her eşyadan birini toplarım", "",
              {"toplama": 2}, "koleksiyon"),
             ("Başka oyuncuların üssüne giderim", "baskın",
              {"rekabet": 2}, "baskin"),
         ]},
        # Bu soru kullanıcının kendi cevabından geldi: "kaç kere
        # zorlandığıma bağlı". Cevap `zorlaninca` olarak ayrıca saklanıyor;
        # §0'ın "zorlanma tekrarlandıkça destek artar" ilkesine bir gün
        # öğrencinin kendi tercihiyle bağlanabilsin diye.
        {"kod": "ucuncu_deneme", "tip": "tek",
         "metin": "Aynı yerde ikinci kez öldün. Üçüncüde ne yaparsın?",
         "secenekler": [
             ("Aynı yoldan, daha dikkatli", "", {"rekabet": 1}, "israr"),
             ("Başka bir yol denerim", "", {"kesif": 1}, "baska_yol"),
             ("Hazırlanıp güçlenip dönerim", "",
              {"kurma": 1, "toplama": 1}, "hazirlan"),
             ("Birine sorar ya da izlerim", "", {"sosyal": 1}, "sor"),
         ]},
        {"kod": "seni_tutan", "tip": "tek",
         "metin": "Hangisi seni oyunda tutar?",
         "secenekler": [
             ("Kurduğum şeyi büyütmek", "", {"kurma": 2}, "buyutmek"),
             ("Görmediğim yerler", "", {"kesif": 2}, "yerler"),
             ("Eksik kalan koleksiyon", "", {"toplama": 2}, "eksik"),
             ("Rakibimi geçmek", "", {"rekabet": 2}, "rakip"),
         ]},
    ],
    "rekabetci": [
        {"kod": "hangi_oyunlar", "tip": "coklu",
         "metin": "Hangilerini oynarsın?",
         "secenekler": [
             ("Valorant", "", {"rekabet": 1, "sosyal": 1}, "valorant"),
             ("CS (Counter-Strike)", "", {"rekabet": 1, "sosyal": 1}, "cs"),
             ("LoL", "", {"rekabet": 1, "sosyal": 1}, "lol"),
             ("PUBG / Fortnite", "battle royale",
              {"rekabet": 1, "kesif": 1}, "br"),
             ("Başka bir rekabetçi oyun", "", {"rekabet": 1}, "diger"),
         ]},
        {"kod": "takimda", "tip": "tek",
         "metin": "Takımda genelde ne yaparsın?",
         "secenekler": [
             ("Öne ben girerim", "ilk çatışmaya", {"rekabet": 2}, "giris"),
             ("Takımı yönetirim", "çağrıyı ben yaparım",
              {"sosyal": 1, "kurma": 1}, "lider"),
             ("Destek olurum", "takım kazansın yeter",
              {"sosyal": 2}, "destek"),
             ("Haritayı ve açıları iyi bilirim", "nereden gelecekler",
              {"kesif": 2}, "harita"),
         ]},
        {"kod": "rank_dustu", "tip": "tek",
         "metin": "Rank'ın düştü. Ne yaparsın?",
         "secenekler": [
             ("Hemen tekrar oynar, geri alırım", "", {"rekabet": 2}, "hemen"),
             ("Maçımı izler, hatamı bulurum", "",
              {"kurma": 1, "rekabet": 1}, "analiz"),
             ("Ara verir, sonra dönerim", "", {"kesif": 1}, "ara"),
             ("Arkadaşlarla oynarım", "", {"sosyal": 2}, "arkadas"),
         ]},
        {"kod": "rekabet_gurur", "tip": "tek",
         "metin": "Seni en çok ne gururlandırır?",
         "secenekler": [
             ("Rank atlamak", "", {"rekabet": 2}, "rank"),
             ("Maçın en iyisi olmak", "MVP",
              {"rekabet": 1, "toplama": 1}, "mvp"),
             ("Bütün karakterleri açmak", "", {"toplama": 2}, "karakter"),
             ("Takımımı taşımak", "", {"sosyal": 2}, "tasimak"),
         ]},
    ],
    "simulasyon": [
        {"kod": "hangi_simulasyon", "tip": "coklu",
         "metin": "Hangi tür simülasyonları oynarsın?",
         "secenekler": [
             ("Şehir ya da üs kurma", "Cities, Frostpunk",
              {"kurma": 1}, "sehir"),
             ("Çiftlik ya da yaşam", "Stardew Valley, The Sims",
              {"toplama": 1, "sosyal": 1}, "yasam"),
             ("Araç, uçuş ya da yarış", "Euro Truck, F1",
              {"rekabet": 1, "kesif": 1}, "arac"),
             ("İşletme (tycoon)", "", {"kurma": 1, "rekabet": 1}, "isletme"),
         ]},
        {"kod": "buyudu", "tip": "tek",
         "metin": "Şehrin ya da işletmen büyüdü. Şimdi ne yaparsın?",
         "secenekler": [
             ("Verimliliği artırırım", "", {"kurma": 2}, "verim"),
             ("Yeni bir bölge açarım", "", {"kesif": 2}, "bolge"),
             ("Her binayı ya da ürünü açarım", "", {"toplama": 2}, "hepsi"),
             ("Başkalarınınkini geçmeye çalışırım", "",
              {"rekabet": 2}, "gec"),
         ]},
        {"kod": "para_bitiyor", "tip": "tek",
         "metin": "Para ya da kaynak bitmek üzere. İlk ne yaparsın?",
         "secenekler": [
             ("Hesap yapıp gideri kısarım", "", {"kurma": 2}, "hesap"),
             ("Yeni bir gelir yolu ararım", "", {"kesif": 2}, "gelir"),
             ("Riske girip büyük oynarım", "", {"rekabet": 2}, "risk"),
             ("Yavaşlar, her şeyi dengelerim", "",
              {"kurma": 1, "toplama": 1}, "denge"),
         ]},
        {"kod": "en_sevdigin_an", "tip": "tek",
         "metin": "Bir simülasyonda en sevdiğin an hangisi?",
         "secenekler": [
             ("Her şeyin kendi kendine döndüğü an", "",
              {"kurma": 2}, "donuyor"),
             ("Yeni bir şeyin açıldığı an", "", {"kesif": 2}, "acildi"),
             ("Listeyi tamamladığım an", "", {"toplama": 2}, "tamam"),
             ("Birine gösterdiğim an", "", {"sosyal": 2}, "goster"),
         ]},
    ],
}


def _soru(tur: str, kod: str) -> Dict[str, Any]:
    return next(s for s in SORULAR[tur] if s["kod"] == kod)


def soru_dagilimi(turler: Sequence[str]) -> List[Tuple[str, int]]:
    """Seçilen türlere göre sorulacak takip soruları: (tür, sorunun sırası).

    Dört takip sorusu türlere sırayla dağıtılır: tek tür 4, iki tür 2+2,
    üç tür 2+1+1, dört tür 1+1+1+1. Kullanıcının kuralı: birden çok tür
    seçene birleşim sorusu SORULMAZ; her türün kendi sorularından alır.
    """
    if not turler:
        return []
    sayac = {tur: 0 for tur in turler}
    for sira in range(TAKIP_SORU_SAYISI):
        sayac[turler[sira % len(turler)]] += 1
    return [(tur, j) for tur in turler for j in range(sayac[tur])]


def profil_hesapla(turler: Sequence[str],
                   cevaplar: Sequence[Tuple[str, str, Sequence[int]]]
                   ) -> Dict[str, Any]:
    """Cevaplardan profil. Saf fonksiyon: ekran yok, kayıt yok.

    `cevaplar`: (tür, soru kodu, seçilen indeksler).
    """
    egilim = {e: 0.0 for e in EGILIMLER}
    for tur in turler:
        for anahtar, puan in TUR_AGIRLIGI.get(tur, {}).items():
            egilim[anahtar] += puan / len(turler)

    hesap_uslubu = ""
    zorlaninca = ""
    kayit: Dict[str, List[str]] = {}
    for tur, kod, secilenler in cevaplar:
        soru = _soru(tur, kod)
        secenekler = soru["secenekler"]
        kayit[kod] = [secenekler[i][3] for i in secilenler]
        if soru["tip"] == "sirali":
            # İlk sıradaki tam, ikinci yarım puan. Hepsini eşit saymak
            # sıralamayı çöpe atmak olurdu; sıralama bir yoğunluk bilgisi.
            for sira, indeks in enumerate(list(secilenler)[:2]):
                carpan = 1.0 if sira == 0 else 0.5
                for anahtar, puan in secenekler[indeks][2].items():
                    egilim[anahtar] += puan * carpan
        else:
            # Çoklu seçimde toplam, tek seçimli bir sorunun ağırlığını
            # geçmesin: beş oyun işaretleyen beş kat sayılmaz.
            bolen = max(1, len(secilenler)) if soru["tip"] == "coklu" else 1
            for indeks in secilenler:
                for anahtar, puan in secenekler[indeks][2].items():
                    egilim[anahtar] += puan / bolen
        if kod == "uretim_sirasi" and secilenler:
            hesap_uslubu = secenekler[secilenler[0]][3]
        if kod == "ucuncu_deneme" and secilenler:
            zorlaninca = secenekler[secilenler[0]][3]

    return {
        "surum": 1,
        "turler": list(turler),
        "egilim": {e: round(v, 2) for e, v in egilim.items()},
        # Otomasyon oyuncusunun hesap üslubu: ileri, tersten, kestirme ya da
        # doğaçlama. Test gibi hissettirmeyen bir oyun sorusu, ama aslında
        # öğrencinin bir modelleme problemine nasıl yaklaştığını söylüyor.
        # Şimdilik yalnızca saklanıyor; hiçbir şeyi DEĞİŞTİRMİYOR.
        "hesap_uslubu": hesap_uslubu,
        "zorlaninca": zorlaninca,
        "cevaplar": kayit,
        "ziyaret": {},
    }


def anket(durum) -> Dict[str, Any]:
    """Beş soruluk anketi sorar, profili durum'a yazar. Kaydetmez."""
    eski_ziyaret = dict((durum.oyuncu_profili or {}).get("ziyaret") or {})
    ekran.yaz()
    ekran.kutu(
        "Komutan seni tanımak istiyor. En çok beş soru; doğru cevabı yok, not"
        "verilmiyor.\n\n"
        "Cevaplarına göre üs sana önce neyi göstereceğine karar verir. "
        "Hiçbir yer kapanmaz.",
        "ÜSSE HOŞ GELDİN", "beyaz")
    secenekler = [(t[1], t[2]) for t in TURLER] + [HICBIRI]
    secilen = ekran.coklu_sec(
        "1/5  Boş vaktinde en çok hangi tür oyunları oynarsın?",
        secenekler, ipucu="Birden çoksa aralarına boşluk koy (ör. 1 3).")
    turler = [TURLER[i][0] for i in secilen if i < len(TURLER)]

    cevaplar = []
    for no, (tur, j) in enumerate(soru_dagilimi(turler), start=2):
        soru = SORULAR[tur][j]
        baslik = "{}/5  {}".format(no, soru["metin"])
        gorunen = [(s[0], s[1]) for s in soru["secenekler"]]
        if soru["tip"] == "tek":
            indeksler = [ekran.menu(baslik, gorunen)]
        elif soru["tip"] == "sirali":
            indeksler = ekran.coklu_sec(
                baslik, gorunen, sirali=True,
                ipucu="Numaraları sırayla yaz (ör. 2 1 4 3). Hepsini "
                      "yazmak zorunda değilsin.")
        else:
            indeksler = ekran.coklu_sec(
                baslik, gorunen, ipucu="Birden çoksa aralarına boşluk koy.")
        cevaplar.append((tur, soru["kod"], indeksler))

    profil = profil_hesapla(turler, cevaplar)
    profil["ziyaret"] = eski_ziyaret
    # Kayıtta sorulan ritim (B41) anketin parçası değil; anket yenilenince
    # silinmesin.
    eski_ritim = (durum.oyuncu_profili or {}).get("ritim")
    if eski_ritim:
        profil["ritim"] = dict(eski_ritim)
    durum.oyuncu_profili = profil
    return profil


# ================================================= ne sıklıkla uğrar (B41)
# Kullanıcı (11 Eylül 2026): okul sorulmaz. Okuyup okumadığı ve çalışıp
# çalışmadığı sorulur; amaç "oyuna ne sıklıkla girebileceğini tahmin etmek"
# diye söylenir. Oyun kendini ders ya da ödev olarak tanıtmaz -- "ödevi ceza
# olarak kodlayan her dersten kaçar."
#
# Söylenen amaç GERÇEK amaç olmak zorunda. Cevap YALNIZCA şuna yarar: vakti
# az olana ana menüde Kısa Sefer öne gelir. Öğretmen raporuna, panoya,
# karneye gitmez. Başka bir işe (ör. B40 ekip çeşitliliği) kullanılacaksa o
# iş de soru ekranında söylenmeli.
OKUYOR_SECENEKLERI = (("evet", "Evet"), ("hayir", "Hayır"),
                      ("", "Söylemek istemiyorum"))
CALISIYOR_SECENEKLERI = (("hayir", "Hayır"), ("yari", "Yarı zamanlı"),
                         ("tam", "Tam zamanlı"), ("", "Söylemek istemiyorum"))


def ritim_sor(okulda: bool = False) -> Dict[str, str]:
    """İki atlanabilir soru. Okuldan giren "okuyor musun"u görmez."""
    ekran.yaz()
    ekran.kutu(
        "İki kısa soru. Üs, ne sıklıkla uğrayabileceğini tahmin etmek "
        "istiyor: vakti az olana kısa seferler öne çıkar. Az uğrayan geride "
        "kalmış sayılmaz.\n\n"
        "Söylemek istemezsen son seçeneği seç.",
        "NÖBET ÇİZELGESİ", "beyaz")
    ritim = {}
    if not okulda:
        i = ekran.menu("Şu an okuyor musun?",
                       [s[1] for s in OKUYOR_SECENEKLERI])
        ritim["okuyor"] = OKUYOR_SECENEKLERI[i][0]
    i = ekran.menu("Bir işte çalışıyor musun?",
                   [s[1] for s in CALISIYOR_SECENEKLERI])
    ritim["calisiyor"] = CALISIYOR_SECENEKLERI[i][0]
    return ritim


def ritim_yaz(durum, ritim: Dict[str, str]) -> None:
    if not isinstance(durum.oyuncu_profili, dict):
        durum.oyuncu_profili = {}
    durum.oyuncu_profili["ritim"] = dict(ritim)


def vakti_az(durum) -> bool:
    ritim = (durum.oyuncu_profili or {}).get("ritim") or {}
    return ritim.get("calisiyor") in ("yari", "tam")


# ======================================================= sıralama ve ses

# Ana menüde yeri kişiye göre değişen katmanlar. Öğrenmenin çekirdeği
# (Usta Çadırı, Komuta Masası) ve ayarlar bu listede YOK: onların yeri
# sabit, öğretmen tahtadan "Komuta Masası'na girin" dediğinde herkes aynı
# yerde bulsun.
VARSAYILAN_KATMAN_SIRASI = ("kronograf", "tesis", "gunluk")
KATMAN_EGILIMLERI = {
    "kronograf": ("kesif",),
    "tesis": ("kurma",),
    "gunluk": ("rekabet", "toplama"),
}
KATMAN_ADLARI = {
    "kronograf": "Kronograf Odası",
    "tesis": "Üssün Tesisleri",
    "gunluk": "Kâşif Günlüğü",
}
# Bir ziyaret, ankette verilen yarım puana denk. On ziyarette tavan:
# yoksa bir katmana bir süre takılan öğrencinin menüsü kalıcı olarak
# ona döner.
ZIYARET_AGIRLIGI = 0.5
ZIYARET_TAVANI = 10


def _ziyaret(profil: Dict[str, Any], katman: str) -> float:
    sayi = int((profil.get("ziyaret") or {}).get(katman, 0))
    return ZIYARET_AGIRLIGI * min(sayi, ZIYARET_TAVANI)


def katman_sirasi(durum) -> List[str]:
    """Ana menüdeki katmanların sırası. HEP AYNI ÜÇ KATMAN döner.

    Anket yoksa ya da eşitlik varsa varsayılan sıra korunur (sorted
    kararlıdır). Oturum başında bir kez hesaplanmalı; her ziyarette
    yeniden hesaplanırsa menü öğrencinin elinin altında kayar.
    """
    profil = durum.oyuncu_profili or {}
    egilim = profil.get("egilim") or {}

    def puan(katman: str) -> float:
        anket_puani = max(float(egilim.get(e, 0))
                          for e in KATMAN_EGILIMLERI[katman])
        return anket_puani + _ziyaret(profil, katman)

    return sorted(VARSAYILAN_KATMAN_SIRASI, key=lambda k: -puan(k))


def ziyaret_say(durum, katman: str) -> None:
    if katman not in KATMAN_EGILIMLERI:
        return
    if not isinstance(durum.oyuncu_profili, dict):
        durum.oyuncu_profili = {}
    ziyaret = durum.oyuncu_profili.setdefault("ziyaret", {})
    ziyaret[katman] = int(ziyaret.get(katman, 0)) + 1


def baskin_egilim(durum) -> Optional[str]:
    """Açılış satırının sesi. "sosyal" hiçbir zaman dönmez: ona karşılık
    gelen bir katman bugün yok ve olmayan bir şeyi vaat etmiyoruz."""
    profil = durum.oyuncu_profili or {}
    egilim = profil.get("egilim") or {}
    puanlar = {e: float(egilim.get(e, 0))
               for e in ("rekabet", "kurma", "kesif", "toplama")}
    puanlar["kesif"] += _ziyaret(profil, "kronograf")
    puanlar["kurma"] += _ziyaret(profil, "tesis")
    puanlar["rekabet"] += _ziyaret(profil, "gunluk")
    en_iyi = max(puanlar, key=lambda e: puanlar[e])
    return en_iyi if puanlar[en_iyi] > 0 else None


def acilis_satiri(durum, onumdeki: Optional[Dict[str, Any]] = None,
                  sefer_bedeli: Optional[Dict[str, int]] = None
                  ) -> Optional[str]:
    """Ana menünün üstünde üssün öğrenciye söylediği tek satır.

    Aynı gerçek, farklı vurgu. Hiçbir satır bir şeyin KAPALI olduğunu
    söylemez; hepsi mevcut veriden üretilir, yeni içerik gerektirmez.
    """
    egilim = baskin_egilim(durum)
    if egilim == "rekabet":
        if onumdeki:
            return "Önünde {} var, {} yıldız önde. Geçmek için {} yıldız.".format(
                onumdeki["takma"], onumdeki["fark"], onumdeki["fark"] + 1)
        sonraki = durum.sonraki_rutbe
        if sonraki:
            return "{} olmana {} yıldız kaldı.".format(
                sonraki[1], max(0, sonraki[0] - durum.rutbe_puani))
        return "En yüksek rütbedesin: {}.".format(durum.rutbe)
    if egilim == "kurma":
        from . import tesis
        arizali = tesis.arizali_kodlar(durum)
        if arizali:
            return "{} durdu; Üssün Tesisleri'nden onarabilirsin.".format(
                tesis.ad(arizali[0]))
        for kod in tesis.TESIS_KODLARI:
            bedel = tesis.gelistirme_bedeli(durum, kod)
            if bedel and durum.kaynak_yeter_mi(bedel):
                return "{} geliştirilebilir; kaynağın yetiyor.".format(
                    tesis.ad(kod))
        toplam = sum(tesis.uretim_miktari(durum, k)
                     for k in tesis.TESIS_KODLARI)
        return "Tesisler görev başına toplam +{} kaynak üretiyor.".format(
            toplam)
    if egilim == "kesif":
        if sefer_bedeli and durum.kaynak_yeter_mi(sefer_bedeli):
            return "Kronograf yeni bir kayıt yakaladı; sefer bedelin hazır."
        from oyun.icerik import hikaye
        if durum.bolum + 1 < len(hikaye.BOLUMLER):
            sonraki = hikaye.BOLUMLER[durum.bolum + 1]
            return "Sıradaki keşif: {}, {} görev kaldı.".format(
                sonraki.baslik,
                max(0, sonraki.gereken_gorev - durum.oynanan_gorev))
        return ("Haritada açılmamış bölüm kalmadı; Kronograf yeni çağlar "
                "bekliyor.")
    if egilim == "toplama":
        from .ilerleme import ROZETLER
        return "Rozet defterin: {} / {} dolu.".format(
            len(durum.rozetler), len(ROZETLER))
    return None


# ========================================================== zorlanınca

# Anketteki "Aynı yerde ikinci kez öldün. Üçüncüde ne yaparsın?" sorusunun
# cevabı, takılan öğrenciye ÖNCE hangi desteğin gösterileceğini seçer (B35.10).
#
# Hiçbir yardım gizlenmez, kilitlenmez, yenisi eklenmez (§12: katman, kapı
# değil). Değişen iki şey var: yanlıştan sonraki yardım listesinin SIRASI ve
# tek satırlık bir öneri. Öneri, aynı adımda zorlanma sürdükçe listede bir
# sonrakine geçer -- kullanıcının kendi cevabı "kaç kere zorlandığıma bağlı"
# idi ve §0 da aynısını söylüyor: zorlanma tekrarlandıkça destek artar.
#
# Harfler oturum komutlarıdır: i ipucu, c çözüm / nasıl düşünülür, o basit
# örnek (yoksa basit alıştırmalar), k kaynaklar, e el kaldır (yalnız sınıfta).
ZORLANINCA_SIRASI = {
    # "Aynı yoldan, daha dikkatli": yolu değiştirme, küçük bir dürtme ver.
    "israr": ("i", "k", "o", "c"),
    # "Başka bir yol denerim": sorunun nasıl düşünüldüğü, sonra başka örnek.
    "baska_yol": ("c", "o", "i", "k"),
    # "Hazırlanıp güçlenip dönerim": önce basitten başla, sonra dön.
    "hazirlan": ("o", "i", "c", "k"),
    # "Birine sorar ya da izlerim": sınıfta el kaldır; değilse çözümü izle.
    "sor": ("e", "c", "o", "i", "k"),
}
ZORLANINCA_SESI = {
    "israr": "Aynı yoldan, daha dikkatli",
    "baska_yol": "Başka bir yoldan bakmak istersen",
    "hazirlan": "Hazırlanıp dönmek istersen",
    "sor": "Sormak ya da izlemek istersen",
}
YARDIM_EYLEMI = {
    "i": "i ile bir ipucu al",
    "c": "c ile çözüm yolunu oku",
    "o": "o ile basitten başla",
    "k": "k ile kaynaklara dön",
    "e": "e ile el kaldır",
}


def zorlaninca(durum) -> str:
    """Öğrencinin ankette seçtiği cevap; yoksa ya da tanınmıyorsa "".

    Anketten önce açılmış kayıtlar, testler ve önizleme (`durum` None)
    için boş döner -- o öğrenciler bugünkü ekranı AYNEN görür.
    """
    profil = getattr(durum, "oyuncu_profili", None) or {}
    cevap = profil.get("zorlaninca") or ""
    return cevap if cevap in ZORLANINCA_SIRASI else ""


def yardim_sirala(durum, yardimlar) -> list:
    """(harf, etiket) listesini öğrencinin tercih sırasına dizer.

    Hiçbir öğe düşmez: tercihte olmayan harfler sonda, kendi sıralarıyla
    kalır (sıralama kararlı). Tercih yoksa liste olduğu gibi döner.
    """
    sira = ZORLANINCA_SIRASI.get(zorlaninca(durum))
    if not sira:
        return list(yardimlar)
    return sorted(yardimlar,
                  key=lambda ikili: sira.index(ikili[0])
                  if ikili[0] in sira else len(sira))


def yardim_onerisi(durum, yardimlar, atla=()) -> Optional[str]:
    """Takılan öğrenciye tek satırlık öneri; söylenecek bir şey yoksa None.

    `yardimlar` şu an GERÇEKTEN kullanılabilir olanlardır; olmayan bir
    yardımı önermek, öğrenciyi deneme hakkını onu aramakla harcamaya
    gönderir (E01). `atla` bu adımda zaten başvurulan ya da şu an
    kullanılamayan harfler: öneri onları geçip bir sonrakine iner.
    """
    cevap = zorlaninca(durum)
    if not cevap:
        return None
    mevcut = {harf for harf, _ in yardimlar}
    for harf in ZORLANINCA_SIRASI[cevap]:
        if harf in mevcut and harf not in atla:
            return "{}: {}.".format(ZORLANINCA_SESI[cevap], YARDIM_EYLEMI[harf])
    return None


# ============================================================= tanışma

def tanisma_gerekli_mi(durum) -> bool:
    return not (durum.ayarlar or {}).get("tanisma_bitti")


def tanisma(durum) -> None:
    """Takma ad (anket artık isteğe bağlı). Bitince işaretler; KAYDETMEZ.

    Yarıda kesilirse (telefonda sekme ölürse) işaret konmadığı için bir
    sonraki açılışta yeniden sorulur -- anket kaybolmaz, baştan gelir.
    """
    if not (durum.takma_ad or "").strip():
        takma_ad_sec(durum)
    # 5 Kasim 2026 (oyun turu, kullanici): "Hangi oyunlari oynadigini sormak
    # su anda gereksiz geldi." Anket artik ilk gorevden sonra SORULMUYOR.
    # Katman sirasi ziyaretlerden ogreniliyor (`_ziyaret`); anket Techizat
    # ve Ayarlar'da istege bagli duruyor.
    ekran.yaz()
    ekran.kutu(
        "Hoş geldin, {}.\n\n"
        "Hiçbir yer kapalı değil; her yere her zaman girebilirsin. "
        "Oynadıkça üs seni tanır ve sık gittiğin yerleri öne alır. "
        "İstersen Teçhizat ve Ayarlar'dan kısa oyuncu anketini "
        "doldurabilirsin.".format(durum.goruntu_adi),
        "KOMUTAN", "acik_yesil")
    durum.ayarlar["tanisma_bitti"] = True
    ekran.bekle()
