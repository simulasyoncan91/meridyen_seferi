# -*- coding: utf-8 -*-
"""
Oyun durumu ve kayıt dosyaları.

Durum tamamen JSON'a çevrilebilir tutuldu: harici kütüphane yok, kayıt dosyası
insan tarafından okunabilir. Öğretmen bir öğrencinin kayıt dosyasını açıp
hangi derste hangi kademede olduğunu çıplak gözle görebilir.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import random
import shutil
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .modeller import (
    ANLATIM, BIRLIKTE, DERSLER, KADEME_ADLARI, SERBEST, ZORLUK_KADEME,
    kademe_zorlugu, sonraki_asama, onceki_asama,
)

# Kayıtlar varsayılan olarak proje klasörünün altındaki kayitlar/ dizinine
# yazılır. Okulda bilgisayarlar ortak kullanıldığı ve öğrenci her seferinde
# aynı makineye oturamadığı için, bu klasör MERIDYEN_KAYIT ortam değişkeniyle
# ağdaki ortak bir klasöre alınabilir:
#
#     set MERIDYEN_KAYIT=\\sunucu\ogrenci\meridyen      (Windows)
#     export MERIDYEN_KAYIT=/mnt/ortak/meridyen        (Linux)
#
# Böylece öğrenci hangi makineye otursa oturursa kendi seferinden devam eder.
# Dikkat havuzu ayarlari. Bkz. Durum.dikkat_tavani().
DIKKAT_BASLANGIC = 100      # hic konusu oturmamis ogrenci
DIKKAT_TABANI = 18          # her seyi oturtmus ogrenci
# Neden 18: olculdu (5 Eylul 2026). Bir bulmacanin TAM maliyeti (her kanit +
# her cozum) ortalama 10-12,5. Taban 10 olsaydi ustalasmis ogrenci tek bir
# bulmacada bile her seyi acamazdi ve dolum (1-6) tek bulmaca maliyetinin
# altinda kaldigi icin surekli acikta kalirdi.
#
# 25 onerildi, kullanici 18'i secti ve gerekcesi su: dikkat zamanla azaldigi
# icin ogrenci kendisi secici olmayi ogrenir, her soruda butun ipuclarini
# almaya calismaz, elindekini degerlendirmeye baslar. Yani taban "her seyi
# acabilecegin miktar" olmak zorunda degil -- ogrencinin kendi dikkati
# aradaki farki kapatir. Taban, "dogru yere bak" demeli; "hic bakma" degil.
EN_AZ_KONU_ICIN_TAVAN = 5   # bu kadar konu baslanmadan oran hesaplanmaz

# Bir konudaki ustaligin kac kademe yukariya kadar gecerli sayilacagi.
# Bkz. KonuDurumu.oturdugu_kademe ve Durum.oturmus_oran.
#
# Pedagojik gerekce: konu adi ayni kalsa da ayrinti kademeyle artar. 4. sinifta
# "kesirler"i oturtan ogrenci 7. sinif kesirlerini bilmez; ayni ad altinda
# bambaska bir is vardir. Ustalik damgasi olmayinca oturmus konu yillar
# boyunca birikiyor, oturmus_oran 1'e yaklasiyor ve dikkat tavani kalici
# olarak tabanda kaliyordu -- yani sinif atlamanin tavani yukselten duzeltici
# etkisi her yil biraz daha zayifliyordu (bkz. GOREVLER.md B19, Olcum 2).
#
# 2 secildi cunku bir-iki kademelik fark ayni konunun biraz derinlesmis hali
# sayilabilir; ucuncu kademeden sonrasi baska bir konudur ve yeniden
# ogrenilmesi gerekir.
USTALIK_KADEME_TOLERANSI = 2
# Gorev bitince verilen dikkat, gorevin zorluguna gore (1..5)
DIKKAT_DOLUM = {1: 1, 2: 2, 3: 3, 4: 4, 5: 6}

KAYIT_KLASORU = os.environ.get("MERIDYEN_KAYIT") or os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), "kayitlar")

# KAYIT UYUMU (B47.1, 23 Eylül 2026). Kullanıcı: güncelleme GitHub/Steam'den
# gelecek, "bütün kayıt verilerimiz ileriye dönük uyumlu olması şart".
#   * Geriye uyum: eski kayıt yeni sürümde açılır (`sozlukten` içindeki göçler;
#     şemayı değiştiren her yeni göç KAYIT_SURUMU'nu bir artırır).
#   * İleriye uyum: YENİ sürümün kaydını bu sürüm açıp kaydederse tanımadığı
#     alanlar olduğu gibi geri yazılır ve şema numarası düşürülmez.
#   * Kendinden yeni şemalı kayda ilk kez yazmadan önce bir kopya alınır.
# Dondurulmuş örnek kayıtlar: testler/ornek_kayitlar/ (her sürümde yüklenmeli).
KAYIT_SURUMU = 1
YENI_SURUM_YEDEGI = ".yeni-surum.bak"


def _bilinmeyenler(ham: Dict[str, Any], sinif, ayrilmis=()) -> Dict[str, Any]:
    """`ham` içinde `sinif`ın alanı olmayan (yeni sürümün eklediği) anahtarlar."""
    bilinen = set(sinif.__dataclass_fields__) | set(ayrilmis)
    return {k: v for k, v in (ham or {}).items() if k not in bilinen}

# Koloni döngüsünün para birimi. Şu an yarım bir döngü: kaynaklar görev
# bitince kazanılıyor ama harcanacak yer neredeyse yok (tek gider
# oyun.GOREV_BEDELI). Koloni katmanı -tesis kurma, masa açma, arıza onarma-
# tam olarak bu boşluğu dolduracak.
#
# Yazarken uyulacak kural: kaynak YALNIZCA öğrenerek kazanılır ve YALNIZCA
# öğrenmeye harcanır. Paralel bir üs kurma optimizasyonu eklenirse oyun,
# ödev yapıştırılmış bir tıklama oyununa dönüşür.
# Gerekçesi: TASARIM_NOTLARI.md §3
KAYNAKLAR = ["erzak", "cevher", "enerji", "itibar"]

KAYNAK_ADLARI = {
    "erzak": "Erzak",
    "cevher": "Cevher",
    "enerji": "Enerji",
    "itibar": "İtibar",
}

KAYNAK_SIMGE = {
    "erzak": "E",
    "cevher": "C",
    "enerji": "J",
    "itibar": "İ",
}

# Görev sayısına bağlı sade rütbe sistemi. Eğitim ilerlemesini not gibi değil,
# üste verilen sorumluluk gibi hissettirir.
#
# 10 Eylul 2026: merdiven uzatildi. Bes basamak 28 gorevde bitiyordu --
# iki uc derslik bir yol. Kullanici rutbenin "saglam rekabet ve hirs"
# yaratmasini istedi; bitmis bir merdivenle hirs olmaz.
#
# ILK BES ESIGE DOKUNULMADI VE DOKUNULMAMALI. Rutbe kayitta saklanmiyor
# (asagidaki `rutbe` bir property, yalnizca `oynanan_gorev` kaydediliyor).
# Bir esigi yukseltmek, mevcut ogrenciyi bir sonraki acilista SESSIZCE
# rutbe dusurur ve oyun bunu ona aciklayamaz. Yalnizca ustune eklenir.
# testler/test_rutbe.py bunu kilitliyor.
#
# 5 Kasim 2026 (oyun turu, kullanici karari): "Yildizlarin toplami olsun."
# Ingilizce gorevini yapamayan ogrenci yine de terfi etmisti: rutbe gorev
# SAYISINDAN geliyordu, basari bakilmiyordu. Artik esikler TOPLAM YILDIZ.
# Gorev basina 0-3 yildiz; ortalama ogrenci ~2 aldigi icin yildiz esikleri
# eski gorev esiklerinin kabaca iki kati -- ortalama hiz ayni kalir, iyi
# cozen daha hizli yukselir, sifir yildizli deneme rutbe getirmez.
#
# ESKI KAYITTA RUTBE DUSMEZ: kayitta `rutbe_tabani` yoksa (bu surumden
# once acilmis sefer) eski gorev esiklerine gore o anki basamak taban olarak
# yazilir. Rutbe = max(taban, yildiz basamagi). Yukaridaki uyari boylece
# korunuyor: hicbir ogrenci bir sonraki acilista sessizce rutbe kaybetmez.
RUTBELER = [
    (0, "Aday Kâşif"),
    (6, "Saha Kâtibi"),
    (16, "İz Sürücü"),
    (30, "Sefer Uzmanı"),
    (56, "Meridyen Muhafızı"),
    (80, "Kıdemli Muhafız"),
    (110, "Keşif Kolu Başı"),
    (150, "Sefer Komutanı"),
    (200, "Üs Komutanı"),
    (270, "Meridyen Efsanesi"),
]
# Eski (gorev sayisi) esikleri: YALNIZCA eski kaydin tabanini hesaplamak icin.
RUTBELER_GOREV = (0, 3, 8, 15, 28, 40, 55, 75, 100, 135)


def rutbe_basamagi(puan: int, esikler=None) -> int:
    """Puanin (yildiz ya da eski gorev sayisi) ulastigi en yuksek basamak."""
    esikler = esikler if esikler is not None else [e for e, _ in RUTBELER]
    sira = 0
    for indeks, esik in enumerate(esikler):
        if int(puan or 0) >= esik:
            sira = indeks
    return sira


@dataclass
class KonuDurumu:
    """
    Tek bir konudaki ilerleme.

    Oyunun asıl birimi budur: öğrenci "matematikte" değil, "denklem kurmada"
    zorlanır. Aşama, o konuyu hangi destek düzeyinde çalıştığını gösterir.
    """
    asama: str = ANLATIM
    anlatim_sayisi: int = 0
    birlikte_sayisi: int = 0
    serbest_dogru: int = 0
    serbest_toplam: int = 0
    ustalik: float = 0.0
    ust_uste_zorlanma: int = 0
    # Konunun HANGI kademede oturdugu. 0 = hic olculmedi; eski kayitlar ve
    # henuz oturmamis konular buradadir. Ustaligin "hala gecerli" olup
    # olmadigina bu alan karar verir (bkz. USTALIK_KADEME_TOLERANSI).
    oturdugu_kademe: int = 0
    # Damganin vuruldugu andaki serbest deneme sayisi. Tek isi, konunun
    # damgadan SONRA yeniden calisilip calisilmadigini anlamak: serbest_toplam
    # bu sayidan buyukse ogrenci konuyu yeni kademede tekrar sinamis demektir
    # ve damga o kademeye tasinabilir. Bu olmadan bir konu, bir kez eski
    # kademede damgalandiktan sonra bir daha asla "oturmus" sayilamazdi.
    damga_serbest_toplam: int = 0
    son_calisma_gunu: str = ""
    tekrar_gunu: str = ""
    tekrar_basamagi: int = 0
    tekrar_kademesi: int = 0
    zorlanma: float = 0.0
    zorlanma_gozlemi: int = 0
    # Bu konudaki son BAĞIMSIZ görevin özeti (B31.14). Öğrenciyi yalnızca
    # kendi geçmişiyle karşılaştırmak için -- sınıfla asla. Bkz.
    # degerlendirme.kisisel_karsilastirma.
    son_gorev: Dict[str, Any] = field(default_factory=dict)

    @property
    def tamamlandi(self) -> bool:
        """Kendi başına en az iki kez iyi geçtiyse konu oturmuş sayılır."""
        return self.asama == SERBEST and self.serbest_dogru >= 2 and self.ustalik >= 0.7

    @property
    def baslanmis(self) -> bool:
        return (self.anlatim_sayisi + self.birlikte_sayisi + self.serbest_toplam) > 0

    def kademeyi_damgala(self, kademe: int) -> bool:
        """
        Konu oturmussa, hangi kademede oturdugunu isaretler. Degistiyse True.

        Damga uc durumda yenilenir:

        1. `oturdugu_kademe == 0` -- hic olculmemis. ESKI KAYITLAR buraya
           duser ve ogrencinin MEVCUT kademesine yazilir. Aksi halde surumu
           yukselten her okul, butun eski ogrencilerin ustaligini bir gecede
           silmis ve dikkat tavanlarini tavana firlatmis olurdu.
        2. Damga zaten bu kademedeyse -- damga (ve serbest sayaci) tazelenir.
           Bu sik onemli: tazelenmezse ayni kademede yapilan calismalar,
           kademe yukseldiginde "yeni kademede tekrar sinandi" gibi sayilir ve
           konu hic calisilmadan bir ust kademeye tasinirdi.
        3. Damgadan bu yana serbest asamada yeni calisma yapilmissa -- konu bu
           kademede yeniden sinanmis ve yine oturmustur; damga tasinir.

        Yalnizca `tamamlandi` konular damgalanir: oturmamis bir konuya kademe
        yazmak, ilerideki gercek damgayi kirletir.
        """
        if not self.tamamlandi:
            return False
        if not (self.oturdugu_kademe <= 0
                or self.oturdugu_kademe == kademe
                or self.serbest_toplam > self.damga_serbest_toplam):
            return False
        degisti = self.oturdugu_kademe != int(kademe)
        self.oturdugu_kademe = int(kademe)
        self.damga_serbest_toplam = self.serbest_toplam
        return degisti


def ustalik_gecerli_mi(oturdugu_kademe: int, simdiki_kademe: int) -> bool:
    """
    Bir kademede oturmus konu, su anki kademede hala oturmus sayilir mi?

    Kural TEK YONLU: yalnizca damga su anki kademenin GERISINDE kalirsa
    ustalik eskir. Damga ileride olabilir (ders kademesi dustuyse) ve o durumda
    ustalik elbette gecerlidir -- daha zorunu bilen kolayini da bilir.
    """
    if oturdugu_kademe <= 0:
        return False        # olculmemis; damgalanmadan sayilmaz
    return int(simdiki_kademe) - int(oturdugu_kademe) <= USTALIK_KADEME_TOLERANSI


@dataclass
class DersDurumu:
    """Tek bir dersteki ilerleme."""
    kademe: int = 1
    ustalik: float = 0.5          # 0..1 arası kayan ortalama
    cozulen: int = 0
    toplam_puan: int = 0
    toplam_yildiz: int = 0
    seri: int = 0                 # üst üste iyi geçen görev sayısı
    kotu_seri: int = 0
    model_dogru: int = 0          # modelleme adımını ilk denemede geçme sayısı
    model_toplam: int = 0
    son_ureticiler: List[str] = field(default_factory=list)
    konu_puani: Dict[str, float] = field(default_factory=dict)
    # Yanlış teşhisi -> kaç kez görüldüğü. Tek seferlik dalgınlık ile yerleşmiş
    # bir karışıklığı ayırt eden şey tekrar sayısıdır; karne buna bakar.
    hata_turleri: Dict[str, int] = field(default_factory=dict)
    konular: Dict[str, KonuDurumu] = field(default_factory=dict)

    @property
    def model_orani(self) -> float:
        return 0.0 if self.model_toplam == 0 else self.model_dogru / self.model_toplam

    def konu(self, konu_kodu: str) -> KonuDurumu:
        if konu_kodu not in self.konular:
            self.konular[konu_kodu] = KonuDurumu()
        return self.konular[konu_kodu]


@dataclass
class Durum:
    """Bir öğrencinin tüm oyun durumu."""
    ad: str = "Kâşif"
    # Sınıf/şube: yalnızca öğretmen raporunu ve karneyi gruplamak için. Oyun
    # akışında hiçbir yerde kullanılmaz; boş bırakılabilir.
    sinif: str = ""
    # Öğrenci numarası. Okulda kayıt dosyasının KİMLİĞİ budur; evde oynayan
    # için boş kalır ve kimlik yine ada düşer. Aynı adlı iki öğrencinin
    # birbirinin kaydını ezmesini engelleyen tek şey bu alandır.
    numara: str = ""
    # Oyuncu tipi: "ev" ya da "okul". Sınıf ve numara ESKİDEN HERKESE
    # soruluyordu; mezun, yetişkin ya da evde oynayan biri için ikisi de
    # anlamsız. Artık açılışta tek soru soruluyor ve okul dışındakilere o iki
    # soru hiç gösterilmiyor. Bkz. oyun.py _yeni_oyun().
    tip: str = "ev"
    # Kayıt dosyasının adı. Boşsa kimlik eski kuralla türetilir (numara varsa
    # "sinif-numara", yoksa öğrencinin adı) - eski kayıtlar bu sayede aynen
    # açılmaya devam eder. Yeni açılan numarasız kayıtlar burayı doldurur;
    # böylece aynı adlı iki oyuncu birbirinin dosyasını EZMEZ.
    kayit_adi: str = ""
    # Sinif kodu ve okul: ogretmenin actigi siniftan geliyor (araclar/sinif.py).
    # Kod kaydedilince ogrenci hangi sinifa bagli oldugu BELLI olur; rapor ve
    # karne gruplamasi ileride ada gore degil koda gore yapilabilir -- ad
    # yazim hatasina acik, kod degil.
    sinif_kodu: str = ""
    okul: str = ""
    # Meslek dalı (bölüm). Akademik ders adları öğrenciye hiç gösterilmez ama
    # meslek dalı gösterilir: o öğrencinin kendi bölümüdür. Meslek masasına
    # ilk girişte sorulur ve hatırlanır. Meslek lisesinde olmayan için boş.
    dal: str = ""
    # PIN'in özeti - PIN'in kendisi hiçbir yerde saklanmaz. Bunun ne olduğu
    # konusunda dürüst olalım: sınıf arkadaşının merakla başkasının kaydını
    # açmasını engeller, kayıt dosyasını Gezgin'den açan birini engellemez.
    # Gerçek gizlilik isteniyorsa sunucu tarafında kimlik doğrulama gerekir.
    pin_ozeti: str = ""
    tohum: int = 0
    bolum: int = 0
    zorluk: int = 2
    kaynaklar: Dict[str, int] = field(default_factory=dict)
    dersler: Dict[str, DersDurumu] = field(default_factory=dict)
    gunluk: List[str] = field(default_factory=list)
    rozetler: List[str] = field(default_factory=list)
    # Meridyen OS Arşiv ve Posta (bkz. arsiv.py): son 200 kayıt, düz liste.
    # Eski kayıtta yoktur (boş açılır); tanınmayan alanlar korunur.
    arsiv: List[Dict[str, Any]] = field(default_factory=list)
    tamamlanan_gorevler: List[str] = field(default_factory=list)
    ayarlar: Dict[str, Any] = field(default_factory=dict)
    # Sınıf kodu yoksa öğrencinin kendi okul programı. Sınıfa bağlı öğrenci
    # öğretmenin ortak programını okur; eski kayıtlar boş programla açılır.
    ders_programi: Dict[str, Any] = field(default_factory=dict)
    kesfedilen_konular: List[str] = field(default_factory=list)
    # Dikkat: ESKIDEN bulmaca basinaydi (Bulmaca.dikkat, varsayilan 6) ve her
    # gorevde sifirlaniyordu. Artik KALICI bir havuz. Sebep: "belirli surede
    # 1 dolsun" ancak havuzda anlamli; gorev basina sifirlanan bir sayida
    # dolum diye bir sey yok.
    #
    # Tavan ustalikla TERS orantili: yeni ogrenci 100 ile baslar ve kanit
    # acmakta comert davranabilir; konular oturdukca tavan DIKKAT_TABANI'na
    # (10) iner ve dogru yere bakmak zorunda kalir. Bu, TASARIM_NOTLARI §0'in
    # tersten okunusu: destek, ihtiyac azaldikca azalir -- ceza degil.
    # Sessiz el kaldirma: ogrencinin HANGI sorulari ogretmene bildirdigi.
    # Yalnizca burada, ogrencinin kendi kaydinda duruyor -- sinif dosyasinda
    # isim yok, sadece sayi var (araclar/el_kaldirma.py). Bunun tek isi ayni
    # soruyu iki kez bildirip sayiyi sismesini onlemek.
    bildirilen_sorular: List[str] = field(default_factory=list)
    # Uretim tesisleri (maden/tarla/atolye). Bos birakiliyor; ilk
    # kullanimda `tesis.tesisleri_al` dolduruyor. Boylece eski kayitlar
    # da bozulmadan aciliyor ve yeni tesis eklenirse kendiliginde geliyor.
    tesisler: Dict[str, Any] = field(default_factory=dict)
    # Uretim zinciri stoklari (GOREVLER B28.9): GRAM, tam sayi. Bos acilir;
    # eski kayitlar bozulmaz. Kurallar oyun/motor/zincir.py icinde.
    madenler: Dict[str, int] = field(default_factory=dict)
    kulceler: Dict[str, int] = field(default_factory=dict)
    alasimlar: Dict[str, int] = field(default_factory=dict)
    # Materyal stoku (B28.14): kod -> ADET (gram degil). Bos acilir; eski
    # kayitlar bozulmaz. Kurallar oyun/motor/materyal.py icinde.
    materyaller: Dict[str, int] = field(default_factory=dict)
    # Ussun konumu ("yeryuzu:duzluk", "gokyuzu"...). Bos ise varsayilan
    # yeryuzu sayilir; eski kayitlar da bu yuzden bozulmadan aciliyor.
    # Kurallar oyun/motor/konum.py icinde.
    konum: str = ""
    # Rutbe tabani (5 Kasim 2026): eski kayit acilinca gorev sayisindan
    # hesaplanan basamak; rutbe bunun altina dusmez. Yeni seferde 0.
    rutbe_tabani: int = 0
    # Ussun GERCEK yeri (5 Kasim 2026): {"plaka", "enlem", "boylam"}. Yeni
    # seferde kurulumun "konum" adiminda atanir; eski kayitta bos kalir ve
    # hicbir sey degismez. Kurallar oyun/motor/yer.py icinde.
    yer: Dict[str, Any] = field(default_factory=dict)
    # Konumla gelen sayaclar: enerji gideri karsilanamayan gorev sayisi
    # (gerilim) ve kac kez zorunlu inis yasandigi.
    us: Dict[str, Any] = field(default_factory=dict)
    # Takma ad: sinifin ogrenciyi TANIDIGI ad. Kullanici: "bir oyuncu icin
    # takma ad kendi kimligidir." Gercek ad (`ad`) ogretmende, karnede ve
    # kayit kimliginde kalir; takma ad yalnizca GOSTERIMDIR.
    #
    # kimlik() ONDAN TURETILMEZ. Turetilseydi takma ad degisince kayit
    # dosyasi kaybolur, ustelik PIN ozetinin tuzu kimlik oldugu icin butun
    # PIN'ler kirilirdi (araclar/sinif.py bu tuzagi bir kez yasadi).
    # Bkz. TASARIM_NOTLARI §11.
    takma_ad: str = ""
    # Oyuncu anketinin sonucu ve oynarken biriken egilimler. DUZ sozluk:
    # sozlukten() ic ice dataclass'i sessizce dusurur, sozluk tasir.
    # HICBIR SEY KILITLEMEZ -- yalnizca ana menudeki katmanlarin sirasini
    # ve ussun acilis satirini degistirir. Bkz. oyun/motor/oyuncu.py
    oyuncu_profili: Dict[str, Any] = field(default_factory=dict)
    # Ogrencinin OKUDUGU bildirimlerin numaralari. Bildirimin kendisi ayri
    # dosyada (kayitlar/bildiriler/). Burada tutulsaydi: ogretmen masadan
    # yazar, ogrenci o sirada oyundaysa bir sonraki otomatik kayit onu
    # SILERDI -- ve kimse fark etmezdi. Bkz. oyun/motor/bildiri.py
    okunan_bildiriler: List[str] = field(default_factory=list)
    dikkat: int = -1            # -1 = henuz kurulmadi, ilk kullanimda tavana esitlenir
    oynanan_gorev: int = 0
    ilk_oynama: float = 0.0
    son_oynama: float = 0.0
    # Süreklilik (TASARIM_NOTLARI §2, B35.11): görev yapılan AYRI GÜN sayısı.
    # Toplam süre değil -- evinde bilgisayarı olan öğrenci, yalnızca okul
    # saatinde oynayabileni her zaman geçer ve ölçü yeteneği değil imkânı
    # ölçmeye başlar. "Kaç gün ÜST ÜSTE" de değil -- seri kaybedilebilir;
    # hasta olan, telefonu elinden alınan öğrenci ilerlemesini geri verirdi.
    # Bu sayı yalnızca birikir, hiçbir olayla azalmaz.
    ayri_gun: int = 0
    son_katilim_gunu: str = ""

    def katilim_gunu_isle(self, bugun: Optional[str] = None) -> bool:
        """Bugün ilk kez görev sayıldıysa ayrı gün sayısını bir artırır.

        ESKİ KAYITLAR: bu alanlar yokken oynanan günler bilinmiyor.
        `ilk_oynama` bugünden önceyse ve daha önce görev yapılmışsa o günler
        EN AZ bir gün sayılır -- bir alt sınır; olmayan günü uydurmaz.
        """
        bugun = bugun or time.strftime("%Y-%m-%d")
        if self.son_katilim_gunu == bugun:
            return False
        if (self.ayri_gun == 0 and self.oynanan_gorev > 1 and self.ilk_oynama
                and time.strftime("%Y-%m-%d",
                                  time.localtime(self.ilk_oynama)) < bugun):
            self.ayri_gun = 1
        self.ayri_gun += 1
        self.son_katilim_gunu = bugun
        return True

    def gorevi_say(self, bugun: Optional[str] = None) -> None:
        """Katılımı sayar: görev sayacı ve ayrı gün birlikte, TEK yerde.

        Sayaç doğrudan artırılırsa gün sayılmaz ve süreklilik sessizce
        eksik kalır; `testler/test_sureklilik.py` bunu yakalar.
        """
        self.oynanan_gorev += 1
        self.katilim_gunu_isle(bugun)

    # ---------------------------------------------------------------- kurulum
    @classmethod
    def yeni(cls, ad: str, baslangic_kademesi: int = 5, tohum: Optional[int] = None,
             zorluk: Optional[int] = None, sinif: str = "", numara: str = "",
             pin: str = "", tip: str = "ev", kayit_adi: str = "") -> "Durum":
        secilen_zorluk = zorluk or kademe_zorlugu(baslangic_kademesi)
        # Yeni arayüz zorluk verir; eski eklentiler doğrudan kademe veriyorsa
        # o kesin değeri aynen koruruz.
        if zorluk is not None:
            baslangic_kademesi = ZORLUK_KADEME[secilen_zorluk]
        durum = cls(
            ad=ad or "Kâşif",
            sinif=(sinif or "").strip(),
            numara=(numara or "").strip(),
            tip=tip,
            kayit_adi=(kayit_adi or "").strip(),
            zorluk=secilen_zorluk,
            tohum=tohum if tohum is not None else random.randrange(1, 10 ** 9),
            kaynaklar={"erzak": 40, "cevher": 20, "enerji": 30, "itibar": 0},
            dersler={ders: DersDurumu(kademe=baslangic_kademesi) for ders in DERSLER},
            ayarlar={"yazim_hizi": 0.0, "zorluk": "uyarlanir", "ipucu_acik": True},
            ilk_oynama=time.time(),
            son_oynama=time.time(),
        )
        if pin:
            durum.pin_kur(pin)
        durum.gunluk_ekle("Meridyen Üssü'ne kayıt subayı olarak atandın.")
        return durum

    # ---------------------------------------------------------------- yardımcı
    def ders(self, ders_kodu: str) -> DersDurumu:
        if ders_kodu not in self.dersler:
            self.dersler[ders_kodu] = DersDurumu()
        return self.dersler[ders_kodu]

    def aktif_dersler(self) -> List[str]:
        """
        İçerik motorunun kullanabileceği alan kodları.

        Oyuncu bu teknik kodları görmez; arayüz onları dört öğrenme yolunda
        toplar. Ad eski kayıt ve eklenti uyumluluğu için korunmuştur.
        """
        return list(DERSLER)

    @property
    def sik_sayisi(self) -> int:
        """Görevlerin ortak şık üst sınırı."""
        return 5

    @property
    def zorluk_kademe_araligi(self):
        merkez = ZORLUK_KADEME.get(self.zorluk, 5)
        return (max(1, merkez - 2), min(13, merkez + 2))

    @property
    def zorluk_adi(self) -> str:
        from .modeller import ZORLUK_ADLARI
        return ZORLUK_ADLARI.get(self.zorluk, "Temel")

    def zorluk_ayarla(self, zorluk: int) -> None:
        """Bütün alanları seçilen zorluğun merkezine taşır."""
        self.zorluk = max(1, min(5, int(zorluk)))
        merkez = ZORLUK_KADEME[self.zorluk]
        for durum in self.dersler.values():
            durum.kademe = merkez

    def rastgele(self, etiket: str = "") -> random.Random:
        """
        Tohuma bağlı ama her görevde farklı bir rastgele üreteci.
        Aynı kayıt dosyası + aynı görev sırası = aynı sayılar (tekrarlanabilir).
        """
        return random.Random("{}|{}|{}".format(self.tohum, self.oynanan_gorev, etiket))

    def kaynak_ekle(self, odul: Dict[str, int]) -> Dict[str, int]:
        """Ödülü uygular, gerçekten eklenen miktarları döner."""
        uygulanan = {}
        for anahtar, miktar in (odul or {}).items():
            if anahtar not in KAYNAKLAR:
                continue
            onceki = self.kaynaklar.get(anahtar, 0)
            yeni = max(0, onceki + int(miktar))
            self.kaynaklar[anahtar] = yeni
            uygulanan[anahtar] = yeni - onceki
        return uygulanan

    def kaynak_yeter_mi(self, bedel: Dict[str, int]) -> bool:
        """
        Bir harcamanın karşılanıp karşılanmadığı.

        Şu an hiçbir yerden çağrılmıyor; koloni katmanı (tesis kurma, onarım,
        masa açma) yazıldığında giriş noktası burası olacak.
        Bkz. TASARIM_NOTLARI.md §3
        """
        return all(self.kaynaklar.get(a, 0) >= m for a, m in (bedel or {}).items())

    def gunluk_ekle(self, metin: str) -> None:
        damga = time.strftime("%d.%m %H:%M")
        self.gunluk.append("[{}] {}".format(damga, metin))
        if len(self.gunluk) > 200:
            del self.gunluk[:-200]

    def rozet_ekle(self, rozet: str) -> bool:
        if rozet in self.rozetler:
            return False
        self.rozetler.append(rozet)
        self.gunluk_ekle("Rozet kazanıldı: " + rozet)
        return True

    @property
    def ortalama_kademe(self) -> float:
        aktif = self.aktif_dersler()
        if not aktif:
            return 1.0
        return sum(self.ders(d).kademe for d in aktif) / len(aktif)

    def ozet_satiri(self, dar: bool = False) -> str:
        """Kaynaklar tek satirda. `dar` telefon icin: ayraclar sikisir.

        Genis ayrac ("  |  ") 49 karakter ediyor ve 50 sutunluk bir
        telefonda tek basina butun satiri dolduruyordu. Dar hali 43.
        """
        parcalar = ["{} {}".format(KAYNAK_ADLARI[a], self.kaynaklar.get(a, 0)) for a in KAYNAKLAR]
        return (" | " if dar else "  |  ").join(parcalar)

    @property
    def rutbe_puani(self) -> int:
        """Rütbeyi ilerleten sayı: bütün derslerde toplanan yıldız."""
        return sum(int(d.toplam_yildiz or 0) for d in self.dersler.values())

    @property
    def rutbe(self) -> str:
        return RUTBELER[self.rutbe_sirasi][1]

    @property
    def sonraki_rutbe(self):
        """(yıldız eşiği, ad) ya da son rütbedeyse None."""
        sira = self.rutbe_sirasi + 1
        return RUTBELER[sira] if sira < len(RUTBELER) else None

    @property
    def rutbe_sirasi(self) -> int:
        """RUTBELER içindeki indeks (merdivende kaçıncı basamak)."""
        return max(int(self.rutbe_tabani or 0), rutbe_basamagi(self.rutbe_puani))

    @property
    def goruntu_adi(self) -> str:
        """Oyun dünyasındaki ad: takma ad, yoksa gerçek ad.

        Öğrencinin kendi ekranında ve sınıf panosunda bu kullanılır.
        Karne, öğretmen masası ve kayıt kimliği GERÇEK adı kullanmaya
        devam eder.
        """
        return (self.takma_ad or "").strip() or self.ad

    # ---------------------------------------------------------------- kayıt
    def sozluge(self) -> Dict[str, Any]:
        from oyun import __version__

        veri = asdict(self)
        # İleriye uyum (B47.1): yüklerken tanınmayan alanlar olduğu gibi geri.
        for kod, ders in self.dersler.items():
            ders_veri = veri["dersler"][kod]
            for anahtar, deger in getattr(ders, "_bilinmeyen", {}).items():
                ders_veri.setdefault(anahtar, deger)
            for konu_kodu, konu in ders.konular.items():
                for anahtar, deger in getattr(konu, "_bilinmeyen", {}).items():
                    ders_veri["konular"][konu_kodu].setdefault(anahtar, deger)
        for anahtar, deger in getattr(self, "_bilinmeyen", {}).items():
            veri.setdefault(anahtar, deger)
        # Şema numarası DÜŞÜRÜLMEZ: yeni sürümün kaydını eski sürüm "1" diye
        # geri yazsaydı, yeni sürüm açınca aynı göçü ikinci kez yapardı.
        veri["_surum"] = max(KAYIT_SURUMU, getattr(self, "_okunan_surum", 0))
        veri["_uygulama"] = __version__
        return veri

    @classmethod
    def sozlukten(cls, veri: Dict[str, Any]) -> "Durum":
        dersler = {}
        for ders_kodu, ham in (veri.get("dersler") or {}).items():
            alanlar = {a: ham[a] for a in DersDurumu.__dataclass_fields__ if a in ham}
            # Konular sözlüğü JSON'da düz sözlük olarak durur; nesneye çeviriyoruz.
            ham_konular = alanlar.pop("konular", None) or {}
            ders_durumu = DersDurumu(**alanlar)
            ders_durumu._bilinmeyen = _bilinmeyenler(ham, DersDurumu)
            for konu_kodu, konu_ham in ham_konular.items():
                konu_alanlar = {a: konu_ham[a]
                                for a in KonuDurumu.__dataclass_fields__
                                if a in konu_ham}
                konu_durumu = KonuDurumu(**konu_alanlar)
                konu_durumu._bilinmeyen = _bilinmeyenler(konu_ham, KonuDurumu)
                ders_durumu.konular[konu_kodu] = konu_durumu
            dersler[ders_kodu] = ders_durumu
        for ders_kodu in DERSLER:
            dersler.setdefault(ders_kodu, DersDurumu())
        alanlar = {a: veri[a] for a in cls.__dataclass_fields__ if a in veri}
        alanlar["dersler"] = dersler
        durum = cls(**alanlar)
        durum._bilinmeyen = _bilinmeyenler(veri, cls, ("_surum", "_uygulama"))
        try:
            durum._okunan_surum = int(veri.get("_surum") or 0)
        except (TypeError, ValueError):
            durum._okunan_surum = 0
        if "rutbe_tabani" not in veri:
            # Yildiz rutbesinden onceki kayit: kazandigi rutbe korunur.
            durum.rutbe_tabani = rutbe_basamagi(durum.oynanan_gorev,
                                                RUTBELER_GOREV)
        if "kesfedilen_konular" not in veri:
            # Önceki sürümde çalışılmış konu adlarını yeniden kilitleme.
            durum.kesfedilen_konular = [ders + ":" + konu
                                       for ders, dd in dersler.items()
                                       for konu, kd in dd.konular.items() if kd.baslanmis]
        if "zorluk" not in veri:
            # Eski kayıttaki düzeyi silmeden, alanların
            # ortalama iç düzeyini yeni beşli ölçeğe taşıyoruz.
            ortalama = sum(d.kademe for d in dersler.values()) / max(1, len(dersler))
            durum.zorluk = kademe_zorlugu(int(round(ortalama)))
        for kaynak in KAYNAKLAR:
            durum.kaynaklar.setdefault(kaynak, 0)
        return durum

    # ------------------------------------------------------------- dikkat
    def ustaliklari_damgala(self) -> int:
        """
        Oturmus her konuya, hangi kademede oturdugunu isaretler.

        Damganin ASIL yazilma yeri burasidir. Konu oturma ani `ilerleme.py`
        icinde gecer ama orasi kademeyi damgalamaz; bu yuzden damga, oturmus
        konularin sayildigi ilk yerde -- yani her gorev sonrasi calisan
        `oturmus_oran` icinde -- toplu olarak vurulur. Bir gorev gecikmesi
        onemsiz: tavan zaten gorevden sonra yeniden hesaplanir.

        Ayni cagri eski kayitlari da onarir: `oturdugu_kademe == 0` olan
        oturmus konular ogrencinin mevcut kademesine yazilir.

        Kac konunun damgasi degisti, onu doner.
        """
        damgalanan = 0
        for ders in self.dersler.values():
            for konu in ders.konular.values():
                if konu.kademeyi_damgala(ders.kademe):
                    damgalanan += 1
        return damgalanan

    @property
    def oturmus_oran(self) -> float:
        """
        Baslanmis konularin ne kadari HALA oturmus? 0.0 - 1.0.

        "Hala" onemli: konu oturdugu kademeden `USTALIK_KADEME_TOLERANSI`
        kademeden fazla uzaklastiysa artik oturmus sayilmaz, yeniden
        ogrenilecek sayilir -- cunku ayrinti kademeyle artiyor. Boylece sinif
        atlayan ogrencinin dikkat tavani kendiliginden ve GUCLU bicimde
        yukselir; elle sifirlama gerekmez.
        """
        self.ustaliklari_damgala()
        baslanmis = oturmus = 0
        for ders in self.dersler.values():
            for konu in ders.konular.values():
                if konu.baslanmis:
                    baslanmis += 1
                    if konu.tamamlandi and ustalik_gecerli_mi(
                            konu.oturdugu_kademe, ders.kademe):
                        oturmus += 1
        if baslanmis < EN_AZ_KONU_ICIN_TAVAN:
            # Cok az konu varken oran gurultudur: iki konudan biri oturunca
            # ogrenci "yarisini biliyor" sayilip tavani yariya inmemeli.
            return 0.0
        return oturmus / baslanmis

    def dikkat_tavani(self) -> int:
        """Ustalikla ters orantili dikkat tavani."""
        oran = max(0.0, min(1.0, self.oturmus_oran))
        tavan = DIKKAT_BASLANGIC - (DIKKAT_BASLANGIC - DIKKAT_TABANI) * oran
        return int(round(tavan))

    def dikkati_hazirla(self) -> int:
        """Eski kayitlarda ve ilk aciliste havuzu tavana esitler."""
        if self.dikkat < 0:
            self.dikkat = self.dikkat_tavani()
        return self.dikkat

    def dikkat_ekle(self, zorluk: int) -> int:
        """Gorev bitince dikkat geri verir. Zor gorev daha cok verir.

        Kullanicinin istegi: "gorevin zorluguna gore dolum miktari artabilir."
        Bu §0'a uyuyor -- zorlanan ogrenci cezalandirilmiyor, kaynagini geri
        kazaniyor. Dolum gercek zamana degil GOREVE bagli: gercek zamana
        baglanirsa beklemek odullendirilir ve 40 dakikalik derste ise yaramaz.
        """
        self.dikkati_hazirla()
        kazanc = DIKKAT_DOLUM.get(int(zorluk), 1)
        tavan = self.dikkat_tavani()
        onceki = self.dikkat
        self.dikkat = min(tavan, self.dikkat + kazanc)
        return self.dikkat - onceki

    def dikkat_harca(self, bedel: int) -> bool:
        """Yeterliyse harcar ve True doner."""
        self.dikkati_hazirla()
        if self.dikkat < bedel:
            return False
        self.dikkat -= bedel
        return True

    # ---------------------------------------------------------------- kimlik
    def kimlik(self) -> str:
        """
        Kayıt dosyasını belirleyen ad.

        Numara varsa kimlik "sinif-numara" olur; okulda aynı adlı iki öğrenci
        bu sayede ayrı dosyalara yazar. Numara yoksa eski davranış korunur ve
        kimlik öğrencinin adıdır - evde oynayanın ya da eski kayıtların
        bozulmaması için.
        """
        if self.kayit_adi:
            return dosya_adi_yap(self.kayit_adi)
        if self.numara:
            parcalar = [p for p in ((self.sinif or "").strip(), self.numara) if p]
            return dosya_adi_yap("-".join(parcalar))
        return dosya_adi_yap(self.ad)

    def pin_kur(self, pin: str) -> None:
        self.pin_ozeti = guclu_ozet(pin) if pin else ""

    def pin_dogru_mu(self, pin: str) -> bool:
        """PIN konulmamışsa herkes girebilir; konulmuşsa eşleşmeli."""
        if not self.pin_ozeti:
            return True
        dogru, yenile = ozet_dogru_mu(pin, self.pin_ozeti, self.kimlik())
        if dogru and yenile:
            self.pin_ozeti = guclu_ozet(pin)    # eski kayit: bir sonraki kayitta yeni bicim
        return dogru

    def dosya_yolu(self) -> str:
        return os.path.join(KAYIT_KLASORU, self.kimlik() + ".json")

    def kaydet(self) -> str:
        # Kayit silindiyse (B36.16, "Kaydimi sil") bellekteki durum diske
        # GERI YAZILMAZ. Yoksa silmeden sonra calisan herhangi bir kaydet --
        # cokme korumasi, oturum sonu -- silinen kaydi sessizce diriltir.
        if getattr(self, "_silindi", False):
            return ""
        self.son_oynama = time.time()
        os.makedirs(KAYIT_KLASORU, exist_ok=True)
        yol = self.dosya_yolu()
        if (getattr(self, "_okunan_surum", 0) > KAYIT_SURUMU
                and not getattr(self, "_yedeklendi", False)):
            # Kayıt bu oyundan YENİ bir sürümle yazılmış. Bilinmeyen alanlar
            # korunuyor, ama yeni sürüm bir alanın ANLAMINI da değiştirmiş
            # olabilir; ilk yazmadan önce olduğu gibi bir kopya kalsın.
            if os.path.exists(yol) and not os.path.exists(yol + YENI_SURUM_YEDEGI):
                shutil.copy2(yol, yol + YENI_SURUM_YEDEGI)
            self._yedeklendi = True
        gecici = yol + ".tmp"
        with open(gecici, "w", encoding="utf-8") as dosya:
            json.dump(self.sozluge(), dosya, ensure_ascii=False, indent=2)
        os.replace(gecici, yol)  # yarıda kesilirse eski kayıt bozulmasın
        _kalici_kil(yol)
        return yol


# --------------------------------------------------------------------------
# Kaydın GERÇEKTEN kalıcı olması
# --------------------------------------------------------------------------
# Bilgisayarda `os.replace` bitince dosya diskte olur; yapacak bir şey yok.
#
# TARAYICIDA ÖYLE DEĞİL. Oyun orada sanal bir dosya sisteminde çalışıyor;
# yazdığı şey ancak `FS.syncfs` çağrılınca IndexedDB'ye iniyor. O çağrı
# yapılmazsa dosya yalnızca bellekte kalır ve sekme kapanınca yok olur.
#
# 9 Eylül 2026'da ölçüldü: oyun "✔ Kaydedildi" yazıyor, IndexedDB'nin
# FILE_DATA deposu BOŞ kalıyordu. Eşitleme yalnızca oyun temiz kapanınca
# ya da sekme gizlenince yapılıyordu. Telefonda bu istisna değil kural --
# Android arka plandaki sekmeyi kendi kararıyla öldürür ve öğrenci
# ilerlemesini kaybeder. Öğrenci için en kötü hata bu.
#
# Motor tarayıcıyı BİLMİYOR: burada yalnızca "kayıt yazıldı" diye haber
# veren bir kanca var. Bilgisayarda hiçbir şey yapmıyor; tarayıcı kabuğu
# açılışta kendi işlevini takıyor (bkz. mobil/isci.js). Ekran için
# kurulan kabuk deseninin aynısı -- TASARIM_NOTLARI §8.
_KAYIT_KANCASI = None


def kayit_kancasi_ata(kanca) -> None:
    """Kayıt yazıldıktan sonra çağrılacak işlevi takar. None = kanca yok."""
    global _KAYIT_KANCASI
    _KAYIT_KANCASI = kanca


def _kalici_kil(yol: str, silindi: bool = False) -> None:
    if _KAYIT_KANCASI is None:
        return
    try:
        _KAYIT_KANCASI(yol, silindi)
    except Exception:          # noqa: BLE001
        # Eşitleme başarısızsa oyun DURMAMALI: dosya bellekte duruyor ve
        # sekme kapanırken bir şans daha var. Öğrenciye burada hata
        # göstermek, yapabileceği bir şey olmadığı için işe yaramaz.
        pass


# --------------------------------------------------------------------------
# Kayıt dosyası işlemleri
# --------------------------------------------------------------------------

_GECERSIZ = '<>:"/\\|?*'


def dosya_adi_yap(ad: str) -> str:
    temiz = "".join("_" if h in _GECERSIZ else h for h in (ad or "kasif")).strip()
    temiz = temiz.replace(" ", "_")
    return temiz[:40] or "kasif"


def benzersiz_kayit_adi(ad: str) -> str:
    """
    Numarasız bir oyuncu için kayıt klasöründe boşta olan bir ad üretir.

    Neden gerekli: numarasız kayıtta kimlik öğrencinin ADIYDI. Aynı evde iki
    "Ali" oynarsa ikincisi birincinin dosyasına yazıyor ve ilerlemesi
    siliniyordu. Sınıf/numara sorusu okul dışındakilerden kaldırılınca bu
    durum istisna olmaktan çıkıp olağan hâle geldi.

    İlk oyuncu adını olduğu gibi alır ("ali"); ikincisi "ali-2" olur. Numara
    eklemek rastgele son ekten iyidir: dosya adı hâlâ insan okuyabilir ve
    öğretmen klasöre baktığında kimin kim olduğunu çıkarabilir.
    """
    taban = dosya_adi_yap(ad)
    aday = taban
    sayac = 2
    while os.path.exists(os.path.join(KAYIT_KLASORU, aday + ".json")):
        aday = "{}-{}".format(taban, sayac)
        sayac += 1
        if sayac > 999:          # olmaz ama sonsuz döngü de bırakılmaz
            return "{}-{}".format(taban, int(time.time()))
    return aday


def pin_ozetle(pin: str, tuz: str) -> str:
    """
    PIN'i geri çevrilemez bir özete indirger.

    Amaç kayıt dosyasını açan birinin PIN'i çıplak gözle okumaması. Bu bir
    güvenlik çözümü değildir: dosyaya yazma yetkisi olan kişi özeti silip
    PIN'i kaldırabilir. Okul ağında gerçek koruma isteniyorsa iş sunucuya
    taşınmalı.
    """
    ham = "{}|{}".format(tuz, (pin or "").strip())
    return hashlib.sha256(ham.encode("utf-8")).hexdigest()


# Yeni kayitlar PBKDF2-HMAC-SHA256 + rastgele tuz kullanir (dusuk tuzlu tek tur
# SHA-256 kayit dosyasini okuyanin cevrimdisi hizla kirabilecegi bir ozetti).
# Bicim: "pbkdf2_sha256$<tur>$<tuz hex>$<ozet hex>". Eski (tuzlu SHA-256, 64
# onaltilik hane) ozetler okunmaya devam eder ve ilk dogru giriste yenilenir.
PBKDF2_TUR = 200_000
_PBKDF2_ONEK = "pbkdf2_sha256$"


def _pbkdf2(sifre: str, tuz: bytes, tur: int) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", (sifre or "").strip().encode("utf-8"), tuz, tur)


def guclu_ozet(sifre: str) -> str:
    """PIN/parola icin rastgele tuzlu PBKDF2 ozeti (geri cevrilemez)."""
    tuz = os.urandom(16)
    return "{}{}${}${}".format(_PBKDF2_ONEK, PBKDF2_TUR, tuz.hex(),
                               _pbkdf2(sifre, tuz, PBKDF2_TUR).hex())


def ozet_dogru_mu(sifre: str, kayitli: str, eski_tuz: str) -> Tuple[bool, bool]:
    """(dogru mu, yeni bicime yenilenmeli mi). Eski ve yeni bicimi dogrular."""
    kayitli = kayitli or ""
    if kayitli.startswith(_PBKDF2_ONEK):
        try:
            _, tur, tuz, ozet = kayitli.split("$")
            tur, tuz, ozet = int(tur), bytes.fromhex(tuz), bytes.fromhex(ozet)
        except ValueError:
            return False, False
        if not 1 <= tur <= 5_000_000:          # bozuk/kotu kayit sunucuyu kilitlemesin
            return False, False
        return hmac.compare_digest(_pbkdf2(sifre, tuz, tur), ozet), False
    dogru = hmac.compare_digest(pin_ozetle(sifre, eski_tuz), kayitli)
    return dogru, dogru


def numarayla_bul(numara: str, sinif: str = "") -> List[Dict[str, Any]]:
    """Verilen öğrenci numarasına ait kayıt özetlerini döner."""
    aranan = (numara or "").strip().lower()
    if not aranan:
        return []
    bulunan = []
    for ozet in kayitlari_listele():
        if (ozet.get("numara") or "").strip().lower() != aranan:
            continue
        if sinif and sinif.strip().lower() not in (ozet.get("sinif") or "").lower():
            continue
        bulunan.append(ozet)
    return bulunan


def kayitlari_listele() -> List[Dict[str, Any]]:
    """Kayıt klasöründeki dosyaların özetini döner."""
    if not os.path.isdir(KAYIT_KLASORU):
        return []
    ozetler = []
    for dosya_adi in sorted(os.listdir(KAYIT_KLASORU)):
        if not dosya_adi.endswith(".json"):
            continue
        yol = os.path.join(KAYIT_KLASORU, dosya_adi)
        try:
            with open(yol, encoding="utf-8") as dosya:
                veri = json.load(dosya)
            # Klasörde öğrenci kaydı olmayan JSON'lar da bulunabilir
            # (öğretmen parolası gibi). Ada göre değil YAPIYA göre eliyoruz:
            # her öğrenci kaydında "dersler" sözlüğü vardır.
            if not isinstance(veri, dict) or "dersler" not in veri:
                continue
            ozetler.append({
                "dosya": dosya_adi,
                "ad": veri.get("ad", "?"),
                "sinif": veri.get("sinif", ""),
                "numara": veri.get("numara", ""),
                "sinif_kodu": veri.get("sinif_kodu", ""),
                "okul": veri.get("okul", ""),
                "pinli": bool(veri.get("pin_ozeti")),
                "bolum": veri.get("bolum", 0),
                # Takma ad ve pano tercihi. OGRENCIYE GIDEN hicbir ekran
                # "takma"yi gercek adla YAN YANA basmamali; bu anahtar sinif
                # panosu (yalnizca takma) ve ogretmenin bildirimli ifsasi icin.
                "takma": veri.get("takma_ad", "") or "",
                "panoda": bool((veri.get("ayarlar") or {}).get(
                    "panoda_gorun", True)),
                "gorev": veri.get("oynanan_gorev", 0),
                # Sinif panosu rutbeyle ayni olcuyu kullansin: toplam yildiz.
                "yildiz": sum(int((dd or {}).get("toplam_yildiz", 0) or 0)
                              for dd in (veri.get("dersler") or {}).values()),
                "son": veri.get("son_oynama", 0),
                # Saklama suresi (B36.16): son_oynama olmayan ESKI kayitta
                # yedek tarih. Bkz. araclar/kvkk.son_oynama_zamani.
                "ilk": veri.get("ilk_oynama", 0),
                "yol": yol,
            })
        except Exception:
            continue
    ozetler.sort(key=lambda o: o.get("son", 0), reverse=True)
    return ozetler


def yukle(yol: str) -> Optional[Durum]:
    try:
        with open(yol, encoding="utf-8") as dosya:
            veri = json.load(dosya)
        durum = Durum.sozlukten(veri)
    except Exception:
        return None
    # Hangi dosyadan acildigi (diske YAZILMAZ: dataclass alani degil).
    # Dosya adi kimlikle tutmayabilir (elle kopyalanmis ya da yeniden
    # adlandirilmis kayit); "Kaydimi sil" o dosyayi da silmeli (B36.16).
    durum._okunan_yol = yol
    return durum


def sil(yol: str) -> bool:
    try:
        os.remove(yol)
    except Exception:
        return False
    # Silme de kalici olmali: yoksa tarayicida silinen kayit bir sonraki
    # acilista geri geliyor.
    _kalici_kil(yol, silindi=True)
    return True


def kademe_adi(kademe: int) -> str:
    return KADEME_ADLARI.get(int(kademe), str(kademe))
