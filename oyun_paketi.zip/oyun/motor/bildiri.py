# -*- coding: utf-8 -*-
"""
Öğretmenden öğrenciye bildirim. Şimdilik tek türü var: takma ad görüldü.

Kullanıcı: öğretmen "gizlileri göster" deyince takma adları da görür ve
"bunu yaptığında gördüğü öğrencilere de bildirim gider: 'şu ders
bölümünden şu hoca sizin takma adınızı gördü' diye. Çünkü bir oyuncu
için takma ad kendi kimliğidir."

NEDEN AYRI DOSYA
----------------
Bildirim öğrencinin kayıt dosyasına yazılsaydı: öğretmen masadan yazar,
öğrenci o sırada oyundaysa -- ki ders sırasında olağan durum budur --
oyunun bir sonraki otomatik kaydı bellekteki eski durumu diske basar ve
bildirim SİLİNİR. Kimse fark etmez; öğretmen "bildirildi" görmüştür.
Bu projenin en sık hatası tam bu türden: sistem yaptım der, yapmamıştır.

Bu yüzden bildirim `kayitlar/bildiriler/<kimlik>.json` içinde durur ve
yalnızca öğretmen yazar. Öğrenci okuduğunu KENDİ kaydına not eder
(`Durum.okunan_bildiriler`); iki taraf aynı dosyaya hiç yazmaz.

ÇEKME, İTME DEĞİL
-----------------
Öğrenci bildirimi oyunu bir sonraki açışında görür. Öğretmene "gönderildi"
değil "bırakıldı; öğrenci oyunu açınca görecek" denir -- söylenen şey
kodun tutabildiği şeydir.

TELEFONDA ÇALIŞMAZ. Öğretmen masası telefondaki kayıtları hiç göremez
(tarayıcının kendi deposunda dururlar), dolayısıyla orada ne gerçek ad
ne takma ad ifşa edilebilir. Ortak klasörlü kurulum içindir.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import time
from typing import Any, Dict, List, Optional

from . import durum as durum_modulu

AZAMI_BILDIRI = 50
AZAMI_OKUNAN = 200
TAKMA_AD_GORULDU = "takma_ad_goruldu"


def bildiri_klasoru() -> str:
    return os.path.join(durum_modulu.KAYIT_KLASORU, "bildiriler")


def _yol(kimlik: str) -> str:
    return os.path.join(bildiri_klasoru(), kimlik + ".json")


def bildirileri_sil(kimlik: str) -> bool:
    """Öğrencinin bildirim dosyasını siler (kaydı silinirken, B36.16).

    Bildirimde öğretmenin adı ve dersi yazar; kayıt silinip bu dosya kalırsa
    öğrenciye ait bir iz klasörde durmaya devam eder. Dosya yoksa True.
    """
    try:
        os.remove(_yol(kimlik))
    except FileNotFoundError:
        return True
    except OSError:
        return False
    return True


def bildirileri_oku(kimlik: str) -> List[Dict[str, Any]]:
    try:
        with io.open(_yol(kimlik), encoding="utf-8") as dosya:
            veri = json.load(dosya)
    except (OSError, ValueError):
        return []
    if not isinstance(veri, list):
        return []
    return [b for b in veri if isinstance(b, dict) and b.get("no")]


def bildiri_yaz(kimlik: str, metin: str, tur: str = TAKMA_AD_GORULDU,
                ek: Optional[Dict[str, Any]] = None) -> bool:
    """Bildirimi bırakır. Yazamazsa False -- asla sessizce True demez."""
    ham = "{}|{}|{}|{}".format(kimlik, tur, metin, time.time())
    bildiri = {
        "no": hashlib.sha256(ham.encode("utf-8")).hexdigest()[:16],
        "tur": tur,
        "metin": metin,
        "zaman": time.strftime("%d.%m.%Y %H:%M"),
    }
    if ek:
        bildiri.update(ek)
    try:
        os.makedirs(bildiri_klasoru(), exist_ok=True)
        liste = bildirileri_oku(kimlik)
        liste.append(bildiri)
        gecici = _yol(kimlik) + ".tmp"
        with io.open(gecici, "w", encoding="utf-8") as dosya:
            json.dump(liste[-AZAMI_BILDIRI:], dosya, ensure_ascii=False,
                      indent=2)
        os.replace(gecici, _yol(kimlik))
    except OSError:
        return False
    return True


def okunmamislar(durum) -> List[Dict[str, Any]]:
    okunan = set(durum.okunan_bildiriler or [])
    return [b for b in bildirileri_oku(durum.kimlik()) if b["no"] not in okunan]


def okundu_isaretle(durum, bildiriler: List[Dict[str, Any]]) -> None:
    for bildiri in bildiriler:
        if bildiri["no"] not in durum.okunan_bildiriler:
            durum.okunan_bildiriler.append(bildiri["no"])
    del durum.okunan_bildiriler[:-AZAMI_OKUNAN]


def takma_ad_metni(ogretmen: str, ders: str) -> str:
    """Öğrenciye giden cümle. Öğretmene de BİREBİR bu gösterilir."""
    return "{} dersinden {} takma adını gördü.".format(ders, ogretmen)
