# -*- coding: utf-8 -*-
"""
Tarih görevleri.

Çerçeve: KRONOGRAF. Üsse geçmişten kayıt parçaları geliyor - bir çarşı
gürültüsü, bir tablet, bir alet, bir mektup. Kronograf hangi çağdan geldiğini
söylemez.

Bu yüzden bu derste öğrenciye "Malazgirt kaç yılındaydı?" diye sorulmaz.
Öğrenciye bir kayıt verilir; içindeki teknoloji, malzeme, unvan ve alışkanlık
izlerinden dönemi kendisi çıkarır. Tarih burada ezberlenecek bir liste değil,
kanıttan sonuca giden bir akıl yürütmedir.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, coklu_siklar, model_adimi, sayi_adimi, secim_adimi,
    sirala_adimi, yorum_adimi,
)


# ==========================================================================
# KRONOGRAF KAYITLARI - kanıttan dönem çıkarma
# ==========================================================================

# Her kaydın belirleyici izi, o dönemi diğerlerinden ayıran teknolojik eşiktir.
_DONEMLER = [
    {
        "ad": "Neolitik Çağ (ilk tarım köyleri)",
        "aralik": "yaklaşık MÖ 8000",
        "sahne": (
            "Alçak, yan yana yapışık kerpiç evler. Damlardan girilip "
            "çıkılıyor. Bir kadın taş bir tekneye arpa döküp başka bir taşla "
            "eziyor. Avluda birkaç koyun bağlı duruyor; kimse onları avlamıyor, "
            "besliyor."
        ),
        "izler": [
            ("Alet incelemesi",
             "Aletlerin hepsi taştan ve kemikten. Hiçbirinde metal yok.", True),
            ("Yazı araması",
             "Duvarlarda boya ile yapılmış resimler var; ama hiçbir yerde yazı, "
             "işaret dizisi ya da kayıt levhası yok.", True),
            ("Tarım izi",
             "Ekilmiş tahıl tarlaları ve besiye alınmış hayvanlar görülüyor. "
             "Topluluk yerleşik.", True),
            ("Kap kacak",
             "Pişmiş topraktan çanak çömlek kullanılıyor.", False),
        ],
        "belirleyici": "Yazının hiç bulunmaması ve metal aletin olmaması",
        "belirleyici_aciklama": (
            "Yazının olmaması bu kaydı doğrudan tarih öncesine yerleştirir; "
            "metalin hiç bulunmaması ise Maden çağlarından da önce olduğunu "
            "gösterir. Yerleşik tarım ise Neolitik'in tanımıdır."
        ),
        "secim_teshis": (
            "Neolitik'i seçtin. Bu çağın imzası hiç metal ve hiç yazı "
            "bulunmamasıdır; kayıttaki izlerde metal bir alet ya da bir "
            "işaret dizisi geçiyor mu, bir daha bak."
        ),
        "gerekce_teshis": (
            "Bu gerekçe, kayıtta ne yazı ne de metal gördüğünü söyler. "
            "Gerekçe hatırladığın çağdan değil, önündeki izlerden çıkar; "
            "kayıtta bunların ikisi de yok mu?"
        ),
    },
    {
        "ad": "Tunç Çağı Anadolu (Hitit dönemi)",
        "aralik": "yaklaşık MÖ 1300",
        "sahne": (
            "Taş temelli büyük bir yapı. Bir kâtip, ıslak kil bir levhaya "
            "ucu üçgen bir kamışla işaretler basıyor. Avluda iki atın çektiği "
            "hafif bir savaş arabası duruyor. Askerlerin baltaları sarımtırak "
            "bir metalden."
        ),
        "izler": [
            ("Kâtip levhası",
             "Islak kile kamışla basılan üçgen uçlu işaretler: çivi yazısı. "
             "Levhada bir antlaşma metni var.", True),
            ("Metal incelemesi",
             "Aletler ve silahlar tunç (bakır-kalay alaşımı). Demir silah yok.",
             True),
            ("Ulaşım",
             "İki atın çektiği iki tekerlekli hafif savaş arabası kullanılıyor.",
             False),
            ("Yapı düzeni",
             "Taş temelli anıtsal yapılar, arşiv odası, mühürler.", False),
        ],
        "belirleyici": "Çivi yazılı kil tablet ile tunç silahların birlikte bulunması",
        "belirleyici_aciklama": (
            "Yazının varlığı kaydı tarihî çağlara taşır. Silahların demir değil "
            "tunç olması ise Demir Çağı'ndan önce olduğunu gösterir. İkisi "
            "birlikte dönemi oldukça dar bir aralığa sıkıştırır."
        ),
        "secim_teshis": (
            "Tunç Çağı'nı seçtin. Bu çağın imzası çivi yazılı kil tablet ile "
            "tunç -demir değil- silahların BİRLİKTE bulunmasıdır; kayıtta bu "
            "ikisini de görüyor musun?"
        ),
        "gerekce_teshis": (
            "Bu gerekçe, kayıtta hem çivi yazılı tablet hem tunç silah "
            "gördüğünü söyler. Gerekçe kanıta bağlıdır: kayıtta böyle bir "
            "tablet ya da tunç alet geçiyor mu?"
        ),
    },
    {
        "ad": "Roma dönemi Akdeniz kenti",
        "aralik": "yaklaşık MS 100",
        "sahne": (
            "Taş döşeli geniş bir cadde. Kemerli bir su yolu şehre su "
            "taşıyor. Bir tüccar, üzerinde imparator başı basılı madenî "
            "paralarla ödeme alıyor. Katip papirüs tomarına hesap yazıyor."
        ),
        "izler": [
            ("Ödeme aracı",
             "Alışverişte takas yok; üzerinde bir hükümdar portresi basılı "
             "madenî sikkeler kullanılıyor.", True),
            ("Su yapısı",
             "Kemerli su kemerleri (su yolları) şehre kilometrelerce uzaktan "
             "su getiriyor.", True),
            ("Yazı malzemesi",
             "Kayıtlar papirüs tomarlarına ve mumlu tabletlere tutuluyor. "
             "Kâğıt ya da matbaa izi yok.", True),
            ("Yapı tekniği",
             "Yuvarlak kemer ve beton kullanımı yaygın.", False),
        ],
        "belirleyici": "Basılı sikke ve kemerli su yolu birlikteliği",
        "belirleyici_aciklama": (
            "Madenî para, örgütlü bir devlet ve gelişmiş ticaret demektir. "
            "Kemerli su yolları ise büyük ölçekli mühendislik gerektirir. "
            "Kâğıdın ve matbaanın yokluğu üst sınırı belirler."
        ),
        "secim_teshis": (
            "Roma dönemini seçtin. Bu dönemin ayırt edici izleri hükümdar "
            "portresi basılı madenî sikke ile kemerli su yoludur; kayıtta "
            "bunlar geçiyor mu?"
        ),
        "gerekce_teshis": (
            "Bu gerekçe, kayıtta basılı sikke ve kemerli su yolu gördüğünü "
            "söyler. Kayıtta bunlar yoksa gerekçen elindeki kaydı değil, "
            "aklındaki başka bir sahneyi anlatıyor demektir."
        ),
    },
    {
        "ad": "Sanayi Devrimi dönemi",
        "aralik": "yaklaşık 1850",
        "sahne": (
            "Bacalarından duman çıkan uzun bir yapı. İçeride onlarca tezgâh "
            "aynı anda dönüyor; hepsi tavandaki tek bir milden güç alıyor. "
            "Dışarıda demir raylar üzerinde buhar püskürten bir makine "
            "vagonları çekiyor. Duvarda büyük bir saat asılı; işçiler ona "
            "göre giriyor çıkıyor."
        ),
        "izler": [
            ("Güç kaynağı",
             "Tezgâhlar insan ya da hayvan gücüyle değil, buhar makinesiyle "
             "çalışıyor.", True),
            ("Ulaşım",
             "Demir raylar üzerinde buharlı lokomotif; yükler kara yolundan "
             "çok daha hızlı taşınıyor.", True),
            ("Çalışma düzeni",
             "İş, güneşe göre değil duvardaki saate göre bölünmüş. Vardiya "
             "kavramı var.", False),
            ("Haberleşme",
             "Şehirler arasında tel üzerinden işaret gönderen bir düzenek "
             "(telgraf) kullanılıyor.", False),
        ],
        "belirleyici": "Buhar gücüyle çalışan makineler ve demiryolu",
        "belirleyici_aciklama": (
            "Buhar makinesinin üretime ve ulaşıma girmesi Sanayi Devrimi'nin "
            "tanımlayıcı eşiğidir. Bundan önce üretim insan, hayvan, su ve "
            "rüzgâr gücüne dayanıyordu."
        ),
        "secim_teshis": (
            "Sanayi Devrimi'ni seçtin. Bu dönemin eşiği buhar gücünün "
            "üretime ve ulaşıma girmesidir; kayıtta buharla çalışan bir "
            "makine ya da demir ray geçiyor mu?"
        ),
        "gerekce_teshis": (
            "Bu gerekçe, kayıtta buhar makinesi ve demiryolu gördüğünü "
            "söyler. Kayıtta buhar ya da ray yoksa bu gerekçe senin "
            "gözlemine değil, bir başka kayda aittir."
        ),
    },
]


@bulmaca(ders="tarih", konu="donem_tespiti", kademeler=(4, 12), agirlik=1.6)
def kronograf_kaydi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kronograf bir sahne getirdi; hangi çağdan olduğu kanıtlardan çıkarılacak."""
    donem = rastgele.choice(_DONEMLER)
    digerleri = [d for d in _DONEMLER if d["ad"] != donem["ad"]]
    rastgele.shuffle(digerleri)

    kanitlar = [Kanit(etiket, icerik, bedel=2 if kritik else 1, kritik=kritik)
                for etiket, icerik, kritik in donem["izler"]]
    kanitlar.append(Kanit(
        "Kronograf çıktısı",
        "KAYIT ALINDI.\nSüre: 3 dakika 20 saniye.\nDÖNEM: (aygıt bu alanı "
        "boş bırakıyor)", bedel=1))

    return Bulmaca(
        kod="tar-kronograf-kaydi",
        ders="tarih",
        baslik="Kronograf Kaydı",
        kademe=kademe,
        konu="donem_tespiti",
        kazanim="Maddi kalıntılardan dönem çıkarımı; teknolojik eşiklerle tarihlendirme.",
        dikkat=7,
        brifing=(
            "Kronograf yine bir kayıt getirdi. Aygıt hangi çağdan olduğunu "
            "söylemiyor; yalnızca gördüğünü aktarıyor:\n\n"
            "\"{}\"\n\n"
            "Komutan kaydın hangi döneme ait olduğunu arşive yazmamızı "
            "istiyor. \"Tahmin yazma\" diyor, \"neye dayandığını da yaz.\""
        ).format(donem["sahne"]),
        kanitlar=kanitlar,
        adimlar=[
            model_adimi(
                soru="Bir kaydı tarihlendirirken hangi tür iz en güvenilirdir?",
                dogru=("Bir teknolojinin VARLIĞI ya da YOKLUĞU; çünkü her "
                       "teknoloji belli bir tarihten sonra ortaya çıkar ve "
                       "zaman aralığını iki uçtan sıkıştırır."),
                yanlislar={
                    "İnsanların giyimi; kıyafet her dönemde benzerdir.":
                        "Giyimi ölçüt aldın. Kıyafetin kesin bir başlangıç "
                        "tarihi yoktur; benzer bir kumaş yüzyıllar boyunca "
                        "dokunabilir. Bir alet ise ancak icat edildikten "
                        "sonra sahneye girebilir.",
                    "Sahnedeki insan sayısı; kalabalık dönemler daha yenidir.":
                        "Kalabalığı takvim yerine koydun. Bir pazar yeri her "
                        "çağda kalabalık, bir dağ köyü her çağda tenhadır; "
                        "kişi sayısı hiçbir dönemi dışarıda bırakmaz.",
                    "Yapıların büyüklüğü; büyük yapılar her zaman daha yenidir.":
                        "Büyüklüğü yenilik saydın. Piramitler ve tapınaklar "
                        "çok eski oldukları hâlde devasadır; boyut, yapının "
                        "hangi tarihten sonra mümkün olduğunu söylemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarihlendirmenin mantığı şu: bir nesne ancak icat edildikten "
                    "sonra kullanılabilir. Yazılı tabletin bulunması kaydı yazının "
                    "icadından SONRAYA taşır; demir silahın hiç bulunmaması ise "
                    "Demir Çağı'ndan ÖNCEYE. İki iz birleşince aralık daralır. "
                    "Yapı büyüklüğü ya da kalabalık böyle kesin bir sınır vermez."
                ),
                ipuclari=[
                    "Bir nesne icat edilmeden kullanılabilir mi? Bu sana ne söyler?",
                    "Bir şeyin YOK olması da bilgi verir: henüz bilinmiyor olabilir.",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="Bu kayıt hangi döneme aittir?",
                dogru="{} ({})".format(donem["ad"], donem["aralik"]),
                yanlislar={"{} ({})".format(d["ad"], d["aralik"]):
                           d["secim_teshis"] for d in digerleri},
                rastgele=rastgele,
                aciklama="Belirleyici iz: {}. {}".format(
                    donem["belirleyici"], donem["belirleyici_aciklama"]),
                ipuclari=[
                    "Kayıtta hangi teknoloji VAR, hangisi YOK? İkisini birlikte düşün.",
                    "En eski ve en yeni ihtimali ele, ortada kalanı karşılaştır.",
                ],
                puan=18,
            ),
            secim_adimi(
                soru="Arşive yazacağın gerekçe hangisi olmalı?",
                dogru=donem["belirleyici"],
                yanlislar={
                    d["belirleyici"]: d["gerekce_teshis"] for d in digerleri
                },
                rastgele=rastgele,
                aciklama=donem["belirleyici_aciklama"],
                ipuclari=["Kararını hangi tek gözlem olmadan veremezdin?"],
                puan=14,
            ),
            yorum_adimi(
                soru="Kayıtta hiç yazı görülmemesi ne anlama gelir?",
                dogru=("Ya kayıt yazının bulunmasından öncedir ya da o toplulukta "
                       "yazı kullanılmıyordur; tek başına kesin tarih vermez ama "
                       "güçlü bir sınır koyar."),
                yanlislar={
                    "Kesinlikle yazının icadından öncedir; başka açıklaması yoktur.":
                        "Sınırı kesinliğe çevirdin. Yazı görülmemesi güçlü bir "
                        "işarettir ama tek başına kanıt değildir: yazının "
                        "bilindiği çağlarda da onu kullanmayan topluluklar vardı.",
                    "Hiçbir şey ifade etmez; yazı her dönemde ender bulunur.":
                        "Bu sefer izi tümden attın. Bir şeyin bulunmaması da "
                        "bilgidir; kaydı yazının icadından öncesine doğru çeker.",
                    "Kaydın sahte olduğunu gösterir.":
                        "Eksik kanıtı sahtelik saydın. Bir izin görülmemesi "
                        "aygıtı yalancı çıkarmaz; yalnızca kaydın hangi çağdan "
                        "gelebileceğini daraltır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kanıtın yokluğu, yokluğun kanıtı değildir. Yazı görülmemesi "
                    "kaydı tarih öncesine YAKLAŞTIRIR, ama aynı dönemde yazıyı "
                    "kullanmayan topluluklar da vardı. İyi bir tarihçi bunu "
                    "'kesin' değil 'kuvvetle muhtemel' diye yazar."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Arşiv fişine yazıldı: {} ({}). Gerekçe hanesi de dolduruldu; "
            "Kronograf'ın söylemediğini biz yazdık."
        ).format(donem["ad"], donem["aralik"]),
        odul={"itibar": 8, "enerji": 4},
    )


@bulmaca(ders="tarih", konu="anakronizm", kademeler=(5, 12))
def anakronizm_avi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kronograf transkripti bozulmuş; başka çağlardan cümleler karışmış."""
    donemine_uygun = [
        "Tüccar, tunçtan dövülmüş baltayı tezgâhın üstüne koydu.",
        "Kâtip ıslak kil tablete çivi yazısıyla borcu işledi.",
        "Eşeğin heybesinde arpa ve mercimek vardı.",
        "Rahip, tapınağın önünde tören için hazırlık yapıyordu.",
        "Bir kadın koyun yününü elinde eğirip iplik yapıyordu.",
    ]
    anakronizmler = [
        "Adam cebinden çıkardığı saate bakıp geç kaldığını anladı.",
        "Çocuklar meydanın kenarında patates közlüyordu.",
        "Bir kadın matbaadan yeni çıkmış duyuru kâğıdını yüksek sesle okudu.",
        "Kervancı, gelen haberi telgrafla merkeze bildirdi.",
    ]
    secilen_uygun = rastgele.sample(donemine_uygun, 4)
    secilen_yanlis = rastgele.sample(anakronizmler, 3)
    secenekler, dogru_indeksler = coklu_siklar(rastgele, secilen_yanlis, secilen_uygun)

    return Bulmaca(
        kod="tar-anakronizm",
        ders="tarih",
        baslik="Bozuk Transkript",
        kademe=kademe,
        konu="anakronizm",
        kazanim="Anakronizmi fark etme; nesnelerin tarihsel sırasını kavrama.",
        dikkat=6,
        brifing=(
            "Kronograf bu sefer bir ses kaydı getirdi ve aygıt onu kendiliğinden "
            "yazıya döktü. Kayıt, Tunç Çağı'nda bir Anadolu kasabasının pazar "
            "yerinden (yaklaşık MÖ 1800).\n\n"
            "Ama transkriptte bir tuhaflık var: aygıt başka kayıtlardan "
            "cümleler karıştırmış. Bazı cümleler o çağda geçmesi mümkün olmayan "
            "şeyler anlatıyor.\n\n"
            "Arşive temiz bir metin bırakmadan önce yabancı cümleleri ayıklaman "
            "gerekiyor."
        ),
        kanitlar=[
            Kanit("Teknoloji tarihi çizelgesi",
                  "Kâğıt: MS 100'ler (Çin)\n"
                  "Matbaa (Avrupa): 1450'ler\n"
                  "Taşınabilir mekanik saat: 1500'ler\n"
                  "Telgraf: 1800'ler",
                  bedel=2, kritik=True),
            Kanit("Tarım tarihi notu",
                  "Patates, domates, mısır ve kakao Amerika kıtasına özgüdür; "
                  "Avrupa ve Asya'ya 1492'den sonra ulaşmıştır.",
                  bedel=2, kritik=True),
            Kanit("Tunç Çağı el kitabı",
                  "Bu dönemde: tunç aletler, çivi yazılı kil tablet, dokuma, "
                  "arpa-buğday-mercimek tarımı, koyun-keçi besisi yaygındır.",
                  bedel=1, kritik=True),
            Kanit("Aygıt arıza kaydı",
                  "Kronograf son bakımdan beri farklı kayıtları birbirine "
                  "karıştırıyor. Karışan cümle sayısı her seferinde değişiyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir cümlenin döneme ait olmadığını nasıl anlarız?",
                dogru=("Cümlede geçen nesnenin ya da uygulamanın, o tarihten "
                       "SONRA ortaya çıkmış olup olmadığına bakarız."),
                yanlislar={
                    "Cümlenin diline bakarız; eski dönemde insanlar kısa cümle kurardı.":
                        "Üslubu ölçüt aldın. Transkripti bugünkü dile döken "
                        "aygıttır; cümlenin uzunluğu konuşana değil, çeviriye "
                        "aittir. Dönemi ele veren şey cümledeki nesnedir.",
                    "Cümlede geçen kişi sayısına bakarız.":
                        "Kişi sayısını takvim yerine koydun. Bir pazar yerinde "
                        "her çağda kalabalık olabilir; bu sayı hiçbir tarihi "
                        "dışarıda bırakmaz.",
                    "Cümle şaşırtıcıysa anakronizmdir; sıradan cümleler dönemine uyar.":
                        "Şaşırtıcılığı ölçüt saydın. \"Adam saatine baktı\" "
                        "cümlesi hiç şaşırtıcı değildir ama MÖ 1800'de "
                        "imkânsızdır; sıradan görünmek döneme uygunluk demek "
                        "değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Anakronizm, bir şeyin kendi zamanından önce görünmesidir. "
                    "Tespit yöntemi tek bir soruya iner: bu nesne o tarihte var "
                    "mıydı? Cümlenin üslubu ya da inandırıcılığı ölçüt değildir; "
                    "çok doğal görünen bir cümle de anakronizm taşıyabilir."
                ),
                ipuclari=[
                    "Her cümledeki NESNEYİ tek tek çıkar: saat, patates, kâğıt...",
                    "Çizelgeye bakıp o nesnenin tarihini MÖ 1800 ile karşılaştır.",
                ],
                puan=18,
            ),
            coklu_adimi(
                soru=("Aşağıdaki cümlelerden hangileri MÖ 1800'e ait OLAMAZ? "
                      "(numaralarını yaz)"),
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Ayıklananlar ve gerekçeleri:\n"
                    "- Cep saati: taşınabilir mekanik saat 1500'lerden sonra.\n"
                    "- Patates: Amerika kıtasına özgü, Eski Dünya'ya 1492'den sonra.\n"
                    "- Matbaa kâğıdı: Avrupa'da matbaa 1450'ler.\n"
                    "- Telgraf: 1800'ler.\n"
                    "Kalan cümlelerdeki tunç, çivi yazısı, arpa, yün eğirme ise "
                    "Tunç Çağı Anadolu'suyla tam uyumludur."
                ),
                ipuclari=[
                    "Dört cümlede de dönemine uymayan tek bir nesne var; onu bul.",
                    "Amerika kıtasından gelen bitkileri unutma.",
                ],
                puan=20,
            ),
            yorum_adimi(
                soru="Patatesli cümle neden anakronizmdir?",
                dogru=("Patates Amerika kıtasına özgüdür; Anadolu'ya ancak "
                       "1492'den sonraki temaslarla ulaşmıştır."),
                yanlislar={
                    "Patates o dönemde vardı ama yalnızca zenginler yerdi.":
                        "Sorunu bulunabilirlik sandın. Patates o tarihte "
                        "Anadolu'da pahalı değildi; mesele kimin yediği değil, "
                        "bitkinin bu kıtaya henüz hiç ulaşmamış olması.",
                    "Patates pişirmek için gerekli kap kacak henüz yoktu.":
                        "Engeli mutfakta aradın. Tunç Çağı'nda pişirme kabı "
                        "vardı; eksik olan kap değil, bitkinin kendisi.",
                    "Anakronizm değildir; patates Anadolu'nun yerli bitkisidir.":
                        "Bitkinin anavatanını karıştırdın. Tarım tarihi notu "
                        "patatesin Amerika kıtasına özgü olduğunu ve Eski "
                        "Dünya'ya sonradan geldiğini söylüyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bugün mutfağımızın doğal parçası saydığımız pek çok ürün "
                    "(patates, domates, mısır, biber, kakao) Amerika kıtasından "
                    "gelmiştir. Kıtalar arası bu bitki alışverişi, Coğrafi "
                    "Keşifler'in en kalıcı sonuçlarından biridir."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Transkript temizlendi ve arşive kondu. Kronograf'ın bakımı için "
            "de talep açıldı."
        ),
        odul={"itibar": 7, "enerji": 3},
    )


# ==========================================================================
# TARİH ARİTMETİĞİ
# ==========================================================================

@bulmaca(ders="tarih", konu="tarih_aritmetigi", kademeler=(4, 9))
def yuzyil_hesabi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yıldan yüzyıla geçiş; 'yüzyıl, yılın ilk iki hanesi değildir' tuzağı."""
    yil = rastgele.choice([1071, 1176, 1453, 1492, 1789, 1839, 1923, 1200, 1600])
    yuzyil = (yil - 1) // 100 + 1
    yanlis_yuzyil = yil // 100
    olay = {
        1071: "Malazgirt Savaşı", 1176: "Miryokefalon Savaşı",
        1453: "İstanbul'un fethi", 1492: "Amerika kıtasına ulaşılması",
        1789: "Fransız İhtilali", 1839: "Tanzimat Fermanı",
        1923: "Cumhuriyet'in ilanı", 1200: "bir vakıf kaydının yazılması",
        1600: "bir ticaret antlaşmasının imzalanması",
    }[yil]

    return Bulmaca(
        kod="tar-yuzyil-hesabi",
        ders="tarih",
        baslik="Arşiv Fişi",
        kademe=kademe,
        konu="tarih_aritmetigi",
        kazanim="Yıl-yüzyıl dönüşümü; yüzyılların 1'den başlayarak sayılması.",
        dikkat=5,
        brifing=(
            "Arşivdeki fişler yüzyıla göre dizilecek. Elindeki fişte yalnızca "
            "yıl yazıyor: {} ({}).\n\n"
            "Yardımcı memur fişi \"{} . yüzyıl\" rafına koymuş; \"yılın ilk iki "
            "rakamı, bakması bile kolay\" diyor.\n\n"
            "Ama arşiv sorumlusu bu yerleştirmeden emin değil. Doğrusunu "
            "belirlemen gerekiyor."
        ).format(yil, olay, yanlis_yuzyil),
        kanitlar=[
            Kanit("Arşiv yönergesi",
                  "\"Yüzyıllar 1. yüzyıldan başlar. 1. yüzyıl 1-100 yıllarını, "
                  "2. yüzyıl 101-200 yıllarını kapsar ve böyle devam eder.\"",
                  bedel=2, kritik=True),
            Kanit("Örnek fiş - 100",
                  "100 yılı: 1. yüzyıl (çünkü 1-100 aralığındadır)",
                  bedel=1, kritik=True),
            Kanit("Örnek fiş - 101",
                  "101 yılı: 2. yüzyıl (çünkü 101-200 aralığındadır)",
                  bedel=1, kritik=True),
            Kanit("Yardımcı memurun notu",
                  "\"Yılın ilk iki rakamı yüzyılı verir. {} yılı {}. yüzyıl "
                  "olur.\"".format(yil, yanlis_yuzyil), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir yılın hangi yüzyıla ait olduğunu ne belirler?",
                dogru=("Yıl hangi yüz yıllık aralığa düşüyorsa o yüzyıldır; "
                       "aralıklar 1-100, 101-200 diye ilerler."),
                yanlislar={
                    "Yılın ilk iki rakamı doğrudan yüzyılı verir.":
                        "Memurun ezberini kural yerine koydun. Bu yol yılın "
                        "YAZILIŞINA bakıyor; yönerge ise yılın hangi yüz "
                        "yıllık aralığa düştüğünü soruyor. İkisi aynı şey değil.",
                    "Yıl 100'e bölünür, çıkan tam sayı yüzyıldır.":
                        "Bölmenin sonucunu doğrudan yüzyıl saydın. O bölme sana "
                        "kaç tam yüzlüğün geride kaldığını söyler; yıl ise "
                        "içinde bulunduğu aralığa göre adlandırılır.",
                    "Yıl 100'e bölünüp sonuç aşağı yuvarlanır.":
                        "Aşağı yuvarlama, bir aralığın ilk yılını hâlâ bir "
                        "önceki yüzyılda sayar: yönergeye göre 101 yılı 2. "
                        "yüzyılın ilk yılıdır, bu kural onu 1. yüzyılda bırakır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sayım 0'dan değil 1'den başladığı için ilk yüzyıl 1-100 "
                    "yıllarını kapsar. Bu yüzden 100 yılı hâlâ 1. yüzyıldadır, "
                    "101 ise 2. yüzyıla geçer. 'İlk iki rakam' kuralı yalnızca "
                    "tam yüzlük yıllarda yanılır ama işte tam orada yanılır."
                ),
                ipuclari=[
                    "1. yüzyıl hangi yıllarla başlar ve biter?",
                    "100 yılı 1. yüzyılda mı 2. yüzyılda mı? Yönergeye bak.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="{} yılı kaçıncı yüzyıldadır? (yalnızca sayı yaz)".format(yil),
                cevap=yuzyil,
                birim="",
                aciklama=(
                    "{} yılı, {}-{} aralığına düşer; bu da {}. yüzyıldır. "
                    "Yardımcı memurun bulduğu {} yanlıştır."
                ).format(yil, (yuzyil - 1) * 100 + 1, yuzyil * 100, yuzyil, yanlis_yuzyil),
                ipuclari=[
                    "Yıldan 1 çıkar, 100'e böl, tam kısmı al, 1 ekle.",
                    "Ya da: yıl hangi yüzlük aralığa düşüyor diye bak.",
                ],
                puan=14,
            ),
            secim_adimi(
                soru="Memurun kuralı hangi yıllarda yanlış sonuç verir?",
                dogru="Yalnızca 100'ün tam katı olan yıllarda (100, 200, 1500 gibi)",
                yanlislar={
                    "Bütün yıllarda yanlış sonuç verir.":
                        "Kuralı tümden yanlış saydın. Aynı çağ içinde kalan "
                        "tarihlerde çıkarma doğru sonucu verir; sorun yalnızca "
                        "sıfır yılının olmadığı geçişte çıkar.",
                    "Yalnızca MÖ yıllarında yanlış sonuç verir.":
                        "Hatayı tek çağa hapsettin. İki tarih de MÖ ise "
                        "çıkarma yine doğrudur; aksayan yer çağ DEĞİŞTİREN "
                        "hesaplar.",
                    "Hiçbir zaman yanlış sonuç vermez; kural doğrudur.":
                        "Kuralı sınamadan kabul ettin. Takvimde sıfır yılı "
                        "yoktur; MÖ 1'den MS 1'e bir yıl geçer, iki değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "1453 için memurun kuralı 14 der, doğrusu 15'tir - yani kural "
                    "aslında hemen her yılda bir eksik verir. Tam yüzlük yıllarda "
                    "ise (1500 gibi) tesadüfen doğru sonucu verir: 1500 gerçekten "
                    "15. yüzyıldadır. Kural tersine dönmüş bir ezberdir."
                ),
                ipuclari=["Kuralı 1500 ve 1501 yıllarında ayrı ayrı dene."],
                puan=12,
            ),
        ],
        kapanis="Fiş {}. yüzyıl rafına kaldırıldı; yönerge de panoya asıldı.".format(yuzyil),
        odul={"itibar": 5},
    )


@bulmaca(ders="tarih", konu="tarih_aritmetigi", kademeler=(6, 12))
def mo_ms_araligi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """MÖ-MÖ farkı çıkarma, MÖ-MS farkı toplamadır."""
    mo_kurulus = rastgele.choice([700, 650, 600, 550, 500])
    mo_olay = mo_kurulus - rastgele.choice([120, 150, 200, 250])
    ms_yikilis = rastgele.choice([100, 200, 250, 300])
    mo_fark = mo_kurulus - mo_olay
    toplam_omur = mo_kurulus + ms_yikilis

    return Bulmaca(
        kod="tar-mo-ms",
        ders="tarih",
        baslik="Sıfırsız Takvim",
        kademe=kademe,
        konu="tarih_aritmetigi",
        kazanim="MÖ-MS zaman aralığı hesabı; takvimin sıfır noktasının anlamı.",
        dikkat=6,
        brifing=(
            "Kronograf'ın getirdiği kayıtlar arşivde bir zaman şeridine "
            "dizilecek. Elimizde bir kent devletinin üç tarihi var:\n\n"
            "  Kuruluş: MÖ {}\n"
            "  Surların yapımı: MÖ {}\n"
            "  Yıkılış: MS {}\n\n"
            "Yardımcı memur \"hepsi sayı, çıkarırız olur biter\" deyip kuruluş "
            "ile yıkılış arasını {} yıl yazmış. Sorumlu bu sayıya itiraz ediyor."
        ).format(mo_kurulus, mo_olay, ms_yikilis, mo_kurulus - ms_yikilis),
        kanitlar=[
            Kanit("Takvim yönergesi",
                  "\"Takvimde sıfır yılı yoktur. Sayım başlangıç noktasından "
                  "geriye (MÖ) ve ileriye (MS) doğru ayrı ayrı ilerler. MÖ "
                  "yıllarında sayı BÜYÜDÜKÇE tarih ESKİLEŞİR.\"",
                  bedel=2, kritik=True),
            Kanit("Zaman şeridi çizimi",
                  "MÖ 700 ---- MÖ 500 ---- MÖ 100 ---- | ---- MS 100 ---- MS 300\n"
                  "Ok, soldan sağa doğru zamanın akışını gösteriyor.",
                  bedel=2, kritik=True),
            Kanit("Arşiv fişi",
                  "Kuruluş MÖ {}, surlar MÖ {}, yıkılış MS {}.".format(
                      mo_kurulus, mo_olay, ms_yikilis),
                  bedel=1, kritik=True),
            Kanit("Memurun hesabı",
                  "\"MÖ {} eksi MS {} eşittir {}.\"".format(
                      mo_kurulus, ms_yikilis, mo_kurulus - ms_yikilis), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İki tarih arasındaki süreyi hesaplarken hangi kural geçerlidir?",
                dogru=("Aynı çağdaysalar (ikisi de MÖ ya da ikisi de MS) sayılar "
                       "ÇIKARILIR; farklı çağdaysalar TOPLANIR."),
                yanlislar={
                    "Her durumda büyük sayıdan küçük sayı çıkarılır.":
                        "Tek bir kuralla her durumu çözmeye çalıştın. MÖ "
                        "tarihlerinde büyük sayı DAHA ESKİdir; çıkarma yönü "
                        "çağa göre değişir.",
                    "Her durumda iki sayı toplanır.":
                        "Toplama yalnızca çağ değiştiren hesaplarda anlamlı. "
                        "Aynı çağdaki iki tarihte toplama, olmayan bir süre "
                        "üretir.",
                    "MÖ tarihleri eksi işaretli sayılır ve normal çıkarma yapılır.":
                        "İyi bir fikir ama bir tuzağı var: takvimde sıfır yılı "
                        "yok. Eksi sayı gibi işlem yaparsan çağ geçişlerinde "
                        "bir yıl fazla sayarsın.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zaman şeridinde MÖ tarihleri başlangıç noktasının solunda, MS "
                    "tarihleri sağındadır. İki nokta aynı taraftaysa aralarındaki "
                    "mesafe farktır. Ayrı taraflardaysa, biri başlangıca kadar olan "
                    "mesafe, diğeri başlangıçtan itibaren olan mesafedir; ikisi "
                    "toplanır. Bu yüzden çıkarma yapmak süreyi olduğundan çok kısa "
                    "gösterir."
                ),
                ipuclari=[
                    "Zaman şeridini gözünde canlandır: iki tarih başlangıcın aynı "
                    "tarafında mı, ayrı taraflarında mı?",
                    "Ayrı taraftaki iki noktanın arası, ikisinin merkeze uzaklığının "
                    "toplamıdır.",
                ],
                puan=20,
            ),
            sayi_adimi(
                soru="Kuruluştan sur yapımına kadar kaç yıl geçmiş?",
                cevap=mo_fark,
                birim="yıl",
                aciklama=(
                    "İkisi de MÖ olduğu için çıkarma yapılır: {} − {} = {} yıl. "
                    "MÖ {} , MÖ {}'den daha yenidir; çünkü MÖ'de sayı küçüldükçe "
                    "tarih yaklaşır."
                ).format(mo_kurulus, mo_olay, mo_fark, mo_olay, mo_kurulus),
                ipuclari=["İki tarih de aynı çağda. Hangi işlem gerekir?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Kent devleti toplam kaç yıl ayakta kalmış?",
                cevap=toplam_omur,
                birim="yıl",
                aciklama=(
                    "Kuruluş MÖ {}, yıkılış MS {}. Farklı çağlarda oldukları için "
                    "toplanır: {} + {} = {} yıl. Memurun bulduğu {} sayısı, "
                    "şeridin bir yarısını hiç saymadığı için yanlıştır."
                ).format(mo_kurulus, ms_yikilis, mo_kurulus, ms_yikilis,
                         toplam_omur, mo_kurulus - ms_yikilis),
                ipuclari=[
                    "Tarihler başlangıç noktasının iki ayrı yanında.",
                    "Başlangıca kadar geçen süre + başlangıçtan sonraki süre.",
                ],
                puan=16,
            ),
            yorum_adimi(
                soru="MÖ 300 ile MÖ 100 tarihlerinden hangisi daha eskidir?",
                dogru="MÖ 300; MÖ tarihlerinde sayı büyüdükçe tarih eskiye gider.",
                yanlislar={
                    "MÖ 100; her zaman büyük sayı daha yenidir.":
                        "MS tarihlerindeki alışkanlığı MÖ'ye taşıdın. MÖ "
                        "sayıları geriye doğru sayar: sayı büyüdükçe tarih "
                        "ESKİLEŞİR.",
                    "İkisi aynı yaştadır, yalnızca yazımları farklıdır.":
                        "İki farklı yılı aynı saydın. MÖ 300 ile MÖ 100 "
                        "arasında iki yüz yıl var.",
                    "Belirlenemez; MÖ tarihleri karşılaştırılamaz.":
                        "MÖ tarihleri pekâlâ karşılaştırılır; yalnızca "
                        "sıralama yönü terstir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "MÖ, 'başlangıçtan kaç yıl önce' demektir. 300 yıl önce, 100 yıl "
                    "önceden daha eskidir. MS tarihlerinde ise tam tersi işler. "
                    "Bu ters yön, MÖ hesaplarında yapılan hataların çoğunun kaynağıdır."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Zaman şeridi düzeltildi: kent devleti {} yıl ayakta kalmış. Memurun "
            "hesabı da örnek olarak panoya asıldı - yanlışıyla birlikte."
        ).format(toplam_omur),
        odul={"itibar": 6, "enerji": 3},
    )


# ==========================================================================
# KRONOLOJİ, NEDEN-SONUÇ, KAYNAK
# ==========================================================================

@bulmaca(ders="tarih", konu="kronoloji", kademeler=(5, 12))
def kronolojik_siralama(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kronograf kayıtları karışık geldi; zaman sırasına dizilecek."""
    havuz = [
        ("Sümerlerde çivi yazısının kullanılmaya başlanması", -3200),
        ("Anadolu'da Hitit Devleti'nin kurulması", -1650),
        ("Lidyalıların madenî parayı kullanmaya başlaması", -600),
        ("Kâğıdın Çin'de üretilmesi", 105),
        ("Malazgirt Savaşı", 1071),
        ("İstanbul'un fethi", 1453),
        ("Fransız İhtilali", 1789),
        ("Türkiye Cumhuriyeti'nin ilanı", 1923),
    ]
    adet = 4 if kademe <= 6 else 5
    secilen = rastgele.sample(havuz, adet)
    rastgele.shuffle(secilen)
    secenekler = [ad for ad, _ in secilen]
    sirali = sorted(range(len(secilen)), key=lambda i: secilen[i][1])

    def yil_metni(yil):
        return "MÖ {}".format(-yil) if yil < 0 else "MS {}".format(yil)

    dogru_liste = "; ".join(
        "{} ({})".format(secilen[i][0], yil_metni(secilen[i][1])) for i in sirali)

    return Bulmaca(
        kod="tar-kronoloji",
        ders="tarih",
        baslik="Karışan Kayıtlar",
        kademe=kademe,
        konu="kronoloji",
        kazanim="Olayları kronolojik sıraya koyma; MÖ-MS sıralamasını doğru kurma.",
        dikkat=6,
        brifing=(
            "Kronograf gece boyunca çalışmış ve {} ayrı kayıt getirmiş. Ama "
            "kayıtlar sırasız: aygıt hangisini önce aldığını not etmemiş.\n\n"
            "Arşivde kayıtlar zaman sırasına göre dizilir; sırasız kayıt hiçbir "
            "işe yaramaz, çünkü hangisinin hangisine sebep olduğunu göremeyiz.\n\n"
            "Kayıtları eskiden yeniye doğru sıraya dizmen gerekiyor."
        ).format(adet),
        kanitlar=[
            Kanit("Arşiv yönergesi",
                  "\"Sıralama eskiden yeniye yapılır. MÖ tarihleri MS "
                  "tarihlerinden önce gelir; MÖ içinde sayı büyük olan daha "
                  "eskidir.\"", bedel=1, kritik=True),
            Kanit("Dönem çizelgesi",
                  "İlk Çağ: yazının bulunuşundan (MÖ 3200) Roma'nın "
                  "ikiye ayrılmasına (MS 395)\n"
                  "Orta Çağ: 395 - 1453\n"
                  "Yeni Çağ: 1453 - 1789\n"
                  "Yakın Çağ: 1789 - günümüz",
                  bedel=2, kritik=True),
            Kanit("Kronograf günlüğü",
                  "Kayıtların hepsi alınmış ve okunabiliyor; yalnızca sıraları "
                  "kayıp.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kayıtları sıralarken neye göre karar vereceksin?",
                dogru=("Her kaydın hangi çağa ve hangi yıla ait olduğuna; MÖ "
                       "kayıtları önce, MÖ içinde de büyük sayı daha önce gelir."),
                yanlislar={
                    "Kayıtların uzunluğuna; kısa kayıtlar daha eskidir.":
                        "Metin uzunluğunu tarih ölçüsü saydın. Bir olayın kaç "
                        "cümleyle anlatıldığının ne zaman olduğuyla ilgisi yok.",
                    "Kayıtların önem sırasına; büyük olaylar önce yazılır.":
                        "Önemi zamanla karıştırdın. Sıralama olayların "
                        "büyüklüğüne göre değil, gerçekleştikleri ana göre "
                        "yapılır.",
                    "Sayısal büyüklüğe; küçük sayıdan büyüğe doğru dizilir.":
                        "Sayıları düz sıraladın. MÖ tarihlerinde büyük sayı "
                        "daha eskidir; bu yüzden tek başına sayı sırası "
                        "yanıltır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kronoloji tek bir eksene dayanır: zaman. MÖ tarafında sayı "
                    "büyüdükçe geriye gidildiği için sıralama orada tersine döner. "
                    "Doğrudan 'küçükten büyüğe' dizmek MÖ kayıtlarını ters çevirir."
                ),
                ipuclari=[
                    "MÖ 3200 mü daha eski, MÖ 600 mü?",
                    "Önce her kaydın yılını yaz, sonra sırala.",
                ],
                puan=18,
            ),
            sirala_adimi(
                soru="Kayıtları en eskiden en yeniye doğru sırala (numaralarını sırayla yaz):",
                secenekler=secenekler,
                dogru_sira=sirali,
                aciklama="Doğru sıra: " + dogru_liste,
                ipuclari=[
                    "Önce MÖ olanları ayır; onlar mutlaka başta.",
                    "MÖ olanları kendi içinde büyükten küçüğe diz.",
                ],
                puan=22,
            ),
            secim_adimi(
                soru="Bu sıralamadaki en eski kayıt hangi çağa aittir?",
                dogru=(
                    "Tarih öncesi (yazıdan önce)"
                    if secilen[sirali[0]][1] < -3200 else
                    ("İlk Çağ" if secilen[sirali[0]][1] < 395 else
                     ("Orta Çağ" if secilen[sirali[0]][1] < 1453 else
                      ("Yeni Çağ" if secilen[sirali[0]][1] < 1789 else "Yakın Çağ")))
                ),
                yanlislar={
                    "Tarih öncesi (yazıdan önce)":
                        "Tarih öncesi, yazının bulunmasından ÖNCEsidir. "
                        "Elindeki kayıt yazılı olduğuna göre bu çağın dışında.",
                    "İlk Çağ":
                        "Çizelgedeki İlk Çağ aralığına bak; bu tarih o "
                        "aralığın içine düşmüyor.",
                    "Orta Çağ":
                        "Çizelgedeki Orta Çağ aralığına bak; bu tarih o "
                        "aralığın içine düşmüyor.",
                    "Yeni Çağ":
                        "Çizelgedeki Yeni Çağ aralığına bak; bu tarih o "
                        "aralığın içine düşmüyor.",
                    "Yakın Çağ":
                        "Yakın Çağ çizelgenin en son dilimi. En ESKİ kayıt "
                        "sorulmuştu; en yeni çağa bakıyorsun.",
                },
                rastgele=rastgele,
                aciklama=(
                    "En eski kayıt: {} ({}). Dönem çizelgesine göre bu tarih ilgili "
                    "çağın sınırları içindedir. Çağlar, tarihçilerin sonradan koyduğu "
                    "sınırlardır; o çağda yaşayanlar kendilerini öyle adlandırmıyordu."
                ).format(secilen[sirali[0]][0], yil_metni(secilen[sirali[0]][1])),
                ipuclari=["Dönem çizelgesindeki tarih aralıklarına bak."],
                puan=12,
            ),
        ],
        kapanis="Kayıtlar sıraya dizildi ve arşive kaldırıldı.",
        odul={"itibar": 6, "enerji": 4},
    )


@bulmaca(ders="tarih", konu="neden_sonuc", kademeler=(7, 13))
def neden_mi_sonuc_mu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir olayın nedenleri ile sonuçları karışmış."""
    nedenler = [
        "Pusula ve gemicilik bilgisinin gelişmesi",
        "İpek ve Baharat yollarının Avrupalılar için güvenli olmaktan çıkması",
        "Doğu ülkelerinin zenginliğine dair anlatıların yayılması",
        "Cesur gemicilerin ve onları destekleyen krallıkların ortaya çıkması",
    ]
    sonuclar = [
        "Atlas Okyanusu limanlarının önem kazanması, Akdeniz limanlarının gerilemesi",
        "Avrupa'ya değerli maden ve yeni bitkilerin (patates, mısır) akması",
        "Sömürge imparatorluklarının kurulması",
        "Kilise ve din adamlarının otoritesinin sarsılması",
    ]
    secilen_neden = rastgele.sample(nedenler, 3)
    secilen_sonuc = rastgele.sample(sonuclar, 3)
    secenekler, dogru_indeksler = coklu_siklar(rastgele, secilen_neden, secilen_sonuc)

    return Bulmaca(
        kod="tar-neden-sonuc",
        ders="tarih",
        baslik="Sebep Defteri",
        kademe=kademe,
        konu="neden_sonuc",
        kazanim="Tarihsel olaylarda neden ile sonucu ayırt etme.",
        dikkat=6,
        brifing=(
            "Arşivde Coğrafi Keşifler için hazırlanmış bir defter var. Defterin "
            "sol sayfasına \"nedenler\", sağ sayfasına \"sonuçlar\" yazılacakmış.\n\n"
            "Ama defteri tutan kişi acele etmiş: maddeleri alt alta tek bir "
            "listeye yazmış, hangisinin neden hangisinin sonuç olduğunu "
            "belirtmemiş.\n\n"
            "Komutan bu defteri merkeze gönderecek. Ayırmamız gerekiyor."
        ),
        kanitlar=[
            Kanit("Arşiv notu",
                  "\"Neden, olaydan ÖNCE var olan ve olayı hazırlayan durumdur. "
                  "Sonuç, olaydan SONRA ortaya çıkan değişikliktir.\"",
                  bedel=2, kritik=True),
            Kanit("Zaman kontrolü",
                  "\"Bir maddenin neden mi sonuç mu olduğunu anlamak için sor: "
                  "bu durum keşifler başlamadan önce de var mıydı, yoksa "
                  "keşifler yüzünden mi ortaya çıktı?\"",
                  bedel=2, kritik=True),
            Kanit("Defter sayfası",
                  "Sol sayfa: NEDENLER (boş)\nSağ sayfa: SONUÇLAR (boş)\n"
                  "Maddeler arka sayfaya karışık yazılmış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir maddenin neden mi sonuç mu olduğunu ne belirler?",
                dogru=("Olaya göre zamanı: olaydan önce var olan durum nedendir, "
                       "olaydan sonra ortaya çıkan değişiklik sonuçtur."),
                yanlislar={
                    "Maddenin önemi: büyük etkiler sonuç, küçükler nedendir.":
                        "Büyüklüğü ölçüt saydın. Küçük bir gelişme de büyük "
                        "bir olayı başlatabilir; belirleyici olan ZAMAN "
                        "sırası, boyut değil.",
                    "Maddenin olumlu ya da olumsuz olması: olumsuzlar nedendir.":
                        "İyi-kötü ayrımını neden-sonuç ayrımı yerine koydun. "
                        "Olumlu bir gelişme de bir olayın nedeni olabilir.",
                    "Maddenin uzunluğu ve ayrıntı düzeyi.":
                        "Metnin biçimine baktın. Bir maddenin neden mi sonuç "
                        "mu olduğu, olayın öncesinde mi sonrasında mı "
                        "gerçekleştiğine bağlıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Neden-sonuç ilişkisinin belirleyicisi zaman yönüdür. Aynı "
                    "cümle bir olayın sonucu, başka bir olayın nedeni olabilir; "
                    "bu yüzden 'hangi olaya göre' diye sormak gerekir. Önem, "
                    "büyüklük ya da olumluluk bu ayrımı kurmaz."
                ),
                ipuclari=[
                    "Kendine sor: bu durum keşifler BAŞLAMADAN önce de var mıydı?",
                    "Bir şey olayı hazırlıyorsa nedendir; olay onu doğurmuşsa sonuçtur.",
                ],
                puan=18,
            ),
            coklu_adimi(
                soru="Aşağıdakilerden hangileri Coğrafi Keşifler'in NEDENLERİDİR?",
                secenekler=secenekler,
                dogru_indeksler=dogru_indeksler,
                aciklama=(
                    "Nedenler keşiflerden önce vardı: gemicilik ve pusula bilgisi, "
                    "ticaret yollarının kapanması, doğunun zenginliğine dair "
                    "anlatılar, girişimi destekleyen krallıklar. Sonuçlar ise "
                    "keşiflerden sonra ortaya çıktı: yeni ticaret merkezleri, "
                    "Avrupa'ya akan maden ve bitkiler, sömürgecilik, otoritenin "
                    "sarsılması."
                ),
                ipuclari=[
                    "Her maddeyi 'önce mi vardı, sonra mı oldu' diye sına.",
                    "Patates ve mısırın Avrupa'ya gelmesi hangi tarafta olabilir?",
                ],
                puan=20,
            ),
            yorum_adimi(
                soru="\"Sömürge imparatorluklarının kurulması\" neden bir sonuçtur?",
                dogru=("Keşifler sayesinde ulaşılan yeni topraklarda kurulduğu "
                       "için; keşiflerden önce böyle bir yapı yoktu."),
                yanlislar={
                    "Çünkü olumsuz bir gelişmedir; olumsuzlar sonuç sayılır.":
                        "Olumsuzluğu ölçüt saydın. Bir gelişmenin sonuç "
                        "olması, iyi ya da kötü olmasına değil, olaydan SONRA "
                        "gelmesine bağlıdır.",
                    "Çünkü çok uzun sürmüştür; uzun süreli olaylar sonuçtur.":
                        "Süreyi ölçüt saydın. Kısa süren bir gelişme de sonuç "
                        "olabilir; belirleyici olan sıradaki yeri.",
                    "Aslında nedendir; sömürge arayışı keşifleri başlatmıştır.":
                        "Bu iyi bir itiraz ama zamanlamayı kaçırıyor: arayış "
                        "nedendi, İMPARATORLUKLARIN KURULMASI ise keşiflerden "
                        "sonra gelen sonuç.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Keşiflerden önce Avrupa devletlerinin okyanus ötesinde "
                    "sömürgesi yoktu; bu yapı ancak yeni kıtalara ulaşıldıktan "
                    "sonra kuruldu. Zenginlik arayışı nedendir, kurulan sömürge "
                    "düzeni ise onun sonucudur - istek ile sonuç karıştırılmamalı."
                ),
                puan=12,
            ),
        ],
        kapanis="Defter iki sayfaya ayrıldı ve merkeze temiz hâliyle gönderildi.",
        odul={"itibar": 7, "enerji": 3},
    )


@bulmaca(ders="tarih", konu="kaynak_elestirisi", kademeler=(8, 13))
def kaynak_elestirisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki çelişen anlatı; hangisi daha güvenilir ve neden."""
    yil_fark = rastgele.choice([150, 180, 200, 240])

    return Bulmaca(
        kod="tar-kaynak-elestirisi",
        ders="tarih",
        baslik="İki Anlatı",
        kademe=kademe,
        konu="kaynak_elestirisi",
        kazanim="Birincil ve ikincil kaynak ayrımı; kaynağın güvenilirliğini değerlendirme.",
        dikkat=7,
        brifing=(
            "Kronograf aynı olay için iki ayrı metin getirdi: bir kalenin "
            "kuşatma sırasında nasıl düştüğü anlatılıyor. İki metin birbirini "
            "tutmuyor.\n\n"
            "Birinci metin kuşatmayı bizzat gören bir kâtibin günlüğü. İkincisi "
            "aradan {} yıl geçtikten sonra, kaleyi alan hükümdarın torununun "
            "sarayında yazılmış bir övgü kitabı.\n\n"
            "Arşive tek bir anlatı geçecek. Hangisini temel alacağımıza karar "
            "vermemiz ve gerekçesini yazmamız gerekiyor."
        ).format(yil_fark),
        kanitlar=[
            Kanit("Metin 1 - kâtip günlüğü",
                  "Olayla aynı yıl yazılmış. Yazar kuşatma sırasında kalede "
                  "bulunmuş. Kayıpları, açlığı ve surda açılan gediği ayrıntılı "
                  "anlatıyor; kendi tarafının hatalarını da yazmış.",
                  bedel=2, kritik=True),
            Kanit("Metin 2 - saray övgü kitabı",
                  "Olaydan {} yıl sonra yazılmış. Yazar olayı görmemiş; "
                  "\"büyüklerimizden dinlediğime göre\" diye başlıyor. Kitap, "
                  "kaleyi alan hükümdarın torunu için ve onun himayesinde "
                  "yazılmış. Hiçbir hata ya da kayıp anlatılmıyor.".format(yil_fark),
                  bedel=2, kritik=True),
            Kanit("Kaynak tanımları",
                  "Birincil kaynak: olayı yaşayan ya da gören kişinin bıraktığı "
                  "kayıt.\nİkincil kaynak: olayı sonradan, başka kaynaklara "
                  "dayanarak anlatan çalışma.", bedel=2, kritik=True),
            Kanit("Arkeoloji raporu",
                  "Kale surlarında, günlükte tarif edilen yerde gedik izi "
                  "bulundu. Övgü kitabındaki \"surlara hiç dokunulmadan teslim "
                  "alındı\" ifadesiyle uyuşmuyor.", bedel=2, kritik=True),
            Kanit("Arşiv sorumlusunun notu",
                  "\"Uzun ve süslü yazılmış olması bir metni güvenilir yapmaz.\"",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir tarihî metnin güvenilirliğini asıl olarak ne belirler?",
                dogru=("Yazarın olaya yakınlığı ve tarafsızlığı: olayı görmüş mü, "
                       "anlatısında çıkarı var mı?"),
                yanlislar={
                    "Metnin uzunluğu ve dilinin güzelliği.":
                        "Biçimi güvenilirlik ölçüsü saydın. Güzel yazılmış bir "
                        "metin de yanlış olabilir; belirleyici olan yazarın "
                        "olaya ne kadar yakın olduğu.",
                    "Metnin ne kadar sonra yazıldığı önemli değildir; önemli olan "
                    "yazarın ünlü olmasıdır.":
                        "Ünü tanıklığın yerine koydun. Olaya uzak bir tanık, "
                        "ne kadar ünlü olursa olsun ikinci elden aktarır.",
                    "Metnin bugün bilinen anlatıya ne kadar uyduğu.":
                        "Ölçütü tersine çevirdin. Bugünkü anlatı zaten "
                        "kaynaklardan kuruluyor; kaynağı ona uydurmak, "
                        "kanıtı sonuca göre seçmek olur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki ölçüt öne çıkar: YAKINLIK (olayı gördü mü, ne kadar sonra "
                    "yazdı) ve TARAFSIZLIK (anlatının belli bir yönde çıkması "
                    "yazarın işine yarıyor mu). Süslü dil ve uzunluk, güvenilirlik "
                    "değil ustalık göstergesidir. \"Bugün bildiğimize uyuyor mu\" "
                    "ölçütü ise döngüseldir: bugün bildiğimiz de bu kaynaklardan gelir."
                ),
                ipuclari=[
                    "Yazarlardan biri olayı gördü, diğeri duydu. Bu neyi değiştirir?",
                    "İkinci metin kimin himayesinde yazılmış? Yazarın çıkarı var mı?",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="Hangi metin arşive temel alınmalı?",
                dogru="Kâtip günlüğü; birincil kaynaktır ve arkeolojik bulguyla uyuşur.",
                yanlislar={
                    "Saray övgü kitabı; daha kapsamlı ve düzenli yazılmıştır.":
                        "Düzeni güvenilirlik saydın. Övgü için yazılmış bir "
                        "metnin amacı bilgi vermek değil; kapsamlı olması bunu "
                        "değiştirmez.",
                    "İkisi de eşit ağırlıkta alınmalı; ortalaması yazılmalı.":
                        "Tarihte ortalama alınmaz. İki kaynak çelişiyorsa "
                        "hangisinin olaya daha yakın ve daha az çıkarı olduğu "
                        "sorulur.",
                    "Hiçbiri; çelişen kaynaklar kullanılamaz.":
                        "Çelişkiyi çıkmaz saydın. Çelişki tarihçinin işini "
                        "bitirmez, başlatır: hangisinin neden farklı "
                        "söylediğini araştırır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Günlük birincil kaynaktır: yazar olaydaydı, olayla aynı yıl "
                    "yazdı ve kendi tarafının hatalarını da kaydetti - bu, çıkarına "
                    "aykırı bilgi vermesi demektir ve güvenilirliği artırır. Üstelik "
                    "surdaki gedik izi anlatısını bağımsız olarak doğruluyor."
                ),
                ipuclari=[
                    "Hangi metin bağımsız bir kanıtla (arkeoloji) destekleniyor?",
                    "Kendi tarafının hatasını yazan bir yazar neden daha güvenilirdir?",
                ],
                puan=16,
            ),
            yorum_adimi(
                soru="Övgü kitabı tamamen çöpe mi atılmalı?",
                dogru=("Hayır; olayın kendisi için zayıf ama yazıldığı dönemin "
                       "bakışını ve hükümdar ailesinin kendini nasıl göstermek "
                       "istediğini anlatan bir kaynaktır."),
                yanlislar={
                    "Evet; güvenilir olmayan kaynak hiçbir işe yaramaz.":
                        "Taraflı kaynağı işe yaramaz saydın. Övgü kitabı "
                        "olayları çarpıtsa bile o dönemin nasıl görünmek "
                        "istediğini gösterir; bu da bir bilgidir.",
                    "Evet; ikincil kaynaklar tarihte kullanılmaz.":
                        "Böyle bir kural yok. İkincil kaynaklar dikkatle "
                        "kullanılır; atılmaz.",
                    "Hayır; aslında daha güvenilirdir, çünkü daha çok kaynağa dayanır.":
                        "Kaynak sayısını güvenilirlik saydın. Hepsi aynı "
                        "amaca hizmet ediyorsa çokluk yanlılığı azaltmaz, "
                        "çoğaltır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir kaynağın hangi soruya cevap verdiği önemlidir. Övgü kitabı "
                    "\"kuşatma nasıl geçti\" sorusuna kötü bir kaynaktır; ama "
                    "\"{} yıl sonra saray bu olayı nasıl anlatmak istiyordu\" "
                    "sorusuna birinci elden cevap verir. Tarihçi kaynağı atmaz, "
                    "hangi soru için kullanacağını seçer."
                ).format(yil_fark),
                puan=14,
            ),
        ],
        kapanis=(
            "Arşive kâtip günlüğü temel alınarak yazıldı; övgü kitabı da "
            "\"dönemin bakışı\" notuyla yanına kondu."
        ),
        odul={"itibar": 9, "enerji": 4},
    )


@bulmaca(ders="tarih", konu="donem_esikleri", kademeler=(9, 13))
def donem_esikleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir buluşun kendisi değil, TOPLUMSAL SONUCU sorulur."""
    esikler = [
        {
            "ad": "Yazının bulunması (Sümerler, yaklaşık MÖ 3200)",
            "sonuc": ("Bilginin kuşaktan kuşağa bellekle değil kayıtla "
                      "aktarılabilmesi; tarih öncesi çağların kapanması"),
            "yanlislar": [
                "İnsanların ilk kez yerleşik hayata geçmesi",
                "Ateşin kullanılmaya başlanması",
                "Tekerleğin icat edilmesi",
            ],
            "neden": ("Tarihî çağlar yazının bulunmasıyla başlatılır; çünkü "
                      "yazılı kayıt, geçmişi tanıkların ömrüyle sınırlı olmaktan "
                      "çıkarır."),
        },
        {
            "ad": "Tarıma geçiş (Neolitik, yaklaşık MÖ 8000)",
            "sonuc": ("Besinin üretilmeye başlanmasıyla yerleşik hayata geçilmesi "
                      "ve ilk köylerin kurulması"),
            "yanlislar": [
                "Yazının icat edilmesi",
                "Madenlerin işlenmeye başlanması",
                "Deniz ticaretinin doğması",
            ],
            "neden": ("İnsan besinini üretmeye başlayınca sürekli yer değiştirmesi "
                      "gerekmedi; yerleşiklik, artı ürün, iş bölümü ve nüfus artışı "
                      "bunun ardından geldi."),
        },
        {
            "ad": "Matbaanın Avrupa'da yaygınlaşması (1450'ler)",
            "sonuc": ("Kitabın ucuzlaması ve çoğalması; okuryazarlığın ve yeni "
                      "düşüncelerin hızla yayılması"),
            "yanlislar": [
                "Kâğıdın ilk kez üretilmesi",
                "Üniversitelerin ilk kez kurulması",
                "Alfabenin icat edilmesi",
            ],
            "neden": ("Matbaadan önce kitaplar tek tek elle çoğaltılıyordu; bu "
                      "onları pahalı ve ender kılıyordu. Basım, aynı metnin binlerce "
                      "kopyasını mümkün kıldı ve düşüncelerin yayılma hızını değiştirdi."),
        },
        {
            "ad": "Buhar makinesinin üretime girmesi (18. yüzyıl sonu)",
            "sonuc": ("Üretimin el tezgâhlarından fabrikalara taşınması; kentlere "
                      "göç ve işçi sınıfının doğuşu"),
            "yanlislar": [
                "Elektriğin evlere girmesi",
                "Otomobilin icat edilmesi",
                "Tarımın ilk kez başlaması",
            ],
            "neden": ("Buhar gücü, üretimi akarsu kenarına ve kas gücüne bağlı "
                      "olmaktan kurtardı. Makinenin kurulabildiği her yere fabrika "
                      "kurulabildi; bu da kentleşmeyi ve yeni bir toplumsal düzeni getirdi."),
        },
    ]
    esik = rastgele.choice(esikler)

    return Bulmaca(
        kod="tar-donem-esikleri",
        ders="tarih",
        baslik="Eşik",
        kademe=kademe,
        konu="donem_esikleri",
        kazanim="Tarihsel dönüm noktalarının toplumsal sonuçlarını değerlendirme.",
        dikkat=5,
        brifing=(
            "Komutan, arşivdeki kayıtları \"dönüm noktaları\" başlığı altında "
            "toplamak istiyor. Ama tek bir şart koyuyor:\n\n"
            "\"Bana buluşun adını yazmayın; onu zaten biliyorum. Bana bu buluşun "
            "insanların yaşayışında NEYİ değiştirdiğini yazın. Değiştirmediyse "
            "dönüm noktası değildir.\"\n\n"
            "Elindeki fişte şu yazıyor: {}"
        ).format(esik["ad"]),
        kanitlar=[
            Kanit("Arşiv ölçütü",
                  "\"Bir gelişme, ancak insanların yaşama biçimini kalıcı olarak "
                  "değiştirdiyse dönüm noktası sayılır. Tek başına teknik bir "
                  "yenilik yeterli değildir.\"", bedel=2, kritik=True),
            Kanit("Karşılaştırma notu",
                  "\"Bir eşiğin etkisini görmek için sor: bu gelişmeden ÖNCE "
                  "insanlar nasıl yaşıyordu, SONRA nasıl yaşamaya başladı?\"",
                  bedel=2, kritik=True),
            Kanit("Fiş", esik["ad"], bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir gelişmeyi \"dönüm noktası\" yapan şey nedir?",
                dogru=("İnsanların yaşama, üretme ya da bilgi aktarma biçimini "
                       "kalıcı olarak değiştirmesi."),
                yanlislar={
                    "Çok sayıda insanın o gelişmeyi duymuş olması.":
                        "Duyulmayı etki saydın. Bir gelişme yaygın olarak "
                        "bilinmeden de hayatı kökten değiştirebilir.",
                    "Gelişmenin teknik olarak karmaşık olması.":
                        "Karmaşıklığı ölçüt saydın. Çok basit bir buluş da "
                        "dönüm noktası olabilir; belirleyici olan SONRASINI ne "
                        "kadar değiştirdiği.",
                    "Gelişmenin bir savaşla aynı yıla denk gelmesi.":
                        "Aynı yıla düşmek bir bağ kurmaz. Dönüm noktasını "
                        "yapan şey rastlantı değil, yol açtığı değişim.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarihte çağ değiştiren şeyler, kendinden sonra insanların "
                    "gündelik hayatını başka türlü kuran gelişmelerdir. Teknik "
                    "karmaşıklık ya da ün, bu ölçütün yerini tutmaz: çok basit bir "
                    "buluş (mesela tohumu ekmek) çağ açabilirken, karmaşık bir alet "
                    "iz bırakmadan kaybolabilir."
                ),
                ipuclari=[
                    "Bu gelişmeden önce ve sonra insanların günü nasıl geçiyordu?",
                    "Değişen şey bir alet mi, yoksa bir yaşama biçimi mi?",
                ],
                puan=18,
            ),
            secim_adimi(
                soru="Bu eşiğin asıl sonucu hangisidir?",
                dogru=esik["sonuc"],
                yanlislar=esik["yanlislar"],
                rastgele=rastgele,
                aciklama=esik["neden"],
                ipuclari=[
                    "Şıklardan bazıları BAŞKA bir eşiğin sonucudur; onları ele.",
                    "Fişteki gelişmeyle doğrudan bağı olan değişikliği ara.",
                ],
                puan=16,
            ),
            yorum_adimi(
                soru="Aynı buluş her toplumda aynı sonucu doğurur mu?",
                dogru=("Hayır; sonucu doğuran buluşun kendisi kadar, toplumun "
                       "ekonomik ve toplumsal koşullarıdır."),
                yanlislar={
                    "Evet; teknik bir buluşun etkisi her yerde aynıdır.":
                        "Buluşu tek başına etken saydın. Aynı araç, farklı "
                        "toplumsal düzenlerde farklı sonuç doğurur.",
                    "Evet; yeter ki buluş aynı yılda ulaşsın.":
                        "Zamanlamayı tek koşul saydın. Aynı yıl ulaşsa bile "
                        "toplumun yapısı sonucu değiştirir.",
                    "Hayır; çünkü buluşlar yalnızca bulundukları ülkede kullanılır.":
                        "Doğru sonuca yanlış gerekçeyle vardın. Buluşlar "
                        "yayılır; farklı sonuç doğurmalarının sebebi "
                        "yayılmamaları değil, karşılaştıkları koşullar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı teknoloji farklı toplumlarda farklı sonuçlar verebilir. "
                    "Kâğıt Çin'de yüzyıllarca kullanıldı; Avrupa'da matbaayla "
                    "birleşince bambaşka bir etki yarattı. Tarihte 'teknoloji "
                    "belirler' demek eksik kalır; teknolojinin düştüğü zemin de belirler."
                ),
                puan=14,
            ),
        ],
        kapanis="Fiş, sonucu yazılmış hâliyle \"dönüm noktaları\" dosyasına kondu.",
        odul={"itibar": 8, "enerji": 4},
    )


# ==========================================================================
# İLKOKUL
# ==========================================================================

@bulmaca(ders="tarih", konu="kronoloji", kademeler=(1, 5))
def sandiktaki_fotograflar(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Dört fotoğraf, tarihleri yok; sıra fotoğrafların İÇİNDEKİ ipuçlarından çıkar.

    İlkokulda tarih öğretmenin en doğru yolu budur: çocuk henüz tarih
    ezberlemez ama "hangisi önce oldu" sorusunu kanıtla yanıtlayabilir.
    """
    fotograflar = [
        ("Boş bir arazi; yalnızca bir çadır ve birkaç sandık var.", 1),
        ("Aynı arazide taş temeller atılmış, duvarlar yarım.", 2),
        ("Bina bitmiş, önünde yeni dikilmiş ince bir fidan var.", 3),
        ("Aynı bina; kapısının önündeki ağaç kalınlaşmış, gölge yapıyor.", 4),
    ]
    karisik = list(fotograflar)
    rastgele.shuffle(karisik)
    secenekler = [metin for metin, _ in karisik]
    dogru_sira = [karisik.index(f) for f in sorted(fotograflar, key=lambda x: x[1])]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tar-fotograflar",
        ders="tarih",
        baslik="Sandıktaki Fotoğraflar",
        kademe=kademe,
        konu="kronoloji",
        kazanim="Kanıta dayalı sıralama; öncelik-sonralık ilişkisi kurma.",
        dikkat=5,
        brifing=(
            "Arşivde eski bir sandık bulundu. İçinde üssün kuruluşundan kalma "
            "dört fotoğraf var.\n\n"
            "Fotoğrafların arkasına tarih yazılmamış. {} \"karışık atmışlar, "
            "artık hangisi önce belli olmaz\" diyor.\n\n"
            "Ama fotoğraflara dikkatli bakınca hangisinin önce çekildiği "
            "anlaşılıyor. Sıraya dizip albüme yapıştırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Fotoğrafların arkası",
                  "Dördünde de tarih yok. Yalnızca \"Meridyen Üssü\" yazıyor.",
                  bedel=1),
            Kanit("Arşivcinin notu",
                  "\"Tarih yazmıyorsa fotoğrafın İÇİNE bakılır: bir bina yapılıyor "
                  "mu, bitmiş mi? Ağaç ince mi, kalın mı? Bunlar zamanı gösterir.\"",
                  bedel=2, kritik=True),
            Kanit("Bahçıvan defteri",
                  "\"Ağaçlar yıllar geçtikçe kalınlaşır ve büyür; incelmez.\"",
                  bedel=1, kritik=True),
            Kanit("İnşaat kaydı",
                  "\"Bir bina önce temelden başlar, sonra duvarları örülür, en "
                  "son biter. Tersi olmaz.\"", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Tarihi yazmayan fotoğrafları nasıl sıraya dizeriz?",
                dogru=("Fotoğraftaki şeylerin nasıl değiştiğine bakarak: yapılan "
                       "bina ilerler, ağaç büyür."),
                yanlislar={
                    "Fotoğrafların büyüklüğüne bakarak.":
                        "Baskı boyutunu tarih ölçüsü saydın. Boyut fotoğrafın "
                        "ne zaman çekildiğiyle ilgili değil.",
                    "Fotoğrafların renginin soluk olup olmamasına bakarak.":
                        "Solmayı takvim saydın. Solma saklama koşullarına "
                        "bağlıdır; kötü saklanan yeni bir fotoğraf da solar.",
                    "Sandıkta hangisi üstteyse o en yenisidir.":
                        "Sandıktaki sırayı kanıt saydın. Kim ne zaman koydu "
                        "bilmiyoruz; fotoğrafların İÇİNDEKİ değişimlere bakmak "
                        "gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bazı şeyler zamanla hep aynı yönde değişir: bina yapılır ama "
                    "kendiliğinden yıkılıp temele dönmez; ağaç kalınlaşır ama "
                    "incelmez. Bu tek yönlü değişimler bize sırayı söyler. "
                    "Tarihçiler de kalıntılara tam olarak böyle bakar."
                ),
                ipuclari=[
                    "Bir bina önce mi biter, önce mi temel atılır?",
                    "Ağaç zamanla incelir mi, kalınlaşır mı?",
                ],
            ),
            sirala_adimi(
                soru="Fotoğrafları en eskiden en yeniye sırala (numaraları sırayla yaz):",
                secenekler=secenekler,
                dogru_sira=dogru_sira,
                aciklama=(
                    "Doğru sıra: önce boş arazi ve çadır, sonra yarım duvarlar, "
                    "sonra biten bina ve yeni fidan, en son kalınlaşmış ağaç. "
                    "Her adımda bir şey ilerlemiş: önce yapı, sonra ağaç."
                ),
                ipuclari=[
                    "Önce hangi fotoğrafta hiç bina yok? O en eskisi.",
                    "Bina bittikten sonra hangisinde ağaç daha büyük?",
                ],
                puan=20,
            ),
            secim_adimi(
                soru="Ağacın kalınlığı bize ne söylüyor?",
                dogru="Aradan zaman geçtiğini; kalın ağacın olduğu fotoğraf daha yenidir.",
                yanlislar={
                    "Fotoğrafın daha eski olduğunu; ağaçlar zamanla incelir.":
                        "Yönü ters aldın. Ağaçlar yıllar geçtikçe kalınlaşır; "
                        "kalın gövde daha YENİ bir fotoğrafa işaret eder.",
                    "Hiçbir şey söylemez; ağaçlar her yıl aynı kalır.":
                        "Ağacı değişmez saydın. Her yıl bir halka eklenir ve "
                        "gövde kalınlaşır; bu, fotoğrafları sıralamak için "
                        "kullanılabilecek bir iz.",
                    "Fotoğrafın kışın çekildiğini.":
                        "Mevsim ipucu arıyorsun ama gövde kalınlığı mevsimle "
                        "değil, geçen YILLARLA ilgili.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ağaç her yıl biraz daha kalınlaşır. Bu yüzden aynı ağacın iki "
                    "fotoğrafından kalın olanı daha sonra çekilmiştir. Ağaçların "
                    "gövdesindeki halkaların sayılmasıyla yaş bulunması da aynı fikre dayanır."
                ),
                ipuclari=["Bir ağaç yıllar içinde büyür mü, küçülür mü?"],
                puan=12,
            ),
        ],
        kapanis="Fotoğraflar sıraya dizilip albüme yapıştırıldı; altlarına sıra "
                "numarası yazıldı.",
        odul={"itibar": 4, "enerji": 2},
    )
