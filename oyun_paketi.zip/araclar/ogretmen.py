# -*- coding: utf-8 -*-
"""
Öğretmen girişi ve öğretmen masası.

Öğretmen araçları bugüne kadar yalnızca komut satırındaydı (`--rapor`,
`--karne`, `--kapsama`, `--denetle`). Okulda bu, öğretmenin terminal açıp
komut yazması demek; pratikte kimse yapmaz. Bu modül aynı araçları oyunun
açılış ekranından erişilebilir bir menüye taşır.

Girişin bir parolası var. Parolanın ne olduğu konusunda net olalım:

    Bu parola, öğrencinin merakla sınıfın tamamının kaydına bakmasını
    engeller. GERÇEK bir güvenlik değildir: parola özeti düz bir JSON
    dosyasında durur ve kayıt klasörüne erişimi olan biri o dosyayı silip
    parolayı sıfırlayabilir. Öğrenci PIN'i için de aynı şey geçerli
    (bkz. TASARIM_NOTLARI.md §7). Gerçek gizlilik sunucu ister.

İlk çalıştırmada parola yoktur; öğretmen ilk girişte kendi belirler. Okul
kurulumunda bunun İLK İŞ olarak yapılması gerekir - yoksa parolayı ilk giren
öğrenci belirler.
"""
from __future__ import annotations

import io
import json
import os
import time
from typing import Any, Dict, List, Optional

from oyun.motor import durum as durum_modulu
from oyun.motor import terminal as ekran
from oyun.motor.durum import Durum, guclu_ozet, kayitlari_listele, ozet_dogru_mu, yukle

# Parola özeti kayıt klasöründe durur: ağ paylaşımı kullanılıyorsa öğretmen
# hangi makineye otursa aynı parolayla girer.
#
# Yol içe aktarma anında SABİTLENMEZ, her çağrıda okunur: kayıt klasörü
# MERIDYEN_KAYIT ile değiştirilebiliyor ve testler de onu değiştiriyor.
# Sabitlenseydi modül eski klasöre yazmaya devam ederdi.
AYAR_ADI = "ogretmen.json"


def ayar_dosyasi() -> str:
    return os.path.join(durum_modulu.KAYIT_KLASORU, AYAR_ADI)

# ESKİ özet tuzu (yalnız eski kayıtları doğrulamak için; yeni özetler
# rastgele tuzlu PBKDF2, bkz. durum.guclu_ozet).
TUZ = "ogretmen"

EN_AZ_UZUNLUK = 4


# --------------------------------------------------------------------------
# Parola
# --------------------------------------------------------------------------

def _ayarlari_oku() -> Dict[str, Any]:
    try:
        with io.open(ayar_dosyasi(), encoding="utf-8") as dosya:
            return json.load(dosya)
    except Exception:
        return {}


def _ayarlari_yaz(veri: Dict[str, Any]) -> None:
    os.makedirs(durum_modulu.KAYIT_KLASORU, exist_ok=True)
    hedef = ayar_dosyasi()
    gecici = hedef + ".tmp"
    with io.open(gecici, "w", encoding="utf-8") as dosya:
        json.dump(veri, dosya, ensure_ascii=False, indent=2)
    os.replace(gecici, hedef)


def parola_kurulu_mu() -> bool:
    return bool(_ayarlari_oku().get("parola_ozeti"))


def parola_kur(parola: str) -> bool:
    """Parolayı kaydeder. Çok kısaysa reddeder."""
    parola = (parola or "").strip()
    if len(parola) < EN_AZ_UZUNLUK:
        return False
    veri = _ayarlari_oku()
    veri["parola_ozeti"] = guclu_ozet(parola)
    veri["kurulum"] = time.strftime("%d.%m.%Y %H:%M")
    _ayarlari_yaz(veri)
    return True


def branslar() -> List[str]:
    """Öğretmenin seçtiği dersler (B42.1). Kişisel bilgi değil, ders kodları."""
    liste = _ayarlari_oku().get("branslar") or []
    return [d for d in liste if isinstance(d, str)]


def branslari_kaydet(dersler: List[str]) -> None:
    veri = _ayarlari_oku()
    veri["branslar"] = list(dict.fromkeys(d for d in dersler if d))
    _ayarlari_yaz(veri)


def brans_secenekleri() -> List[str]:
    """Branş olarak seçilebilecek dersler: oyunun ders kodları, ada göre.

    Ders programındaki ders listesiyle (DERS_ADLARI) AYNI kodlar; içerik
    modüllerinin `ders` alanı da bu kodlardır (testle kilitli). İçeriğin
    yüklenmiş olmasına bağlı DEĞİL: eskiden `onizleme.tum_dersler()`
    kullanılıyordu, içerik yüklenmeden açılan masada liste boş kalırdı.
    """
    from oyun.motor.modeller import DERS_ADLARI
    return sorted(DERS_ADLARI, key=lambda d: DERS_ADLARI[d])


def gonderilebilir_dersler() -> Optional[List[str]]:
    """Öğretmenin sınıf programına konu ekleyebileceği dersler (B42.4).

    None = süzgeç yok: okul yönetimi branş dışını açmış (okul ayarı).
    Boş liste = branş seçilmemiş: hiçbir dersin konusu eklenemez.

    Kullanıcı kararı (29 Eylül 2026): öğretmen VARSAYILAN olarak yalnız
    kendi branşının konusunu gönderir; branş dışını okul yönetimi açar.
    Branşsız kurulum bu yüzden "her şey açık" SAYILMAZ -- sayılsaydı
    yeni kurulumun varsayılanı branş dışı açık olurdu ve öğretmen
    "Branşım"ı boşaltarak yönetimin kararını tek adımda aşardı. Branş
    girişte sorulmaz (ders sırasında "El kaldıranlar"ın önüne geçmesin);
    sınıf programına ders eklenirken ya da bir ders satırı değiştirilirken
    o anda sorulur (araclar/program.py).
    """
    from araclar import okul_ayarlari
    from oyun.motor.modeller import DERS_ADLARI
    if okul_ayarlari.brans_disi_acik():
        return None
    return [d for d in branslar() if d in DERS_ADLARI]


def _brans_sec(neden: str = "") -> None:
    """Masadan branş seçimi: numaralar virgülle, boş bırakınca temizlenir.

    `neden`: ekran başka bir işin ortasında açıldıysa (sınıf programı,
    B42.4) öğretmene neden sorulduğunu söyleyen satır.
    """
    from araclar import okul_ayarlari
    from oyun.motor.degerlendirme import liste_coz
    from oyun.motor.modeller import DERS_ADLARI

    dersler = brans_secenekleri()
    ekran.temizle()
    ekran.baslik("BRANŞIM", "kalin", "acik_cam")
    if neden:
        ekran.yaz(neden, "acik_sari")
    ekran.bilgi("Sınıf programına yalnız seçtiğin derslerin konularını "
                "ekleyebilirsin; \"Görevleri dene\" listesi de bu derslerle "
                "açılır. Birden çok ders seçebilirsin (ör. tarih öğretmeni "
                "İnkılap Tarihi'ni de). Yalnız ders kodu saklanır; adın ya da "
                "başka bilgin değil.")
    if okul_ayarlari.brans_disi_acik():
        ekran.yaz("Okul yönetimi branş dışı dersleri açmış: programda bütün "
                  "dersler görünür.", "gri")
    for n, ders in enumerate(dersler, start=1):
        ekran.yaz("{:>3}. {}".format(n, DERS_ADLARI.get(ders, ders)), sar=False)
    mevcut = branslar()
    if mevcut:
        ekran.yaz("Şu an: " + ", ".join(DERS_ADLARI.get(d, d) for d in mevcut), "gri")
    ham = ekran.sor("Ders numaraları (ör. 3,7; boş = branşı temizle):", "")
    if not (ham or "").strip():
        branslari_kaydet([])
        if mevcut:
            ekran.basari("Branş temizlendi. \"Görevleri dene\" bütün dersleri "
                         "gösterir; sınıf programına ders eklemeden önce "
                         "branşın yeniden sorulur.")
        else:
            ekran.bilgi("Branş seçilmedi.")
    else:
        secilen = liste_coz(ham, len(dersler))
        if not secilen:
            ekran.hata("Numaralar anlaşılmadı; branş değişmedi.")
        else:
            branslari_kaydet([dersler[i] for i in secilen])
            ekran.basari("Branş kaydedildi.")
    ekran.bekle()


def parola_dogru_mu(parola: str) -> bool:
    ayar = _ayarlari_oku()
    ozet = ayar.get("parola_ozeti")
    if not ozet:
        return False
    dogru, yenile = ozet_dogru_mu(parola, ozet, TUZ)
    if dogru and yenile:                  # eski kayit: ilk girisle yeni bicime gec
        try:
            ayar["parola_ozeti"] = guclu_ozet(parola)
            _ayarlari_yaz(ayar)
        except OSError:
            pass
    return dogru


# --------------------------------------------------------------------------
# Giriş
# --------------------------------------------------------------------------

# Bu masada oturan ogretmen: takma ad bildirimine yazilacak ad ve ders.
# Makine basina TEK parola var, ogretmen hesabi yok; ayni parolayla giren
# iki ogretmen ayirt edilemez. Sinif kaydindaki "ogretmen" alani da sinifi
# ACAN kisidir, listeye bakan degil. Bu yuzden ad, ifsa aninda bakan
# kisiye sorulur ve her giriste sifirlanir.
_OTURUM_OGRETMENI = {}


def _ilk_kurulum() -> bool:
    """Parola yoksa masadan ilk parolayı ister -- ama yalnız öğrenci kaydı yokken.

    B36.6: parola yoksa masayı ilk açan kişi parolayı kurar. Klasörde öğrenci
    kaydı varsa o kişi bir öğrenci olabilir (giriş menüde gizli ama "öğretmen"
    yazmak yetiyor). O durumda kurulum ayrı bir adıma, `--ogretmen-kur`
    komutuna (OGRETMEN_KURULUMU.cmd) taşınır. Kayıt yokken yeni kurulan bir
    sınıfta öğretmenin masayı ilk açması beklenen akıştır; o açık kalır.
    """
    if kayitlari_listele():
        ekran.yaz()
        ekran.kutu(
            "Bu bilgisayarda öğrenci kayıtları var ama öğretmen parolası henüz "
            "belirlenmemiş. Güvenlik için parola buradan belirlenemez: masayı "
            "ilk açan kişi bir öğrenci de olabilir.\n\n"
            "Öğretmen parolayı oyun klasöründeki OGRETMEN_KURULUMU.cmd "
            "dosyasıyla (ya da 'python main.py --ogretmen-kur' komutuyla) "
            "belirlemeli.",
            "PAROLA KURULUMU KAPALI", "acik_sari")
        ekran.bekle()
        return False
    return _parola_belirle()


def parola_kurulumu() -> int:
    """`--ogretmen-kur`: parolayı öğretmen masasından ayrı bir adımla belirler.

    Kurulu parolanın üstüne YAZMAZ; yoksa bu komut parolayı bilmeyen birine
    sıfırlama yolu olurdu. Değiştirmek için masadaki "Parolayı değiştir"
    eski parolayı sorar.
    """
    ekran.temizle()
    ekran.baslik("ÖĞRETMEN PAROLASI KURULUMU", "kalin", "acik_cam")
    if parola_kurulu_mu():
        ekran.bilgi("Öğretmen parolası zaten belirlenmiş. Değiştirmek için "
                    "öğretmen masasına girip 'Parolayı değiştir'i kullan.")
        return 1
    return 0 if _parola_belirle() else 1


def _parola_belirle() -> bool:
    """İlk parolayı iki kez yazdırarak kaydeder."""
    ekran.yaz()
    ekran.kutu(
        "Bu bilgisayarda öğretmen parolası henüz belirlenmemiş. Şimdi "
        "belirlersen bundan sonra öğretmen masasına yalnızca bu parolayla "
        "girilir.\n\n"
        "Parola, öğrencinin sınıfın kayıtlarına merakla bakmasını engeller. "
        "Kayıt klasörüne erişimi olan birine karşı koruma sağlamaz; okulun "
        "asıl koruması klasör izinleridir.",
        "İLK KURULUM", "acik_sari")
    if not ekran.onayla("Öğretmen parolası şimdi belirlensin mi?", False):
        return False
    for _ in range(3):
        parola = ekran.sor("Yeni parola (en az {} karakter):".format(EN_AZ_UZUNLUK))
        if not parola:
            return False
        if parola != ekran.sor("Parolayı bir daha yaz:"):
            ekran.hata("İki parola aynı değil.")
            continue
        if parola_kur(parola):
            ekran.basari("Parola kaydedildi: " + ayar_dosyasi())
            return True
        ekran.hata("Parola en az {} karakter olmalı.".format(EN_AZ_UZUNLUK))
    return False


def giris() -> bool:
    """Öğretmen girişi. Başarılıysa True döner."""
    if not parola_kurulu_mu():
        return _ilk_kurulum()
    for kalan in (2, 1, 0):
        if parola_dogru_mu(ekran.sor("Öğretmen parolası:")):
            return True
        if kalan:
            ekran.hata("Parola tutmadı. {} hakkın kaldı.".format(kalan))
    ekran.hata("Parola tutmadı.")
    ekran.bekle()
    return False


# --------------------------------------------------------------------------
# Öğretmen masası
# --------------------------------------------------------------------------

def _ogrenci_listesi() -> None:
    ozetler = kayitlari_listele()
    if not ozetler:
        ekran.bilgi("Henüz kayıtlı öğrenci yok.")
        ekran.bekle()
        return
    ekran.yaz()
    ekran.yaz("ÖĞRENCİ LİSTESİ  ({} kayıt)".format(len(ozetler)),
              "kalin", "acik_cam")
    ekran.yaz()
    ekran.yaz("{:<18}{:<7}{:<8}{:>7}{:>8}   {}".format(
        "ÖĞRENCİ", "NO", "SINIF", "GÖREV", "PIN", "SON OYNAMA"), "gri")
    ekran.ayrac()
    for ozet in ozetler:
        zaman = (time.strftime("%d.%m.%Y %H:%M", time.localtime(ozet["son"]))
                 if ozet["son"] else "-")
        print("  " + "{:<18}{:<7}{:<8}{:>7}{:>8}   {}".format(
            ozet["ad"][:17], (ozet.get("numara") or "-")[:6],
            (ozet.get("sinif") or "-")[:7], ozet["gorev"],
            "var" if ozet.get("pinli") else "-", zaman))
    ekran.yaz()
    ekran.yaz("Kayıt dosyaları: " + durum_modulu.KAYIT_KLASORU, "gri", sar=False,
              girinti="  ")
    if any((o.get("takma") or "").strip() for o in ozetler):
        ekran.yaz()
        cevap = ekran.sor("g = takma adları göster, Enter = geri:", "")
        if cevap.strip().lower() == "g":
            _takma_adlari_goster(ozetler)
        return
    ekran.bekle()


def _oturum_ogretmeni():
    """Bildirime yazılacak öğretmen adı ve dersi; oturum başına bir kez."""
    if _OTURUM_OGRETMENI.get("ad") and _OTURUM_OGRETMENI.get("ders"):
        return dict(_OTURUM_OGRETMENI)
    ekran.yaz()
    ekran.yaz("Bildirimde senin adın ve dersin yazacak.", "gri")
    ad = ekran.sor("Adın (ör. Ayşe Yılmaz):", "").strip()
    ders = ekran.sor("Dersin ya da bölümün (ör. Matematik):", "").strip()
    if not ad or not ders:
        ekran.hata("Ad ve ders olmadan takma adlar açılmaz: öğrenciye kimin "
                   "gördüğünü söyleyemeyiz.")
        return None
    _OTURUM_OGRETMENI.update(ad=ad, ders=ders)
    return dict(_OTURUM_OGRETMENI)


def takma_adlari_ac(ozetler, ogretmen: str, ders: str) -> dict:
    """Bildirimi BIRAKILABİLEN her öğrencinin takma adı: {kayıt yolu: takma}.

    Bildirim yazılamayan öğrencinin takma adı DÖNMEZ. Kullanıcının kuralı
    "görürse bildirilir"; bildirim yazılamıyorsa söz tutulamıyor demektir,
    o zaman gösterilmez. Ters sıra (önce göster, sonra yazmayı dene) tam da
    bu projenin en sık hatasını üretirdi: ekranda iş bitmiş görünür, öğrenci
    hiçbir şey öğrenmez.
    """
    import os
    from oyun.motor import bildiri
    metin = bildiri.takma_ad_metni(ogretmen, ders)
    acilan = {}
    for ozet in ozetler:
        takma = (ozet.get("takma") or "").strip()
        if not takma:
            continue
        kimlik = os.path.splitext(ozet["dosya"])[0]
        if bildiri.bildiri_yaz(kimlik, metin,
                               ek={"ogretmen": ogretmen, "ders": ders}):
            acilan[ozet["yol"]] = takma
    return acilan


def _takma_adlari_goster(ozetler) -> None:
    """"Gizlileri göster": önce uyarı, sonra bildirim, EN SON gösterim."""
    from oyun.motor import bildiri
    sube = ekran.sor("Hangi şube? (hepsi için boş bırak):", "").strip()
    if sube:
        ozetler = [o for o in ozetler
                   if ekran.ayni_ad((o.get("sinif") or "").strip(), sube)]
    hedef = [o for o in ozetler if (o.get("takma") or "").strip()]
    if not hedef:
        ekran.bilgi("Bu listede takma adı olan öğrenci yok.")
        ekran.bekle()
        return
    kim = _oturum_ogretmeni()
    if kim is None:
        ekran.bekle()
        return
    metin = bildiri.takma_ad_metni(kim["ad"], kim["ders"])
    ekran.yaz()
    ekran.kutu(
        "Takma adları açarsan listedeki {} öğrencinin HER BİRİNE şu "
        "bildirim bırakılacak:\n\n    “{}”\n\n"
        "Bir oyuncu için takma ad kendi kimliğidir; bu yüzden gizli tutulur "
        "ve görüldüğünde söylenir. Öğrenci bildirimi oyunu bir sonraki "
        "açışında görür.".format(len(hedef), metin),
        "TAKMA ADLAR", "acik_sari")
    if not ekran.onayla("Takma adlar açılsın ve bildirim bırakılsın mı?", False):
        return
    acilan = takma_adlari_ac(hedef, kim["ad"], kim["ders"])
    ekran.yaz()
    ekran.yaz("{:<18}{:<8}{}".format("ÖĞRENCİ", "SINIF", "TAKMA AD"), "gri")
    ekran.ayrac()
    for ozet in hedef:
        takma = acilan.get(ozet["yol"])
        ekran.yaz("{:<18}{:<8}{}".format(
            ozet["ad"][:17], (ozet.get("sinif") or "-")[:7],
            takma if takma else "(bildirim yazılamadı, gösterilmedi)"),
            sar=False, girinti="  ")
    ekran.yaz()
    ekran.basari("{} öğrenciye bildirim bırakıldı; oyunu açınca "
                 "görecekler.".format(len(acilan)))
    if len(acilan) < len(hedef):
        ekran.hata("{} öğrenciye bildirim yazılamadı; onların takma adı "
                   "gösterilmedi.".format(len(hedef) - len(acilan)))
    ekran.bekle()


def _ogrenci_sec() -> Optional[Durum]:
    """Listeden tek öğrenci seçtirir."""
    ozetler = kayitlari_listele()
    if not ozetler:
        ekran.bilgi("Henüz kayıtlı öğrenci yok.")
        ekran.bekle()
        return None
    secenekler = []
    for ozet in ozetler:
        etiket = ozet["ad"]
        ek = " ".join(p for p in ((ozet.get("sinif") or ""),
                                  (ozet.get("numara") or "")) if p)
        if ek:
            etiket = "{}  ({})".format(etiket, ek)
        secenekler.append((etiket, "{} görev".format(ozet["gorev"])))
    secenekler.append(("Vazgeç", ""))
    secim = ekran.menu("ÖĞRENCİ", secenekler)
    if secim >= len(ozetler):
        return None
    durum = yukle(ozetler[secim]["yol"])
    if durum is None:
        ekran.hata("Kayıt dosyası okunamadı.")
        ekran.bekle()
    return durum


def _karne_ekrani() -> None:
    from araclar.karne import karne_bas, karne_verisi, karne_yaz

    durum = _ogrenci_sec()
    if durum is None:
        return
    ekran.temizle()
    karne_bas(karne_verisi(durum))
    ekran.yaz()
    if ekran.onayla("Bu karneyi yazdırılabilir dosya olarak kaydedeyim mi?",
                    False):
        try:
            ekran.basari("Karne hazır: " + karne_yaz(durum))
        except OSError as sorun:
            ekran.hata("Karne yazılamadı: {}".format(sorun))
    ekran.bekle()


def _parola_degistir() -> None:
    if not parola_dogru_mu(ekran.sor("Mevcut parola:")):
        ekran.hata("Parola tutmadı.")
        ekran.bekle()
        return
    yeni = ekran.sor("Yeni parola (en az {} karakter):".format(EN_AZ_UZUNLUK))
    if yeni != ekran.sor("Yeni parolayı bir daha yaz:"):
        ekran.hata("İki parola aynı değil.")
    elif parola_kur(yeni):
        ekran.basari("Parola değiştirildi.")
    else:
        ekran.hata("Parola en az {} karakter olmalı.".format(EN_AZ_UZUNLUK))
    ekran.bekle()


def _ogrenci_tasi(siniflar) -> None:
    """Öğrenciyi başka sınıfa taşır. KAYIT SİLİNMEZ, yalnızca bağ değişir."""
    from araclar import sinif as sinif_modulu

    durum = _ogrenci_sec()
    if durum is None:
        return
    ozetler = [o for o in kayitlari_listele()
               if o["ad"] == durum.ad and o.get("numara") == durum.numara]
    if not ozetler:
        ekran.hata("Kayıt bulunamadı.")
        ekran.bekle()
        return

    secenekler = [("{}  {}".format(k["kod"], k["ad"]), k.get("okul", ""))
                  for k in siniflar]
    secenekler.append(("Sınıf bağını kaldır", "kayıt ve ilerleme durur"))
    secenekler.append(("Vazgeç", ""))
    secim = ekran.menu("{} hangi sınıfa?".format(durum.ad), secenekler)
    if secim >= len(secenekler) - 1:
        return
    kod = "" if secim == len(siniflar) else siniflar[secim]["kod"]
    if sinif_modulu.ogrenciyi_tasi(ozetler[0]["yol"], kod):
        ekran.bilgi("{} taşındı. İlerlemesi olduğu gibi duruyor.".format(durum.ad))
    else:
        ekran.hata("Taşınamadı.")
    ekran.bekle()


def _siniflar() -> None:
    """Sınıf açma ve kod verme ekranı.

    Kodun işi şu: öğrenci onu girince sınıfı, şubesi ve okulu kendiliğinden
    dolsun. Öğrenciden kimlik numarası ya da başka kişisel veri istenmiyor;
    ad ve kod yetiyor. Kod tahtaya yazılacağı için okunaklı üretiliyor
    (bkz. araclar/sinif.py).
    """
    from araclar import sinif as sinif_modulu

    while True:
        ekran.temizle()
        ekran.baslik("SINIFLAR", "kalin", "acik_cam")
        siniflar = sinif_modulu.siniflari_listele()
        if siniflar:
            ekran.yaz()
            for kayit in siniflar:
                satir = "{}   {}".format(
                    ekran.renkli(kayit["kod"], "acik_sari"), kayit["ad"])
                if kayit.get("okul"):
                    satir += ekran.renkli("  ({})".format(kayit["okul"]), "gri")
                ekran.yaz("  " + satir)
            ekran.yaz()
            ekran.yaz("Kodu tahtaya yazın; öğrenci yeni sefer açarken giriyor.",
                      "gri")
        else:
            ekran.bilgi("Henüz sınıf açılmamış.")
        ekran.ayrac()

        secim = ekran.menu("", [
            ("Yeni sınıf aç", "kod üretilir"),
            ("Öğrenciyi başka sınıfa taşı", "yanlış koda girmiş olabilir"),
            ("Geri dön", ""),
        ])
        if secim == 1:
            _ogrenci_tasi(siniflar)
            continue
        if secim != 0:
            return

        ekran.yaz()
        ad = ekran.sor("Sınıf/şube (örn. 7-A):", "").strip()
        if not ad:
            ekran.hata("Sınıf adı boş olamaz.")
            ekran.bekle()
            continue
        okul = ekran.sor("Okul adı (isteğe bağlı):", "")
        ogretmen_adi = ekran.sor("Öğretmen adı (isteğe bağlı):", "")
        try:
            kayit = sinif_modulu.sinif_olustur(ad, okul, ogretmen_adi)
        except Exception as sorun:  # noqa: BLE001 - kullaniciya soyle, cokme
            ekran.hata("Sınıf açılamadı: {}".format(sorun))
            ekran.bekle()
            continue
        ekran.yaz()
        ekran.kutu(
            kayit["kod"] + "\n\n" +
            "Bu kodu tahtaya yazın. Öğrenci \"Yeni sefer\" sonra \"Okulda\" " +
            "derken bu kodu giriyor; sınıfı ve okulu kendiliğinden doluyor.",
            "SINIF KODU: " + kayit["ad"], "acik_yesil")
        ekran.bekle()


def _bekleyen_ozeti() -> str:
    """Menü satırının yanına "(3)" gibi bir sayı. Yoksa boş dizge.

    Öğretmenin menüye girmeden bekleyen olduğunu görmesi için. Sayı toplam
    BILDIRI değil, bekleyen SORU sayısıdır -- öğretmenin yapacağı iş kadar
    madde görünsün.
    """
    try:
        from araclar import el_kaldirma
        from araclar.sinif import siniflari_listele
        from araclar.sinif import ogretmen_anahtari
        toplam = sum(len(el_kaldirma.bekleyenler(
            s.get("kod", ""), ogretmen_anahtari(s.get("kod", ""))))
            for s in siniflari_listele())
    except Exception:              # noqa: BLE001 - menü asla bu yüzden çökmesin
        return ""
    return "  ({})".format(toplam) if toplam else ""


def masa() -> None:
    """Öğretmen masası menüsü. Giriş yapılmış varsayılır."""
    from araclar.denetim import tumunu_denetle
    from araclar.karne import toplu_karne
    from araclar.rapor import sinif_raporu
    from oyun.motor.oyun import kapsama_yazdir

    while True:
        ekran.temizle()
        ekran.baslik("ÖĞRETMEN MASASI", "kalin", "acik_cam")
        ozetler = kayitlari_listele()
        subeler = sorted(set((o.get("sinif") or "").strip()
                             for o in ozetler if (o.get("sinif") or "").strip()))
        ekran.yaz("{} öğrenci kaydı{}".format(
            len(ozetler),
            "  |  şubeler: " + ", ".join(subeler) if subeler else ""), "gri")
        dolan_sayi = _suresi_dolan_sayisi(ozetler)
        if dolan_sayi:
            ekran.yaz("{} kayıt saklama süresini doldurdu; \"Kayıt silme ve "
                      "saklama\" menüsünden bakın.".format(dolan_sayi),
                      "acik_sari")
        ekran.ayrac()

        # "El kaldıranlar" en üstte: ders SIRASINDA bakılan tek madde bu,
        # diğerleri ders dışı işler. Öğretmen tahtadan dönüp iki saniyede
        # görebilmeli.
        bekleyen_sayi = _bekleyen_ozeti()
        secim = ekran.menu("", [
            ("El kaldıranlar" + bekleyen_sayi,
             "kim olduğu yazmaz - hangi soruda kaç kişi takıldı"),
            ("Sınıf raporu", "kim nerede takılıyor, sınıfın ortak hataları"),
            ("Öğrenci listesi", "kayıtlar, şubeler ve son oynama zamanları"),
            ("Bir öğrencinin karnesi", "ekranda göster, istersen yazdır"),
            ("Bütün karneleri üret", "karneler/ klasörüne HTML olarak"),
            ("İçerik kapsaması", "hangi öğrenme yolunda hangi zorlukta iş var"),
            ("İçerik denetimi", "bütün görevleri üretip tutarlılık kontrolü"),
            ("Sınıflar ve kodlar", "sınıf aç, kodu öğrencilere ver"),
            ("Parolayı değiştir", ""),
            ("Okul ders programı", "saatler, dersler ve işlenen konular"),
            ("Görevleri dene", "örnek soru ve cevap anahtarı; kayıt tutulmaz"),
            ("Branşım", "hangi derslerin öğretmenisin (sınıf programı süzgeci)"),
            ("Kayıt silme ve saklama" +
             ("  ({})".format(dolan_sayi) if dolan_sayi else ""),
             "tek kayıt, süresi dolanlar, yıl sonu sınıf; aydınlatma metni"),
            ("Çıkış", "ana ekrana dön"),
        ])

        if secim == 0:
            _el_kaldiranlar()
        elif secim == 1:
            sube = ekran.sor("Hangi şube? (hepsi için boş bırak):", "")
            ekran.temizle()
            sinif_raporu(sube)
            ekran.bekle()
        elif secim == 2:
            ekran.temizle()
            _ogrenci_listesi()
        elif secim == 3:
            _karne_ekrani()
        elif secim == 4:
            ekran.temizle()
            toplu_karne()
            ekran.bekle()
        elif secim == 5:
            ekran.temizle()
            kapsama_yazdir()
            ekran.bekle()
        elif secim == 6:
            ekran.temizle()
            ekran.bilgi("Bütün görev üreticileri çalıştırılıyor, biraz "
                        "sürebilir...")
            tumunu_denetle()
            ekran.bekle()
        elif secim == 7:
            _siniflar()
        elif secim == 8:
            _parola_degistir()
        elif secim == 9:
            from araclar.program import ogretmen_programi
            ogretmen_programi()
        elif secim == 10:
            from araclar.onizleme import onizleme
            onizleme()
        elif secim == 11:
            _brans_sec()
        elif secim == 12:
            _kvkk_menusu()
        else:
            return


def _kayit_sil() -> None:
    """Bir öğrencinin kaydını kalıcı olarak siler (B36.16, KVKK).

    Veli ya da öğrenci silme istediğinde, ya da yıl sonunda, öğretmenin oyun
    içinde bir yolu olsun; kayıt klasöründe dosya aramak zorunda kalmasın.
    Yanlışlıkla silmeye karşı öğrencinin adı AYNEN yazdırılır: geri alma yok.
    Karnesi de silinir -- ama aynı adda başka öğrenci kaldıysa karne dosyası
    ortak olduğu için dokunulmaz (karne dosya adı öğrenci adından türer).
    Hangi dosyaların birlikte gittiği tek yerde: araclar/kvkk.kaydi_sil.
    """
    from araclar import kvkk

    ekran.temizle()
    ekran.baslik("ÖĞRENCİ KAYDINI SİL", "kalin", "acik_cam")
    ozetler = kayitlari_listele()
    if not ozetler:
        ekran.bilgi("Henüz kayıtlı öğrenci yok.")
        ekran.bekle()
        return
    secim = ekran.menu("Hangi öğrencinin kaydı silinsin?",
                       [(o["ad"], "{} {}".format(o.get("sinif") or "-",
                                                 o.get("numara") or ""))
                        for o in ozetler] + [("Vazgeç", "")])
    if secim is None or secim >= len(ozetler):
        return
    ozet = ozetler[secim]
    ekran.kutu(
        "{} adlı öğrencinin kaydı KALICI olarak silinecek: ilerleme, günlük, "
        "anket cevapları, karnesi, bildirimleri, hata kayıtları ve geri "
        "bildirim paketleri. Geri alınamaz.\n\n"
        "Onaylamak için öğrencinin adını aynen yaz.".format(ozet["ad"]),
        "DİKKAT", "acik_sari")
    if (ekran.sor("Öğrencinin adı:") or "").strip() != ozet["ad"]:
        ekran.bilgi("Ad tutmadı; kayıt silinmedi.")
        ekran.bekle()
        return
    _silme_sonuclarini_yaz([kvkk.kaydi_sil(ozet["yol"])])
    ekran.bekle()


def _silme_sonuclarini_yaz(sonuclar) -> int:
    """Silme sonuçlarını söyler; silinen kayıt sayısını döner.

    Söylenen şey dosya sisteminin durumudur: "silindi" yalnız dosya gerçekten
    gittiyse yazılır, silinemeyen her dosya adıyla gösterilir.
    """
    tamam = [s for s in sonuclar if s.basarili]
    for sonuc in sonuclar:
        if not sonuc.basarili:
            ekran.hata("Kayıt silinemedi: " + sonuc.yol)
        for yol in sonuc.silinemeyen:
            if yol != sonuc.yol:
                ekran.hata("Silinemedi: " + yol)
    korunan = sorted({s.ad for s in tamam if s.karne_korundu})
    if korunan:
        ekran.yaz("Aynı adda başka öğrenci olduğu için karne dosyası "
                  "korundu: " + ", ".join(korunan), "gri")
    if len(sonuclar) == 1:
        if tamam:
            ekran.basari("Kayıt silindi.")
    elif tamam:
        ekran.basari("{} kayıt silindi.".format(len(tamam)))
    return len(tamam)


def _suresi_dolan_sayisi(ozetler=None) -> int:
    """Masa başlığı için; hesap bozulursa masa yine açılsın."""
    try:
        from araclar import kvkk
        return len(kvkk.suresi_dolanlar(ozetler=ozetler))
    except Exception:              # noqa: BLE001
        return 0


def _tarih(zaman: float) -> str:
    return time.strftime("%d.%m.%Y", time.localtime(zaman)) if zaman else "-"


def _suresi_dolanlari_sil() -> None:
    """Saklama süresi dolan kayıtlar: önce LİSTE, sonra açık onay (B36.16).

    Sessiz otomatik silme yok: süre yalnız listeyi belirler. Onay için
    silinecek kayıt SAYISI yazdırılır -- "e/h" sorusu, uzun bir listeyi
    okumadan geçmeye fazla kolay.
    """
    from araclar import kvkk, okul_ayarlari
    from oyun.motor.degerlendirme import liste_coz

    ekran.temizle()
    ekran.baslik("SAKLAMA SÜRESİ DOLAN KAYITLAR", "kalin", "acik_cam")
    ay = okul_ayarlari.saklama_ayi()
    dolan = kvkk.suresi_dolanlar(ay=ay)
    ekran.yaz("Saklama süresi: {} ay (okul ayarı).".format(ay), "gri")
    if not dolan:
        ekran.bilgi("{} aydır oynanmayan kayıt yok.".format(ay))
        ekran.bekle()
        return
    ekran.yaz()
    ekran.yaz("Şu {} kayıt {} aydır oynanmadı:".format(len(dolan), ay), "kalin")
    for sira, ozet in enumerate(dolan, 1):
        ekran.yaz("{:>3}. {:<20}{:<8}{:<6} son oynama: {}{}".format(
            sira, ozet["ad"][:19], (ozet.get("sinif") or "-")[:7],
            (ozet.get("numara") or "-")[:5], _tarih(ozet["son_gercek"]),
            " (kayıtta tarih yok; dosya tarihi)" if ozet.get("tahmini") else ""),
            sar=False, girinti="  ")
    ekran.yaz()
    ekran.kutu(
        "Okulun saklama kuralına göre bu kayıtlar silinir. Silinen kayıt geri "
        "getirilemez; karnesi, bildirimleri, hata kayıtları ve geri "
        "bildirim paketleri de gider.\n\n"
        "Listede tutulması gereken biri varsa (ör. uzun süre okula "
        "gelemeyen bir öğrenci) \"Seçerek sil\" ile onu dışarıda bırakın.",
        "DİKKAT", "acik_sari")
    secim = ekran.menu("", [("Hepsini sil", "{} kayıt".format(len(dolan))),
                            ("Seçerek sil", "numaraları yazın"),
                            ("Vazgeç", "")])
    if secim == 1:
        secilen = liste_coz(ekran.sor("Silinecek numaralar (ör. 1,3):", ""),
                            len(dolan))
        if not secilen:
            ekran.bilgi("Numaralar anlaşılmadı; hiçbir kayıt silinmedi.")
            ekran.bekle()
            return
        hedef = [dolan[i] for i in sorted(set(secilen))]
    elif secim == 0:
        hedef = dolan
    else:
        return
    onay = ekran.sor("Onaylamak için silinecek kayıt sayısını yazın ({}):"
                     .format(len(hedef)), "").strip()
    if onay != str(len(hedef)):
        ekran.bilgi("Sayı tutmadı; hiçbir kayıt silinmedi.")
        ekran.bekle()
        return
    _silme_sonuclarini_yaz(kvkk.toplu_sil(o["yol"] for o in hedef))
    ekran.bekle()


def _sinif_kayitlarini_sil() -> None:
    """Yıl sonu: bir sınıfın bütün kayıtları (B36.16).

    Onay için sınıf KODU yazdırılır. Kod büyük/küçük harf duyarsız
    karşılaştırılır (sınıf kodu her yerde öyle: bkz. sinif.sinif_bul).
    Önce öğrenciler silinir, sonra -ayrıca sorularak- sınıfın kendisi.
    """
    from araclar import kvkk

    ekran.temizle()
    ekran.baslik("SINIFIN KAYITLARINI SİL (YIL SONU)", "kalin", "acik_cam")
    siniflar = kvkk.bilinen_siniflar()
    kodsuz = kvkk.kodsuz_kayit_sayisi()
    if kodsuz:
        # Sınıf kodu isteğe bağlı: kodsuz giren öğrenci hiçbir sınıfın
        # listesine girmez. Öğretmen "sınıfı sildim" sanıp onları unutmasın.
        ekran.yaz("Sınıf koduna bağlı olmayan {} kayıt bu listede yok; onlar "
                  "\"Bir öğrencinin kaydını sil\" ya da saklama süresi yoluyla "
                  "silinir.".format(kodsuz), "gri")
    if not siniflar:
        ekran.bilgi("Sınıf koduyla bağlı kayıt ya da açılmış sınıf yok.")
        ekran.bekle()
        return
    secim = ekran.menu("Hangi sınıf?", [
        ("{}  {}".format(s["kod"], s["ad"] or "-"),
         "{} öğrenci kaydı{}".format(
             s["ogrenci"], "" if s["tanimli"] else " (sınıf bu klasörde tanımlı değil)"))
        for s in siniflar] + [("Vazgeç", "")])
    if secim is None or secim >= len(siniflar):
        return
    sinif = siniflar[secim]
    kod = sinif["kod"]
    ogrenciler = kvkk.sinif_kayitlari(kod)
    ekran.temizle()
    ekran.baslik("SINIF " + kod, "kalin", "acik_cam")
    for ozet in ogrenciler:
        ekran.yaz("{:<22}{}".format(ozet["ad"][:21], ozet.get("numara") or "-"),
                  sar=False, girinti="  ")
    if ogrenciler:
        ekran.yaz()
        ekran.kutu(
            "Bu sınıfın {} öğrenci kaydı KALICI olarak silinecek: ilerleme, "
            "günlük, karne, bildirimler, hata kayıtları ve geri bildirim "
            "paketleri. Geri alınamaz.\n\n"
            "Gelecek yıl devam edecek öğrenci varsa önce \"Sınıflar ve "
            "kodlar > Öğrenciyi başka sınıfa taşı\" ile yeni sınıfına taşıyın.\n\n"
            "Telefonda oynayanların kayıtları kendi telefonlarındadır; bu işlem "
            "onlara ulaşmaz. Onlar \"Teçhizat ve Ayarlar > Kaydımı sil\" ile "
            "kendileri siler.\n\n"
            "Onaylamak için sınıf kodunu yazın.".format(len(ogrenciler)),
            "DİKKAT", "acik_sari")
        if (ekran.sor("Sınıf kodu:") or "").strip().upper() != kod:
            ekran.bilgi("Kod tutmadı; hiçbir kayıt silinmedi.")
            ekran.bekle()
            return
        _silme_sonuclarini_yaz(kvkk.sinif_kayitlarini_sil(kod))
    else:
        ekran.bilgi("Bu bilgisayarda bu sınıfa bağlı öğrenci kaydı yok. "
                    "Telefonda oynayanların kayıtları burada görünmez.")
    # Varsayılan HAYIR. Kapatma geri alınamaz: öğretmen anahtarı yalnız
    # yerel sınıf dosyasında durur, aynı kod başka anahtarla yeniden
    # açılamaz. Telefonla oynanan sınıf burada "0 kayıt" görünür; listeye
    # bakmak için giren öğretmen tek bir Enter'la sınıfı ders yılının
    # ortasında kapatmasın.
    if sinif["tanimli"]:
        ekran.yaz()
        ekran.yaz("Sınıfı kapatmak geri alınamaz: sınıf kodu çalışmaz olur ve "
                  "bu koddan gelen \"anlamadım\" bildirimleri size ulaşmaz. "
                  "Yeni ders yılı için yeni sınıf açılır.", "gri")
    if sinif["tanimli"] and ekran.onayla(
            "Sınıfın kendisi de kapatılsın mı? (kod, ders programı, el kaldırma "
            "sayıları; sunucuda açıksa oradan da)", False):
        sonuc = kvkk.sinifi_kapat(kod)
        for yol in sonuc["silinemeyen"]:
            ekran.hata("Silinemedi: " + yol)
        if sonuc["sunucu"] is False:
            ekran.hata("Sunucu sınıfı silmeyi reddetti (anahtar tutmadı). "
                       "Sunucuda yalnız sınıf adı, okul adı ve isimsiz el "
                       "kaldırma sayıları durur.")
        elif sonuc["sunucu"] is None:
            from oyun.motor import ag
            if ag.acik_mi():
                ekran.hata("Sunucuya ulaşılamadı; sınıf sunucuda kaldı "
                           "(öğrenci verisi yok: sınıf adı, okul adı, isimsiz "
                           "sayılar).")
        if not sonuc["silinemeyen"]:
            ekran.basari("Sınıf {} kapatıldı.".format(kod))
    ekran.bekle()


def _aydinlatma_goster() -> None:
    from araclar import kvkk
    ekran.temizle()
    ekran.baslik("AYDINLATMA METNİ", "kalin", "acik_cam")
    ekran.kutu(kvkk.AYDINLATMA_ETIKETI + "\n\nBu metin okulun ve bir "
               "hukukçunun onayından geçmeden veliye ya da öğrenciye "
               "dağıtılmamalı.", "TASLAK", "acik_sari")
    ekran.yaz()
    for paragraf in kvkk.aydinlatma_metni().split("\n\n"):
        ekran.yaz(paragraf)
        ekran.yaz()
    ekran.bekle()


def _kvkk_menusu() -> None:
    """Kayıt silme ve saklama (B36.16): dört iş tek menüde."""
    from araclar import okul_ayarlari
    while True:
        ekran.temizle()
        ekran.baslik("KAYIT SİLME VE SAKLAMA", "kalin", "acik_cam")
        ay = okul_ayarlari.saklama_ayi()
        dolan = _suresi_dolan_sayisi()
        ekran.yaz("Saklama süresi: {} ay (okul ayarı; OKUL_AYARLARI.cmd). "
                  "Hiçbir kayıt onaysız silinmez.".format(ay), "gri")
        secim = ekran.menu("", [
            ("Bir öğrencinin kaydını sil", "veli/öğrenci isteği; ad aynen yazılır"),
            ("Saklama süresi dolan kayıtlar" +
             ("  ({})".format(dolan) if dolan else ""),
             "{} aydır oynanmayanlar; liste ve onay".format(ay)),
            ("Sınıfın bütün kayıtlarını sil", "yıl sonu; sınıf kodu yazılır"),
            ("Aydınlatma metni (TASLAK)", "hukukçu/okul görüşü bekliyor"),
            ("Geri dön", ""),
        ])
        if secim == 0:
            _kayit_sil()
        elif secim == 1:
            _suresi_dolanlari_sil()
        elif secim == 2:
            _sinif_kayitlarini_sil()
        elif secim == 3:
            _aydinlatma_goster()
        else:
            return


def ogretmen_girisi() -> None:
    """Açılış ekranından çağrılan giriş + masa akışı."""
    ekran.temizle()
    ekran.baslik("ÖĞRETMEN GİRİŞİ", "kalin", "acik_cam")
    if giris():
        # Her giriste sifirlanir: onceki oturumdaki ogretmenin adi, sonra
        # giren baska bir ogretmenin bildirimlerine yazilmasin.
        _OTURUM_OGRETMENI.clear()
        masa()


def _el_kaldiranlar() -> None:
    """Sessiz el kaldırma ekranı. Bkz. araclar/el_kaldirma.py.

    BU EKRANDA İSİM YOKTUR VE OLMAYACAKTIR. Tahtaya yansısa bile kimse
    açığa çıkmamalı; öğrencinin bunu kullanmasının tek şartı bu.
    Kimin nerede zorlandığı sınıf raporunda, ayrı bir yerde duruyor.
    """
    import time as _zaman

    from araclar import el_kaldirma
    from araclar.sinif import siniflari_listele

    siniflar = siniflari_listele()
    if not siniflar:
        ekran.temizle()
        ekran.baslik("EL KALDIRANLAR", "kalin", "acik_cam")
        ekran.bilgi("Henüz sınıf açılmamış. Önce \"Sınıflar ve kodlar\" "
                    "menüsünden bir sınıf aç ve kodu tahtaya yaz.")
        ekran.bekle()
        return

    if len(siniflar) == 1:
        secilen = siniflar[0]
    else:
        ekran.temizle()
        ekran.baslik("EL KALDIRANLAR", "kalin", "acik_cam")
        secim = ekran.menu("Hangi sınıf?",
                           [(s.get("ad", "?"), s.get("kod", "")) for s in siniflar]
                           + [("Geri", "")])
        if secim is None or secim >= len(siniflar):
            return
        secilen = siniflar[secim]

    kod = secilen.get("kod", "")
    # Sunucu uzerinden calisiliyorsa ogretmen isleri anahtar istiyor;
    # sinif kodu tahtada yazili oldugu icin tek basina yetki degil.
    from araclar.sinif import ogretmen_anahtari
    anahtar = ogretmen_anahtari(kod)
    while True:
        ekran.temizle()
        ekran.baslik("EL KALDIRANLAR - {}".format(secilen.get("ad", "?")),
                     "kalin", "acik_cam")
        bekleyen = el_kaldirma.bekleyenler(kod, anahtar)
        if not bekleyen:
            ekran.yaz("Şu an bekleyen yok.", "gri")
            ekran.yaz()
            ekran.yaz("Öğrenci bir soruda takılınca oyunda \"e\" yazar; "
                      "burada görünür.", "gri")
            ekran.bekle()
            return

        # Tek parça veriliyor: satırı ekranın genişliğine göre terminal
        # kırsın. Elle kırılmış satırlar telefonda (50 sütun) ortasından
        # bölünüyordu.
        ekran.yaz("Kimin bildirdiği YAZMIYOR ve yazmayacak; yalnızca kaç "
                  "kişinin takıldığı görünür. Tahtada anlatırken kimseyi "
                  "seçme, sınıfa \"şu soruyu birlikte yapalım\" demek yeter.",
                  "gri")
        ekran.ayrac()

        simdi = _zaman.time()
        satirlar = []
        for sira, kayit in enumerate(bekleyen, 1):
            gecen = max(0, int((simdi - float(kayit.get("son", simdi))) // 60))
            ne_zaman = "az önce" if gecen < 1 else "{} dk önce".format(gecen)
            ekran.yaz("{:>2}. {} kişi  {}  ({})".format(
                sira, kayit.get("sayi", 0), kayit.get("konu", "?"), ne_zaman),
                "acik_sari" if kayit.get("sayi", 0) > 1 else None)
            baslik = (kayit.get("baslik") or "").strip()
            if baslik:
                ekran.yaz("    " + baslik[:200], "gri")
            satirlar.append(kayit)

        ekran.ayrac()
        ekran.yaz("Anlattığın satırın numarasını yaz. "
                  "t = hepsini temizle, Enter = geri.", "gri")
        ham = ekran.sor("Satır no / t / Enter:").strip().lower()
        if not ham:
            return
        if ham == "t":
            if ekran.onayla("Bekleyenlerin hepsi silinsin mi?", False):
                el_kaldirma.temizle(kod, anahtar)
            continue
        if ham.isdecimal():
            sira = int(ham)
            if 1 <= sira <= len(satirlar):
                el_kaldirma.anlatildi(kod, satirlar[sira - 1]["anahtar"],
                                      anahtar)
                continue
        ekran.hata("Anlamadım. Satır numarası, t ya da Enter.")
        ekran.bekle()
