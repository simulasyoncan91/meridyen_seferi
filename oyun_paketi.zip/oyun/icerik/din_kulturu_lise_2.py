# -*- coding: utf-8 -*-
"""
Din Kültürü ve Ahlak Bilgisi: lise ikinci dalga.

`din_kulturu_lise.py` ile AYNI üslup kuralları geçerlidir (oraya bak):
mezhepler üstü, MEB ders kitabı dili, tartışmalı fıkhî hükümde kesin cevap
isteyen soru YOK, şıklar "Kavram, çünkü gerekçe" biçiminde ve hiçbirinde
noktalı virgül yok. Ayet notları MEAL DEĞİL, anlam özetidir ve kartta öyle
belirtilir.

Üreticiler: inanc_esaslari, peygamber_gorevleri, toplumsal_ahlak,
din_bilim_felsefe. MEB satırlarına bağları `oyun/veri/ek_karsilik.csv`
içinde gerekçeleriyle yazılıdır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import PERSONEL, ad_sec, model_adimi, yorum_adimi
from .din_kulturu_lise import _sik, _siniflama


# ==========================================================================
# 1. İNANÇ ESASLARI (Nisâ 136: altı esas)
# ==========================================================================

_ESAS_KARTI = (
    "ALLAH'A İMAN: Allah'ın var ve bir olduğuna, yaratıcı olduğuna inanmak.\n"
    "MELEKLERE İMAN: Allah'ın yarattığı, emrine uyan, gözle görülmeyen "
    "varlıklara (Cebrail gibi) inanmak.\n"
    "KİTAPLARA İMAN: Allah'ın peygamberleri aracılığıyla gönderdiği kitaplara, "
    "sonuncusu Kur'an'a inanmak.\n"
    "PEYGAMBERLERE İMAN: Allah'ın doğru yolu bildirmek için seçtiği elçilere "
    "inanmak.\n"
    "AHİRETE İMAN: Ölümden sonra dirilmeye, hesaba ve karşılığın görüleceği "
    "hayata inanmak.\n"
    "KADERE İMAN: Her şeyin Allah'ın ilmi ve takdiriyle bir düzen içinde "
    "olduğuna, insanın da iradesiyle sorumlu olduğuna inanmak."
)

_ESAS_YONTEMI = [
    ("İnancın konu aldığı şeye bakılarak",
     "esaslar iman edilen şeyin türüne göre ayrılır",
     ""),
    ("Cümledeki ilk sözcüğe bakılarak",
     "esaslar kayıtlarda sözcük sırasıyla tanınır",
     "Sözcük sırası esası belirlemez: aynı esas farklı cümlelerle anlatılabilir. "
     "Ölçüt, cümlenin neye inanıldığını söylemesidir."),
    ("Cümlenin ne kadar kesin söylendiğine bakılarak",
     "emin bir üslup esasın ağırlığını gösterir",
     "Kesinlik üslupla ilgilidir, konuyla değil. Aynı esas kararlı ya da "
     "çekingen bir sesle söylenebilir; esası inanılan şey belirler."),
    ("Cümleyi kimin yazdığına bakılarak",
     "kayıtlar yazanın görevine göre sınıflanır",
     "Kayıt tutanın kim olduğu esası değiştirmez. Aynı cümleyi kim yazarsa "
     "yazsın, esas inanılan şeye göre belirlenir."),
]

_ESAS_HAVUZU = [
    {
        "kayit": "{a}: \"Peygamberlere vahyi ulaştıran Cebrail'in görevine inanıyorum.\"",
        "aciklama": ("Cümlenin konusu vahyi taşıyan görünmez varlık: melek. Vahyi "
                     "alan peygamber ve vahyin yazıya geçmiş hâli kitap ayrı "
                     "esaslardır; burada inanılan şey Cebrail'dir."),
        "sec": [
            ("Meleklere iman", "cümle gözle görülmeyen, vahyi taşıyan bir varlığı konu alıyor", ""),
            ("Peygamberlere iman", "vahyi alan kişiler peygamberlerdir ve cümle onlardan söz ediyor",
             "Peygamberler vahyi alan elçilerdir ama cümlenin inandığı şey vahyi "
             "taşıyan Cebrail. Esası belirleyen, cümlede inanılan nesnedir."),
            ("Kitaplara iman", "vahiy sonunda yazıya geçer ve cümle vahiyle ilgilidir",
             "Vahiy kitaba dönüşse de cümlede bir kitap anılmıyor. Konu, vahyi "
             "getiren varlığın görevine inanmak."),
            ("Allah'a iman", "vahiy Allah'tan geldiği için her vahiy cümlesi O'na iman sayılır",
             "Her esas Allah'a imanla ilişkilidir ama kayıtta ayrı bir esas aranıyor. "
             "Cümlenin doğrudan inandığı şey vahyi taşıyan varlıktır."),
        ],
    },
    {
        "kayit": "{a}: \"Tevrat, Zebur, İncil ve Kur'an'ın Allah tarafından indirildiğine inanıyorum.\"",
        "aciklama": ("Cümlede inanılan şey indirilen kitaplardır. Kitapları getiren "
                     "peygamberler ve vahyi taşıyan melek ayrı esaslardır."),
        "sec": [
            ("Kitaplara iman", "cümle Allah tarafından indirilen kitapları tek tek sayıyor", ""),
            ("Peygamberlere iman", "kitapları insanlara ulaştıranlar peygamberlerdir",
             "Elçiler vahyi getirir ama cümlede hiçbir elçi anılmıyor. "
             "Sayılan şeyler Allah'ın indirdiği yazılı metinlerdir."),
            ("Meleklere iman", "vahiy bir melek aracılığıyla geldiği için kitap cümlesi meleğe bağlanır",
             "Vahyin aracısı melek olsa da cümlenin konusu melek değil. Esası, "
             "cümlede anılan indirilmiş metinler belirler."),
            ("Allah'a iman", "kitapları indiren Allah olduğundan cümle O'na imanı anlatıyor",
             "İndiren Allah'tır ama sayılan şeyler indirilmiş metinler. Cümlenin kendi "
             "konusu bu metinlere inanmak."),
        ],
    },
    {
        "kayit": "{a}: \"Bu hayatta yaptıklarımın hesabının ölümden sonra görüleceğine inanıyorum.\"",
        "aciklama": ("Ölümden sonraki hayat, hesap ve karşılık ahirete imanın "
                     "konusudur. Sorumluluk kaderde de geçer ama burada konu "
                     "hesabın görüleceği ikinci hayattır."),
        "sec": [
            ("Ahirete iman", "cümle ölümden sonra hesap ve karşılık görülecek hayatı anlatıyor", ""),
            ("Kadere iman", "cümle yapılan işlerden sorumlu olmayı ve hesap vermeyi anlatıyor",
             "Sorumluluk kader başlığında da geçer ama kayıtta sorumluluğun "
             "ne zaman ve nerede görüleceği söyleniyor: ölümden sonra."),
            ("Allah'a iman", "hesabı görecek olan Allah olduğu için cümle O'na imanı gösteriyor",
             "Hesabı gören Allah'tır ama cümlenin inandığı şey o hesabın "
             "yapılacağı hayat. Esası bu belirler."),
            ("Peygamberlere iman", "hesap günü hakkında bilgiyi peygamberler bildirdi",
             "Bilgiyi elçilerin bildirmiş olması cümleyi peygamber esasına "
             "sokmaz. Cümle hesap gününe inanmayı söylüyor."),
        ],
    },
    {
        "kayit": ("{a}: \"Hz. Âdem'den Hz. Muhammed'e gelen elçilerin hepsine, "
                  "aralarında ayrım yapmadan inanıyorum.\""),
        "aciklama": ("Cümle Allah'ın seçtiği elçilere, yani peygamberlere imanı "
                     "anlatıyor. Elçilerin getirdiği kitaplar ayrı bir esastır."),
        "sec": [
            ("Peygamberlere iman", "cümlede inanılanlar Allah'ın seçip gönderdiği elçilerdir", ""),
            ("Kitaplara iman", "elçiler kitap getirdiği için cümle kitaplara imanı da anlatıyor",
             "Elçilerin kitap getirmesi ayrı bir bilgidir. Cümlede kitap anılmıyor; "
             "inanılan şey elçilerin kendisi."),
            ("Meleklere iman", "elçilere vahiy melekle ulaştığından cümle meleklere dayanıyor",
             "Vahyin aracısı melek olsa da cümle melekten söz etmiyor. Konusu "
             "gönderilen insanlardır."),
            ("Allah'a iman", "elçileri gönderen Allah olduğu için esas Allah'a imandır",
             "Gönderen Allah'tır ama cümle gönderilenlere inanıyor. Ölçüt "
             "cümlede inanılan şeydir."),
        ],
    },
    {
        "kayit": ("{a}: \"Evrendeki her şeyin bir ölçü ve düzen içinde olduğuna, "
                  "benim de seçimlerimden sorumlu olduğuma inanıyorum.\""),
        "aciklama": ("Her şeyin Allah'ın ilmi ve takdiriyle bir düzen içinde olması "
                     "ve insanın iradesiyle sorumluluk taşıması kadere imanın "
                     "konusudur."),
        "sec": [
            ("Kadere iman", "cümle ölçü, düzen ve iradeyle sorumluluğu bir arada söylüyor", ""),
            ("Ahirete iman", "sorumluluk hesap gününde sorulacağı için cümle ahireti anlatıyor",
             "Sorumluluk ahirette sorulsa da cümle ikinci bir hayattan söz etmiyor. "
             "Konu evrendeki düzen ve insanın iradesi."),
            ("Allah'a iman", "evrenin düzenini yaratan Allah olduğundan cümle O'na imanı gösteriyor",
             "Yaratan Allah'tır ama cümle düzenin ölçüsünü ve insanın "
             "iradesini söylüyor. Bu, düzen ve irade konusudur."),
            ("Peygamberlere iman", "insana sorumluluğu öğreten elçilerdir",
             "Sorumluluğu elçiler öğretir ama cümlede bir elçi anılmıyor. "
             "İnanılan şey düzen ve irade."),
        ],
    },
    {
        "kayit": ("{a}: \"Gökleri ve yeri yaratanın tek olduğuna, O'ndan başka "
                  "ilah bulunmadığına inanıyorum.\""),
        "aciklama": ("Yaratıcının varlığı ve birliği Allah'a imanın özüdür. "
                     "Melekler, kitaplar, elçiler, ahiret ve kader Allah'a "
                     "imandan ayrı esaslar olarak sayılır."),
        "sec": [
            ("Allah'a iman", "cümle gökleri ve yeri yaratan yaratıcının varlığını ve birliğini söylüyor", ""),
            ("Kadere iman", "yaratılışta bir ölçü ve düzen bulunduğu için cümle kadere dayanıyor",
             "Düzen kaderin konusudur ama cümle düzenden değil, yaratanın "
             "bir olmasından söz ediyor."),
            ("Meleklere iman", "yaratılmış varlıkların içinde melekler de olduğu için cümle onlara bağlanır",
             "Meleklerin de yaratılmış olması cümleyi melek esasına çevirmez. "
             "Cümle yaratanın birliğini anlatıyor."),
            ("Ahirete iman", "yaratanın tek oluşu ahirette de geçerli olduğu için cümle ahireti anlatıyor",
             "Ahirette de geçerli olması cümleyi ahiret esası yapmaz. İnanılan "
             "şey yaratanın varlığı ve birliği."),
        ],
    },
]


@bulmaca(ders="din_kulturu", konu="inanc_esaslari", kademeler=(9, 10),
         agirlik=1.2)
def inanc_esaslari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir iman cümlesinin hangi inanç esasına girdiği, inanılan şeye bakılarak
    ayrılır; esaslar birbirinin yerine geçmez.

    MEB satırları: İslam'ın inanç esasları, Nisâ 136, ayet ve hadislerle
    inanç esasları, Bakara 177.
    """
    durum = rastgele.choice(_ESAS_HAVUZU)
    a = ad_sec(rastgele, PERSONEL, 1)[0]
    kayit = durum["kayit"].format(a=a)

    return Bulmaca(
        kod="din-inanc-esaslari",
        ders="din_kulturu",
        baslik="İnanç Fişi",
        kademe=kademe,
        konu="inanc_esaslari",
        kazanim="İslam'ın inanç esaslarını (Allah, melekler, kitaplar, "
                "peygamberler, ahiret, kader) birbirinden ayırma.",
        dikkat=6,
        brifing=(
            "Üssün Kültür Odası'nda herkes bir inanç cümlesi bırakıyor. "
            "Kâtip Sarp bunları esaslarına göre fişlere ayıracak, ama altı "
            "esas birbirine karışmasın istiyor.\n\n"
            "Bugünkü cümle şu:\n\n  {}\n\n"
            "Fişe doğru esası yazmak gerekiyor."
        ).format(kayit),
        kanitlar=[
            Kanit("Bugünkü cümle", kayit, bedel=1, kritik=True),
            Kanit("Esas kartı", _ESAS_KARTI, bedel=2, kritik=True),
            Kanit("Fiş notu",
                  "\"Fişe, cümlenin hangi duyguyla söylendiği değil, neye "
                  "inanıldığı yazılır.\"", bedel=1, kritik=True),
            Kanit("Ayet notu (anlam özeti)",
                  "Nisâ 136: İman edenlere, Allah'a, Elçisine, indirdiği "
                  "kitaba ve daha önce indirdiği kitaplara iman etmeleri "
                  "öğütlenir. Allah'ı, meleklerini, kitaplarını, elçilerini "
                  "ve ahiret gününü inkâr eden kişinin doğru yoldan iyice "
                  "uzaklaşmış olacağı bildirilir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir iman cümlesinin hangi esasa girdiği neye bakılarak belirlenir?",
                dogru=_sik(_ESAS_YONTEMI[0][0], _ESAS_YONTEMI[0][1]),
                yanlislar={_sik(x, g): t for x, g, t in _ESAS_YONTEMI[1:]},
                rastgele=rastgele,
                aciklama=("Altı esas, iman edilen şeyin türüne göre ayrılır: Allah, "
                          "melekler, kitaplar, peygamberler, ahiret günü, kader. "
                          "Cümlenin üslubu ya da yazanı esası değiştirmez."),
                ipuclari=[
                    "Cümlede 'inanıyorum' sözünden sonra gelen şeyi bul: neye "
                    "inanılıyor?",
                    "Esas kartındaki altı tanımdan hangisi o şeyi anlatıyor?",
                ],
                puan=16,
                cozum=("1) Cümlede inanılan şeyi ayır (bir varlık mı, kitaplar mı, "
                       "elçiler mi, ikinci hayat mı, düzen mi?).\n"
                       "2) Esas kartında o şeyi tanımlayan satırı bul.\n\n"
                       "Ölçüt: iman edilen şey."),
            ),
            _siniflama(
                soru="Bugünkü cümle hangi inanç esasını anlatıyor?",
                sec=durum["sec"], rastgele=rastgele, aciklama=durum["aciklama"],
                ipuclari=["Cümlede neye inanıldığını söyleyen kısmı bul; sonra "
                          "kartta onu tanımlayan satırı ara."],
                puan=16),
            yorum_adimi(
                soru="Bir cümlede iki ayrı esas birlikte geçiyorsa fişe nasıl yazılmalı?",
                dogru=_sik("İki esas için ayrı kayıt açılmalı",
                           "ayette esaslar tek tek ve ayrı ayrı sayılır"),
                yanlislar={
                    _sik("Yalnız cümlenin son esası yazılmalı",
                         "cümlenin sonunda geçen esas asıl konu sayılır"):
                        "Sözcük sırası ağırlığı belirlemez. Cümlede iki esas "
                        "geçiyorsa ikisi de fişte yer almalı.",
                    _sik("Esaslardan biri ötekini içerdiği için tek kayıt yeterli",
                         "büyük esas küçüğün yerini tutar"):
                        "Esaslar birbirinin yerine geçmez: ayette de tek tek "
                        "sayılırlar. Biri sayılınca ötekiler kendiliğinden "
                        "yazılmış olmaz.",
                    _sik("Cümle hiç fişe yazılmamalı",
                         "birden çok esası olan cümle ayrıştırılamaz"):
                        "Cümle ayrıştırılabilir: her esası kendi tanımına göre "
                        "bulursun. Atılacak kayıt değil, bölünecek kayıttır.",
                },
                rastgele=rastgele,
                aciklama=("Nisâ 136 esasları tek tek anar; yani her biri ayrı bir "
                          "inanç konusudur. İki esası aynı cümlede söyleyen kişi "
                          "iki ayrı şeye inanmış olur ve fişe iki kayıt düşer."),
                ipuclari=["Ayette esaslar tek bir ifadeyle mi, tek tek mi sayılıyor?"],
                puan=14,
            ),
        ],
        kapanis="{} fişi doğru esasa yazdı; Kültür Odası'nın dosyasına eklendi.".format(a),
        odul={"itibar": 6, "erzak": 2},
    )


# ==========================================================================
# 2. PEYGAMBERİN GÖREVLERİ: tebliğ, tebyin, teşri, temsil; sünnetin türleri
# ==========================================================================

_GOREV_KARTI = (
    "TEBLİĞ: Allah'tan alınan vahyi insanlara eksiksiz ulaştırmak.\n"
    "TEBYİN: Vahyin anlamını sözle ve uygulamayla açıklamak.\n"
    "TEŞRİ: Vahyin çizdiği çerçevede dinî hükümleri ortaya koymak ve "
    "uygulamaya geçirmek.\n"
    "TEMSİL: Öğrettiği ilkeleri önce kendi hayatında yaşayarak örnek olmak."
)

_SUNNET_KARTI = (
    "SÜNNET: Hz. Muhammed'in söz, davranış ve onayları. Üç türü vardır.\n"
    "KAVLÎ SÜNNET: Peygamberin sözleri.\n"
    "FİİLÎ SÜNNET: Peygamberin yaptığı, uyguladığı işler.\n"
    "TAKRÎRÎ SÜNNET: Yanında yapılan bir davranışı görüp yasaklamayarak "
    "onaylaması.\n"
    "Kur'an ayetleri sünnetten ayrıdır: vahiy olarak indirilen sözdür."
)

_GOREV_YONTEMI = [
    ("Davranışın hangi amaca hizmet ettiğine bakılarak",
     "tebliğ, tebyin, teşri ve temsil amaçlarıyla ayrılır",
     ""),
    ("Davranışın hangi mekânda yapıldığına bakılarak",
     "Mekke'deki işler tebliğ, Medine'deki işler teşri sayılır",
     "Mekân görevi belirlemez: tebliğ de tebyin de her iki şehirde yapıldı. "
     "Ölçüt, davranışın amacı."),
    ("Davranışın kaç kişinin önünde yapıldığına bakılarak",
     "kalabalığa yapılan iş tebliğ, tek kişiye yapılan iş temsildir",
     "Dinleyici sayısı görevi değiştirmez. Aynı görev bir kişiye de bin kişiye "
     "de yapılabilir; amaca bakılır."),
    ("Davranışın ne zaman yapıldığına bakılarak",
     "ilk yıllardaki işler tebliğ, sonraki işler tebyin olur",
     "Zaman tek başına görevi göstermez. Ölçüt, davranışın vahiyle ilişkisi: "
     "ulaştırma mı, açıklama mı, hüküm mü, örnek mi."),
]

_GOREV_HAVUZU = [
    {
        "kayit": ("Hz. Muhammed, Safa Tepesi'nde halkı toplayıp kendisine "
                  "indirilen vahyi onlara duyurdu."),
        "aciklama": ("Vahyi eksiksiz ulaştırmak tebliğdir. Burada ne açıklama, "
                     "ne yeni bir düzenleme, ne de örnek olma öne çıkıyor: "
                     "gelen mesaj olduğu gibi duyuruluyor."),
        "sec": [
            ("Tebliğ", "olayın amacı vahyi insanlara eksiksiz ulaştırmak", ""),
            ("Tebyin", "duyurulan mesajın anlamı halka ayrıca açıklanıyor",
             "Kayıtta mesajın anlamı açıklanmıyor, yalnız duyuruluyor. Açıklama "
             "ve uygulamayla gösterme tebyinin işidir."),
            ("Teşri", "toplanan halka yeni bir hüküm bildirilip uygulanıyor",
             "Olayda yeni bir hüküm ortaya konmuyor; vahiy duyuruluyor. Hüküm "
             "koymak ve uygulamaya geçirmek teşridir."),
            ("Temsil", "toplananlar peygamberin hayatından örnek alıyor",
             "Kayıtta peygamberin yaşantısı değil, vahyi duyurması var. Örnek "
             "olma temsilin alanı."),
        ],
    },
    {
        "kayit": ("Hz. Muhammed, hac mevsiminde kabile kabile dolaşıp Allah'tan "
                  "aldığı mesajı insanlara okudu."),
        "aciklama": ("Mesajı kabile kabile götürüp okumak, vahyi insanlara "
                     "ulaştırmaktır: tebliğ. Okunan mesajın ayrıca "
                     "yorumlanması olayın konusu değil."),
        "sec": [
            ("Tebliğ", "olayda vahiy farklı topluluklara ulaştırılıyor", ""),
            ("Temsil", "kabileler peygamberin ahlakını görerek etkileniyor",
             "Olay peygamberin yaşayışını değil, mesajı götürmesini anlatıyor. "
             "Yaşayarak örnek olma temsildir."),
            ("Tebyin", "okunan mesajın her kabileye ayrıca anlatılıyor",
             "Kayıtta anlamın açıklanması yok; mesaj okunuyor. Tebyin, mesajın "
             "anlamını açıklamaktır."),
            ("Teşri", "kabilelere yeni düzenlemeler getiriliyor",
             "Kayıtta bir düzenleme ya da hüküm yok. Konu vahyin kendisini "
             "duyurmak."),
        ],
    },
    {
        "kayit": ("Kur'an'da namaz emredilir ama nasıl kılınacağı ayrıntılı "
                  "yazılmaz. Hz. Muhammed namazı kıldırıp \"Beni nasıl "
                  "kılarken görüyorsanız öyle kılın\" dedi."),
        "aciklama": ("Vahyin emrettiği ibadetin nasıl yapılacağını sözle ve "
                     "uygulamayla göstermek tebyindir. Kur'an'ın kısa bıraktığı "
                     "yeri peygamber açıklıyor."),
        "sec": [
            ("Tebyin", "olayda vahyin emri söz ve uygulamayla açıklanıyor", ""),
            ("Tebliğ", "namaz emri insanlara ulaştırılıyor",
             "Emir zaten ayetle bildirilmiş; olay onun nasıl yerine "
             "getirileceğini gösteriyor. Ulaştırmak tebliğdir."),
            ("Teşri", "olayda namaz için yeni bir hüküm konuyor",
             "Namazın farz oluşu vahiyle bildirilmiş. Olay yeni hüküm değil, "
             "var olan emrin uygulamasını gösteriyor."),
            ("Temsil", "peygamber namazı kendi hayatında yaşayarak örnek oluyor",
             "Örnek olma yönü vardır ama olayın asıl amacı \"nasıl kılınır\" "
             "sorusuna cevap vermek: açıklama."),
        ],
    },
    {
        "kayit": ("Hz. Muhammed, doğruluk ve emanet ilkesini öğretmeden çok "
                  "önce hayatında öyle yaşadı ki halk ona \"el-Emîn\" "
                  "(güvenilir) dedi."),
        "aciklama": ("Öğrettiği ilkeyi önce kendi hayatında yaşamak ve başkalarına "
                     "örnek olmak temsildir. Burada ne vahiy duyuruluyor ne de "
                     "bir hüküm konuyor."),
        "sec": [
            ("Temsil", "olayda ilke önce kendi hayatında yaşanıyor", ""),
            ("Tebliğ", "halka doğruluk ilkesi öğüt olarak duyuruluyor",
             "Kayıtta bir mesaj duyurulmuyor; kişinin yaşayışı anlatılıyor. "
             "Duyurma tebliğdir; kayıtta ise bir kişinin yaşayışı anlatılıyor."),
            ("Tebyin", "halka doğruluğun anlamı sözle açıklanıyor",
             "Olayda açıklama yok; kişinin kendi davranışı var. Tebyin söz ve "
             "uygulamayla anlam göstermektir."),
            ("Teşri", "güvenilirlik için halka yeni bir hüküm konuyor",
             "Kayıtta hüküm ortaya konmuyor. Bu, bir kişinin yaşayışıyla "
             "kazandığı güvenin anlatımı."),
        ],
    },
    {
        "kayit": ("Hz. Muhammed, Medine çarşısını dolaşıp ölçü ve tartıda hileyi "
                  "yasakladı ve bu yasağı çarşıda uygulattı."),
        "aciklama": ("Vahyin adalet ve dürüstlük ilkeleri çerçevesinde bir "
                     "düzenlemeyi ortaya koyup uygulamaya geçirmek teşri "
                     "olarak anlatılır. Hüküm koyma yetkisinin Allah'a ait "
                     "olduğu, peygamberin vahyin çerçevesinde hareket ettiği "
                     "unutulmamalı."),
        "sec": [
            ("Teşri", "olayda vahyin çerçevesinde bir hüküm uygulanıyor", ""),
            ("Tebyin", "olayda bir ayetin anlamı çarşıdaki halka açıklanıyor",
             "Kayıtta bir ayet açıklanmıyor; bir düzenleme çarşıda "
             "uygulanıyor. Tebyin, bir ayetin anlamını açıklamaktır."),
            ("Tebliğ", "çarşıdaki halka vahiy olduğu gibi duyuruluyor",
             "Kayıtta vahyin duyurulması değil, bir hükmün uygulanması var. "
             "Duyurmak tebliğdir."),
            ("Temsil", "peygamber çarşıda kendi dürüstlüğüyle örnek oluyor",
             "Olayın merkezinde peygamberin kendi yaşantısı yok; yasağın "
             "konması ve uygulanması var."),
        ],
    },
]

_SUNNET_HAVUZU = [
    {
        "kayit": "Hz. Muhammed şöyle buyurdu: \"Ameller niyetlere göredir.\"",
        "aciklama": ("Peygamberin söylediği söz kavlî sünnettir. Kur'an'dan "
                     "farkı, vahiy olarak indirilen söz değil, peygamberin "
                     "kendi sözü olmasıdır."),
        "sec": [
            ("Kavlî sünnet", "kayıt peygamberin söylediği bir sözü aktarıyor", ""),
            ("Fiilî sünnet", "kayıtta peygamberin yaptığı bir iş anlatılıyor",
             "Kayıtta bir uygulama yok, bir söz var. Fiilî sünnet, "
             "peygamberin yaptığı işlerdir."),
            ("Takrîrî sünnet", "peygamber sözle bir davranışı onaylıyor",
             "Takrîrî sünnette peygamber yanında yapılan bir davranışı "
             "yasaklamayarak onaylar. Kayıttaki ise onun kendi sözü."),
            ("Kur'an ayeti", "söz kutsal bir sözdür ve ilahî bir mesaj taşıyor",
             "Kur'an ayetleri vahiy olarak indirilen sözdür. Kayıttaki söz "
             "peygamberin kendi sözü olarak aktarılıyor."),
        ],
    },
    {
        "kayit": ("Sahabiler Hz. Muhammed'in abdest alışını izledi ve "
                  "yaptıklarını sırayla öğrenip uyguladı."),
        "aciklama": ("Peygamberin yaptığı, uyguladığı işler fiilî sünnettir. "
                     "Abdestin nasıl alındığı bu yolla aktarılmıştır."),
        "sec": [
            ("Fiilî sünnet", "kayıtta peygamberin yaptığı uygulama aktarılıyor", ""),
            ("Kavlî sünnet", "sahabiler peygamberden bir şey dinleyip öğreniyor",
             "Kayıtta peygamberin bir sözü yok, yaptığı iş izleniyor. "
             "Kavlî sünnet, peygamberin sözleridir."),
            ("Takrîrî sünnet", "sahabilerin davranışını peygamber onaylıyor",
             "Takrîrde sahabenin davranışı peygamberce onaylanır. Kayıtta "
             "ise peygamberin kendi uygulaması izleniyor."),
            ("Kur'an ayeti", "abdest ayette anıldığı için kayıt ayeti aktarıyor",
             "Kayıt bir ayet aktarmıyor, peygamberin uygulamasını anlatıyor. "
             "Ayet vahiy, uygulama ise sünnettir."),
        ],
    },
    {
        "kayit": ("Bir sahabi, Hz. Muhammed'in yanında yenmesinde sakınca "
                  "olmayan bir yiyeceği yedi; peygamber onu görüp bir şey "
                  "söylemeden onayladı."),
        "aciklama": ("Yanında yapılan bir davranışı görüp yasaklamayarak "
                     "onaylamak takrîrî sünnettir. Peygamber ne söz söyledi ne "
                     "yeni bir iş yaptı; onayı sünnet oldu."),
        "sec": [
            ("Takrîrî sünnet", "peygamber yanında yapılan davranışı görüp yasaklamayarak onayladı", ""),
            ("Kavlî sünnet", "peygamberin tepkisi bir söz olarak aktarılıyor",
             "Kayıtta peygamber bir şey söylemiyor; sessiz kalarak "
             "onaylıyor. Söz kavlî sünnetin işidir."),
            ("Fiilî sünnet", "peygamber de aynı yiyeceği yiyerek bir iş yapmış oluyor",
             "Kayıtta peygamberin yaptığı bir iş değil, sahabinin davranışına "
             "tepkisizliği var. Fiilî sünnet kendi uygulamasıdır."),
            ("Kur'an ayeti", "yiyeceklerle ilgili hüküm ayette bildirildiği için kayıt ayetten aktarılıyor",
             "Kayıtta ayet aktarımı yok. Bir davranışın peygamberce "
             "onaylanması vahiy değil, sünnettir."),
        ],
    },
]


@bulmaca(ders="din_kulturu", konu="peygamber_gorevleri", kademeler=(9, 11),
         agirlik=1.2)
def peygamber_gorevleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir olayın peygamberin hangi görevine (tebliğ, tebyin, teşri, temsil)
    girdiği ve bir kaydın sünnetin hangi türü olduğu ayrılır.

    MEB satırları: tebliğ, tebyin, teşri ve temsil görevleri; Ahzâb 45-46 ve
    Nahl 43-44; hadis, sünnet ve peygambere bağlılık.
    """
    durum = rastgele.choice(_GOREV_HAVUZU)
    sunnet = rastgele.choice(_SUNNET_HAVUZU)

    return Bulmaca(
        kod="din-peygamber-gorevleri",
        ders="din_kulturu",
        baslik="Elçi Kaydı",
        kademe=kademe,
        konu="peygamber_gorevleri",
        kazanim="Peygamberin görevlerini (tebliğ, tebyin, teşri, temsil) ve "
                "sünnetin türlerini ayırt etme.",
        dikkat=6,
        brifing=(
            "Kültür Odası'ndaki Elçi Kaydı iki ayrı soruyla açılıyor: bir "
            "olay peygamberin hangi görevini gösteriyor, bir aktarım da "
            "sünnetin hangi türü?\n\n"
            "Bugünkü olay:\n\n  \"{}\"\n\n"
            "Bugünkü aktarım:\n\n  \"{}\"\n\n"
            "İkisini de kartlara göre sınıflaman gerekiyor."
        ).format(durum["kayit"], sunnet["kayit"]),
        kanitlar=[
            Kanit("Olay kaydı", durum["kayit"], bedel=1, kritik=True),
            Kanit("Görev kartı", _GOREV_KARTI, bedel=2, kritik=True),
            Kanit("Sünnet kartı", _SUNNET_KARTI, bedel=2, kritik=True),
            Kanit("Aktarım kaydı", sunnet["kayit"], bedel=1, kritik=True),
            Kanit("Ayet notu (anlam özeti)",
                  "Ahzâb 45-46: Peygamberin şahit, müjdeleyici, uyarıcı, "
                  "Allah'ın izniyle O'na çağıran ve aydınlatan bir kandil "
                  "olarak gönderildiği bildirilir.\n"
                  "Nahl 44: Peygambere, insanlara kendilerine indirileni "
                  "açıklaması için Kur'an'ın indirildiği hatırlatılır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir olayın peygamberin hangi görevine girdiği neye bakılarak belirlenir?",
                dogru=_sik(_GOREV_YONTEMI[0][0], _GOREV_YONTEMI[0][1]),
                yanlislar={_sik(x, g): t for x, g, t in _GOREV_YONTEMI[1:]},
                rastgele=rastgele,
                aciklama=("Görevi, olayın mekânı, zamanı ya da dinleyici sayısı değil, "
                          "davranışın vahiyle ilişkisi belirler: vahyi ulaştırma "
                          "(tebliğ), açıklama (tebyin), hüküm ortaya koyma "
                          "(teşri) ya da örnek olma (temsil)."),
                ipuclari=[
                    "Olayda peygamber vahiyle ne yapıyor: ulaştırıyor mu, "
                    "açıklıyor mu, hüküm mü koyuyor, yoksa yaşayarak mı gösteriyor?",
                ],
                puan=16,
                cozum=("1) Olayda peygamberin yaptığı şeyi tek cümleyle söyle.\n"
                       "2) Görev kartında o cümleyi karşılayan tanımı bul.\n\n"
                       "Ölçüt: davranışın amacı."),
            ),
            _siniflama(
                soru="Olay kaydı peygamberin hangi görevini gösteriyor?",
                sec=durum["sec"], rastgele=rastgele, aciklama=durum["aciklama"],
                ipuclari=["Olayın amacı vahyi duyurmak mı, anlamını açmak mı, "
                          "hüküm koymak mı, örnek olmak mı?"],
                puan=16),
            _siniflama(
                soru="Aktarım kaydı sünnetin hangi türüdür?",
                sec=sunnet["sec"], rastgele=rastgele, aciklama=sunnet["aciklama"],
                ipuclari=["Kayıtta peygamberin söylediği mi, yaptığı mı, yoksa "
                          "yanında yapılana tepkisi mi anlatılıyor?"],
                puan=14, yorum=True),
        ],
        kapanis="Elçi Kaydı iki satırıyla tamamlandı ve Kültür Odası'nın dosyasına geçti.",
        odul={"itibar": 6, "erzak": 2},
    )


# ==========================================================================
# 3. TOPLUMSAL AHLAK (Hucurât 11-13)
# ==========================================================================

_AHLAK_KARTI = (
    "ALAY: Birini küçümseyerek eğlence konusu yapmak.\n"
    "KÖTÜ LAKAP: Birine kendisini rahatsız eden bir ad takmak.\n"
    "KÖTÜ ZAN: Delili olmadan birini kötülükle suçlamak.\n"
    "TECESSÜS: Birinin gizli kalmış hâllerini araştırmak.\n"
    "GIYBET: Birini, arkasından, hoşlanmayacağı gerçek bir şeyle anmak."
)

_AHLAK_YONTEMI = [
    ("Davranışın kime, nasıl ve neye dayanarak yapıldığına bakılarak",
     "her davranışın tanımı ayrıdır",
     ""),
    ("Davranışı yapan kişinin niyetine bakılarak",
     "niyet iyiyse davranış ahlaki bir kusur sayılmaz",
     "Niyet önemlidir ama davranışın türünü belirleyen tanımıdır. İyi niyetle "
     "bile birine ad takmak ya da arkasından konuşmak yine o türdendir."),
    ("Davranışın kaç kişi tarafından görüldüğüne bakılarak",
     "kalabalığın önündeki davranışlar alay, gizli olanlar gıybettir",
     "Davranışın izleyici sayısı türü belirlemez. Gıybet kalabalıkta da, "
     "alay iki kişi arasında da olabilir."),
    ("Davranışın sonucunda kimin gülüp kimin üzüldüğüne bakılarak",
     "gülen varsa alay, üzülen varsa gıybet sayılır",
     "Sonuç türü göstermez. Kötü lakap da kötü zan da kişiyi üzer; ayıran "
     "şey davranışın tanımıdır."),
]

_AHLAK_HAVUZU = [
    {
        "kayit": ("{a}, sınıfa yeni gelen arkadaşı {b} için herkesin önünde "
                  "konuşma biçimini taklit edip onu eğlence konusu yapıyor."),
        "aciklama": ("Birini küçümseyerek eğlence konusu yapmak alaydır. {b} "
                     "karşıda olduğu için gıybet, ad takılmadığı için de kötü "
                     "lakap değil: davranışın merkezinde küçümseme var."),
        "sec": [
            ("Alay", "davranış kişiyi küçümseyip herkese eğlence konusu yapıyor", ""),
            ("Gıybet", "kişi hakkında konuşuluyor ve söylenenler hoşuna gitmeyecek",
             "Gıybette kişi arkasından anılır. Burada o karşıda ve taklit "
             "edilerek küçümseniyor; bu alaydır."),
            ("Kötü lakap", "kişiyi rahatsız eden bir biçimde adlandırılıyor",
             "Kayıtta kişiye takılan bir ad yok. Taklitle küçümseme var; "
             "lakap, rahatsız eden bir ad takmaktır."),
            ("Kötü zan", "davranış kişiyle ilgili olumsuz bir kanıya dayanıyor",
             "Kötü zan, delilsiz suçlamadır. Kayıtta bir suçlama yok; kişi "
             "taklit edilerek küçük düşürülüyor."),
        ],
    },
    {
        "kayit": ("{a}, arkadaşı {b} için sınıfta herkesin gülüp geçtiği, onu kızartan bir "
                  "ad takmış ve onu hep bu adla çağırıyor."),
        "aciklama": ("Birine kendisini rahatsız eden bir ad takmak kötü lakaptır. "
                     "Gülüşmeler davranışın etrafında olabilir ama davranışın "
                     "kendisi adlandırma."),
        "sec": [
            ("Kötü lakap", "kişiye rahatsız eden bir ad takılmış ve o adla çağrılıyor", ""),
            ("Alay", "kişi herkesin önünde gülünç duruma düşürülüyor",
             "Gülüşme vardır ama davranışın merkezinde bir ad takmak var. "
             "Alay, ad takmadan küçümsemektir; burada ad takılmış."),
            ("Gıybet", "kişi hakkında yokken konuşulup hoşlanmayacağı şeyler söyleniyor",
             "Kayıtta kişi yokken söylenen gerçek bir şey yok. Davranış "
             "kişiye ad takmak ve onu o adla çağırmak."),
            ("Kötü zan", "ad, kişiyle ilgili olumsuz bir kanıya dayanıyor",
             "Kayıtta kanıtsız bir suçlama yok. Ad takmak başlı başına "
             "ayrı bir davranıştır."),
        ],
    },
    {
        "kayit": ("Depodan bir çuval eksilmiş. {a}, hiçbir kanıt yokken \"bunu "
                  "{b} almıştır\" diyerek ona kuşkuyla bakıyor."),
        "aciklama": ("Delili olmadan birini kötülükle suçlamak kötü zandır. Eksik "
                     "çuval için bir kanıt gösterilmedi; kuşku yalnızca "
                     "tahmine dayanıyor."),
        "sec": [
            ("Kötü zan", "kişi delilsiz olarak kötülükle suçlanıp kuşkuyla izleniyor", ""),
            ("Tecessüs", "kişi hakkında bir şeyler araştırılıp gizli yönleri sorgulanıyor",
             "Tecessüs, gizli kalmış hâlleri araştırmaktır. Kayıtta araştırma "
             "yok; kanıtsız bir kuşku yürütülüyor."),
            ("Gıybet", "kişi hakkında kuşkulu sözler söylenip başkalarına aktarılıyor",
             "Gıybet, arkasından gerçek bir şeyle anmaktır. Burada söylenen "
             "gerçek değil, delilsiz bir suçlama."),
            ("Alay", "kuşkulu bakış kişiyi başkalarının önünde küçük düşürüyor",
             "Alay, eğlence konusu yapmaktır. Kuşkuyla bakmak küçümseme "
             "değil, delilsiz suçlama."),
        ],
    },
    {
        "kayit": ("{a}, kimse izin vermediği hâlde arkadaşı {b} yokken çekmecedeki kişisel "
                  "defteri karıştırıp özel hâllerini öğrenmeye çalışıyor."),
        "aciklama": ("Birinin gizli kalmış hâllerini araştırmak tecessüstür. Burada "
                     "izinsiz bir araştırma var; henüz kimseye söylenmiş ya da "
                     "suçlanmış bir şey yok."),
        "sec": [
            ("Tecessüs", "davranış kişinin gizli kalmış hâllerini araştırmaya yönelik", ""),
            ("Kötü zan", "kişi hakkında kuşku duyulduğu için defteri karıştırılıyor",
             "Kayıtta kuşkulanıldığı ya da suçlandığı yazmıyor; izinsiz "
             "araştırma var. Kuşku delilsiz suçlamadır."),
            ("Gıybet", "araştırılan bilgiler sonradan başkalarına anlatılacak",
             "Kayıtta anlatılan bir şey yok, yalnızca araştırma var. Gıybet "
             "söylenmiş sözdür."),
            ("Alay", "kişisel defter karıştırılarak kişi herkesin önünde küçük düşürülüyor",
             "Kayıtta küçümseme ya da eğlence yok. Davranış gizli hâlleri "
             "öğrenme isteği."),
        ],
    },
    {
        "kayit": ("{a}, {b} yokken arkadaşlarına onun gerçekten yaptığı bir "
                  "yanlışı, hoşlanmayacağını bilerek anlatıyor."),
        "aciklama": ("Birini, arkasından, hoşlanmayacağı gerçek bir şeyle anmak "
                     "gıybettir. Söylenen şey yalan olsaydı bu başka bir "
                     "ahlaki sorun olurdu; burada gerçek olması gıybeti "
                     "ortadan kaldırmaz."),
        "sec": [
            ("Gıybet", "kişi yokken, hoşlanmayacağı gerçek bir şeyle anılıyor", ""),
            ("Kötü zan", "kişi hakkında delilsiz ve olumsuz bir şey söyleniyor",
             "Kötü zan delilsizdir. Kayıtta söylenen şey gerçek bir yanlış; "
             "mesele delilsizlik değil, arkasından konuşmak."),
            ("Tecessüs", "kişiyle ilgili gizli bilgiler öğrenilip yayılıyor",
             "Kayıtta gizli bir şey araştırılmıyor; bilinen bir yanlış "
             "anlatılıyor. Davranışın adı arkasından konuşmak."),
            ("Kötü lakap", "kişi, rahatsız eden bir biçimde adlandırılıyor",
             "Kayıtta kişiye takılan bir ad yok. Konuşma, yokken "
             "hoşlanmayacağı bir gerçeği anlatmak."),
        ],
    },
]

_USTUNLUK_HAVUZU = [
    {
        "kayit": ("Ambar ekibinin bir kısmı, doğu yöresinden gelen arkadaşlarına "
                  "\"Sizin yörenizden gelen bizden aşağıdır\" diyor."),
        "aciklama": ("Hucurât 13'ün mesajı: insanlar bir erkek ve bir dişiden "
                     "yaratılmış, topluluklara tanışsınlar diye ayrılmıştır; "
                     "üstünlük yörede ya da soyda değil, takvada (Allah'a saygı "
                     "ve kötülükten sakınma bilinci) aranır."),
        "sec": [
            ("Farklılığı tanışma vesilesi saymak", "ayet ayrılığı tanışma ve tanıma için sayar", ""),
            ("Yöreleri sıralayıp üstünü seçmek", "yöre üstünlüğü doğal ve gözlemlenen bir ölçüdür",
             "Ayet üstünlüğü yöreye bağlamaz; yörelerin ayrı olması tanışma "
             "içindir. Değer, kişinin sorumluluk bilincinde aranır."),
            ("Ekibi yöre yöre ayrı odalara bölmek", "benzerler bir arada daha verimli çalışır",
             "Ayrılığın amacı tanışmaktır, ayrı durmak değil. Bölmek ayetin "
             "mesajına ters düşer."),
            ("Konuyu sessizce geçiştirmek", "yöre sözleri gelip geçici olduğundan ilgilenmeye değmez",
             "Ayet bir ayrımcılık ölçüsünü açıkça reddeder; geçiştirmek "
             "söze karşı ayetin ilkesini uygulamamaktır."),
        ],
    },
    {
        "kayit": ("Telsiz odasında, farklı bir dil konuşan konvoy sürücüsü için "
                  "\"Dilini bilmeyen bizden sayılmaz\" deniyor."),
        "aciklama": ("Hucurât 13'e göre kavimler ve topluluklar tanışmak için "
                     "vardır; ayrı dil ayrı bir değer farkı sayılmaz. Değer "
                     "ölçüsü takvadır, yani sorumluluk bilinci ve kötülükten "
                     "sakınma."),
        "sec": [
            ("Dil farkını tanışma fırsatı saymak", "ayet topluluk ayrılıklarının tanışma için olduğunu söyler", ""),
            ("Ortak dili konuşmayanı dışarıda bırakmak", "ortak dil ortak değer ve güven demektir elbette",
             "Dilin ortak olması iletişimi kolaylaştırır ama değer ölçüsü "
             "değildir. Ayet ayrılığı dışlama değil, tanışma için sayar."),
            ("Sürücüyü yalnız görev anında kabul etmek", "iş bittiğinde ilişkinin de bitmesi gerekir diye düşünülür",
             "Ayet tanışmayı amaç sayar, görev süresini değil. Kabul bir "
             "iş ilişkisine sığdırılmamalı."),
            ("Yeni sürücünün dilinin değiştirilmesini istemek", "herkesin aynı dili konuşması bir iyiliktir ve uyum sağlar",
             "Ayet farklılığı tanışma vesilesi sayar; birini kendine "
             "benzetmeye çalışmak onu tanımak değildir."),
        ],
    },
    {
        "kayit": ("Mutfakta, hanesi geniş bir aileden gelen ekip arkadaşı için "
                  "\"Malı çok olan, sözü geçen olmalı\" deniyor."),
        "aciklama": ("Hucurât 13'e göre Allah katında en değerli olan, en çok "
                     "takva sahibi olandır; servet ya da mal değer ölçüsü "
                     "değildir. Takva burada sorumluluk bilinci ve "
                     "kötülükten sakınma demektir."),
        "sec": [
            ("Değeri sorumluluk bilincinde aramak", "ayete göre üstünlük takvaya bağlıdır", ""),
            ("Değeri zenginlikte aramak", "mal sahibi işi yaptıran ve yöneten kişidir",
             "Ayet değeri takvaya bağlar. Zenginlik bir imkândır, "
             "üstünlük ölçüsü değil."),
            ("Değeri ailenin büyüklüğünde aramak", "kalabalık aile her işte destek verir",
             "Aile desteği değerli olabilir ama ayet üstünlüğü kişinin "
             "takvasına bağlar, çevresinin büyüklüğüne değil."),
            ("Değeri en uzun süredir üste olmakta aramak", "kıdem tecrübenin en güçlü kanıtıdır",
             "Kıdem tecrübe katar ama değer ölçüsü olarak anılmaz. Ayet "
             "takvayı ölçü gösterir."),
        ],
    },
]


@bulmaca(ders="din_kulturu", konu="toplumsal_ahlak", kademeler=(9, 11),
         agirlik=1.2)
def toplumsal_ahlak(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Hucurât 11-12'deki toplumsal ahlaka aykırı davranışlar (alay, kötü
    lakap, kötü zan, tecessüs, gıybet) tanımına göre ayrılır; Hucurât 13'e
    göre farklılıklar karşısındaki tutum yorumlanır.

    MEB satırları: Hucurât 11-12 toplumsal ahlak; Hucurât 13 insanlık ve
    farklılıklar.
    """
    durum = rastgele.choice(_AHLAK_HAVUZU)
    ustunluk = rastgele.choice(_USTUNLUK_HAVUZU)
    a, b = ad_sec(rastgele, PERSONEL, 2)
    kayit = durum["kayit"].format(a=a, b=b)
    aciklama1 = durum["aciklama"].format(a=a, b=b)

    return Bulmaca(
        kod="din-toplumsal-ahlak",
        ders="din_kulturu",
        baslik="Üs İçi Davranış Defteri",
        kademe=kademe,
        konu="toplumsal_ahlak",
        kazanim="Toplumsal ahlaka aykırı davranışları (alay, lakap, kötü zan, "
                "tecessüs, gıybet) tanımlarına göre ayırma; farklılıklara "
                "karşı tutumu yorumlama.",
        dikkat=6,
        brifing=(
            "Üste yeni bir uyum kuralı yazılıyor ve davranış defteri her olayın "
            "adını doğru koymak istiyor. Adı yanlış konan olay yanlış çözülür.\n\n"
            "Bugünkü olay:\n\n  \"{}\"\n\n"
            "Ayrıca bir de farklılıklarla ilgili durum var:\n\n  \"{}\"\n\n"
            "İkisini de defterin tanımlarına göre değerlendirmen gerekiyor."
        ).format(kayit, ustunluk["kayit"]),
        kanitlar=[
            Kanit("Bugünkü olay", kayit, bedel=1, kritik=True),
            Kanit("Davranış kartı", _AHLAK_KARTI, bedel=2, kritik=True),
            Kanit("Farklılık durumu", ustunluk["kayit"], bedel=1, kritik=True),
            Kanit("Ayet notu (anlam özeti)",
                  "Hucurât 11-12: İnananlara birbirini alaya almamaları, "
                  "birbirine kötü lakap takmamaları, çoğu zandan kaçınmaları, "
                  "birbirinin gizli hâllerini araştırmamaları ve birbirini "
                  "arkasından çekiştirmemeleri öğütlenir.\n"
                  "Hucurât 13: İnsanların bir erkek ve bir dişiden "
                  "yaratıldığı, birbirini tanısınlar diye topluluklara "
                  "ayrıldığı, Allah katında en değerlinin takvaca en ileri "
                  "olan olduğu bildirilir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir olayın hangi toplumsal ahlak kusuruna girdiği neye bakılarak belirlenir?",
                dogru=_sik(_AHLAK_YONTEMI[0][0], _AHLAK_YONTEMI[0][1]),
                yanlislar={_sik(x, g): t for x, g, t in _AHLAK_YONTEMI[1:]},
                rastgele=rastgele,
                aciklama=("Alay, lakap, kötü zan, tecessüs ve gıybet ayrı "
                          "davranışlardır; her birinin kendi tanımı var. Olayı "
                          "izleyenlerin sayısı, niyet ya da sonuç türü "
                          "belirlemez; davranışın kendisi belirler."),
                ipuclari=[
                    "Olayda kişiye ne yapılıyor: küçümseniyor mu, ad mı takılıyor, "
                    "suçlanıyor mu, araştırılıyor mu, arkasından mı konuşuluyor?",
                ],
                puan=16,
                cozum=("1) Olayda yapılan davranışı tek cümleyle söyle.\n"
                       "2) Davranış kartında o cümleyi karşılayan tanımı bul.\n\n"
                       "Ölçüt: davranışın tanımı."),
            ),
            _siniflama(
                soru="Bugünkü olay hangi davranışa girer?",
                sec=[(ad, ger, tes.format(a=a, b=b) if tes else "")
                     for ad, ger, tes in durum["sec"]],
                rastgele=rastgele, aciklama=aciklama1,
                ipuclari=["Kayıttaki davranışın hedefi kim, hangi ortamda ve neye "
                          "dayanarak yapılıyor?"],
                puan=16),
            _siniflama(
                soru="Farklılık durumunda Hucurât 13'ün mesajına en uygun tutum hangisidir?",
                sec=ustunluk["sec"], rastgele=rastgele,
                aciklama=ustunluk["aciklama"],
                ipuclari=["Ayet insanların topluluklara ayrılmasının amacını ne "
                          "olarak bildiriyor?"],
                puan=14, yorum=True),
        ],
        kapanis="Davranış defterine olayın adı doğru yazıldı; uyum kuralı bu tanıma göre uygulanacak.",
        odul={"itibar": 6, "erzak": 2},
    )


# ==========================================================================
# 4. DİN, BİLİM VE FELSEFE: soruların yöntemi
# ==========================================================================

_YONTEM_KARTI = (
    "BİLİM: Gözlem, deney ve ölçümle cevap arar.\n"
    "FELSEFE: Akıl yürütme, kavram çözümleme ve tutarlılık sınamasıyla "
    "cevap arar.\n"
    "DİN: Cevabını vahiyden ve vahyin yorumundan alır; inanç, ibadet ve "
    "ahlak konularında bilgi kaynağı vahiydir.\n"
    "GÜNDELİK KANAAT: Dayanağı gösterilmemiş kişisel kanı; bu üç yoldan "
    "biri sayılmaz."
)

_YONTEM_YONTEMI = [
    ("Cevabın nasıl aranacağına bakılarak",
     "bilim ölçümle, felsefe akıl yürütmeyle, din vahiyle cevap arar",
     ""),
    ("Soruyu soran kişinin mesleğine bakılarak",
     "bilim insanının sorduğu soru bilim, din görevlisinin sorduğu soru dindir",
     "Soruyu sorarın mesleği sorunun türünü belirlemez; bilim insanı felsefi, "
     "din görevlisi bilimsel bir soru sorabilir. Cevap arama yolu belirler."),
    ("Sorunun ne kadar önemli olduğuna bakılarak",
     "önemli sorular dine, önemsiz sorular bilime aittir",
     "Önem, soruyu bir alana atamaz. Her alan önemli sorular da gündelik "
     "sorular da ele alır; ayıran şey cevap arama yoludur."),
    ("Soru cümlesinin kaç sözcükten oluştuğuna bakılarak",
     "kısa sorular bilimsel, uzun sorular felsefidir",
     "Cümlenin uzunluğunun yöntemle ilişkisi yoktur. Ayıran şey cevabın "
     "deneyle mi, akılla mı, vahiyle mi aranacağıdır."),
]

_YONTEM_HAVUZU = [
    {
        "kayit": "{a}: \"Aynı tohumlar farklı sıcaklıkta tutulursa hangisi kaç günde filizlenir?\"",
        "aciklama": ("Sıcaklığı değiştirip filizlenme süresini ölçerek cevap "
                     "aranır: bu bilimin yöntemidir. Akıl yürütmek ya da "
                     "vahye başvurmak ölçüm yerine geçmez."),
        "sec": [
            ("Bilim", "cevap sıcaklığı değiştirip filizlenme süresini ölçmekle bulunur", ""),
            ("Felsefe", "cevap tohumun doğası üzerine akıl yürütmekle bulunur",
             "Akıl yürütme sıcaklığın etkisini sayıya dökemez. Burada ölçüm "
             "ve deney gerekiyor."),
            ("Din", "cevap bitkilerin yaratılışını bildiren kaynaklardan öğrenilir",
             "Vahiy bitkilerin yaratıldığını bildirebilir ama bu sorunun "
             "cevabı sıcaklıkla filizlenme arasındaki sayısal ilişkidedir."),
            ("Gündelik kanaat", "sıcak havada tohumlar daha hızlı filizlenir diye düşünülür",
             "Böyle bir kanı dayanaksız bir tahmindir. Soruya cevap, "
             "ölçümle gösterilebilen bir ilişki ister."),
        ],
    },
    {
        "kayit": "{a}: \"Adalet ile eşitlik aynı şey midir, iki tanım birbiriyle çelişiyor mu?\"",
        "aciklama": ("İki kavramı tanımlayıp birbirleriyle tutarlı olup olmadığını "
                     "sınamak kavram çözümlemesidir: felsefenin yöntemi. Deney "
                     "ya da vahiy bu karşılaştırmanın yerine geçmez."),
        "sec": [
            ("Felsefe", "cevap kavramları çözümleyip tutarlılıklarını sınamakla bulunur", ""),
            ("Bilim", "cevap iki kavramı ölçerek bulunur",
             "Adalet ve eşitlik ölçü aletiyle okunacak büyüklükler değil. "
             "Soru kavramların tanımları ve tutarlılığıyla ilgili."),
            ("Din", "adalet vahiyde bildirilen bir ilke olduğu için cevap vahiyden alınır",
             "Vahiy adaleti bildirir ama sorulan şey iki kavramın tanımında "
             "çelişki olup olmadığı. Bu, kavramları çözümleyen akıl "
             "yürütmeyle yoklanır."),
            ("Gündelik kanaat", "iki kavram günlük hayatta aynı anlamda kullanıldığı için aynıdır",
             "Günlük kullanım dayanak göstermez. Soru tanımları sınayarak "
             "cevaplanır."),
        ],
    },
    {
        "kayit": "{a}: \"Namazın farz oluşu hangi kaynağa dayanıyor, bunu nasıl öğreniriz?\"",
        "aciklama": ("İbadetin hükmü ve dayanağı vahiyden ve vahyin yorumundan "
                     "öğrenilir; deney ya da kavram çözümlemesi bu sorunun "
                     "cevabını veremez. Din, ibadet konusunda bilgi kaynağı "
                     "olarak vahyi gösterir."),
        "sec": [
            ("Din", "ibadetin dayanağı vahiyden ve vahyin yorumundan öğrenilir", ""),
            ("Bilim", "cevap namaz kılan kişiler üzerinde ölçüm yaparak bulunur",
             "Ölçüm namazın bedene etkilerini gösterebilir ama bir "
             "ibadetin farz olup olmadığını belirleyemez."),
            ("Felsefe", "cevap ibadet kavramını çözümleyip tartışarak bulunur",
             "Kavram çözümlemesi ibadetin anlamını düşündürür ama hükmünün "
             "kaynağını göstermez. Bu kaynak vahiydir."),
            ("Gündelik kanaat", "büyüklerden duyulan bilgi her zaman yeterlidir",
             "Duyulan bilgi, kaynağı gösterilmedikçe dayanak olmaz. "
             "Soru kaynağı soruyor."),
        ],
    },
    {
        "kayit": "{a}: \"Işık boşlukta bir saniyede kaç kilometre yol alır?\"",
        "aciklama": ("Işığın hızı ölçüm yoluyla bulunan bir niceliktir. Gözlem ve "
                     "deney bilimin yöntemidir; akıl yürütme ya da vahiy bu "
                     "sayıyı veremez."),
        "sec": [
            ("Bilim", "cevap ışığın aldığı yol ve süre ölçülerek bulunur ve sınanır", ""),
            ("Felsefe", "cevap ışığın ne olduğu üzerine akıl yürütülerek bulunur",
             "Işığın doğası üzerine düşünmek bir şeydir, hızını bulmak "
             "başka. Hızı bulmak için ölçüm gerekir."),
            ("Din", "cevap evrenin yaratılışını bildiren kaynaklarda aranır",
             "Vahiy yaratıcıyı ve evrenin yaratıldığını bildirir ama ışığın "
             "sayısal hızını vermez. Bu, ölçümle bulunur."),
            ("Gündelik kanaat", "ışık çok hızlı olduğu için ölçülemeyeceği düşünülür",
             "Bu bir tahmin ve dayanaksız. Işığın hızı ölçülmüştür."),
        ],
    },
    {
        "kayit": "{a}: \"Bir şeyi bildiğimizi nasıl söyleriz, bilmek ile sanmak arasındaki fark nedir?\"",
        "aciklama": ("Bilginin ne olduğunu ve bilmekle sanmak arasındaki ayrımı "
                     "kavramlar ve tutarlılık üzerinden araştırmak felsefenin "
                     "bilgi alanıdır. Deney bu soruyu cevaplamaz; tanımlar ve "
                     "gerekçeler incelenir."),
        "sec": [
            ("Felsefe", "cevap bilgi kavramı çözümlenerek ve gerekçeler sınanarak aranır", ""),
            ("Bilim", "cevap bilmek ile sanmak arasındaki farkı ölçerek bulunur diye düşünülür",
             "Bilmek ile sanmak arasındaki fark ölçü aletiyle okunacak bir "
             "büyüklük değil, bir kavram ayrımı."),
            ("Din", "bilgi vahiyden geldiği için tüm bilgi soruları dine aittir",
             "Din de bilgi kaynaklarından söz eder ama sorulan, bilginin ne "
             "olduğu ve gerekçelendirilmesi: akıl yürütmeyle ele alınan bir soru."),
            ("Gündelik kanaat", "bilmek ve sanmak günlük dilde zaten aynı şeydir",
             "Günlük dilde karışabilir ama iki kavramı ayırmak soruyu "
             "çözümlemek demektir."),
        ],
    },
    {
        "kayit": "{a}: \"Meleklerin varlığı ve görevleri hakkında ne biliyoruz?\"",
        "aciklama": ("Gözle görülmeyen varlıkların bilgisi vahyin bildirdiği "
                     "inanç konusudur; gözlem ve deney yöntemleri bu konuda "
                     "cevap vermez. Din, bu bilgiyi vahiyden alır."),
        "sec": [
            ("Din", "melekler hakkındaki bilgi vahyin bildirdiği inanç konusudur", ""),
            ("Bilim", "cevap melekleri gözlem ve deneyle inceleyerek bulunur",
             "Gözlem ve deney yalnız gözlemlenebilen şeylere uygulanır. "
             "Gözle görülmeyen varlıklar bu yöntemin konusu değildir."),
            ("Felsefe", "cevap varlık kavramını çözümleyerek bulunur",
             "Kavram çözümlemesi varlık üzerine düşündürür ama meleklerin "
             "varlığı ve görevleri hakkında bilgi vermez."),
            ("Gündelik kanaat", "melekler hakkındaki düşünceler kişiden kişiye değişir",
             "Kişisel düşüncelerden söz edilmiyor. Soru bu konunun bilgi "
             "kaynağını soruyor: vahiy."),
        ],
    },
]


@bulmaca(ders="din_kulturu", konu="din_bilim_felsefe", kademeler=(11, 12),
         agirlik=1.2)
def din_bilim_felsefe(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir sorunun hangi yolla (bilim, felsefe, din) cevaplanacağı ayrılır;
    bir alanın cevabıyla ötekinin sorusunun karıştırılması sınanır.

    MEB satırları: din ve bilim ilişkisi; din, felsefe ve bilim ilişkisi;
    Âl-i İmrân 190-191 (akıl ve düşünme).
    """
    durum = rastgele.choice(_YONTEM_HAVUZU)
    a = ad_sec(rastgele, PERSONEL, 1)[0]
    kayit = durum["kayit"].format(a=a)

    return Bulmaca(
        kod="din-bilim-felsefe",
        ders="din_kulturu",
        baslik="Soru Panosu",
        kademe=kademe,
        konu="din_bilim_felsefe",
        kazanim="Din, bilim ve felsefenin soru türlerini ve cevap arama "
                "yollarını ayırt etme; alanlar arası ilişkiyi yorumlama.",
        dikkat=6,
        brifing=(
            "Üssün Soru Panosu'na herkes bir soru asıyor. Pano görevlisi her "
            "sorunun hangi yolla cevaplanacağını yazacak; yoksa bilimsel bir "
            "soru için vahye, inanç sorusu için termometreye başvurulur.\n\n"
            "Bugünkü soru şu:\n\n  {}\n\n"
            "Cevap arama yolunu doğru yazman gerekiyor."
        ).format(kayit),
        kanitlar=[
            Kanit("Bugünkü soru", kayit, bedel=1, kritik=True),
            Kanit("Yöntem kartı", _YONTEM_KARTI, bedel=2, kritik=True),
            Kanit("Pano notu",
                  "\"Panoya, sorunun ne kadar kıymetli olduğu değil, cevabının "
                  "hangi yolla aranacağı yazılır.\"", bedel=1, kritik=True),
            Kanit("Ayet notu (anlam özeti)",
                  "Âl-i İmrân 190-191: Göklerin ve yerin yaratılışında, gece "
                  "ile gündüzün birbirini izlemesinde akıl sahipleri için "
                  "deliller bulunduğu; onların ayakta, otururken ve yatarken "
                  "Allah'ı anıp yaratılış üzerinde düşündükleri bildirilir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir sorunun hangi alana ait olduğu neye bakılarak belirlenir?",
                dogru=_sik(_YONTEM_YONTEMI[0][0], _YONTEM_YONTEMI[0][1]),
                yanlislar={_sik(x, g): t for x, g, t in _YONTEM_YONTEMI[1:]},
                rastgele=rastgele,
                aciklama=("Her alanın kendi yöntemi var: bilim gözlem ve deneyle, "
                          "felsefe akıl yürütmeyle, din vahiy ve yorumuyla cevap "
                          "arar. Soruyu alana bağlayan, cevabın bu yollardan "
                          "hangisiyle aranacağıdır."),
                ipuclari=[
                    "Soruya cevap bulmak için ne yapmak gerekir: ölçmek mi, kavramları "
                    "tartmak mı, vahye bakmak mı?",
                ],
                puan=16,
                cozum=("1) Cevaba nasıl ulaşılacağını söyle (ölçüm, akıl yürütme, "
                       "vahiy).\n"
                       "2) Yöntem kartında o yolu anlatan alanı bul.\n\n"
                       "Ölçüt: cevabın aranacağı yol."),
            ),
            _siniflama(
                soru="Bugünkü sorunun cevabı hangi yolla aranır?",
                sec=durum["sec"], rastgele=rastgele, aciklama=durum["aciklama"],
                ipuclari=["Cevap ölçümle mi, kavramları tartarak mı, vahyin "
                          "bildirdiğine bakılarak mı bulunur?"],
                puan=16),
            yorum_adimi(
                soru="Biri \"Bilim bunu açıkladı, o hâlde din sorusu geçersiz\" diyorsa pano ne yazmalı?",
                dogru=_sik("İddianın hangi soruya cevap verdiğine bakılmalı",
                           "bilimin ölçtüğü ile dinin anlam soruları ayrı olabilir"),
                yanlislar={
                    _sik("Bilimin sonucu hiç dikkate alınmamalı",
                         "bilimin bütün sorulara verdiği cevaplar yanlış çıkmaya mahkûmdur"):
                        "Gözlem ve akıl bilgi kaynaklarıdır; ayet de akıl "
                        "sahiplerine yaratılış üzerinde düşünmeyi önerir. "
                        "Bilimin sonucunu yok saymak çözüm olmaz.",
                    _sik("Din sorusu da ölçümle cevaplanmalı",
                         "ölçülemeyen hiçbir şey gerçek bilgi sayılmaz ve dikkate alınmaz"):
                        "Her alanın yöntemi kendi sorusuna uygundur. Vahiy "
                        "konusunu termometreyle, sıcaklığı da vahiyle "
                        "cevaplamak yöntem karışıklığıdır.",
                    _sik("İddia sorgulanmadan kabul edilmeli",
                         "bilim her türlü soruya kesin cevap verebilen tek yoldur"):
                        "Bilim ölçülebilen soruları cevaplar; anlam ya da "
                        "ilke soruları başka yollarla ele alınır. İddianın "
                        "hangi soruya cevap verdiği yoklanmalı.",
                },
                rastgele=rastgele,
                aciklama=("Ders kitabında alanların soruları ve yöntemleri ayrı "
                          "anlatılır. Çelişki iddiası geldiğinde önce iddianın "
                          "hangi soruya cevap verdiği ve hangi yöntemle "
                          "ulaştığı yoklanır; yöntem karışmışsa çelişki "
                          "sanıldığı kadar derin değildir."),
                ipuclari=["Bilimin cevapladığı soru ile dinin ele aldığı soru "
                          "aynı mı?"],
                puan=14,
            ),
        ],
        kapanis="{} sorusunun yolunu Soru Panosu'na yazdı; pano o yola göre cevaplanacak.".format(a),
        odul={"itibar": 6, "erzak": 2},
    )
