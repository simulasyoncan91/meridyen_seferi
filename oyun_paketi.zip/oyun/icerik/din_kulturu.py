# -*- coding: utf-8 -*-
"""
İnanç, kültür ve ahlaki düşünme görevleri.

İçerik ders kitabı düzeyinde ve bilgi verici tutuldu: ibadetlerin hesaplanma
kuralları, ahlaki kavramların tanımları ve dinler hakkında olgusal bilgiler.
Metinler bir inancı savunmaz ya da eleştirmez; müfredatta öğretildiği biçimde
aktarır.

Hesaplamalı görevler (zekât gibi) bu derste keşif formatına çok uygun: kural
bellidir ama hangi malın hesaba katılacağını öğrenci kendisi çıkarır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi, sy, yorum_adimi,
)


# ==========================================================================
# ZEKÂT HESABI
# ==========================================================================

@bulmaca(ders="din_kulturu", konu="ibadetler", kademeler=(7, 12), agirlik=1.3)
def zekat_hesabi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Hangi malın hesaba katılacağı bulunacak, sonra kırkta bir uygulanacak."""
    birikim = rastgele.randrange(80, 200) * 1000
    borc = rastgele.randrange(10, 40) * 1000
    temel_ihtiyac = rastgele.choice([0, 0, 15000, 20000])   # oturduğu ev, kullandığı araç
    yeni_para = rastgele.randrange(10, 30) * 1000           # üzerinden yıl geçmemiş
    zekata_tabi = birikim - borc - temel_ihtiyac
    zekat = zekata_tabi / 40.0
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="din-zekat",
        ders="din_kulturu",
        baslik="Hesaptaki Pay",
        kademe=kademe,
        konu="ibadetler",
        kazanim="Zekâtın hesaplanma ölçütleri; zekâta tabi malın belirlenmesi.",
        dikkat=6,
        brifing=(
            "{} , yıl sonunda vereceği zekâtı hesaplamak için üsse danıştı. "
            "Elindeki kâğıtta birkaç ayrı kalem var ve hangilerinin hesaba "
            "katılacağını bilmiyor.\n\n"
            "\"Toplamın kırkta birini versem olmaz mı?\" diyor. Ama önce hangi "
            "toplamın alınacağına karar vermek gerekiyor: her mal zekâta tabi "
            "değil.\n\n"
            "Hesabı doğru çıkarmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Mal dökümü",
                  "Bir yıldır elinde duran birikim: {} TL\n"
                  "Ödenmemiş borç: {} TL\n"
                  "Oturduğu ev ve kullandığı eşya değeri: {} TL\n"
                  "Üç ay önce eline geçen para: {} TL".format(
                      birikim, borc, temel_ihtiyac, yeni_para),
                  bedel=2, kritik=True),
            Kanit("İlmihal notu - zekâtın şartları",
                  "Zekât, dinen zengin sayılacak kadar (nisap miktarı) mala sahip "
                  "olan kişiye gerekir. Zekâta tabi malda üç şart aranır:\n"
                  "  1) Temel ihtiyaçlardan (oturulan ev, kullanılan eşya) fazla olması\n"
                  "  2) Borçtan arta kalması\n"
                  "  3) Üzerinden bir yıl geçmiş olması",
                  bedel=2, kritik=True),
            Kanit("İlmihal notu - oran",
                  "Zekât oranı kırkta birdir (1/40), yani yüzde iki buçuk.",
                  bedel=1, kritik=True),
            Kanit("Nisap açıklaması",
                  "Nisap, zekâtın gerekli olması için gereken en az mal miktarıdır. "
                  "Bu miktarın altındaki mala zekât düşmez.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Zekât hangi tutar üzerinden hesaplanır?",
                dogru=("Borç ve temel ihtiyaçlar düşüldükten sonra kalan ve üzerinden "
                       "bir yıl geçmiş mal üzerinden."),
                yanlislar={
                    "Elindeki bütün paranın toplamı üzerinden.":
                        "Bütün varlığı hesaba kattın. Zekât, temel ihtiyaç ve "
                        "borç düşüldükten sonra ARTAN mal üzerinden "
                        "hesaplanır.",
                    "Yalnızca o yıl kazanılan para üzerinden.":
                        "Hesabı yıllık gelire indirdin. Ölçü gelir değil, "
                        "üzerinden bir yıl geçmiş birikmiş maldır.",
                    "Borçlar eklendikten sonraki toplam üzerinden.":
                        "Borcu artı yönde işledin. Borç, zekâta esas maldan "
                        "DÜŞÜLÜR; eklenmez.",
                    "Oturduğu evin değeri de dahil bütün varlık üzerinden.":
                        "Temel ihtiyacı hesaba kattın. Oturulan ev asli "
                        "ihtiyaçtır ve zekât matrahına girmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zekât, kişinin gerçekten \"artan\" malı üzerinden hesaplanır. Bu "
                    "yüzden önce borç düşülür (o mal aslında başkasınındır), sonra "
                    "temel ihtiyaçlar çıkarılır (oturulan ev, kullanılan eşya artan "
                    "mal sayılmaz). Ayrıca elde yeni bulunan mal, üzerinden bir yıl "
                    "geçmediği için o yılın hesabına katılmaz."
                ),
                ipuclari=[
                    "İlmihal notundaki üç şartı dökümdeki kalemlere tek tek uygula.",
                    "Üç ay önce eline geçen para bir yılı doldurmuş mu?",
                ],
                puan=20,
                cozum=(
                    "1) Bir yıldır elde duran birikim: {} TL (hesaba girer)\n"
                    "2) Borç düşülür: -{} TL\n"
                    "3) Temel ihtiyaç düşülür: -{} TL\n"
                    "4) Üç ay önceki para: yıl dolmadığı için bu yıl HESABA GİRMEZ\n\n"
                    "Zekâta tabi tutar: {} - {} - {} = {} TL\n"
                    "Zekât: {} / 40 = {} TL"
                ).format(birikim, borc, temel_ihtiyac, birikim, borc, temel_ihtiyac,
                         sy(zekata_tabi), sy(zekata_tabi), sy(zekat)),
            ),
            sayi_adimi(
                soru="Zekâta tabi tutar kaç TL?",
                cevap=zekata_tabi,
                birim="TL",
                aciklama=("{} - {} - {} = {} TL. Üç ay önce eline geçen para, "
                          "üzerinden bir yıl geçmediği için katılmaz.").format(
                    birikim, borc, temel_ihtiyac, sy(zekata_tabi)),
                ipuclari=[
                    "Birikimden borcu çıkar.",
                    "Sonra temel ihtiyaç değerini de çıkar; yeni parayı hiç ekleme.",
                ],
                tolerans=1.0,
                puan=16,
            ),
            sayi_adimi(
                soru="Verilmesi gereken zekât kaç TL?",
                cevap=zekat,
                birim="TL",
                aciklama="{} / 40 = {} TL (yüzde iki buçuk).".format(
                    sy(zekata_tabi), sy(zekat)),
                ipuclari=["Bulduğun tutarı kırka böl."],
                tolerans=1.0,
                puan=14,
            ),
            yorum_adimi(
                soru="Üç ay önce eline geçen para neden bu yılın hesabına katılmadı?",
                dogru="Üzerinden bir yıl geçmediği için; zekâtta malın bir yıl elde kalması aranır.",
                yanlislar={
                    "Miktarı az olduğu için.":
                        "Sebebi miktara bağladın. Tutar yeterli olsa da bu "
                        "para henüz gerekli SÜREYİ doldurmadı.",
                    "Borç sayıldığı için.":
                        "Parayı borç saydın. Kayıtta böyle bir bilgi yok; "
                        "dışarıda kalma sebebi zaman.",
                    "Temel ihtiyaç sayıldığı için.":
                        "Temel ihtiyaç saydın. Sorun paranın türü değil, "
                        "elde kalma süresi.",
                    "Zekâta hiçbir zaman tabi olmadığı için.":
                        "Parayı kalıcı olarak muaf saydın. Üzerinden bir yıl "
                        "geçtiğinde gelecek yılın hesabına girer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Şart, malın \"üzerinden bir yıl geçmesi\"dir. Bu para gelecek yılın "
                    "hesabına girecektir; hiç girmeyecek değildir. Bu ayrıntı, zekât "
                    "sorularında en sık gözden kaçan yerdir."
                ),
                puan=12,
            ),
        ],
        kapanis="Hesap yapıldı; {} zekâtını doğru tutar üzerinden ayırdı.".format(kisi),
        odul={"itibar": 7, "erzak": 3},
    )


# ==========================================================================
# AHLAKİ KAVRAMLAR
# ==========================================================================

@bulmaca(ders="din_kulturu", konu="ahlaki_degerler", kademeler=(5, 11))
def ahlaki_kavram(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir davranışın hangi ahlaki değeri örneklediği bulunacak."""
    ornekler = [
        {
            "olay": ("Kendisine bırakılan kapalı zarfı, içinde ne olduğunu merak "
                     "etmesine rağmen açmadan sahibine teslim etti."),
            "deger": "Emanete sadakat",
            "neden": ("Kendisine bırakılan bir şeyi korumak ve olduğu gibi geri "
                      "vermek emanet kavramının tanımıdır."),
        },
        {
            "olay": ("Kendi arkadaşının haksız olduğunu görünce, arkadaşı "
                     "olmasına rağmen karşı tarafı haklı buldu."),
            "deger": "Adalet",
            "neden": ("Yakınlık gözetmeden hakkı sahibine vermek adaletin "
                      "ayırt edici özelliğidir."),
        },
        {
            "olay": ("Hata yaptığını kimse fark etmemişken kendisi gidip "
                     "durumu bildirdi."),
            "deger": "Dürüstlük",
            "neden": ("Çıkarına aykırı olduğu hâlde doğruyu söylemek dürüstlüktür."),
        },
        {
            "olay": ("Uzun süre sonuç alamamasına rağmen işi bırakmadı, "
                     "öfkelenip başkalarını suçlamadı."),
            "deger": "Sabır",
            "neden": ("Zorluk karşısında dayanma ve dengeyi koruma sabırdır."),
        },
        {
            "olay": ("Yardıma ihtiyacı olan birini gördüğünde, tanımadığı hâlde "
                     "kendi işini erteleyip yardım etti."),
            "deger": "Merhamet",
            "neden": ("Başkasının sıkıntısını hissedip harekete geçmek merhamettir."),
        },
    ]
    ornek = rastgele.choice(ornekler)
    digerleri = [o["deger"] for o in ornekler if o["deger"] != ornek["deger"]]
    rastgele.shuffle(digerleri)

    return Bulmaca(
        kod="din-ahlaki-kavram",
        ders="din_kulturu",
        baslik="Tutanaktaki Davranış",
        kademe=kademe,
        konu="ahlaki_degerler",
        kazanim="Ahlaki kavramları davranış örnekleriyle eşleştirme.",
        dikkat=5,
        brifing=(
            "Üssün aylık değerlendirme tutanağına örnek davranışlar yazılıyor. "
            "Her davranışın yanına hangi değeri gösterdiği not edilecek.\n\n"
            "Elindeki kayıt şu:\n\n"
            "  \"{}\"\n\n"
            "Birden çok değer akla gelebilir; ama davranışı asıl belirleyen tek "
            "bir ölçüt var."
        ).format(ornek["olay"]),
        kanitlar=[
            Kanit("Davranış kaydı", ornek["olay"], bedel=1, kritik=True),
            Kanit("Değerler kılavuzu",
                  "ADALET: Yakınlık gözetmeden hakkı sahibine vermek.\n"
                  "EMANETE SADAKAT: Kendisine bırakılanı koruyup olduğu gibi "
                  "geri vermek.\n"
                  "DÜRÜSTLÜK: Çıkarına aykırı olsa da doğruyu söylemek.\n"
                  "SABIR: Zorluk karşısında dayanmak, dengeyi korumak.\n"
                  "MERHAMET: Başkasının sıkıntısını hissedip yardıma geçmek.",
                  bedel=2, kritik=True),
            Kanit("Değerlendirme notu",
                  "\"Bir davranışta birden çok güzel yan bulunabilir. Fişe, "
                  "davranışı asıl AYIRT EDEN değer yazılır: kişi neyi yapmasa da "
                  "olurdu, ama yaptı?\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir davranışın hangi değeri gösterdiğini ne belirler?",
                dogru="Davranışı asıl ayırt eden yön: kişinin hangi zorluğa rağmen ne yaptığı.",
                yanlislar={
                    "Davranışın kaç kişiyi etkilediği.":
                        "Kapsamı ölçüt saydın. Tek kişiye yapılan bir iyilik "
                        "de aynı değeri gösterir; belirleyici olan davranışın "
                        "NİTELİĞİ.",
                    "Davranışın ne kadar sürdüğü.":
                        "Süreyi ölçüt saydın. Bir anlık bir davranış da bir "
                        "değeri açıkça gösterebilir.",
                    "Kişinin o sırada nerede bulunduğu.":
                        "Yeri ölçüt saydın. Aynı davranış her yerde aynı "
                        "değere işaret eder.",
                    "Davranışın alışkanlık hâline gelip gelmediği.":
                        "Tekrarı şart koştun. Bir kez yapılan davranış da "
                        "hangi değere dayandığını gösterir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı davranış birden çok değere yakın durabilir. Ayırt edici "
                    "soru şudur: kişi neyi yapmamakta serbestti, buna rağmen ne "
                    "yaptı? Kapalı zarfı açmamak merhamet değil emanettir; çünkü "
                    "zorlandığı şey merak ve fırsattı."
                ),
                ipuclari=[
                    "Kişi burada neyi yapmamayı seçti?",
                    "Kılavuzdaki beş tanımı olayla tek tek karşılaştır.",
                ],
                puan=16,
                cozum=(
                    "1) Olayda kişinin karşı koyduğu şeyi bul (merak, çıkar, "
                    "yakınlık, zorluk, ilgisizlik).\n"
                    "2) Kılavuzdaki tanımlardan hangisi bu karşı koyuşu anlatıyor?\n"
                    "3) {}\n\n"
                    "Sonuç: {}"
                ).format(ornek["neden"], ornek["deger"]),
            ),
            secim_adimi(
                soru="Bu davranış hangi değeri gösterir?",
                dogru=ornek["deger"],
                yanlislar=digerleri[:4],
                rastgele=rastgele,
                aciklama=ornek["neden"],
                ipuclari=["Kılavuzdaki tanımları olayla karşılaştır."],
                puan=16,
            ),
            yorum_adimi(
                soru="Bir davranış aynı anda birden çok değeri gösterebilir mi?",
                dogru="Evet; ama fişe davranışı asıl ayırt eden değer yazılır.",
                yanlislar={
                    "Hayır; her davranış tek bir değere karşılık gelir.":
                        "Değerleri tek tek eşleştirdin. Bir yardım aynı anda "
                        "hem cömertlik hem merhamet gösterebilir.",
                    "Hayır; değerler birbirini dışlar.":
                        "Değerleri birbirine rakip saydın. Çoğu davranışta "
                        "birkaçı bir arada bulunur.",
                    "Evet; bu durumda hepsi fişe yazılır.":
                        "Doğru başlayıp yanlış bitirdin. Birden çok değer "
                        "gösterebilir ama fişe, davranışın en belirgin "
                        "dayanağı yazılır.",
                    "Evet; ama o zaman davranış değersiz sayılır.":
                        "Çokluğu değersizlik saydın. Birden çok değere "
                        "dayanan davranış daha güçlüdür, daha zayıf değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Değerler iç içe geçer: adaletli davranan kişi çoğu zaman dürüst "
                    "de davranır. Burada \"en uygun\" seçenek istenir; bu "
                    "yüzden hepsini birden işaretlemek değil, ayırt edici olanı seçmek "
                    "gerekir."
                ),
                puan=12,
            ),
        ],
        kapanis="Davranış tutanağa değeriyle birlikte işlendi.",
        odul={"itibar": 6},
    )


# ==========================================================================
# DİNLER HAKKINDA BİLGİ
# ==========================================================================

@bulmaca(ders="din_kulturu", konu="dinler_bilgisi", kademeler=(7, 12))
def dinler_bilgisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kronograf'ın getirdiği kayıt hangi dine ait? Olgusal ayırt etme."""
    dinler = [
        {
            "ad": "İslam",
            "kitap": "Kur'an-ı Kerim",
            "mabet": "cami",
            "isaret": ("Kayıtta günde beş vakit topluca kılınan bir ibadetten ve "
                       "ay takvimine göre tutulan bir aylık oruçtan söz ediliyor."),
        },
        {
            "ad": "Hristiyanlık",
            "kitap": "İncil",
            "mabet": "kilise",
            "isaret": ("Kayıtta haftalık ibadetin pazar günü yapıldığı ve "
                       "vaftiz adı verilen bir törenden söz ediliyor."),
        },
        {
            "ad": "Yahudilik",
            "kitap": "Tevrat",
            "mabet": "sinagog",
            "isaret": ("Kayıtta cumartesi gününün dinlenme ve ibadet günü olarak "
                       "tutulduğundan söz ediliyor."),
        },
    ]
    din = rastgele.choice(dinler)
    digerleri = [d for d in dinler if d["ad"] != din["ad"]]

    return Bulmaca(
        kod="din-dinler-bilgisi",
        ders="din_kulturu",
        baslik="Adı Yazılmamış Kayıt",
        kademe=kademe,
        konu="dinler_bilgisi",
        kazanim="Dinler hakkında temel bilgiler; kutsal kitap ve ibadet yeri eşleştirmesi.",
        dikkat=5,
        brifing=(
            "Kronograf bir topluluğun ibadet düzenini anlatan bir kayıt getirdi. "
            "Kayıtta dinin adı geçmiyor; yalnızca uygulamalar anlatılıyor:\n\n"
            "  \"{}\"\n\n"
            "Arşiv fişine hangi dine ait olduğu yazılacak. Kayıt bir inancı "
            "değerlendirmiyor, yalnızca uygulamaları aktarıyor; fişe de öyle "
            "yazılacak."
        ).format(din["isaret"]),
        kanitlar=[
            Kanit("Kayıt metni", din["isaret"], bedel=1, kritik=True),
            Kanit("Dinler bilgi çizelgesi",
                  "İSLAM - Kutsal kitap: Kur'an-ı Kerim - İbadet yeri: cami\n"
                  "  Günde beş vakit namaz, ramazan ayında oruç.\n\n"
                  "HRİSTİYANLIK - Kutsal kitap: İncil - İbadet yeri: kilise\n"
                  "  Haftalık ibadet pazar günü, vaftiz töreni.\n\n"
                  "YAHUDİLİK - Kutsal kitap: Tevrat - İbadet yeri: sinagog\n"
                  "  Cumartesi (Şabat) dinlenme ve ibadet günü.",
                  bedel=2, kritik=True),
            Kanit("Arşivci notu",
                  "\"Kayıtlar uygulamaları anlatır; fişe de olgu yazılır. "
                  "Değerlendirme yapmak arşivcinin işi değildir.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kaydın hangi dine ait olduğunu ne belirler?",
                dogru="Kayıtta anlatılan ibadet düzeninin, bilinen uygulamalarla eşleşmesi.",
                yanlislar={
                    "Kaydın ne kadar uzun olduğu.":
                        "Uzunluğu ölçüt saydın. Kısa bir kayıt da ayırt edici "
                        "bir uygulamayı anlatabilir.",
                    "Kayıttaki kişi sayısı.":
                        "Kişi sayısını ölçüt saydın. Belirleyici olan kaç kişi "
                        "olduğu değil, NE YAPTIKLARI.",
                    "Kaydın hangi coğrafyadan geldiği.":
                        "Coğrafyayı ölçüt saydın. Dinler tek bir bölgeye bağlı "
                        "değildir; aynı yerde birden çok inanç yaşar.",
                    "Kaydın hangi dilde yazıldığı.":
                        "Dili ölçüt saydın. Aynı din farklı dillerde yazılır; "
                        "ayırt edici olan ibadetin biçimi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ayırt edici bilgi, ibadetin ZAMANI ve BİÇİMİDİR: haftalık ibadet "
                    "günü, oruç düzeni, tören adları. Coğrafya ve dil yanıltıcıdır; "
                    "aynı dinin mensupları farklı ülkelerde ve dillerde yaşar."
                ),
                ipuclari=[
                    "Kayıtta hangi gün ya da hangi zaman düzeni geçiyor?",
                    "Çizelgedeki üç satırla karşılaştır.",
                ],
                puan=16,
                cozum=(
                    "1) Kayıttaki ibadet zamanını ve biçimini işaretle.\n"
                    "2) Çizelgedeki üç dinin uygulamalarıyla karşılaştır.\n"
                    "3) Eşleşen satır: {} (kutsal kitap: {}, ibadet yeri: {})\n\n"
                    "Sonuç: {}"
                ).format(din["ad"], din["kitap"], din["mabet"], din["ad"]),
            ),
            secim_adimi(
                soru="Bu kayıt hangi dine aittir?",
                dogru=din["ad"],
                yanlislar=dict(
                    [(d["ad"], "{} inancının ibadet düzeni kayıttakiyle "
                               "uyuşmuyor. Çizelgedeki satırı karşılaştır."
                               .format(d["ad"])) for d in digerleri]
                    + [("Belirlenemez",
                        "Kayıt yeterince ayırt edici: anlatılan uygulama "
                        "çizelgedeki tek bir satırla eşleşiyor.")]
                ),
                rastgele=rastgele,
                aciklama="Kayıttaki uygulama {} ile eşleşiyor.".format(din["ad"]),
                ipuclari=["Çizelgedeki ibadet düzenleriyle karşılaştır."],
                puan=14,
            ),
            secim_adimi(
                soru="Bu dinin kutsal kitabı ve ibadet yeri hangisidir?",
                dogru="{} - {}".format(din["kitap"], din["mabet"]),
                yanlislar=dict(
                    [("{} - {}".format(d["kitap"], d["mabet"]),
                      "Bu ikili {} inancına ait. Bir önceki adımda "
                      "belirlediğin dinin satırına bak.".format(d["ad"]))
                     for d in digerleri]
                    + [("{} - {}".format(din["kitap"], digerleri[0]["mabet"]),
                        "Kutsal kitabı doğru seçtin ama ibadet yerini başka "
                        "bir satırdan aldın. İkisi aynı satırda olmalı.")]
                ),
                rastgele=rastgele,
                aciklama="{} dininde kutsal kitap {}, ibadet yeri {}dir.".format(
                    din["ad"], din["kitap"], din["mabet"]),
                ipuclari=["Çizelgedeki ilgili satırı oku."],
                puan=14,
            ),
        ],
        kapanis="Kayıt fişlendi ve arşive kaldırıldı.",
        odul={"itibar": 6},
    )
