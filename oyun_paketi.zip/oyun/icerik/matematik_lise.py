# -*- coding: utf-8 -*-
"""
Matematik -- lise (9-12) boşlukları (B37.7).

`matematik.py` ilkokuldan liseye uzanan çekirdek görevleri taşır; bu modül MEB
konu haritasında (`oyun/veri/konu_haritasi.csv`) boş kalan lise satırlarını
kapatır. Her görevin `konu` adı haritadaki `onerilen_kod` ile AYNIDIR: konu
adı bire bir eşleşince satır kendiliğinden "hazır" sayılır.

Kurallar `ICERIK_EKLEME.md`'dekiyle aynı: sayılar yalnız `rastgele`den gelir,
her görevde en az bir model adımı vardır, yanlış şıklar bir öğrencinin
gerçekten yapacağı hatalardır ve teşhis cümlesi doğru cevabı söylemez.
İlk ekran sade tutulur (formül işareti yerine sözcük; ilk adım şıklıdır).
"""
from __future__ import annotations

import math
import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    DEPO_ADLARI, MEVKI_ADLARI, PERSONEL, ad_sec, coklu_adimi, coklu_siklar,
    model_adimi, sayi_adimi, secim_adimi, sy, yorum_adimi,
)


# ==========================================================================
# ÜÇGENLER
# ==========================================================================

@bulmaca(ders="matematik", konu="ucgen_aci_kenar", kademeler=(8, 11), agirlik=1.2)
def kablo_halkasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Üçgen eşitsizliği ve açı-kenar ilişkisi: kablo parçalarıyla halka kurma."""
    istasyon = ad_sec(rastgele, DEPO_ADLARI, 1)[0]
    depocu = ad_sec(rastgele, PERSONEL, 1)[0]

    def uclu_gecerli():
        x = rastgele.randrange(4, 14)
        y = rastgele.randrange(x, x + 7)
        z = rastgele.randrange(y, x + y)          # y <= z < x + y: halka kapanır
        return (x, y, z)

    gecerli = []
    while len(gecerli) < 2:
        aday = uclu_gecerli()
        if aday not in gecerli:
            gecerli.append(aday)
    x, y = rastgele.randrange(5, 13), rastgele.randrange(5, 13)
    tam_dogru = (x, y, x + y)                      # tek hatta uzanır, halka olmaz
    p, q = rastgele.randrange(4, 10), rastgele.randrange(4, 10)
    kisa = (p, q, p + q + rastgele.randrange(2, 6))  # uzun parça yetmez

    def yaz(uclu):
        sirali = list(uclu)
        rastgele.shuffle(sirali)
        return "{}, {} ve {} m".format(*sirali)

    def ac(uclu):
        k1, k2, uz = sorted(uclu)
        if k1 + k2 > uz:
            return "{}, {}, {}".format(k1, k2, uz), "{} + {} = {} > {}: halka kapanır".format(k1, k2, k1 + k2, uz)
        if k1 + k2 == uz:
            return "{}, {}, {}".format(k1, k2, uz), "{} + {} = {}: düz çizgi, halka olmaz".format(k1, k2, uz)
        return "{}, {}, {}".format(k1, k2, uz), "{} + {} = {} < {}: uçlar yetişmez".format(k1, k2, k1 + k2, uz)

    secenekler, dogrular = coklu_siklar(
        rastgele, [yaz(g) for g in gecerli], [yaz(tam_dogru), yaz(kisa)])

    # Açı-kenar adımı için ayrı bir üçgen: üç kenar birbirinden farklı.
    while True:
        kl, lm, mk = uclu_gecerli()
        if len({kl, lm, mk}) == 3:
            break
    kenarlar = [kl, lm, mk]
    rastgele.shuffle(kenarlar)
    kl, lm, mk = kenarlar
    # Köşe adı -> karşısındaki kenar
    karsi = {"K": lm, "L": mk, "M": kl}
    en_uzun_kose = max(karsi, key=karsi.get)
    en_kisa_kose = min(karsi, key=karsi.get)
    ortadaki_kose = [k for k in "KLM" if k not in (en_uzun_kose, en_kisa_kose)][0]

    p_min, p_max = sorted((rastgele.randrange(5, 13), rastgele.randrange(13, 20)))
    # p_min < p_max garanti: üçüncü kenar için kaç tam sayı cm olabilir
    adet = 2 * p_min - 1

    yorum_yanlislari = {}
    yorum_yanlislari["{} direğindeki açı".format(en_kisa_kose)] = (
        "Bu köşenin karşısındaki kenar üçünün en kısası; en küçük açı orada. "
        "Açı, kendi karşısındaki kenarla birlikte büyür.")
    yorum_yanlislari["{} direğindeki açı".format(ortadaki_kose)] = (
        "Bu köşenin karşısındaki kenar ne en uzun ne en kısa; açısı da "
        "ortada kalır. Üç kenarı karşılaştırınca fark görünür.")
    yorum_yanlislari["Üç açı da eşit"] = (
        "Eşit açı ancak eşit kenarla gelir; burada üç kenar da farklı, "
        "dolayısıyla üç açı da farklı.")

    return Bulmaca(
        kod="mat-kablo-halkasi",
        ders="matematik",
        baslik="Kablo Halkası",
        kademe=kademe,
        konu="ucgen_aci_kenar",
        kazanim="Üç uzunlukla üçgen çizilip çizilemeyeceğini ve açı-kenar ilişkisini yorumlama.",
        dikkat=5,
        brifing=(
            "{} deposunun çevresindeki üç sensör direği arasına üçgen biçiminde "
            "bir kablo halkası çekilecek. Kablolar hazır parçalar hâlinde geldi: "
            "her halka üç parçadan oluşacak, parçalar kesilmeyecek, yalnız uçlardan "
            "direklere bağlanacak.\n\n"
            "{} elindeki parçaları üçerli dizdi. Hangi üçlüyle halka kapanır, "
            "hangisinde kablolar yetmeyip düz bir çizgi gibi uzanır, bunu "
            "bilmeden direk dikilirse bütün gün boşa gider."
        ).format(istasyon, depocu),
        kanitlar=[
            Kanit("Kesim listesi",
                  "Hazır üçlüler (parça boyları): " + " | ".join(secenekler),
                  bedel=1, kritik=True),
            Kanit("Bağlantı şartı",
                  "\"Parçalar kesilmeyecek; uçlar köşe direklerinde birleşecek, "
                  "kablo gergin kalacak.\"",
                  bedel=1, kritik=True),
            Kanit("Direk yerleşimi",
                  "Halkanın kenarları: K-L {} m, L-M {} m, M-K {} m.".format(kl, lm, mk),
                  bedel=1),
            Kanit("Makara notu",
                  "Her parça ayrı makaradan gelmiş; renkleri farklı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Üç parçanın halka kurup kurmayacağına hangi kural karar verir?",
                dogru="Her parça, öteki ikisinin toplamından kısa olmalı.",
                yanlislar={
                    "Üç parçanın toplam boyu yeterince uzun olmalı.":
                        "Toplam büyük olsa da bir parça ötekilerin toplamından "
                        "uzunsa uçlar birbirine ulaşmaz; asıl sınır tek tek bakar.",
                    "Üç parçanın uzunluğu birbirinden farklı olmalı.":
                        "İkizkenar ve eşkenar halkalar da kapanır; parçaların "
                        "farklı olması şart değil.",
                    "En uzun parça öteki ikisinin toplamına eşit olmalı.":
                        "Eşit olursa kablolar gergin tek çizgi hâlinde uzanır, "
                        "içeride alan kalmaz; halka ancak daha kısa olursa açılır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir köşeden öbürüne en kısa yol düz çizgidir. Bu yüzden iki "
                    "kenarın toplamı üçüncüden küçük kalırsa uçlar buluşmaz, eşit "
                    "kalırsa kablo düz bir çizgiye yatar. Halka için her kenar, "
                    "ötekilerin toplamından kısa olmalı; en uzun kenarı denetlemek yeter."
                ),
                ipuclari=[
                    "Bir köşeden diğerine en kısa yol nedir? İki kenarın dolaşması o yolu geçebilmeli.",
                    "En uzun parçayı seç; ötekiler birlikte ona yetişiyor mu?",
                ],
                cozum=("En uzun parçayı bul, öteki ikisini topla. Toplam en uzundan "
                       "büyükse halka kapanır; eşit ya da küçükse kapanmaz."),
            ),
            coklu_adimi(
                soru="Hangi üçlülerle halka kapanır?",
                secenekler=secenekler,
                dogru_indeksler=dogrular,
                aciklama=(
                    "Her üçlüde iki kısa parçanın toplamı en uzunla karşılaştırılır. "
                    "{} -> {}; {} -> {}; {} -> {}; {} -> {}."
                ).format(*sum(([ac(u)[0], ac(u)[1]] for u in
                               (gecerli[0], gecerli[1], tam_dogru, kisa)), [])),
                ipuclari=["Her üçlüde en uzun parçayı bul; öteki ikisinin toplamıyla kıyasla."],
                puan=15,
            ),
            sayi_adimi(
                soru=("Elinde {} m ve {} m uzunluğunda iki parça kaldı. Üçüncü parçayı "
                      "tam metre olarak kesersen halkayı kapatan kaç farklı "
                      "boy olabilir?").format(p_min, p_max),
                cevap=adet,
                birim="boy",
                aciklama=(
                    "Üçüncü parça farktan uzun, toplamdan kısa olmalı: {} m ile {} m "
                    "arasında, uçlar HARİÇ. Tam sayı olarak {} ... {} aralığı {} boy eder."
                ).format(p_max - p_min, p_min + p_max, p_max - p_min + 1,
                         p_min + p_max - 1, adet),
                yaygin_yanlislar={
                    2 * p_min + 1:
                        "Aralığın iki ucunu da saydın. Uçlardaki boyda kablo düz "
                        "çizgiye yatar; halka olmaz.",
                    p_min + p_max - 1:
                        "Yalnız en büyük boyu verdin. Soru olabilecek tüm boyları "
                        "soruyor; alt sınır da var.",
                },
                ipuclari=["Üçüncü kenar iki kenarın toplamından küçük, farkından büyük olmalı."],
                puan=14,
                cozum=("Fark: {} - {} = {}, toplam: {} + {} = {}. Boy {} ile {} arasında "
                       "(uçlar dışarıda): {} değer.").format(
                           p_max, p_min, p_max - p_min, p_min, p_max, p_min + p_max,
                           p_max - p_min + 1, p_min + p_max - 1, adet),
            ),
            yorum_adimi(
                soru=("Halka K-L {} m, L-M {} m, M-K {} m olarak kuruldu. Teknisyen "
                      "projektörü en geniş açılı köşeye takacak. Hangi direk?").format(
                          kl, lm, mk),
                dogru="{} direğindeki açı".format(en_uzun_kose),
                yanlislar=yorum_yanlislari,
                rastgele=rastgele,
                aciklama=(
                    "Bir üçgende en büyük açı en uzun kenarın karşısındadır. "
                    "{} direğinin karşısındaki kenar {} m ile en uzunu; açı da orada en geniş."
                ).format(en_uzun_kose, karsi[en_uzun_kose]),
                ipuclari=["Her direğin karşısındaki kenarı bul; en uzun olanı seç."],
                puan=10,
            ),
        ],
        kapanis="Kesim listesi onaylandı; kapanmayan üçlüler makaraya geri döndü.",
        odul={"cevher": 2, "itibar": 3},
    )


@bulmaca(ders="matematik", konu="ucgen_eslik_benzerlik", kademeler=(8, 11), agirlik=1.2)
def golge_olcumu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Benzer üçgenler: ulaşılamayan yüksekliği gölgeden bulma; benzer ile eşi ayırma."""
    h = rastgele.choice([2, 3])
    g = h + rastgele.randrange(1, 4)
    k = rastgele.randrange(4, 10)
    yukseklik, golge = h * k, g * k
    alan_orani = k * k
    yapi = rastgele.choice(["haberleşme direğinin", "su kulesinin", "sinyal direğinin"])
    olcumcu = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-golge-olcumu",
        ders="matematik",
        baslik="Gölge Ölçümü",
        kademe=kademe,
        konu="ucgen_eslik_benzerlik",
        kazanim="Benzer üçgenlerde kenar oranıyla uzunluk bulma; benzerlik ile eşliği ayırt etme.",
        dikkat=5,
        brifing=(
            "Üssün {} tepesine çıkmak tehlikeli; yüksekliği ölçülemiyor. "
            "{} öğleden sonra düz zemine yere dik bir bakım çubuğu dikti ve iki "
            "gölgeyi de aynı anda ölçtü.\n\n"
            "Üstlerin istediği, yapının yüksekliği. Merdiven de ip de yok; elde "
            "yalnızca üç ölçüm var."
        ).format(yapi, olcumcu),
        kanitlar=[
            Kanit("Çubuk ölçümü",
                  "Çubuk {} m yüksekliğinde; gölgesi {} m.".format(h, g),
                  bedel=1, kritik=True),
            Kanit("Yapı gölgesi",
                  "Yapının gölgesi tabandan uca {} m.".format(golge),
                  bedel=1, kritik=True),
            Kanit("Ölçüm koşulu",
                  "\"İki gölge de aynı anda, aynı düz zeminde ölçüldü.\"",
                  bedel=1, kritik=True),
            Kanit("Hava notu",
                  "Gökyüzü açık; rüzgâr çubuğu eğmedi.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Çubuk ile yapı arasındaki ilişkiyi hangi düşünce kurar?",
                dogru=("Işınlar paralel geldiği için iki dik üçgenin açıları aynı, "
                       "kenarları orantılıdır."),
                yanlislar={
                    "Gölge farkı ile boy farkı eşit olduğu için iki üçgenin kenar farkları sabit kalır.":
                        "Farkın sabit kalması toplamsal düşünmektir. Gölgeler uzayınca "
                        "boylar ölçekle, yani ÇARPARAK büyür; toplayarak değil.",
                    "İki cisim de yere dik olduğu için gölgeleri de birbirine eşit çıkar.":
                        "Dik olmaları gölgeleri eşitlemez. Gölge, cismin boyuyla "
                        "birlikte büyür; ikisi arasında sabit bir oran var.",
                    "Işın uzunlukları eşit olduğu için iki üçgen de aynı boyda çizilmiş olur.":
                        "Işının boyu aynı değil; farklı boylarda cisimler farklı "
                        "boylarda üçgenler çizer. Ortak olan açıdır, uzunluk değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Güneş ışınları paralel gelir; çubuk ve yapı aynı açıyla gölge "
                    "bırakır. Dik açı ortak, ışın açısı ortak: iki üçgenin açıları "
                    "aynı, yani BENZER. Benzer üçgenlerde karşılıklı kenarlar "
                    "aynı orandadır."
                ),
                ipuclari=[
                    "Işınlar paralel; çubuğun ve yapının tepesinden gelen ışın zemine kaç derece düşer?",
                    "Aynı açıları paylaşan iki üçgenin kenarları aynı oranda büyür.",
                ],
                cozum=("Çubuk: {} m boy, {} m gölge. Yapı: ? boy, {} m gölge. Gölge "
                       "kaç kat büyümüşse boy da o kadar kat büyür.").format(h, g, golge),
            ),
            sayi_adimi(
                soru="Yapının yüksekliği kaç metre?",
                cevap=yukseklik,
                birim="m",
                aciklama=(
                    "Boy / gölge oranı iki üçgende aynı: {} / {} = ? / {}. Gölge "
                    "{} kat uzamış, boy da {} kat uzar: {} × {} = {} m."
                ).format(h, g, golge, k, k, h, k, yukseklik),
                yaygin_yanlislar={
                    h + golge - g:
                        "Fark sabit kalır sandın (gölge farkını boya ekledin). "
                        "Benzerlikte oran sabittir, fark değil.",
                    round(g * golge / h, 4):
                        "Oranı ters kurdun: gölge/boy ile boy/gölge birbirine "
                        "karıştı. Boy, gölgeyle birlikte büyür.",
                },
                ipuclari=["Gölge çubuğunkinden kaç kat uzun? Boy da o kat uzun."],
                puan=14,
                cozum=("Gölge oranı: {} ÷ {} = {} kat. "
                       "Boy: {} × {} = {} m.").format(golge, g, k, h, k, yukseklik),
            ),
            secim_adimi(
                soru=("Çubuğun gölge üçgeni ile yapının gölge üçgeni için hangisi "
                      "doğru?"),
                dogru="Benzerdirler ama eş değiller, çünkü açılar aynı kalırken kenarlar aynı oranda büyür.",
                yanlislar={
                    "Eştirler, çünkü açıları aynı olan iki üçgenin kenar uzunlukları da birebir aynı olur.":
                        "Aynı açı yalnız aynı BİÇİM verir; boyut farklı olabilir. Eş "
                        "demek üst üste oturmak demektir; burada biri diğerinin büyütülmüşü.",
                    "Eştirler, çünkü kenar oranı sabit kaldığı için iki üçgen de aynı boyda sayılır.":
                        "Sabit oran benzerliğin kanıtı, eşliğin değil. Eşlik için "
                        "oranın 1 olması, yani kenarların birebir aynı olması gerekir.",
                    "Benzer değiller, çünkü biri çok daha büyük olduğu için açıları da değişmiştir.":
                        "Büyüklük açıyı değiştirmez; bir fotoğrafı büyütünce köşeler "
                        "aynı açıda kalır. Boyut değişir, biçim değişmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Benzer üçgenler biçim olarak aynı, boyut olarak farklı olabilir "
                    "(açılar eşit, kenarlar orantılı). Eş üçgenler ise tam üst üste "
                    "oturur: kenarlar da açılar da birebir aynıdır. Eş olanlar "
                    "benzerdir, ama benzer olanlar eş olmak zorunda değil."
                ),
                ipuclari=["Bir fotoğrafı büyüttüğünde köşeler ve boyutlar için ne olur?"],
                puan=12,
            ),
            sayi_adimi(
                soru=("Yapının gölge üçgeninin alanı, çubuğun gölge üçgeninin alanının "
                      "kaç katıdır?"),
                cevap=alan_orani,
                birim="kat",
                aciklama=(
                    "Kenarlar {} kat büyüdü. Alan iki boyutludur: hem boy hem taban "
                    "{} kat büyür, alan {} × {} = {} kat büyür."
                ).format(k, k, k, k, alan_orani),
                yaygin_yanlislar={
                    k: "Kenar oranını aldın. Alan, kenarların İKİSİNİN birden "
                       "büyümesidir; oranın karesi kadar artar.",
                    2 * k: "İki kenarın oranını toplayarak aldın; alanda çarpım var.",
                },
                ipuclari=["Üçgenin alanı taban × yükseklik: ikisi de aynı kat büyür."],
                puan=12,
            ),
        ],
        kapanis="Yapının yüksekliği rapora yazıldı; çubuk ve iki gölge kayıt altına alındı.",
        odul={"itibar": 3, "enerji": 2},
    )


@bulmaca(ders="matematik", konu="tales_oklid_pisagor", kademeler=(8, 11), agirlik=1.2)
def merdiven_boyu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Pisagor bağıntısı: merdiven boyu, dik üçgen ayırma, kayan merdiven."""
    aileler = [(3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25), (20, 21, 29)]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    aile = rastgele.choice(aileler)
    olcek = rastgele.choice([1, 2]) if aile[2] <= 13 else 1
    yuk, taban, boy = [v * olcek for v in aile]
    if rastgele.random() < 0.5:
        yuk, taban = taban, yuk

    # Dik üçgen ayırma adımı: iki gerçek üçlü, iki "yakın" üçlü
    diger = [a for a in aileler if a != aile]
    rastgele.shuffle(diger)
    gercek = [aile, diger[0]]
    gercek = [tuple(v * m for v in a)
              for a, m in ((a, rastgele.choice([1, 2])) for a in gercek)]
    yakin = []
    for a in diger[1:3]:
        s = rastgele.choice([1, 2])
        a1, b1, c1 = (v * s for v in a)
        yakin.append((a1, b1, c1 + 1))          # hipotenüs bir fazla: dik değil
    def yaz(u):
        return "{}, {} ve {} m".format(*sorted(u))
    secenekler, dogrular = coklu_siklar(
        rastgele, [yaz(u) for u in gercek], [yaz(u) for u in yakin])

    # Kayan merdiven: 25 m (veya 50 m) boyunda; üst uç 24 -> 20 iner, taban 7 -> 15 açılır
    s = rastgele.choice([1, 2])
    kayma_cevap = 8 * s

    return Bulmaca(
        kod="mat-merdiven-boyu",
        ders="matematik",
        baslik="Merdiven Boyu",
        kademe=kademe,
        konu="tales_oklid_pisagor",
        kazanim="Pisagor bağıntısıyla dik üçgende kenar uzunluğu bulma ve dik üçgen olup olmadığını denetleme.",
        dikkat=5,
        brifing=(
            "{} bölgesindeki gözlem kulesinin bakım penceresine ulaşılacak. "
            "{} duvara dayanacak bir bakım merdiveni arıyor; merdivenin ucu "
            "pencere pervazına kadar yetmeli, ayağı da zeminde kaymayacak.\n\n"
            "Ambarda boyu yazılı bir merdiven yok. Kule duvarının yüksekliği "
            "ile ayağın duvardan uzaklığı ise ölçüldü."
        ).format(mevki, kisi),
        kanitlar=[
            Kanit("Duvar ölçümü",
                  "Pencere zeminden {} m yüksekte.".format(yuk),
                  bedel=1, kritik=True),
            Kanit("Ayak uzaklığı",
                  "Merdivenin ayağı duvar dibinden {} m uzağa konacak.".format(taban),
                  bedel=1, kritik=True),
            Kanit("Zemin şartı",
                  "\"Duvar zemine diktir; merdiven duvara tam pencerenin altına dayanacak.\"",
                  bedel=1, kritik=True),
            Kanit("Merdiven notu",
                  "Ambardaki merdivenlerin basamak sayısı farklı; hiçbirinin boyu yazılı değil.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Merdiven boyu bu iki ölçümden nasıl çıkar?",
                dogru=("Dik üçgen kurulur, yükseklik ile uzaklığın kareleri toplanır ve "
                       "karekökü alınır."),
                yanlislar={
                    "Boy, yükseklik ile uzaklığın toplamına eşittir, ikisi uç uca eklenir.":
                        "Toplam, iki dik kenarı uç uca dizip yürüyen yolun uzunluğudur. "
                        "Merdiven ise bu iki kenarı kısaltan eğik çizgidir; "
                        "toplamdan kısadır.",
                    "Boy, yükseklik ile uzaklığın farkına eşittir, büyükten küçük çıkarılır.":
                        "Fark, merdivenin ucunu ve ayağını karşılaştırır; boyu değil. "
                        "Eğik kenar dik kenarlardan her zaman daha uzundur.",
                    "Boyun karesi, yükseklik ile uzaklığın çarpımına eşittir, çünkü alan çarpımla bulunur.":
                        "Çarpım dik üçgenin alanıyla ilgilidir. Kenar bağıntısında "
                        "kareler toplanır, çarpılmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Duvar zemine dik olduğu için merdiven, duvar ve zemin bir dik "
                    "üçgen oluşturur. Dik açının karşısındaki kenar (merdiven) "
                    "hipotenüstür; karesi iki dik kenarın karelerinin toplamına eşittir "
                    "(Pisagor bağıntısı)."
                ),
                ipuclari=[
                    "Duvar zemine dik. Merdiven bu iki doğrunun arasında hangi kenarı oluşturur?",
                    "Dik üçgende en uzun kenar hangi kenar ve karesi neye eşit?",
                ],
                cozum=("Merdiven eğik kenar. Boy² = {}² + {}²; sonra kök al."
                       ).format(yuk, taban),
            ),
            sayi_adimi(
                soru="Merdivenin boyu kaç metre olmalı?",
                cevap=boy,
                birim="m",
                aciklama=("{}² + {}² = {} + {} = {}; {} = {}² olduğundan "
                          "boy {} m.").format(yuk, taban, yuk * yuk, taban * taban,
                                              yuk * yuk + taban * taban, boy * boy,
                                              boy, boy),
                yaygin_yanlislar={
                    yuk + taban:
                        "Dik kenarları topladın. Merdiven eğik çizgidir; toplam "
                        "yol uzunluğundan kısadır.",
                    abs(taban - yuk):
                        "Farkı aldın. Fark eğik kenarı değil iki dik kenarın farkını verir.",
                },
                ipuclari=["Önce iki dik kenarın karelerini topla, sonra karekökü al."],
                puan=14,
                cozum=("{}² = {}, {}² = {}; toplam {}; karekök {}.").format(
                    yuk, yuk * yuk, taban, taban * taban, yuk * yuk + taban * taban, boy),
            ),
            coklu_adimi(
                soru=("Kule yamacındaki dört ayrı bakım yerinde ölçülen kenarlardan "
                      "hangilerinde duvarla zemin tam dik açı yapar? (Üçüncü sayı "
                      "en uzun kenardır.)"),
                secenekler=secenekler,
                dogru_indeksler=dogrular,
                aciklama=("Dik açı varsa en uzun kenarın karesi ötekilerin kareleri "
                          "toplamına tam eşit olur. " + " ".join(
                              "{}: {} + {} = {}, {}² = {} ({}).".format(
                                  yaz(u), u[0] ** 2, u[1] ** 2, u[0] ** 2 + u[1] ** 2,
                                  u[2], u[2] ** 2,
                                  "dik" if u[0] ** 2 + u[1] ** 2 == u[2] ** 2 else "dik değil")
                              for u in gercek + yakin)),
                ipuclari=["Her üçlüde küçük ikisinin karelerini topla; en büyüğün karesiyle kıyasla."],
                puan=15,
            ),
            sayi_adimi(
                soru=("Başka bir yangın merdiveni {} m boyunda; üst ucu duvarda "
                      "{} m yükseklikteyken ayağı duvardan {} m uzakta. Üst uç "
                      "{} m yüksekliğe indirilirse ayağı duvardan kaç metre daha "
                      "uzağa kayar?").format(25 * s, 24 * s, 7 * s, 20 * s),
                cevap=kayma_cevap,
                birim="m",
                aciklama=(
                    "Yeni uzaklık: boy² − yükseklik² = {}² − {}² = {}; karekök {} m. "
                    "Eskisi {} m olduğundan ayak {} − {} = {} m kayar."
                ).format(25 * s, 20 * s, (25 * s) ** 2 - (20 * s) ** 2, 15 * s,
                         7 * s, 15 * s, 7 * s, kayma_cevap),
                yaygin_yanlislar={
                    4 * s:
                        "Üst ucun inme miktarını ayağın kayma miktarı saydın. İkisi "
                        "birbirine eşit değil; dik üçgenin iki kenarı aynı hızla değişmez.",
                    15 * s:
                        "Yeni uzaklığı buldun ama eskiyi çıkarmayı unuttun; soru "
                        "KAÇ METRE DAHA uzağa kaydığını soruyor.",
                },
                ipuclari=["Yeni durumda bilinmeyen ayağın duvara uzaklığı. Yeni dik üçgeni kur."],
                puan=14,
            ),
        ],
        kapanis="Merdiven boyu ambara bildirildi; yamaçtaki dik açılar işaretlendi.",
        odul={"cevher": 2, "erzak": 1},
    )


# ==========================================================================
# VERİ, İSTATİSTİK, FONKSİYON
# ==========================================================================

def _temiz(cevap, yanlislar):
    """Teşhis anahtarlarından doğru cevaba (sayısal olarak) eşit olanları atar."""
    return {k: v for k, v in yanlislar.items() if abs(float(k) - float(cevap)) > 1e-9}


@bulmaca(ders="matematik", konu="tek_degiskenli_istatistik", kademeler=(6, 11), agirlik=1.2)
def tuketim_defteri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Ortanca, ortalama ve aşırı değer: 'tipik gün' hangi ölçüyle anlatılır."""
    taban = rastgele.randrange(18, 36 + 2 * kademe)
    temel = [taban + rastgele.randrange(-4, 5) for _ in range(6)]
    toplam_temel = sum(temel)
    ortanca = sorted(temel)[3]          # aşırı gün en büyük olacağından 7'lide dördüncü
    adaylar = [o for o in range(2 * taban + 12, 4 * taban + 60)
               if (toplam_temel + o) % 7 == 0
               and (toplam_temel + o) // 7 - ortanca >= 3]
    asiri = rastgele.choice(adaylar)
    gunler = temel + [asiri]
    rastgele.shuffle(gunler)
    sirali = sorted(gunler)
    ortalama = sum(gunler) // 7
    dis_ortalama = round(toplam_temel / 6, 4)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    defter = ", ".join("{}. gün {}".format(i + 1, v) for i, v in enumerate(gunler))

    yanlis_ortalama = {
        dis_ortalama: (
            "Aşırı günü dışarıda bıraktın. Ortalama, defterdeki bütün günleri "
            "sayar; yalnız tipik olanları değil."),
        round(sum(gunler) / 6, 4): (
            "Toplamı altıya böldün; defterde yedi gün var. Ortalamada bölen, "
            "gün sayısıdır."),
    }

    return Bulmaca(
        kod="mat-tuketim-defteri",
        ders="matematik",
        baslik="Tüketim Defteri",
        kademe=kademe,
        konu="tek_degiskenli_istatistik",
        kazanim="Ortanca, aritmetik ortalama ve aşırı değerin etkisini yorumlama.",
        dikkat=5,
        brifing=(
            "Üssün mutfağı yedi günlük erzak tüketimini deftere işledi. Kurul "
            "gelecek ay için sevkiyat planlayacak ve tek bir soruya cevap "
            "istiyor: bir günde tipik olarak ne kadar erzak gidiyor?\n\n"
            "{} defteri açtı ama içindeki sayılar birbirine hiç benzemiyor; "
            "birine bakıp \"tipik bu\" demek de, ötekine bakıp demek de doğru "
            "gelmiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Tüketim defteri",
                  "Günlük erzak (kg): {}.".format(defter),
                  bedel=1, kritik=True),
            Kanit("Kurulun sorusu",
                  "\"Planlama için tipik bir gün, aşırı günlerden etkilenmeden "
                  "bilinmeli.\"", bedel=1, kritik=True),
            Kanit("Mutfak notu",
                  "Defterin kenarına biri yazmış: \"Bir gün yan üssün ekibi "
                  "konakladı, o gün normalden çok fazla yemek çıktı.\"", bedel=1),
            Kanit("Depo notu",
                  "Erzak sandıklarının hepsi aynı boyda; sayımda hata yok.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kurulun \"tipik gün\" sorusuna hangi ölçü en iyi cevap verir?",
                dogru=("Ortanca, çünkü uçtaki tek bir aşırı gün, sıralamada ortada kalan "
                       "değeri kaydırmaz."),
                yanlislar={
                    "Aritmetik ortalama, çünkü her günü eşit ağırlıkla hesaba katar ve hiçbirini atlamaz.":
                        "Ortalama her günü sayar, ama aşırı gün de dahil olduğu için "
                        "onu yukarı çeker; tipik günü olduğundan büyük gösterir.",
                    "Tepe değer, çünkü en sık görülen sayı her zaman defterdeki en büyük günü gösterir.":
                        "Tepe değer en SIK görülen sayıdır, en büyük değil. Bu "
                        "defterde günlerin çoğu birbirinden farklı; tepe değer de "
                        "güvenilir bir tipik gün vermez.",
                    "Açıklık, çünkü en büyük gün ile en küçük gün arasındaki fark bütün yayılımı anlatır.":
                        "Açıklık yayılımı ölçer, tipik değeri değil. Kurul \"ne "
                        "kadar gidiyor\" diye soruyor, günler birbirinden ne kadar "
                        "ayrılıyor diye değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ortanca, sıralanmış verinin tam ortasındaki değerdir; uçtaki bir "
                    "değer ne kadar büyük olursa olsun sıralamadaki yeri değişmez. "
                    "Ortalama ise bütün değerlerin toplamına bağlıdır; tek bir "
                    "aşırı değer toplamı, dolayısıyla ortalamayı kolayca çeker."
                ),
                ipuclari=[
                    "Defterdeki bir günü iki katına çıkarırsan hangi ölçü yer değiştirir?",
                    "Sıralanınca ortada kalan değer, uçlardan etkilenmez.",
                ],
                cozum="Verileri küçükten büyüğe sırala; yedinin ortasındaki dördüncüyü al.",
            ),
            sayi_adimi(
                soru="Günlük tüketimin ortancası kaç kg?",
                cevap=ortanca,
                birim="kg",
                aciklama=("Sıralı defter: {}. Yedi değerin ortasındaki, yani "
                          "dördüncü değer {}.").format(
                              ", ".join(str(v) for v in sirali), ortanca),
                yaygin_yanlislar=_temiz(ortanca, {
                    ortalama: "Ortalamayı buldun. Ortanca toplamdan değil, "
                              "sıralamadan çıkar: ortadaki değerdir.",
                    gunler[3]: "Defterin ortasındaki günü aldın. Ortanca, veri "
                               "büyüklük sırasına dizildikten sonra ortada kalandır; "
                               "defterin sırasına göre değil.",
                }),
                ipuclari=["Önce yedi değeri küçükten büyüğe sırala."],
                puan=12,
                cozum="Sırala: {}. Ortadaki dördüncü: {}.".format(
                    ", ".join(str(v) for v in sirali), ortanca),
            ),
            sayi_adimi(
                soru="Günlük tüketimin aritmetik ortalaması kaç kg?",
                cevap=ortalama,
                birim="kg",
                tolerans=0.01,
                aciklama=("Toplam {} kg, yedi gün: {} ÷ 7 = {} kg.").format(
                    sum(gunler), sum(gunler), ortalama),
                yaygin_yanlislar=_temiz(ortalama, yanlis_ortalama),
                ipuclari=["Bütün günleri topla ve gün sayısına böl."],
                puan=12,
                cozum="{} ÷ 7 = {}.".format(sum(gunler), ortalama),
            ),
            yorum_adimi(
                soru=("Ortalama ({} kg) ortancadan ({} kg) büyük çıktı. Bu fark ne "
                      "söylüyor?").format(ortalama, ortanca),
                dogru="Tek bir çok yüksek gün ortalamayı yukarı çekti ama ortancayı hiç kıpırdatmadı.",
                yanlislar={
                    "Ortalama her zaman ortancadan büyük çıkar, bu fark verinin bir özelliği değildir.":
                        "Öyle bir kural yok; veri simetrikse ikisi birbirine "
                        "yakındır, hatta eşit olabilir. Fark bu defterdeki aşırı "
                        "günden geliyor.",
                    "Ortanca yanlış hesaplanmış, çünkü ortalamadan küçük çıkması hatayı gösterir.":
                        "Ortancanın ortalamadan küçük çıkması hata değil. Biri "
                        "toplama, diğeri sıralamaya bağlı olduğu için aşırı değer "
                        "yalnız ortalamayı etkiler.",
                    "Defterdeki sayımlar hatalı, çünkü iyi bir veride ortalama ile ortanca eşit olur.":
                        "İyi bir veride bile ikisi eşit olmak zorunda değil. "
                        "Sayımda hata yok; konuk ekibin günü gerçek bir aşırı gün.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ortalama aşırı değerlere duyarlı, ortanca değil. Ortalamanın "
                    "ortancadan belirgin büyük çıkması, verinin üst ucunda uzun bir "
                    "kuyruk ya da tek bir aşırı değer olduğunu düşündürür. Kurulun "
                    "sorusu (aşırı günlerden etkilenmeyen tipik gün) için ortanca "
                    "doğru ölçüdür."
                ),
                ipuclari=["Konuk ekibin kaldığı gün ortalamayı ne yönde etkiler?"],
                puan=10,
            ),
        ],
        kapanis="Kurul planı ortancaya göre yaptı; konuk günleri ayrı bir kalemde izlenecek.",
        odul={"erzak": 3, "itibar": 3},
    )


@bulmaca(ders="matematik", konu="istatistik_elestirisi", kademeler=(8, 12), agirlik=1.2)
def kirpik_eksen(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Grafik eleştirisi: sıfırdan başlamayan eksen farkı olduğundan büyük gösterir."""
    secenek = []
    for v1 in (100, 120, 150, 200, 250, 300, 400):
        for yuzde in (2, 4, 5, 6, 8, 10, 12):
            if v1 * yuzde % 100:
                continue
            v2 = v1 + v1 * yuzde // 100
            for r in (2, 3, 4):
                if (r * v1 - v2) % (r - 1) == 0:
                    c = (r * v1 - v2) // (r - 1)
                    if 0 < c < v1:
                        secenek.append((v1, v2, yuzde, r, c))
    v1, v2, yuzde, r, c = rastgele.choice(secenek)
    fark = v2 - v1
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    ilk_boy = v1 - c
    ikinci_boy = v2 - c
    b1, b2 = 4, 4 * r        # çubuklar okunur ölçeğe indirildi: oran r kalır

    return Bulmaca(
        kod="mat-kirpik-eksen",
        ders="matematik",
        baslik="Kırpık Eksen",
        kademe=kademe,
        konu="istatistik_elestirisi",
        kazanim="Grafiği eleştirme: eksenin başlangıcı ve görsel fark ile gerçek farkı ayırma.",
        dikkat=5,
        brifing=(
            "Enerji birimi kurula haftalık üretim raporunu sundu. Raporun kapağında "
            "büyük bir cümle var: \"Bu hafta üretim bir önceki haftaya göre çok "
            "büyük bir sıçrama yaptı.\" Altında da iki çubuklu bir grafik.\n\n"
            "{} grafiğe bakınca sıçramayı gördü, sonra aynı rapordaki ham ölçüm "
            "defterine baktı ve sayılar ona o kadar büyük gelmedi. Kurul "
            "yarın yeni jeneratör siparişi verecek."
        ).format(kisi),
        kanitlar=[
            Kanit("Rapor grafiği",
                  "Geçen hafta |{}\nBu hafta   |{}\n(çubuk uzunlukları grafikten "
                  "olduğu gibi aktarıldı)".format("#" * b1, "#" * b2),
                  bedel=1, kritik=True),
            Kanit("Grafik kenar notu",
                  "Dikey eksen {} değerinden başlıyor, sıfırdan değil.".format(c),
                  bedel=1, kritik=True),
            Kanit("Ham ölçüm defteri",
                  "Geçen hafta {} birim, bu hafta {} birim üretildi.".format(v1, v2),
                  bedel=1, kritik=True),
            Kanit("Birim notu",
                  "İki hafta da aynı jeneratörler, aynı ölçüm cihazı.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Raporun \"büyük sıçrama\" iddiasını sınamak için önce neye bakmalı?",
                dogru="Dikey eksenin sıfırdan başlayıp başlamadığına ve gerçek sayıların ne olduğuna.",
                yanlislar={
                    "Çubukların renklerinin ve kalınlığının iki hafta için eşit çizilip çizilmediğine.":
                        "Renk ve kalınlık görünüşü etkiler ama sayıyı değiştirmez. "
                        "Çubuğun uzunluğu neyi, nereden başlayarak gösteriyor, "
                        "yanıltıcılık orada saklı.",
                    "Grafikteki çubuk sayısının raporda anlatılan hafta sayısıyla uyuşup uyuşmadığına.":
                        "Çubuk sayısı doğru olabilir; iki çubuk iki haftayı zaten "
                        "gösteriyor. Yanıltan şey kaç çubuk olduğu değil, uzunluğun "
                        "nasıl çizildiği.",
                    "Grafiğin altında hangi kurumun raporu olduğunun açıkça yazılıp yazılmadığına.":
                        "Kaynak önemlidir ama bu iddiayı sınamaz; kaynağı yazılı "
                        "bir grafik de yine eksenle yanıltabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çubuk grafikte uzunluk, eksenin başladığı yerden ölçülür. "
                    "Eksen sıfırdan değil de yakın bir değerden başlıyorsa küçük bir "
                    "fark çok büyük görünür. İddiayı sınamanın ilk yolu ekseni "
                    "okumak, ikincisi ham sayılara bakmaktır."
                ),
                ipuclari=[
                    "Çubuğun tabanı hangi sayıya denk geliyor?",
                    "Grafiğin kenar notunu ve ham defteri yan yana oku.",
                ],
                cozum=("Önce eksenin başlangıcına bak, sonra ham sayıları karşılaştır: "
                       "iddia hangisiyle uyumlu?"),
            ),
            sayi_adimi(
                soru="Gerçek ölçümlere göre bu haftaki üretim, geçen haftaya göre yüzde kaç arttı?",
                cevap=yuzde,
                birim="%",
                aciklama=("Fark: {} − {} = {} birim. Oran: {} ÷ {} = {}, yani %{}.").format(
                    v2, v1, fark, fark, v1, sy(fark / v1), yuzde),
                yaygin_yanlislar=_temiz(yuzde, {
                    (r - 1) * 100:
                        "Grafikteki çubuk oranından yüzde çıkardın. Çubuklar "
                        "eksen başlangıcından çizildiği için gerçek artışı yansıtmaz; "
                        "ham sayılar gerekir.",
                    fark:
                        "Farkı (birim olarak) buldun, yüzdeyi değil. Yüzde için "
                        "farkı geçen haftaya bölmelisin.",
                }),
                ipuclari=["Artışı, geçen haftanın değerine oranla."],
                puan=12,
                cozum="({} − {}) ÷ {} × 100 = {}.".format(v2, v1, v1, yuzde),
            ),
            sayi_adimi(
                soru="Grafik, bu haftanın çubuğunu geçen haftanınkinin kaç katı uzunlukta çiziyor?",
                cevap=r,
                birim="kat",
                aciklama=("Çubuklar eksen başlangıcından ({}) itibaren çizilir: "
                          "geçen hafta {} − {} = {}, bu hafta {} − {} = {}. "
                          "{} ÷ {} = {} kat.").format(c, v1, c, ilk_boy, v2, c,
                                                       ikinci_boy, ikinci_boy,
                                                       ilk_boy, r),
                yaygin_yanlislar=_temiz(r, {
                    round(v2 / v1, 4):
                        "Ham sayıların oranını aldın. Soru grafikteki "
                        "GÖRÜNEN uzunluğu soruyor; o, eksen başlangıcından ölçülür.",
                }),
                ipuclari=["Her çubuğun uzunluğu, eksenin başlangıç değerinden çıkarılarak bulunur."],
                puan=12,
                cozum="Çubuklar: {} ve {}; oran {}.".format(ilk_boy, ikinci_boy, r),
            ),
            yorum_adimi(
                soru="Rapor düzeltilecek. Kurula en dürüst sunum hangisi olur?",
                dogru="Eksen sıfırdan başlatılsın, gerçek artış da yüzde olarak çubukların altına yazılsın.",
                yanlislar={
                    "Grafik olduğu gibi kalsın, altına çubuk renklerini açıklayan bir not eklensin.":
                        "Renk açıklaması eksen sorununu çözmez. Okuyucu hâlâ "
                        "çubukların oranını fark sanır.",
                    "Çubuklar daha da kalınlaştırılsın ki iki hafta arasındaki fark gözden kaçmasın.":
                        "Kalınlık farkı büyütmez ama sorunu da gidermez; "
                        "yanıltan şey eksenin başlangıcı.",
                    "Grafik tamamen kaldırılsın, yalnız tek bir toplam rakam yazılsın, başka bir şey olmasın.":
                        "Grafiği atmak sorunu çözmez. İki dönemi kıyaslamak için "
                        "grafik gerekli; yeter ki dürüst çizilsin.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Dürüst grafik, çubuğun uzunluğu ile değerin büyüklüğü arasındaki "
                    "ilişkiyi korur: eksen sıfırdan başlarsa uzunluk oranı sayı oranına "
                    "eşit olur. Yüzdeyi yazmak da okuyucunun \"ne kadar\" sorusunu "
                    "doğrudan cevaplar."
                ),
                ipuclari=["Bir çubuğun uzunluğu, ölçülen değerle orantılı olmalı."],
                puan=10,
            ),
        ],
        kapanis="Rapor yenilendi; jeneratör siparişi gerçek artışa göre verildi.",
        odul={"enerji": 2, "itibar": 3},
    )


@bulmaca(ders="matematik", konu="fonksiyon_kavrami", kademeler=(8, 11), agirlik=1.2)
def vardiya_eslemesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Fonksiyon koşulu, tanım ve değer kümesi: vardiya-görevli eşlemesi."""
    vardiyalar = ["Sabah", "Öğle", "Akşam", "Gece"]
    gorevliler = [a.split()[-1] for a in ad_sec(rastgele, PERSONEL, 5)]

    def yaz(satirlar):
        return ", ".join(satirlar)

    # 1. taslak: her vardiyaya farklı görevli (fonksiyon)
    s1 = rastgele.sample(gorevliler, 4)
    farkli = ["{}: {}".format(v, g) for v, g in zip(vardiyalar, s1)]
    # 2. taslak: aynı görevli birden çok vardiyada (hâlâ fonksiyon)
    desen = rastgele.choice([[0, 1, 2, 0], [0, 1, 0, 1], [0, 0, 0, 1]])
    kisiler = rastgele.sample(gorevliler, 3)
    rastgele.shuffle(desen)
    tekrarli = ["{}: {}".format(v, kisiler[i]) for v, i in zip(vardiyalar, desen)]
    goruntu = len(set(desen))
    # 3. taslak: bir vardiyaya iki isim yazılmış (fonksiyon DEĞİL)
    s3 = rastgele.sample(gorevliler, 4)
    cift = rastgele.randrange(4)
    ikili = ["{}: {}".format(v, g) for v, g in zip(vardiyalar, s3)]
    ikinci = [x for x in gorevliler if x != s3[cift]][0]
    ikili[cift] = "{} ve {}".format(ikili[cift], ikinci)
    # 4. taslak: bir vardiya boş bırakılmış (fonksiyon DEĞİL)
    s4 = rastgele.sample(gorevliler, 4)
    eksik_v = rastgele.randrange(4)
    eksik = ["{}: {}".format(v, g) for i, (v, g) in enumerate(zip(vardiyalar, s4))
             if i != eksik_v]

    secenekler, dogrular = coklu_siklar(
        rastgele, [yaz(farkli), yaz(tekrarli)], [yaz(ikili), yaz(eksik)])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-vardiya-eslemesi",
        ders="matematik",
        baslik="Vardiya Eşlemesi",
        kademe=kademe,
        konu="fonksiyon_kavrami",
        kazanim="Fonksiyon koşulunu (her elemanın tam bir eşi), tanım ve değer kümesini ayırt etme.",
        dikkat=5,
        brifing=(
            "Üssün nöbet çizelgesi dört vardiyadan oluşuyor: sabah, öğle, akşam, "
            "gece. Kurul bir kural koydu: çizelge, her vardiya için sorumlu "
            "görevliyi tek bir isimle belirtmeli; sabah vardiyasının hesabı bir "
            "isme sorulabilmeli.\n\n"
            "Dört ayrı çizelge taslağı geldi. Hangileri kurulun kuralına uyuyor, "
            "hangileri uymuyor, kimse net söyleyemiyor."
        ),
        kanitlar=[
            Kanit("Kurulun kuralı",
                  "\"Her vardiyanın sorumlusu tam olarak bir kişi olacak. Bir "
                  "vardiya boş kalmayacak.\"", bedel=1, kritik=True),
            Kanit("Taslak çizelgeler",
                  "Dört taslak, vardiya: görevli biçiminde yazıldı. " +
                  " | ".join(secenekler), bedel=1, kritik=True),
            Kanit("Personel notu",
                  "Bir görevli birden fazla vardiya alabilir; kurulun buna itirazı yok.",
                  bedel=1),
            Kanit("Çizelge notu",
                  "Dört vardiya sabit; vardiya listesi değişmeyecek.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir çizelgenin kurulun kuralına uyması hangi koşula bağlı?",
                dogru=("Her vardiyanın karşısında tam bir görevli bulunmalı, ne "
                       "eksik ne fazla."),
                yanlislar={
                    "Her görevliye tam bir vardiya düşmeli, kimse iki vardiya alamamalı.":
                        "Bunu kural koyan kimse yok: bir görevli birden fazla "
                        "vardiya alabilir. Kuralın bağlandığı yön vardiyalardan "
                        "görevlilere doğrudur.",
                    "Bütün görevliler çizelgede en az bir kez yer almalı, kimse dışarıda kalmamalı.":
                        "Kuralın böyle bir şartı yok; dışarıda kalan görevli "
                        "olabilir. Önemli olan her vardiyanın karşılığının bulunması.",
                    "Vardiya sayısı ile görevli sayısı birbirine eşit olmalı, ikisi denk gelmeli.":
                        "Sayıların eşit olması şart değil: iki vardiyayı aynı kişi "
                        "tutabilir. Şart eşleşmenin kuralında.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Fonksiyonda tanım kümesindeki (burada vardiyalar) HER "
                    "elemanın değer kümesinde tam bir eşi vardır. Eksik eleman "
                    "tanım kümesi dışında kalmış demektir, fazla eş ise tek bir "
                    "cevap alınamaz demektir. Aynı eşi paylaşan iki eleman "
                    "fonksiyonu bozmaz."
                ),
                ipuclari=[
                    "Sabah vardiyasının sorumlusunu sorduğunda iki isim duymak ister misin?",
                    "Soru her zaman vardiyadan görevliye doğru soruluyor.",
                ],
                cozum="Her vardiyanın karşısına tam bir isim yazılmış mı, bak.",
            ),
            coklu_adimi(
                soru="Hangi taslak çizelgeler kurulun kuralına uyuyor?",
                secenekler=secenekler,
                dogru_indeksler=dogrular,
                aciklama=(
                    "Bir taslakta bir vardiyaya iki isim yazılıysa o vardiya için "
                    "tek cevap yoktur; bir vardiya eksikse o vardiya çizelgede "
                    "tanımsızdır. Aynı görevlinin iki vardiyada geçmesi sorun "
                    "değil."
                ),
                ipuclari=["Her taslakta dört vardiyayı tek tek say; her biri yalnız bir isim almış mı?"],
                puan=15,
            ),
            sayi_adimi(
                soru=("Şu çizelgede kaç farklı görevli çalışıyor? {}").format(
                    yaz(tekrarli)),
                cevap=goruntu,
                birim="kişi",
                aciklama=("Vardiyalara yazılan isimler tekrar edebilir. Farklı "
                          "isimleri say: {}. Bu, çizelgenin değer (görüntü) "
                          "kümesinin eleman sayısı."
                          ).format(goruntu),
                yaygin_yanlislar={
                    4: "Vardiya sayısını verdin. Soru kaç FARKLI görevlinin "
                       "çalıştığını soruyor; aynı kişi birden çok vardiyada geçiyor.",
                },
                ipuclari=["Her ismi bir kez say."],
                puan=12,
                cozum="Tekrarlayan isimleri bir kez sayarak say: {} farklı kişi.".format(goruntu),
            ),
            yorum_adimi(
                soru=("{} aynı kişiyi iki vardiyaya yazdı. Kurul bunun çizelgeyi "
                      "bozup bozmadığını soruyor.").format(kisi),
                dogru="Bozmaz, çünkü her vardiyanın yine tek bir sorumlusu olmaya devam ediyor.",
                yanlislar={
                    "Bozar, çünkü aynı kişi iki farklı yerde aynı anda bulunamaz.":
                        "Vardiyalar farklı zamanlar; bir kişi iki farklı vardiyayı "
                        "tutabilir. Kural zaman çakışmasıyla değil, tek isimle ilgili.",
                    "Bozar, çünkü çizelgede her isim yalnız bir kez geçmek zorundadır.":
                        "İsimlerin tekrar etmemesi bir şart değil. Kurulun şartı "
                        "vardiya başına tek isimdir.",
                    "Yalnız o kişi iki ayrı vardiyayı kendi yazarsa bozmaz, aksi hâlde bozar.":
                        "Yazanın kim olduğu önemsiz. Kuralı belirleyen şey "
                        "vardiya başına kaç isim olduğudur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Fonksiyon olmak için girişlerin (vardiyalar) her biri tek bir "
                    "çıkışa gitmeli; iki girişin aynı çıkışa gitmesinde bir "
                    "sakınca yoktur. Bu tür eşlemeler yalnızca birebir olmaktan "
                    "çıkar, fonksiyon olmaktan çıkmaz."
                ),
                puan=10,
            ),
        ],
        kapanis="Kurul çizelgeyi imzaladı; kurala uymayan taslaklar geri döndü.",
        odul={"itibar": 3, "erzak": 1},
    )


# ==========================================================================
# SAYILAR, KÜMELER, TRİGONOMETRİ
# ==========================================================================

@bulmaca(ders="matematik", konu="koklu_ifadeler", kademeler=(8, 11), agirlik=1.2)
def kare_tarlalar(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Köklü ifadeler: iki karekökü sadeleştirip toplama; kökün toplamaya dağılmadığı."""
    m = rastgele.choice([2, 3, 5, 6, 7])
    a, b = rastgele.sample(range(2, 8), 2)
    alan_a, alan_b = a * a * m, b * b * m
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    tam_deger = (a + b) * math.sqrt(m)
    yanlis_deger = math.sqrt(alan_a + alan_b)

    return Bulmaca(
        kod="mat-kare-tarlalar",
        ders="matematik",
        baslik="Kare Tarlalar",
        kademe=kademe,
        konu="koklu_ifadeler",
        kazanim="Köklü ifadeleri sadeleştirme, aynı kökten ifadeleri toplama; kökün toplamaya dağılmadığını bilme.",
        dikkat=5,
        brifing=(
            "Üssün iki kare biçimli sera tarlasının çevresine tel çit çekilecek. "
            "Tarlaların alanları kayıtlı: biri {} metrekare, öteki {} metrekare. "
            "Kenar uzunlukları ise hiç ölçülmemiş.\n\n"
            "{} teli sipariş edecek. Depo, telin tam değerini ister; yaklaşık "
            "ondalık bir sayıyla sipariş verilirse her iki tarla için de fazladan "
            "ya da eksik tel gelebilir."
        ).format(alan_a, alan_b, kisi),
        kanitlar=[
            Kanit("Alan kayıtları",
                  "Birinci tarla {} metrekare, ikinci tarla {} metrekare.".format(
                      alan_a, alan_b),
                  bedel=1, kritik=True),
            Kanit("Tarla biçimi",
                  "\"Her iki tarla da kare: dört kenar birbirine eşit.\"",
                  bedel=1, kritik=True),
            Kanit("Sipariş şartı",
                  "Depo, uzunluğu tam değeriyle (kök işaretiyle) ister; "
                  "yuvarlak ondalık sayı kabul etmez.", bedel=1),
            Kanit("Çit notu",
                  "Çit tek sıra tel olacak, kapı payı bırakılmayacak.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu iki kareköklü uzunluğu toplayıp tam değer bulmak için ne yapmalı?",
                dogru=("Her kökün içindeki tam kareyi dışarı alıp aynı kökü bulur, "
                       "katsayıları toplarım."),
                yanlislar={
                    "Kök içindeki iki sayıyı toplayıp sonucu tek bir karekökün altına yazarım.":
                        "Karekök toplamaya dağılmaz: kök A artı kök B, kök altında "
                        "A artı B'ye eşit değildir. Önce her kök kendi başına "
                        "sadeleşir.",
                    "Kök işaretlerini kaldırıp kök içindeki sayıları doğrudan toplarım, kökü sonra alırım.":
                        "Kök işaretini atlamak sayıyı değiştirir. Kenar uzunluğu, "
                        "alanın karekökü; alanın kendisi değil.",
                    "Kök içindeki iki sayıyı çarpıp sonucu tek karekök altında yazarım, toplama çarpmaya döner.":
                        "Karekökler çarpılırken içler çarpılır, toplanırken çarpılmaz. "
                        "Toplama işlemini çarpma kuralına çevirmek sonucu değiştirir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kareköklü iki sayı ancak kök kısımları aynıysa toplanabilir "
                    "(elma ile elmayı toplamak gibi). Bunun için her kökün içinden tam "
                    "kare çarpan dışarı alınır; geriye aynı kök kalırsa katsayılar "
                    "toplanır."
                ),
                ipuclari=[
                    "Elmayla elma toplanır, elmayla armut toplanmaz. Köklerde \"cins\" hangisi?",
                    "Alanı, bir tam kare ile bir sayının çarpımı olarak yaz.",
                ],
                cozum=("Her alanı tam kare çarpan ve kalan sayı olarak yaz, tam "
                       "kareyi köklü dışına al; kalan kök ikisinde de aynı çıkar."),
            ),
            sayi_adimi(
                soru=("Birinci tarlanın bir kenarı, katsayı × √{} biçiminde "
                      "yazılırsa katsayı kaç olur?").format(m),
                cevap=a,
                aciklama=("Alan {} = {} × {}, yani {}² × {}. Kenar √{} = {} × √{}.").format(
                    alan_a, a * a, m, a, m, alan_a, a, m),
                yaygin_yanlislar=_temiz(a, {
                    a * m: "Kökün altındaki sayıyı da dışarı çıkardın. Yalnız tam "
                           "kare çarpan karekökle dışarı çıkar; geri kalan kök "
                           "altında kalır.",
                    a * a: "Tam kareyi dışarı alırken karekökünü almayı unuttun; "
                           "dışarı çıkan sayı tam karenin KÖKÜ olmalı.",
                }),
                ipuclari=["Alanı, bir tam kare ile {} sayısının çarpımı olarak yaz.".format(m)],
                puan=14,
                cozum="{} = {}² × {}; karekök: {} × √{}.".format(alan_a, a, m, a, m),
            ),
            sayi_adimi(
                soru=("İki tarlanın dört kenarının hepsi çitle çevrilecek. Toplam tel "
                      "uzunluğu katsayı × √{} biçiminde yazılırsa katsayı kaç olur?").format(m),
                cevap=4 * (a + b),
                aciklama=("Kenarlar: {}√{} ve {}√{}. İki tarla, dörder kenar: "
                          "4 × ({} + {}) × √{} = {}√{}.").format(
                              a, m, b, m, a, b, m, 4 * (a + b), m),
                yaygin_yanlislar=_temiz(4 * (a + b), {
                    a + b: "Her tarlanın yalnız bir kenarını saydın. Tel, dört "
                           "kenarın hepsini çevreler.",
                    4 * a: "Yalnız birinci tarlanın çevresini aldın; ikinci tarla "
                           "da çitle çevrilecek.",
                }),
                ipuclari=["İki kenar katsayısını topla, dört kenarla çarp."],
                puan=14,
                cozum="({} + {}) × 4 = {}.".format(a, b, 4 * (a + b)),
            ),
            yorum_adimi(
                soru=("Kâtip iki kenarın toplamını √{} diye yazdı (iki alanın "
                      "toplamının karekökü). Bu yazım için ne söylenir?").format(
                          alan_a + alan_b),
                dogru="Yanlış, çünkü karekök toplamaya dağılmaz ve bu iki ifade farklı değerler verir.",
                yanlislar={
                    "Doğru, çünkü iki karekökü tek bir karekökün altında toplamak her zaman mümkündür.":
                        "Toplama kök içine taşınmaz. Sayısal olarak bak: doğru "
                        "toplam yaklaşık {}, kâtibin yazdığı yaklaşık {}.".format(
                            sy(round(tam_deger, 2)), sy(round(yanlis_deger, 2))),
                    "Doğru, çünkü kök içindeki sayılar aynı katsayıyla çarpıldığı için toplanabilir.":
                        "Katsayı ortak olsa da toplama kök içinde yapılmaz; kökün "
                        "dışındaki katsayılar toplanır, içindeki sayı aynı kalır.",
                    "Yanlış, çünkü toplam yerine çarpım yazılmalı, kök içindeki sayılar çarpılmalıdır.":
                        "Sorun, kökün toplamaya dağıtılması. Çarpmaya geçmek "
                        "çözüm değil; doğru yol sadeleştirip katsayıları toplamak.",
                },
                rastgele=rastgele,
                aciklama=(
                    "√A + √B ile √(A + B) farklı sayılardır: kök toplamaya dağılmaz. "
                    "Burada ({} + {})√{} ≈ {} iken √{} ≈ {}. Köklü ifadeler "
                    "sadeleştirilip aynı kökün katsayıları toplanır."
                ).format(a, b, m, sy(round(tam_deger, 2)), alan_a + alan_b,
                         sy(round(yanlis_deger, 2))),
                ipuclari=["Her ikisini hesap makinesiyle yaklaşık değerle karşılaştır."],
                puan=10,
            ),
        ],
        kapanis="Tel siparişi tam değeriyle yazıldı; depo teli kesip gönderdi.",
        odul={"cevher": 2, "itibar": 3},
    )


@bulmaca(ders="matematik", konu="aralik_ve_kume_islemleri", kademeler=(8, 11), agirlik=1.2)
def calisma_bandi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aralıklar ve küme işlemleri: iki sensörün çalışma sıcaklıkları, uçların dahil olması."""
    a = rastgele.randrange(-20, 8)
    c = a + rastgele.randrange(3, 9)
    b = c + rastgele.randrange(4, 10)
    d = b + rastgele.randrange(3, 9)
    mid = rastgele.randrange(c + 1, b)
    a_dahil, b_dahil, c_dahil, d_dahil = [rastgele.random() < 0.5 for _ in range(4)]
    depo1, depo2 = ad_sec(rastgele, DEPO_ADLARI, 2)

    def uc(dahil):
        return "dahil" if dahil else "hariç"

    degerler = [a, c, mid, b, d]
    secenekler = ["{} derece".format(v) for v in degerler]
    rastgele.shuffle(secenekler)
    ortak_mi = {a: False, d: False, mid: True, c: c_dahil, b: b_dahil}
    dogrular = [i for i, s in enumerate(secenekler)
                if ortak_mi[int(s.split()[0])]]
    ortak_uzun = b - c
    birlesim_uzun = d - a

    def e(v):
        return "({})".format(v) if v < 0 else str(v)

    return Bulmaca(
        kod="mat-calisma-bandi",
        ders="matematik",
        baslik="Çalışma Bandı",
        kademe=kademe,
        konu="aralik_ve_kume_islemleri",
        kazanim="Gerçek sayı aralıklarını tanıma; kesişim ve birleşim işlemlerini uç noktaları gözeterek yapma.",
        dikkat=5,
        brifing=(
            "Su deposunun sıcaklığı iki ayrı sensörle izleniyor. Sensörlerin her "
            "biri yalnızca belli bir sıcaklık aralığında doğru ölçüyor; aralığın "
            "dışında kayıt vermiyor.\n\n"
            "Kurul iki şeyi bilmek istiyor: hangi sıcaklıklarda ikisi birden "
            "çalışır (okuma çift doğrulanır) ve hangi sıcaklıklarda en az biri "
            "çalışır (depo hiç izlenmeden kalmaz)."
        ),
        kanitlar=[
            Kanit("{} sensörü".format(depo1),
                  "{} derece {} ile {} derece {} arasında çalışır.".format(
                      a, uc(a_dahil), b, uc(b_dahil)),
                  bedel=1, kritik=True),
            Kanit("{} sensörü".format(depo2),
                  "{} derece {} ile {} derece {} arasında çalışır.".format(
                      c, uc(c_dahil), d, uc(d_dahil)),
                  bedel=1, kritik=True),
            Kanit("Kurulun iki sorusu",
                  "\"Hangi derecelerde ikisi birden? Hangi derecelerde en az biri?\"",
                  bedel=1),
            Kanit("Bakım notu",
                  "İki sensör de geçen ay kalibre edildi; ölçüm hatası yok.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="\"İkisi birden çalışır\" sorusunu hangi küme işlemi cevaplar?",
                dogru="Kesişim, çünkü iki sensör aralığına birden ait olan dereceler aranıyor.",
                yanlislar={
                    "Birleşim, çünkü iki sensörün çalıştığı dereceler birlikte toplanıyor.":
                        "Birleşim, \"en az biri\" sorusunun cevabıdır; ikisinden "
                        "birine ait olan her sıcaklığı alır. \"İkisi birden\" daha dardır.",
                    "Fark, çünkü ilk sensörün çalıştığı ama ikincinin çalışmadığı dereceler bulunuyor.":
                        "Fark, yalnız birine ait olan dereceleri bulur; ikisinin "
                        "ortak noktalarını değil. Ortak olan kesişimdir.",
                    "Tümleyen, çünkü sensörlerin çalışmadığı dereceler arasından seçim yapılıyor.":
                        "Tümleyen çalışılmayan bölgeyi verir; soru çalışılan "
                        "bölgenin ortak kısmını istiyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Ve\" (ikisi birden) kesişimdir: her iki kümenin ortak "
                    "elemanları. \"Ya da\" (en az biri) birleşimdir: iki kümenin "
                    "elemanlarının hepsi, ortakları bir kez sayılarak."
                ),
                ipuclari=[
                    "Venn şemasında iki dairenin hangi bölgesi 'ikisine birden' ait?",
                    "\"Hem ... hem de\" ifadesi hangi işlemin sözlük karşılığı?",
                ],
                cozum="İki aralığın sayı doğrusunda üst üste bindiği bölgeyi bul: ortak bölge kesişimdir.",
            ),
            coklu_adimi(
                soru="Hangi dereceler için iki sensör de çalışıyor?",
                secenekler=secenekler,
                dogru_indeksler=dogrular,
                aciklama=(
                    "İkisi birden çalışan bölge {} ile {} arasında. Uçlar "
                    "kendi sensörünün kuralına bakar: {} derece ikinci sensörde "
                    "{}, {} derece birinci sensörde {}. Aralığın dışındaki {} ve {} "
                    "derece ortak bölgede olamaz."
                ).format(c, b, c, uc(c_dahil), b, uc(b_dahil), a, d),
                ipuclari=["Her derecenin iki sensör aralığına da girip girmediğine bak; uç noktalarda 'dahil' ya da 'hariç' karar verir."],
                puan=15,
            ),
            sayi_adimi(
                soru="Ortak çalışma bölgesi kaç derece genişliğinde?",
                cevap=ortak_uzun,
                birim="derece",
                aciklama=("Bölge {} ile {} arasında: {} − {} = {} derece. Uçların dahil "
                          "olup olmaması genişliği değiştirmez.").format(
                              c, b, e(b), e(c), ortak_uzun),
                yaygin_yanlislar=_temiz(ortak_uzun, {
                    d - a: "Bütün kapsanan bölgenin genişliğini aldın; soru ortak "
                           "kısmı soruyor.",
                    b - a: "Yalnız ilk sensörün genişliğini aldın; ortak bölge "
                           "ondan daha dar.",
                }),
                ipuclari=["Ortak bölgenin başlangıcı ve bitişi hangi iki sayı?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Depo izlenirken en az bir sensörün çalıştığı dereceler kaç derece genişliğinde bir bölge oluşturur?",
                cevap=birlesim_uzun,
                birim="derece",
                aciklama=("İki aralık kesişiyor, yani birleşim tek parça: {} ile {} "
                          "arası, {} − {} = {} derece. Uzunlukları toplarsan ortak "
                          "bölgeyi iki kez saymış olursun.").format(
                              a, d, e(d), e(a), birlesim_uzun),
                yaygin_yanlislar=_temiz(birlesim_uzun, {
                    (b - a) + (d - c):
                        "İki sensörün genişliklerini topladın. Ortak bölge her "
                        "ikisinde de var; iki kez sayıldı.",
                    ortak_uzun: "Yalnız ortak kısmı aldın. \"En az biri\" "
                                "sorusu ikisinin birleşimini ister.",
                }),
                ipuclari=["Bölgenin en soldaki ve en sağdaki ucu hangi sayılar?"],
                puan=12,
            ),
        ],
        kapanis="Kurul iki bandı da deftere işledi: çift doğrulanan ve izlenen bölgeler.",
        odul={"enerji": 2, "itibar": 3},
    )


@bulmaca(ders="matematik", konu="dik_ucgen_trigonometri", kademeler=(8, 11), agirlik=1.2)
def rampa_egimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Dik üçgende trigonometrik oranlar: rampa yüksekliği, boyu ve eğimi."""
    aile = rastgele.choice([(3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25)])
    olcek = rastgele.choice([1, 2, 3]) if aile[2] <= 13 else 1
    karsi, taban, boy = [v * olcek for v in aile]
    sinus = karsi / boy
    tanjant = karsi / taban
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="mat-rampa-egimi",
        ders="matematik",
        baslik="Rampa Eğimi",
        kademe=kademe,
        konu="dik_ucgen_trigonometri",
        kazanim="Dik üçgende sinüs ve tanjant oranlarını kenarlardan bulma; oranın ölçekten bağımsız olduğunu görme.",
        dikkat=5,
        brifing=(
            "{} bölgesindeki yükleme rampası, eğimi yüzünden araçların kaymasına "
            "yol açıyor. {} rampanın zemine yaslandığı açıyı bilmek istiyor; "
            "iletki yok, ama rampanın boyu ile bir ucunun yerden yüksekliği "
            "ölçülmüş.\n\n"
            "Kurul eğimin belli bir sınırı aşıp aşmadığına bu açıya bakarak "
            "karar verecek."
        ).format(mevki, kisi),
        kanitlar=[
            Kanit("Rampa ölçümü",
                  "Rampanın boyu {} m; yüksek ucu zeminden {} m yukarıda.".format(boy, karsi),
                  bedel=1, kritik=True),
            Kanit("Zemin şartı",
                  "\"Zemin düz ve yatay, rampa zemine tek bir noktadan yaslı; "
                  "yükseklik zemine dik ölçüldü.\"", bedel=1, kritik=True),
            Kanit("Eğim sınırı",
                  "Kurulun kuralı: eğim oranı belli bir sayıyı geçemez.", bedel=1),
            Kanit("Araç notu",
                  "En uzun araç 6 metre; rampadan yavaş geçiyor.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Rampa boyu ile yüksek ucun yüksekliği biliniyor. Açıyı hangi oran verir?",
                dogru="Karşı kenarın hipotenüse oranı, yani yükseklik bölü rampa boyu.",
                yanlislar={
                    "Komşu kenarın hipotenüse oranı, yani zemindeki uzaklık bölü rampa boyu.":
                        "Bu oran kosinüstür ve açının KOMŞU kenarını kullanır. "
                        "Elinde zemindeki uzaklık yok; yükseklik açının karşısında.",
                    "Karşı kenarın komşu kenara oranı, yani yükseklik bölü zemindeki uzaklık.":
                        "Bu oran tanjanttır ve zemindeki uzaklığı ister. Elimizdeki "
                        "iki ölçüm yükseklik ile rampa boyu; zemindeki uzaklık yok.",
                    "Hipotenüsün karşı kenara oranı, yani rampa boyu bölü yükseklik.":
                        "Bu oran sinüsün tersidir; ters çevrildiği için 1'den büyük "
                        "çıkar ve açıyı doğrudan vermez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Açının karşısındaki kenar yükseklik, rampa ise dik açının "
                    "karşısındaki en uzun kenar (hipotenüs). Karşı kenar bölü "
                    "hipotenüs oranı sinüstür; elde bu iki ölçüm olduğu için doğrudan "
                    "kullanılır."
                ),
                ipuclari=[
                    "Rampanın yaslandığı açıya göre yükseklik hangi kenar: karşı mı, komşu mu?",
                    "Hangi iki kenarın ölçüsü elinde? O ikisini içeren oranı seç.",
                ],
                cozum="Açı zeminle rampa arasında; karşısındaki kenar yükseklik, hipotenüs rampa boyu.",
            ),
            sayi_adimi(
                soru="Rampanın zemine yaslandığı açının sinüsü kaç? (Ondalık olarak, en çok iki ondalık.)",
                cevap=round(sinus, 4),
                tolerans=0.006,
                aciklama=("Sinüs = karşı ÷ hipotenüs = {} ÷ {} = {}.").format(
                    karsi, boy, sy(round(sinus, 4))),
                yaygin_yanlislar=_temiz(round(sinus, 4), {
                    round(boy / karsi, 4):
                        "Oranı ters kurdun: yükseklik rampa boyuna bölünür, "
                        "rampa boyu yüksekliğe değil. Sinüs 1'den büyük çıkmaz.",
                    round(taban / boy, 4):
                        "Komşu kenarı kullandın; bu kosinüs oluyor. Sinüs, "
                        "açının karşısındaki kenarı (yüksekliği) kullanır.",
                }),
                ipuclari=["Yüksekliği rampa boyuna böl."],
                puan=12,
                cozum="{} ÷ {} = {}.".format(karsi, boy, sy(round(sinus, 4))),
            ),
            sayi_adimi(
                soru="Rampanın zeminde kapladığı yatay uzaklık kaç metre?",
                cevap=taban,
                birim="m",
                aciklama=("Dik üçgen: yükseklik, yatay uzaklık ve rampa. Pisagor: "
                          "{}² − {}² = {} − {} = {}; karekök {} m.").format(
                              boy, karsi, boy * boy, karsi * karsi,
                              boy * boy - karsi * karsi, taban),
                yaygin_yanlislar=_temiz(taban, {
                    boy - karsi:
                        "Boydan yüksekliği çıkarmak yatay uzaklığı vermez; dik "
                        "üçgenin kenarlarında KARELER çıkarılır.",
                    boy + karsi:
                        "Toplamak mümkün değil; yatay uzaklık rampadan kısadır.",
                }),
                ipuclari=["Pisagor: hipotenüsün karesi, dik kenarların kareleri toplamına eşit."],
                puan=12,
                cozum="{}² − {}² = {}; √{} = {}.".format(
                    boy, karsi, boy * boy - karsi * karsi, boy * boy - karsi * karsi, taban),
            ),
            sayi_adimi(
                soru="Rampanın eğimini (yükseklik bölü yatay uzaklık, yani tanjant) iki ondalıkla yaz.",
                cevap=round(tanjant, 4),
                tolerans=0.006,
                aciklama=("Tanjant = karşı ÷ komşu = {} ÷ {} = {}.").format(
                    karsi, taban, sy(round(tanjant, 4))),
                yaygin_yanlislar=_temiz(round(tanjant, 4), {
                    round(sinus, 4):
                        "Sinüsü yazdın; eğim oranı yükseklik bölü YATAY uzaklıktır, "
                        "rampa boyuna bölünmez.",
                    round(taban / karsi, 4):
                        "Oranı ters kurdun: yükseklik yatay uzaklığa bölünür.",
                }),
                ipuclari=["Yüksekliği yatay uzaklığa böl; rampa boyu bu oranda yok."],
                puan=12,
                cozum="{} ÷ {} = {}.".format(karsi, taban, sy(round(tanjant, 4))),
            ),
            yorum_adimi(
                soru=("Rampa aynı açıyla iki kat uzatılırsa sinüs değeri nasıl değişir?"),
                dogru="Değişmez, çünkü yükseklik de rampa boyuyla birlikte tam aynı oranda büyür.",
                yanlislar={
                    "İki katına çıkar, çünkü rampa boyu iki katına çıkıyor ve sinüs onunla artıyor.":
                        "Rampa uzayınca yükseklik de aynı kat artar; bölümde "
                        "ikisi birbirini götürür. Oran açıya bağlı, boyuta değil.",
                    "Yarıya iner, çünkü bölen olan rampa boyu büyüdüğü için sonuç küçülür.":
                        "Bölen büyüdü ama bölünen de büyüdü; yükseklik aynı kalmıyor. "
                        "Oranın değeri sabit kalır.",
                    "Artar ama tam iki katı olmaz, çünkü rampanın eğimi uzadıkça dikleşir.":
                        "Açı aynı kaldığı için eğim de aynı kalır; rampa dikleşmez. "
                        "Aynı açıda her ölçekte sinüs aynıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Trigonometrik oranlar açıya bağlıdır, dik üçgenin boyutuna değil. "
                    "Benzer dik üçgenlerde karşılıklı kenarlar aynı oranda büyüdüğü "
                    "için oranlar sabit kalır."
                ),
                puan=10,
            ),
        ],
        kapanis="Eğim açısı rapora yazıldı; kurul rampa için kararını verdi.",
        odul={"enerji": 2, "erzak": 1},
    )


@bulmaca(ders="matematik", konu="bolunebilme_kalan", kademeler=(8, 11), agirlik=1.2)
def nobet_carki(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bölünebilme ve kalan: dönüşümlü nöbet sırası, 9'a bölünebilme kuralı."""
    m = rastgele.choice([5, 6, 7, 8])
    n_gun = rastgele.randrange(60, 400)
    while n_gun % m == 0:
        n_gun += 1
    kalan = n_gun % m
    n2 = m * rastgele.randrange(10, 60)
    uzun_yanlis = "Kimse, çünkü kalan sıfır çıktığı zaman o gün için nöbetçi yazılmaz."
    while True:
        kisiler = rastgele.sample(PERSONEL, m)
        c = len(kisiler[m - 1])
        if c >= min(len(kisiler[0]), len(kisiler[m - 2])):
            break
    sira_metni = ", ".join("{}. {}".format(i + 1, k) for i, k in enumerate(kisiler))
    sefer_gun = n_gun
    ilk_kez = (sefer_gun - 1) // m + 1

    def sayi_uret(hedef_toplam):
        while True:
            x = rastgele.randrange(1000, 9999)
            if sum(int(h) for h in str(x)) == hedef_toplam:
                return x

    dokuza = [sayi_uret(rastgele.choice([9, 18, 27])) for _ in range(2)]
    uce = [sayi_uret(rastgele.choice([12, 15, 21, 24])) for _ in range(2)]
    secenekler, dogrular = coklu_siklar(
        rastgele, ["{}".format(x) for x in dokuza], ["{}".format(x) for x in uce])
    secenekler_ayri = len(set(secenekler)) == len(secenekler)
    while not secenekler_ayri:
        dokuza = [sayi_uret(rastgele.choice([9, 18, 27])) for _ in range(2)]
        uce = [sayi_uret(rastgele.choice([12, 15, 21, 24])) for _ in range(2)]
        secenekler, dogrular = coklu_siklar(
            rastgele, ["{}".format(x) for x in dokuza], ["{}".format(x) for x in uce])
        secenekler_ayri = len(set(secenekler)) == len(secenekler)

    return Bulmaca(
        kod="mat-nobet-carki",
        ders="matematik",
        baslik="Nöbet Çarkı",
        kademe=kademe,
        konu="bolunebilme_kalan",
        kazanim="Bölme işleminde kalanla döngüsel sıra bulma; 9 ile bölünebilme kuralı.",
        dikkat=6,
        brifing=(
            "Üssün gözetleme kulesinde {} kişi sırayla nöbet tutuyor: birinci gün "
            "sıradaki ilk kişi, ikinci gün ikinci kişi, ve son kişiden sonra sıra "
            "başa dönüyor. Sefer uzun sürecek; kimse kaçıncı günde kimin nöbette "
            "olduğunu defterden elle saymak istemiyor.\n\n"
            "Kâtip, belirli bir günün nöbetçisini ve ilk kişinin sefer boyunca kaç "
            "kez nöbet tutacağını hesapla bulmak istiyor."
        ).format(m),
        kanitlar=[
            Kanit("Nöbet sırası", "Sıra: {}.".format(sira_metni),
                  bedel=1, kritik=True),
            Kanit("Sefer süresi",
                  "Sefer {} gün sürecek; birinci gün sıradaki ilk kişiyle başlıyor.".format(sefer_gun),
                  bedel=1, kritik=True),
            Kanit("Döngü kuralı",
                  "\"Son kişiden sonra sıra yeniden birinci kişiye döner.\"",
                  bedel=1),
            Kanit("Defter notu",
                  "Defterin ilk sayfasında yalnız ilk iki haftanın nöbetleri yazılı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Verilen bir günün nöbetçisini defteri saymadan hangi işlem bulur?",
                dogru=("Gün numarasını kişi sayısına bölüp kalana bakmak, kalan sıradaki "
                       "kişiyi gösterir."),
                yanlislar={
                    "Gün numarasını kişi sayısına bölüp bölüme bakmak, bölüm sıradaki kişiyi gösterir.":
                        "Bölüm, kaç TAM tur döndüğünü söyler; sıra ise turun içinde "
                        "nerede olunduğuna, yani kalana bağlı.",
                    "Gün numarasını kişi sayısıyla çarpıp çıkan sayının son rakamına bakmak.":
                        "Çarpma sırayı döngüye sokmaz. Döngü bölünerek bulunur: "
                        "her tam turda sıra aynı yere döner.",
                    "Gün numarasının son rakamına bakıp o numaralı kişiyi nöbetçi saymak.":
                        "Son rakam on gün döngüsüne uyar; nöbet çarkı kişi "
                        "sayısına göre döner, onluk basamağa göre değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Her {} günde sıra başa döner. Gün numarasını kişi sayısına bölünce "
                    "bölüm tam turları, kalan ise son tamamlanan turdan sonra kaçıncı "
                    "kişide olunduğunu gösterir."
                ).format(m),
                ipuclari=[
                    "Her tam turdan sonra sıra nereye döner? Tam turlar sırayı değiştirir mi?",
                    "Kalan, tamamlanmış turlardan arta kalan günlerdir.",
                ],
                cozum="Gün numarası = kişi sayısı × tam tur + kalan. Kalan, kaçıncı kişi olduğunu söyler.",
            ),
            sayi_adimi(
                soru="{}. günün nöbetçisini bulmak için {} sayısı, kişi sayısına bölününce kalan kaç olur?".format(
                    n_gun, n_gun),
                cevap=kalan,
                aciklama=("{} = {} × {} + {}; kalan {}, yani {}. gün sırada {}. kişi nöbette."
                          ).format(n_gun, m, n_gun // m, kalan, kalan, n_gun, kalan),
                yaygin_yanlislar=_temiz(kalan, {
                    n_gun // m:
                        "Bölümü verdin. Soru kalanı istiyor; bölüm kaç tam tur "
                        "döndüğünü söyler.",
                }),
                ipuclari=["Bölme işleminde artan sayıya kalan denir."],
                puan=12,
                cozum="{} ÷ {}: bölüm {}, kalan {}.".format(n_gun, m, n_gun // m, kalan),
            ),
            secim_adimi(
                soru=("Başka bir sefer kaydında {}. günün nöbetçisini arıyorsun. "
                      "{} sayısı kişi sayısına tam bölünüyor (kalan sıfır). Kim nöbette?").format(n2, n2),
                dogru=kisiler[m - 1],
                yanlislar={
                    kisiler[0]:
                        "Kalan sıfır, sıranın başa döndüğü anlamına gelmiyor; "
                        "kalan sıfırsa tur tam bitmiştir, yani son kişide.",
                    kisiler[m - 2]:
                        "Son kişiden bir önceki sıraya kaydırdın. Tam tur "
                        "bittiğinde sıra son kişide kalır; bir geri gitmezsin.",
                    uzun_yanlis:
                        "Her gün için bir nöbetçi vardır; kalan sıfır çıkması o günü "
                        "boş bırakmaz, tur son kişide biter.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kalan sıfır demek sıranın tam bir turu bitirdiği, yani döngünün "
                    "son kişisine gelindiği demek. Kalan 1 ilk kişiyi, 2 ikinciyi, ... "
                    "kalan sıfır ise {}. (son) kişiyi gösterir."
                ).format(m),
                ipuclari=["{}. günde bir tam tur bitti mi, yoksa yeni bir tura başlandı mı?".format(n2)],
                puan=12,
            ),
            sayi_adimi(
                soru=("Sefer {} gün sürüyor. Sıradaki İLK kişi sefer boyunca kaç kez "
                      "nöbet tutar?").format(sefer_gun),
                cevap=ilk_kez,
                birim="kez",
                aciklama=("İlk kişi 1., {}., {}. ... günlerde nöbette. {} gün = {} tam tur "
                          "({} gün) ve {} gün fazla. Artan günlerin ilk günü yine ilk "
                          "kişinin olduğundan {} + 1 = {} kez."
                          ).format(1 + m, 1 + 2 * m, sefer_gun, sefer_gun // m,
                                   (sefer_gun // m) * m, sefer_gun % m, sefer_gun // m,
                                   ilk_kez),
                yaygin_yanlislar=_temiz(ilk_kez, {
                    sefer_gun // m:
                        "Yalnız tam turları saydın. Sefer tam tura denk gelmiyor; "
                        "son, yarım kalan turda da ilk kişi nöbete başlıyor.",
                }),
                ipuclari=["Tam turlardan arta kalan günlerde ilk kişi yine sırada mı?"],
                puan=14,
                cozum="{} = {} × {} + {}; kalan sıfırdan büyük: {} + 1 kez.".format(
                    sefer_gun, m, sefer_gun // m, sefer_gun % m, sefer_gun // m),
            ),
            coklu_adimi(
                soru=("Aynı gün gelen konteynerlerin seri numaraları arasından 9'a "
                      "kalansız bölünenler soğuk depoya gidecek. Hangileri?"),
                secenekler=secenekler,
                dogru_indeksler=dogrular,
                aciklama=(
                    "Rakamları toplamı 9'un katı olan sayı 9'a bölünür. "
                    + "; ".join("{}: rakam toplamı {}".format(
                        s, sum(int(h) for h in s)) for s in secenekler)
                    + ". Yalnız 3'ün katı olan toplam (12, 15, 21, 24) 3'e bölünmeyi "
                    "gösterir, 9'a bölünmeyi değil."
                ),
                ipuclari=["Her sayının rakamlarını topla; toplam 9'un katı mı?"],
                puan=15,
            ),
        ],
        kapanis="Nöbet çarkı deftere işlendi; soğuk depoya gidecek konteynerler ayrıldı.",
        odul={"erzak": 2, "itibar": 3},
    )
