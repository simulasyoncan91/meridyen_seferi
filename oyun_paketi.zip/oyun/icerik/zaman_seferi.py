# -*- coding: utf-8 -*-
"""
Zaman seferleri: tek kurgunun içinde birden çok ders.

Kronograf artık yalnızca kayıt getirmiyor; oyuncuyu bir çağın içine bırakıyor.
Orada sırayla dört iş yapılır:

    1. NE ZAMAN?  - çağı kanıtlardan bul                       (tarih)
    2. NEREDE?    - bölgeyi coğrafi izlerden bul                (coğrafya)
    3. HESAP      - o çağın kendi sorununu çöz          (matematik / fen)
    4. RAPOR      - üst makama olayı düzgün anlat               (Türkçe)

Bunun eğitimsel karşılığı şu: öğrenci derslerin birbirinden kopuk olmadığını
burada görür. Aynı olayın tarihi, coğrafyası, hesabı ve anlatımı vardır;
biri olmadan diğeri eksik kalır.

Her bölüm kendi dersinin normal bir görevidir, bu yüzden konu haritasına ve
karneye olduğu gibi işler.
"""
from __future__ import annotations

import random
from typing import List

from oyun.motor.kayit_defteri import sefer
from oyun.motor.modeller import Bulmaca, Kanit, Sefer

from ._ortak import (
    coklu_siklar, coklu_adimi, model_adimi, sayi_adimi, secim_adimi, sy,
    yorum_adimi,
)


def _bolum(kod, ders, baslik, kademe, konu, kazanim, brifing, kanitlar,
           adimlar, kapanis="", odul=None, dikkat=6) -> Bulmaca:
    """Sefer bölümü kurmak için kısayol."""
    return Bulmaca(
        kod=kod, ders=ders, baslik=baslik, kademe=kademe, konu=konu,
        kazanim=kazanim, brifing=brifing, kanitlar=kanitlar, adimlar=adimlar,
        kapanis=kapanis, odul=odul or {}, dikkat=dikkat,
    )


# ==========================================================================
# SEFER 1 - TUNÇ ÇAĞI ANADOLU
# ==========================================================================

@sefer(kod="tunc-cagi-anadolu", kademeler=(6, 11))
def tunc_cagi_seferi(rastgele: random.Random, kademe: int) -> Sefer:
    """MÖ 1300 dolayları, Kızılırmak kavsi. Tarih + coğrafya + oran + rapor."""
    # --- 3. bölümün sayıları: tahıl paylaşımı
    pay_a = rastgele.choice([2, 3, 4])
    pay_b = rastgele.choice([5, 7, 9])
    if pay_a >= pay_b:
        pay_a, pay_b = 3, 7
    birim = rastgele.randrange(12, 20 + 2 * kademe)
    kale_payi = pay_a * birim
    koy_payi = pay_b * birim
    toplam = kale_payi + koy_payi

    return Sefer(
        kod="tunc-cagi-anadolu",
        baslik="Kızılırmak Kavsi",
        donem="MÖ 1300 dolayları - Tunç Çağı Anadolu",
        kademe=kademe,
        giris=(
            "Kronograf bu sefer bir kayıt getirmedi. Kolu çevirdiğinde odanın "
            "duvarları silindi ve kendini bir taş avluda buldun.\n\n"
            "Etrafta insanlar var ama seni görmüyorlar. Bir kâtip ıslak kile "
            "bir şeyler basıyor, avluda iki atın çektiği hafif bir araba "
            "duruyor, uzakta surlar görünüyor.\n\n"
            "Kronograf'ın kolunda tek bir yazı var: DÖNÜŞ İÇİN RAPOR GEREKLİ.\n\n"
            "Yani buradan çıkmanın yolu, gördüğünü üst makama düzgün "
            "anlatmaktan geçiyor. Ama önce nerede ve ne zaman olduğunu "
            "bilmen lazım."
        ),
        baglantilar=[
            "Çağı buldun. Şimdi NEREDE olduğunu çıkarman gerekiyor; "
            "raporda yer adı da yazacak.",
            "Yerini de buldun. Tam bu sırada kâtip elindeki tableti sana "
            "doğru çeviriyor - sanki okumanı istiyor.",
            "Hesap tamam. Geriye tek iş kaldı: bütün bunları üst makama "
            "yazmak. Kronograf raporsuz açılmıyor.",
        ],
        kapanis=(
            "Raporu bitirdiğin anda avlu titriyor ve kendini yeniden Kronograf "
            "odasında buluyorsun. Elinde, biraz önce yazdığın rapor var.\n\n"
            "Komutan okuyup başını sallıyor: \"Tarihini, yerini, hesabını ve "
            "cümlesini bir arada tutmuşsun. Bir olayı anlatmak budur.\""
        ),
        odul={"itibar": 12, "enerji": 6, "cevher": 4},
        bolumler=[
            # ---------------------------------------------------- 1) TARİH
            _bolum(
                kod="sefer-tunc-tarih", ders="tarih", baslik="Ne Zamandayız",
                kademe=kademe, konu="donem_tespiti",
                kazanim="Maddi kalıntılardan dönem çıkarımı; teknolojik eşiklerle tarihlendirme.",
                brifing=(
                    "Avluda durup etrafına bakıyorsun. Kimse seni görmüyor, "
                    "istediğin kadar inceleyebilirsin.\n\n"
                    "Rapora yazacağın ilk şey tarih. Ama takvim yok, kimse "
                    "sana yılı söylemeyecek. Çağı, gördüğün nesnelerden "
                    "çıkarman gerekiyor."
                ),
                kanitlar=[
                    Kanit("Kâtibin elindeki",
                          "Islak kile, ucu üçgen bir kamışla işaretler basıyor. "
                          "Bu bir yazı - çivi yazısı.", bedel=2, kritik=True),
                    Kanit("Askerlerin silahları",
                          "Baltalar ve mızrak uçları sarımtırak bir metalden: "
                          "tunç. Hiçbirinde demir yok.", bedel=2, kritik=True),
                    Kanit("Avludaki araba",
                          "İki atın çektiği, iki tekerlekli hafif bir savaş "
                          "arabası.", bedel=1),
                    Kanit("Surlar",
                          "Taş temelli, kuleli ve anıtsal. Büyük bir örgütlenme "
                          "işi.", bedel=1),
                    Kanit("Aradığın ama bulamadığın",
                          "Kâğıt yok. Basılı hiçbir şey yok. Cam yok. Demir "
                          "alet yok.", bedel=2, kritik=True),
                ],
                adimlar=[
                    model_adimi(
                        soru="Çağı belirlemek için hangi iki iz birlikte kullanılmalı?",
                        dogru=("Yazının VAR olması ve demirin YOK olması; ikisi "
                               "birlikte aralığı iki uçtan sıkıştırır."),
                        yanlislar=[
                            "Surların büyüklüğü ve avludaki insan sayısı.",
                            "Arabanın tekerlek sayısı ve atların cinsi.",
                            "Yalnızca yazının var olması.",
                            "Giysilerin rengi ve kumaşı.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Tarihlendirme iki yönlü sıkıştırmadır. Yazının bulunması "
                            "kaydı tarih öncesinden çıkarır (alt sınır). Demirin hiç "
                            "olmaması ise Demir Çağı'ndan öncede olduğumuzu söyler "
                            "(üst sınır). Yapı büyüklüğü ya da nüfus böyle keskin bir "
                            "sınır vermez."
                        ),
                        ipuclari=[
                            "Bir nesne icat edilmeden kullanılabilir mi?",
                            "Bir şeyin YOKLUĞU da tarih verir: henüz bilinmiyor olabilir.",
                        ],
                        puan=18,
                        cozum=(
                            "1) Çivi yazısı var -> tarihî çağlardayız (MÖ 3200 sonrası).\n"
                            "2) Silahlar tunç, demir yok -> Demir Çağı'ndan önce "
                            "(MÖ 1200 öncesi).\n"
                            "3) İki sınır birleşince: MÖ 3200 ile MÖ 1200 arası.\n"
                            "4) Savaş arabası ve anıtsal surlar bu aralığın son "
                            "dönemine, Tunç Çağı Anadolu'suna işaret eder."
                        ),
                    ),
                    secim_adimi(
                        soru="Rapora hangi çağı yazacaksın?",
                        dogru="Tunç Çağı (yaklaşık MÖ 1300)",
                        yanlislar=[
                            "Neolitik Çağ (yaklaşık MÖ 8000)",
                            "Demir Çağı (MÖ 1200 sonrası)",
                            "Roma dönemi (MS 100 dolayları)",
                            "Orta Çağ (MS 1000 dolayları)",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Yazı var, demir yok, tunç yaygın: bu birleşim Tunç "
                            "Çağı'nı gösterir. Neolitik'te yazı da metal de yoktu; "
                            "Demir Çağı'nda silahlar demir olurdu."
                        ),
                        ipuclari=["İki sınırı birleştir: yazı var mı, demir var mı?"],
                        puan=16,
                    ),
                    yorum_adimi(
                        soru="Kâğıt görememen tarihlendirmeye ne katıyor?",
                        dogru=("Üst sınırı daha da aşağı çekiyor; kâğıt çok daha "
                               "sonra yayılmıştır."),
                        yanlislar=[
                            "Hiçbir şey katmıyor, kâğıt her çağda enderdi.",
                            "Alt sınırı yukarı çekiyor.",
                            "Yazının olmadığını gösteriyor.",
                            "Bölgenin yoksul olduğunu gösteriyor.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Her 'yok' bir tarihtir. Kâğıdın bulunmaması, kaydı "
                            "kâğıdın yayılmasından öncesine yerleştirir. Tarihçi "
                            "gördüğü kadar görmediğini de yazar."
                        ),
                        puan=12,
                    ),
                ],
                kapanis="Rapor taslağına ilk satır yazıldı: çağ belirlendi.",
                odul={"itibar": 4},
            ),

            # -------------------------------------------------- 2) COĞRAFYA
            _bolum(
                kod="sefer-tunc-cografya", ders="cografya", baslik="Neredeyiz",
                kademe=kademe, konu="turkiye_bolgeleri",
                kazanim="Türkiye'nin coğrafi bölgelerini iklim, bitki örtüsü ve yer şekillerinden tanıma.",
                brifing=(
                    "Surların üstüne çıkıp etrafa bakıyorsun. Rapora yer de "
                    "yazman gerekiyor ve elinde harita yok.\n\n"
                    "Ama manzara konuşuyor: bitki örtüsü, arazi, iklim ve "
                    "yakındaki su, bölgeyi ele veriyor."
                ),
                kanitlar=[
                    Kanit("Bitki örtüsü",
                          "Ufka kadar ağaçsız, kısa otlarla kaplı geniş bir "
                          "düzlük. Ormanı ancak uzaktaki tepelerde görüyorsun.",
                          bedel=2, kritik=True),
                    Kanit("Hava",
                          "Gündüz sıcak, gece belirgin biçimde soğuk. Yaz kurak "
                          "geçiyor; halk yağmuru ilkbaharda bekliyor.",
                          bedel=2, kritik=True),
                    Kanit("Su",
                          "Kızıla çalan, geniş bir kavis çizerek akan büyük bir "
                          "ırmak. Yerliler ona 'kızıl su' diyor.",
                          bedel=2, kritik=True),
                    Kanit("Tarla ürünü",
                          "Ekilen şey ağırlıkla buğday ve arpa. Zeytin ya da "
                          "turunçgil hiç yok.", bedel=1, kritik=True),
                    Kanit("Uzaktaki göl",
                          "Günlerce yürüme mesafesinde, kıyısı beyaz kabuk "
                          "bağlamış tuzlu bir göl olduğunu söylüyorlar.", bedel=1),
                ],
                adimlar=[
                    model_adimi(
                        soru="Bölgeyi belirlerken hangi ipuçları birlikte okunmalı?",
                        dogru=("Bitki örtüsü, iklim ve yetiştirilen ürün; üçü "
                               "birlikte tek bir bölgeye işaret eder."),
                        yanlislar=[
                            "Yalnızca ırmağın rengi.",
                            "Surların yüksekliği ve taşın cinsi.",
                            "İnsanların konuştuğu dil.",
                            "Yalnızca gölün varlığı.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Tek bir iz yanıltır: ırmak birçok bölgeden geçebilir. "
                            "Ama 'ağaçsız bozkır + karasal iklim (gece soğuk, yaz "
                            "kurak) + buğday-arpa' birleşimi tek bir yere oturur. "
                            "Coğrafyada bölge, izlerin KESİŞİMİNDEN bulunur."
                        ),
                        ipuclari=[
                            "Zeytin yoksa hangi bölgeler elenir?",
                            "Gece ile gündüz arasında büyük sıcaklık farkı hangi iklimin işaretidir?",
                        ],
                        puan=18,
                        cozum=(
                            "1) Ağaçsız bozkır + yaz kuraklığı + gece-gündüz farkı "
                            "-> KARASAL iklim.\n"
                            "2) Zeytin ve turunçgil yok -> Akdeniz ve Ege elendi.\n"
                            "3) Ormansızlık ve kuraklık -> Karadeniz elendi.\n"
                            "4) Buğday-arpa ağırlıklı tarım + geniş kavisli kızıl "
                            "ırmak (Kızılırmak) + yakında tuzlu göl (Tuz Gölü)\n"
                            "-> İÇ ANADOLU BÖLGESİ."
                        ),
                    ),
                    secim_adimi(
                        soru="Rapora hangi bölgeyi yazacaksın?",
                        dogru="İç Anadolu",
                        yanlislar=["Karadeniz", "Akdeniz", "Ege", "Doğu Anadolu"],
                        rastgele=rastgele,
                        aciklama=(
                            "Bozkır bitki örtüsü, karasal iklim, buğday-arpa tarımı, "
                            "Kızılırmak ve Tuz Gölü: hepsi İç Anadolu'yu gösterir. "
                            "Karadeniz ormanlık ve yağışlı, Akdeniz ile Ege'de zeytin "
                            "ve turunçgil yetişir, Doğu Anadolu çok daha yüksek ve "
                            "sert kışlıdır."
                        ),
                        ipuclari=["Elediklerinden sonra geriye hangi bölge kalıyor?"],
                        puan=16,
                    ),
                    yorum_adimi(
                        soru="Zeytin görememen neden işine yaradı?",
                        dogru=("Zeytin kışı ılık geçen bölgelerde yetişir; yokluğu "
                               "Akdeniz ve Ege'yi doğrudan eledi."),
                        yanlislar=[
                            "Zeytin her bölgede yetişir, bir şey elemez.",
                            "Zeytin yalnızca modern dönemde yetiştirilir.",
                            "Zeytinin yokluğu bölgenin yoksul olduğunu gösterir.",
                            "Zeytin yalnızca Karadeniz'de yetişir.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Bitkiler iklim göstergesidir: zeytin kışı ılık, yazı "
                            "sıcak ve kurak geçen yerlerde yetişir; sert kışa "
                            "dayanmaz. Bu yüzden zeytinin olmaması bir eksiklik "
                            "değil, güçlü bir ipucudur."
                        ),
                        puan=12,
                    ),
                ],
                kapanis="Rapor taslağına ikinci satır yazıldı: bölge belirlendi.",
                odul={"itibar": 4},
            ),

            # -------------------------------------------------- 3) MATEMATİK
            _bolum(
                kod="sefer-tunc-matematik", ders="matematik",
                baslik="Kâtibin Tableti", kademe=kademe, konu="oran_oranti",
                kazanim="Oran-orantı; toplamı bilinen iki payı orana göre ayırma.",
                brifing=(
                    "Kâtip tableti sana çeviriyor. Üzerinde çizgiler ve "
                    "işaretler var; şaşırtıcı biçimde ne demek istediğini "
                    "anlıyorsun.\n\n"
                    "Ambardaki tahıl kale ile köy arasında paylaştırılacak ve "
                    "kâtip toplam sayıyı yazmış ama payları yazmamış. "
                    "Kaydı tamamlaman bekleniyor - anlaşılan Kronograf seni "
                    "buraya boşuna getirmemiş.\n\n"
                    "Ambarda toplam {} ölçek tahıl var."
                ).format(toplam),
                kanitlar=[
                    Kanit("Tabletteki toplam",
                          "Ambar mevcudu: {} ölçek.".format(toplam),
                          bedel=1, kritik=True),
                    Kanit("Kâtibin işaret ettiği satır",
                          "\"Kaleye ayrılan pay, köye ayrılanın {}/{} kadarıdır. "
                          "Bu oran her hasatta aynıdır.\"".format(pay_a, pay_b),
                          bedel=2, kritik=True),
                    Kanit("Ambar görevlisi",
                          "Tahılın tamamı bu iki yere dağıtılacak; başka bir "
                          "yere ayrılan pay yok.", bedel=1, kritik=True),
                    Kanit("Ölçek taşı",
                          "Bir ölçek, iki elle taşınabilecek bir sepet kadar. "
                          "Sayım hep bu taşla yapılıyor.", bedel=1),
                ],
                adimlar=[
                    model_adimi(
                        soru="Payları bulmak için hangi kurulum doğru?",
                        dogru=("Kale {}p, köy {}p olsun (p ortak birim). "
                               "O hâlde {}p + {}p = {}").format(
                            pay_a, pay_b, pay_a, pay_b, toplam),
                        yanlislar=[
                            "Kale {} ölçek, köy {} ölçek alır.".format(pay_a, pay_b),
                            "Kale toplamın {}/{} katını alır: {} × {}/{}".format(
                                pay_a, pay_b, toplam, pay_a, pay_b),
                            "Toplam, {} ile {} sayılarının farkına bölünür.".format(
                                pay_b, pay_a),
                            "Toplam ikiye bölünür, sonra biri {} ile çarpılır.".format(pay_a),
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "\"Kalenin payı köyünkinin {}/{} katı\" demek, ikisini {} ve "
                            "{} birimlik paylar olarak düşünmektir. Dikkat: kale "
                            "toplamın {}/{} katı DEĞİL, toplamın {}/{} katıdır; çünkü toplam "
                            "{} birimdir."
                        ).format(pay_a, pay_b, pay_a, pay_b, pay_a, pay_b,
                                 pay_a, pay_a + pay_b, pay_a + pay_b),
                        ipuclari=[
                            "Oran verildiğinde ortak bir 'birim pay' tanımlamak işi kolaylaştırır.",
                            "Toplam kaç birim pay eder? İki sayıyı topla.",
                        ],
                        puan=18,
                        cozum=(
                            "1) Oran {}/{} -> kale {} birim, köy {} birim.\n"
                            "2) Toplam birim: {} + {} = {}\n"
                            "3) Bir birim: {} / {} = {} ölçek\n"
                            "4) Kale: {} x {} = {} ölçek\n"
                            "   Köy : {} x {} = {} ölçek\n"
                            "5) Denetim: {} + {} = {} - tabletteki toplamla aynı."
                        ).format(pay_a, pay_b, pay_a, pay_b, pay_a, pay_b,
                                 pay_a + pay_b, toplam, pay_a + pay_b, birim,
                                 pay_a, birim, kale_payi, pay_b, birim, koy_payi,
                                 kale_payi, koy_payi, toplam),
                    ),
                    sayi_adimi(
                        soru="Bir birim pay kaç ölçek?",
                        cevap=birim, birim="ölçek",
                        aciklama="{} + {} = {} birim pay var. {} ÷ {} = {} ölçek.".format(
                            pay_a, pay_b, pay_a + pay_b, toplam, pay_a + pay_b, birim),
                        ipuclari=["Toplamı, toplam pay sayısına böl."],
                        puan=14,
                    ),
                    sayi_adimi(
                        soru="Kaleye kaç ölçek tahıl ayrılacak?",
                        cevap=kale_payi, birim="ölçek",
                        aciklama="{} × {} = {} ölçek.".format(pay_a, birim, kale_payi),
                        ipuclari=["Birim payı kalenin pay sayısıyla çarp."],
                        puan=14,
                    ),
                ],
                kapanis=(
                    "Kâtip tablete iki sayı daha basıyor. Sana bakıp hafifçe "
                    "başını sallıyor; anlaşıldığını gösteren bir bakış."
                ),
                odul={"erzak": 6, "itibar": 3},
            ),

            # ---------------------------------------------------- 4) TÜRKÇE
            _bolum(
                kod="sefer-tunc-turkce", ders="turkce", baslik="Üst Makama Rapor",
                kademe=kademe, konu="uslup",
                kazanim="Metin türüne uygun üslup; resmî yazıda nesnellik ve açıklık.",
                brifing=(
                    "Kronograf'ın kolundaki yazı hâlâ duruyor: DÖNÜŞ İÇİN "
                    "RAPOR GEREKLİ.\n\n"
                    "Elinde her şey var: çağ, bölge ve hesap. Şimdi bunları "
                    "üst makama yazacaksın.\n\n"
                    "Rapor merkezde okunacak ve okuyan kişi burayı hiç "
                    "görmedi. Yazdığın cümleler dışında hiçbir bilgisi olmayacak."
                ),
                kanitlar=[
                    Kanit("Elindeki bilgiler",
                          "Çağ: Tunç Çağı (yaklaşık MÖ 1300)\n"
                          "Bölge: İç Anadolu\n"
                          "Hesap: ambardaki {} ölçek tahıl {}/{} oranında "
                          "paylaştırıldı.".format(toplam, pay_a, pay_b),
                          bedel=1, kritik=True),
                    Kanit("Resmî yazışma kılavuzu",
                          "Resmî raporda: nesnel anlatım kullanılır, gözlem ile "
                          "yorum ayrılır, belirsiz ifadeler (\"bir sürü\", "
                          "\"galiba\") kullanılmaz, dayanak belirtilir.",
                          bedel=2, kritik=True),
                    Kanit("Komutanın eski notu",
                          "\"Bana ne gördüğünü yaz, ne hissettiğini değil. "
                          "Hissini merak edersem sorarım.\"", bedel=1, kritik=True),
                    Kanit("Kronograf uyarısı",
                          "Aygıt, dayanağı yazılmamış raporu geçersiz sayıyor.",
                          bedel=1),
                ],
                adimlar=[
                    model_adimi(
                        soru="Bu rapordaki cümleleri ne belirlemeli?",
                        dogru=("Gözlemi ve dayanağını birlikte veren, yoruma "
                               "kaymayan nesnel ifadeler."),
                        yanlislar=[
                            "Okuyanı etkileyecek kadar canlı ve duygulu anlatım.",
                            "Mümkün olduğunca kısa, tek kelimelik notlar.",
                            "Olayın nasıl hissettirdiğini anlatan cümleler.",
                            "Süslü ve edebî bir dil.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Resmî raporun amacı nezaket ya da etkilemek değil, "
                            "okuyanın olayı yazandan bağımsız değerlendirebilmesidir. "
                            "Bu yüzden her iddianın yanında dayanağı bulunur: "
                            "\"tunç silah görüldü, demir silaha rastlanmadı\" gibi. "
                            "Duygu ve süs, doğrulanamayan bilgi ekler."
                        ),
                        ipuclari=[
                            "Raporu okuyan kişi burayı hiç görmedi. Neye ihtiyacı var?",
                            "Komutanın notu ne diyor: ne gördüğün mü, ne hissettiğin mi?",
                        ],
                        puan=18,
                        cozum=(
                            "Resmî rapor cümlesinin iki parçası vardır:\n"
                            "  (a) GÖZLEM: ne görüldü, ölçülebilir biçimde\n"
                            "  (b) DAYANAK: bu sonuca neye bakarak varıldı\n\n"
                            "Örnek: \"Bölgede zeytin tarımına rastlanmamış, bitki "
                            "örtüsü bozkırdır; bu nedenle İç Anadolu olduğu "
                            "değerlendirilmiştir.\"\n\n"
                            "Kaçınılacaklar: \"çok etkileyiciydi\", \"galiba\", "
                            "\"bir sürü asker vardı\" gibi ölçülemez ifadeler."
                        ),
                    ),
                    _rapor_secimi(rastgele),
                    yorum_adimi(
                        soru="Raporda \"galiba Tunç Çağı'ndaydık\" yazmak neden sorunlu?",
                        dogru=("Elde kesin dayanak varken belirsizlik katıyor; "
                               "okuyan kişi neye güveneceğini bilemez."),
                        yanlislar=[
                            "Sorun değil, tarih zaten kesin bilinemez.",
                            "Cümle çok kısa olduğu için sorunlu.",
                            "\"Galiba\" kelimesi kaba olduğu için sorunlu.",
                            "Tarih yazmak rapora hiç girmemeli.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Belirsizlik ifadesi ancak gerçekten belirsizlik varsa "
                            "kullanılır. Burada iki bağımsız iz (yazı var, demir yok) "
                            "çağı sıkıştırıyor; bu bir tahmin değil, gerekçeli bir "
                            "sonuç. \"Galiba\" yazmak, elindeki kanıtı çöpe atmak olur. "
                            "Tersi de doğrudur: kanıtın yokken \"kesindir\" yazmak da "
                            "aynı ölçüde hatalıdır."
                        ),
                        puan=12,
                    ),
                ],
                kapanis="Rapor tamamlandı ve Kronograf'ın koluna asıldı.",
                odul={"itibar": 6},
            ),
        ],
    )


def _rapor_secimi(rastgele: random.Random):
    """Rapora girecek cümleleri seçtiren adım: nesnel olanlar kalır."""
    uygun = [
        "Bölgede demir alete rastlanmamış, silahların tunç olduğu görülmüştür.",
        "Bitki örtüsü bozkırdır; zeytin ve turunçgil tarımı görülmemiştir.",
        "Ambar mevcudu tablete kaydedilmiş, paylar oran esasına göre hesaplanmıştır.",
    ]
    uygunsuz = [
        "Surlar öyle büyüktü ki insanın içi ürperiyordu.",
        "Galiba bir sürü asker vardı, tam sayamadım.",
        "Kâtip bana çok sempatik geldi, iyi bir adama benziyordu.",
    ]
    secenekler, dogru_indeksler = coklu_siklar(rastgele, uygun, uygunsuz)
    return coklu_adimi(
        soru="Rapora hangi cümleler girmelidir? (numaralarını yaz)",
        secenekler=secenekler,
        dogru_indeksler=dogru_indeksler,
        aciklama=(
            "Rapora giren cümleler ne görüldüğünü ölçülebilir biçimde bildirir "
            "ve dayanağını taşır. Elenenler ise doğrulanamayan ifadelerdir: "
            "\"içi ürperiyordu\" bir duygu, \"galiba bir sürü\" bir belirsizlik, "
            "\"sempatik geldi\" bir kişisel değerlendirmedir. Üçü de okuyana "
            "olay hakkında bilgi vermez."
        ),
        ipuclari=[
            "Her cümleyi sına: bunu okuyan biri olayı değerlendirebilir mi?",
            "Ölçülemeyen, duyguya dayanan ifadeleri ele.",
        ],
        puan=20,
        cozum=(
            "Her cümleyi iki soruyla sına:\n"
            "  1) Ölçülebilir/doğrulanabilir bir bilgi veriyor mu?\n"
            "  2) Yazanın kişisel duygusundan bağımsız mı?\n\n"
            "İkisine de EVET diyen cümle rapora girer. Duygu bildiren "
            "(\"ürperiyordu\"), belirsiz (\"galiba bir sürü\") ve kişisel "
            "değerlendirme içeren (\"sempatik geldi\") cümleler elenir."
        ),
    )


# ==========================================================================
# SEFER 2 - SANAYİ ÇAĞI
# ==========================================================================

@sefer(kod="sanayi-cagi", kademeler=(8, 13))
def sanayi_cagi_seferi(rastgele: random.Random, kademe: int) -> Sefer:
    """19. yüzyıl, kömür havzası. Tarih + coğrafya + fizik + rapor."""
    hiz = rastgele.choice([30, 40, 45, 60])          # km/sa
    sure = rastgele.choice([2, 3, 4])                 # saat
    mesafe = hiz * sure
    yuk = rastgele.choice([200, 300, 400])            # ton

    return Sefer(
        kod="sanayi-cagi",
        baslik="Kömür Havzası",
        donem="19. yüzyıl - Sanayi Çağı",
        kademe=kademe,
        giris=(
            "Kronograf'ın kolu ikinci kez çevrildiğinde kendini duman kokan "
            "bir istasyonda buluyorsun.\n\n"
            "Raylar üzerinde buhar püskürten bir makine duruyor, uzakta "
            "bacalar var, tel direkleri boyunca bir hat uzanıyor. İşçiler "
            "duvardaki büyük saate bakarak giriyor çıkıyor.\n\n"
            "Kronograf yine aynı şartı koyuyor: DÖNÜŞ İÇİN RAPOR GEREKLİ."
        ),
        baglantilar=[
            "Çağı buldun. Peki burası neresi? Rapora yer de yazılacak.",
            "Yerini de buldun. İstasyon şefi elindeki çizelgeyi uzatıyor: "
            "bir hesap eksik kalmış.",
            "Hesap tamam. Sıra raporda.",
        ],
        kapanis=(
            "Raporu astığın anda istasyon siliniyor. Komutan raporu okuyup "
            "\"iki ayrı çağdan iki rapor getirdin ve ikisi de aynı düzende\" "
            "diyor. \"Demek ki iş çağı tanımak değil, bakmayı bilmekmiş.\""
        ),
        odul={"itibar": 12, "enerji": 8, "cevher": 5},
        bolumler=[
            _bolum(
                kod="sefer-sanayi-tarih", ders="tarih", baslik="Ne Zamandayız",
                kademe=kademe, konu="donem_esikleri",
                kazanim="Sanayi Devrimi'nin ayırt edici teknolojileri ve toplumsal sonuçları.",
                brifing=(
                    "İstasyonda durmuş etrafına bakıyorsun. Rapora yazılacak "
                    "ilk şey yine tarih; ve yine kimse sana yılı söylemeyecek.\n\n"
                    "Ama burada teknoloji her yerde ve her biri bir tarih taşıyor."
                ),
                kanitlar=[
                    Kanit("Raylardaki makine",
                          "Buhar püskürterek vagonları çekiyor. Ne at var ne "
                          "yelken.", bedel=2, kritik=True),
                    Kanit("Tel hattı",
                          "Direkler boyunca uzanan teller. Şehirler arasında "
                          "işaret gönderiliyor - telgraf.", bedel=2, kritik=True),
                    Kanit("Fabrika duvarındaki saat",
                          "İşçiler güneşe göre değil bu saate göre giriyor "
                          "çıkıyor. Vardiya diye bir düzen var.", bedel=1),
                    Kanit("Aradığın ama bulamadığın",
                          "Ne elektrik ampulü var ne otomobil ne uçak.",
                          bedel=2, kritik=True),
                ],
                adimlar=[
                    model_adimi(
                        soru="Bu çağı belirleyen asıl eşik hangisidir?",
                        dogru=("Buhar gücünün üretime ve ulaşıma girmesi; "
                               "üretim artık kas ve su gücüne bağlı değil."),
                        yanlislar=[
                            "Fabrika duvarına saat asılması.",
                            "Şehirlerin kalabalıklaşması.",
                            "Demir madenlerinin bulunması.",
                            "Yazının yaygınlaşması.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Saat ve kalabalıklaşma bu çağın SONUÇLARIDIR, sebebi "
                            "değil. Değişimi başlatan şey buhar makinesinin üretime "
                            "girmesidir: fabrika artık akarsu kenarına kurulmak "
                            "zorunda değildir, makinenin kurulabildiği her yere "
                            "kurulur. Vardiya düzeni de bunun ardından gelir."
                        ),
                        ipuclari=[
                            "Hangisi diğerlerine sebep olmuş olabilir?",
                            "Bu makineler olmasaydı vardiya düzeni doğar mıydı?",
                        ],
                        puan=18,
                        cozum=(
                            "1) Buharlı lokomotif ve telgraf var -> 19. yüzyıl.\n"
                            "2) Elektrik ampulü, otomobil, uçak yok -> yüzyılın "
                            "sonundan önce.\n"
                            "3) Bu teknolojilerin ortak kaynağı buhar gücüdür; "
                            "Sanayi Devrimi'nin tanımlayıcı eşiği budur.\n"
                            "4) Fabrika saati ve vardiya, buhar gücünün doğurduğu "
                            "yeni çalışma düzenidir - sebep değil sonuçtur."
                        ),
                    ),
                    secim_adimi(
                        soru="Rapora hangi çağı yazacaksın?",
                        dogru="Sanayi Çağı (19. yüzyıl)",
                        yanlislar=[
                            "Tunç Çağı (MÖ 1300 dolayları)",
                            "Orta Çağ (MS 1000 dolayları)",
                            "Bilgi Çağı (20. yüzyıl sonu)",
                            "Roma dönemi (MS 100 dolayları)",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Buharlı lokomotif ve telgraf 19. yüzyıl teknolojileridir. "
                            "Elektrikli aydınlatma ve otomobilin bulunmaması ise üst "
                            "sınırı yüzyılın sonundan önceye çeker."
                        ),
                        ipuclari=["Var olan ve olmayan teknolojileri birlikte düşün."],
                        puan=16,
                    ),
                    yorum_adimi(
                        soru="Fabrika saatinin işçi düzenini belirlemesi neyi gösterir?",
                        dogru=("Üretim biçiminin gündelik hayatı da değiştirdiğini; "
                               "zaman artık güneşe göre değil makineye göre ölçülüyor."),
                        yanlislar=[
                            "Saatin o dönemde yeni icat edildiğini.",
                            "İşçilerin güneşi göremediğini.",
                            "Fabrikanın gece çalışmadığını.",
                            "Zamanın önemsiz hâle geldiğini.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Tarımsal toplumda gün ışığa göre bölünürdü. Makine "
                            "durmadan çalıştığı için insan da saate göre bölündü. "
                            "Bir teknolojinin asıl etkisi, ürettiği maldan çok "
                            "kurduğu yaşam düzeninde görülür."
                        ),
                        puan=12,
                    ),
                ],
                kapanis="Rapor taslağına çağ yazıldı.",
                odul={"itibar": 4},
            ),

            _bolum(
                kod="sefer-sanayi-cografya", ders="cografya", baslik="Neredeyiz",
                kademe=kademe, konu="turkiye_bolgeleri",
                kazanim="Türkiye'de yer altı kaynaklarının dağılışı ve sanayiye etkisi.",
                brifing=(
                    "İstasyonun arkasındaki tepeye çıkıyorsun. Aşağıda deniz "
                    "var, ardında hemen yükselen ormanlık dağlar.\n\n"
                    "Rapora yer yazılacak. Buranın hangi bölge olduğunu "
                    "çıkarman gerekiyor."
                ),
                kanitlar=[
                    Kanit("Ocaktan çıkan",
                          "Vagonlara doldurulan siyah, parlak, sert bir kaya: "
                          "taş kömürü. Ocaklar doğrudan kıyıya yakın.",
                          bedel=2, kritik=True),
                    Kanit("Arazi",
                          "Deniz kıyısından hemen sonra dik yamaçlar başlıyor; "
                          "dağlar kıyıya paralel uzanıyor.", bedel=2, kritik=True),
                    Kanit("Bitki örtüsü",
                          "Yamaçlar gür ormanla kaplı. Yağmur sık; halk yazın "
                          "da yağmur bekliyor.", bedel=2, kritik=True),
                    Kanit("Tarla ürünü",
                          "Kıyıda mısır ekili, bahçelerde fındık ağaçları var.",
                          bedel=1, kritik=True),
                ],
                adimlar=[
                    model_adimi(
                        soru="Bölgeyi bulmak için hangi iz en belirleyici?",
                        dogru=("Taş kömürü ocağının kıyıda bulunması; bu kaynak "
                               "Türkiye'de tek bir havzada çıkarılır."),
                        yanlislar=[
                            "Ormanın gür olması.",
                            "Denizin varlığı.",
                            "İstasyonun büyüklüğü.",
                            "Vagonların sayısı.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Orman ve deniz birçok bölgede bulunur; ayırt edici "
                            "değildir. Ama taş kömürü Türkiye'de yalnızca Zonguldak "
                            "havzasında çıkarılır. Coğrafyada en değerli ipucu, "
                            "en az yerde bulunan izdir."
                        ),
                        ipuclari=[
                            "Hangi ipucu en az sayıda yerde bulunur?",
                            "Fındık ve bol yağış hangi bölgeyi işaret ediyor?",
                        ],
                        puan=18,
                        cozum=(
                            "1) Bol yağış + gür orman + fındık + mısır -> KARADENİZ.\n"
                            "2) Dağların kıyıya paralel uzanması -> Karadeniz "
                            "(ve Akdeniz) kıyı yapısı.\n"
                            "3) Taş kömürü ocakları -> Zonguldak havzası, yani "
                            "BATI KARADENİZ.\n"
                            "Kömür tek başına bölgeyi kilitliyor; diğer izler onu "
                            "doğruluyor."
                        ),
                    ),
                    secim_adimi(
                        soru="Rapora hangi bölgeyi yazacaksın?",
                        dogru="Karadeniz (Zonguldak taş kömürü havzası)",
                        yanlislar=[
                            "Marmara (Trakya kıyıları)",
                            "Ege (İzmir çevresi)",
                            "Akdeniz (Toroslar eteği)",
                            "İç Anadolu (Kızılırmak çevresi)",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Bol yağış, gür orman, fındık ve mısır tarımı Karadeniz'i "
                            "gösterir; taş kömürü ise Zonguldak havzasını işaret eder. "
                            "İç Anadolu bozkırdır ve denizi yoktur; Ege ile Akdeniz'de "
                            "yaz kuraktır."
                        ),
                        ipuclari=["Fındık hangi bölgenin ürünüdür?"],
                        puan=16,
                    ),
                    yorum_adimi(
                        soru="Sanayinin buraya kurulmasının sebebi nedir?",
                        dogru=("Kömür burada çıkıyor; ağır ve hacimli kaynağı "
                               "taşımak yerine fabrikayı kaynağa yaklaştırmak "
                               "daha ucuzdur."),
                        yanlislar=[
                            "Bölgenin nüfusu en kalabalık olduğu için.",
                            "İklimi fabrikalar için en uygun olduğu için.",
                            "Buradaki toprak tarıma elverişsiz olduğu için.",
                            "Devlet böyle karar verdiği için, coğrafi sebebi yoktur.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Sanayi yer seçiminde temel ilke şudur: taşıması pahalı "
                            "olan neyse, tesis ona yaklaşır. Kömür ağır ve çok "
                            "tüketilir; bu yüzden kömüre dayalı sanayi havzanın "
                            "yanına kurulur. Bu, bugün de geçerli bir kuraldır."
                        ),
                        puan=12,
                    ),
                ],
                kapanis="Rapor taslağına bölge yazıldı.",
                odul={"cevher": 5, "itibar": 3},
            ),

            _bolum(
                kod="sefer-sanayi-fen", ders="fen", baslik="Çizelgedeki Boşluk",
                kademe=kademe, konu="hareket",
                kazanim="Sabit hızlı hareket; yol-hız-zaman bağıntısı.",
                brifing=(
                    "İstasyon şefi elindeki çizelgeyi uzatıyor. Bir sütun boş "
                    "kalmış ve treni bekleyen limana haber verilemiyor.\n\n"
                    "Lokomotif {} ton kömürü limana taşıyacak. Hattın uzunluğu "
                    "yazılmamış; yalnızca trenin hızı ve yolculuk süresi "
                    "kayıtlı.\n\n"
                    "Limana \"kaç kilometre yol var\" diye bildirilecek."
                ).format(yuk),
                kanitlar=[
                    Kanit("Sefer çizelgesi",
                          "Ortalama hız: {} km/sa\nYolculuk süresi: {} saat\n"
                          "Hat uzunluğu: (boş)".format(hiz, sure),
                          bedel=1, kritik=True),
                    Kanit("Makinist notu",
                          "\"Hat düz ve boş; tren baştan sona aynı hızla gider, "
                          "durmaz.\"", bedel=2, kritik=True),
                    Kanit("Yük kaydı", "Taşınan kömür: {} ton.".format(yuk), bedel=1),
                    Kanit("Fizik el kitabı",
                          "Sabit hızlı harekette: yol = hız × zaman.\n"
                          "Birimler uyumlu olmalıdır (km/sa ile saat -> km).",
                          bedel=2, kritik=True),
                ],
                adimlar=[
                    model_adimi(
                        soru="Hat uzunluğunu hangi bağıntı verir?",
                        dogru="yol = hız × zaman",
                        yanlislar=[
                            "yol = hız ÷ zaman",
                            "yol = zaman ÷ hız",
                            "yol = hız × zaman × yük",
                            "yol = hız + zaman",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Hız, birim zamanda alınan yoldur. Tren saatte {} km "
                            "gidiyorsa {} saatte bunun {} katını alır. Yükün "
                            "ağırlığı bu hesaba girmez: hız zaten verilmiş, yük "
                            "ancak hızı etkileseydi dolaylı olarak işe karışırdı."
                        ).format(hiz, sure, sure),
                        ipuclari=[
                            "Hızın birimi km/sa. Saatle çarpınca hangi birim kalır?",
                            "Yük bilgisi bu soruda gerekli mi?",
                        ],
                        puan=18,
                        cozum=(
                            "1) Sabit hız var, duruş yok -> yol = hız x zaman.\n"
                            "2) Birim denetimi: (km/sa) x sa = km. Uygun.\n"
                            "3) {} x {} = {} km\n"
                            "4) Yük ({} ton) bu hesaba girmez; hız zaten ölçülmüş "
                            "değerdir."
                        ).format(hiz, sure, mesafe, yuk),
                    ),
                    sayi_adimi(
                        soru="Hat kaç kilometre?",
                        cevap=mesafe, birim="km",
                        aciklama="{} km/sa × {} saat = {} km.".format(hiz, sure, mesafe),
                        ipuclari=["Hızı süreyle çarp."],
                        puan=14,
                    ),
                    yorum_adimi(
                        soru="Yük bilgisi neden hesaba girmedi?",
                        dogru=("Hız zaten ölçülmüş bir değer; yükün etkisi varsa "
                               "bile o hızın içinde."),
                        yanlislar=[
                            "Yük hiçbir zaman hareketi etkilemez.",
                            "Yük yalnızca kimyada kullanılır.",
                            "Yük verisi yanlış yazılmıştır.",
                            "Yük hesaba girmeliydi, çizelge eksik.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Sorularda her verinin kullanılması gerekmez; bazıları "
                            "gerçekçilik için, bazıları da tam olarak bu ayrımı "
                            "sınamak için konur. Burada hız ÖLÇÜLMÜŞ bir değerdir, "
                            "yani yükün etkisi zaten o sayının içindedir."
                        ),
                        puan=12,
                    ),
                ],
                kapanis="Çizelgedeki boşluk dolduruldu; limana telgraf çekildi.",
                odul={"enerji": 6, "itibar": 3},
            ),

            _bolum(
                kod="sefer-sanayi-turkce", ders="turkce", baslik="Üst Makama Rapor",
                kademe=kademe, konu="uslup",
                kazanim="Resmî yazıda nesnellik; gözlem ile yorumun ayrılması.",
                brifing=(
                    "Kronograf yine rapor bekliyor. Elinde çağ, bölge ve hesap "
                    "var.\n\n"
                    "Bu sefer bir zorluk daha var: gördüğün şeylerin bir kısmı "
                    "gözlem, bir kısmı ise senin yorumun. Raporda ikisinin "
                    "karışması, okuyanı yanıltır."
                ),
                kanitlar=[
                    Kanit("Elindeki bilgiler",
                          "Çağ: Sanayi Çağı (19. yüzyıl)\n"
                          "Bölge: Karadeniz, taş kömürü havzası\n"
                          "Hesap: hat uzunluğu {} km.".format(mesafe),
                          bedel=1, kritik=True),
                    Kanit("Yazışma kılavuzu",
                          "\"Gözlem: doğrudan görülen, ölçülen şey.\n"
                          "Yorum: gözlemden çıkarılan sonuç.\n"
                          "Raporda ikisi ayrı yazılır; yorumun dayanağı "
                          "belirtilir.\"", bedel=2, kritik=True),
                    Kanit("Komutanın notu",
                          "\"Yorum yapmanı yasaklamıyorum. Yorumunu gözlem gibi "
                          "yazmanı yasaklıyorum.\"", bedel=2, kritik=True),
                ],
                adimlar=[
                    model_adimi(
                        soru="Gözlem ile yorum arasındaki fark nedir?",
                        dogru=("Gözlem doğrudan görülen/ölçülendir; yorum ondan "
                               "çıkarılan sonuçtur."),
                        yanlislar=[
                            "Gözlem kısa, yorum uzun cümledir.",
                            "Gözlem kesin, yorum her zaman yanlıştır.",
                            "Gözlem sayısal, yorum sözeldir.",
                            "İkisi arasında anlamlı bir fark yoktur.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "\"Ocaklardan siyah, sert bir kaya çıkarılıyordu\" bir "
                            "gözlemdir. \"Burası taş kömürü havzasıdır\" bir yorumdur; "
                            "gözlemden çıkarılmıştır ve yanlış olabilir. Yorum yasak "
                            "değildir - dayanağıyla birlikte yazılması gerekir. "
                            "Sayısal olmak da gözlem yapmaz: \"yaklaşık 300 asker "
                            "vardı\" sayısaldır ama tahmindir."
                        ),
                        ipuclari=[
                            "Hangi cümleyi orada olan başka biri de aynen yazardı?",
                            "Hangi cümle bir çıkarım içeriyor?",
                        ],
                        puan=18,
                        cozum=(
                            "Ayırmak için tek soru yeter: \"Bunu gördüm mü, yoksa "
                            "gördüklerimden çıkardım mı?\"\n\n"
                            "GÖZLEM  : Ocaklardan siyah, sert bir kaya çıkarılıyordu.\n"
                            "YORUM   : Bu kaya taş kömürüdür.\n"
                            "GÖZLEM  : Çizelgede hız 40 km/sa, süre 3 saat yazıyordu.\n"
                            "YORUM   : Hat 120 km uzunluğundadır.\n\n"
                            "Raporda yorum, dayanağıyla birlikte yazılır: "
                            "\"...olduğu değerlendirilmiştir\" gibi."
                        ),
                    ),
                    _gozlem_yorum_adimi(rastgele, mesafe),
                    yorum_adimi(
                        soru="Yorumu \"değerlendirilmiştir\" diye yazmak neyi sağlar?",
                        dogru=("Okuyana bunun bir çıkarım olduğunu, gözlemin "
                               "kendisi olmadığını bildirir."),
                        yanlislar=[
                            "Cümleyi daha resmî ve saygılı yapar.",
                            "Raporu uzatarak daha ciddi gösterir.",
                            "Sorumluluğu okuyana yükler.",
                            "Hiçbir işe yaramaz, alışkanlıktır.",
                        ],
                        rastgele=rastgele,
                        aciklama=(
                            "Bu kalıp bir nezaket süsü değil, bilgi işaretidir: "
                            "\"buradan sonrası benim çıkarımım\" der. Okuyan kişi "
                            "gözlemi olduğu gibi alır, çıkarımı ise kendi "
                            "değerlendirmesine tabi tutar. Bilimsel ve resmî yazının "
                            "ortak alışkanlığı budur."
                        ),
                        puan=12,
                    ),
                ],
                kapanis="Rapor Kronograf'ın koluna asıldı.",
                odul={"itibar": 6},
            ),
        ],
    )


def _gozlem_yorum_adimi(rastgele: random.Random, mesafe: int):
    """Gözlem cümlelerini yorum cümlelerinden ayırma adımı."""
    gozlemler = [
        "Raylar üzerinde buhar püskürten bir makine vagonları çekiyordu.",
        "Çizelgede ortalama hız ve yolculuk süresi yazılıydı.",
        "Ocaklardan siyah, sert ve parlak bir kaya çıkarılıyordu.",
    ]
    yorumlar = [
        "Bölge, taş kömürü havzası olduğu için sanayileşmiştir.",
        "Hat uzunluğunun {} km olduğu hesaplanmıştır.".format(mesafe),
        "Dönemin Sanayi Çağı olduğu değerlendirilmiştir.",
    ]
    secenekler, dogru_indeksler = coklu_siklar(rastgele, gozlemler, yorumlar)
    return coklu_adimi(
        soru="Aşağıdakilerden hangileri GÖZLEMDİR? (numaralarını yaz)",
        secenekler=secenekler,
        dogru_indeksler=dogru_indeksler,
        aciklama=(
            "Gözlemler doğrudan görülen ya da okunan şeylerdir: makinenin "
            "vagon çekmesi, çizelgedeki sayılar, ocaktan çıkan kayanın "
            "görünüşü. Diğerleri ise bu gözlemlerden çıkarılmış YORUMLARDIR: "
            "kayanın taş kömürü olduğu, hattın uzunluğu ve çağın hangisi "
            "olduğu hesapla ya da akıl yürütmeyle bulunmuştur. Yorumlar "
            "rapora girer ama gözlem gibi değil, dayanağıyla birlikte."
        ),
        ipuclari=[
            "Orada olan başka biri hangi cümleleri aynen yazardı?",
            "Hangi cümleler bir hesap ya da çıkarım sonucu?",
        ],
        puan=20,
        cozum=(
            "Her cümleye sor: \"gördüm mü, çıkardım mı?\"\n\n"
            "Gördüm  -> gözlem: makinenin vagon çekmesi, çizelgedeki sayılar, "
            "kayanın rengi ve sertliği.\n"
            "Çıkardım -> yorum: kayanın taş kömürü olması, hattın {} km olması, "
            "çağın Sanayi Çağı olması.\n\n"
            "Not: yorumlar yanlış değildir; yalnızca gözlemden farklı bir "
            "güvenilirlik düzeyindedir."
        ).format(mesafe),
    )
