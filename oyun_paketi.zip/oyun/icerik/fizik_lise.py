# -*- coding: utf-8 -*-
"""
Fizik: lise (9-12) içerik boşlukları -- ikinci dalga.

`fizik.py` her konu satırını en az bir görevle kapatıyor; bu modül aynı
konuların FARKLI kazanımlarını, yani haritadaki satırın ikinci yarısını
doldurur: basınç, görünen ağırlık, ip gerilmesi, iş ve açı, frenleme
mesafesi, tek referanslı enerji, vektör bileşkesi, birim çevirisi.

Çerçeve ve üslup `fizik.py` ile aynıdır: üssün kuvvet atölyesi, g = 10 m/s²,
yanlış şıklar gerçek yanılgılara dayanır ve her yanlışın bir teşhisi vardır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi, sy, yorum_adimi,
)


# ==========================================================================
# BASINÇ: SIVI BASINCI DERİNLİĞE BAĞLIDIR, KABIN HACMİNE DEĞİL
# (10. sınıf, "Katı, sıvı ve gaz basıncı"; yanılgı: "Sıvı basıncını kabın
# toplam hacmine bağlamak; kuvvetle basıncı karıştırmak.")
#
# DÜZENEK: iki su tankı, aynı derinlik, çok farklı hacim. Dip kapağındaki
# kuvvet isteniyor: F = P · A, P = ρ · g · h. Ekin (atmosfer) hesaba
# katılmaz; "yalnız suyun basıncı" kanıtta açıkça yazılır.
#
# YANILGILARIN SAYISAL KARŞILIĞI:
#   * cm² -> m² çevrilmez: F, 10 000 kat şişer.
#   * kPa -> Pa çevrilmez: F, 1000 kat küçülür.
# ==========================================================================

# (derinlik m, kapak alanı cm², büyük tank hacmi m³, küçük tank hacmi m³)
_TANK_KAPAGI = tuple(
    (h, alan, buyuk, kucuk)
    for h in (2, 3, 4, 5, 6)
    for alan in (200, 500, 1000)
    for buyuk, kucuk in ((60, 6), (80, 5), (45, 9))
)


@bulmaca(ders="fizik", konu="basinc", kademeler=(10, 13), agirlik=1.3)
def tank_kapagi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sıvı basıncı derinliğe bağlıdır; kapaktaki kuvvet F = P · A."""
    h, alan_cm2, v_buyuk, v_kucuk = rastgele.choice(_TANK_KAPAGI)
    alan_m2 = alan_cm2 / 10000.0
    basinc_pa = 1000 * 10 * h
    basinc_kpa = basinc_pa // 1000
    kuvvet = basinc_pa * alan_m2
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    buyuk_ad, kucuk_ad = rastgele.sample(["Kuzey", "Güney", "Doğu", "Batı"], 2)

    return Bulmaca(
        kod="fiz-tank-kapagi",
        ders="fizik",
        baslik="Tank Kapağı",
        kademe=kademe,
        konu="basinc",
        kazanim="Durgun sıvı basıncının derinliğe ve sıvı yoğunluğuna bağlı olduğunu, "
                "kabın hacmine ve biçimine bağlı olmadığını açıklama; basınçtan "
                "kuvvet hesaplama (F = P · A) ve birimleri çevirme.",
        dikkat=7,
        brifing=(
            "{} ve {} su tanklarının dip kapakları yenilenecek. {} not düştü: "
            "\"{} tankı daha geniş ve çok daha fazla su alıyor; kapağına binen "
            "basınç da kesin daha büyüktür.\"\n\n"
            "Kapak sipariş edilmeden önce kuvveti doğru hesaplamalıyız."
        ).format(buyuk_ad, kucuk_ad, kisi, buyuk_ad),
        kanitlar=[
            Kanit("Seviye göstergeleri",
                  "Her iki tankta da suyun derinliği {} m.".format(h),
                  bedel=1, kritik=True),
            Kanit("Tank hacimleri",
                  "{} tankında {} metreküp, {} tankında {} metreküp su var.".format(
                      buyuk_ad, v_buyuk, kucuk_ad, v_kucuk),
                  bedel=1),
            Kanit("Kapak şartnamesi",
                  "Her dip kapağının alanı {} santimetrekare. Yalnız suyun "
                  "basıncı hesaplanacak; atmosfer basıncı dışarıda bırakıldı. "
                  "Suyun yoğunluğu 1000 kg/m³, g 10 m/s² alınacak.".format(alan_cm2),
                  bedel=1, kritik=True),
            Kanit("Bağıntı notu",
                  "Sıvı basıncı; yoğunluk, g ve derinliğin çarpımıdır. Kuvvet; "
                  "basınç ile alanın çarpımıdır. Bir metrekare, on bin "
                  "santimetrekaredir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İki tankın dip basıncı için hangi ifade doğrudur?",
                dogru=("Aynıdır, çünkü sıvı basıncı derinliğe ve yoğunluğa bağlıdır, "
                       "hacme değil"),
                yanlislar={
                    ("{} tankında büyüktür, çünkü kapağın üstünde toplam su "
                     "miktarı daha fazladır").format(buyuk_ad):
                        "Basıncı kabın toplam hacmine bağladın. Yan yana "
                        "duran su, dip kapağına binen basıncı artırmaz; "
                        "önemli olan kapağın üstündeki su sütununun "
                        "yüksekliği.",
                    ("{} tankında büyüktür, çünkü dar kapta su dibe doğru "
                     "daha çok sıkışır").format(kucuk_ad):
                        "Dar kapta suyun daha çok sıkıştığı söylenemez; su "
                        "pratikte sıkışmaz. Basınç yine yalnız derinlikle "
                        "belirlenir.",
                    ("Aynıdır, çünkü iki dip kapağı da aynı büyüklükte ve aynı "
                     "kalınlıkta yapılmıştır"):
                        "Sonuç doğru ama gerekçe yanlış: kapak alanı basıncı "
                        "değil, kapağa binen kuvveti belirler. Basıncın "
                        "aynı çıkması derinliğin aynı olmasından gelir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Durgun sıvıda bir noktadaki basınç P = ρ · g · h ile "
                    "bulunur; h, o noktanın üstündeki sıvı sütununun "
                    "yüksekliğidir. Kabın genişliği ya da toplam hacmi bu "
                    "bağıntıda yok. Alan ise basıncı değil, aynı basınçtan "
                    "doğan KUVVETİ değiştirir."
                ),
                ipuclari=[
                    "İçine daldığın havuzda kulağını ağrıtan şey havuzun "
                    "genişliği mi, derinliği mi?",
                    "Kapağın hemen üstünde duran su sütununu düşün: yüksekliği ne?",
                ],
                cozum=(
                    "P = ρ · g · h\n"
                    "İki tankta ρ, g ve h aynı -> P aynı.\n"
                    "Kuvvet için ayrıca alan gerekir: F = P · A."
                ),
            ),
            sayi_adimi(
                soru="Dip kapağına binen basınç kaç kPa?",
                cevap=basinc_kpa,
                birim="kPa",
                aciklama=("P = 1000 × 10 × {} = {} Pa = {} kPa.").format(
                    h, basinc_pa, basinc_kpa),
                yaygin_yanlislar={
                    basinc_pa:
                        "Pa cinsinden hesapladın; soru kPa istiyor. 1 kPa = "
                        "1000 Pa.",
                    10 * v_buyuk:
                        "Derinlik yerine hacmi kullandın. Bağıntıdaki h bir "
                        "yükseklik, hacim değil.",
                },
                ipuclari=["Önce Pa bul, sonra kPa'ya çevir."],
                puan=12,
            ),
            sayi_adimi(
                soru="Bir dip kapağına binen kuvvet kaç N?",
                cevap=kuvvet,
                birim="N",
                aciklama=("Alan: {} cm² = {} m². F = {} Pa × {} m² = {} N.").format(
                    alan_cm2, sy(alan_m2), basinc_pa, sy(alan_m2), sy(kuvvet)),
                yaygin_yanlislar={
                    basinc_pa * alan_cm2:
                        "Alanı cm² olarak çarptın. Pa ile çarpılacak alan "
                        "m² olmalı: 1 m² = 10 000 cm².",
                    basinc_kpa * alan_m2:
                        "kPa değerini Pa'ya çevirmeden çarptın; Newton için "
                        "basınç Pa cinsinden olmalı.",
                },
                ipuclari=["Alanı m²'ye çevirmeden çarpma yapma."],
                puan=14,
                tolerans=0.01,
            ),
            yorum_adimi(
                soru="Rapordaki \"geniş tankın kapağına binen basınç kesin daha büyük\" cümlesi için ne denir?",
                dogru=("Yanlış: basınç iki kapakta da {} kPa; alanlar eşit olduğundan "
                       "kuvvet de eşit, aynı kapak yeter").format(basinc_kpa),
                yanlislar={
                    ("Doğru: geniş tankta çok daha fazla su bulunduğundan kapağı "
                     "da daha çok zorlar"):
                        "Toplam su miktarı kapağı belirlemiyor. Aynı "
                        "derinlikteki iki kapağın üstünde aynı yükseklikte "
                        "su sütunu var.",
                    ("Yanlış: asıl dar tankın basıncı daha büyük, çünkü su yan "
                     "duvarlara yayılamadığı için dibe biner"):
                        "Yan duvarlar basıncı artırmaz; dip basıncı yine "
                        "yalnız derinlik ve yoğunluğa bağlı.",
                    ("Doğru: kapağı zorlayan şey basınç değil, tankın toplam "
                     "ağırlığı olduğundan hacim belirleyicidir"):
                        "Dip kapağına etki eden kuvvet, kapağa dayanan su "
                        "sütunundan gelir (F = P · A); tankın toplam "
                        "ağırlığı kapak şartnamesini belirlemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki tank aynı derinlikte ve kapakları eşit alanlı; bu "
                    "yüzden basınç da kuvvet de aynı. Tek bir tip kapak iki "
                    "tanka da sipariş edilebilir. Hacim yalnız tankın "
                    "taşıyacağı toplam suyu belirler."
                ),
                puan=12,
            ),
        ],
        kapanis=("Not düzeltildi: iki tankın dip basıncı {} kPa, her kapağa binen "
                 "kuvvet {} N. Tek tip kapak siparişi verildi."
                 ).format(basinc_kpa, sy(kuvvet)),
        odul={"itibar": 5, "enerji": 2, "erzak": 1},
    )


# ==========================================================================
# NEWTON: GÖRÜNEN AĞIRLIK -- OKUMA İVMEYE BAĞLIDIR, HIZA DEĞİL
# (9. sınıf, "Kuvvet ve Newton yasaları"; yanılgı: "Hareket sürüyorsa net
# kuvvet vardır sanmak" ve hız yönüyle ivme yönünü karıştırmak.)
#
# DÜZENEK: yük asansörünün platformunda bir kasa, altında yük hücresi.
# Hücre, platformun kasaya uyguladığı dik kuvveti gösterir:
#   N - m·g = m·a (a yukarı pozitif)  ->  N = m · (g + a)
# DÖRT durum, hız yönü ile ivme yönünü ayırır:
#   yukarı+hızlanma (a yukarı), yukarı+yavaşlama (a aşağı),
#   aşağı+hızlanma (a aşağı), aşağı+yavaşlama (a yukarı).
#
# YANILGILARIN SAYISAL KARŞILIĞI:
#   * ivmeyi yok saymak: okuma m·g çıkar.
#   * işareti hız yönüne göre koymak: m·(g - a) yerine m·(g + a) (ya da tersi).
#   * m·a'yı okuma sanmak: ağırlık hesaba hiç girmez.
# ==========================================================================

_ASANSOR_DURUMLARI = (
    {"hareket": "yukarı çıkıyor ve hızlanıyor", "isaret": 1, "yon": "yukarı"},
    {"hareket": "yukarı çıkıyor ama yavaşlayarak duruyor", "isaret": -1, "yon": "aşağı"},
    {"hareket": "aşağı iniyor ve hızlanıyor", "isaret": -1, "yon": "aşağı"},
    {"hareket": "aşağı iniyor ama yavaşlayarak duruyor", "isaret": 1, "yon": "yukarı"},
)

_ASANSOR = tuple(
    (kutle, ivme, durum)
    for kutle in (40, 50, 60, 80)
    for ivme in (1, 2, 3)
    for durum in range(len(_ASANSOR_DURUMLARI))
)


@bulmaca(ders="fizik", konu="kuvvet_newton", kademeler=(9, 13), agirlik=1.3)
def yuk_asansoru(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yük hücresinin okuması ivme yönüne göre ağırlıktan sapar: N = m (g + a)."""
    kutle, ivme, durum_no = rastgele.choice(_ASANSOR)
    durum = _ASANSOR_DURUMLARI[durum_no]
    agirlik = kutle * 10
    okuma = kutle * (10 + durum["isaret"] * ivme)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    buyuk = okuma > agirlik

    return Bulmaca(
        kod="fiz-yuk-asansoru",
        ders="fizik",
        baslik="Yük Asansörü",
        kademe=kademe,
        konu="kuvvet_newton",
        kazanim="Net kuvvet ile ivme arasındaki ilişkiyi (F = m · a) kullanarak "
                "ivmeli hareket eden platformdaki cismin görünen ağırlığını "
                "bulma; hız yönü ile ivme yönünü ayırt etme.",
        dikkat=7,
        brifing=(
            "Kuzey deposunun yük asansöründe bir kasa duruyor; platformun "
            "altındaki hücre kasanın ne kadar bastığını ölçüyor.\n\n"
            "{} not düştü: \"Kasa platformla birlikte {}. Kasa hareket "
            "hâlinde olduğundan hücre değeri değişmez, yine ağırlığı gösterir.\" "
            "Hücrenin ne göstereceğini hesaplamadan raporu imzalayamayız."
        ).format(kisi, durum["hareket"]),
        kanitlar=[
            Kanit("Kasa etiketi", "Kütle {} kg.".format(kutle),
                  bedel=1, kritik=True),
            Kanit("Platform kaydı",
                  "Platform {}. İvmesi {} m/s² büyüklüğünde ve yönü {}.".format(
                      durum["hareket"], ivme, durum["yon"]),
                  bedel=1, kritik=True),
            Kanit("Hücre notu",
                  "Hücre, platformun kasaya uyguladığı dik kuvveti newton "
                  "olarak gösterir. g 10 m/s² alınacak.",
                  bedel=1),
            Kanit("Kasa üzerindeki not",
                  "Kasa platformdan kaymıyor; kasa ve platform aynı ivmeyle "
                  "hareket ediyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Hücrenin okuması nasıl bulunur?",
                dogru=("Net kuvvet kütle çarpı ivmedir, bu yüzden okuma ağırlıktan "
                       "ivme yönünde sapar"),
                yanlislar={
                    ("Okuma ağırlığa eşittir, çünkü kütle hareket sırasında "
                     "değişmediğinden kasanın ağırlığı da değişmez"):
                        "Kütle gerçekten değişmez ama okunan değer ağırlık "
                        "değil, platformun kasaya uyguladığı kuvvet. Kasa "
                        "ivmeleniyorsa bu kuvvet ağırlıktan farklı olmak zorunda.",
                    ("Okuma hız yönüne bağlıdır, çünkü kasa yukarı çıkarken "
                     "kuvvet de hareket yönünde ağırlıktan büyük olur"):
                        "Hız yönü ile ivme yönünü karıştırdın. Net kuvvet "
                        "ivmenin yönündedir; yukarı çıkan ama yavaşlayan "
                        "kasanın ivmesi aşağı yönlüdür.",
                    ("Okuma yalnız kütle çarpı ivmedir, çünkü ağırlık hareket "
                     "başlayınca platforma binmez"):
                        "Ağırlık hâlâ platforma biniyor. Platformun kuvveti "
                        "hem ağırlığı dengelemeli hem de gerekirse ivmeyi "
                        "sağlamalı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kasaya iki kuvvet etki eder: aşağı ağırlık (m · g) ve "
                    "yukarı platformun kuvveti (N). Bileşke kuvvet m · a'dır; "
                    "yukarıyı artı alırsak N − m · g = m · a ve N = m · (g + a). "
                    "İvme yukarıysa okuma ağırlıktan büyük, aşağıysa küçüktür; "
                    "hızın yönü bu işaret için önemli değildir."
                ),
                ipuclari=[
                    "Asansör aniden kalkarken ayaklarının yere biraz daha çok "
                    "bastığını, inerken hafiflediğini hissedersin.",
                    "Önce ivmenin yönünü bul: hızlanma mı, yavaşlama mı, hız hangi yönde?",
                ],
                cozum=(
                    "Aşağı: m · g. Yukarı: N.\n"
                    "Yukarıyı artı alalım: N − m · g = m · a\n"
                    "N = m · (g + a); ivme aşağıysa a eksi yazılır."
                ),
            ),
            sayi_adimi(
                soru="Kasa durgun olsaydı hücre kaç N gösterirdi?",
                cevap=agirlik,
                birim="N",
                aciklama="Ağırlık = {} kg × 10 m/s² = {} N.".format(kutle, agirlik),
                yaygin_yanlislar={
                    kutle: "Kütleyi (kg) kuvvet (N) yerine yazdın. Ağırlık "
                           "kütle çarpı g'dir.",
                },
                ipuclari=["Durgun kasada platform yalnız ağırlığı dengeler."],
                puan=8,
            ),
            sayi_adimi(
                soru="Platform {} iken hücre kaç N gösterir?".format(durum["hareket"]),
                cevap=okuma,
                birim="N",
                aciklama=("İvme {}; N = {} × (10 {} {}) = {} N.").format(
                    durum["yon"], kutle, "+" if durum["isaret"] > 0 else "−",
                    ivme, okuma),
                yaygin_yanlislar={
                    agirlik:
                        "Hareketi hesaba katmadın; ivmesiz kasa gibi hesapladın. "
                        "İvme sıfır değil, kasanın net kuvveti var.",
                    kutle * (10 - durum["isaret"] * ivme):
                        "İvmeyi ters yöne koydun. Hızın değil, ivmenin yönüne "
                        "bak: artı ya da eksi oradan gelir.",
                    kutle * ivme:
                        "Yalnız m · a'yı aldın; ağırlık da platforma biniyor, "
                        "onu da hesaba kat.",
                },
                ipuclari=["İvmenin yönü yukarıysa okuma ağırlıktan büyük çıkar."],
                puan=14,
            ),
            yorum_adimi(
                soru="Bu okuma, kasanın hareketi hakkında ne söyler?",
                dogru=("Net kuvvet {} yönlü, yani ivme {} yönlü; hız ise iki "
                       "yönden biri olabilir").format(durum["yon"], durum["yon"]),
                yanlislar={
                    ("Okuma {} olduğundan kasa kesinlikle {} hareket "
                     "etmektedir, çünkü okuma hızın yönünü verir").format(
                         "ağırlıktan büyük" if buyuk else "ağırlıktan küçük",
                         "yukarı" if buyuk else "aşağı"):
                        "Okuma ivmenin yönünü gösterir, hızın yönünü değil. "
                        "Hem yukarı çıkarken hem aşağı inerken aynı okumayı "
                        "alabilirsin.",
                    ("Kasa {} hâle gelmiştir, çünkü kütlesi hareket "
                     "sırasında değişmiştir").format(
                         "daha hafif" if not buyuk else "daha ağır"):
                        "Kasanın kütlesi değişmedi; değişen, platformun "
                        "kasaya uyguladığı kuvvet. Bu farka görünen ağırlık "
                        "denir.",
                    ("Net kuvvet sıfırdır, çünkü kasa platformla birlikte "
                     "hareket edip ondan kaymıyor"):
                        "Kasa platformdan kaymıyor ama ivmeleniyor; ivmesi "
                        "olan cismin net kuvveti sıfır olamaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Okuma ağırlıktan {} olduğuna göre net kuvvet {} yönlüdür. "
                    "Kasa o sırada yukarı da aşağı da gidiyor olabilir; "
                    "hızlanma ve yavaşlama ikisinde de bu ivme yönünü "
                    "verebilir. Hızın yönü okumadan çıkmaz."
                ).format("büyük" if buyuk else "küçük", durum["yon"]),
                puan=12,
            ),
        ],
        kapanis=("Rapor yeniden yazıldı: kasa {} iken hücre {} N gösterir; "
                 "ağırlık {} N. {} N'luk fark ivmeden geliyor; kasanın "
                 "kütlesi değişmedi."
                 ).format(durum["hareket"], okuma, agirlik, abs(okuma - agirlik)),
        odul={"itibar": 5, "enerji": 2, "erzak": 1},
    )
