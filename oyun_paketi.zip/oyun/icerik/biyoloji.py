# -*- coding: utf-8 -*-
"""
Biyoloji görevleri (lise, 9-13).

Çerçeve: üssün CANLILAR BÖLMESİ. Numune tüpleri, soğutma dolapları, yarım
doldurulmuş saklama fişleri. Buradaki sorular canlının kendisinden çok, onu
ayakta tutan koşullarla ilgilidir: hücre neyi kaldırır, neyi kaldıramaz.

Fen Bilimleri (ortaokul) kaldırılmadı; bu modül onun üstüne biner.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi, secim_adimi,
    sirala_adimi, sy,
    yorum_adimi,
)


# ==========================================================================
# HÜCRE VE SICAKLIK - donma, buz kristali, kontrollü soğutma
# ==========================================================================

@bulmaca(ders="biyoloji", konu="hucre_ve_sicaklik", kademeler=(9, 13),
         agirlik=1.2)
def numune_dondurma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Donarken genleşen su, buz kristali ve kontrollü soğutma hızı."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    su_ml = rastgele.choice([2.0, 2.5, 4.0, 5.0])
    donmus_ml = round(su_ml * 1.09, 3)

    baslangic = rastgele.choice([18, 20, 22])        # °C
    hedef = rastgele.choice([-70, -80, -90])         # °C
    hiz = rastgele.choice([1, 2])                    # °C/dakika
    fark = baslangic - hedef                         # her zaman çift
    sure = fark // hiz                               # dakika

    yanlis_sure = {
        abs(hedef) // hiz:
            "Yalnızca sıfırın altındaki yolu saydın. Numune sıfırın "
            "ÜSTÜNDEN başlıyor; iki parçayı toplaman gerekiyor.",
    }
    if hiz != 1:
        yanlis_sure[fark] = ("Sıcaklık farkını bulup orada durdun. Bu bir "
                             "sıcaklık, süre değil; farkı dakikadaki soğuma "
                             "hızına bölmelisin.")

    return Bulmaca(
        kod="biyoloji-numune-dondurma",
        ders="biyoloji",
        baslik="Numune Dolabındaki Çatlak",
        kademe=kademe,
        konu="hucre_ve_sicaklik",
        kazanim="Hücre zarının bütünlüğü; suyun donarken genleşmesi ve "
                "kontrollü soğutmanın canlılığı korumadaki rolü.",
        dikkat=6,
        brifing=(
            "Sabah dolabı açan {} kötü bir manzarayla karşılaştı: dün gece "
            "acele dondurulan doku numunelerinin tüpleri çatlamış, "
            "çözüldüklerinde de hiçbiri canlı çıkmamış.\n\n"
            "Oysa aynı türden, protokole göre hazırlanmış karşılaştırma numuneleri iyi "
            "durumda. Sıcaklık kaydında da bir arıza görünmüyor; dolap "
            "istenen sıcaklığa inmiş.\n\n"
            "Yeni sevkiyat bu akşam geliyor. Dün gece neyin yanlış gittiğini "
            "bulmadan aynı işlemi tekrarlamak, elimizdeki son numuneleri de "
            "harcamak olur."
        ).format(kisi),
        kanitlar=[
            Kanit("Numune fişi",
                  "Hacim modeli için tüp başına saf su eşdeğeri: {} mL\nDolaba konulduğu sıcaklık: "
                  "{} °C".format(sy(su_ml), baslangic),
                  bedel=1, kritik=True),
            Kanit("Saklama protokolü",
                  "Bu kurgusal örnekte kontrollü soğutmanın son sıcaklığı: {} °C\n"
                  "Kontrollü soğutma hızı: dakikada {} °C\n"
                  "\"Bu hücre türüne uygun koruyucu ortam ve tüp kullanılır. Numune bu örnekte hedefe belirtilen hızla indirilmeden dolaba "
                  "bırakılmaz.\"".format(hedef, hiz),
                  bedel=2, kritik=True),
            Kanit("Biyoloji el kitabı",
                  "\"Su donarken hacmi yaklaşık %9 ARTAR; buz sudan daha az "
                  "yoğundur. Hücre içinde oluşan buz kristalleri zarı "
                  "zedeleyebilir. Hücre türüne uygun kontrollü soğutmada hücrenin "
                  "suyu bir ölçüde dışarı çıkar; hücre içi buz oluşma riski azalır. Çok yavaş soğutma da zarar verebilir; hız tek başına canlılığı garanti etmez.\"", bedel=2, kritik=True),
            Kanit("Gece vardiya defteri",
                  "\"Sevkiyat geç geldi, numuneleri doğrudan dolaba koydum; "
                  "kontrollü soğutma cihazını beklemeye vaktimiz yoktu.\"",
                  bedel=1, kritik=True),
            Kanit("İnceleme sonucu", "Bu örnekte çözülme sonrası mikroskobik inceleme hücre zarı hasarı saptadı. Tüp çatlağı tek başına hücre ölümünün nedenini kanıtlamaz.", bedel=1, kritik=True),
            Kanit("Bakım kaydı",
                  "Dolabın kompresör filtresi geçen ay değiştirildi; sıcaklık "
                  "kaydında sapma yok.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu örnekteki zar hasarını el kitabındaki hangi mekanizma açıklayabilir?",
                dogru=("Hücre içindeki su donarken genleşir; oluşan buz "
                       "kristalleri zarı zedeleyebilir."),
                yanlislar={
                    "Soğuğun kendisi; düşük sıcaklık hücrenin proteinlerini "
                    "doğrudan öldürür.":
                        "Soğuğu tek başına suçladın. Aynı türden, protokole uygun "
                        "hazırlanmış karşılaştırma numuneleri sağlam; bu bulgu tek başına ölüm nedenini kanıtlamaz. Burada incelenen risk "
                        "donma sırasında hücre içi buz oluşmasıdır.",
                    "Hücre soğukta büzülüp çöker; su da her madde gibi "
                    "soğuyup donarken hacmi küçülür.":
                        "Suyun yönünü ters aldın. Su donarken küçülmez, "
                        "yaklaşık yüzde dokuz BÜYÜR - kışın patlayan su "
                        "borusu da bu yüzden patlar.",
                    "Hücre oksijensiz kaldığı için ölür; soğutma solunumu "
                    "durdurur, enerji biter.":
                        "Solunumu sebep saydın. Soğuk zaten metabolizmayı "
                        "yavaşlatarak numuneyi KORUYAN şey; tüplerin "
                        "çatlaması da solunumla açıklanamaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çatlayan tüpler hacim artışıyla uyumludur; tek başına hücre ölümünün nedenini kanıtlamaz. Hücre incelemesinde zar hasarı da görülmüş. Su, donarken genleşen ender maddelerden biridir. "
                    "Aynı genleşme hücrenin içinde de olur ve keskin kenarlı buz "
                    "kristalleri zarı zedeleyebilir. Zarı hasarlı hücre çözüldüğünde "
                    "içeriğini dışarı boşaltır; bu, gözlenen kaybı açıklayabilecek mekanizmalardan biridir."
                ),
                ipuclari=[
                    "Tüpler neden çatladı? İçeride büyüyen bir şey olmalı.",
                    "Aynı türden karşılaştırma numuneleri farklı hazırlanmış olabilir mi?",
                ],
                cozum=(
                    "1) Tüp çatlağı, genleşmeyle uyumludur ama tek başına neden kanıtı değildir.\n"
                    "2) Suyun donarken genleştiği el kitabında yazıyor.\n"
                    "3) Aynı genleşme hücre içinde de olur; kristaller zarı yırtar.\n"
                    "4) Hücre incelemesindeki zar hasarı ve el kitabı birlikte okunur. Uygun soğutma hızı ile koruyucu ortam, hücre içi buz hasarı riskini azaltır."
                ),
                puan=18,
            ),
            sayi_adimi(
                soru="Hacmi {} mL olan saf su eşdeğerinin tümüyle donarken %9 genleştiğini varsay. Son hacmi kaç mL "
                     "olur?".format(sy(su_ml)),
                cevap=donmus_ml,
                birim="mL",
                aciklama=(
                    "Donan su hacminin yaklaşık %9'unu kazanır: "
                    "{} mL × 1,09 = {} mL. Tüpün içinde bu kadar boşluk yoksa "
                    "kap hasarı riski doğar. Gerçek numune çözeltisinin genleşmesi bu basit modelle aynı olmak zorunda değildir."
                ).format(sy(su_ml), sy(donmus_ml)),
                yaygin_yanlislar={
                    su_ml: "Genleşmeyi hiç eklemedin; yazdığın sayı donmadan "
                           "önceki hacim. Sorulan, donduktan sonraki hacim.",
                    round(su_ml * 0.91, 3):
                        "Yüzde dokuzu ekleyeceğine çıkardın. Su donarken "
                        "büzülmez; hacmi büyür.",
                },
                ipuclari=[
                    "El kitabındaki genleşme oranını hacme uygula.",
                    "Hacmi 1,09 ile çarp.",
                ],
                tolerans=0.02,
                puan=12,
            ),
            sayi_adimi(
                soru=("Numune {} °C'den {} °C'ye, dakikada {} °C hızla "
                      "indirilecek. Bu kaç dakika sürer?").format(
                          baslangic, hedef, hiz),
                cevap=sure,
                birim="dakika",
                aciklama=(
                    "Önce toplam sıcaklık farkı: {} − ({}) = {} °C. Sonra bu "
                    "fark soğuma hızına bölünür: {} ÷ {} = {} dakika."
                ).format(baslangic, hedef, fark, fark, hiz, sure),
                yaygin_yanlislar=yanlis_sure,
                ipuclari=[
                    "Sıfırın üstündeki ve altındaki yolu ayrı ayrı düşün, sonra topla.",
                    "Toplam farkı dakikadaki soğuma hızına böl.",
                ],
                tolerans=0.5,
                puan=14,
            ),
            yorum_adimi(
                soru="Numuneler neden doğrudan dolaba konmak yerine kontrollü "
                     "ve yavaş soğutuluyor?",
                dogru=("Yavaş soğutmada su hücreden dışarı çıkabilir; "
                       "hücre içi buz hasarı azalır."),
                yanlislar={
                    "Yavaş soğutulan hücre soğuğa alışır ve dayanıklılık "
                    "kazanır; kışa alışan bir insan gibi.":
                        "Alışma diye bir süreç kurdun; hücrede öyle bir "
                        "öğrenme yok. Kazanılan şey dayanıklılık değil, "
                        "suyun dışarı çıkması için geçen zaman.",
                    "Hızlı soğutma dolabın kompresörünü zorlar; asıl sebep cihazı korumaktır.":
                        "Gerekçeyi cihaza bağladın. Protokol dolabı değil "
                        "hücreyi koruyor; bakım kaydında da bir arıza yok.",
                    "Fark etmez; hücrenin başına geleni yol değil, varılan "
                    "son sıcaklık belirler.":
                        "Yalnızca hedef sıcaklığa baktın. Eski numunelerle "
                        "yenileri aynı sıcaklıkta duruyor ama sonuçları farklı; "
                        "demek ki oraya NASIL gidildiği belirleyici.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Hücre suyunu içeride tutarak donarsa, o su hücrenin İÇİNDE "
                    "genleşir ve zarı yırtar. Yavaş soğutmada dışarıdaki sıvı önce "
                    "donmaya başlar; hücre suyunun bir kısmı dışarı geçer ve içeride "
                    "buz oluşma riski azalır; tamamen ortadan kalkacağı söylenemez. Gece vardiyasının "
                    "atladığı adım tam olarak buydu: hedefe varmak yetmiyor, o "
                    "hedefe hangi hızla gidildiği, koruyucu ortam ve hücre türü de canlılığı etkiliyor."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Kontrollü soğutma cihazı akşam sevkiyatı için hazırlandı, "
            "protokol de dolabın kapağına asıldı: \"Hedef sıcaklık kadar, "
            "oraya iniş hızı da bağlayıcıdır.\""
        ),
        odul={"erzak": 6, "itibar": 5},
    )


# ==========================================================================
# SINIRLAYICI FAKTÖR — darboğazın biyolojideki hâli (kademe 9-13)
# ==========================================================================
#
# YAPI NAKLİYEDEN GELİYOR. `nakliye.aktarma_noktasi` şunu öğretiyordu:
# zincirin hızını EN DAR HALKA belirler; tren ne kadar hızlı olursa olsun
# kamyonlar azsa iş uzar. Biyolojide aynı yapının adı SINIRLAYICI FAKTÖR
# ve müfredatta zaten var (fotosentez hızı).
#
# Bu, GOREVLER B34.9'daki ilkenin uygulaması: yeni kurgu icat etme, aynı
# yapının başka derste nerede yaşadığını bul. Öğrenci nakliyede öğrendiği
# düşünme biçimini burada yeniden tanıyor -- dersler birbirine bağlanıyor.
#
# AYIRT EDİCİ HATA: "en çok neyi artırırsam en çok fayda gelir" diye
# düşünmek. Cevap bol olanı daha da artırmak değil, EKSİK olanı
# tamamlamak. Bol olan bir faktörü artırmak hiçbir şey değiştirmez --
# öğrencilerin en sık kaçırdığı yer burası.

# (faktör adı, birim, bol sayılan değer aralığı, kıt sayılan aralık)
FOTOSENTEZ_FAKTORLERI = [
    ("ışık şiddeti", "birim", (70, 95), (10, 30)),
    ("karbondioksit derişimi", "ppm", (700, 900), (150, 300)),
    ("sıcaklık", "°C", (22, 28), (6, 12)),
]


@bulmaca(ders="biyoloji", konu="sinirlayici_faktor", kademeler=(9, 13),
         agirlik=1.2)
def sinirlayici_faktor(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Fotosentez hızını hangi faktör tutuyor?

    Yükselen tek eksen: bağıntı çeşidi (üç faktör aynı anda, ama yalnızca
    biri belirleyici). Sayılar kolay; zor olan hangisinin belirlediğini
    görmek. (ICERIK_EKLEME.md §2c)
    """
    kit_indeks = rastgele.randrange(len(FOTOSENTEZ_FAKTORLERI))
    olculer = []
    for i, (ad, birim, bol, kit) in enumerate(FOTOSENTEZ_FAKTORLERI):
        aralik = kit if i == kit_indeks else bol
        olculer.append((ad, birim, rastgele.randrange(aralik[0], aralik[1])))
    kit_ad, kit_birim, kit_deger = olculer[kit_indeks]
    bol_olanlar = [o for i, o in enumerate(olculer) if i != kit_indeks]

    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    # Deneme: kıt faktör artırılınca hız artıyor, bol olan artırılınca değil.
    hiz_once = rastgele.randrange(20, 40)
    hiz_kit_artinca = hiz_once + rastgele.randrange(18, 35)
    hiz_bol_artinca = hiz_once + rastgele.choice([0, 1])

    return Bulmaca(
        kod="biy-sinirlayici-faktor",
        ders="biyoloji",
        baslik="Sera Bölmesi",
        kademe=kademe,
        konu="sinirlayici_faktor",
        kazanim=("Sınırlayıcı faktörü tanıma; bol olan bir etkeni artırmanın "
                 "hızı değiştirmediğini açıklama."),
        dikkat=6,
        brifing=(
            "Üssün sera bölmesinde fotosentez hızı beklenenin altında. "
            "{} üç ölçüm aldı:\n\n"
            "  • {}: {} {}\n"
            "  • {}: {} {}\n"
            "  • {}: {} {}\n\n"
            "Komutan \"bir şeyi artıralım da verim yükselsin\" diyor. "
            "Hangisini artıracağımıza karar vermemiz gerekiyor; üçünü "
            "birden yükseltecek kaynağımız yok."
        ).format(kisi,
                 olculer[0][0].capitalize(), sy(olculer[0][2]), olculer[0][1],
                 olculer[1][0].capitalize(), sy(olculer[1][2]), olculer[1][1],
                 olculer[2][0].capitalize(), sy(olculer[2][2]), olculer[2][1]),
        kanitlar=[
            Kanit("Sera el kitabı",
                  "Fotosentez için uygun aralıklar:\n"
                  "  ışık şiddeti 60-100 birim\n"
                  "  karbondioksit 600-1000 ppm\n"
                  "  sıcaklık 20-30 °C",
                  bedel=1, kritik=True),
            Kanit("Deneme kaydı",
                  "\"{} tek başına artırıldığında hız {} -> {} oldu. "
                  "{} artırıldığında hız {} -> {} oldu.\"".format(
                      kit_ad.capitalize(), sy(hiz_once), sy(hiz_kit_artinca),
                      bol_olanlar[0][0].capitalize(), sy(hiz_once),
                      sy(hiz_bol_artinca)),
                  bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="Fotosentez hızını şu anda hangi ölçüm belirliyor?",
                dogru="{} -- uygun aralığın altında kalan tek ölçüm.".format(
                    kit_ad.capitalize()),
                yanlislar=[
                    # ÇELDİRİCİ SAYIYA GÖRE SEÇİLMİYOR. İlk yazımda "en
                    # yüksek değere sahip ölçüm" deniyordu; birimler
                    # farklı olduğu için (ppm, °C, birim) kıt faktör de
                    # çoğu zaman en büyük sayıya sahip oluyor ve çeldirici
                    # DOĞRU CEVABI gösteriyordu -- ölçümde vakaların
                    # yarısında. Artık bol olan faktör adıyla anılıyor.
                    "{} -- uygun aralığın üst ucunda; fazlası bitkiyi zorluyor.".format(
                        bol_olanlar[0][0].capitalize()),
                    "Üçü birlikte belirliyor; fotosentez üçüne de muhtaç, biri seçilemez.",
                    "Hiçbiri: sorun ölçümlerde değil bitkidedir.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "El kitabındaki aralıklara göre iki ölçüm uygun, biri "
                    "değil: {} {} {}. Zincirin hızını en dar halka "
                    "belirler; burada o halka {}."
                ).format(kit_ad, sy(kit_deger), kit_birim, kit_ad),
                cozum=(
                    "Her ölçümü el kitabıyla karşılaştır:\n"
                    "  {} {} {} -> uygun\n"
                    "  {} {} {} -> uygun\n"
                    "  {} {} {} -> ALTINDA\n\n"
                    "Bir süreç, en yetersiz koşulunun izin verdiği kadar "
                    "hızlı gider. Buna SINIRLAYICI FAKTÖR denir.\n\n"
                    "Aynı yapıyı nakliyede de gördün: tren ne kadar hızlı "
                    "olursa olsun, kamyonlar azsa iş uzuyordu."
                ).format(bol_olanlar[0][0], sy(bol_olanlar[0][2]),
                         bol_olanlar[0][1],
                         bol_olanlar[1][0], sy(bol_olanlar[1][2]),
                         bol_olanlar[1][1],
                         kit_ad, sy(kit_deger), kit_birim),
            ),
            sayi_adimi(
                soru=("Deneme kaydına göre {} artırılınca hız kaç birim "
                      "yükseldi?").format(kit_ad),
                cevap=hiz_kit_artinca - hiz_once,
                birim="birim",
                aciklama="{} - {} = {}".format(
                    sy(hiz_kit_artinca), sy(hiz_once),
                    sy(hiz_kit_artinca - hiz_once)),
                cozum=(
                    "{} - {} = {} birim.\n\n"
                    "Karşılaştır: {} artırıldığında hız yalnızca {} birim "
                    "değişti. Bol olan bir faktörü artırmak neredeyse "
                    "hiçbir şey değiştirmiyor."
                ).format(sy(hiz_kit_artinca), sy(hiz_once),
                         sy(hiz_kit_artinca - hiz_once),
                         bol_olanlar[0][0], sy(hiz_bol_artinca - hiz_once)),
            ),
            yorum_adimi(
                soru="{} bir kat daha artırılırsa ne olur?".format(
                    bol_olanlar[0][0].capitalize()),
                dogru="Hız değişmez; o faktör sınırlayıcı değil.",
                yanlislar=[
                    "Hız bir kat daha artar; kaynak arttıkça ürün de artar.",
                    "Hız artar ama daha az miktarda.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Bol olan bir kaynağı daha da artırmak boşa harcamadır. "
                    "Sınırlayıcı olan {} tamamlanmadan başka hiçbir şey "
                    "hızı yükseltmez."
                ).format(kit_ad),
                cozum=(
                    "Deneme kaydı bunu zaten göstermiş: {} artırıldığında "
                    "hız {} -> {} oldu, yani neredeyse değişmedi.\n\n"
                    "Sınırlayıcı faktör mantığının pratik sonucu bu: "
                    "kaynağı BOL olana değil, KIT olana harcarsın."
                ).format(bol_olanlar[0][0], sy(hiz_once),
                         sy(hiz_bol_artinca)),
            ),
        ],
        kapanis=(
            "Sera kaydına \"{} yükseltildi\" notu düşüldü. Diğer iki ölçüm "
            "olduğu gibi bırakıldı."
        ).format(kit_ad),
        odul={"erzak": 8, "itibar": 4},
    )


# ==========================================================================
# DOLAŞIM: ATARDAMAR VE TOPLARDAMAR (B37.13 -- müfredat haritası)
#
# `dolasim_homeostazi` (2026 programı, 11. sınıf) boştu; oyunda dolaşım
# görevi yoktu. 2026-2027'de 11. sınıfta yeni program uygulanıyor, canlı satır
# bu. `yaygin_yanlis`:
#
#   "Bütün atardamarların oksijence zengin kan taşıdığını sanmak."
#
# Atardamar/toplardamar ayrımını KANIN YÖNÜ belirler, oksijen içeriği değil.
# Karşı örnek: akciğer atardamarı oksijence FAKİR kan taşır (kalpten akciğere,
# oksijen almaya giden kan); akciğer toplardamarı oksijence ZENGİN kan taşır.
#
# ÖNCEDEN YAKALANAN KUSUR -- ADLAR CEVABI VERİYOR:
# Damarları adıyla sorsaydık cevap soruda yazardı: "akciğer ATARDAMARI"
# sorusunda öğrenci hiç düşünmeden okur. O yüzden şemanın etiketleri düşmüş;
# damarlar "Damar 1-4" diye kodlu ve kanıtta yalnız akış yönü ile oksijen
# ölçümü var. Gerçek adlar yalnız cevaptan sonra açıklamada geçiyor.
#
# DÖRT DAMAR, DÖRT HÜCRE: atar/toplar x zengin/fakir matrisinin her hücresi
# bir damara düşüyor. Rastgele hangisi gelirse gelsin bir hücre sınanıyor;
# ikisinde yanılgı YANLIŞ hükme, ikisinde DOĞRU hükme ama yanlış gerekçeye
# götürüyor.
# ==========================================================================

# (gerçek ad, nereden, nereye, yön: "cikis"=kalpten/"giris"=kalbe, oksijen)
_DAMARLAR = (
    ("aort", "sol karıncıktan çıkıyor", "vücuda gidiyor", "cikis", "yüksek"),
    ("akciğer atardamarı", "sağ karıncıktan çıkıyor", "akciğerlere gidiyor", "cikis", "düşük"),
    ("akciğer toplardamarı", "akciğerlerden geliyor", "sol kulakçığa giriyor", "giris", "yüksek"),
    ("üst ana toplardamar", "vücudun üst bölümünden geliyor", "sağ kulakçığa giriyor", "giris", "düşük"),
)

_D_ATAR_YON = "Atardamar: kanı kalpten uzağa taşıyor"
_D_TOPLAR_YON = "Toplardamar: kanı kalbe taşıyor"
_D_ATAR_OKSIJEN = "Atardamar: oksijence zengin kan taşıyor"
_D_TOPLAR_OKSIJEN = "Toplardamar: oksijence fakir kan taşıyor"


def _siniflama_yanlislari(yon, oksijen):
    """Doğru şık yöne göre; yanlış şıkların teşhisi damarın hücresine göre."""
    if yon == "cikis":
        dogru = _D_ATAR_YON
        yanlislar = {
            _D_TOPLAR_YON: "Akış yönünü ters okudun: bu damar kalpten ÇIKIYOR.",
        }
        if oksijen == "düşük":
            yanlislar[_D_TOPLAR_OKSIJEN] = (
                "Oksijence fakir diye toplardamar saydın. Ama bu damar kalpten "
                "çıkıyor -- atardamar. Oksijen içeriği sınıfı belirlemez.")
            yanlislar[_D_ATAR_OKSIJEN] = (
                "Bu damar atardamar, doğru; ama oksijence zengin DEĞİL -- ölçüm "
                "düşük. Atardamarların hepsi zengin kan taşımaz.")
        else:
            yanlislar[_D_ATAR_OKSIJEN] = (
                "Hüküm doğru ama gerekçe yanlış: atardamar olduğunu oksijenden "
                "değil yönden anlıyoruz. Oksijenden anlasaydık akciğer "
                "atardamarını yanlış sınıflardık.")
            yanlislar[_D_TOPLAR_OKSIJEN] = (
                "Bu damar oksijence zengin ve kalpten çıkıyor; iki bilgi de "
                "toplardamar hükmüyle çelişiyor.")
    else:
        dogru = _D_TOPLAR_YON
        yanlislar = {
            _D_ATAR_YON: "Akış yönünü ters okudun: bu damar kalbe GİRİYOR.",
        }
        if oksijen == "yüksek":
            yanlislar[_D_ATAR_OKSIJEN] = (
                "Oksijence zengin diye atardamar saydın. Ama bu damar kalbe "
                "giriyor -- toplardamar. Oksijen içeriği sınıfı belirlemez.")
            yanlislar[_D_TOPLAR_OKSIJEN] = (
                "Bu damar toplardamar, doğru; ama oksijence fakir DEĞİL -- ölçüm "
                "yüksek. Toplardamarların hepsi fakir kan taşımaz.")
        else:
            yanlislar[_D_TOPLAR_OKSIJEN] = (
                "Hüküm doğru ama gerekçe yanlış: toplardamar olduğunu oksijenden "
                "değil yönden anlıyoruz. Oksijenden anlasaydık akciğer "
                "toplardamarını yanlış sınıflardık.")
            yanlislar[_D_ATAR_OKSIJEN] = (
                "Bu damar oksijence fakir ve kalbe giriyor; iki bilgi de "
                "atardamar hükmüyle çelişiyor.")
    return dogru, yanlislar


@bulmaca(ders="biyoloji", konu="dolasim_homeostazi", kademeler=(9, 13), agirlik=1.3)
def dolasim_semasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Atardamar/toplardamar ayrımını kanın yönü belirler, oksijen içeriği değil."""
    sira = list(range(len(_DAMARLAR)))
    rastgele.shuffle(sira)
    # kod numarası -> damar
    kodlu = {no + 1: _DAMARLAR[i] for no, i in enumerate(sira)}
    siniflanan_no = rastgele.choice(list(kodlu))
    ad, _, _, yon, oksijen = kodlu[siniflanan_no]
    dogru_sinif, sinif_yanlislari = _siniflama_yanlislari(yon, oksijen)

    curuten_no = next(no for no, d in kodlu.items() if d[3] == "cikis" and d[4] == "düşük")
    aort_no = next(no for no, d in kodlu.items() if d[3] == "cikis" and d[4] == "yüksek")
    akc_top_no = next(no for no, d in kodlu.items() if d[3] == "giris" and d[4] == "yüksek")
    ana_top_no = next(no for no, d in kodlu.items() if d[3] == "giris" and d[4] == "düşük")

    sema = "\n".join(
        "Damar {}: {}, {}. Kandaki oksijen: {}.".format(no, d[1], d[2], d[4])
        for no, d in sorted(kodlu.items()))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-dolasim-semasi",
        ders="biyoloji",
        baslik="Dolaşım Şeması",
        kademe=kademe,
        konu="dolasim_homeostazi",
        kazanim="Atardamar ve toplardamarı kanın akış yönüne göre ayırt etme; "
                "atardamarların hepsinin oksijence zengin kan taşımadığını açıklama.",
        dikkat=7,
        brifing=(
            "Üs revirindeki dolaşım şemasının etiketleri nemden düşmüş. {} "
            "sensörlerle her damardaki akış yönünü ve kanın oksijen düzeyini "
            "ölçtü; ama hangi damarın atardamar, hangisinin toplardamar "
            "olduğunu yazmadan bıraktı.\n\n"
            "Revir defterinin kenarına biri \"Bütün atardamarlar oksijence "
            "zengin kan taşır\" diye not düşmüş. Şemayı yeniden etiketlememiz "
            "ve bu notun doğru olup olmadığını bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Sensör ölçümleri", sema, bedel=2, kritik=True),
            Kanit("Revir defteri",
                  "Kenar notu: \"Bütün atardamarlar oksijence zengin kan taşır.\"",
                  bedel=1, kritik=True),
            Kanit("Terim notu",
                  "Karıncıklar kanı kalpten dışarı pompalar; kulakçıklar kalbe "
                  "gelen kanı alır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir damarın atardamar mı toplardamar mı olduğunu ne belirler?",
                dogru=("Kanın yönü: kalpten çıkanı taşıyan atardamar, kalbe "
                       "geleni taşıyan toplardamardır"),
                yanlislar={
                    "Kanın oksijen içeriği: zengin kan taşıyan atardamar, fakir kan taşıyan toplardamardır":
                        "Atardamarların hepsinin oksijence zengin kan taşıdığını "
                        "sandın. Bu çoğu damar için tutar ama tanım bu değil; "
                        "akciğer dolaşımında tersi olur.",
                    "Damarın çeperinin kalınlığı; kalın çeperli olan "
                    "atardamardır":
                        "Atardamarların çeperi genellikle daha kalındır, ama bu "
                        "yüksek basınca bir UYUM -- tanım değil. Tanımı yön verir.",
                    "Damarın vücudun hangi bölgesinde bulunduğu; derindeki "
                    "atardamar, yüzeydeki toplardamardır":
                        "Atardamar da toplardamar da vücudun her yerinde bulunur. "
                        "Belirleyici olan konum değil, kanın akış yönü.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Atardamar ve toplardamar YÖNE göre tanımlanır. Büyük "
                    "dolaşımda atardamarlar oksijence zengin kan taşıdığı için "
                    "\"atardamar = temiz kan\" diye ezberlenir. Ama küçük "
                    "(akciğer) dolaşımında kan tersine akar: akciğere oksijen "
                    "almaya giden kan fakirdir, dönen kan zengindir."
                ),
                ipuclari=[
                    "Sensör ölçümlerinde her damar için iki bilgi var: yön ve oksijen. Hangisi tanım?",
                    "Akciğere giden kan neden oraya gidiyor?",
                ],
                cozum=(
                    "Kalpten çıkan -> atardamar.\n"
                    "Kalbe giren -> toplardamar.\n"
                    "Oksijen içeriği sınıfı belirlemez."
                ),
            ),
            secim_adimi(
                soru="Damar {} hangi damardır ve neden?".format(siniflanan_no),
                dogru=dogru_sinif,
                yanlislar=sinif_yanlislari,
                rastgele=rastgele,
                aciklama=(
                    "Damar {}, gerçek adıyla {}. Ölçüme göre kalpten {} ve "
                    "oksijeni {}: sınıfını belirleyen yön."
                ).format(siniflanan_no, ad,
                         "çıkıyor" if yon == "cikis" else "gelen kanı taşıyor",
                         oksijen),
                ipuclari=["Yalnız akış yönüne bak."],
                puan=12,
            ),
            secim_adimi(
                soru="Şemadaki hangi damar revir defterindeki kenar notunu ÇÜRÜTÜR?",
                dogru="Damar {}".format(curuten_no),
                yanlislar={
                    "Damar {}".format(aort_no):
                        "Bu damar kalpten çıkıyor ve oksijence zengin: notu "
                        "DOĞRULUYOR. Çürütmek için notla çelişen bir atardamar "
                        "gerekir.",
                    "Damar {}".format(akc_top_no):
                        "Bu damar oksijence zengin ama kalbe giriyor, yani "
                        "toplardamar. Not atardamarlar hakkında; bu damar onu "
                        "çürütemez.",
                    "Damar {}".format(ana_top_no):
                        "Bu damar toplardamar. Not atardamarlar hakkında bir "
                        "genelleme; bir toplardamar onu ne doğrular ne çürütür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Bütün atardamarlar zengin kan taşır\" genellemesini tek bir "
                    "karşı örnek çürütür: oksijence FAKİR kan taşıyan bir "
                    "ATARDAMAR. Damar {} kalpten çıkıyor ama oksijeni düşük -- "
                    "o, akciğer atardamarı."
                ).format(curuten_no),
                ipuclari=["Notu çürütmek için hem atardamar olan hem de nota uymayan bir damar lazım."],
                puan=14,
            ),
            yorum_adimi(
                soru="Akciğer atardamarı neden oksijence fakir kan taşır?",
                dogru=("Kalbin sağından akciğere giden kanı taşır; adını "
                       "yönünden alır, oksijeninden değil."),
                yanlislar={
                    "Çünkü damarda bir tıkanıklık var ve kan oksijenini "
                    "kaybediyor; sağlıklı atardamarda kan hep temizdir.":
                        "Bu bir hastalık değil, normal dolaşım. Kan zaten "
                        "oksijenini vücutta bırakıp kalbe dönmüş; akciğere "
                        "yeniden oksijen almaya gidiyor.",
                    "Çünkü aslında bir toplardamar; oksijensiz kan taşıdığına "
                    "göre adı yanlış konmuş.":
                        "Adı doğru: kalpten çıktığı için atardamar. Yanlış olan "
                        "\"atardamar = zengin kan\" genellemesi.",
                    "Çünkü akciğerde oksijenini bırakıp oradan dönüyor; oksijeni "
                    "en çok akciğer tüketir.":
                        "Yönü ters kurdun. Akciğerde kan oksijen ALIR, bırakmaz; "
                        "ve bu damar akciğerden dönmüyor, akciğere gidiyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Küçük dolaşım: sağ karıncık, vücuttan dönen oksijence fakir "
                    "kanı akciğer atardamarıyla akciğere pompalar. Kan akciğerde "
                    "oksijen alır ve akciğer toplardamarıyla, bu kez zengin "
                    "olarak, sol kulakçığa döner. İki damar da adını yönünden "
                    "alıyor; içerikleri büyük dolaşımdakinin tersi."
                ),
                puan=12,
            ),
        ],
        kapanis=("Şema yeniden etiketlendi. Revir defterindeki not silindi: "
                 "akciğer atardamarı oksijence fakir kan taşıyan bir atardamar."),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# ZARDAN SU GEÇİŞİ: OSMOZ (B37.13 -- müfredat haritası)
#
# `zar_tasinmasi` (2018+2026, 9. sınıf) boştu; oyunda osmoz yoktu. Bağlam:
# "Numune hücrelerinin farklı ortamlardaki değişimini yorumlama".
# `yaygin_yanlis` İKİ yanılgı birden:
#
#   "Osmozu çözünen maddenin hareketi sanmak; her geçişte ATP gerektiğini
#    düşünmek."
#
# DENEY: aynı patatesten kesilen parçalar 0-0,5 mol/L sükroz çözeltilerinde
# bekletilir, önce ve sonra tartılır. Su, çözünenin az olduğu taraftan çok
# olduğu tarafa geçer; sükroz zardan geçmez.
#
# YANILGILARIN VERİDEKİ KARŞILIĞI:
#   * sükroz hücreye girseydi yoğun çözeltide parça AĞIRLAŞIRDI -- veride
#     hafifliyor (0,5 mol/L her zaman hücre içinden yoğun; havuz bunu
#     garanti ediyor);
#   * osmoz ATP isteseydi solunumu durdurulmuş parçada değişim küçülürdü --
#     ek tüpte AYNI yüzde çıkıyor.
#
# YÜZDE NEDEN ŞART: parçaların ilk kütleleri farklı. Gram farkı parçanın
# büyüklüğünü ölçer, suyun ne kadar geçtiğini değil.
# ==========================================================================

_SUKROZ = (0, 1, 2, 3, 4, 5)            # onda bir mol/L: 0,0 ... 0,5
_PARCA_KUTLELERI = (20, 30, 40, 50)     # g; 10'un katı -> son kütle tek ondalık


def _osmoz_havuzu():
    """(egim, sinir, kaydirma): yüzde değişim_j = egim × (ic − C_j).

    İç derişim ic = (sinir + kaydirma/4) / 10 mol/L, yani iki komşu tüpün
    ARASINDA; hiçbir tüp tam dengede değil.

    Koşullar:
      1. Her tüpün yüzde değişimi TAM SAYI.
      2. |değişim| ≤ 30: patates dokusu için gerçekçi.
      3. sinir 1-3: iç derişimin iki yanında en az iki tüp var; 0,5 mol/L
         tüpü her zaman kütle kaybediyor (brifingteki öneri bu tüp).
    """
    havuz = []
    for egim in (40, 60, 80, 100, 120):
        for sinir in (1, 2, 3):
            for kaydirma in (1, 2, 3):
                ham = [egim * (4 * (sinir - j) + kaydirma) for j in _SUKROZ]
                if any(d % 40 for d in ham):
                    continue
                degisim = [d // 40 for d in ham]
                if max(abs(d) for d in degisim) > 30:
                    continue
                havuz.append((egim, sinir, kaydirma))
    return tuple(havuz)


_OSMOZ = _osmoz_havuzu()


def _yuzde_degisimler(egim, sinir, kaydirma):
    return [egim * (4 * (sinir - j) + kaydirma) // 40 for j in _SUKROZ]


def _derisim(j):
    return sy(j / 10.0)


def _aralik(j):
    return "{} ile {} mol/L arasında".format(_derisim(j), _derisim(j + 1))


@bulmaca(ders="biyoloji", konu="zar_tasinmasi", kademeler=(9, 13), agirlik=1.3)
def numune_cozeltisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Osmoz: su derişim farkıyla kendiliğinden geçer; çözünen geçmez, ATP gerekmez."""
    egim, sinir, kaydirma = rastgele.choice(_OSMOZ)
    degisim = _yuzde_degisimler(egim, sinir, kaydirma)
    ilk = [rastgele.choice(_PARCA_KUTLELERI) for _ in _SUKROZ]
    son = [m + m * d / 100.0 for m, d in zip(ilk, degisim)]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    # Sorulan tüp: kütle KAYBEDEN (hücreden yoğun) tüplerden biri.
    sorulan = rastgele.choice([j for j in _SUKROZ if degisim[j] < 0])
    kayip = -degisim[sorulan]
    gram = ilk[sorulan] - son[sorulan]
    ek_ilk = rastgele.choice([m for m in _PARCA_KUTLELERI if m != ilk[sorulan]])
    ek_son = ek_ilk - ek_ilk * kayip / 100.0

    cizelge = "\n".join(
        "Tüp {} -- {} mol/L sükroz{}: önce {} g, sonra {} g.".format(
            j + 1, _derisim(j), " (saf su)" if j == 0 else "", ilk[j], sy(son[j]))
        for j in _SUKROZ)

    # Aralık seçenekleri: doğru, iki komşu ve en uçtaki.
    uc = len(_SUKROZ) - 2 if sinir == 1 else 0
    yanlis_araliklar = [sinir - 1, sinir + 1, uc]

    def aralik_teshisi(j):
        yon = "arttı" if degisim[j] > 0 else "azaldı"
        return ("Bu aralığın iki ucundaki tüplerde de kütle {}. Kütlenin "
                "değişmeyeceği derişim, değişimin YÖN DEĞİŞTİRDİĞİ yerdedir: "
                "bir yanda artan, öbür yanda azalan iki tüp.").format(yon)

    return Bulmaca(
        kod="biyo-numune-cozeltisi",
        ders="biyoloji",
        baslik="Numune Çözeltisi",
        kademe=kademe,
        konu="zar_tasinmasi",
        kazanim="Hücre zarından su geçişini (osmoz) derişim farkıyla açıklama; "
                "osmozun ATP gerektirmediğini deney verisiyle gösterme; yüzde "
                "kütle değişimini hesaplama.",
        dikkat=7,
        brifing=(
            "Canlılar bölmesi seradan aldığı patates dokusu numunelerini "
            "uzak laboratuvara gönderecek. Yolda numuneler bir çözeltide "
            "bekleyecek ve ne şişmeleri ne de büzülmeleri isteniyor.\n\n"
            "{} bir öneri getirdi: \"Numuneleri 0,5 mol/L şekerli çözeltiye "
            "koyalım. Şeker hücrelere girer, numuneler dolgunlaşır. Hücreler "
            "bunu enerji harcayarak yaptığı için taze kalırlar.\"\n\n"
            "Laboratuvar karar vermeden önce bir deney kurdu. Hangi derişimin "
            "uygun olduğunu ve öneriyi verilerle değerlendirmemiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Tartım çizelgesi", cizelge, bedel=2, kritik=True),
            Kanit("Zar notu",
                  "Patates hücrelerinin zarı su moleküllerini geçirir. Sükroz "
                  "molekülleri bu deneyin süresi boyunca zardan geçmez.",
                  bedel=1, kritik=True),
            Kanit("Ek tüp",
                  "Tüp {} ile aynı derişimde ({} mol/L) bir tüp daha kuruldu. "
                  "Buradaki parça önce hücre solunumunu durduran bir maddede "
                  "bekletildi; hücreleri ATP üretemiyordu. Önce {} g, sonra {} g."
                  .format(sorulan + 1, _derisim(sorulan), ek_ilk, sy(ek_son)),
                  bedel=1, kritik=True),
            Kanit("Deney koşulları",
                  "Bütün parçalar aynı patatesten kesildi. Tüpler 24 saat aynı "
                  "sıcaklıkta bekletildi.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Tüplerdeki kütle değişimini hangi açıklama doğru anlatıyor?",
                dogru=("Su, çözünen maddenin az olduğu taraftan çok olduğu "
                       "tarafa geçer; sükroz geçmez"),
                yanlislar={
                    "Sükroz hücreye girer; çözelti yoğunlaştıkça parça "
                    "ağırlaşır, şeker hücrenin içinde birikir":
                        "Osmozu çözünen maddenin hareketi sandın. Zar notuna "
                        "göre sükroz geçmiyor ve çizelgede en yoğun tüpteki "
                        "parça ağırlaşmadı, HAFİFLEDİ.",
                    "Hücre ATP harcayarak suyu içeri ya da dışarı pompalar; "
                    "canlı hücrede her taşıma enerji ister":
                        "Her geçişte ATP gerektiğini düşündün. Su, derişim "
                        "farkıyla kendiliğinden geçer; ek tüp bunu sınıyor.",
                    "Su, çözünen maddenin çok olduğu taraftan az olduğu tarafa "
                    "geçer; yayılma gibi":
                        "Yönü ters kurdun. Saf sudaki parça su aldı: dışarıda "
                        "çözünen yok, hücrenin içinde var. Su, çözüneni AZ olan "
                        "taraftan ÇOK olan tarafa gidiyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zar suyu geçirip sükrozu geçirmiyorsa derişim farkını "
                    "yalnız su kapatabilir. Dışarısı hücrenin içinden daha suluysa "
                    "su hücreye girer, parça ağırlaşır; dışarısı daha yoğunsa "
                    "su hücreden çıkar, parça hafifler. Bu geçişe OSMOZ denir "
                    "ve hareket eden sudur, çözünen madde değil."
                ),
                ipuclari=[
                    "Zar notu hangi molekülün geçtiğini söylüyor?",
                    "Saf sudaki parça ile en yoğun çözeltideki parça aynı yönde mi değişti?",
                ],
                cozum=(
                    "Çözünen az -> su çok.\n"
                    "Su, suyun çok olduğu taraftan az olduğu tarafa geçer.\n"
                    "Sükroz yerinde kalır."
                ),
            ),
            sayi_adimi(
                soru="Tüp {} parçasının kütlesi yüzde kaç azaldı?".format(sorulan + 1),
                cevap=kayip,
                aciklama=(
                    "Kayıp: {} − {} = {} g. Yüzde: {} ÷ {} × 100 = {}. Yüzdeyi "
                    "ilk kütleye göre alıyoruz, çünkü parçalar farklı büyüklükte."
                ).format(ilk[sorulan], sy(son[sorulan]), sy(gram),
                         sy(gram), ilk[sorulan], kayip),
                yaygin_yanlislar={
                    sy(gram).replace(",", "."):
                        "Gram farkını yazdın; soru yüzde. Parçaların ilk "
                        "kütleleri farklı, gram farkı parçanın büyüklüğüne de "
                        "bağlı.",
                    100 - kayip:
                        "Son kütlenin ilk kütleye oranını yazdın. Azalma, bu "
                        "oranın 100'den eksiği.",
                },
                ipuclari=["Kütle farkını ilk kütleye böl, 100 ile çarp."],
                puan=12,
            ),
            secim_adimi(
                soru=("Numunelerin kütlesi yolda değişmesin isteniyorsa çözeltinin "
                      "derişimi hangi aralıkta olmalı?"),
                dogru=_aralik(sinir),
                yanlislar={_aralik(j): aralik_teshisi(j) for j in yanlis_araliklar},
                rastgele=rastgele,
                aciklama=(
                    "{} mol/L tüpünde kütle yüzde {} arttı, {} mol/L tüpünde "
                    "yüzde {} azaldı. Değişimin yön değiştirdiği yer bu iki "
                    "derişimin arası: orada hücrenin içi ile dışı arasında su "
                    "akışı dengede."
                ).format(_derisim(sinir), degisim[sinir],
                         _derisim(sinir + 1), -degisim[sinir + 1]),
                ipuclari=["Kütlenin arttığı son tüpü ve azaldığı ilk tüpü bul."],
                puan=12,
            ),
            yorum_adimi(
                soru=("Ek tüpte solunumu durdurulmuş parçanın kütlesi nasıl "
                      "değişti ve bu ne gösteriyor?"),
                dogru=("Aynı oranda azaldı: suyun zardan geçişi ATP gerektirmez, "
                       "pasif taşımadır"),
                yanlislar={
                    "Hiç değişmedi: ATP olmadan su zardan geçemez":
                        "Her geçişte ATP gerektiğini düşündün. Ek tüpün "
                        "tartımına bak: kütle değişti.",
                    "Aynı oranda azaldı: hücre önceden depoladığı ATP ile suyu dışarı pompaladı":
                        "Hücreler 24 saat boyunca ATP üretemedi. Su "
                        "pompalanıyor olsaydı ATP'siz parçada değişim küçülürdü; "
                        "oran aynı çıktı, demek ki geçiş enerjiye bağlı değil.",
                    "Daha çok azaldı: solunum durunca sükroz hücreye girdi":
                        "Sükroz hücreye girseydi parça ağırlaşırdı, hafiflemezdi. "
                        "Ek tüpteki yüzde kaybı da Tüp {} ile aynı."
                        .format(sorulan + 1),
                },
                rastgele=rastgele,
                aciklama=(
                    "Ek tüpte kayıp {} − {} = {} g, yani yüzde {} -- Tüp {} ile "
                    "aynı. ATP üretemeyen hücrede de su aynı ölçüde geçtiyse "
                    "osmoz enerji harcamıyor demektir: su, derişim farkıyla "
                    "kendiliğinden hareket eder. Buna pasif taşıma denir."
                ).format(ek_ilk, sy(ek_son), sy(ek_ilk - ek_son), kayip, sorulan + 1),
                puan=12,
            ),
        ],
        kapanis=("Rapor: numuneler {} bir çözeltide taşınacak. 0,5 mol/L önerisi "
                 "reddedildi -- o tüpteki parça yüzde {} su kaybetti ve şeker "
                 "hücreye girmedi. Suyun geçişi için ATP de gerekmedi."
                 ).format(_aralik(sinir), -degisim[-1]),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# HÜCRE DÖNGÜSÜ VE MİTOZ: KROMOZOM SAYISI NE ZAMAN İKİYE KATLANIR?
# (B37.13 -- müfredat haritası)
#
# `mitoz_eseysiz` (2018, 10. sınıf) ve `hucre_dongusu` (2026, 12. sınıf)
# boştu; yanılgı ve bağlam ikisinde de aynı:
#
#   "DNA eşlenmesiyle kromozom sayısının koşulsuz iki kat olduğunu sanmak."
#   Bağlam: "Hücre gözlem serisini doğru sıraya koyma."
#
# DOĞRUSU: eşlenmeden sonra DNA miktarı iki katına çıkar ama kromozom sayısı
# DEĞİŞMEZ -- iki kardeş kromatit tek sentromerden bağlıdır. Sayı ancak
# anafazda, kardeş kromatitler ayrılınca iki katına çıkar; bölünme bitince
# her yavru hücre yine 2n alır. "Koşulsuz" sözcüğü tam bu ayrımı anlatıyor.
#
# YANILGININ İKİ SAYISAL YÜZÜ -- ikisi de ayrı adım:
#   * eşlenmiş (G2) hücrede 4n demek,
#   * anafazda 2n demek ("ayrılma sayıyı değiştirmez").
#
# Türler gerçek kök ucu gözlem materyali; 2n değerleri testte bağımsız bir
# başvuru tablosuyla sınanır.
# ==========================================================================

_KOK_UCU_TURLERI = (("soğan", 16), ("bezelye", 14), ("domates", 24),
                    ("mısır", 20), ("fasulye", 22))

# Döngü sırasıyla gözlem kartları (sıra = doğru sıra).
_MITOZ_KARTLARI = (
    "Çekirdek zarı sağlam, kromozomlar ince iplikler hâlinde; DNA ölçümü 2 birim",
    "Çekirdek zarı sağlam, kromozomlar ince iplikler hâlinde; DNA ölçümü 4 birim",
    "Çekirdek zarı yok, X biçimli kalın kromozomlar hücrenin ortasında tek sıra "
    "dizilmiş; DNA ölçümü 4 birim",
    "X biçimli yapılar ortadan ayrılmış, tek kollu yapılar zıt kutuplara "
    "çekiliyor; DNA ölçümü 4 birim",
    "Kutuplarda iki yeni çekirdek var, aralarında yeni ara duvar oluşuyor; her "
    "çekirdekte DNA ölçümü 2 birim",
)


@bulmaca(ders="biyoloji", konu="mitoz_eseysiz", kademeler=(10, 13), agirlik=1.3)
def gozlem_serisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """DNA eşlenince kromozom sayısı değişmez; anafazda kromatitler ayrılınca ikiye katlanır."""
    tur, iki_n = rastgele.choice(_KOK_UCU_TURLERI)
    n, dort_n = iki_n // 2, iki_n * 2
    karisik = list(range(len(_MITOZ_KARTLARI)))
    rastgele.shuffle(karisik)
    secenekler = [_MITOZ_KARTLARI[i] for i in karisik]
    dogru_sira = [karisik.index(i) for i in range(len(_MITOZ_KARTLARI))]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-gozlem-serisi",
        ders="biyoloji",
        baslik="Gözlem Serisi",
        kademe=kademe,
        konu="mitoz_eseysiz",
        kazanim="Hücre döngüsü evrelerini gözleme göre sıralama; DNA miktarı ile "
                "kromozom sayısının değişimini ayırt etme; kromozom sayısının "
                "anafazda iki katına çıktığını açıklama.",
        dikkat=7,
        brifing=(
            "Tohum bankası, {} kök ucundan bir bölünme serisi fotoğrafladı. "
            "Beş kart laboratuvar masasında karıştı ve asistanın üzerlerine "
            "yazdığı sayılar birbirini tutmuyor.\n\n"
            "{} kartların sırasını ve sayıların doğrusunu istiyor: seri, ekim "
            "öncesi tohum sağlığı raporuna girecek."
        ).format(tur, kisi),
        kanitlar=[
            Kanit("Tür kartı",
                  "Numune: {} kök ucu. Bu türün vücut hücrelerinde 2n = {} "
                  "kromozom vardır.".format(tur, iki_n),
                  bedel=1, kritik=True),
            Kanit("Asistanın notları",
                  "DNA ölçümü 4 birim olan, çekirdek zarı sağlam hücrenin kartına: "
                  "\"DNA eşlendi, {} kromozom.\"\n"
                  "Tek kollu yapıların kutuplara çekildiği karta: \"{} kromozom; "
                  "ayrılma sayıyı değiştirmez.\"".format(dort_n, iki_n),
                  bedel=1, kritik=True),
            Kanit("Sayım kuralı",
                  "Kromozomlar sentromerden sayılır: bir sentromer, bir kromozom. "
                  "Eşlenmiş bir kromozomun iki kardeş kromatiti aynı sentromere "
                  "bağlıdır.",
                  bedel=2),
            Kanit("Seri notu",
                  "Seri, DNA'sı henüz eşlenmemiş bir hücreyle başlıyor ve yeni "
                  "hücrelerin oluşmasıyla bitiyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir hücrede DNA eşlendikten hemen sonra kromozom sayısı ne olur?",
                dogru=("Değişmez: kromozom iki kromatitli olur; iki katına "
                       "çıkan DNA'dır"),
                yanlislar={
                    "İki katına çıkar: DNA eşlendiğine göre kromozomlar da ikiye katlanır":
                        "DNA eşlenmesiyle kromozom sayısının koşulsuz iki kat "
                        "olduğunu sandın. Kardeş kromatitler sentromerden bağlı "
                        "kalır; bir sentromer bir kromozom sayılır.",
                    "Yarıya iner: kromozomlar eşlenirken ikiye bölünür, her "
                    "parça yarım kalır":
                        "Eşlenme kopyalamadır, bölme değil. Kromozom sayısının "
                        "yarıya inmesi mayozun sonucudur.",
                    "Değişmez; DNA miktarı da değişmez":
                        "Kromozom sayısı doğru, ama kartlarda DNA ölçümü 2 birimden "
                        "4 birime çıkıyor: eşlenme DNA miktarını iki katına çıkarır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Eşlenme her kromozomun bir kopyasını çıkarır ama kopya "
                    "ayrılmaz; iki kardeş kromatit sentromerden bağlı kalır. DNA "
                    "miktarı iki katına çıkar, kromozom sayısı aynı kalır. "
                    "Sayının döngünün başka bir anında değişip değişmediğini "
                    "kartlarda sentromerleri sayarak bulacaksın."
                ),
                ipuclari=[
                    "Kromozomları sayarken neyi sayarsın: kromatitleri mi, sentromerleri mi?",
                    "DNA ölçümü eşlenmeden önce ve sonra ne gösteriyor?",
                ],
                cozum=(
                    "Eşlenme: DNA × 2, kromozom sayısı aynı.\n"
                    "Anafaz: kromatitler ayrılır, kromozom sayısı × 2.\n"
                    "Bölünme sonu: her yavru hücrede ana hücre kadar kromozom."
                ),
            ),
            sirala_adimi(
                soru=("Kartları hücre döngüsündeki sıraya koy (numaraları sırayla "
                      "yaz):"),
                secenekler=secenekler,
                dogru_sira=dogru_sira,
                aciklama=(
                    "Eşlenmemiş hücre (DNA 2) -> eşlenmiş hücre (DNA 4, zar hâlâ "
                    "sağlam) -> kromozomlar ortada dizilir -> kardeş kromatitler "
                    "kutuplara çekilir -> iki yeni çekirdek ve ara duvar. İlk iki "
                    "kart yalnız DNA ölçümüyle ayrılıyor."
                ),
                ipuclari=[
                    "Görünüşü aynı iki kartı neyle ayırırsın?",
                    "Seri notu nereden başlayıp nerede bittiğini söylüyor.",
                ],
                puan=16,
            ),
            sayi_adimi(
                soru=("DNA ölçümü 4 birim olan, çekirdek zarı sağlam hücrede kaç "
                      "kromozom vardır?"),
                cevap=iki_n,
                aciklama=(
                    "Eşlenme kromozom sayısını değiştirmez: {} kromozom var ve her "
                    "biri iki kardeş kromatitten oluşuyor, yani {} kromatit."
                ).format(iki_n, dort_n),
                yaygin_yanlislar={
                    dort_n:
                        "DNA eşlenmesiyle kromozom sayısının iki katına çıktığını "
                        "sandın ya da kromatitleri saydın. İki kardeş kromatit tek "
                        "sentromere bağlı; bir kromozom sayılır.",
                    n:
                        "Yarıya indirdin. Eşlenme bir bölünme değil; yarıya inme "
                        "mayozda olur.",
                },
                ipuclari=["Sayım kuralına bak: sentromerleri say."],
                puan=12,
            ),
            sayi_adimi(
                soru="Tek kollu yapıların zıt kutuplara çekildiği hücrede kaç kromozom vardır?",
                cevap=dort_n,
                aciklama=(
                    "Anafazda {} kromozomun her birinin kardeş kromatitleri "
                    "ayrıldı. Ayrılan her kromatit kendi sentromeriyle ayrı bir "
                    "kromozom sayılır: {} × 2 = {}. Kromozom sayısının iki katına "
                    "çıktığı an budur -- eşlenme değil."
                ).format(iki_n, iki_n, dort_n),
                yaygin_yanlislar={
                    iki_n:
                        "Ayrılmanın sayıyı değiştirmediğini düşündün. Kardeş "
                        "kromatitler ayrılınca her biri kendi sentromeriyle ayrı "
                        "bir kromozom olur.",
                },
                ipuclari=["Bu hücrede kaç sentromer var? Her tek kollu yapının bir tane."],
                puan=14,
            ),
            yorum_adimi(
                soru="Asistanın eşlenmiş hücre kartına yazdığı not nasıl düzeltilmeli?",
                dogru=("\"{} kromozom, {} kromatit; DNA 4 birim.\"").format(iki_n, dort_n),
                yanlislar={
                    "Düzeltme gerekmez: \"{} kromozom\" doğru.".format(dort_n):
                        "DNA eşlenmesiyle kromozom sayısının koşulsuz iki kat "
                        "olduğunu sandın. Sayı eşlenmede değil, anafazda iki katına "
                        "çıkar.",
                    "\"{} kromozom, {} kromatit; DNA 2 birim.\"".format(iki_n, iki_n):
                        "Kromozom sayısı doğru ama bu hücrenin DNA'sı eşlenmiş: "
                        "ölçüm 4 birim ve her kromozomda iki kromatit var.",
                    "\"{} kromozom; DNA 4 birim.\"".format(n):
                        "Yarıya indirdin. Mitozun hiçbir evresinde kromozom sayısı "
                        "yarıya inmez; her yavru hücre ana hücre kadar kromozom alır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Eşlenmiş hücre: {} kromozom, {} kromatit, DNA 4 birim. Anafaz: "
                    "{} kromozom. Bölünme bitince her yeni hücre yine {} kromozom "
                    "ve 2 birim DNA taşır."
                ).format(iki_n, dort_n, dort_n, iki_n),
                puan=10,
            ),
        ],
        kapanis=("Rapor: seri sıralandı. {} kök ucu: eşlenmiş hücrede {} kromozom "
                 "({} kromatit), anafazda {} kromozom, her yeni hücrede yine {}. "
                 "Asistanın iki notu düzeltildi."
                 ).format(tur.capitalize(), iki_n, dort_n, dort_n, iki_n),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# ATP VE HÜCRESEL ENERJİ (B37.13 -- müfredat haritası)
#
# `atp` iki satırda boştu (2018: 12; 2026: 10). Bağlam: "Hücre modelinde
# enerji gerektiren işleri ayırt etme". `yaygin_yanlis`:
#
#   "ATP'yi hücrenin uzun süreli besin deposu sanmak."
#
# DÜZENEK: bir kas hücresi modelinde ATP stoku, glikojen ve yağ deposu MODEL
# BİRİMİYLE verilmiş (gerçek değer iddia edilmiyor; oranlar gerçekçi): ATP
# sprintte birkaç saniye, glikojen onlarca dakika yetiyor. Personel "enerjiyi
# depolamak için ATP takviyesi" öneriyor.
#
# YANILGININ SAYISAL KARŞILIĞI: ATP süresine glikojenin süresini yazmak (ATP'yi
# uzun süreli depo sanmak) ayrı teşhis alır. "Hangi işler ATP harcar" çoklu
# seçiminde osmoz ve difüzyon da var -- `numune_cozeltisi` göreviyle bağlantı.
# ==========================================================================

_ATP_STOK_HIZ = ((4, 2), (6, 2), (6, 3), (9, 3), (8, 4), (12, 4))   # (stok, birim/s)
_GLIKOJEN_DAKIKA = (20, 30, 45, 60, 90)

# (hücre işi, ATP harcar mı)
_HUCRE_ISLERI = (
    ("Kas liflerinin kasılması", True),
    ("Na⁺/K⁺ pompasıyla iyonların zar boyunca taşınması", True),
    ("Ribozomda protein sentezi", True),
    ("Osmozla hücreye su girmesi", False),
    ("Oksijenin zardan difüzyonu", False),
)


@bulmaca(ders="biyoloji", konu="atp", kademeler=(10, 13), agirlik=1.3)
def enerji_deposu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """ATP anlık enerji taşıyıcısıdır; uzun süreli depo glikojen ve yağdır."""
    stok, hiz = rastgele.choice(_ATP_STOK_HIZ)
    atp_saniye = stok // hiz
    glikojen_dk = rastgele.choice(_GLIKOJEN_DAKIKA)
    glikojen = hiz * 60 * glikojen_dk
    yag_saat = rastgele.choice((20, 40))
    yag = hiz * 3600 * yag_saat
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    sira = list(range(len(_HUCRE_ISLERI)))
    rastgele.shuffle(sira)
    isler = [_HUCRE_ISLERI[i][0] for i in sira]
    atp_harcayan = [n for n, i in enumerate(sira) if _HUCRE_ISLERI[i][1]]

    return Bulmaca(
        kod="biyo-enerji-deposu",
        ders="biyoloji",
        baslik="Enerji Deposu",
        kademe=kademe,
        konu="atp",
        kazanim="ATP'nin anlık enerji taşıyıcısı olduğunu, uzun süreli deponun "
                "glikojen ve yağ olduğunu açıklama; hücrede ATP harcayan işleri "
                "ayırt etme.",
        dikkat=7,
        brifing=(
            "Üssün sağlık birimi, uzun yürüyüşe çıkacak ekibin beslenme planını "
            "hazırlıyor. Laboratuvar bir kas hücresi modeli üzerinde çalışıyor.\n\n"
            "{} bir öneri getirdi: \"ATP hücrenin enerjisi. Ekibe ATP takviyesi "
            "verelim, hücreler enerjiyi ATP olarak depolasın; yol boyunca ondan "
            "harcarlar.\"\n\n"
            "Plan yazılmadan önce hücrenin enerjisini gerçekte nerede, ne kadar "
            "süre için tuttuğunu bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Hücre modeli -- depolar",
                  "Model birimleriyle (1 birim = 1 birim ATP'lik enerji):\n"
                  "Hazır ATP stoku: {} birim.\n"
                  "Glikojen deposu: yıkılınca {} birim ATP üretebilir.\n"
                  "Yağ deposu: yıkılınca {} birim ATP üretebilir."
                  .format(stok, glikojen, yag),
                  bedel=1, kritik=True),
            Kanit("Hücre modeli -- sprint",
                  "Tam güç koşuda hücre saniyede {} birim ATP harcıyor.".format(hiz),
                  bedel=1, kritik=True),
            Kanit("Laboratuvar notu",
                  "Hücre ATP'yi harcadıkça besinleri yıkarak yeniden üretir. "
                  "Sprintte ölçülen ATP miktarı neredeyse sabit kalıyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Hücrede ATP'nin rolü için hangisi doğrudur?",
                dogru=("Anlık enerji taşıyıcısıdır: azdır, hızla harcanır, "
                       "besin yıkımıyla yenilenir"),
                yanlislar={
                    "Uzun süreli besin deposudur; hücre enerjisini ATP olarak "
                    "biriktirir, gerektikçe harcar":
                        "ATP'yi uzun süreli besin deposu sandın. Modeldeki ATP "
                        "stoku sprintte birkaç saniye yetiyor; uzun süreli depolar "
                        "glikojen ve yağ.",
                    "Yalnız kas hücrelerinde bulunur; hareket etmeyen öteki "
                    "hücreler enerji kullanmaz":
                        "Her canlı hücre ATP kullanır: iyon pompalamak ve protein "
                        "yapmak da enerji ister.",
                    "Besin yıkımına gerek olmadan kendiliğinden oluşur, "
                    "hücrede hep hazır bulunur":
                        "ATP üretmek enerji ister; o enerji glikoz ve yağ gibi "
                        "besinlerin yıkımından gelir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "ATP hücrenin 'bozuk parası'dır: her enerjili iş onunla ödenir, "
                    "ama cepte az bulunur. Hücre onu dakikada defalarca harcayıp "
                    "yeniden üretir. Enerji uzun süre glikojen ve yağ olarak "
                    "saklanır; gerektikçe bunlar yıkılıp ATP'ye çevrilir."
                ),
                ipuclari=[
                    "Hazır ATP stoku sprintte ne kadar dayanır?",
                    "Laboratuvar notu ATP miktarı hakkında ne diyor?",
                ],
                cozum=(
                    "Süre = stok ÷ harcama hızı\n"
                    "ATP: saniyeler\nGlikojen: dakikalar\nYağ: saatler"
                ),
            ),
            sayi_adimi(
                soru="Hazır ATP stoku, yenilenmeseydi sprintte kaç saniye yeterdi?",
                cevap=atp_saniye,
                birim="s",
                aciklama="{} birim ÷ {} birim/s = {} s.".format(stok, hiz, atp_saniye),
                yaygin_yanlislar={
                    glikojen // hiz:
                        "Glikojen deposunun süresini yazdın. ATP'yi uzun süreli "
                        "depo sandın; ATP stoku yalnız birkaç saniyelik.",
                    stok:
                        "Stok miktarını yazdın; süre için harcama hızına böl.",
                    stok * hiz:
                        "Böleceğin yerde çarptın: süre = stok ÷ hız.",
                },
                ipuclari=["Stoku saniyedeki harcamaya böl."],
                puan=12,
            ),
            sayi_adimi(
                soru="Glikojen deposu aynı hızla kaç dakika ATP üretebilir?",
                cevap=glikojen_dk,
                birim="dk",
                aciklama="{} ÷ {} = {} s = {} dk.".format(
                    glikojen, hiz, glikojen // hiz, glikojen_dk),
                yaygin_yanlislar={
                    glikojen // hiz:
                        "Saniyeyi buldun ama dakikaya çevirmedin.",
                    atp_saniye:
                        "ATP stokunun süresini yazdın; soru glikojen deposunu soruyor.",
                },
                ipuclari=["Önce saniyeyi bul, sonra dakikaya çevir."],
                puan=12,
            ),
            coklu_adimi(
                soru="Bu işlerden hangileri ATP harcar? (numaraları virgülle yaz)",
                secenekler=isler,
                dogru_indeksler=atp_harcayan,
                aciklama=(
                    "Kas kasılması, iyon pompası ve protein sentezi enerji ister. "
                    "Osmoz ve difüzyon pasif taşımadır: maddeler derişim farkıyla "
                    "kendiliğinden geçer, ATP harcanmaz."
                ),
                ipuclari=["Madde derişim farkının tersine mi taşınıyor, yönünde mi?"],
                puan=12,
            ),
            yorum_adimi(
                soru="\"Hücreler enerjiyi ATP olarak depolasın\" önerisi için hangisi doğru?",
                dogru=("Yanlış: ATP birkaç saniyelik stoktur; yürüyüşün "
                       "enerjisi glikojen ve yağdan gelir"),
                yanlislar={
                    "Doğru: ATP hücrenin uzun süreli enerji deposudur; her iş "
                    "onunla ödendiğine göre depo da o":
                        "ATP'yi uzun süreli besin deposu sandın. Modelde ATP stoku "
                        "{} saniye, glikojen {} dakika yetiyor.".format(
                            atp_saniye, glikojen_dk),
                    "Doğru, ama yalnız sprint için; yürüyüş hafif iştir, orada "
                    "ATP hiç kullanılmaz":
                        "Her kasılma ATP harcar -- yürürken de. Fark, harcanan "
                        "ATP'nin hangi depodan yenilendiğinde.",
                    "Yanlış: hücre enerjiyi yalnız yağ olarak depolar ve yakar, "
                    "ATP hiç kullanmaz":
                        "Depo konusunda kısmen haklısın, ama hücre her enerjili işi "
                        "ATP ile yapar; glikojen de bir depodur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Hazır ATP {} saniye, glikojen {} dakika, yağ {} saat yetecek "
                    "kadar. Uzun yürüyüşün planı ATP'ye değil, glikojeni ve yağı "
                    "dolduracak beslenmeye dayanmalı."
                ).format(atp_saniye, glikojen_dk, yag_saat),
                puan=10,
            ),
        ],
        kapanis=("Beslenme planına not: \"ATP depo değil, bozuk para.\" Hazır ATP "
                 "{} saniye, glikojen {} dakika, yağ {} saat yetiyor; plan "
                 "karbonhidrat ve yağ depolarına göre yazıldı."
                 ).format(atp_saniye, glikojen_dk, yag_saat),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# SİNİR VE HORMON İLETİMİ (B37.13 -- müfredat haritası)
#
# `sinir_duyu` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Sefer
# biyoloji arşivinde uyaran-tepki zincirini tamamlama". `yaygin_yanlis`:
#
#   "Sinir ile hormon iletimini aynı süreç saymak."
#
# DÜZENEK: nöbetçi sıcak bir boruya dokunuyor. İki tepki: el çekme refleksi
# (impuls nöronlar boyunca, milisaniyeler) ve ardından yükselen nabız
# (adrenalin kanla, saniyeler; etkisi dakikalar sürer). Model değerleri:
# iletim hızı 40-100 m/s, sinaptik gecikme ihmal.
#
# YANILGININ SAYISAL KARŞILIĞI: iki iletimin süresini birbirine karıştırmak
# (impuls süresine kanla taşınma süresini yazmak) ve iki süreyi birim
# çevirmeden karşılaştırmak ayrı teşhis alır; zincir sorusunda adrenalinin
# taşıyıcısına "motor nöron" demek yanılgının şıkkı.
# ==========================================================================

def _iletim_havuzu():
    """(yol_cm, hiz, kan_s): impuls yolu cm, iletim hızı m/s, adrenalinin
    kalbe ulaşma süresi s.

    Koşullar:
      1. İmpuls süresi TAM SAYI milisaniye.
      2. Oran (kan süresi ÷ impuls süresi) tam sayı; birim çevirmeden
         bulunan oran (s ÷ ms) en çok iki ondalık.
    """
    havuz = []
    for yol_cm in (120, 150, 160, 200):
        for hiz in (40, 50, 60, 80, 100):
            if (yol_cm * 10) % hiz:
                continue
            ms = yol_cm * 10 // hiz
            for kan_s in (6, 8, 10, 12, 15):
                if (kan_s * 1000) % ms or (kan_s * 100) % ms:
                    continue
                havuz.append((yol_cm, hiz, kan_s))
    return tuple(havuz)


_ILETIM = _iletim_havuzu()


@bulmaca(ders="biyoloji", konu="sinir_duyu", kademeler=(11, 13), agirlik=1.3)
def uyari_zinciri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sinirsel iletim hızlı ve kısa, hormonal iletim kanla yavaş ve uzun süreli."""
    yol_cm, hiz, kan_s = rastgele.choice(_ILETIM)
    ms = yol_cm * 10 // hiz
    oran = kan_s * 1000 // ms
    etki_dk = rastgele.choice((3, 5, 10))
    kisi, nobetci = ad_sec(rastgele, PERSONEL, 2)

    impuls_yanlislari = {
        sy(ms / 1000.0).replace(",", "."):
            "Saniyeyi buldun ama milisaniyeye çevirmedin (× 1000).",
        kan_s * 1000:
            "Adrenalinin kanla ulaşma süresini yazdın. Sinir ile hormon "
            "iletimini aynı süreç saydın; refleksin süresi impuls yolundan ve "
            "iletim hızından hesaplanır.",
    }
    if yol_cm * hiz not in impuls_yanlislari:
        impuls_yanlislari[yol_cm * hiz] = "Böleceğin yerde çarptın: süre = yol ÷ hız."

    return Bulmaca(
        kod="biyo-uyari-zinciri",
        ders="biyoloji",
        baslik="Uyarı Zinciri",
        kademe=kademe,
        konu="sinir_duyu",
        kazanim="Sinirsel ve hormonal iletimi hız, süre ve taşıyıcı bakımından "
                "karşılaştırma; uyaran-tepki zincirini tamamlama.",
        dikkat=7,
        brifing=(
            "Sefer arşivindeki bir biyoloji kaydı yarım kalmış. {} kazan dairesinde "
            "sıcak bir boruya dokunmuş: eli anında geri çekilmiş, birkaç saniye "
            "sonra da kalbi hızla çarpmaya başlamış ve uzun süre sakinleşmemiş.\n\n"
            "Kaydı tamamlayan {} iki tepkiyi tek satırda birleştirmiş: \"İkisi "
            "de sinirlerle iletildi; nabız sadece biraz geç yükseldi.\"\n\n"
            "Kayıt arşive girmeden önce iki tepkinin nasıl iletildiğini "
            "bulmamız gerekiyor."
        ).format(nobetci, kisi),
        kanitlar=[
            Kanit("Refleks ölçümü",
                  "Parmak ucundan omuriliğe ve oradan kol kasına impuls yolu: {} cm. "
                  "İletim hızı: {} m/s. (Model: sinaptik gecikme ihmal.)"
                  .format(yol_cm, hiz),
                  bedel=1, kritik=True),
            Kanit("Nabız kaydı",
                  "Böbrek üstü bezinden salgılanan adrenalin kanla {} saniyede "
                  "kalbe ulaştı. Nabız yaklaşık {} dakika yüksek kaldı."
                  .format(kan_s, etki_dk),
                  bedel=1, kritik=True),
            Kanit("Arşiv şeması",
                  "Uyaran -> reseptör -> ? -> tepki. İki tepki için iki ayrı satır "
                  "açılmış; ikisinin de ortası boş.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="El çekme refleksi ile nabzın yükselmesini hangisi doğru ayırır?",
                dogru=("Refleks impulsla nöronlarda iletilir: hızlı, kısa, tek "
                       "hedef; adrenalin kanla: yavaş, uzun, birçok organ"),
                yanlislar={
                    "İkisi aynı süreçtir: adrenalin de sinirler boyunca "
                    "iletilir, yalnız yolu uzun olduğu için biraz geç kalır":
                        "Sinir ile hormon iletimini aynı süreç saydın. Adrenalin "
                        "bir bezden kana salgılanır ve kanla taşınır; impuls ise "
                        "nöronların zarında ilerler.",
                    "İkisi de kanla taşınır; refleks yalnız daha yakın bir "
                    "bezden gelir, o yüzden kola çabuk ulaşır":
                        "Refleksin taşıyıcısı kan değil: impuls nöronlar boyunca "
                        "saniyede onlarca metre ilerler.",
                    "Refleks kanla, adrenalin sinirle iletilir; kan her yere "
                    "hemen ulaşır, sinir sinyali beyinden dolaşarak gelir":
                        "Tersi: hızlı olan sinirsel iletim, yavaş ve uzun süreli "
                        "olan hormonal iletim.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sinirsel iletimde sinyal nöronların zarı boyunca elektriksel "
                    "impuls olarak ilerler ve belli bir kasa ulaşır: milisaniyeler. "
                    "Hormonal iletimde bez, hormonu kana bırakır; kan onu bütün "
                    "vücuda taşır, etkisi yavaş başlar ve uzun sürer."
                ),
                ipuclari=[
                    "Refleks ölçümünde ve nabız kaydında taşıyıcı ne?",
                    "Hangi tepki daha uzun sürdü?",
                ],
                cozum=(
                    "Sinir: impuls, nöron, ms, kısa süreli.\n"
                    "Hormon: kan, bez, saniye-dakika, uzun süreli."
                ),
            ),
            sayi_adimi(
                soru="İmpuls parmak ucundan kol kasına kaç milisaniyede ulaşır?",
                cevap=ms,
                birim="ms",
                aciklama="{} cm = {} m. Süre = {} m ÷ {} m/s = {} s = {} ms.".format(
                    yol_cm, sy(yol_cm / 100.0), sy(yol_cm / 100.0), hiz,
                    sy(ms / 1000.0), ms),
                yaygin_yanlislar=impuls_yanlislari,
                ipuclari=["Önce santimetreyi metreye çevir."],
                puan=12,
            ),
            sayi_adimi(
                soru="Adrenalin kalbe, impulsun kasa ulaşmasından kaç kat daha geç ulaşır?",
                cevap=oran,
                birim="kat",
                aciklama="{} s = {} ms. {} ÷ {} = {} kat.".format(
                    kan_s, kan_s * 1000, kan_s * 1000, ms, oran),
                yaygin_yanlislar={
                    sy(kan_s / float(ms)).replace(",", "."):
                        "Saniyeyi milisaniyeye bölerek birim çevirmeden "
                        "karşılaştırdın; önce ikisini aynı birime getir.",
                },
                ipuclari=["İki süreyi aynı birime çevirip böl."],
                puan=12,
            ),
            secim_adimi(
                soru="Arşiv şemasında nabız satırının boş kutusuna ne yazılmalı?",
                dogru="Böbrek üstü bezi -> kan (hormon: adrenalin)",
                yanlislar={
                    "Omurilik -> motor nöron (impuls)":
                        "Sinir ile hormon iletimini aynı süreç saydın. Bu el çekme "
                        "refleksinin yolu; nabzı yükselten adrenalin kanla taşındı.",
                    "Duyu nöronu -> beyin (impuls: sıcaklık bilgisi)":
                        "Duyu nöronu sıcaklık bilgisini taşır ama nabzı uzun süre "
                        "yüksek tutan kandaki adrenalindir.",
                    "Kan dolaşımı -> omurilik (hormon: adrenalin)":
                        "Hormon kanla hedef organa, burada kalbe gider; omurilikte "
                        "bir impulsa dönüşmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Nabız satırı: sıcak boru -> deri reseptörleri -> böbrek üstü "
                    "bezi, adrenalin, kan -> kalp. Refleks satırı: deri "
                    "reseptörleri -> duyu nöronu -> omurilik -> motor nöron -> kol "
                    "kası. Aynı uyaran, iki ayrı iletim yolu."
                ),
                ipuclari=["Nabız kaydında adrenalin kalbe neyle ulaştı?"],
                puan=12,
            ),
        ],
        kapanis=("Kayıt iki satıra ayrıldı: refleks impulsla {} milisaniyede, adrenalin "
                 "kanla {} saniyede -- {} kat geç -- ve etkisi {} dakika sürdü. "
                 "\"İkisi de sinirle\" ifadesi silindi."
                 ).format(ms, kan_s, oran, etki_dk),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# HÜCRESEL SOLUNUM VE FERMANTASYON (B37.13 -- müfredat haritası)
#
# `hucresel_solunum` iki satırda boştu (2018: 12; 2026: 10). Bağlam: "Hücrenin
# farklı koşullardaki enerji yollarını karşılaştırma". `yaygin_yanlis`:
#
#   "Fermantasyon ile oksijensiz solunumu aynı saymak."
#
# DÜZENEK: üssün iki oksijensiz tankı. Ekmek hamurundaki maya FERMANTASYON
# yapıyor (elektron taşıma sistemi yok, ATP yalnız glikolizden). Arıtma
# tankındaki bakteri NİTRATLA OKSİJENSİZ SOLUNUM yapıyor (elektron taşıma
# sistemi var, son elektron alıcısı nitrat). Glikoz başına ATP değerleri
# MODEL DEĞERİ olarak verilir; oksijensiz solunumun verimi türden türe
# değiştiği için gerçek değer iddia edilmez, yalnız sıralama gerçek.
#
# YANILGININ SAYISAL KARŞILIĞI: bakteriye fermantasyonun 2 ATP'sini uygulamak
# -> gereken glikoz sayısı ayrı teşhis alır; son elektron alıcısına pirüvat
# demek şık teşhisidir.
# ==========================================================================

_SOLUNUM_ATP = {"oksijenli": 32, "nitratla": 24, "fermantasyon": 2}   # model
_ATP_IHTIYACI = (960, 1920, 2880, 4800)   # 2, 24 ve 32'ye bölünür


@bulmaca(ders="biyoloji", konu="hucresel_solunum", kademeler=(10, 13), agirlik=1.3)
def iki_tank(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Fermantasyonda ETS yok ve verim düşük; oksijensiz solunumda ETS ve inorganik alıcı var."""
    ihtiyac = rastgele.choice(_ATP_IHTIYACI)
    ferm, nitrat, oksijenli = (_SOLUNUM_ATP["fermantasyon"], _SOLUNUM_ATP["nitratla"],
                               _SOLUNUM_ATP["oksijenli"])
    maya_glikoz = ihtiyac // ferm
    bakteri_glikoz = ihtiyac // nitrat
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-iki-tank",
        ders="biyoloji",
        baslik="İki Tank",
        kademe=kademe,
        konu="hucresel_solunum",
        kazanim="Fermantasyon ile oksijensiz solunumu elektron taşıma sistemi, son "
                "elektron alıcısı ve ATP verimi bakımından ayırt etme; aynı enerji "
                "ihtiyacı için gereken glikozu karşılaştırma.",
        dikkat=7,
        brifing=(
            "Üssün iki kapalı tankında oksijen yok. Mutfaktaki hamur tankında "
            "maya çalışıyor; arıtma tesisinin dip tankında nitrat kullanan "
            "bakteriler.\n\n"
            "{} ikisinin besin ihtiyacını tek kalemde hesaplamak istiyor: "
            "\"Oksijen yoksa hepsi fermantasyon yapar; ikisine de aynı miktarda "
            "glikoz yeter.\"\n\n"
            "Glikoz siparişi verilmeden önce iki tankta hangi enerji yolunun "
            "çalıştığını ve ne kadar glikoz gerektiğini bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Hamur tankı kaydı",
                  "Maya hücreleri: oksijen yok. Ürünler: etil alkol ve CO₂. "
                  "Hücrelerde elektron taşıma sistemi çalışmıyor.",
                  bedel=1, kritik=True),
            Kanit("Arıtma tankı kaydı",
                  "Bakteriler: oksijen yok. Nitrat (NO₃⁻) harcanıyor, azot gazı "
                  "çıkıyor. Hücre zarındaki elektron taşıma sistemi çalışıyor.",
                  bedel=1, kritik=True),
            Kanit("Model tablosu -- glikoz başına net ATP",
                  "Oksijenli solunum: {}\nNitratla oksijensiz solunum: {}\n"
                  "Fermantasyon: {}\n(Model değerleri; sıralama gerçektir.)"
                  .format(oksijenli, nitrat, ferm),
                  bedel=1, kritik=True),
            Kanit("Günlük ihtiyaç",
                  "Her iki tanktaki hücre topluluğu günde {} ATP harcıyor."
                  .format(ihtiyac),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Fermantasyonu oksijensiz solunumdan ayıran nedir?",
                dogru=("Oksijensiz solunumda ETS çalışır, son alıcı nitrat gibi "
                       "inorganiktir; fermantasyonda ETS yoktur"),
                yanlislar={
                    "Hiçbir şey: ikisinde de oksijen yok, yani ikisi aynı "
                    "süreçtir; farklı adlar aynı şeyi anlatır":
                        "Fermantasyon ile oksijensiz solunumu aynı saydın. Oksijenin "
                        "yokluğu ortak; ama arıtma tankında elektron taşıma sistemi "
                        "çalışıyor, hamur tankında çalışmıyor.",
                    "Fermantasyonda oksijen kullanılır, oksijensiz solunumda "
                    "kullanılmaz; adı zaten oksijensiz diyor":
                        "İki tankta da oksijen yok; fermantasyon oksijen kullanmaz.",
                    "Oksijensiz solunum yalnız hayvan hücresinde, fermantasyon yalnız bakteride olur":
                        "Kayıtlar tersini gösteriyor: fermantasyonu maya, oksijensiz "
                        "solunumu bakteri yapıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İkisi de oksijensizdir ama farklı yollardır. Oksijensiz "
                    "solunum, oksijenli solunum gibi elektron taşıma sistemini "
                    "kullanır; yalnız son elektron alıcısı oksijen değil nitrat, "
                    "sülfat gibi bir moleküldür ve çok daha fazla ATP çıkar. "
                    "Fermantasyonda bu sistem yoktur; glikoliz yeniden dönebilsin "
                    "diye elektronlar organik bir moleküle aktarılır."
                ),
                ipuclari=[
                    "İki tank kaydında elektron taşıma sistemi için ne yazıyor?",
                    "Arıtma tankında harcanan inorganik molekül hangisi?",
                ],
                cozum=(
                    "Fermantasyon: ETS yok, alıcı organik, verim düşük.\n"
                    "Oksijensiz solunum: ETS var, alıcı inorganik (NO₃⁻), verim yüksek."
                ),
            ),
            sayi_adimi(
                soru="Hamur tankındaki maya günlük ihtiyacı için kaç glikoz yıkar?",
                cevap=maya_glikoz,
                aciklama="Fermantasyon: {} ÷ {} = {} glikoz.".format(
                    ihtiyac, ferm, maya_glikoz),
                yaygin_yanlislar={
                    ihtiyac // oksijenli:
                        "Oksijenli solunumun verimini kullandın; hamurda oksijen yok.",
                    ihtiyac // nitrat:
                        "Oksijensiz solunumun verimini kullandın; maya fermantasyon "
                        "yapıyor, elektron taşıma sistemi çalışmıyor.",
                    ihtiyac * ferm:
                        "Böleceğin yerde çarptın: glikoz = ATP ÷ glikoz başına ATP.",
                },
                ipuclari=["Hamur tankında hangi enerji yolu çalışıyor?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Arıtma tankındaki bakteri aynı günlük ihtiyaç için kaç glikoz yıkar?",
                cevap=bakteri_glikoz,
                aciklama="Nitratla oksijensiz solunum: {} ÷ {} = {} glikoz.".format(
                    ihtiyac, nitrat, bakteri_glikoz),
                yaygin_yanlislar={
                    maya_glikoz:
                        "Fermantasyon ile oksijensiz solunumu aynı saydın. Bakteride "
                        "elektron taşıma sistemi çalışıyor; glikoz başına çok daha "
                        "fazla ATP çıkıyor.",
                    ihtiyac // oksijenli:
                        "Oksijenli solunumun verimini kullandın; tankta oksijen yok.",
                },
                ipuclari=["Model tablosunda arıtma tankına uyan satırı bul."],
                puan=12,
            ),
            secim_adimi(
                soru="Arıtma tankındaki bakterilerde son elektron alıcısı hangisidir?",
                dogru="Nitrat (NO₃⁻)",
                yanlislar={
                    "Pirüvat ya da ondan türeyen organik bir molekül":
                        "Fermantasyon ile oksijensiz solunumu aynı saydın. Organik "
                        "alıcı fermantasyonun özelliği; bu tankta ETS çalışıyor ve "
                        "harcanan molekül nitrat.",
                    "Oksijen (O₂)":
                        "Tankta oksijen yok; oksijen son alıcı olsaydı bu oksijenli "
                        "solunum olurdu.",
                    "Etil alkol":
                        "Etil alkol hamur tankındaki fermantasyonun ürünü, bir "
                        "elektron alıcısı değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kayıtta nitrat harcanıyor ve azot gazı çıkıyor: elektronlar ETS "
                    "sonunda nitrata aktarılıyor. Bu, inorganik alıcılı oksijensiz "
                    "solunumdur."
                ),
                ipuclari=["Arıtma tankı kaydında ne harcanıyor, ne çıkıyor?"],
                puan=12,
            ),
        ],
        kapanis=("Sipariş iki kaleme ayrıldı: maya günde {} glikoz, bakteri {} glikoz "
                 "yıkıyor. İkisi de oksijensiz ama aynı yol değil -- arıtma "
                 "tankındaki elektron taşıma sistemi farkı {} kat."
                 ).format(maya_glikoz, bakteri_glikoz, maya_glikoz // bakteri_glikoz),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# SOLUK ALMA VE HÜCRESEL SOLUNUM (B37.13 -- müfredat haritası)
#
# `solunum_sistemi` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Verilen
# gaz alışverişi şemasını tamamlayıp açıklama". `yaygin_yanlis`:
#
#   "Soluk alma ile hücresel solunumu eşitlemek."
#
# DÜZENEK: dalgıç adayının solunum ölçümü. Soluk alınan havada O₂ %21,
# verilen havada %16 (ders kitabı değerleri). Sonra aday nefesini tutuyor:
# SOLUK ALMA duruyor ama hücreler O₂ harcamayı SÜRDÜRÜYOR (kandaki O₂'den).
#
# YANILGININ SAYISAL KARŞILIĞI: nefes tutulurken harcanan O₂'ye 0 demek (iki
# süreci eşitlemek) ayrı teşhis alır; şemada ATP üretimini alveole yazmak
# şık teşhisidir.
# ==========================================================================

_NEFES_HACMI = (500, 600)          # mL, soluk başına
_NEFES_SIKLIGI = (12, 14, 15, 16, 20)   # dakikada
_NEFES_TUTMA = (30, 45, 60)        # s


@bulmaca(ders="biyoloji", konu="solunum_sistemi", kademeler=(11, 13), agirlik=1.3)
def nefes_olcumu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Soluk alma hava taşır; hücresel solunum hücrede O₂ kullanıp ATP üretir."""
    while True:
        hacim = rastgele.choice(_NEFES_HACMI)
        siklik = rastgele.choice(_NEFES_SIKLIGI)
        tutma = rastgele.choice(_NEFES_TUTMA)
        o2_dakika = hacim * siklik * 5 // 100
        if (o2_dakika * tutma) % 60 == 0:
            break
    harcanan = o2_dakika * tutma // 60
    kisi, dalgic = ad_sec(rastgele, PERSONEL, 2)

    return Bulmaca(
        kod="biyo-nefes-olcumu",
        ders="biyoloji",
        baslik="Nefes Ölçümü",
        kademe=kademe,
        konu="solunum_sistemi",
        kazanim="Soluk alıp vermeyi (hava taşınması), gaz alışverişini ve hücresel "
                "solunumu (hücrede O₂ kullanımı ve ATP üretimi) ayırt etme; gaz "
                "alışverişi şemasını tamamlama.",
        dikkat=7,
        brifing=(
            "Sağlık birimi dalgıç adaylarının solunum ölçümünü yapıyor. Şemanın "
            "bir kutusu boş kaldı.\n\n"
            "{} rapora şunu yazmak istiyor: \"Solunum, akciğerde olan bir olay. "
            "{} nefesini tuttuğu sürece solunumu da durdu; o arada vücudu hiç "
            "oksijen harcamadı.\"\n\n"
            "Rapor imzalanmadan önce ölçümleri yorumlamamız gerekiyor."
        ).format(kisi, dalgic),
        kanitlar=[
            Kanit("Solunum ölçümü",
                  "{}: dakikada {} soluk, her solukta {} mL hava.\n"
                  "Soluk alınan havada O₂: %21. Verilen havada O₂: %16."
                  .format(dalgic, siklik, hacim),
                  bedel=1, kritik=True),
            Kanit("Nefes tutma kaydı",
                  "{} nefesini {} saniye tuttu. Bu sürede kandaki O₂ düştü, CO₂ "
                  "yükseldi. Hücrelerin O₂ kullanım hızı ölçüm öncesiyle aynı kaldı."
                  .format(dalgic, tutma),
                  bedel=1, kritik=True),
            Kanit("Gaz alışverişi şeması",
                  "Hava -> burun, soluk borusu -> alveol (O₂ kana, CO₂ havaya) -> "
                  "kan -> [ ? : O₂ kullanılır, CO₂ ve ATP üretilir ] -> kan -> "
                  "alveol -> dışarı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Soluk alma ile hücresel solunum arasındaki ilişki için hangisi doğru?",
                dogru=("Ayrı süreçler: soluk alma O₂ getirir; hücresel solunum "
                       "hücrede besini O₂ ile yıkıp ATP üretir"),
                yanlislar={
                    "İkisi aynı süreçtir: soluk alırken akciğerde ATP "
                    "üretilir; ikisine de solunum denmesi bundandır":
                        "Soluk alma ile hücresel solunumu eşitledin. Akciğer havayı "
                        "yalnız taşır ve gazları kana geçirir; ATP vücudun bütün "
                        "hücrelerinde üretilir.",
                    "Hücresel solunum yalnız akciğer hücrelerinde olur; O₂ "
                    "ilk olarak ve en çok oraya gelir":
                        "Her canlı vücut hücresi O₂ kullanır; akciğer yalnız gaz "
                        "alışverişinin yapıldığı yer.",
                    "Soluk verme hücresel solunumun kendisidir; CO₂ akciğerde "
                    "üretilir, çünkü dışarı oradan çıkıyor":
                        "CO₂ hücrelerde üretilir, kanla akciğere taşınır ve soluk "
                        "vermeyle dışarı atılır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Üç ayrı olay var: soluk alıp verme (hava hareketi), alveolde "
                    "gaz alışverişi (difüzyon) ve hücresel solunum (hücrede O₂ "
                    "kullanımı, ATP üretimi). Nefes tutulunca birincisi durur; "
                    "hücreler kandaki O₂'yi kullanmaya devam eder."
                ),
                ipuclari=[
                    "Nefes tutma kaydında hücrelerin O₂ kullanımı için ne yazıyor?",
                    "ATP hangi yapıda üretilir?",
                ],
                cozum=(
                    "Soluk alma: hava -> akciğer.\n"
                    "Gaz alışverişi: alveol <-> kan.\n"
                    "Hücresel solunum: hücre (mitokondri), O₂ + besin -> CO₂ + su + ATP."
                ),
            ),
            sayi_adimi(
                soru="Dakikada kana kaç mL O₂ geçer?",
                cevap=o2_dakika,
                birim="mL",
                aciklama=(
                    "Dakikadaki hava: {} × {} = {} mL. Kana geçen O₂ payı %21 − %16 "
                    "= %5: {} × 5 ÷ 100 = {} mL."
                ).format(siklik, hacim, siklik * hacim, siklik * hacim, o2_dakika),
                yaygin_yanlislar={
                    hacim * siklik * 21 // 100:
                        "Soluk alınan havadaki O₂'nin tamamının kana geçtiğini "
                        "varsaydın; verilen havada hâlâ %16 O₂ var.",
                    hacim * siklik:
                        "Havanın tamamını O₂ saydın; havanın yalnız bir kısmı O₂.",
                    hacim * siklik * 16 // 100:
                        "Verilen havadaki O₂ miktarını yazdın; kana geçen, "
                        "alınanla verilen arasındaki fark.",
                },
                ipuclari=["Alınan ve verilen havadaki O₂ yüzdelerinin farkını kullan."],
                puan=12,
            ),
            sayi_adimi(
                soru="Nefes tutulan sürede hücreler kaç mL O₂ harcadı?",
                cevap=harcanan,
                birim="mL",
                aciklama=(
                    "Hücrelerin O₂ kullanımı sürdü: dakikada {} mL, yani {} saniyede "
                    "{} × {} ÷ 60 = {} mL. Bu O₂ kandaki depodan geldi."
                ).format(o2_dakika, tutma, o2_dakika, tutma, harcanan),
                yaygin_yanlislar={
                    0:
                        "Soluk alma ile hücresel solunumu eşitledin: soluk alma "
                        "durdu diye hücrelerin de durduğunu sandın. Kayıt, O₂ "
                        "kullanım hızının değişmediğini söylüyor.",
                    o2_dakika * tutma:
                        "Dakikadaki miktarı saniyeyle çarptın; önce saniyedeki "
                        "miktara çevir.",
                },
                ipuclari=["Hücrelerin O₂ kullanım hızı değişti mi?"],
                puan=12,
            ),
            secim_adimi(
                soru="Gaz alışverişi şemasındaki boş kutu hangi yeri gösterir?",
                dogru="Vücut hücrelerinin mitokondrileri",
                yanlislar={
                    "Akciğer alveolleri":
                        "Soluk alma ile hücresel solunumu eşitledin. Alveolde "
                        "yalnız gaz alışverişi olur; O₂ kullanılıp ATP üretilen yer "
                        "hücreler.",
                    "Burun ve soluk borusu (havanın ilk durağı)":
                        "Burası havanın geçtiği yol; burada gaz alışverişi de, "
                        "ATP üretimi de olmaz.",
                    "Kan plazması (kanın sıvı kısmı)":
                        "Kan gazları taşır; O₂'yi kullanıp ATP üreten hücrelerdir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "O₂ kullanılıp CO₂ ve ATP üretilen yer, vücut hücrelerinin "
                    "mitokondrileridir: hücresel solunum. Şemanın geri kalanı -- "
                    "burun, alveol, kan -- taşıma ve gaz alışverişi."
                ),
                ipuclari=["Kutuda ATP üretildiği yazıyor."],
                puan=12,
            ),
        ],
        kapanis=("Rapor düzeltildi: nefes tutulunca soluk alma durdu, hücresel "
                 "solunum durmadı -- {} saniyede {} mL O₂ harcandı. Şemadaki boş "
                 "kutuya \"vücut hücreleri (mitokondri)\" yazıldı."
                 ).format(tutma, harcanan),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# SİNDİRİM, EMİLİM VE BESİNİN HÜCREYE YOLU (B37.13 -- müfredat haritası)
#
# `sindirim` iki satırda boştu (2018: 11; 2026: 10). Bağlam: "Bir besinin
# hücreye ulaşıncaya kadarki yolunu izleme". `yaygin_yanlis`:
#
#   "Sindirim ile hücresel solunumu aynı süreç saymak."
#
# DÜZENEK: ekmekteki bir nişasta parçasının yolu. Sindirim, sindirim
# kanalında büyük molekülü (su ile) glikoz birimlerine AYIRIR ve ATP
# ÜRETMEZ; ATP, glikoz hücreye ulaşıp hücresel solunumla yıkılınca çıkar.
# Glikoz başına ATP, `iki_tank` göreviyle aynı MODEL DEĞERİ: 32.
#
# YANILGININ SAYISAL KARŞILIĞI: "sindirim sırasında kaç ATP üretilir"
# sorusuna solunumun ATP'sini yazmak ayrı teşhis alır; ATP'nin üretildiği
# yere "ince bağırsak" demek şık teşhisidir.
# ==========================================================================

_GLIKOZ_ATP_MODEL = 32
_NISASTA_BIRIMI = (6, 8, 10, 12, 20)

# Besinin yolu, doğru sırayla
_BESIN_YOLU = (
    "Ağız: tükürükteki enzim nişastayı parçalamaya başlar",
    "İnce bağırsak: nişasta glikoz birimlerine kadar parçalanır",
    "Bağırsak tüyü (villus): glikoz bağırsak duvarından kana geçer",
    "Kan: glikoz vücut hücrelerine taşınır",
    "Kas hücresi: glikoz oksijenle yıkılır, ATP üretilir",
)


@bulmaca(ders="biyoloji", konu="sindirim", kademeler=(10, 13), agirlik=1.3)
def besin_yolu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sindirim besini parçalar ve ATP üretmez; ATP hücrede solunumla üretilir."""
    birim = rastgele.choice(_NISASTA_BIRIMI)
    atp = birim * _GLIKOZ_ATP_MODEL
    karisik = list(range(len(_BESIN_YOLU)))
    rastgele.shuffle(karisik)
    kartlar = [_BESIN_YOLU[i] for i in karisik]
    dogru_sira = [karisik.index(i) for i in range(len(_BESIN_YOLU))]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-besin-yolu",
        ders="biyoloji",
        baslik="Besin Yolu",
        kademe=kademe,
        konu="sindirim",
        kazanim="Sindirim, emilim, taşınma ve hücresel solunumu sırasıyla izleme; "
                "sindirimin ATP üretmediğini, ATP'nin hücrede solunumla "
                "üretildiğini açıklama.",
        dikkat=7,
        brifing=(
            "Okul çadırındaki beslenme dersi için bir afiş hazırlanıyor: bir "
            "lokma ekmekteki nişastanın kas hücresine kadar yolu.\n\n"
            "{} afişe şu cümleyi yazdı: \"Sindirim, besinden enerji elde etme "
            "işidir; ekmek ince bağırsakta sindirilirken kaslarımızın ATP'si "
            "üretilir.\"\n\n"
            "Afiş asılmadan önce cümlenin doğru olup olmadığını bulmamız ve yolun "
            "kartlarını sıraya koymamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Laboratuvar notu -- nişasta",
                  "İncelenen nişasta parçası {} glikoz biriminden oluşuyor. "
                  "Sindirim enzimleri bağları suyla kopararak parçayı glikozlara "
                  "ayırıyor; bu sırada ATP ölçülmedi.".format(birim),
                  bedel=1, kritik=True),
            Kanit("Model tablosu",
                  "Oksijenli solunumda glikoz başına net ATP: {} (model değeri)."
                  .format(_GLIKOZ_ATP_MODEL),
                  bedel=1, kritik=True),
            Kanit("Yol kartları",
                  "Beş kart karışık: nişastanın ağızdan kas hücresine kadar "
                  "geçtiği yerler.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Sindirim ile hücresel solunum arasındaki fark için hangisi doğru?",
                dogru=("Sindirim kanalda besini küçük birimlere ayırır, ATP "
                       "üretmez; solunum hücrede glikozu yıkıp ATP üretir"),
                yanlislar={
                    "İkisi aynı süreçtir: besin sindirilirken ATP açığa çıkar; "
                    "parçalanan besinin enerjisi hemen serbest kalır":
                        "Sindirim ile hücresel solunumu aynı süreç saydın. Sindirim "
                        "yalnız parçalar; enerjiyi ATP'ye aktaran, hücrenin içindeki "
                        "solunumdur.",
                    "Sindirim hücrelerin mitokondrisinde olur; besinleri "
                    "parçalayan organel mitokondridir":
                        "Sindirim hücre dışında, sindirim kanalının boşluğunda olur; "
                        "mitokondri hücresel solunumun yeridir.",
                    "Hücresel solunum ince bağırsakta, sindirim kas hücresinde "
                    "olur; enerji bağırsakta çıkar, kas yalnız kullanır":
                        "Tersi: sindirim ince bağırsakta, hücresel solunum kas "
                        "hücresinde.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Nişasta hücre zarından geçemeyecek kadar büyük. Sindirim onu "
                    "glikozlara ayırır -- bu bir parçalama, enerji kazanma değil. "
                    "Glikoz emilip kanla hücreye ulaştıktan sonra hücresel solunum "
                    "onu yıkar ve ATP üretir."
                ),
                ipuclari=[
                    "Laboratuvar notu sindirim sırasında ATP için ne diyor?",
                    "Nişasta hücreye neden olduğu gibi giremez?",
                ],
                cozum=(
                    "Sindirim: kanal boşluğu, parçalama, ATP yok.\n"
                    "Emilim: villus -> kan.\n"
                    "Hücresel solunum: hücre, glikoz + O₂ -> ATP."
                ),
            ),
            sirala_adimi(
                soru="Yol kartlarını ağızdan kas hücresine doğru sırala (numaraları sırayla yaz):",
                secenekler=kartlar,
                dogru_sira=dogru_sira,
                aciklama=(
                    "Ağız -> ince bağırsak (sindirim) -> villus (emilim) -> kan "
                    "(taşınma) -> kas hücresi (hücresel solunum). ATP yalnız son "
                    "durakta üretiliyor."
                ),
                ipuclari=["Nişasta önce parçalanmalı mı, emilmeli mi?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Nişasta parçası ince bağırsakta sindirilirken kaç ATP üretilir?",
                cevap=0,
                birim="ATP",
                aciklama=("Sindirim ATP üretmez: {} glikoz birimi ayrılır ama enerji "
                          "henüz ATP'ye aktarılmaz.").format(birim),
                yaygin_yanlislar={
                    atp:
                        "Sindirim ile hücresel solunumu aynı süreç saydın. {} ATP, "
                        "glikozlar hücrede yıkılınca çıkar; bağırsakta değil."
                        .format(atp),
                    birim:
                        "Glikoz sayısını yazdın; sindirim glikozları ayırır ama "
                        "ATP üretmez.",
                },
                ipuclari=["Laboratuvar notunu oku."],
                puan=12,
            ),
            sayi_adimi(
                soru="Bu glikozların hepsi kas hücresinde oksijenli solunumla yıkılırsa kaç ATP üretilir?",
                cevap=atp,
                birim="ATP",
                aciklama="{} glikoz × {} = {} ATP (model değeri).".format(
                    birim, _GLIKOZ_ATP_MODEL, atp),
                yaygin_yanlislar={
                    _GLIKOZ_ATP_MODEL:
                        "Tek glikozun ATP'sini yazdın; parçada {} glikoz var."
                        .format(birim),
                    birim * 2:
                        "Yalnız glikolizin net ATP'sini saydın; oksijenli solunum "
                        "çok daha fazlasını üretir.",
                },
                ipuclari=["Model tablosundaki değeri glikoz sayısıyla çarp."],
                puan=12,
            ),
            secim_adimi(
                soru="Afişteki cümle nasıl düzeltilmeli?",
                dogru=("\"Ekmek ince bağırsakta glikoza sindirilir; ATP, glikoz "
                       "kas hücresinde yıkılınca üretilir.\""),
                yanlislar={
                    "Düzeltme gerekmez; ATP sindirim sırasında ince bağırsakta "
                    "üretilir, besinin enerjisi orada çıkar":
                        "Sindirim ile hücresel solunumu aynı süreç saydın; "
                        "sindirim sırasında ATP üretilmiyor.",
                    "\"Ekmek kas hücresinde sindirilir ve ATP hemen orada, "
                    "kullanılacağı yerde üretilir.\"":
                        "Nişasta kas hücresine giremez; önce sindirim kanalında "
                        "glikozlara ayrılması gerekir.",
                    "\"Ekmek ince bağırsakta sindirilir; ATP, glikozu kaslara "
                    "taşıyan kanda üretilir.\"":
                        "Kan glikozu taşır; ATP'yi glikozu yıkan hücre üretir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Doğru cümle iki süreci ayırıyor: sindirim bağırsakta parçalar, "
                    "hücresel solunum hücrede ATP üretir. Bu parçadan {} ATP "
                    "çıkabilir -- ama bağırsakta değil, kas hücresinde."
                ).format(atp),
                ipuclari=["ATP hangi kartın durağında üretiliyor?"],
                puan=12,
            ),
        ],
        kapanis=("Afiş düzeltildi: ince bağırsakta 0 ATP, kas hücresinde {} glikozdan "
                 "{} ATP. \"Sindirim parçalar, solunum enerjiyi ATP'ye aktarır.\""
                 ).format(birim, atp),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# DESTEK VE HAREKET: KAS GEVŞERKEN DE ATP HARCAR (B37.13 -- müfredat haritası)
#
# `destek_hareket` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Modelde
# kas ve iskeletin birlikte çalışmasını açıklama". `yaygin_yanlis`:
#
#   "Kasların yalnız kısalırken enerji kullandığını sanmak."
#
# DÜZENEK: kol modeli bir yükü kaldırıyor, havada tutuyor, bırakıyor. Kas
# modeli üç evrede de ATP harcıyor (MODEL BİRİMİ): kısalma, kasılı kalma
# (çapraz köprüler tekrar tekrar kurulup çözülür) ve gevşeme (miyozinin
# aktinden ayrılması ve Ca²⁺'nin geri pompalanması). Kanıt: ölüm sertliği --
# ATP bitince kas gevşeyemez.
#
# Fizikteki `vinc_karsilastirma` göreviyle tutarlı: havada tutulan kasaya
# İŞ yapılmaz, ama kaslar ENERJİ harcar.
#
# YANILGININ SAYISAL KARŞILIĞI: toplam ATP'ye yalnız kısalmayı yazmak ayrı
# teşhis alır; tutmayı ya da gevşemeyi unutmak da ayrı teşhis alır.
# ==========================================================================

def _kas_havuzu():
    """(kisalma, gevseme, tutma_hizi, tutma_s): birim, birim, birim/s, s.

    Koşul: tutma evresinin toplamı gevşemeye eşit değil -- yoksa "tutmayı
    unutmak" ile "gevşemeyi unutmak" aynı sayıya düşer.
    """
    havuz = []
    for kisalma in (20, 30, 40):
        for gevseme in (10, 15, 20):
            for tutma_hizi in (2, 3, 4):
                for tutma_s in (10, 20, 30):
                    if tutma_hizi * tutma_s == gevseme:
                        continue
                    havuz.append((kisalma, gevseme, tutma_hizi, tutma_s))
    return tuple(havuz)


_KAS = _kas_havuzu()


@bulmaca(ders="biyoloji", konu="destek_hareket", kademeler=(11, 13), agirlik=1.3)
def kol_modeli(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kas kısalırken, kasılı kalırken ve gevşerken ATP harcar."""
    kisalma, gevseme, tutma_hizi, tutma_s = rastgele.choice(_KAS)
    tutma = tutma_hizi * tutma_s
    toplam = kisalma + tutma + gevseme
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-kol-modeli",
        ders="biyoloji",
        baslik="Kol Modeli",
        kademe=kademe,
        konu="destek_hareket",
        kazanim="Kasın kısalma, kasılı kalma ve gevşeme evrelerinde ATP harcadığını "
                "açıklama; ölüm sertliğini ATP ile ilişkilendirme; kas-iskelet "
                "modelinde enerji hesabı yapma.",
        dikkat=7,
        brifing=(
            "Sağlık birimi, depo işçileri için bir kol modeli üzerinde ağırlık "
            "taşıma çalışması yapıyor: yük kaldırılıyor, bir süre havada "
            "tutuluyor, sonra bırakılıyor.\n\n"
            "{} enerji tablosunu tek satırla doldurdu: \"Kas yalnız kısalırken "
            "enerji harcar. Yükü tutarken kol kıpırdamıyor, bırakırken de kas "
            "kendiliğinden gevşiyor.\"\n\n"
            "Çalışma planı yazılmadan önce kasın hangi evrelerde enerji "
            "harcadığını bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Kas modeli ölçümü",
                  "Model birimleriyle ATP harcaması:\n"
                  "Kısalma (kaldırma): {} birim.\n"
                  "Kasılı kalma (tutma): saniyede {} birim; yük {} saniye tutuldu.\n"
                  "Gevşeme (bırakma): {} birim."
                  .format(kisalma, tutma_hizi, tutma_s, gevseme),
                  bedel=1, kritik=True),
            Kanit("Ölüm sertliği kaydı",
                  "Canlılığını yitiren hücrelerde ATP üretimi durur. Birkaç saat "
                  "içinde kaslar kasılı hâlde katılaşır ve gevşeyemez; ATP "
                  "verilen kas lifleri ise gevşer.",
                  bedel=1, kritik=True),
            Kanit("Kas-iskelet notu",
                  "Kas yalnız çekebilir, itemez. Kolu büken kas gevşeyince karşıt "
                  "kas kolu açar; kemik kaldıraç, eklem destek noktasıdır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kas hangi evrelerde ATP harcar?",
                dogru=("Kısalırken, kasılıyken ve gevşerken: miyozinin aktinden "
                       "ayrılması da ATP ister"),
                yanlislar={
                    "Yalnız kısalırken; gevşeme kendiliğinden olur, kas bırakınca "
                    "kendi uzar":
                        "Kasların yalnız kısalırken enerji kullandığını sandın. "
                        "Ölüm sertliği kaydına bak: ATP bitince kas gevşeyemiyor.",
                    "Yalnız gevşerken; kısalma kendiliğinden olur, kas gerilmiş "
                    "bir yay gibi toplanır":
                        "Kısalma da ATP ister: miyozin başları aktini ATP'nin "
                        "enerjisiyle çeker.",
                    "Hiç harcamaz: hareketi kemikler ve eklemler sağlar, kas "
                    "yalnız bağlar":
                        "Kemikler kaldıraçtır; kuvveti kas üretir ve bunun için "
                        "ATP harcar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kasılmada miyozin başları aktine tutunup çeker; ayrılmaları "
                    "için yeni bir ATP gerekir. Kasılı kalırken bu döngü sürer. "
                    "Gevşemede kalsiyum geri pompalanır ve bu da ATP ister. ATP "
                    "bitince baş aktine yapışık kalır: ölüm sertliği."
                ),
                ipuclari=[
                    "Ölüm sertliği kaydında ATP bitince kas ne yapamıyor?",
                    "Yük havada dururken kas gevşemiş mi, kasılı mı?",
                ],
                cozum=(
                    "Kısalma: ATP.\nKasılı kalma: sürekli ATP.\n"
                    "Gevşeme: ATP (ayrılma, Ca²⁺ pompası)."
                ),
            ),
            sayi_adimi(
                soru="Kaldır-tut-bırak döngüsünün tamamında kas modeli kaç birim ATP harcar?",
                cevap=toplam,
                birim="birim",
                aciklama="Kısalma {} + tutma {} × {} = {} + gevşeme {} = {} birim.".format(
                    kisalma, tutma_hizi, tutma_s, tutma, gevseme, toplam),
                yaygin_yanlislar={
                    kisalma:
                        "Kasların yalnız kısalırken enerji kullandığını sandın. "
                        "Tutma ve gevşeme evreleri de ATP harcıyor.",
                    kisalma + gevseme:
                        "Tutma evresini unuttun: kol kıpırdamasa da kas kasılı ve "
                        "ATP harcıyor.",
                    kisalma + tutma:
                        "Gevşemeyi unuttun: kas gevşerken de ATP harcar.",
                },
                ipuclari=["Üç evrenin harcamasını ayrı ayrı bul ve topla."],
                puan=14,
            ),
            secim_adimi(
                soru="Ölüm sertliği kaydı neyi gösteriyor?",
                dogru="Gevşeme de ATP ister: ATP bitince kas kasılı hâlde kalır",
                yanlislar={
                    "Kaslar ölümden sonra ATP üretip kasılmaya devam eder":
                        "Kayıt, ATP üretiminin DURDUĞUNU söylüyor; kas kasılı kalıyor "
                        "çünkü gevşemek için ATP yok.",
                    "Kasılma ATP istemez; ölüm sonrası kasılma bunun kanıtıdır":
                        "Kas ölümden önce kasılmıştı; ölüm sertliğinde yeni bir "
                        "kasılma değil, gevşeyememe görülüyor.",
                    "Kemikler eklemlerde kilitlenir; kasla ilgisi yoktur":
                        "Kayıt kas liflerinden söz ediyor: ATP verilen lifler "
                        "gevşiyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "ATP verilen liflerin gevşemesi kesin kanıt: gevşemeyi sağlayan "
                    "ATP'dir. Kasların yalnız kısalırken enerji harcadığı fikri bu "
                    "kayıtla çöker."
                ),
                ipuclari=["ATP verilen kas lifleri ne yapıyor?"],
                puan=12,
            ),
            yorum_adimi(
                soru="Tablodaki \"yükü tutarken kas enerji harcamaz\" cümlesi için hangisi doğru?",
                dogru=("Yanlış: kas kasılı kalıyor; {} saniyede {} birim ATP "
                       "harcıyor").format(tutma_s, tutma),
                yanlislar={
                    "Doğru: kol hareket etmediği için enerji harcanmaz; iş "
                    "yapılmıyor ki":
                        "Kasların yalnız kısalırken enerji kullandığını sandın. Yüke "
                        "iş yapılmıyor olabilir, ama kasın kasılı kalması ATP ister.",
                    "Doğru: tutma sırasındaki yükü kemikler ve eklemler taşır":
                        "Yük havada kalıyorsa kas çekmeyi sürdürüyor; kemik yalnız "
                        "kaldıraç.",
                    "Yanlış: tutma sırasında kas yalnız gevşeme ATP'si harcar":
                        "Tutma sırasında kas gevşemiyor, kasılı kalıyor; harcanan "
                        "tutma evresinin ATP'si.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Fizikte havada tutulan yüke iş yapılmaz, çünkü yük yer "
                    "değiştirmez. Ama kas bu sırada çapraz köprüleri durmadan "
                    "kurup çözer: {} birim ATP. İş ile vücudun harcadığı enerji "
                    "aynı şey değil."
                ).format(tutma),
                puan=10,
            ),
        ],
        kapanis=("Enerji tablosu üç satıra ayrıldı: kısalma {}, tutma {}, gevşeme {} "
                 "birim; toplam {}. Uzun tutma süreleri planda kısaltıldı."
                 ).format(kisalma, tutma, gevseme, toplam),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# BOŞALTIM VE SU-TUZ DENGESİ (B37.13 -- müfredat haritası)
#
# `bosaltim` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Su dengesi
# modelinde böbreğin işlevini yorumlama". `yaygin_yanlis`:
#
#   "Boşaltımı yalnız dışkılama sanmak."
#
# DÜZENEK: sağlık biriminin günlük su dengesi tablosu (mL). Alınan su = içme
# + besin + metabolik su. Verilen: idrar (böbrek), ter (deri), soluk (akciğer),
# dışkı. İdrar satırı boş. Böbrekler günde 180 L süzüyor. Dışkı çoğunlukla
# sindirilmemiş kalıntıdır -- metabolizma artığı değil, boşaltım sayılmaz.
#
# YANILGININ SAYISAL KARŞILIĞI: suyun yalnız dışkıyla atıldığını varsaymak
# (idrar = alınan − dışkı); atık listesinde yalnız bağırsağı seçmek.
# ==========================================================================

_SUZULEN_ML = 180000


def _su_dengesi_havuzu():
    """(icme, besin, ter, soluk, diski): mL; metabolik su 300 mL.

    Koşul: idrar = alınan − (ter + soluk + dışkı) 800-2000 mL arasında.
    """
    havuz = []
    for icme in (1200, 1500, 1800):
        for besin in (600, 700, 800):
            for ter in (400, 500, 600, 800):
                for soluk in (300, 350, 400):
                    for diski in (100, 150, 200):
                        alinan = icme + besin + 300
                        idrar = alinan - ter - soluk - diski
                        if 800 <= idrar <= 2000:
                            havuz.append((icme, besin, ter, soluk, diski))
    return tuple(havuz)


_SU_DENGESI = _su_dengesi_havuzu()


@bulmaca(ders="biyoloji", konu="bosaltim", kademeler=(11, 13), agirlik=1.3)
def su_dengesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Boşaltım böbrek, deri ve akciğerle metabolizma artıklarını atmaktır; dışkılama değil."""
    icme, besin, ter, soluk, diski = rastgele.choice(_SU_DENGESI)
    alinan = icme + besin + 300
    idrar = alinan - ter - soluk - diski
    geri_emilen = _SUZULEN_ML - idrar
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-su-dengesi",
        ders="biyoloji",
        baslik="Su Dengesi",
        kademe=kademe,
        konu="bosaltim",
        kazanim="Boşaltımı metabolizma artıklarının böbrek, deri ve akciğerle "
                "atılması olarak açıklama; su dengesi tablosunda idrar miktarını "
                "ve böbrekte geri emilen sıvıyı hesaplama.",
        dikkat=7,
        brifing=(
            "Sağlık birimi, sıcak havada çalışan ekibin günlük su dengesi "
            "tablosunu dolduruyor. İdrar satırı boş kaldı.\n\n"
            "{} tabloya not düştü: \"Boşaltım dışkılama demek. Vücut fazla suyu "
            "bağırsaktan atar; böbrek ve ter bu tabloya ait değil.\"\n\n"
            "Tablo imzalanmadan önce boşaltımın yollarını ve idrar satırını "
            "doğru doldurmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Günlük alınan su",
                  "İçme: {} mL. Besinlerdeki su: {} mL. Hücrelerde üretilen "
                  "(metabolik) su: 300 mL.".format(icme, besin),
                  bedel=1, kritik=True),
            Kanit("Günlük verilen su",
                  "İdrar: ? mL. Ter (deri): {} mL. Soluk (akciğer): {} mL. "
                  "Dışkı: {} mL. Vücut suyu gün boyunca sabit kaldı."
                  .format(ter, soluk, diski),
                  bedel=1, kritik=True),
            Kanit("Böbrek notu",
                  "Böbrekler günde yaklaşık 180 L (180 000 mL) sıvı süzer; bunun "
                  "büyük kısmını geri emer, kalanı idrar olur. İdrarda üre ve fazla "
                  "tuz atılır. Dışkı çoğunlukla sindirilmemiş besin kalıntısıdır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Boşaltım için hangisi doğrudur?",
                dogru=("Üre, CO₂, fazla su ve tuzun böbrek, deri ve akciğerle "
                       "atılmasıdır; dışkılama boşaltım değildir"),
                yanlislar={
                    "Boşaltım dışkılamadır; fazla su ve artıklar bağırsaktan "
                    "atılır, vücuttan çıkan her atık boşaltımdır":
                        "Boşaltımı yalnız dışkılama sandın. Dışkı çoğunlukla hiç "
                        "hücreye girmemiş besin kalıntısıdır; hücrelerin ürettiği "
                        "artıkları böbrek, deri ve akciğer atar.",
                    "Boşaltım yalnız terlemedir; böbrek suyu depolar, atık ter "
                    "bezlerinden çıkar":
                        "Böbrek suyu depolamaz, süzüp fazlasını idrarla atar.",
                    "Boşaltım yalnız akciğerde olur: asıl atık CO₂, o da soluk "
                    "vermeyle çıkar":
                        "Akciğer boşaltımın bir yolu; üre ve fazla tuzu ise böbrek "
                        "atar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Boşaltım, hücrelerde metabolizma sonucu oluşan artıkların "
                    "atılmasıdır: böbrek üre, su ve tuzu; akciğer CO₂ ve su "
                    "buharını; deri terle su ve tuzu atar. Dışkılama ise sindirim "
                    "kanalından geçip emilmeyen kalıntının atılmasıdır."
                ),
                ipuclari=[
                    "Dışkıdaki madde hiç hücreye girdi mi?",
                    "Böbrek notu idrarla neyin atıldığını söylüyor?",
                ],
                cozum=(
                    "Alınan = verilen (vücut suyu sabit)\n"
                    "İdrar = alınan − (ter + soluk + dışkı)"
                ),
            ),
            sayi_adimi(
                soru="Su dengesinin korunması için günlük idrar kaç mL olmalı?",
                cevap=idrar,
                birim="mL",
                aciklama="Alınan: {} + {} + 300 = {} mL. İdrar = {} − ({} + {} + {}) = {} mL.".format(
                    icme, besin, alinan, alinan, ter, soluk, diski, idrar),
                yaygin_yanlislar={
                    alinan - diski:
                        "Boşaltımı yalnız dışkılama sandın ve teri, soluğu yok "
                        "saydın. Deri ve akciğer de su atıyor.",
                    alinan:
                        "Alınan suyun tamamını idrara yazdın; ter, soluk ve dışkıyla "
                        "da su gidiyor.",
                },
                ipuclari=["Vücut suyu sabitse alınan ve verilen eşittir."],
                puan=12,
            ),
            sayi_adimi(
                soru="Böbrekler günde kaç mL süzüntüyü geri emer?",
                cevap=geri_emilen,
                birim="mL",
                aciklama="{} − {} = {} mL; süzülenin neredeyse tamamı geri emiliyor.".format(
                    _SUZULEN_ML, idrar, geri_emilen),
                yaygin_yanlislar={
                    _SUZULEN_ML:
                        "Süzülenin tamamını yazdın; bir kısmı idrar olarak atılıyor.",
                    idrar:
                        "İdrar miktarını yazdın; soru geri emilen kısmı soruyor.",
                },
                ipuclari=["Süzülenden idrarı çıkar."],
                puan=12,
            ),
            secim_adimi(
                soru="Hangi eşleştirme boşaltım organlarını ve attıklarını doğru verir?",
                dogru="Böbrek: üre, su, tuz; akciğer: CO₂, su buharı; deri: ter",
                yanlislar={
                    "Yalnız bağırsak: dışkı":
                        "Boşaltımı yalnız dışkılama sandın; dışkı büyük ölçüde "
                        "sindirilmemiş kalıntı, hücre artıklarını başka organlar atar.",
                    "Böbrek: dışkı; akciğer: oksijen, su buharı; deri: yağ, kir":
                        "Böbrek idrar üretir; akciğer CO₂ atar, oksijeni alır.",
                    "Karaciğer: idrar, safra; bağırsak: üre ve dışkı":
                        "Karaciğer üreyi ÜRETİR ama atmaz; üreyi böbrek idrarla atar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tablodaki su kayıplarının üçü boşaltım yolu: idrar ({} mL), "
                    "ter ({} mL), soluk ({} mL). Dışkıyla giden {} mL su boşaltım "
                    "değil, sindirim kanalının kalıntısıyla atılan su."
                ).format(idrar, ter, soluk, diski),
                ipuclari=["Hücrede üretilen artıkları hangi organlar atar?"],
                puan=12,
            ),
        ],
        kapanis=("Tablo dolduruldu: idrar {} mL; böbrekler {} mL geri emiyor. Not "
                 "düzeltildi: boşaltım böbrek, deri ve akciğerle yapılır."
                 ).format(idrar, geri_emilen),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# KEMOSENTEZ: IŞIK DEĞİL, İNORGANİK MADDELERİN ENERJİSİ (B37.13)
#
# `kemosentez` iki satırda boştu (2018: 12; 2026: 10). Bağlam: "Keşif
# numunelerinin enerji kaynağını sınıflandırma". `yaygin_yanlis`:
#
#   "Kemosentezin de ışık gerektirdiğini sanmak."
#
# DÜZENEK: göl dibindeki sıcak kaynaktan iki numune -- yeşil alg ve H₂S
# kullanan bakteri -- aydınlık ve tamamen karanlık tanklarda günlük organik
# madde üretimiyle izleniyor. Alg karanlıkta üretmiyor; bakteri aynı hızla
# üretiyor. Bakterinin tankına H₂S verilmeyince üretimi duruyor.
#
# YANILGININ SAYISAL KARŞILIĞI: karanlıktaki bakteri üretimine 0 demek ayrı
# teşhis alır; enerji kaynağı sorusunda "ışık" şıkkı yanılgı teşhislidir.
# ==========================================================================

_KEMO_URETIM = (12, 15, 18, 20, 24)   # mg/gün; alg hızlarıyla kesişmez (teşhis çakışmasın)
_ALG_URETIM = (25, 30, 40, 45, 50)          # mg/gün (aydınlıkta)
_GOZLEM_GUN = (3, 4, 5, 6)


@bulmaca(ders="biyoloji", konu="kemosentez", kademeler=(10, 13), agirlik=1.3)
def karanlik_tank(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kemosentez ışık gerektirmez; enerjiyi inorganik maddelerin yükseltgenmesinden alır."""
    bakteri = rastgele.choice(_KEMO_URETIM)
    alg = rastgele.choice(_ALG_URETIM)
    gun = rastgele.choice(_GOZLEM_GUN)
    toplam = bakteri * gun
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-karanlik-tank",
        ders="biyoloji",
        baslik="Karanlık Tank",
        kademe=kademe,
        konu="kemosentez",
        kazanim="Kemosentezin ışık gerektirmediğini, enerjinin inorganik maddelerin "
                "yükseltgenmesinden geldiğini açıklama; fotosentez yapan ve "
                "kemosentez yapan canlıları enerji kaynağına göre ayırt etme.",
        dikkat=7,
        brifing=(
            "Göl dibindeki sıcak kaynaktan iki numune getirildi: yeşil bir alg ve "
            "çürük yumurta kokulu sudan alınmış bir bakteri. İkisi de kendi "
            "besinini üretiyor.\n\n"
            "{} sınıflandırma kartına şunu yazdı: \"Kendi besinini üreten her "
            "canlı ışığa muhtaçtır; bakteri de karanlıkta üretemez.\"\n\n"
            "Kart arşive girmeden önce tank ölçümlerini yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Aydınlık tank",
                  "Alg: günde {} mg organik madde. Bakteri: günde {} mg organik "
                  "madde.".format(alg, bakteri),
                  bedel=1, kritik=True),
            Kanit("Karanlık tank",
                  "{} gün tam karanlık. Alg: organik madde üretimi yok, hücreler "
                  "zayıfladı. Bakteri: üretim hızı aydınlık tanktakiyle aynı "
                  "kaldı.".format(gun),
                  bedel=1, kritik=True),
            Kanit("Gaz kaydı",
                  "Bakteri tankına H₂S (hidrojen sülfür) verilmediği gün bakterinin "
                  "üretimi durdu; ışık açık olsa da başlamadı.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Kemosentez yapan bakteri besin üretmek için enerjiyi nereden alır?",
                dogru=("H₂S gibi inorganik maddeleri yükseltgeyerek elde ettiği "
                       "kimyasal enerjiden"),
                yanlislar={
                    "Güneş ışığından; kendi besinini üreten her canlı ışık "
                    "kullanır, bitkiler gibi":
                        "Kemosentezin de ışık gerektirdiğini sandın. Karanlık tankta "
                        "bakteri aynı hızla üretti; H₂S kesilince ışık açıkken bile "
                        "durdu.",
                    "Başka canlıları yiyerek; ışık yoksa besin üretilemez, "
                    "geriye yemek kalır":
                        "Bakteri kendi besinini üretiyor; hazır besin tüketmiyor.",
                    "Tanktaki sıcak sudan, çünkü ısı da bir enerjidir ve doğrudan "
                    "besine dönüşür":
                        "Isı değil, inorganik maddelerin kimyasal enerjisi "
                        "kullanılıyor; H₂S kesilince sıcak su yetmedi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kemosentez yapan bakteriler H₂S, amonyak, demir gibi inorganik "
                    "maddeleri yükseltger ve açığa çıkan enerjiyle CO₂'den organik "
                    "madde yapar. Işık gerekmez; bu yüzden okyanus diplerinde ve "
                    "karanlık kaynaklarda yaşarlar."
                ),
                ipuclari=[
                    "Karanlık tankta bakterinin üretimi ne oldu?",
                    "Gaz kaydında bakterinin üretimini ne durdurdu?",
                ],
                cozum="Fotosentez: ışık enerjisi.\nKemosentez: inorganik madde yükseltgenmesi.",
            ),
            sayi_adimi(
                soru="Karanlık tanktaki bakteri {} günde toplam kaç mg organik madde üretti?".format(gun),
                cevap=toplam,
                birim="mg",
                aciklama="Üretim hızı değişmedi: {} mg/gün × {} gün = {} mg.".format(
                    bakteri, gun, toplam),
                yaygin_yanlislar={
                    0:
                        "Kemosentezin de ışık gerektirdiğini sandın. Karanlık tank "
                        "kaydı, bakterinin üretim hızının değişmediğini söylüyor.",
                    bakteri:
                        "Bir günlük üretimi yazdın; soru {} günün toplamını soruyor."
                        .format(gun),
                    alg * gun:
                        "Algin aydınlıktaki hızını kullandın; soru bakteriyi soruyor.",
                },
                ipuclari=["Karanlık tankta bakterinin üretim hızı değişti mi?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Aynı sürede karanlık tanktaki alg kaç mg organik madde üretti?",
                cevap=0,
                birim="mg",
                aciklama="Alg fotosentez yapıyor: ışık yokken üretim yok, 0 mg.",
                yaygin_yanlislar={
                    alg * gun:
                        "Algin aydınlıktaki hızını karanlığa taşıdın; fotosentez "
                        "ışık ister.",
                },
                ipuclari=["Karanlık tank kaydında alg için ne yazıyor?"],
                puan=10,
            ),
            secim_adimi(
                soru="Sınıflandırma kartı nasıl düzeltilmeli?",
                dogru=("Alg: fotosentez (ışık); bakteri: kemosentez (H₂S "
                       "yükseltgenmesi)"),
                yanlislar={
                    "İkisi de fotosentez yapar; bakteri yalnız daha az ışıkla idare eder":
                        "Kemosentezin de ışık gerektirdiğini sandın. Bakteri "
                        "karanlıkta aynı hızla üretti.",
                    "Alg: kemosentez; bakteri: fotosentez, aydınlıkta o da "
                    "üretiyordu":
                        "Tersi: ışık olmadan duran alg, H₂S olmadan duran bakteri.",
                    "İkisi de kemosentez yapar; alg karanlıkta yalnızca "
                    "hastalandığı için durdu":
                        "Alg aydınlıkta üretip karanlıkta duruyor: fotosentezin "
                        "tipik davranışı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki deney birbirini tamamlıyor: ışığı kesmek algi durdurdu, "
                    "bakteriyi durdurmadı; H₂S vermemek bakteriyi durdurdu, ışık "
                    "açıkken bile. Enerji kaynakları farklı."
                ),
                ipuclari=["Her canlıyı hangi koşulun yokluğu durdurdu?"],
                puan=12,
            ),
        ],
        kapanis=("Kart düzeltildi: karanlıkta bakteri {} günde {} mg üretti, alg 0 mg. "
                 "Kemosentez ışığa değil inorganik maddelere bağlı."
                 ).format(gun, toplam),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# PROTEİN SENTEZİ: HER MUTASYON AYNI SONUCU VERMEZ (B37.13)
#
# `protein_sentezi` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Arşivdeki
# DNA-RNA-protein bağlantılarını yorumlama". `yaygin_yanlis`:
#
#   "Her mutasyonun aynı sonucu verdiğini sanmak."
#
# DÜZENEK: arşivdeki kısa bir genin mRNA'sı (AUG + 5 kodon + UAA) ve tek harfi
# değişmiş üç mutant: SESSİZ (aynı amino asit), YANLIŞ ANLAMLI (tek amino asit
# değişir), ANLAMSIZ (erken durdurma kodonu, protein kısalır). Mutasyonlar
# standart genetik kod tablosunun tamamı üzerinden aranır.
#
# YANILGININ SAYISAL KARŞILIĞI: sessiz mutantta "1 amino asit değişti" ve
# anlamsız mutantta "boy değişmedi" demek ayrı teşhis alır.
# ==========================================================================

_BAZLAR = "UCAG"
# Standart genetik kod: indeks = 16·b1 + 4·b2 + b3 (U=0, C=1, A=2, G=3); * = dur
_KOD = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
_UC_HARF = {"F": "Phe", "L": "Leu", "S": "Ser", "Y": "Tyr", "C": "Cys", "W": "Trp",
            "P": "Pro", "H": "His", "Q": "Gln", "R": "Arg", "I": "Ile", "M": "Met",
            "T": "Thr", "N": "Asn", "K": "Lys", "V": "Val", "A": "Ala", "D": "Asp",
            "E": "Glu", "G": "Gly", "*": "DUR"}


def _cevir(kodon):
    i = 16 * _BAZLAR.index(kodon[0]) + 4 * _BAZLAR.index(kodon[1]) + _BAZLAR.index(kodon[2])
    return _KOD[i]


def _protein(kodonlar):
    sonuc = []
    for kodon in kodonlar:
        aa = _cevir(kodon)
        if aa == "*":
            break
        sonuc.append(aa)
    return sonuc


def _tek_harf_degisimleri(kodon):
    for sira in range(3):
        for baz in _BAZLAR:
            if baz != kodon[sira]:
                yield kodon[:sira] + baz + kodon[sira + 1:]


def _gen_ve_mutantlar(rastgele):
    """(normal, sessiz, yanlis_anlamli, anlamsiz, konumlar) -- kodon listeleri."""
    anlamli = [a + b + c for a in _BAZLAR for b in _BAZLAR for c in _BAZLAR
               if _cevir(a + b + c) not in ("*", "M")]
    while True:
        normal = ["AUG"] + [rastgele.choice(anlamli) for _ in range(5)] + ["UAA"]
        konumlar = [1, 2, 3, 4, 5]
        rastgele.shuffle(konumlar)
        p, q, r = konumlar[:3]
        if r == 5:                       # anlamsız mutant en az bir amino asit kısaltsın
            continue
        sessizler = [k for k in _tek_harf_degisimleri(normal[p]) if _cevir(k) == _cevir(normal[p])]
        yanlislar = [k for k in _tek_harf_degisimleri(normal[q])
                     if _cevir(k) not in ("*", _cevir(normal[q]))]
        durdurucular = [k for k in _tek_harf_degisimleri(normal[r]) if _cevir(k) == "*"]
        if sessizler and yanlislar and durdurucular:
            break
    sessiz = list(normal)
    sessiz[p] = rastgele.choice(sessizler)
    yanlis = list(normal)
    yanlis[q] = rastgele.choice(yanlislar)
    anlamsiz = list(normal)
    anlamsiz[r] = rastgele.choice(durdurucular)
    return normal, sessiz, yanlis, anlamsiz, (p, q, r)


def _dizi(kodonlar):
    return "-".join(kodonlar)


def _amino(aa_listesi):
    return "-".join(_UC_HARF[a] for a in aa_listesi)


@bulmaca(ders="biyoloji", konu="protein_sentezi", kademeler=(12, 13), agirlik=1.3)
def arsiv_geni(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Mutasyonun sonucu kodondaki değişime bağlı: sessiz, yanlış anlamlı, anlamsız."""
    normal, sessiz, yanlis, anlamsiz, (p, q, r) = _gen_ve_mutantlar(rastgele)
    p_normal = _protein(normal)
    p_yanlis = _protein(yanlis)
    boy_anlamsiz = len(_protein(anlamsiz))
    tum_kodonlar = sorted(set(normal + sessiz + yanlis + anlamsiz))
    tablo = "\n".join("{} -> {}".format(k, _UC_HARF[_cevir(k)]) for k in tum_kodonlar)
    eski_aa, yeni_aa = _UC_HARF[p_normal[q]], _UC_HARF[p_yanlis[q]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-arsiv-geni",
        ders="biyoloji",
        baslik="Arşiv Geni",
        kademe=kademe,
        konu="protein_sentezi",
        kazanim="mRNA dizisini kodon tablosuyla proteine çevirme; sessiz, yanlış "
                "anlamlı ve anlamsız nokta mutasyonlarının proteine etkisini "
                "karşılaştırma.",
        dikkat=8,
        brifing=(
            "Tohum bankası arşivinde bir enzim geninin normal hâli ve üç mutant "
            "kaydı bulundu. Her mutantta mRNA'nın yalnız BİR harfi değişmiş.\n\n"
            "{} rapora şunu yazdı: \"Üçü de birer harf değişikliği; üç mutantın "
            "proteini de aynı ölçüde bozulmuştur.\"\n\n"
            "Rapor arşive girmeden önce her mutantın proteinini çıkarmamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("mRNA dizileri",
                  "Normal: {}\nMutant A: {}\nMutant B: {}\nMutant C: {}".format(
                      _dizi(normal), _dizi(sessiz), _dizi(yanlis), _dizi(anlamsiz)),
                  bedel=1, kritik=True),
            Kanit("Kodon tablosu (bu dizilerdeki kodonlar)", tablo,
                  bedel=1, kritik=True),
            Kanit("Çeviri notu",
                  "Ribozom AUG'den başlar, üçer harf okur ve ilk DUR kodonunda "
                  "durur. DUR kodonu amino asit eklemez.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Tek harflik mutasyonların proteine etkisi için hangisi doğru?",
                dogru=("Değişime bağlı: aynı amino asidi veren kodon etkisiz, "
                       "farklısı bir yeri değiştirir, DUR kısaltır"),
                yanlislar={
                    "Her tek harflik mutasyon proteinin tam bir amino asidini "
                    "değiştirir; harf değişirse amino asit de değişir":
                        "Her mutasyonun aynı sonucu verdiğini sandın. Kodon tablosunda "
                        "birden çok kodon aynı amino asidi veriyor; bazı değişimler "
                        "hiç fark yaratmaz, bazıları proteini keser.",
                    "Her mutasyon proteini tamamen bozar; tek harf bile bütün "
                    "tarifi geçersiz kılar":
                        "Tek harf yalnız bir kodonu etkiler; sonucu o kodonun neye "
                        "dönüştüğü belirler.",
                    "Mutasyon yalnız DNA'yı değiştirir, proteine hiç yansımaz, "
                    "çünkü protein DNA'dan ayrı bir maddedir":
                        "mRNA DNA'dan kopyalanır; kodon değişirse protein de "
                        "değişebilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Genetik şifre 'yedeklidir': çoğu amino asidi birden çok kodon "
                    "belirler. Bu yüzden aynı büyüklükte (tek harflik) iki mutasyonun "
                    "sonucu çok farklı olabilir: hiçbir değişiklik, tek amino asit "
                    "değişikliği ya da yarım kalmış bir protein."
                ),
                ipuclari=[
                    "Kodon tablosunda aynı amino asidi veren iki kodon var mı?",
                    "DUR kodonuna rastlayan ribozom ne yapar?",
                ],
                cozum="Her mutantı kodon kodon çevir, normal proteinle karşılaştır.",
            ),
            sayi_adimi(
                soru="Mutant A'nın proteininde normal proteinden kaç amino asit farklı?",
                cevap=0,
                aciklama=("{}. kodon {} -> {} değişti ama ikisi de {}: protein aynı "
                          "({}).").format(p + 1, normal[p], sessiz[p],
                                          _UC_HARF[p_normal[p]], _amino(p_normal)),
                yaygin_yanlislar={
                    1:
                        "Her mutasyonun aynı sonucu verdiğini sandın: bir harf "
                        "değişti diye bir amino asit değişti saydın. İki kodon da "
                        "aynı amino asidi veriyor.",
                    len(p_normal):
                        "Tek harf bütün proteini değiştirmez; yalnız bir kodon "
                        "etkilendi ve o da aynı amino asidi veriyor.",
                },
                ipuclari=["Değişen kodonun normal ve mutant hâlini tabloda bul."],
                puan=12,
            ),
            sayi_adimi(
                soru="Mutant C'nin proteini kaç amino asitten oluşur?",
                cevap=boy_anlamsiz,
                aciklama=("{}. kodon {} oldu: DUR. Ribozom orada durur; protein "
                          "{} amino asitte kalır (normali {}).").format(
                              r + 1, anlamsiz[r], boy_anlamsiz, len(p_normal)),
                yaygin_yanlislar={
                    len(p_normal):
                        "Her mutasyonun aynı sonucu verdiğini sandın: boyun "
                        "değişmediğini varsaydın. Değişen kodon bir DUR kodonu.",
                    len(p_normal) - 1:
                        "Yalnız bir amino asidin düştüğünü varsaydın; DUR kodonundan "
                        "sonraki bütün kodonlar okunmaz.",
                },
                ipuclari=["Mutant C'de ilk DUR kodonu kaçıncı kodonda?"],
                puan=14,
            ),
            secim_adimi(
                soru="Mutant B'nin proteini için hangisi doğru?",
                dogru="{}. amino asit {} yerine {}; proteinin geri kalanı ve boyu aynı".format(
                    q + 1, eski_aa, yeni_aa),
                yanlislar={
                    "Protein normalle aynı; tek harf değişikliği amino asidi değiştirmez":
                        "Her mutasyonun aynı sonucu verdiğini sandın: A'daki sessiz "
                        "sonucu B'ye taşıdın. B'deki yeni kodon farklı bir amino asit "
                        "veriyor.",
                    "Protein {}. amino asitte kesilir".format(q + 1):
                        "B'deki kodon DUR değil; kesilme C'de oluyor.",
                    "Değişen kodondan sonraki bütün amino asitler değişir":
                        "Bu, harf eklenip çıkınca olan çerçeve kaymasıdır; burada "
                        "harf yer değiştirdi, okuma çerçevesi aynı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Normal: {}.\nMutant B: {}.\nTek fark {}. konumda: {} -> {}."
                ).format(_amino(p_normal), _amino(p_yanlis), q + 1, eski_aa, yeni_aa),
                ipuclari=["Mutant B'yi kodon kodon çevir."],
                puan=12,
            ),
        ],
        kapanis=("Rapor düzeltildi: A sessiz (protein aynı), B yanlış anlamlı ({}. "
                 "konumda {} -> {}), C anlamsız ({} amino asitte kesik). Üç tek "
                 "harflik mutasyon, üç farklı sonuç."
                 ).format(q + 1, eski_aa, yeni_aa, boy_anlamsiz),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# BİTKİDE ÜREME: TOZLAŞMA DÖLLENME DEĞİLDİR (B37.13 -- müfredat haritası)
#
# `bitki_ureme` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Sera
# kayıtlarında çimlenme koşullarını karşılaştırma". `yaygin_yanlis`:
#
#   "Tozlaşma ile döllenmeyi aynı saymak."
#
# DÜZENEK: seradaki domates çiçekleri. Böcekler çiçeklerin bir kısmını
# tozlaştırıyor (polen tepeciğe taşınıyor). Aşırı sıcak bir gecede bazı
# çiçeklerde polen tüpü tohum taslağına ulaşamıyor: tozlaşma var, döllenme
# yok. Tohumu yalnız döllenen tohum taslakları verir.
#
# YANILGININ SAYISAL KARŞILIĞI: tohum sayısını tozlaşan çiçeklerden hesaplamak
# (tozlaşan × döllenen taslak) ya da tozlaşan her çiçekte bütün taslakların
# döllendiğini varsaymak -- ikisi de ayrı teşhis alır.
# ==========================================================================

def _tozlasma_havuzu():
    """(tozlasan, dollenen_cicek, taslak, dollenen_taslak).

    Koşullar: dollenen_cicek < tozlasan; dollenen_taslak < taslak; üç çeldirici
    (tozlaşan × döllenen taslak, tozlaşan × taslak, döllenen çiçek × taslak)
    doğru cevaptan ve birbirinden farklı.
    """
    havuz = []
    for tozlasan in (40, 50, 60):
        for dollenen in (20, 25, 30, 35):
            if dollenen >= tozlasan:
                continue
            for taslak in (6, 8, 10):
                for dollenen_taslak in (3, 4, 5):
                    if dollenen_taslak >= taslak:
                        continue
                    dogru = dollenen * dollenen_taslak
                    adaylar = {dogru, tozlasan * dollenen_taslak, tozlasan * taslak,
                               dollenen * taslak}
                    if len(adaylar) == 4:
                        havuz.append((tozlasan, dollenen, taslak, dollenen_taslak))
    return tuple(havuz)


_TOZLASMA = _tozlasma_havuzu()


@bulmaca(ders="biyoloji", konu="bitki_ureme", kademeler=(12, 13), agirlik=1.3)
def sera_cicekleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tozlaşma polenin tepeciğe taşınmasıdır; tohumu döllenme verir."""
    tozlasan, dollenen, taslak, dollenen_taslak = rastgele.choice(_TOZLASMA)
    tohum = dollenen * dollenen_taslak
    tozlasip_dollenmeyen = tozlasan - dollenen
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-sera-cicekleri",
        ders="biyoloji",
        baslik="Sera Çiçekleri",
        kademe=kademe,
        konu="bitki_ureme",
        kazanim="Tozlaşma ile döllenmeyi ayırt etme; tohum sayısını döllenen tohum "
                "taslaklarından hesaplama; tozlaşan çiçekte döllenmenin "
                "gerçekleşmeyebileceğini açıklama.",
        dikkat=7,
        brifing=(
            "Seradaki domates çiçekleri böceklerle tozlaştırıldı. Tohum bankası "
            "bu partiden tohum toplayacak ve kaç tohum çıkacağını bilmek istiyor.\n\n"
            "{} hesabı kısa tuttu: \"Tozlaşan her çiçek döllenmiş demektir; tohum "
            "sayısını tozlaşan çiçeklerden bulurum.\"\n\n"
            "Tohum kavanozları hazırlanmadan önce sera kayıtlarını doğru "
            "yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Tozlaşma kaydı",
                  "Böcek gözlemi: {} çiçeğin tepeciğine polen taşındı. Her çiçekte "
                  "{} tohum taslağı var.".format(tozlasan, taslak),
                  bedel=1, kritik=True),
            Kanit("Polen tüpü incelemesi",
                  "Sıcak gecenin ardından mikroskopla bakıldı: tozlaşan çiçeklerden "
                  "yalnız {} tanesinde polen tüpü tohum taslaklarına ulaştı. Bu "
                  "çiçeklerin her birinde ortalama {} tohum taslağı döllendi."
                  .format(dollenen, dollenen_taslak),
                  bedel=1, kritik=True),
            Kanit("Üreme notu",
                  "Tozlaşma: polenin tepeciğe ulaşması. Döllenme: polen tüpüyle "
                  "gelen sperm çekirdeğinin tohum taslağındaki yumurta hücresiyle "
                  "birleşmesi. Tohum, döllenen tohum taslağından gelişir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Tozlaşma ile döllenme arasındaki ilişki için hangisi doğru?",
                dogru=("Tozlaşma polenin tepeciğe konmasıdır; döllenme için "
                       "polen tüpü tohum taslağına ulaşmalı"),
                yanlislar={
                    "İkisi aynı olaydır: polen tepeciğe değdiği an döllenme de "
                    "olur, ayrıca bir aşama yoktur":
                        "Tozlaşma ile döllenmeyi aynı saydın. Polen tepecikten "
                        "tohum taslağına kadar bir polen tüpü uzatmalı; inceleme "
                        "bunun her çiçekte olmadığını gösteriyor.",
                    "Döllenme tozlaşmadan önce olur; polen ancak döllenmiş "
                    "çiçeğe gelir":
                        "Döllenme için sperm çekirdeği polenle gelir; tozlaşma "
                        "olmadan döllenme olamaz.",
                    "Tozlaşan çiçeğin bütün tohum taslakları kesinlikle döllenir; "
                    "tek polen tüpü hepsine yeter":
                        "İnceleme, döllenen çiçeklerde bile taslakların yalnız bir "
                        "kısmının döllendiğini söylüyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tozlaşma yalnız ilk adımdır. Polen çimlenip polen tüpünü "
                    "dişicik borusundan tohum taslağına kadar uzatmalı; sperm "
                    "çekirdeği yumurta hücresiyle birleşince döllenme olur. Sıcak, "
                    "kuraklık gibi koşullar bu yolculuğu durdurabilir."
                ),
                ipuclari=[
                    "Polen tüpü incelemesi tozlaşan her çiçekte ne gördü?",
                    "Tohum hangi yapıdan gelişir?",
                ],
                cozum="Tohum = döllenen çiçek × çiçek başına döllenen taslak",
            ),
            sayi_adimi(
                soru="Bu partiden kaç tohum çıkması beklenir?",
                cevap=tohum,
                aciklama="{} döllenen çiçek × {} döllenen taslak = {} tohum.".format(
                    dollenen, dollenen_taslak, tohum),
                yaygin_yanlislar={
                    tozlasan * dollenen_taslak:
                        "Tozlaşma ile döllenmeyi aynı saydın: tozlaşan bütün "
                        "çiçekleri saydın. Yalnız {} çiçekte döllenme oldu."
                        .format(dollenen),
                    tozlasan * taslak:
                        "Tozlaşan her çiçeğin bütün tohum taslaklarının döllendiğini "
                        "varsaydın.",
                    dollenen * taslak:
                        "Döllenen çiçeklerde bütün taslakları saydın; ortalama "
                        "{} taslak döllendi.".format(dollenen_taslak),
                },
                ipuclari=["Tohumu tozlaşma mı verir, döllenme mi?"],
                puan=14,
            ),
            sayi_adimi(
                soru="Tozlaştığı hâlde döllenmeyen kaç çiçek var?",
                cevap=tozlasip_dollenmeyen,
                aciklama="{} tozlaşan − {} döllenen = {} çiçek.".format(
                    tozlasan, dollenen, tozlasip_dollenmeyen),
                yaygin_yanlislar={
                    0:
                        "Tozlaşma ile döllenmeyi aynı saydın; inceleme bazı "
                        "çiçeklerde polen tüpünün ulaşmadığını söylüyor.",
                },
                ipuclari=["İki kaydı karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("Kavanozlar {} tohuma göre hazırlandı. {} çiçek tozlaştı ama "
                 "döllenmedi: tozlaşma döllenme demek değil."
                 ).format(tohum, tozlasip_dollenmeyen),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# İNSANDA ÜREME: DÖLLENME VE YERLEŞME AYRI OLAYLARDIR (B37.13)
#
# `insanda_ureme` iki satırda boştu (2018: 11; 2026: 12). Bağlam: "Bilim
# arşivindeki gelişim aşamalarını sıralama". `yaygin_yanlis`:
#
#   "Döllenme ile embriyonun yerleşmesini aynı olay saymak."
#
# DÜZENEK: bilim arşivinde erken gelişim kartları karışmış. Döllenme fallop
# tüpünde olur; zigot bölünerek rahme doğru ilerler ve blastosist olarak
# yaklaşık 6-7 gün sonra rahim duvarına yerleşmeye başlar (ders kitabı
# ölçeği; kartlarda "yaklaşık" yazılı).
#
# YANILGININ SAYISAL KARŞILIĞI: iki olay arasındaki süreye 0 demek; yerleşmenin
# yerine fallop tüpü demek.
# ==========================================================================

# Erken gelişim kartları, doğru sırayla.
_GELISIM_KARTLARI = (
    "Yumurtlama: yumurta hücresi yumurtalıktan fallop tüpüne bırakılır",
    "Döllenme: sperm ve yumurta hücresi fallop tüpünde birleşir, zigot oluşur",
    "Bölünmeler: zigot tüpte ilerlerken hücre sayısı artar (morula)",
    "Blastosist: içi boşluklu hücre topluluğu rahme ulaşır",
    "Yerleşme: blastosist rahim duvarına tutunur ve içine gömülür",
)


@bulmaca(ders="biyoloji", konu="insanda_ureme", kademeler=(11, 13), agirlik=1.3)
def gelisim_arsivi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Döllenme fallop tüpünde; embriyonun rahme yerleşmesi yaklaşık bir hafta sonra."""
    fark = rastgele.choice((6, 7))
    dollenme_gunu = rastgele.choice((1, 2))
    yerlesme_gunu = dollenme_gunu + fark
    karisik = list(range(len(_GELISIM_KARTLARI)))
    rastgele.shuffle(karisik)
    kartlar = [_GELISIM_KARTLARI[i] for i in karisik]
    dogru_sira = [karisik.index(i) for i in range(len(_GELISIM_KARTLARI))]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-gelisim-arsivi",
        ders="biyoloji",
        baslik="Gelişim Arşivi",
        kademe=kademe,
        konu="insanda_ureme",
        kazanim="Döllenme ile embriyonun rahme yerleşmesini yer ve zaman bakımından "
                "ayırt etme; erken gelişim aşamalarını sıralama.",
        dikkat=7,
        brifing=(
            "Sağlık biriminin bilim arşivinde erken gelişim kartları karışmış. "
            "Kartlar okul çadırındaki biyoloji dersi için yeniden dizilecek.\n\n"
            "{} kartların üstüne not düşmüş: \"Döllenme ile yerleşme aynı şey; "
            "sperm yumurtaya ulaştığı an embriyo rahme yerleşmiş olur.\"\n\n"
            "Kartlar derse gitmeden önce doğru sıralamamız ve notu düzeltmemiz "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Arşiv takvimi",
                  "Model kaydı (yaklaşık): döllenme {}. gün, yerleşmenin başlaması "
                  "{}. gün.".format(dollenme_gunu, yerlesme_gunu),
                  bedel=1, kritik=True),
            Kanit("Yer notu",
                  "Döllenme çoğunlukla fallop tüpünün üst kısmında olur. Rahim "
                  "duvarı embriyonun tutunup beslendiği yerdir.",
                  bedel=1, kritik=True),
            Kanit("Karışık kartlar", "Beş kart; her biri bir aşamayı anlatıyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Döllenme ile yerleşme için hangisi doğru?",
                dogru=("Ayrı olaylar: döllenme fallop tüpünde; embriyo günler sonra "
                       "rahim duvarına yerleşir"),
                yanlislar={
                    "Aynı olaydır: sperm yumurtaya ulaştığı an embriyo rahme "
                    "yerleşir; gebelik tek anda başlar":
                        "Döllenme ile yerleşmeyi aynı olay saydın. Arşiv takvimine "
                        "göre aralarında günler var ve yerleri farklı.",
                    "Yerleşme döllenmeden önce olur; yumurta rahme yerleşir, "
                    "sperm onu orada bulur":
                        "Yerleşecek bir embriyo olması için önce döllenme gerekir.",
                    "İkisi de rahimde, aynı gün olur; bebek rahimde geliştiğine "
                    "göre döllenme de orada olur":
                        "Döllenme çoğunlukla fallop tüpünde olur; rahme ulaşmak "
                        "günler sürer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Döllenme bir birleşmedir: sperm ve yumurta hücresi fallop "
                    "tüpünde zigotu oluşturur. Yerleşme ise sonradan gelen bir "
                    "tutunmadır: bölünerek büyüyen embriyo rahme ulaşır ve duvarına "
                    "gömülür."
                ),
                ipuclari=[
                    "Arşiv takviminde iki olayın günleri aynı mı?",
                    "Yer notu döllenme için hangi organı söylüyor?",
                ],
                cozum="Döllenme: fallop tüpü, 0. gün.\nYerleşme: rahim duvarı, yaklaşık 6-7 gün sonra.",
            ),
            sirala_adimi(
                soru="Kartları gelişim sırasına koy (numaraları sırayla yaz):",
                secenekler=kartlar,
                dogru_sira=dogru_sira,
                aciklama=("Yumurtlama -> döllenme (tüp) -> bölünmeler -> blastosist -> "
                          "yerleşme (rahim)."),
                ipuclari=["Yerleşecek bir hücre topluluğu olması için önce ne olmalı?"],
                puan=14,
            ),
            sayi_adimi(
                soru="Döllenmeden yerleşmenin başlamasına yaklaşık kaç gün geçer?",
                cevap=fark,
                birim="gün",
                aciklama="{}. gün − {}. gün = {} gün.".format(yerlesme_gunu, dollenme_gunu, fark),
                yaygin_yanlislar={
                    0:
                        "Döllenme ile yerleşmeyi aynı olay saydın; takvimde "
                        "aralarında {} gün var.".format(fark),
                    yerlesme_gunu:
                        "Yerleşmenin takvim gününü yazdın; soru döllenmeden sonra "
                        "geçen süreyi soruyor.",
                },
                ipuclari=["Arşiv takvimindeki iki günü karşılaştır."],
                puan=10,
            ),
            secim_adimi(
                soru="Karttaki not nasıl düzeltilmeli?",
                dogru=("\"Döllenme fallop tüpünde olur; embriyo {} gün sonra "
                       "rahim duvarına yerleşir.\"").format(fark),
                yanlislar={
                    "Düzeltme gerekmez; döllenme ve yerleşme aynı anda olur, "
                    "arada bekleme yoktur":
                        "Döllenme ile yerleşmeyi aynı olay saydın.",
                    "\"Döllenme rahim duvarında olur; yerleşme fallop "
                    "tüpündedir, bebek oradan rahme iner.\"":
                        "Yerler ters: döllenme tüpte, yerleşme rahimde.",
                    "\"Yerleşme döllenmeden {} gün önce olur; yumurta rahimde "
                    "spermi bekler.\"".format(fark):
                        "Sıra ters: önce döllenme, sonra yerleşme.",
                },
                rastgele=rastgele,
                aciklama="İki olay farklı yerde ve farklı zamanda: tüpte döllenme, "
                         "yaklaşık {} gün sonra rahimde yerleşme.".format(fark),
                ipuclari=["Yer notunu ve takvimi birlikte kullan."],
                puan=12,
            ),
        ],
        kapanis=("Kartlar sıralandı ve not düzeltildi: döllenme fallop tüpünde, "
                 "yerleşme yaklaşık {} gün sonra rahim duvarında."
                 ).format(fark),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# SINIFLANDIRMA: GÖRÜNÜŞ BENZERLİĞİ AKRABALIK KANITI DEĞİLDİR (B37.13)
#
# `siniflandirma` iki satırda boştu (2018: 9; 2026: 9). Bağlam: "Keşif
# numunelerini sınıflandırma ölçütleriyle düzenleme". `yaygin_yanlis`:
#
#   "Dış görünüş benzerliğini tek akrabalık kanıtı saymak."
#
# DÜZENEK: üç canlının özellik kartı. İkisi aynı ortama uyum sağladığı için
# BENZER GÖRÜNÜR (yüzgeç, kanat), ama temel yapıları (meme bezi, akciğer, kıl,
# yavru doğurma) üçüncüsüyle ortaktır. Akrabalığı ortak temel yapılar gösterir.
#
# YANILGININ SAYISAL KARŞILIĞI: ortak özellik sayısında görünüş özelliklerini
# saymak; "en yakın akraba" sorusunda benzer görüneni seçmek.
# ==========================================================================

# (hedef, benzer görünen, gerçek akraba, görünüş özellikleri, temel özellikler)
_SINIF_SETLERI = (
    ("yunus", "köpekbalığı", "inek",
     ("akıcı, torpido biçimli gövde", "yüzgeç biçimli ön üyeler"),
     ("meme bezleri, yavrusunu emzirir", "akciğerle solunum", "sıcakkanlılık",
      "yavru doğurma")),
    ("yarasa", "serçe", "fare",
     ("uçmaya yarayan kanat", "havada avlanma"),
     ("meme bezleri, yavrusunu emzirir", "vücudu kılla örtülü", "yavru doğurma",
      "dişli çene")),
)


def _tr_buyuk(ad):
    """Türkçe baş harf: "inek" -> "İnek" (str.capitalize "Inek" yapar)."""
    return ("İ" if ad[:1] == "i" else ad[:1].upper()) + ad[1:]


@bulmaca(ders="biyoloji", konu="siniflandirma", kademeler=(9, 13), agirlik=1.3)
def numune_kartlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Akrabalığı ortak temel yapılar gösterir; dış görünüş benzerliği uyumdan gelebilir."""
    hedef, benzer, akraba, gorunus, temel = rastgele.choice(_SINIF_SETLERI)
    temel_sayi = len(temel)
    gorunus_sayi = len(gorunus)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    def maddeler(liste):
        return "; ".join(liste)

    return Bulmaca(
        kod="biyo-numune-kartlari",
        ders="biyoloji",
        baslik="Numune Kartları",
        kademe=kademe,
        konu="siniflandirma",
        kazanim="Sınıflandırmada dış görünüş benzerliği ile temel yapısal "
                "özellikleri ayırt etme; akrabalığı ortak temel özelliklere göre "
                "belirleme.",
        dikkat=7,
        brifing=(
            "Keşif arşivine üç canlının kartı eklenecek: {}, {} ve {}.\n\n"
            "{} kartları hızlıca gruplandırdı: \"{} ile {} birbirine çok benziyor; "
            "demek ki en yakın akrabalar onlar. {} ayrı grupta.\"\n\n"
            "Kartlar arşive girmeden önce sınıflandırmayı ölçütlerle denetlememiz "
            "gerekiyor."
        ).format(hedef, benzer, akraba, kisi, _tr_buyuk(hedef),
                 benzer, _tr_buyuk(akraba)),
        kanitlar=[
            Kanit("{} ile {} ortak".format(_tr_buyuk(hedef), benzer),
                  maddeler(gorunus) + ".", bedel=1, kritik=True),
            Kanit("{} ile {} ortak".format(_tr_buyuk(hedef), akraba),
                  maddeler(temel) + ".", bedel=1, kritik=True),
            Kanit("Sınıflandırma notu",
                  "Aynı ortamda yaşayan canlılar birbirine benzer görünebilir "
                  "(yüzmeye, uçmaya uyum). Akrabalığı iç yapı, üreme ve gelişim "
                  "gibi temel özellikler gösterir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İki canlının akrabalığını en güvenilir biçimde ne gösterir?",
                dogru=("Üreme ve iç yapı gibi temel özellikler; görünüş "
                       "benzerliği ortama uyumdan gelebilir"),
                yanlislar={
                    "Dış görünüşlerinin benzerliği; benzer görünenler akrabadır, "
                    "ebeveynine benzeyen çocuk gibi":
                        "Dış görünüş benzerliğini tek akrabalık kanıtı saydın. "
                        "Yüzmeye ya da uçmaya uyum, akraba olmayan canlılarda da "
                        "benzer biçimler oluşturur.",
                    "Aynı ortamda yaşamaları; akrabalar aynı yerde kalır, "
                    "birbirinden uzağa dağılmaz":
                        "Aynı ortam benzer uyumlar doğurur; akrabalık göstermez.",
                    "Vücut büyüklüklerinin yakın olması; akraba canlılar benzer "
                    "boyda olur":
                        "Büyüklük yakın akrabalarda bile çok farklı olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Benzer ortam benzer çözümler üretir: yüzen canlılarda akıcı "
                    "gövde, uçanlarda kanat. Bu benzerlikler akrabalık kanıtı "
                    "değildir. Yavru doğurma, emzirme, solunum biçimi gibi temel "
                    "özellikler ortak kökeni gösterir."
                ),
                ipuclari=[
                    "Sınıflandırma notu benzer görünüşün nereden gelebileceğini söylüyor?",
                    "Hangi kartta üreme ve iç yapı özellikleri var?",
                ],
                cozum="Görünüş -> uyum.\nTemel yapı -> akrabalık.",
            ),
            sayi_adimi(
                soru="{} ile {} kaç TEMEL özelliği paylaşıyor?".format(_tr_buyuk(hedef), akraba),
                cevap=temel_sayi,
                aciklama="Kartta {} temel özellik var: {}.".format(temel_sayi, maddeler(temel)),
                yaygin_yanlislar={
                    gorunus_sayi:
                        "{} ile {} kartındaki görünüş özelliklerini saydın. Soru "
                        "{} ile {} kartını soruyor.".format(
                            _tr_buyuk(hedef), benzer, hedef, akraba),
                    0:
                        "Dış görünüş benzemiyor diye ortak özellik olmadığını "
                        "sandın; kartta temel özellikler yazılı.",
                },
                ipuclari=["İlgili kartı madde madde say."],
                puan=10,
            ),
            secim_adimi(
                soru="{} hangisiyle daha yakın akrabadır?".format(_tr_buyuk(hedef)),
                dogru="{}: meme bezleri ve yavru doğurma ortak".format(
                    _tr_buyuk(akraba)),
                yanlislar={
                    "{}: dış görünüşleri çok benziyor, bu da akrabalığı "
                    "gösterir".format(_tr_buyuk(benzer)):
                        "Dış görünüş benzerliğini tek akrabalık kanıtı saydın. {} "
                        "ile {} arasındaki benzerlik aynı yaşam biçimine uyumdan "
                        "geliyor.".format(_tr_buyuk(hedef), benzer),
                    "İkisine eşit uzaklıkta; kanıtlar birbirini götürüyor":
                        "İki kart eşit ağırlıkta değil: temel yapı akrabalığı, "
                        "görünüş ise uyumu gösterir.",
                    "Hiçbiriyle akraba değil; ayrı bir âleme ait":
                        "Üçü de hayvanlar âleminde; soru hangisinin daha yakın "
                        "olduğu.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{} ve {} memelidir: {}. {} ile benzer görünüşleri aynı "
                    "yaşam biçimine uyumdan geliyor."
                ).format(_tr_buyuk(hedef), akraba, maddeler(temel),
                         _tr_buyuk(benzer)),
                ipuclari=["Hangi kart temel yapıları, hangisi görünüşü anlatıyor?"],
                puan=12,
            ),
        ],
        kapanis=("Kartlar düzeltildi: {} ile {} aynı grupta (memeliler). {} ile "
                 "benzerlik uyum kaynaklı olarak not edildi."
                 ).format(hedef, akraba, _tr_buyuk(benzer)),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# CANLILIĞIN ORTAK ÖZELLİKLERİ VE BİLİMSEL KANIT (B37.13 -- müfredat haritası)
#
# `biyoloji_bilimi` iki satırda boştu (2018: 9; 2026: 9). Bağlam: "Sefer
# gözlem kaydında iddia ile kanıtı ayırma". `yaygin_yanlis`:
#
#   "Canlılık özelliğini tek bir ölçüte indirgemek; ilişkiyi neden saymak."
#
# DÜZENEK: sefer kaydında dört numune (tuz kristali, kamp ateşi, maya, kuru
# tohum) beş canlılık ölçütüyle işaretlenmiş. Kristal ve ateş "büyüyor";
# canlılık tek ölçütle verilemez. İkinci kayıt: lamba açık kalan gecelerde
# böcek sayısı yüksek -- ama o geceler aynı zamanda daha sıcak.
#
# YANILGILARIN KARŞILIĞI: kristalin karşıladığı ölçüt sayısında "büyüme var,
# canlıdır" demek; canlıları seçerken büyüyenleri seçmek; lamba-böcek
# ilişkisini neden saymak.
# ==========================================================================

_CANLILIK_OLCUTLERI = ("hücresel yapı", "metabolizma (enerji dönüşümü)",
                       "üreme", "uyarılara tepki", "büyüme")
# numune -> karşıladığı ölçütler
_NUMUNE_OLCUTLERI = (
    ("tuz kristali", ("büyüme",)),
    ("kamp ateşi", ("büyüme",)),
    ("maya", _CANLILIK_OLCUTLERI),
    ("kuru fasulye tohumu (ıslatılınca çimlendi)", ("hücresel yapı", "metabolizma (enerji dönüşümü)",
                             "üreme", "uyarılara tepki", "büyüme")),
)
_CANLI_NUMUNELER = ("maya", "kuru fasulye tohumu (ıslatılınca çimlendi)")


@bulmaca(ders="biyoloji", konu="biyoloji_bilimi", kademeler=(9, 13), agirlik=1.3)
def gozlem_kaydi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Canlılık birden çok ortak özellikle belirlenir; birlikte değişen iki şey neden-sonuç olmayabilir."""
    lamba_bocek = rastgele.choice((28, 32, 36, 40))
    kapali_bocek = rastgele.choice((10, 12, 14))
    sicak_fark = rastgele.choice((5, 6, 7))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    sira = list(range(len(_NUMUNE_OLCUTLERI)))
    rastgele.shuffle(sira)
    numuneler = [_NUMUNE_OLCUTLERI[i][0] for i in sira]
    canlilar = [n for n, i in enumerate(sira) if _NUMUNE_OLCUTLERI[i][0] in _CANLI_NUMUNELER]
    tablo = "\n".join("{}: {}".format(ad[:1].upper() + ad[1:], ", ".join(olcutler))
                      for ad, olcutler in _NUMUNE_OLCUTLERI)
    kristal_sayi = len(_NUMUNE_OLCUTLERI[0][1])

    return Bulmaca(
        kod="biyo-gozlem-kaydi",
        ders="biyoloji",
        baslik="Gözlem Kaydı",
        kademe=kademe,
        konu="biyoloji_bilimi",
        kazanim="Canlılığı birden çok ortak özellikle belirleme; tek ölçüte dayalı "
                "sınıflandırmayı eleştirme; birlikte değişen iki değişkenin neden-"
                "sonuç ilişkisi kanıtlamadığını açıklama.",
        dikkat=7,
        brifing=(
            "Sefer gözlem kaydı arşive girecek, ama iki not tartışmalı.\n\n"
            "{} birinci nota \"Büyüyen her şey canlıdır; tuz kristali de kamp ateşi "
            "de büyüdü.\" yazmış. İkinci nota: \"Lamba açık kalan gecelerde çok daha "
            "fazla böcek sayıldı; demek ki lamba böcek üretiyor.\"\n\n"
            "Kayıt onaylanmadan önce iddiaları kanıtlarla ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Ölçüt tablosu",
                  "Canlılık ölçütleri: {}.\nNumunelerde gözlenenler:\n{}".format(
                      ", ".join(_CANLILIK_OLCUTLERI), tablo),
                  bedel=1, kritik=True),
            Kanit("Böcek sayımı",
                  "Lamba açık geceler: ortalama {} böcek. Lamba kapalı geceler: "
                  "ortalama {} böcek.".format(lamba_bocek, kapali_bocek),
                  bedel=1, kritik=True),
            Kanit("Hava kaydı",
                  "Lambanın açık bırakıldığı geceler, kapalı olanlardan ortalama "
                  "{} °C daha sıcaktı. Böcekler sıcak gecelerde daha etkin olur."
                  .format(sicak_fark),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir numunenin canlı olup olmadığına nasıl karar verilir?",
                dogru=("Canlılığın ortak özellikleri birlikte aranır; büyüme gibi "
                       "tek ölçüt cansızda da görülür"),
                yanlislar={
                    "Büyüyorsa canlıdır; büyüme tek başına yeter, cansız bir şey "
                    "kendiliğinden büyümez":
                        "Canlılık özelliğini tek bir ölçüte indirgedin. Tuz kristali "
                        "ve ateş de büyüyor ama hücreleri yok, üremiyorlar.",
                    "Hareket ediyorsa canlıdır; cansız şeyler kendi kendine yer "
                    "değiştirmez":
                        "Ateşin alevi de hareket eder; kuru tohum hareket etmez ama "
                        "canlıdır.",
                    "Enerji kullanıyorsa canlıdır; yaşamak enerji harcamak "
                    "demektir, gerisine bakmaya gerek yok":
                        "Ateş de enerji dönüştürür; tek ölçüt yetmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Canlılar hücrelerden oluşur, metabolizma yürütür, ürer, "
                    "uyarılara tepki verir, büyüyüp gelişir. Bu özelliklerin biri "
                    "cansız bir şeyde de görülebilir; canlılığı hepsinin birlikte "
                    "bulunması gösterir."
                ),
                ipuclari=[
                    "Ölçüt tablosunda kristal kaç ölçütü karşılıyor?",
                    "Ateş üreyebilir mi, hücresi var mı?",
                ],
                cozum="Tek ölçüt değil, ölçütlerin birlikteliği.",
            ),
            sayi_adimi(
                soru="Tuz kristali beş canlılık ölçütünden kaçını karşılıyor?",
                cevap=kristal_sayi,
                aciklama="Yalnız büyüme: 1 ölçüt. Hücresi, metabolizması, üremesi yok.",
                yaygin_yanlislar={
                    5:
                        "Canlılık özelliğini tek bir ölçüte indirgedin: büyüdüğü "
                        "için bütün ölçütleri karşıladığını varsaydın.",
                    0:
                        "Tabloya göre kristal büyüyor; bir ölçütü karşılıyor, ama "
                        "tek ölçüt canlılık için yetmez.",
                },
                ipuclari=["Ölçüt tablosunda kristalin satırını say."],
                puan=10,
            ),
            coklu_adimi(
                soru="Hangi numuneler canlıdır? (numaraları virgülle yaz)",
                secenekler=numuneler,
                dogru_indeksler=canlilar,
                aciklama=(
                    "Maya ve kuru tohum bütün ölçütleri karşılıyor; tohumun "
                    "metabolizması yavaş ama durmuş değil. Kristal ve ateş yalnız "
                    "büyüme ölçütünü gösteriyor: cansız."
                ),
                ipuclari=["Bütün ölçütleri karşılayanları seç."],
                puan=12,
            ),
            secim_adimi(
                soru="\"Lamba böcek üretiyor\" iddiası için hangisi doğru?",
                dogru=("Kanıtlanmamış: lamba açık geceler aynı zamanda daha sıcak; "
                       "sıcaklık sabit tutularak denenmeli"),
                yanlislar={
                    "Doğru: lamba açıkken böcek sayısı arttığına göre lamba böcek "
                    "üretiyor; birlikte artan şeyler birbirini doğurur":
                        "İlişkiyi neden saydın. İki şeyin birlikte değişmesi, birinin "
                        "ötekini yarattığını göstermez; hava kaydı başka bir etkeni "
                        "işaret ediyor.",
                    "Yanlış: lambanın böceklerle hiçbir ilişkisi olamaz; sayılardaki "
                    "artış tesadüftür":
                        "İlişki olabilir (ışık böcekleri çekebilir), ama bu kayıtla "
                        "ayırt edilemiyor; kesin 'hiç' demek de kanıtsız.",
                    "Doğru: sıcaklık farkı önemsizdir, böcekler ışığı sever; "
                    "geceleri lambaya üşüştükleri bilinir":
                        "Hava kaydı sıcaklığın böceklerin etkinliğini artırdığını "
                        "söylüyor; bu etkeni yok sayamazsın.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Böcek sayısı ({} ve {}) lambayla birlikte değişti, ama o geceler "
                    "{} °C daha sıcaktı. Lambanın etkisini görmek için aynı sıcaklıkta "
                    "lambalı ve lambasız geceleri karşılaştırmak gerekir."
                ).format(lamba_bocek, kapali_bocek, sicak_fark),
                ipuclari=["Lamba açık gecelerde başka ne farklıydı?"],
                puan=12,
            ),
        ],
        kapanis=("Kayıt düzeltildi: kristal ve ateş cansız (tek ölçüt yetmez); lamba "
                 "ile böcek arasındaki bağ, sıcaklık denetlenmeden neden sayılmayacak."),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# BİTKİLERDE HAREKET: YER DEĞİŞTİRMEDEN TROPİZMA VE NASTİ (B37.13)
#
# `bitki_yapisi` (2018: 12) ve `canlilarda_tepki_bitki` (2026: 11) tek
# satırlıktı; ikisinin `yaygin_yanlis` ve bağlamı aynı ("Sera bitkisinde yapı
# ve büyüme yönünü ilişkilendirme"):
#
#   "Bitki hareketlerini yalnız yer değiştirme sanmak."
#
# DÜZENEK: sera gözlem defteri. Bitki yer değiştirmez ama organlarını hareket
# ettirir: uyarının YÖNÜNE göre büyüme (tropizma: ışığa eğilen gövde, aşağı
# kıvrılan kök, desteğe sarılan sülük) ve yönden bağımsız turgor/büyüme
# değişimi (nasti: dokununca kapanan küstüm, sıcakta açılan lale). Rüzgârda
# sallanma ya da saksının taşınması bitkinin kendi hareketi DEĞİL.
#
# YANILGININ SAYISAL KARŞILIĞI: kendi hareket sayısını 0 yazmak (bitki yer
# değiştirmedi); edilgen olayları da saymak.
# ==========================================================================

_TROPIZMA_GOZLEMLERI = (
    "Pencere önündeki fidenin gövdesi ışığa doğru eğildi.",
    "Yatay konan fidenin kökü aşağı doğru kıvrıldı.",
    "Fasulye sülükleri destek çubuğuna sarıldı.",
)
_NASTI_GOZLEMLERI = (
    "Küstüm otunun yaprakları dokununca kapandı.",
    "Lale çiçekleri sıcak öğlede açıldı, akşam serinliğinde kapandı.",
    "Fasulye yaprakları gece aşağı sarktı, sabah yeniden kalktı.",
)
_EDILGEN_GOZLEMLER = (
    "Havalandırma açılınca yapraklar rüzgârda sallandı.",
    "Saksı öteki rafa taşındı.",
    "Sulama suyu yaprakları bir süre aşağı bastırdı.",
)


@bulmaca(ders="biyoloji", konu="bitki_yapisi", kademeler=(11, 13), agirlik=1.3)
def sera_defteri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bitkiler yer değiştirmeden organlarını hareket ettirir: tropizma ve nasti."""
    tropizma = rastgele.sample(_TROPIZMA_GOZLEMLERI, 2)
    nasti = rastgele.sample(_NASTI_GOZLEMLERI, rastgele.choice((1, 2)))
    edilgen = rastgele.sample(_EDILGEN_GOZLEMLER, rastgele.choice((1, 2)))
    kayitlar = ([(g, "tropizma") for g in tropizma] + [(g, "nasti") for g in nasti]
                + [(g, "edilgen") for g in edilgen])
    rastgele.shuffle(kayitlar)
    gozlemler = [g for g, _ in kayitlar]
    kendi_sayisi = len(tropizma) + len(nasti)
    tropizma_indeksleri = [n for n, (_, tur) in enumerate(kayitlar) if tur == "tropizma"]
    isik_yonu, golge_yonu = rastgele.choice((("sol", "sağ"), ("sağ", "sol")))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-sera-defteri",
        ders="biyoloji",
        baslik="Sera Defteri",
        kademe=kademe,
        konu="bitki_yapisi",
        kazanim="Bitkilerin yer değiştirmeden organlarını hareket ettirdiğini açıklama; "
                "tropizmayı (uyarının yönüne göre büyüme) nastiden ayırma; ışığa "
                "yönelmeyi oksin dağılımı ve hücre uzamasıyla ilişkilendirme.",
        dikkat=7,
        brifing=(
            "Seranın haftalık gözlem defteri rapora dönüştürülecek.\n\n"
            "{} rapora şunu yazdı: \"Bitkiler kök saldıkları yerden hiç ayrılmıyor; "
            "yani hareket etmiyorlar. Defterdeki olayların hiçbiri bitki hareketi "
            "sayılmaz.\"\n\n"
            "Rapor gönderilmeden önce gözlemleri doğru sınıflandırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Gözlem defteri", "\n".join(gozlemler), bedel=1, kritik=True),
            Kanit("Hareket notu",
                  "Tropizma: organın uyarının geldiği yöne göre büyümesi (ışık, "
                  "yerçekimi, dokunma). Nasti: uyarının yönünden bağımsız, hücrelerdeki "
                  "su basıncı ya da büyüme farkıyla açılıp kapanma. Rüzgâr ya da insanın "
                  "taşıması bitkinin kendi hareketi değildir.",
                  bedel=1, kritik=True),
            Kanit("Oksin notu",
                  "Işık bir yandan gelince büyüme hormonu oksin gövde ucunun gölgede "
                  "kalan yanında birikir; o yandaki hücreler daha çok uzar.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bitkilerde hareket için hangisi doğrudur?",
                dogru=("Bitki yer değiştirmez ama organlarını büyüyerek ya da su "
                       "basıncıyla hareket ettirir"),
                yanlislar={
                    "Hareket yer değiştirmektir; kök salmış bitki hareket etmez, "
                    "yerinden kıpırdamayana hareket denmez":
                        "Bitki hareketlerini yalnız yer değiştirme sandın. Işığa "
                        "eğilen gövde ve kapanan küstüm yaprağı da harekettir.",
                    "Bitki kası olmadığı için yalnız rüzgâr ya da su gibi dış "
                    "etkilerle hareket eder":
                        "Dış etkiyle sallanma edilgendir; bitki kendi büyümesi ve "
                        "hücre basıncıyla da hareket eder.",
                    "Bitkinin bütün hareketleri uyarının yönüne göredir; ışığa "
                    "dönen gövde gibi":
                        "Nasti hareketleri uyarının yönünden bağımsızdır; küstüm "
                        "hangi yandan dokunulsa kapanır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Hayvanlar çoğunlukla yer değiştirerek hareket eder; bitkiler ise "
                    "sabit kalıp organlarını hareket ettirir. Bu hareketler ya büyüme "
                    "yönünün değişmesiyle (tropizma) ya da hücrelerin su basıncının "
                    "değişmesiyle (nasti) olur."
                ),
                ipuclari=[
                    "Işığa eğilen gövde yer değiştirdi mi, yine de hareket etti mi?",
                    "Hareket notunda edilgen olaylar nasıl ayrılıyor?",
                ],
                cozum="Tropizma: yönlü büyüme.\nNasti: yönsüz açılıp kapanma.\nEdilgen: dış etki, bitkinin hareketi değil.",
            ),
            sayi_adimi(
                soru="Defterdeki olaylardan kaç tanesi bitkinin kendi hareketidir?",
                cevap=kendi_sayisi,
                aciklama="{} tropizma + {} nasti = {}; rüzgâr, su ya da taşıma edilgen.".format(
                    len(tropizma), len(nasti), kendi_sayisi),
                yaygin_yanlislar={
                    0:
                        "Bitki hareketlerini yalnız yer değiştirme sandın; bitki "
                        "yerinden ayrılmadan organlarını hareket ettiriyor.",
                    len(kayitlar):
                        "Edilgen olayları da saydın; rüzgâr ya da taşıma bitkinin "
                        "kendi hareketi değil.",
                },
                ipuclari=["Bitkinin kendi büyümesi ya da hücre basıncıyla olanları say."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi olaylar tropizmadır (uyarının yönüne göre büyüme)? (numaraları virgülle yaz)",
                secenekler=gozlemler,
                dogru_indeksler=tropizma_indeksleri,
                aciklama=("Işığa eğilen gövde, yerçekimi yönünde kıvrılan kök ve desteğe "
                          "sarılan sülük uyarının yönüne göre büyüyor: tropizma. Açılıp "
                          "kapanan yaprak ve çiçekler nastidir."),
                ipuclari=["Olay uyarının hangi yönden geldiğine bağlı mı?"],
                puan=12,
            ),
            secim_adimi(
                soru="Işık fideye yalnız {} yandan gelirse hangisi olur?".format(isik_yonu),
                dogru=("Oksin gölgedeki {} yanda birikir; o yan daha çok uzar, "
                       "gövde {} yana eğilir").format(golge_yonu, isik_yonu),
                yanlislar={
                    ("Oksin ışık alan {} yanda birikir ve gövde {} yana eğilir; "
                     "oksin ışığın geldiği yana toplanır").format(isik_yonu, golge_yonu):
                        "Oksin notunu ters okudun: hormon gölgede birikir.",
                    "Fide yer değiştiremediği için ışığa yönelemez; kökü onu "
                    "olduğu yere bağlar":
                        "Bitki hareketlerini yalnız yer değiştirme sandın; fide "
                        "büyüme yönünü değiştirerek ışığa döner.",
                    "Gövde ışıktan kaçmak için {} yana eğilir; fazla ışık yaprağı "
                    "yakar".format(golge_yonu):
                        "Gövde ışığa doğru büyür (pozitif fototropizma).",
                },
                rastgele=rastgele,
                aciklama=("Gölgedeki yanın hücreleri daha çok uzadığı için gövde ışık "
                          "gelen yana kıvrılır: fototropizma."),
                ipuclari=["Oksin notunu oku: hangi yanın hücreleri daha çok uzuyor?"],
                puan=10,
            ),
        ],
        kapanis=("Rapor düzeltildi: defterde {} bitki hareketi var ({} tropizma, {} nasti); "
                 "bitkiler yer değiştirmeden hareket ediyor."
                 ).format(kendi_sayisi, len(tropizma), len(nasti)),
        odul={"itibar": 4, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# BİYOMOLEKÜLLER: BESİN TESTİ, ENZİM VE VİTAMİN (B37.13)
#
# `biyomolekuller` (2018: 9, 2026: 9) ve `besin_kanitlari` (2026: 9) aynı
# bağlamı paylaşıyor ("Üs numunesinin besin ve enzim verilerini yorumlama").
# İki `yaygin_yanlis`:
#
#   "Enzimin tepkimede tüketildiğini sanmak; vitaminleri enerji kaynağı saymak."
#   "Bir besinin yalnız tek tür organik madde içerdiğini sanmak."
#
# DÜZENEK: erzak numunesine dört besin testi (iyot, Benedict, biüret, yağ
# lekesi); her numunede en az iki test olumlu. Etiketten enerji hesabı: 1 g
# karbonhidrat ve protein 4 kcal, 1 g yağ 9 kcal, vitamin 0 kcal. Amilaz
# deneyi: nişasta bittikten sonra tüpteki enzim miktarı aynı; yeni nişasta
# ekleyince yine parçalıyor.
#
# YANILGILARIN SAYISAL KARŞILIĞI: vitamini 4 kcal/g saymak; tepkimeden sonra
# enzimi 0 mg yazmak. Çoklu seçimde yalnız tek organik madde işaretlemek.
# ==========================================================================

# numune -> olumlu testler (organik madde grupları)
_BESIN_NUMUNELERI = (
    ("mercimek unu", ("nişasta", "protein")),
    ("süt", ("indirgen şeker", "protein", "yağ")),
    ("fındık ezmesi", ("protein", "yağ")),
    ("yumurta sarısı", ("protein", "yağ")),
    ("ham muz", ("nişasta", "indirgen şeker")),
)
_BESIN_TESTLERI = (
    ("İyot çözeltisi", "nişasta", "mavi-mor", "sarı-kahve (değişmedi)"),
    ("Benedict testi", "indirgen şeker", "turuncu-kırmızı çökelti", "mavi (değişmedi)"),
    ("Biüret testi", "protein", "mor", "mavi (değişmedi)"),
    ("Kâğıt lekesi testi", "yağ", "yarı saydam leke kaldı", "leke kalmadı"),
)
_ORGANIK_GRUPLAR = ("nişasta", "indirgen şeker", "protein", "yağ")


@bulmaca(ders="biyoloji", konu="biyomolekuller", kademeler=(9, 13), agirlik=1.3)
def numune_tahlili(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Besinler çoğunlukla birden çok organik madde içerir; enzim tükenmez; vitamin enerji vermez."""
    numune, olumlular = rastgele.choice(_BESIN_NUMUNELERI)
    gruplar = list(_ORGANIK_GRUPLAR)
    sonuclar = []
    for (test, grup, olumlu, olumsuz), grup_adi in zip(_BESIN_TESTLERI, gruplar):
        sonuclar.append("{} ({}): {}".format(test, grup_adi, olumlu if grup_adi in olumlular else olumsuz))
    olumlu_indeksler = [n for n, g in enumerate(gruplar) if g in olumlular]
    tek_grup = [g for g in gruplar if g in olumlular][0]
    tek_test = [t for t, grup, _, _ in _BESIN_TESTLERI if grup == tek_grup][0]

    karb = rastgele.choice((10, 20, 30))
    prot = rastgele.choice((5, 10, 15))
    yag = rastgele.choice((2, 4, 6))
    vitamin = rastgele.choice((1, 2))
    enerji = 4 * karb + 4 * prot + 9 * yag
    enzim = rastgele.choice((2, 3, 5))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-numune-tahlili",
        ders="biyoloji",
        baslik="Numune Tahlili",
        kademe=kademe,
        konu="biyomolekuller",
        kazanim="Besin testlerinin sonuçlarından bir besindeki organik maddeleri "
                "belirleme; besin etiketinden enerji hesaplayıp vitaminlerin enerji "
                "vermediğini açıklama; enzimin tepkimede tüketilmediğini deney "
                "verisiyle gösterme.",
        dikkat=7,
        brifing=(
            "Erzak deposundaki {} numunesi tahlil edildi; sonuçlar erzak kartına "
            "yazılacak.\n\n"
            "{} karta şunu yazdı: \"{} olumlu çıktı, demek ki bu besinde yalnız {} var. "
            "Amilaz da nişastayı parçalarken tükendi; tüpe yeni enzim "
            "koymalıyız. Enerji için de erzağa vitamin tableti ekleyelim.\"\n\n"
            "Kart basılmadan önce verileri doğru yorumlamamız gerekiyor."
        ).format(numune, kisi, tek_test, tek_grup),
        kanitlar=[
            Kanit("Test sonuçları", "\n".join(sonuclar), bedel=1, kritik=True),
            Kanit("Erzak etiketi",
                  "100 g ek gıda: {} g karbonhidrat, {} g protein, {} g yağ, {} g vitamin "
                  "karışımı. 1 g karbonhidrat ve 1 g protein 4 kcal, 1 g yağ 9 kcal "
                  "enerji verir; vitaminler enerji vermez.".format(karb, prot, yag, vitamin),
                  bedel=1, kritik=True),
            Kanit("Enzim deneyi",
                  "Tüpe {} mg amilaz ve nişasta kondu; 10 dakikada iyot testi olumsuz oldu "
                  "(nişasta bitti). Tüpteki amilaz yeniden ölçüldü. Aynı tüpe yeni nişasta "
                  "eklenince 10 dakikada o da parçalandı.".format(enzim),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Besinler, enzimler ve vitaminler için hangisi doğrudur?",
                dogru=("Besin çoğu zaman birden çok organik madde içerir; enzim "
                       "tükenmez; vitamin enerji vermez"),
                yanlislar={
                    "Bir besin yalnız tek tür organik madde içerir; ekmek "
                    "karbonhidrat, et proteindir":
                        "Bir besinin yalnız tek tür organik madde içerdiğini sandın. "
                        "Test sonuçlarında birden çok olumlu sonuç var.",
                    "Enzim tepkimeye girip tükenir; her tepkime için yeni enzim "
                    "gerekir, yakıt gibi harcanır":
                        "Enzimin tepkimede tüketildiğini sandın. Enzim deneyinde aynı "
                        "amilaz yeni nişastayı da parçaladı.",
                    "Vitaminler vücuda en çok enerjiyi veren besin öğeleridir; "
                    "yorgunluğa vitamin önerilir":
                        "Vitaminleri enerji kaynağı saydın; etikete göre vitaminin "
                        "enerji değeri yok.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Mercimekte hem nişasta hem protein, sütte laktoz, protein ve yağ "
                    "vardır. Enzim tepkimeyi hızlandırır ve değişmeden çıkar; tekrar "
                    "kullanılır. Vitaminler az miktarda gereken düzenleyicilerdir; enerji "
                    "karbonhidrat, yağ ve proteinden gelir."
                ),
                ipuclari=[
                    "Test sonuçlarında kaç test olumlu?",
                    "Enzim deneyinde ikinci nişasta partisine ne oldu?",
                ],
                cozum="Besin: çoğu zaman karışık.\nEnzim: tükenmez.\nVitamin: 0 kcal.",
            ),
            coklu_adimi(
                soru="Test sonuçlarına göre numunede hangi organik maddeler var? (numaraları virgülle yaz)",
                secenekler=gruplar,
                dogru_indeksler=olumlu_indeksler,
                aciklama="Olumlu çıkan her test ayrı bir organik madde grubunu gösterir: {}.".format(
                    ", ".join(g for g in gruplar if g in olumlular)),
                ipuclari=["Rengi değişen ya da leke bırakan testleri seç."],
                puan=12,
            ),
            sayi_adimi(
                soru="Etiketteki 100 g ek gıda kaç kcal enerji verir?",
                cevap=enerji,
                birim="kcal",
                aciklama="4 × {} + 4 × {} + 9 × {} = {} kcal; vitamin karışımı 0 kcal.".format(
                    karb, prot, yag, enerji),
                yaygin_yanlislar={
                    enerji + 4 * vitamin:
                        "Vitaminleri enerji kaynağı saydın; vitamin karışımına da gram "
                        "başına 4 kcal verdin.",
                    4 * karb + 4 * prot + 4 * yag:
                        "Yağın gramını 4 kcal saydın; yağ 9 kcal verir.",
                },
                ipuclari=["Her besin öğesinin gramını kendi kcal değeriyle çarp."],
                puan=12,
            ),
            sayi_adimi(
                soru="Nişasta bittikten sonra tüpte kaç mg amilaz vardır?",
                cevap=enzim,
                birim="mg",
                aciklama="Enzim tepkimeden değişmeden çıkar: {} mg; bu yüzden yeni nişastayı da parçaladı.".format(enzim),
                yaygin_yanlislar={
                    0:
                        "Enzimin tepkimede tüketildiğini sandın; öyle olsaydı ikinci "
                        "nişasta partisi parçalanmazdı.",
                },
                ipuclari=["Aynı tüpe eklenen yeni nişastaya ne oldu?"],
                puan=10,
            ),
            yorum_adimi(
                soru="Erzak kartı için hangi düzeltme doğru?",
                dogru=("Numune birden çok organik madde içerir; enzim yeniden "
                       "kullanılır; enerji karbonhidrat ve yağdan gelir"),
                yanlislar={
                    ("Numune yalnız {}; enzim yenilenmeli; vitamin tableti enerji "
                     "verir, yorgunluğa iyi gelir").format(tek_grup):
                        "Üç yanılgıyı birden karta yazdın: tek besin öğesi, tükenen enzim, "
                        "enerji veren vitamin.",
                    "Numune birden çok organik madde içerir ama enzim yine de her "
                    "seferinde yenilenmeli, çünkü tepkimede harcanır":
                        "Enzimin tepkimede tüketildiğini sandın.",
                },
                rastgele=rastgele,
                aciklama="Veriler üç iddiayı da çürütüyor: çok sayıda olumlu test, yeniden çalışan enzim, 0 kcal vitamin.",
                ipuclari=["Üç kanıt kartını birlikte düşün."],
                puan=8,
            ),
        ],
        kapanis=("Erzak kartı düzeltildi: {} içinde {} var; amilaz tükenmedi ({} mg); ek "
                 "gıda {} kcal veriyor, vitaminler bunun içinde değil."
                 ).format(numune, ", ".join(g for g in gruplar if g in olumlular), enzim, enerji),
        odul={"itibar": 4, "erzak": 3, "enerji": 1},
    )


# ==========================================================================
# HOMEOSTAZİ: DENGE, HİÇ DEĞİŞMEMEK DEĞİLDİR (B37.13)
#
# `homeostazi` tek satırlıktı (2026: 11). Bağlam: "Üs biyoloji modelinde geri
# bildirim döngüsünü yorumlama". `yaygin_yanlis`:
#
#   "Dengenin bütün değerlerin hiç değişmemesi olduğunu sanmak."
#
# DÜZENEK: sağlık kaydındaki ölçüm dizisi (kan şekeri ya da vücut sıcaklığı)
# gün boyunca dalgalanıyor ama her sapmadan sonra ayar değerine geri dönüyor.
# Negatif geri bildirim: sapma yönünün TERSİNE çalışan tepki.
#
# YANILGININ SAYISAL KARŞILIĞI: en yüksek ile en düşük ölçüm arasındaki farkı
# 0 yazmak; dalgalanmayı "denge yok" diye yorumlamak.
# ==========================================================================

# (ad, birim, ayar değeri, ölçümler, yükselince devreye giren, düşünce devreye giren)
_HOMEOSTAZI_KAYITLARI = (
    ("kan şekeri", "mg/dL", 90, (92, 138, 118, 96, 84, 91),
     "insülin (şekeri hücrelere alarak düşürür)", "glukagon (karaciğerden şeker salarak yükseltir)"),
    ("vücut sıcaklığı", "°C", 37, (36.8, 37.4, 37.2, 36.9, 36.6, 37.0),
     "terleme ve damar genişlemesi (ısı kaybını artırır)",
     "titreme ve damar daralması (ısı kaybını azaltır)"),
)


@bulmaca(ders="biyoloji", konu="homeostazi", kademeler=(11, 13), agirlik=1.3)
def saglik_kaydi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Homeostazi dar bir aralıkta dinamik dengedir; negatif geri bildirim sapmayı geri çeker."""
    ad, birim, ayar, olcumler, yukselince, dusunce = rastgele.choice(_HOMEOSTAZI_KAYITLARI)
    fark = round(max(olcumler) - min(olcumler), 2)
    en_yuksek = max(olcumler)
    saatler = [8 + 2 * i for i in range(len(olcumler))]
    tablo = "; ".join("{}:00 -> {}".format(s, sy(o)) for s, o in zip(saatler, olcumler))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-saglik-kaydi",
        ders="biyoloji",
        baslik="Sağlık Kaydı",
        kademe=kademe,
        konu="homeostazi",
        kazanim="Homeostazinin dar bir aralıkta dinamik denge olduğunu ölçüm dizisiyle "
                "gösterme; negatif geri bildirimde tepkinin sapmanın tersi yönde "
                "olduğunu açıklama.",
        dikkat=7,
        brifing=(
            "Üs sağlık biriminde bir ekip üyesinin gün boyu {} ölçümleri alındı; "
            "kayıt değerlendirilecek.\n\n"
            "{} rapora şunu yazdı: \"Denge demek hiçbir değerin değişmemesi demektir. "
            "Ölçümler gün boyunca değişmiş; demek ki bu kişide denge (homeostazi) "
            "bozulmuş.\"\n\n"
            "Rapor imzalanmadan önce kaydı doğru yorumlamamız gerekiyor."
        ).format(ad, kisi),
        kanitlar=[
            Kanit("Ölçüm kaydı",
                  "{} ({}). Ayar değeri yaklaşık {}.\n{}".format(
                      ad[:1].upper() + ad[1:], birim, sy(ayar), tablo),
                  bedel=1, kritik=True),
            Kanit("Geri bildirim notu",
                  "Homeostazi, iç ortamın dar bir aralıkta tutulmasıdır; değerler "
                  "dalgalanır ama ayar değerine geri döner. Negatif geri bildirimde "
                  "tepki, sapmanın tersi yönde çalışır.",
                  bedel=1, kritik=True),
            Kanit("Düzenleyiciler",
                  "Değer yükselince: {}.\nDeğer düşünce: {}.".format(yukselince, dusunce),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Homeostazi (iç denge) için hangisi doğrudur?",
                dogru=("Değerler dar aralıkta dalgalanır, her sapmadan sonra ayar "
                       "değerine döner"),
                yanlislar={
                    "Denge, bütün değerlerin hiç değişmemesidir; dengedeki terazi "
                    "kıpırdamaz":
                        "Dengenin bütün değerlerin hiç değişmemesi olduğunu sandın. "
                        "Kayıtta değerler değişiyor ama ayar değerine geri dönüyor.",
                    "Değer değiştiği anda homeostazi bozulmuştur; sağlıklı vücutta "
                    "değer sabit kalır":
                        "Sapma normaldir; önemli olan geri bildirimin değeri geri "
                        "çekmesi.",
                    "Geri bildirim sapmayı aynı yönde büyütür, çünkü tepki "
                    "uyaranla aynı yöne gider":
                        "Bu pozitif geri bildirimdir; iç dengeyi negatif geri bildirim "
                        "korur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Homeostazi durgunluk değil, sürekli düzeltmedir: yemek sonrası "
                    "yükselen değer, düzenleyici tepkiyle ayar değerine döner. Ölçümler "
                    "dalgalanıyorsa sistem çalışıyor demektir."
                ),
                ipuclari=[
                    "Kayıtta değerler sonunda nereye dönüyor?",
                    "Geri bildirim notunda tepkinin yönü ne?",
                ],
                cozum="Homeostazi = dar aralıkta dinamik denge\nNegatif geri bildirim: ters yönde tepki",
            ),
            sayi_adimi(
                soru="Kayıttaki en yüksek ve en düşük ölçüm arasındaki fark kaç {}?".format(birim),
                cevap=fark,
                birim=birim,
                aciklama="{} − {} = {} {}.".format(sy(max(olcumler)), sy(min(olcumler)), sy(fark), birim),
                yaygin_yanlislar={
                    0:
                        "Dengenin bütün değerlerin hiç değişmemesi olduğunu sandın; "
                        "kayıtta ölçümler dalgalanıyor.",
                },
                ipuclari=["En büyük ölçümden en küçüğünü çıkar."],
                puan=10,
                tolerans=0.01,
            ),
            secim_adimi(
                soru="Ölçüm {} değerine çıktığında hangi tepki devreye girer?".format(sy(en_yuksek)),
                dogru=yukselince,
                yanlislar={
                    dusunce:
                        "Negatif geri bildirimde tepki sapmanın tersi yönde olur; bu "
                        "tepki değeri daha da yükseltirdi.",
                    "Hiçbiri: dengede olan vücutta tepki gerekmez, değer "
                    "kendiliğinden eski yerine döner":
                        "Dengeyi koruyan şey tam da bu tepkiler; olmasalardı değer "
                        "geri dönmezdi.",
                },
                rastgele=rastgele,
                aciklama="Yükselen değeri düşüren tepki devreye girer: {}.".format(yukselince),
                ipuclari=["Düzenleyiciler kartını oku."],
                puan=12,
            ),
            yorum_adimi(
                soru="Rapor için hangisi doğru?",
                dogru="Homeostazi çalışıyor: değerler dalgalanıp ayar değerine dönüyor",
                yanlislar={
                    "Homeostazi bozulmuş: ölçümler gün boyunca değişmiş, sabit "
                    "kalmaları gerekirdi":
                        "Dengenin bütün değerlerin hiç değişmemesi olduğunu sandın.",
                    "Homeostazi çalışıyor çünkü bütün ölçümler birbirinin aynı":
                        "Ölçümler aynı değil; denge, sapmaların geri çekilmesiyle sağlanıyor.",
                },
                rastgele=rastgele,
                aciklama="Değerler {} {} aralığında dalgalanıp {} dolayına dönüyor.".format(
                    sy(fark), birim, sy(ayar)),
                ipuclari=["Son ölçümler ayar değerine yakın mı?"],
                puan=10,
            ),
        ],
        kapanis=("Rapor düzeltildi: {} ölçümleri {} {} aralığında dalgalanıp ayar değeri "
                 "olan {} dolayına dönüyor; homeostazi çalışıyor."
                 ).format(ad, sy(fark), birim, sy(ayar)),
        odul={"itibar": 4, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# BAĞIŞIKLIK: HER TEPKİ AYNI ÖZGÜLLÜKTE DEĞİL (B37.13)
#
# `bagisiklik` tek satırlıktı (2026: 11). Bağlam: "Hazır savunma modeli
# üzerinde tepki türlerini ayırma". `yaygin_yanlis`:
#
#   "Her bağışıklık tepkisini aynı özgüllükte sanmak."
#
# DÜZENEK: savunma modeli kartları. Özgül olmayan (doğal) savunma her mikroba
# aynı biçimde karşılık verir: deri, mide asidi, iltihap, ateş, fagositoz.
# Özgül (kazanılmış) savunma belirli antijene göre çalışır ve hafıza bırakır:
# B lenfosit antikorları, T lenfositler. Antikor ölçümü ikinci karşılaşmada
# daha hızlı ve daha yüksek; ama bu hafıza YALNIZ aynı mikrop için geçerli.
#
# YANILGILARIN SAYISAL KARŞILIĞI: ikinci karşılaşmadaki antikor tepesini ilk
# karşılaşmayla aynı (kat = 1) saymak; başka mikrop için de hafıza beklemek.
# ==========================================================================

_OZGUL_OLMAYAN = (
    "Deri ve mukoza engeli: mikropların girişini engeller",
    "Mide asidi: yutulan mikropların çoğunu öldürür",
    "İltihap tepkisi: bölgeye kan akışını ve savunma hücrelerini artırır",
    "Ateş: mikropların üremesini yavaşlatır",
    "Fagositoz: akyuvarlar mikrobu yutup sindirir",
)
_OZGUL = (
    "B lenfositler: o antijene özel antikor üretir",
    "T lenfositler: o antijeni taşıyan hücreleri tanıyıp yok eder",
    "Hafıza hücreleri: aynı antijenle ikinci karşılaşmada hızlı tepki verir",
)


@bulmaca(ders="biyoloji", konu="bagisiklik", kademeler=(11, 13), agirlik=1.3)
def savunma_modeli(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Doğal savunma her mikroba aynı karşılığı verir; özgül savunma antijene özeldir ve hafıza bırakır."""
    ozgul_olmayan = rastgele.sample(_OZGUL_OLMAYAN, 3)
    ozgul = rastgele.sample(_OZGUL, 2)
    kartlar = [(k, False) for k in ozgul_olmayan] + [(k, True) for k in ozgul]
    rastgele.shuffle(kartlar)
    secenekler = [k for k, _ in kartlar]
    ozgul_indeksler = [n for n, (_, o) in enumerate(kartlar) if o]

    ilk_tepe = rastgele.choice((20, 25, 40))
    kat = rastgele.choice((8, 10, 12))
    ikinci_tepe = ilk_tepe * kat
    ilk_gun = rastgele.choice((10, 12))
    ikinci_gun = rastgele.choice((3, 4))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-savunma-modeli",
        ders="biyoloji",
        baslik="Savunma Modeli",
        kademe=kademe,
        konu="bagisiklik",
        kazanim="Özgül olmayan (doğal) ve özgül (kazanılmış) bağışıklık tepkilerini "
                "ayırt etme; hafıza hücrelerinin yalnız aynı antijene karşı hızlı tepki "
                "sağladığını antikor verisiyle açıklama.",
        dikkat=7,
        brifing=(
            "Üs sağlık eğitimi için savunma modeli kartları düzenlenecek; antikor "
            "ölçümleri de raporda yer alacak.\n\n"
            "{} kartlara şunu yazdı: \"Bütün savunma tepkileri aynıdır; hepsi mikroba "
            "özel çalışır ve hepsi hafıza bırakır. Bir mikrobu geçiren kişi artık "
            "bütün mikroplara karşı hızlı tepki verir.\"\n\n"
            "Kartlar dağıtılmadan önce tepki türlerini ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Savunma kartları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Antikor ölçümü",
                  "X mikrobuyla ilk karşılaşma: antikor tepe değeri {} birim, {}. günde. "
                  "Aynı mikropla ikinci karşılaşma: {} birim, {}. günde. Aynı kişide "
                  "farklı bir mikropla (Y) ilk karşılaşma: {} birim, {}. günde.".format(
                      ilk_tepe, ilk_gun, ikinci_tepe, ikinci_gun, ilk_tepe, ilk_gun),
                  bedel=1, kritik=True),
            Kanit("Savunma notu",
                  "Özgül olmayan savunma her mikroba aynı biçimde karşılık verir ve "
                  "hafıza bırakmaz. Özgül savunma belirli bir antijene göre kurulur; "
                  "hafıza hücreleri yalnız o antijen için hızlı tepki sağlar.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bağışıklık tepkileri için hangisi doğrudur?",
                dogru=("Doğal savunma her mikroba aynıdır; özgül savunma tek "
                       "antijene yöneliktir, hafızası da o antijen içindir"),
                yanlislar={
                    "Bütün bağışıklık tepkileri mikroba özeldir ve hafıza "
                    "bırakır; vücut her mikrobu tanıyıp ona göre savaşır":
                        "Her bağışıklık tepkisini aynı özgüllükte saydın. Deri, mide "
                        "asidi ve fagositoz hangi mikrop olursa olsun aynı çalışır.",
                    "Hiçbir bağışıklık tepkisi mikroba özel değildir; akyuvarlar "
                    "önüne geleni yok eder":
                        "B ve T lenfositlerin tepkisi antijene özeldir.",
                    "Bir mikrobu geçiren kişi bütün mikroplara karşı bağışık "
                    "olur; hastalık bağışıklığı genel olarak güçlendirir":
                        "Hafıza yalnız karşılaşılan antijen için geçerli; ölçümde Y "
                        "mikrobuna tepki yine yavaş.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Savunmanın ilk hattı seçici değildir: her mikroba aynı engelleri "
                    "ve aynı hücresel tepkiyi uygular. İkinci hat antijene göre kurulur; "
                    "hafıza hücreleri o antijeni tanır ve ikinci karşılaşmada hızlı, "
                    "yüksek antikor tepkisi sağlar."
                ),
                ipuclari=[
                    "Antikor ölçümünde Y mikrobuna tepki nasıl?",
                    "Savunma notunda hangi tepki hafıza bırakıyor?",
                ],
                cozum="Doğal: her mikroba aynı, hafızasız.\nÖzgül: antijene özel, hafızalı.",
            ),
            coklu_adimi(
                soru="Hangi kartlar özgül (kazanılmış) bağışıklık tepkisidir? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=ozgul_indeksler,
                aciklama="Lenfositlerin antijene özel tepkisi ve hafıza hücreleri özgüldür; deri, asit, iltihap, ateş ve fagositoz özgül değildir.",
                ipuclari=["Kart belirli bir antijenden söz ediyor mu?"],
                puan=12,
            ),
            sayi_adimi(
                soru="X mikrobuyla ikinci karşılaşmada antikor tepe değeri ilkinin kaç katı?",
                cevap=kat,
                aciklama="{} ÷ {} = {}.".format(ikinci_tepe, ilk_tepe, kat),
                yaygin_yanlislar={
                    1:
                        "Her bağışıklık tepkisini aynı özgüllükte saydın; hafıza "
                        "hücreleri ikinci tepkiyi çok daha güçlü yapıyor.",
                    ikinci_tepe:
                        "Tepe değerini yazdın; soru kaç kat olduğunu soruyor.",
                },
                ipuclari=["İkinci tepe değerini ilkine böl."],
                puan=12,
            ),
            yorum_adimi(
                soru="Y mikrobu ölçümü ne gösteriyor?",
                dogru="Hafıza yalnız X mikrobuna özel: Y mikrobunda tepki yine yavaş ve düşük",
                yanlislar={
                    "X mikrobunu geçiren kişi Y mikrobuna da hızlı tepki verir, "
                    "sistem artık güçlü":
                        "Her bağışıklık tepkisini aynı özgüllükte saydın; ölçüm Y için "
                        "ilk karşılaşma değerlerini gösteriyor.",
                    "Y ölçümü hatalı; hafıza bütün mikroplar için çalışır":
                        "Özgül bağışıklık antijene özeldir; ölçüm bunu doğruluyor.",
                },
                rastgele=rastgele,
                aciklama="Y mikrobunda tepe {} birim ve {}. gün: X ile ilk karşılaşmadaki gibi.".format(
                    ilk_tepe, ilk_gun),
                ipuclari=["Antikor ölçümünde Y satırını X ile karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("Kartlar düzeltildi: doğal savunma her mikroba aynı, özgül savunma "
                 "antijene özel. X ile ikinci karşılaşmada antikor {} kat yüksek; Y "
                 "mikrobunda hafıza yok.").format(kat),
        odul={"itibar": 4, "erzak": 1, "enerji": 2},
    )


# ==========================================================================
# BİTKİDE TAŞIMA: ODUN SU, SOYMUK ORGANİK MADDE TAŞIR (B37.13)
#
# `bitki_tasima` tek satırlıktı (2018: 12). Bağlam: "Serada su ve organik madde
# hareketini modelleme". `yaygin_yanlis`:
#
#   "Odun ve soymuk borularının görevlerini karıştırmak."
#
# DÜZENEK: iki sera deneyi. (1) Kereviz sapı boyalı suya konur: boya odun
# borularında yükselir (su ve mineral, kökten yukarı, tek yönlü). (2) Bir
# dalın kabuğu halka şeklinde soyulur (soymuk kesilir, odun sağlam): yapraklar
# solmaz, ama yapraklarda üretilen şeker halkanın üstünde birikir; altı
# şekersiz kalır.
#
# YANILGILARIN SAYISAL KARŞILIĞI: halkalamadan sonra üst ve alt bölgenin şeker
# farkını 0 yazmak (şekeri odun taşır sanmak). Seçimlerde boyayı soymukta
# görmek, halkalanan dalın hemen solacağını sanmak.
# ==========================================================================


@bulmaca(ders="biyoloji", konu="bitki_tasima", kademeler=(12, 13), agirlik=1.3)
def sera_deneyleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Odun boruları suyu ve mineralleri, soymuk boruları organik maddeyi taşır."""
    yukseklik = rastgele.choice((9, 12, 15))        # cm, 30 dakikada
    hiz = yukseklik / 30.0                           # cm/dk
    govde = rastgele.choice((45, 60))                # cm
    sure = round(govde / hiz, 1)
    ust = rastgele.choice((18, 24))                  # mg/g şeker
    alt = rastgele.choice((5, 6))
    fark = ust - alt
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-sera-deneyleri",
        ders="biyoloji",
        baslik="Sera Deneyleri",
        kademe=kademe,
        konu="bitki_tasima",
        kazanim="Odun borularının su ve mineralleri kökten yukarı, soymuk borularının "
                "organik maddeyi yapraklardan öteki bölgelere taşıdığını deney "
                "verisiyle ayırt etme; halkalama deneyini yorumlama.",
        dikkat=8,
        brifing=(
            "Serada iki deney yapıldı; sonuçlar sulama ve budama planına "
            "işlenecek.\n\n"
            "{} rapora şunu yazdı: \"Suyu da şekeri de soymuk boruları taşır. "
            "Halkalanan dalın kabuğu soyulduğu için su gidemez, dal yarın solar; "
            "şeker de zaten her yere eşit dağılır.\"\n\n"
            "Plan yazılmadan önce deney sonuçlarını doğru yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Boya deneyi",
                  "Kereviz sapı mavi boyalı suya kondu; 30 dakikada boya {} cm yükseldi. "
                  "Kesit mikroskopta incelendi: boya kalın çeperli, ölü hücrelerden "
                  "oluşan borularda (odun) görüldü; ince çeperli canlı hücrelerde "
                  "(soymuk) görülmedi.".format(yukseklik),
                  bedel=1, kritik=True),
            Kanit("Halkalama deneyi",
                  "Bir dalın kabuğu halka şeklinde soyuldu; içteki odun sağlam bırakıldı. "
                  "10 gün sonra yapraklar canlı ve dik. Şeker ölçümü: halkanın üstü {} mg/g, "
                  "halkanın altı {} mg/g (deneyden önce ikisi de yaklaşık 10 mg/g).".format(ust, alt),
                  bedel=1, kritik=True),
            Kanit("Doku notu",
                  "Odun boruları: ölü hücreler, su ve mineralleri kökten yukarı taşır. "
                  "Soymuk boruları: canlı hücreler, yapraklarda üretilen organik maddeyi "
                  "gereken bölgeye (yukarı ya da aşağı) taşır; kabuğun iç kısmındadır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bitkide taşıma için hangisi doğrudur?",
                dogru=("Odun boruları su ve minerali kökten yukarı taşır; soymuk "
                       "boruları yaprakta yapılan besini dağıtır"),
                yanlislar={
                    "Soymuk boruları suyu, odun boruları şekeri taşır; su "
                    "kabuğun hemen altından, şeker gövdenin içinden gider":
                        "Odun ve soymuk borularının görevlerini karıştırdın. Boya "
                        "deneyinde su, ölü hücreli odun borularında yükseldi.",
                    "Su da şeker de aynı borularda, aynı yönde taşınır; bitkide "
                    "tek bir taşıma sistemi vardır":
                        "İki ayrı iletim dokusu var; halkalama deneyi şekerin kabuktaki "
                        "soymukla taşındığını gösteriyor.",
                    "Organik madde yalnız kökten yapraklara doğru taşınır; "
                    "besini bitki topraktan alır":
                        "Organik madde yapraklarda üretilir ve gereken yöne taşınır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Odun ölü, kalın çeperli hücrelerden oluşan tek yönlü bir su "
                    "hattıdır. Soymuk canlı hücrelerden oluşur ve şekeri kaynaktan "
                    "(yaprak) kullanım ya da depo yerine (kök, meyve) taşır. Kabuk "
                    "soyulunca soymuk kesilir, odun sağlam kalır."
                ),
                ipuclari=[
                    "Boya hangi hücrelerde görüldü?",
                    "Halkalanan dalın yaprakları neden solmadı?",
                ],
                cozum="Odun: su + mineral, yukarı.\nSoymuk: organik madde, kaynaktan kullanıma.",
            ),
            sayi_adimi(
                soru="Halkalamadan 10 gün sonra halkanın üstü ile altı arasındaki şeker farkı kaç mg/g?",
                cevap=fark,
                birim="mg/g",
                aciklama="{} − {} = {} mg/g. Soymuk kesildiği için yapraklardaki şeker aşağı inemedi.".format(
                    ust, alt, fark),
                yaygin_yanlislar={
                    0:
                        "Odun ve soymuk borularının görevlerini karıştırdın: şekeri odun "
                        "taşısaydı fark oluşmazdı; ölçüm tersini gösteriyor.",
                },
                ipuclari=["Halkalama deneyindeki iki ölçümü çıkar."],
                puan=12,
            ),
            secim_adimi(
                soru="Boya deneyinde boya hangi borularda görüldü?",
                dogru="Odun borularında: suyu kökten yukarı taşıyan ölü hücreli borular",
                yanlislar={
                    "Soymuk borularında: canlı hücreler suyu taşır, ölü hücre iş "
                    "göremez":
                        "Odun ve soymuk borularının görevlerini karıştırdın; boya kalın "
                        "çeperli ölü hücrelerde görüldü.",
                    "Her iki boruda eşit olarak; boya her yere ulaşır":
                        "Kesitte boya yalnız bir doku türünde görüldü.",
                },
                rastgele=rastgele,
                aciklama="Su ve içindeki boya odun borularıyla yükselir.",
                ipuclari=["Boya deneyi kartında hücre türünü oku."],
                puan=10,
            ),
            sayi_adimi(
                soru="Aynı hızla boya {} cm boyundaki bir sapın tepesine kaç dakikada ulaşır?".format(govde),
                cevap=sure,
                birim="dk",
                aciklama="Hız {} ÷ 30 = {} cm/dk. {} ÷ {} = {} dk.".format(
                    yukseklik, sy(round(hiz, 2)), govde, sy(round(hiz, 2)), sy(sure)),
                ipuclari=["Önce dakikada kaç cm yükseldiğini bul."],
                puan=8,
                tolerans=0.5,
            ),
            yorum_adimi(
                soru="Halkalanan dal için hangisi doğru?",
                dogru=("Yapraklar solmaz, çünkü odun sağlam; ama kökler şeker "
                       "alamayıp zamanla zayıflar"),
                yanlislar={
                    "Dal hemen solar, çünkü suyu taşıyan kabuk soyuldu; bitkinin "
                    "damarları kabuktadır":
                        "Odun ve soymuk borularının görevlerini karıştırdın; su odunla "
                        "taşınıyor ve yapraklar 10 gün sonra hâlâ dik.",
                    "Hiçbir şey değişmez; şeker her yere kendiliğinden eşit "
                    "dağılır":
                        "Ölçüm halkanın üstünde şeker biriktiğini gösteriyor.",
                },
                rastgele=rastgele,
                aciklama="Soymuk kesildi: şeker yukarıda birikti, aşağısı şekersiz kaldı. Odun sağlam: yapraklar su almaya devam etti.",
                ipuclari=["İki ölçümü ve yaprakların durumunu birlikte düşün."],
                puan=10,
            ),
        ],
        kapanis=("Rapor düzeltildi: su odunla yükseliyor ({} dakikada {} cm), şeker "
                 "soymukla taşınıyor; halkalanan dalda üstte {} mg/g şeker birikti, dal solmadı."
                 ).format(sy(sure), govde, ust),
        odul={"itibar": 4, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# CANLI VE ÇEVRE: HER ÇEVRESEL DEĞİŞİM KALITSAL DEĞİL (B37.13)
#
# `canli_cevre_uyum` tek satırlıktı (2018: 12). Bağlam: "Farklı ortamlardaki
# canlı özelliklerini kanıtla karşılaştırma". `yaygin_yanlis`:
#
#   "Her çevresel değişimi kalıtsal saymak."
#
# DÜZENEK: dağ ve ova popülasyonları arazide iki özellikte farklı. Tohumlar
# aynı sera bahçesinde (ortak bahçe) yetiştirilince bir fark SÜRÜYOR (kalıtsal
# uyum), öteki KAYBOLUYOR (çevrenin etkisi, modifikasyon). Ayrıca ortanca
# çeliklerinin toprak pH'ına göre renk değiştirmesi.
#
# YANILGININ SAYISAL KARŞILIĞI: ortak bahçede kaybolan özelliğin yavrulardaki
# oranını %100 yazmak.
# ==========================================================================

# (kalıtsal özellik adı, dağ değeri, ova değeri, bahçe dağ, bahçe ova, birim)
_KALITSAL_OZELLIKLER = (
    ("boy", 20, 60, 22, 58, "cm"),
    ("çiçeklenme günü", 40, 70, 42, 69, "gün"),
)
# (çevresel özellik, dağdaki durum, ovadaki durum)
_CEVRESEL_OZELLIKLER = (
    ("yaprak tüylülüğü", "yoğun tüylü", "tüysüz"),
    ("yaprak rengi", "koyu mor lekeli", "düz yeşil"),
)


@bulmaca(ders="biyoloji", konu="canli_cevre_uyum", kademeler=(12, 13), agirlik=1.3)
def ortak_bahce(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Çevrenin yol açtığı değişim kalıtsal değildir; ortak bahçe deneyi ikisini ayırır."""
    k_ad, dag, ova, b_dag, b_ova, birim = rastgele.choice(_KALITSAL_OZELLIKLER)
    c_ad, c_dag, c_ova = rastgele.choice(_CEVRESEL_OZELLIKLER)
    bahce_fark = abs(b_ova - b_dag)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="biyo-ortak-bahce",
        ders="biyoloji",
        baslik="Ortak Bahçe",
        kademe=kademe,
        konu="canli_cevre_uyum",
        kazanim="Canlılardaki farkın kalıtsal uyum mu, çevrenin etkisi (modifikasyon) "
                "mu olduğunu ortak ortam deneyiyle ayırt etme; modifikasyonların "
                "yavrulara aktarılmadığını açıklama.",
        dikkat=8,
        brifing=(
            "Keşif ekibi dağ yamacı ve ova popülasyonlarından aynı bitki türünü "
            "topladı; farklar arşive yazılacak.\n\n"
            "{} arşive şunu yazdı: \"Dağdaki bitkilerin {} ve {} ovadakilerden farklı; "
            "çevreye uyum sağlamışlar, bu özelliklerin hepsi artık kalıtsal. "
            "Tohumları nereye eksek eksek aynı özellikler çıkar.\"\n\n"
            "Arşive geçmeden önce farkları kanıtla ayırmamız gerekiyor."
        ).format(kisi, k_ad, c_ad),
        kanitlar=[
            Kanit("Arazi ölçümü",
                  "Dağ yamacı: {} {} {}, {} {}. Ova: {} {} {}, {} {}.".format(
                      k_ad, dag, birim, c_ad, c_dag, k_ad, ova, birim, c_ad, c_ova),
                  bedel=1, kritik=True),
            Kanit("Ortak bahçe deneyi",
                  "İki popülasyonun tohumları aynı sera bahçesinde, aynı toprak, ışık ve "
                  "sulamayla yetiştirildi. Dağ tohumlarından: {} {} {}, {} {}. Ova "
                  "tohumlarından: {} {} {}, {} {}.".format(
                      k_ad, b_dag, birim, c_ad, c_ova, k_ad, b_ova, birim, c_ad, c_ova),
                  bedel=1, kritik=True),
            Kanit("Ortanca notu",
                  "Aynı ortanca bitkisinden alınan çelikler asidik toprakta mavi, bazik "
                  "toprakta pembe çiçek açtı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Farklı ortamlardaki canlıların farkları için hangisi doğrudur?",
                dogru=("Bazı farklar kalıtsal, bazıları çevreden; ayırmak için "
                       "canlılar aynı ortamda yetiştirilir"),
                yanlislar={
                    "Çevrenin yol açtığı her değişim kalıtsal olur ve yavrulara "
                    "geçer; canlı edindiğini yavrusuna aktarır":
                        "Her çevresel değişimi kalıtsal saydın. Ortak bahçede bazı farklar "
                        "kayboluyor: onlar çevrenin anlık etkisiydi.",
                    "Hiçbir fark kalıtsal değildir; hepsi çevreden gelir, aynı "
                    "türün bireyleri özünde aynıdır":
                        "Ortak bahçede de süren fark kalıtsal olmalı.",
                    "Farkların kaynağı arazi ölçümünden kesin olarak anlaşılır; "
                    "ölçülen fark gerçektir":
                        "Arazide hem genler hem çevre farklı; ayırmak için ortamı eşitlemek gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı genler farklı ortamda farklı görünüm verebilir (modifikasyon); bu "
                    "değişim yavrulara geçmez. Ortak bahçede ortam eşitlenince yalnız "
                    "kalıtsal farklar kalır."
                ),
                ipuclari=[
                    "Ortak bahçede hangi fark sürdü, hangisi kayboldu?",
                    "Ortanca çelikleri aynı bitkiden mi?",
                ],
                cozum="Ortak ortamda süren fark: kalıtsal.\nKaybolan fark: çevresel (modifikasyon).",
            ),
            sayi_adimi(
                soru="Ortak bahçede iki popülasyonun {} farkı kaç {}?".format(k_ad, birim),
                cevap=bahce_fark,
                birim=birim,
                aciklama="{} − {} = {} {}: fark aynı ortamda da sürüyor, kalıtsal.".format(
                    max(b_ova, b_dag), min(b_ova, b_dag), bahce_fark, birim),
                yaygin_yanlislar={
                    0:
                        "Farkın bahçede kaybolduğunu sandın; ölçüme bak, bu özellikte "
                        "fark sürüyor.",
                    abs(ova - dag):
                        "Arazi ölçümünü kullandın; soru ortak bahçeyi soruyor.",
                },
                ipuclari=["Ortak bahçe deneyindeki iki değeri çıkar."],
                puan=10,
            ),
            sayi_adimi(
                soru="Dağ tohumlarından ortak bahçede yetişen bitkilerin yüzde kaçı {} gösterir?".format(c_dag),
                cevap=0,
                birim="%",
                aciklama="Bahçede dağ tohumlarının hepsi de {}: {} çevrenin etkisiydi, kalıtsal değil.".format(
                    c_ova, c_ad),
                yaygin_yanlislar={
                    100:
                        "Her çevresel değişimi kalıtsal saydın; ortam değişince özellik "
                        "kayboldu.",
                },
                ipuclari=["Ortak bahçe deneyinde dağ tohumlarının bu özelliğine bak."],
                puan=12,
            ),
            secim_adimi(
                soru="Ortanca çiçeğinin rengi için hangisi doğru?",
                dogru="Çevrenin etkisi: aynı bitkinin çelikleri toprağa göre farklı renk açtı",
                yanlislar={
                    "Kalıtsal fark: mavi ve pembe ortancalar farklı türdür, renk "
                    "türün işaretidir":
                        "Her çevresel değişimi kalıtsal saydın; çelikler aynı bitkiden, "
                        "genleri aynı.",
                    "Rastlantı: renk hiçbir şeye bağlı değildir":
                        "Renk toprağın asitliğiyle düzenli olarak değişiyor.",
                },
                rastgele=rastgele,
                aciklama="Genleri aynı çelikler farklı toprakta farklı renk verdi: modifikasyon.",
                ipuclari=["Ortanca notunu oku."],
                puan=8,
            ),
        ],
        kapanis=("Arşiv düzeltildi: {} farkı ortak bahçede de sürdü, kalıtsal uyum; {} "
                 "farkı kayboldu, çevrenin etkisi. Ortanca rengi de modifikasyon."
                 ).format(k_ad, c_ad),
        odul={"itibar": 4, "erzak": 2, "enerji": 1},
    )
