# -*- coding: utf-8 -*-
"""
Konu taraması.

Bu bir sınav DEĞİLDİR ve öyle hissettirmemesi için özellikle böyle kurulmuştur:
süre yoktur, net hesaplanmaz, yanlışın bir bedeli yoktur, puan gösterilmez.

Tek işi şu: öğrencinin hangi konuları rahatlıkla yaptığını, hangilerinde
takıldığını anlamak ve her konuyu doğru öğretim aşamasına yerleştirmek.

  - Konuyu bilen öğrenci baştan anlatım izlemek zorunda kalmaz; doğrudan
    kendi başına çözmeye geçer.
  - Takıldığı konu anlatımdan başlar.

Yani tarama, ölçmek için değil, NEREDEN BAŞLANACAĞINI bulmak için yapılır.
Sorular her konudan bir tanedir ve modelleme adımı seçilir: "işlemi yapabiliyor
mu" değil, "olayı kurabiliyor mu" bilgisi aranır.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import terminal as ekran
from .degerlendirme import degerlendir, dogru_cevap_metni
from .durum import Durum
from .kayit_defteri import konular, uret
from .modeller import (
    Adim, ANLATIM, Bulmaca, DERS_ADLARI, DERS_RENGI, MODEL, SERBEST,
)
from .terminal import S

# Bir taramada sorulacak en çok konu sayısı. Uzun tarama yorar ve amacına
# ters düşer; gerekirse öğrenci taramayı tekrar yapar.
EN_COK_KONU = 8


@dataclass
class KonuSonucu:
    ders: str
    konu: str
    bildi: bool
    atladi: bool
    soru: str
    dogru_cevap: str
    aciklama: str
    cozum: str


@dataclass
class TaramaSonucu:
    ders: str
    sonuclar: List[KonuSonucu] = field(default_factory=list)
    yarida_birakildi: bool = False

    @property
    def bilinen(self) -> List[KonuSonucu]:
        return [s for s in self.sonuclar if s.bildi]

    @property
    def calisilacak(self) -> List[KonuSonucu]:
        return [s for s in self.sonuclar if not s.bildi]


# --------------------------------------------------------------------------
# Soru seçimi
# --------------------------------------------------------------------------

def _konu_sorusu(durum: Durum, ders: str, konu_kodu: str) -> Optional[Tuple[Bulmaca, Adim]]:
    """Bir konudan tek soru: varsa modelleme adımı, yoksa ilk adım."""
    bulmaca = uret(
        ders=ders,
        kademe=durum.ders(ders).kademe,
        rastgele=durum.rastgele("tarama-{}-{}".format(ders, konu_kodu)),
        konu=konu_kodu,
    )
    if bulmaca is None or not bulmaca.adimlar:
        return None
    modelli = [a for a in bulmaca.adimlar if a.rol == MODEL]
    return bulmaca, (modelli[0] if modelli else bulmaca.adimlar[0])


# --------------------------------------------------------------------------
# Tarama
# --------------------------------------------------------------------------

def _soru_goster(bulmaca: Bulmaca, adim: Adim, sira: int, toplam: int) -> None:
    ekran.temizle()
    renk = DERS_RENGI.get(bulmaca.ders, "beyaz")
    ekran.yaz("İZ SÜRME  {}/{}   {}".format(
        sira, toplam, bulmaca.baslik), "kalin", renk)
    ekran.ayrac()
    ekran.yaz()
    ekran.kutu(bulmaca.brifing, bulmaca.baslik, "beyaz")

    for kanit in bulmaca.kanitlar:
        ekran.kutu(kanit.icerik, kanit.etiket, "gri")

    ekran.yaz()
    ekran.yaz(adim.soru, "beyaz", "kalin")
    if adim.secenekler:
        ekran.yaz()
        for i, secenek in enumerate(adim.secenekler, 1):
            ekran.asili_yaz("  {:>2}) ".format(i), secenek,
                            onek_renkleri=("acik_sari",))


def tarama_yap(durum: Durum, ders: str) -> Optional[TaramaSonucu]:
    """Bir dersin konularını tarar ve her konuyu doğru aşamaya yerleştirir."""
    konu_listesi = konular(ders)
    if not konu_listesi:
        ekran.hata("Bu derste konu yok.")
        ekran.bekle()
        return None

    ders_durumu = durum.ders(ders)
    # Önce hiç dokunulmamış konular taranır; oturmuş konuları tekrar sormak
    # hem zaman kaybı hem de öğrenci için gereksiz bir sınav hissi yaratır.
    sirali = sorted(konu_listesi,
                    key=lambda k: (ders_durumu.konu(k).baslanmis,
                                   ders_durumu.konu(k).ustalik))
    secilen = sirali[:EN_COK_KONU]

    ekran.temizle()
    ekran.baslik("İZ SÜRME", "kalin", "acik_cam")
    ekran.yaz()
    ekran.kutu(
        "Bu bir sınav değil. Süre yok, puan yok, yanlışın hiçbir şey "
        "kaybettirmez.\n\n"
        "Her işten bir tane göstereceğim. Amacım neyi rahat yaptığını, "
        "nerede takıldığını görmek; sonra sana doğru yerden başlatayım.\n\n"
        "Bilmediğin soruyu boş geçmen bir sorun değil - hatta işime yarar. "
        "Boş geçmek için Enter'a bas.",
        "NASIL İŞLİYOR", "beyaz")
    ekran.yaz()
    ekran.yaz("{} iş bakacağız.".format(len(secilen)), "gri")
    if not ekran.onayla("Başlayalım mı?", True):
        return None

    sonuc = TaramaSonucu(ders=ders)

    for sira, konu_kodu in enumerate(secilen, 1):
        paket = _konu_sorusu(durum, ders, konu_kodu)
        if paket is None:
            continue
        bulmaca, adim = paket

        _soru_goster(bulmaca, adim, sira, len(secilen))
        ham = ekran.sor("Cevabın (bilmiyorsan Enter):").strip()

        if ham.lower() == "x":
            if ekran.onayla("Taramayı burada kesip sonuca bakalım mı?", True):
                sonuc.yarida_birakildi = True
                break
            ham = ""

        atladi = not ham
        bildi = False if atladi else degerlendir(adim, ham)[0]

        sonuc.sonuclar.append(KonuSonucu(
            ders=ders, konu=konu_kodu, bildi=bildi, atladi=atladi,
            soru=adim.soru, dogru_cevap=dogru_cevap_metni(adim),
            aciklama=adim.aciklama, cozum=adim.cozum,
        ))

        # Anında ve yumuşak geri bildirim: doğru/yanlış denmez, yönlendirilir.
        ekran.yaz()
        if bildi:
            ekran.basari("Bu iş sende var; listeye öyle yazdım.")
        elif atladi:
            ekran.bilgi("Tamam, buna birlikte bakarız.")
        else:
            ekran.bilgi("Bunu baştan göstereceğim; şimdilik takılman normal.")
        ekran.bekle()

    return sonuc


# --------------------------------------------------------------------------
# Sonuç ve yönlendirme
# --------------------------------------------------------------------------

def sonucu_uygula(durum: Durum, sonuc: TaramaSonucu) -> None:
    """
    Tarama sonucuna göre her konuyu doğru öğretim aşamasına yerleştirir.

    Bilen öğrenci anlatımı tekrar izlemek zorunda kalmaz; takılan öğrenci
    en baştan başlar. Taramanın bütün amacı budur.
    """
    ders_durumu = durum.ders(sonuc.ders)
    for kayit in sonuc.sonuclar:
        konu = ders_durumu.konu(kayit.konu)
        if konu.baslanmis:
            continue  # zaten çalışılmış bir konuyu tarama geri almaz
        if kayit.bildi:
            konu.asama = SERBEST
            konu.ustalik = max(konu.ustalik, 0.6)
        else:
            konu.asama = ANLATIM
    durum.gunluk_ekle("İz sürme yapıldı.")
    durum.kaydet()


def sonucu_goster(sonuc: TaramaSonucu) -> Optional[str]:
    """
    Tarama haritasını gösterir. Devam edilecek konu seçilirse onu döner.
    """
    ekran.temizle()
    ekran.baslik("İZLERİN SÖYLEDİĞİ", "kalin", "acik_cam")

    if not sonuc.sonuclar:
        ekran.bilgi("Hiç konu taranmadı.")
        ekran.bekle()
        return None

    bilinen = sonuc.bilinen
    calisilacak = sonuc.calisilacak

    ekran.yaz()
    ekran.yaz("{} işten {} tanesi zaten elinde, {} tanesine bakacağız.".format(
        len(sonuc.sonuclar), len(bilinen), len(calisilacak)), "kalin")
    ekran.yaz()
    ekran.yaz("Burada \"yanlış\" diye bir şey yok; bu liste sadece nereden "
              "başlayacağımızı söylüyor.", "gri")

    if bilinen:
        ekran.yaz()
        ekran.yaz("BUNLAR SENDE VAR", "kalin", "acik_yesil")
        for kayit in bilinen:
            ekran.madde(kayit.konu.replace("_", " "), "acik_yesil",
                        isaret=S["onay"])
        ekran.yaz("Bunlarda doğrudan kendi başına çalışabilirsin.",
                  "gri", girinti="   ")

    if calisilacak:
        ekran.yaz()
        ekran.yaz("BUNLARA BİRLİKTE BAKACAĞIZ", "kalin", "acik_sari")
        for kayit in calisilacak:
            not_metni = "boş geçtin" if kayit.atladi else "takıldın"
            ekran.madde("{}  ({})".format(
                kayit.konu.replace("_", " "), not_metni), "acik_sari")
        ekran.yaz("Bunları önce sana göstereceğim; kimse senden bilmeni "
                  "beklemiyor.", "gri", girinti="   ")

    ekran.bekle()

    if not calisilacak:
        ekran.yaz()
        ekran.basari("Taradığım bütün konular sende var. "
                     "İstersen bir üst zorluğa geçebilirsin.")
        ekran.bekle()
        return None

    ekran.yaz()
    secenekler = [k.konu.replace("_", " ") for k in calisilacak[:5]]
    secenekler.append("Şimdi değil, geri döneyim")
    secim = ekran.menu("Hangisinden başlayalım?", secenekler,
                       ipucu="İstediğin sırayla gidebilirsin.")
    if secim < len(calisilacak[:5]):
        return calisilacak[secim].konu
    return None
