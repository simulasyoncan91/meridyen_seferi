# -*- coding: utf-8 -*-
"""
Yayına hazır klasör üretir: oyunu bir web adresine koymak için.

    python main.py --yayin

NEDEN GEREKİYOR
---------------
Oyun telefonda `SharedArrayBuffer` kullanıyor (senkron `input()` için) ve
tarayıcılar onu **yalnızca https** üzerinde veriyor. Dosyaya tıklamak,
düz http, yerel ağ -- hiçbiri yeterli değil. Bu bir ayar değil,
kapatılamayan bir tarayıcı kuralı.

Sonuç: oyunun telefonda açılması için bir kez bir web adresine konması
gerekiyor. Ondan sonrası rahat -- sayfa telefona kurulabiliyor (PWA) ve
bir daha ne bilgisayar ne internet istiyor.

Sınıf için zaten tek yol bu: otuz öğrenci kendi hücresel verisiyle
bağlanacaksa hepsinin öğretmenin bilgisayarına bağlanması mümkün değil.

BU KLASÖRDE NE YOK
------------------
`sunucu_ornegi.py` (yerel deneme sunucusu) ve `deneme-sertifikasi.pem`
YAYINA GİRMEZ. Birincisi gereksiz, ikincisi özel anahtar içeriyor --
gerçek sunucuda onun işi yok, sunucunun kendi sertifikası var.

BAŞLIK DOSYALARI
----------------
Sunucunun iki başlık vermesi şart:

    Cross-Origin-Opener-Policy: same-origin
    Cross-Origin-Embedder-Policy: credentialless

Yoksa sayfa açılır ama ilk soruda kilitlenir. Her servis bunu farklı
dosyadan okuyor; hepsi birden konuyor, ilgisiz olan görmezden gelinir.
"""
from __future__ import annotations

import io
import os
import shutil

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KAYNAK = os.path.join(KOK, "mobil")
HEDEF = os.path.join(KOK, "yayin")

# Yayına GİRECEK dosyalar. Beyaz liste kullanıyoruz, kara liste değil:
# `mobil/` klasörüne ileride bir şey eklendiğinde sessizce yayına
# sızmasın. Özel anahtar sızdırmanın en kolay yolu "hepsini kopyala".
DOSYALAR = (
    "index.html", "isci.js", "oyun_paketi.zip", "ayarlar.json",
    "manifest.webmanifest", "sw.js", "simge.svg",
    "simge-192.png", "simge-512.png",
)

BASLIKLAR = """/*
  Cross-Origin-Opener-Policy: same-origin
  Cross-Origin-Embedder-Policy: credentialless
"""

VERCEL = """{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "Cross-Origin-Opener-Policy", "value": "same-origin" },
        { "key": "Cross-Origin-Embedder-Policy", "value": "credentialless" }
      ]
    }
  ]
}
"""

OKU = """# Oyunu yayına koymak

Bu klasörü olduğu gibi bir yere yükle. Toplam boyut 500 KB'nin altında.

## En kolayı: Netlify Drop (hesap bile gerekmiyor)

1. https://app.netlify.com/drop adresini aç.
2. BU KLASÖRÜ sayfaya sürükle bırak.
3. Sana `https://...netlify.app` diye bir adres verir.
4. O adresi telefonda aç.

`_headers` dosyası gerekli ayarı kendisi yapıyor, elle bir şey yok.

## Cloudflare Pages

Aynı `_headers` dosyasını okur. Ücretsiz, sınırsız trafik.

## Vercel

`vercel.json` dosyası hazır.

## Kendi sunucun varsa

nginx:

    add_header Cross-Origin-Opener-Policy same-origin;
    add_header Cross-Origin-Embedder-Policy credentialless;

Apache:

    Header set Cross-Origin-Opener-Policy "same-origin"
    Header set Cross-Origin-Embedder-Policy "credentialless"

## Çalıştı mı, nasıl anlarım

Adresi telefonda aç. Sol altta küçük bir yazı görünür:

* **"çevrimdışı hazır"** -> her şey tamam. Oyun telefona kaydedildi,
  bundan sonra internet olmasa da açılır.
* **"çevrimdışı hazır değil"** -> oyun çalışır ama her açılışta yeniden
  iner. Dokununca sebebini söyler.

Sayfa açılıp da ilk soruda kilitleniyorsa başlıklar gelmiyordur.

## Telefona kurmak (öğrencilere söylenecek)

Adresi tarayıcıda aç, menüden **"Ana ekrana ekle"** de. Uygulama gibi
açılır ve internet gerekmez.

## Sınıf kodu kullanacaksan

`ayarlar.json` içindeki `sinif_sunucusu` alanına sınıf sunucusunun
adresini yaz (bkz. `SINIF_KURULUMU.md`). Boş bırakılırsa oyun tek başına
çalışır; sınıf kodu ve el kaldırma kapalı olur.

**Sunucu da https olmalı:** sayfa https ise tarayıcı http bir adrese
bağlanmayı reddeder.
"""


def yayinla() -> str:
    """`yayin/` klasörünü üretir ve yolunu döndürür."""
    from araclar.mobil_paket import guncel_mi, main as mobil_paketle

    if not guncel_mi():
        print("  mobil/oyun_paketi.zip eskiydi, yenileniyor...")
        mobil_paketle()

    shutil.rmtree(HEDEF, ignore_errors=True)
    os.makedirs(HEDEF, exist_ok=True)

    eksik = []
    for ad in DOSYALAR:
        kaynak = os.path.join(KAYNAK, ad)
        if not os.path.exists(kaynak):
            eksik.append(ad)
            continue
        shutil.copy2(kaynak, os.path.join(HEDEF, ad))

    for ad, metin in (("_headers", BASLIKLAR), ("vercel.json", VERCEL),
                      ("OKU.md", OKU)):
        with io.open(os.path.join(HEDEF, ad), "w", encoding="utf-8",
                     newline="\n") as d:
            d.write(metin)

    boyut = sum(os.path.getsize(os.path.join(HEDEF, a))
                for a in os.listdir(HEDEF))
    print("Yayın klasörü hazır: {}".format(HEDEF))
    print("  {} dosya, {:.0f} KB".format(len(os.listdir(HEDEF)), boyut / 1024))
    if eksik:
        print("  !! EKSİK: {}".format(", ".join(eksik)))
    print()
    print("  Sırada: https://app.netlify.com/drop adresine bu klasörü")
    print("  sürükle bırak. Ayrıntı: yayin/OKU.md")
    return HEDEF


def main() -> int:
    yayinla()
    return 0


if __name__ == "__main__":
    import sys
    sys.path.insert(0, KOK)
    raise SystemExit(main())
