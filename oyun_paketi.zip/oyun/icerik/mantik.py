# -*- coding: utf-8 -*-
"""
Muhakeme ve düzen kurma görevleri.

Bu ders oyunun fikrine en çok yakışan yer: muhakeme sorusunda zaten ezber
yoktur, verilenden çıkarım yapılır. Yaptığımız tek şey soruyu üssün içine
yerleştirmek ve öğrenciden önce "hangi kural işliyor" demesini istemek.

TEKNİK NOT - cevap tekliği:
Sıralama ve eşleştirme bulmacalarında ipuçlarını rastgele üretip sonra BÜTÜN
olasılıkları tarayarak tek çözüm kalıp kalmadığını denetliyoruz. Tek çözüm
kalmıyorsa ipucu ekleniyor. Böylece "birden fazla cevabı olan soru" üretmek
imkânsız hâle geliyor - tutarlı bir muhakeme görevinin ilk şartı da budur.
"""
from __future__ import annotations

import itertools
import random
from typing import Callable, List, Sequence, Tuple

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi, sirala_adimi, sy,
    yorum_adimi,
)


def _tek_cozum(kisiler: Sequence[str],
               kosullar: Sequence[Callable[[dict], bool]]) -> List[Tuple[str, ...]]:
    """Bütün sıralamaları tarar, koşulları sağlayanları döner."""
    uygun = []
    for dizilim in itertools.permutations(kisiler):
        yer = {ad: sira for sira, ad in enumerate(dizilim)}
        if all(kosul(yer) for kosul in kosullar):
            uygun.append(dizilim)
    return uygun


# ==========================================================================
# SIRALAMA
# ==========================================================================

@bulmaca(ders="mantik", konu="siralama", kademeler=(6, 13), agirlik=1.4)
def siralama_bulmacasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Beş kişilik bir sıralama; ipuçları tek çözüme kilitlenene kadar eklenir."""
    kisiler = [ad.split()[-1] for ad in ad_sec(rastgele, PERSONEL, 5)]
    gercek = list(kisiler)
    rastgele.shuffle(gercek)

    yer = {ad: sira for sira, ad in enumerate(gercek)}

    # Aday ipucu havuzu: her biri (metin, koşul) çifti
    adaylar: List[Tuple[str, Callable[[dict], bool]]] = []

    for a, b in itertools.combinations(kisiler, 2):
        if yer[a] < yer[b]:
            once, sonra = a, b
        else:
            once, sonra = b, a
        adaylar.append((
            "{} önce, {} sonra teslim etti.".format(once, sonra),
            (lambda o, s: (lambda y: y[o] < y[s]))(once, sonra),
        ))
        if abs(yer[a] - yer[b]) == 1:
            adaylar.append((
                "{} teslim etti, hemen ardından {}.".format(once, sonra),
                (lambda o, s: (lambda y: y[o] + 1 == y[s]))(once, sonra),
            ))

    ilk = gercek[0]
    son = gercek[-1]
    adaylar.append(("{} ilk teslim eden kişiydi.".format(ilk),
                    (lambda k: (lambda y: y[k] == 0))(ilk)))
    adaylar.append(("{} en son teslim etti.".format(son),
                    (lambda k: (lambda y: y[k] == 4))(son)))
    orta = gercek[2]
    adaylar.append(("{} tam ortada, üçüncü sırada teslim etti.".format(orta),
                    (lambda k: (lambda y: y[k] == 2))(orta)))

    rastgele.shuffle(adaylar)

    # Tek çözüm kalana kadar ipucu ekle
    secilen: List[Tuple[str, Callable]] = []
    for aday in adaylar:
        if len(_tek_cozum(kisiler, [k for _, k in secilen])) == 1:
            break
        secilen.append(aday)
    # Gereksiz ipuçlarını ayıkla: çıkarınca hâlâ tek çözüm veriyorsa gerekmiyordur
    sadelesmis = list(secilen)
    for aday in list(sadelesmis):
        kalan = [k for k in sadelesmis if k is not aday]
        if len(_tek_cozum(kisiler, [k for _, k in kalan])) == 1:
            sadelesmis = kalan

    cozumler = _tek_cozum(kisiler, [k for _, k in sadelesmis])
    if len(cozumler) != 1:
        # Emniyet kemeri: tek çözüm çıkmadıysa tam sırayı veren ipuçlarına dön
        sadelesmis = []
        for i in range(4):
            once, sonra = gercek[i], gercek[i + 1]
            sadelesmis.append((
                "{} teslim etti, hemen ardından {}.".format(once, sonra),
                (lambda o, s: (lambda y: y[o] + 1 == y[s]))(once, sonra),
            ))
        cozumler = _tek_cozum(kisiler, [k for _, k in sadelesmis])

    dogru_dizilim = list(cozumler[0])
    ipucu_metinleri = [m for m, _ in sadelesmis]

    karisik = list(kisiler)
    rastgele.shuffle(karisik)
    dogru_sira = [karisik.index(ad) for ad in dogru_dizilim]

    return Bulmaca(
        kod="man-siralama",
        ders="mantik",
        baslik="Teslim Sırası",
        kademe=kademe,
        konu="siralama",
        kazanim="Sözel muhakeme: kısmi bilgilerden tam sıralamaya ulaşma.",
        dikkat=6,
        brifing=(
            "Beş görevli aylık raporunu ayrı ayrı teslim etti: {}.\n\n"
            "Teslim saatlerini yazması gereken nöbetçi uyuyakalmış. Elimizde "
            "saat yok; yalnızca görevlilerin birbirleri hakkında söyledikleri "
            "var.\n\n"
            "Merkeze gidecek dosyada teslim sırası yazacak. Söylenenlerden tam "
            "sırayı çıkarman gerekiyor."
        ).format(", ".join(kisiler)),
        kanitlar=[
                     Kanit("Görevli ifadesi {}".format(i + 1), metin, bedel=1, kritik=True)
                     for i, metin in enumerate(ipucu_metinleri)
                 ] + [
                     Kanit("Nöbetçi defteri",
                           "Saat sütunu boş. Yalnızca \"beş teslim alındı\" yazıyor.",
                           bedel=1),
                     Kanit("Muhakeme notu",
                           "\"Bu tür sıralamalarda önce KESİN bilgiyi kullan: bir "
                           "kişiyi belli bir sıraya çivileyen ifadeyi bul, diğerlerini "
                           "ona göre yerleştir.\"", bedel=2, kritik=True),
                 ],
        adimlar=[
            model_adimi(
                soru="Bu sıralamayı çözmeye nereden başlamak gerekir?",
                dogru="Bir kişinin yerini kesin belirleyen ifadeden.",
                yanlislar={
                    "İfadeleri verildikleri sırayla tek tek uygulamaktan.":
                        "İfadelerin yazılma sırası bir bilgi değil; nöbetçi "
                        "onları rastgele not etmiş. \"Ondan önce\" diyen bir "
                        "ifade, dayanacak bir yer bulunmadan hiçbir kişiyi "
                        "kutusuna oturtmaz.",
                    "İsimleri alfabetik sıraya dizmekten.":
                        "Alfabe ile teslim sırasını karıştırdın. İfadelerin "
                        "hiçbiri isimlerin harflerinden söz etmiyor; sıra "
                        "yalnızca söylenenlerden çıkar.",
                    "En çok adı geçen kişiyi başa koymaktan.":
                        "İfade sayısını konum bilgisi sandın. Bir kişinin çok "
                        "anılması onun erken teslim ettiğini değil, hakkında "
                        "çok konuşulduğunu gösterir.",
                    "Rastgele bir sıra kurup ifadelerle karşılaştırmaktan.":
                        "Deneme yanılma sonunda doğruyu bulur ama beş kişi "
                        "için 120 farklı dizilim var. Kesin bilgiden "
                        "başlarsan bu dizilimlerin neredeyse hepsi tek "
                        "hamlede elenir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sıralama sorularında bilgiler iki türlüdür: KESİN (\"ilk teslim "
                    "eden oydu\", \"üçüncü sıradaydı\") ve GÖRECELİ (\"ondan önce "
                    "teslim etti\"). Kesin bilgi bir kişiyi doğrudan bir kutuya "
                    "oturtur; göreceli bilgi ise ancak bir dayanak varsa işe yarar. "
                    "Bu yüzden önce çivi çakılır, sonra etrafı örülür."
                ),
                ipuclari=[
                    "İfadelerden hangisi tek başına bir kişinin yerini söylüyor?",
                    "\"İlk\", \"son\", \"üçüncü\" gibi sözler geçen ifadeyi ara.",
                ],
                puan=18,
                cozum=(
                    "1) Önce kesin konum bildiren ifadeleri işaretle ve o kişileri "
                    "yerlerine koy.\n"
                    "2) Sonra \"hemen önce\" diyen ifadeleri kullan: bunlar iki kişiyi "
                    "birbirine yapıştırır, ikisini tek blok gibi düşün.\n"
                    "3) En son \"önce/sonra\" diyen gevşek ifadelerle kalan boşlukları "
                    "doldur.\n"
                    "4) Kurduğun sırayı bütün ifadelerle tek tek sına; hepsini "
                    "sağlıyorsa cevap odur.\n\n"
                    "Bu soruda doğru sıra: " + " - ".join(dogru_dizilim)
                ),
            ),
            sirala_adimi(
                soru="Teslim sırasını ilkten sona doğru diz (numaraları sırayla yaz):",
                secenekler=karisik,
                dogru_sira=dogru_sira,
                aciklama="Doğru sıra: " + " - ".join(dogru_dizilim) +
                         ". Bu dizilim verilen ifadelerin hepsini birden sağlayan tek dizilimdir.",
                ipuclari=[
                    "Kesin konum bildiren ifadeyle başla.",
                    "\"Hemen önce\" diyen ifadeler iki kişiyi yan yana kilitler.",
                ],
                puan=22,
                cozum=(
                    "İfadeler tek tek uygulandığında yalnızca şu dizilim hepsini "
                    "birden sağlar:\n\n  " + " - ".join(dogru_dizilim) +
                    "\n\nDenetim: her ifadeyi bu sıraya uygula, hiçbiri çelişmiyor. "
                    "Başka bir dizilim denendiğinde en az bir ifade bozulur."
                ),
            ),
            secim_adimi(
                soru="{} kaçıncı sırada teslim etti?".format(dogru_dizilim[1]),
                dogru="2. sırada",
                yanlislar={
                    "1. sırada":
                        "\"Önce teslim etti\" ile \"ilk teslim etti\"yi "
                        "karıştırdın. Birinden önce olmak, herkesten önce "
                        "olmak demek değildir; kurduğun dizilimde bu adın "
                        "solunda kimse kalmamış mı, bak.",
                    "3. sırada":
                        "Sayarken bir kişiyi atladın. Dizilimin en solundan "
                        "başlayıp aradığın ada gelene kadar herkesi tek tek "
                        "say; ortada olmak ile ortaya yakın olmak aynı şey "
                        "değil.",
                    "4. sırada":
                        "Sondan saydın. Teslim sırası ilk teslim edenden "
                        "başlar; aynı kişi sağdan sayınca başka bir numara "
                        "alır.",
                    "5. sırada":
                        "\"En son teslim etti\" diyen ifadeyi bu ada "
                        "yapıştırdın. O ifade dizilimin öteki ucundaki kişiyi "
                        "anlatıyor; kurduğun sıraya dönüp adı nerede "
                        "bıraktığını kontrol et.",
                },
                rastgele=rastgele,
                aciklama="Bulunan sırada {} ikinci teslim eden kişidir.".format(
                    dogru_dizilim[1]),
                ipuclari=["Bulduğun sıralamaya bak, soldan ikinciyi say."],
                puan=10,
            ),
        ],
        kapanis="Teslim sırası dosyaya işlendi. Nöbetçiye de bir uyarı yazıldı.",
        odul={"itibar": 7},
    )


# ==========================================================================
# KOŞULLU ÖNERME
# ==========================================================================

@bulmaca(ders="mantik", konu="kosullu_onerme", kademeler=(8, 13))
def kosullu_onerme(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    "P ise Q" önermesinden ne çıkar, ne çıkmaz.

    Yaygın tuzak: Q doğruysa P de doğrudur sanmak (ters yanlışı).
    """
    durumlar = [
        {
            "p": "telsizde arıza var",
            "q": "gece bildirimi gelmez",
            "onerme": "Telsizde arıza varsa gece bildirimi gelmez.",
            "gozlem": "Gece bildirimi gelmedi.",
            "dogru": "Kesin bir şey söylenemez.",
            "yanlislar": {
                "Telsizde kesinlikle arıza vardır.":
                    "Sonuçtan sebebe gittin. Talimat yalnızca arıza VARSA "
                    "bildirimin kesileceğini söylüyor; bildirimin kesilmesinin "
                    "tek yolu olduğunu söylemiyor.",
                "Telsizde kesinlikle arıza yoktur.":
                    "Kuralı hem ters çevirdin hem de olumsuzladın. Bildirimin "
                    "gelmemesi arızayı ne kanıtlar ne de çürütür.",
                "Bildirim gelmediği için telsiz sağlamdır.":
                    "\"Sağlam\" diyerek elindekinden fazla kesinlik ekledin. "
                    "Kural sonuçtan sebebe doğru çalışmaz; bu yönde konuşmak "
                    "için başka bir kanıt gerekir.",
                "Önerme yanlıştır.":
                    "Bildirim önermeyle çelişmiyor. Talimatı çürütmek için "
                    "arızanın olduğu HÂLDE bildirimin geldiği bir gece "
                    "göstermen gerekirdi.",
            },
            "kural": "Sonucun gerçekleşmesi, sebebi kanıtlamaz",
        },
        {
            "p": "telsizde arıza var",
            "q": "gece bildirimi gelmez",
            "onerme": "Telsizde arıza varsa gece bildirimi gelmez.",
            "gozlem": "Gece bildirimi geldi.",
            "dogru": "Telsizde arıza yoktur.",
            "yanlislar": {
                "Telsizde arıza vardır.":
                    "Kuralın yönünü ters okudun. Talimat arızanın bildirimi "
                    "kestiğini söylüyor; bildirimin arızayı getirdiğini "
                    "değil.",
                "Kesin bir şey söylenemez.":
                    "Bu cevap, sonucun DOĞRULANDIĞI durumlar içindir. Burada "
                    "sonuç doğrulanmadı, yalanlandı; kural bu yönde kesin "
                    "konuşur.",
                "Önerme yanlıştır.":
                    "Talimatı çürütmek için arızanın olduğu hâlde bildirimin "
                    "geldiğini göstermen gerekir. Elimizde arıza hakkında "
                    "doğrudan bir gözlem yok.",
                "Bildirim gelmesi önermeyle ilgisizdir.":
                    "Bildirim, talimatın tam da sonuç tarafı. İlgisiz olsaydı "
                    "kural o cümleyi hiç kurmazdı.",
            },
            "kural": "Sonuç gerçekleşmediyse sebep de yoktur",
        },
        {
            "p": "yol kapalı",
            "q": "konvoy gecikir",
            "onerme": "Yol kapalıysa konvoy gecikir.",
            "gozlem": "Yol kapalı.",
            "dogru": "Konvoy gecikir.",
            "yanlislar": {
                "Konvoy gecikmez.":
                    "Kuralı olumsuzladın. Talimat, sebep gerçekleştiğinde "
                    "sonucun ne olacağını doğrudan söylüyor; bu yönü tersine "
                    "çevirme yetkin yok.",
                "Kesin bir şey söylenemez.":
                    "Belirsizlik, kuralın işlemediği yönler içindir. Burada "
                    "bildirim doğrudan sebebi doğruluyor ve kural tam olarak "
                    "bu durumdan söz ediyor.",
                "Konvoy hiç gelmez.":
                    "Kuraldan fazlasını okudun. Talimat gecikmeden söz "
                    "ediyor, seferin iptalinden değil.",
                "Önerme yanlıştır.":
                    "Talimatı çürütmek için yolun kapalı olduğu hâlde "
                    "konvoyun zamanında geldiği bir örnek gerekir; böyle bir "
                    "gözlem elimizde yok.",
            },
            "kural": "Sebep gerçekleştiyse sonuç da gerçekleşir",
        },
        {
            "p": "yol kapalı",
            "q": "konvoy gecikir",
            "onerme": "Yol kapalıysa konvoy gecikir.",
            "gozlem": "Yol kapalı değil.",
            "dogru": "Kesin bir şey söylenemez.",
            "yanlislar": {
                "Konvoy kesinlikle gecikmez.":
                    "Sebebin yokluğundan sonucun yokluğunu çıkardın. Talimat "
                    "kapalı yolun geciktirdiğini söylüyor, gecikmenin tek "
                    "sebebi olduğunu değil.",
                "Konvoy kesinlikle gecikir.":
                    "Kuralı hem ters çevirdin hem de sebep ortada yokken "
                    "çalıştırdın. Yol açıkken talimat hiçbir şey vaat etmez.",
                "Önerme yanlıştır.":
                    "Yolun açık olması talimatla çelişmez. Talimat yalnızca "
                    "yol KAPALIYKEN ne olacağını söylüyor; açık gün hakkında "
                    "hiç konuşmuyor.",
                "Konvoy zamanında gelir.":
                    "Sebep ortadan kalkınca sonucun da kalkacağını varsaydın. "
                    "Arıza, hava, yakıt: gecikmenin yolla ilgisi olmayan "
                    "sebepleri de var.",
            },
            "kural": "Sebep yoksa sonuç için bir şey söylenemez",
        },
    ]
    durum = rastgele.choice(durumlar)

    # Kural şıkkı yanlış seçildiğinde: hangi kural, bildirimin hangi ucundan
    # söz edildiğinde işler? Teşhis, öğrencinin kuralı yanlış uca bağladığını
    # söyler; doğru maddeyi söylemez.
    kural_teshisleri = {
        "Sonucun gerçekleşmesi, sebebi kanıtlamaz":
            "Bu madde ancak SONUCUN gerçekleştiği bildirilmişse işler. "
            "Buradaki bildirimin kuralın hangi ucundan söz ettiğini bir daha "
            "oku: sebepten mi, sonuçtan mı?",
        "Sonuç gerçekleşmediyse sebep de yoktur":
            "Bu madde sonucun gerçekleşMEdiği bildirilmişse işler. Bildirimi "
            "bu kalıba zorlarsan kuralı, kendisinin konuşmadığı bir yönde "
            "kullanmış olursun.",
        "Sebep gerçekleştiyse sonuç da gerçekleşir":
            "Bu madde sebebin gerçekleştiği bildirilmişse işler. Bildirim "
            "sebebin varlığını söylemiyorsa bu maddeyi çalıştıramazsın.",
        "Sebep yoksa sonuç için bir şey söylenemez":
            "Bu madde sebebin gerçekleşMEdiği bildirilmişse işler. Bildirimin "
            "kuralın hangi tarafını, hangi yönde karşıladığına dikkat et.",
    }

    return Bulmaca(
        kod="man-kosullu-onerme",
        ders="mantik",
        baslik="Telsiz Kuralı",
        kademe=kademe,
        konu="kosullu_onerme",
        kazanim="Koşullu önermeden geçerli çıkarım yapma; ters ve karşıt yanlışlarını ayırt etme.",
        dikkat=5,
        brifing=(
            "Üssün işletme talimatında tek bir cümle var:\n\n"
            "  \"{}\"\n\n"
            "Bu sabah nöbetçi şunu bildirdi: {}\n\n"
            "Komutan bu bilgiden ne çıkarabileceğimizi soruyor. Fazlasını "
            "söylemek de eksiğini söylemek kadar hatalı olur."
        ).format(durum["onerme"], durum["gozlem"]),
        kanitlar=[
            Kanit("İşletme talimatı", durum["onerme"], bedel=1, kritik=True),
            Kanit("Nöbetçi bildirimi", durum["gozlem"], bedel=1, kritik=True),
            Kanit("Mantık el kitabı",
                  "\"P ise Q\" biçimindeki bir kural için:\n"
                  "  - P doğruysa Q kesin doğrudur.\n"
                  "  - Q yanlışsa P kesin yanlıştır.\n"
                  "  - Q doğruysa P hakkında BİR ŞEY SÖYLENEMEZ.\n"
                  "  - P yanlışsa Q hakkında BİR ŞEY SÖYLENEMEZ.",
                  bedel=2, kritik=True),
            Kanit("Örnek",
                  "\"Yağmur yağarsa yer ıslanır.\" Yer ıslak diye yağmur yağdığı "
                  "söylenemez; biri suyu dökmüş olabilir.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu bildirimden çıkarım yaparken hangi kural işliyor?",
                dogru=durum["kural"],
                yanlislar={d["kural"]: kural_teshisleri[d["kural"]]
                           for d in durumlar if d["kural"] != durum["kural"]},
                rastgele=rastgele,
                aciklama=(
                    "\"P ise Q\" kuralı yalnızca iki yönde kesin sonuç verir: P varsa "
                    "Q vardır, Q yoksa P yoktur. Diğer iki yön (Q varsa P vardır, "
                    "P yoksa Q yoktur) geçersizdir; muhakeme hatalarının çoğu tam olarak "
                    "bu iki geçersiz yönü sınar."
                ),
                ipuclari=[
                    "Bildirim kuralın hangi tarafından söz ediyor: sebepten mi sonuçtan mı?",
                    "El kitabındaki dört maddeyi bildirime uygula.",
                ],
                puan=20,
                cozum=(
                    "Kural: \"{}\" ise \"{}\".\n"
                    "Bildirim: {}\n\n"
                    "El kitabındaki dört maddeden hangisine denk düştüğüne bak:\n"
                    "  - Sebep doğrulanmışsa sonuç kesindir.\n"
                    "  - Sonuç yalanlanmışsa sebep de yalanlanır.\n"
                    "  - Sonuç doğrulanmışsa sebep hakkında konuşulamaz.\n"
                    "  - Sebep yalanlanmışsa sonuç hakkında konuşulamaz.\n\n"
                    "Burada işleyen madde: {}"
                ).format(durum["p"], durum["q"], durum["gozlem"], durum["kural"]),
            ),
            secim_adimi(
                soru="Bu bildirime göre kesin olarak ne söylenebilir?",
                dogru=durum["dogru"],
                yanlislar=durum["yanlislar"],
                rastgele=rastgele,
                aciklama=(
                    "Doğru cevap: {}\n\nKuralın yalnızca iki yönü kesin sonuç verir. "
                    "Diğer yönlerde \"kesin bir şey söylenemez\" demek, bilgisizlik "
                    "değil doğru muhakemedir."
                ).format(durum["dogru"]),
                ipuclari=["Kuralı tersine çevirip çevirmediğini kontrol et."],
                puan=18,
            ),
            yorum_adimi(
                soru="\"Yer ıslaksa yağmur yağmıştır\" çıkarımı neden hatalıdır?",
                dogru="Başka sebepler de olabilir, sonuçtan sebebe gidilmez.",
                yanlislar={
                    "Hatalı değildir, doğru bir çıkarımdır.":
                        "Sonucu görüp sebebe atlamak geçerli bir adım değil. "
                        "Bu adımı atabilmen için ıslanmanın yağmurdan başka "
                        "yolu olmadığının da söylenmiş olması gerekirdi.",
                    "Yağmur yerin ıslanmasının tek sebebi olduğu için hatalıdır.":
                        "Gerekçeyi ters kurdun: yağmur tek sebep OLSAYDI "
                        "çıkarım hatalı olmazdı. Hata tam da başka sebeplerin "
                        "bulunmasından doğuyor.",
                    "Hava durumu tahmin edilemediği için hatalıdır.":
                        "Sorun tahmin etmek değil. Elimizde bir gözlem var; "
                        "tartışılan şey o gözlemden hangi çıkarımın "
                        "yapılabileceği.",
                    "Yer her zaman ıslak olduğu için hatalıdır.":
                        "Gözlemi değiştirerek kurtulmaya çalıştın. Hatanın "
                        "kaynağı gözlemin yanlışlığı değil, gözlemden sebebe "
                        "atılan adımın kendisi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir sonucu doğuran birden çok sebep olabilir. Kural yalnızca "
                    "\"yağmur yağarsa ıslanır\" diyor; ıslanmanın başka yolları "
                    "kapatılmıyor. Bu hataya mantıkta \"sonucu doğrulama yanlışı\" denir "
                    "ve günlük hayatta en sık yapılan akıl yürütme hatasıdır."
                ),
                puan=12,
            ),
        ],
        kapanis="Komutana yalnızca kesin olan yazıldı; gerisi \"belirsiz\" diye geçildi.",
        odul={"itibar": 6},
    )


# ==========================================================================
# SAYI DİZİSİ
# ==========================================================================

@bulmaca(ders="mantik", konu="sayi_orgusu", kademeler=(5, 12))
def sayi_orgusu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Diziyi üreten kuralı bulup sonraki terimi hesaplama."""
    tur = rastgele.choice(["carp_ekle", "artan_fark", "kare_ekle"])
    ilk = rastgele.randrange(2, 9)

    if tur == "carp_ekle":
        k = rastgele.choice([2, 3])
        c = rastgele.choice([1, 2, 3])
        dizi = [ilk]
        for _ in range(4):
            dizi.append(dizi[-1] * k + c)
        kural = "Her terim bir öncekinin {} katının {} fazlasıdır.".format(k, c)
        yanlis_kurallar = {
            "Her terim bir öncekinin {} katıdır.".format(k):
                "Kuralı ilk iki günde sına: {} × {} = {}, oysa kayıtta "
                "ikinci gün {} yazıyor. Tek işlem bu diziyi kapatmıyor.".format(
                    dizi[0], k, dizi[0] * k, dizi[1]),
            "Her terime sabit {} eklenmektedir.".format(c):
                "Sabit toplama, bütün ardışık farkların aynı olması demektir. "
                "Buradaki farklar ise her adımda büyüyor; ilk iki farkı yan "
                "yana yazarsan tutmadığını görürsün.",
            "Terimler arasındaki fark düzenli olarak artmaktadır.":
                "Farkların büyüdüğünü doğru gördün ama DÜZENLİ artmıyorlar: "
                "farkların kendi farkı da her adımda büyüyor. Böyle hızlanan "
                "bir büyümenin arkasında çarpma vardır.",
            "Her terim bir öncekinin karesidir.":
                "Kareyi tek bir adımda değil bütün adımlarda sına. Son "
                "günlere gelindiğinde kare alma sayıyı kayıttakinin çok "
                "ötesine taşıyor.",
        }
        sonraki = dizi[-1] * k + c
        yaygin_sonraki = {
            dizi[-1] * k:
                "Çarpmayı yaptın, sabit eklemeyi unuttun. Kuraldaki iki işlem "
                "her gün birlikte uygulanıyor; son gün de ayrıcalıklı değil.",
            dizi[-1] + c:
                "Yalnızca sabiti ekledin, çarpanı atladın. Bu kuralla dizi bu "
                "kadar hızlı büyüyemezdi.",
            2 * dizi[-1] - dizi[-2]:
                "Son farkı olduğu gibi bir kez daha ekledin, yani farkı sabit "
                "saydın. Bu kayıtta farklar her adımda büyüyor.",
        }
        cozum_metni = (
            "Ardışık terimlere bak: {} -> {}. Fark {} ama sabit değil.\n"
            "Bölmeyi dene: {} / {} yaklaşık {}. Demek ki çarpım var.\n"
            "{} x {} = {}, aradaki {} fark sabit ekleme.\n"
            "Kural: terim = önceki x {} + {}\n"
            "Sonraki terim: {} x {} + {} = {}"
        ).format(dizi[0], dizi[1], dizi[1] - dizi[0], dizi[1], dizi[0],
                 sy(round(dizi[1] / dizi[0], 2)), dizi[0], k, dizi[0] * k, c,
                 k, c, dizi[-1], k, c, sonraki)

    elif tur == "artan_fark":
        baslangic_fark = rastgele.choice([2, 3, 4])
        artis = rastgele.choice([1, 2, 3])
        dizi = [ilk]
        fark = baslangic_fark
        for _ in range(4):
            dizi.append(dizi[-1] + fark)
            fark += artis
        kural = ("Terimler arasındaki fark her adımda {} artar "
                 "(ilk fark {}).".format(artis, baslangic_fark))
        yanlis_kurallar = {
            "Dizide kural yok; sayaç sayıları rastgele yazıyor.":
                "Kural olmadığına erken karar verdin. Teknisyen notu sayacın "
                "beş gündür aynı kurala uyduğunu söylüyor; ardışık farkları "
                "yazınca düzen görünür.",
            "Her terim bir öncekinin {} katıdır, dizi bu yüzden hızla büyür.".format(artis + 1):
                "Çarpma kuralını bütün günlerde sına; bir yerde tutsa bile "
                "öteki günlerde kayıttaki sayıyı vermiyor.",
            "Her terime sabit {} eklenmektedir.".format(baslangic_fark):
                "Farkı sabit saydın. Ardışık farkları yan yana yazınca her "
                "adımda büyüdüklerini görürsün.",
            "Terimler asal sayılardır.":
                "Asallık bir sonraki sayıyı üreten bir işlem değil; kural, "
                "bir günün sayısından ötekini hesaplatmalı.",
        }
        sonraki = dizi[-1] + fark
        farklar = [dizi[i + 1] - dizi[i] for i in range(len(dizi) - 1)]
        cozum_metni = (
            "Ardışık farkları yaz: {}\n"
            "Farklar sabit değil ama kendi aralarında düzenli artıyor: her "
            "adımda {} artmış.\n"
            "Son fark {} idi; sıradaki fark {} olur.\n"
            "Sonraki terim: {} + {} = {}"
        ).format(" , ".join(str(f) for f in farklar), artis,
                 farklar[-1], farklar[-1] + artis, dizi[-1],
                 farklar[-1] + artis, sonraki)

    else:  # kare_ekle
        dizi = [ilk]
        for n in range(1, 5):
            dizi.append(dizi[-1] + n * n)
        kural = "Sırayla tam kareler (1, 4, 9, 16) eklenmektedir."
        yanlis_kurallar = {
            "Terimler arasındaki fark her adımda aynı miktar artar.":
                "Farkları yaz: 1, 4, 9, 16. Aralarındaki artış 3, 5, 7; "
                "aynı miktar değil. Farkların kendisi tam kare.",
            "Her terim bir öncekinin karesidir.":
                "Kareyi terimin kendisine uyguladın; ilk sayının karesi "
                "kayıttaki ikinci sayıyı vermiyor. Kare, farklarda gizli.",
            "Her terime sabit 5 eklenmektedir.":
                "Sabit toplama, bütün farkların aynı olması demek; buradaki "
                "farklar 1, 4, 9, 16.",
            "Her terim bir öncekinin iki katının 1 eksiğidir.":
                "Kuralı bütün günlerde sına; iki katının 1 eksiği kayıttaki "
                "sayıları sırayla vermiyor.",
        }
        sonraki = dizi[-1] + 25
        farklar = [dizi[i + 1] - dizi[i] for i in range(len(dizi) - 1)]
        cozum_metni = (
            "Ardışık farkları yaz: {}\n"
            "Bu sayılar tam kare: 1, 4, 9, 16 yani 1², 2², 3², 4².\n"
            "Sıradaki fark 5² = 25 olmalı.\n"
            "Sonraki terim: {} + 25 = {}"
        ).format(" , ".join(str(f) for f in farklar), dizi[-1], sonraki)

    dizi_metni = ", ".join(str(d) for d in dizi)

    return Bulmaca(
        kod="man-sayi-orgusu",
        ders="mantik",
        baslik="Şifreli Sayaç",
        kademe=kademe,
        konu="sayi_orgusu",
        kazanim="Sayı örüntüsündeki kuralı bulma ve sonraki terimi hesaplama.",
        dikkat=5,
        brifing=(
            "Depo sayacı bozulmuş; her gün doğru sayıyı değil, kendi kurduğu "
            "bir kurala göre üretilmiş bir sayı yazıyor.\n\n"
            "Beş günlük kayıt elimizde:\n\n"
            "  {}\n\n"
            "Teknisyen sayacı söküp bakmak yerine \"kuralı bulun, ben yarınki "
            "sayıyı ona göre düzeltirim\" diyor. Yarın sayacın ne yazacağını "
            "bilmemiz gerekiyor."
        ).format(dizi_metni),
        kanitlar=[
            Kanit("Sayaç kaydı", dizi_metni, bedel=1, kritik=True),
            Kanit("Teknisyen notu",
                  "\"Sayaç her gün bir önceki günün sayısına bakarak yeni sayıyı "
                  "üretiyor. Kural beş gündür değişmedi.\"", bedel=2, kritik=True),
            Kanit("Muhakeme notu",
                  "\"Örüntü ararken önce ARDIŞIK FARKLARA bak. Farklar sabitse "
                  "toplama, farklar da düzenli değişiyorsa iki katmanlı bir kural, "
                  "hiçbiri değilse çarpma vardır.\"", bedel=2, kritik=True),
            Kanit("Eski kayıtlar",
                  "Sayaç geçen ay da benzer şekilde bozulmuş; o zaman kural "
                  "farklıydı ama yöntem aynı işlemişti.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu diziyi üreten kural hangisidir?",
                dogru=kural,
                yanlislar=yanlis_kurallar,
                rastgele=rastgele,
                aciklama=(
                    "Örüntü bulmanın yöntemi denemeden önce ölçmektir: önce ardışık "
                    "farkları yaz. Farklar sabitse kural toplamadır. Farklar kendi "
                    "aralarında düzenliyse iki katmanlı bir kural vardır. Farklar "
                    "hızla büyüyorsa çarpma aramak gerekir. Doğru kural: " + kural
                ),
                ipuclari=[
                    "Ardışık terimlerin farkını yaz. Sabit mi, artıyor mu?",
                    "Fark hızla büyüyorsa bölme yapıp çarpan ara.",
                ],
                puan=20,
                cozum=cozum_metni,
            ),
            sayi_adimi(
                soru="Sayaç yarın hangi sayıyı yazar?",
                cevap=sonraki,
                aciklama="Kural uygulandığında sonraki terim {} olur.".format(sonraki),
                ipuclari=["Bulduğun kuralı son terime uygula."],
                puan=16,
                cozum=cozum_metni,
            ),
            yorum_adimi(
                soru="Örüntü sorularında neden önce ardışık farklara bakılır?",
                dogru="Sabit fark toplamayı, düzenli değişen fark iki katmanlı kuralı gösterir.",
                yanlislar={
                    "Fark almak her zaman doğru cevabı doğrudan verir, başka bir sınamaya gerek kalmaz.":
                        "Farkı garanti saydın. Fark bir SINAMA aracıdır: "
                        "sabit çıkarsa kural bulunmuş olur, çıkmazsa başka "
                        "bir kural aranır.",
                    "Çünkü bütün diziler toplama ile üretilir.":
                        "Bütün dizileri tek kurala bağladın. Çarpma ya da "
                        "kare alarak ilerleyen diziler de vardır.",
                    "Çünkü çarpma işlemi dizilerde kullanılmaz.":
                        "Çarpmayı devre dışı bıraktın. Geometrik dizilerin "
                        "tamamı çarpmayla ilerler.",
                    "Alışkanlıktan; başka bir sebebi yoktur.":
                        "Yöntemi gelenek saydın. Farkla başlamanın sebebi "
                        "var: en yaygın dizi türünü tek adımda eler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Fark almak, diziyi bir kat 'soyar'. Bir kez soyunca sabit çıkıyorsa "
                    "kural birinci dereceden, iki kez soyunca sabit çıkıyorsa ikinci "
                    "derecedendir. Bu yüzden rastgele kural denemek yerine önce fark "
                    "almak, aramayı kısaltan sistemli bir yöntemdir."
                ),
                puan=12,
            ),
        ],
        kapanis="Sayacın kuralı çözüldü; teknisyen düzeltmeyi yarınki sayıya göre yapacak.",
        odul={"itibar": 6, "enerji": 3},
    )


# ==========================================================================
# TARTMA
# ==========================================================================

@bulmaca(ders="mantik", konu="tartma", kademeler=(6, 13))
def tartma_bulmacasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Eşit kollu terazi; en az kaç tartımda sahte kasa bulunur?"""
    kasa_sayisi = rastgele.choice([9, 27])
    tartim = 2 if kasa_sayisi == 9 else 3
    fazla_tartim = kasa_sayisi // 2  # ikili arama sanısı

    return Bulmaca(
        kod="man-tartma",
        ders="mantik",
        baslik="Ağır Kasa",
        kademe=kademe,
        konu="tartma",
        kazanim="Bilgi kazanımını en büyükleyerek arama; üçe bölme stratejisi.",
        dikkat=6,
        brifing=(
            "Depoya {} kasa geldi. Hepsi aynı görünüyor ama biri diğerlerinden "
            "biraz ağır: içine fazladan malzeme konmuş.\n\n"
            "Elimizde eşit kollu bir terazi var - dijital tartı değil. Terazi "
            "yalnızca üç şey söyleyebiliyor: sol ağır, sağ ağır, ya da eşit.\n\n"
            "Kasaları açmadan, en az kaç tartımda ağır olanı bulabileceğimizi "
            "bilmemiz gerekiyor. Depocu \"teker teker tartarız\" diyor."
        ).format(kasa_sayisi),
        kanitlar=[
            Kanit("Terazi künyesi",
                  "Eşit kollu terazi. Her tartımda üç sonuçtan biri çıkar: "
                  "sol ağır / sağ ağır / eşit.", bedel=2, kritik=True),
            Kanit("Kasa sayımı",
                  "Toplam {} kasa. Yalnızca biri ağır, diğerlerinin hepsi "
                  "birbirine eşit.".format(kasa_sayisi), bedel=1, kritik=True),
            Kanit("Muhakeme notu",
                  "\"Her tartım üç farklı sonuç verebiliyorsa, bir tartım "
                  "olasılıkları üçe böler. İki tartım dokuza, üç tartım yirmi "
                  "yediye kadar ayırt eder.\"", bedel=2, kritik=True),
            Kanit("Depocunun önerisi",
                  "\"Kasaları ikişer ikişer karşılaştıralım, eninde sonunda "
                  "buluruz.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir tartımdan en çok bilgi nasıl alınır?",
                dogru="Kasalar ÜÇ eşit gruba ayrılıp ikisi tartılarak; olasılıklar üçte bire iner.",
                yanlislar={
                    "Kasalar ikiye ayrılıp iki kefeye konarak; her tartım olasılıkları yarıya indirir.":
                        "İkiye böldün. Terazi ÜÇ sonuç verir (sol ağır, sağ "
                        "ağır, eşit); bu yüzden üçe bölmek her tartımda daha "
                        "çok olasılık eler.",
                    "Kasalar teker teker tartılarak.":
                        "Tek tek tarttın. Bu en çok tartım gerektiren yol; "
                        "terazinin karşılaştırma gücünü hiç kullanmıyorsun.",
                    "Her tartımda tek bir kasa dışarıda bırakılarak, kalanlar kefelere bölünür.":
                        "Yalnızca bir kasayı dışarıda bıraktın. Dışarıda kalan "
                        "grup da bilgi verir; onu büyük tutmak gerekir.",
                    "Kasalar rastgele eşleştirilerek.":
                        "Rastgele böldün. Tartım sayısını en aza indiren şey "
                        "grupların EŞİT büyüklükte olması.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Eşit kollu terazinin üç sonucu vardır; dijital tartıdan farkı "
                    "budur. Kasaları ikiye bölerseniz 'eşit' sonucunu boşa harcamış "
                    "olursunuz. Üçe bölüp iki grubu tartarsanız: sol ağırsa hedef "
                    "solda, sağ ağırsa sağda, eşitse tartılmayan üçüncü gruptadır. "
                    "Yani tek tartımda olasılıkların üçte ikisi elenir."
                ),
                ipuclari=[
                    "Terazi kaç farklı sonuç verebiliyor? İki mi üç mü?",
                    "\"Eşit\" sonucu da bir bilgidir. Onu kullanabiliyor musun?",
                ],
                puan=20,
                cozum=(
                    "Terazi üç sonuç verir, o hâlde her tartım olasılık sayısını "
                    "en fazla ÜÇE böler.\n"
                    "{} kasa için: {} kasayı üçe böl, her grupta {} kasa olsun.\n"
                    "Grup A ile grup B'yi tart:\n"
                    "  - Sol ağırsa hedef A'da,\n"
                    "  - Sağ ağırsa B'de,\n"
                    "  - Eşitse hiç tartmadığın C'de.\n"
                    "Tek tartımla {} kasadan {} kasaya indin.\n"
                    "Aynı işlemi tekrarlayarak {} tartımda tek kasaya inilir."
                ).format(kasa_sayisi, kasa_sayisi, kasa_sayisi // 3,
                         kasa_sayisi, kasa_sayisi // 3, tartim),
            ),
            sayi_adimi(
                soru="En kötü durumda en az kaç tartım yeter?",
                cevap=tartim,
                birim="tartım",
                aciklama=(
                    "Her tartım olasılıkları üçte bire indirdiği için {} kasa {} "
                    "tartımda ayırt edilir (3^{} = {})."
                ).format(kasa_sayisi, tartim, tartim, 3 ** tartim),
                ipuclari=[
                    "Her tartım olasılıkları kaça böler?",
                    "3'ün kaçıncı kuvveti kasa sayısına ulaşır?",
                ],
                puan=16,
                cozum=(
                    "Her tartım olasılık sayısını üçe böler.\n"
                    "{} kasa -> {} -> {} -> 1\n"
                    "Yani {} tartım. Genel kural: 3 üzeri (tartım sayısı), ayırt "
                    "edilebilecek en çok kasa sayısıdır."
                ).format(kasa_sayisi, kasa_sayisi // 3,
                         max(1, kasa_sayisi // 9), tartim),
            ),
            yorum_adimi(
                soru="Depocunun \"ikişer ikişer karşılaştıralım\" önerisi neden kötü?",
                dogru="Eşit gelen her tartım yalnız iki kasayı eler; tartım sayısı çok artar.",
                yanlislar={
                    "Yanlış sonuç verir, çünkü iki kasa eşit gelirse ağır kasa bulunamaz.":
                        "Yöntemi yanlış saydın. İkişer karşılaştırma sonunda "
                        "ağır kasayı bulur; sorun doğruluğu değil, kaç tartım "
                        "gerektirdiği.",
                    "Kötü değildir; her karşılaştırma sonuçta aynı sayıda tartım gerektirir.":
                        "İki yöntemi eşit saydın. Üçe bölme her tartımda "
                        "olasılıkların üçte ikisini eler; ikişer karşılaştırma "
                        "çok daha yavaş ilerler.",
                    "Teraziyi bozabileceği için kötüdür.":
                        "Sorunu araca bağladın. Terazi her iki yöntemde de "
                        "aynı biçimde kullanılıyor.",
                    "Kasaların açılmasını gerektirdiği için kötüdür.":
                        "Açma gerekmiyor; iki yöntem de kasaları kapalı "
                        "tartıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Depocunun yöntemi de sonunda doğru kasayı bulur; sorun "
                    "verimsizliktir. Elindeki aracın verebileceği bilgiyi tam "
                    "kullanmamak, her adımda kazandığın bilgiyi yarıya düşürür. "
                    "Muhakeme sorularının çoğu \"doğru mu\" değil \"en az kaç adımda\" "
                    "diye sorar; oradaki kazanç bu ayrımda saklıdır."
                ),
                puan=12,
            ),
        ],
        kapanis="Ağır kasa {} tartımda bulundu; depocu teraziye bir daha başka gözle baktı.".format(
            tartim),
        odul={"cevher": 5, "itibar": 6},
    )


# ==========================================================================
# TAKVİM
# ==========================================================================

@bulmaca(ders="mantik", konu="takvim", kademeler=(5, 11))
def takvim_muhakemesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Gün sayısından haftanın gününü bulma: mod 7 muhakemesi."""
    gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma",
              "Cumartesi", "Pazar"]
    baslangic_indeks = rastgele.randrange(7)
    gun_sayisi = rastgele.choice([30, 45, 60, 100, 120, 200])
    kalan = gun_sayisi % 7
    hedef_indeks = (baslangic_indeks + kalan) % 7

    return Bulmaca(
        kod="man-takvim",
        ders="mantik",
        baslik="Sefer Günü",
        kademe=kademe,
        konu="takvim",
        kazanim="Bölme kalanıyla döngüsel muhakeme; haftanın gününü hesaplama.",
        dikkat=5,
        brifing=(
            "Büyük sefer bugünden tam {} gün sonra başlayacak. Bugün {}.\n\n"
            "Sefer hazırlığı haftanın gününe göre planlanıyor: pazar günü "
            "depolar kapalı, cumartesi ise ulaşım yarım gün.\n\n"
            "Takvim yok; kimse {} günü tek tek saymak istemiyor. Seferin "
            "hangi güne denk geldiğini hesaplamamız gerekiyor."
        ).format(gun_sayisi, gunler[baslangic_indeks], gun_sayisi),
        kanitlar=[
            Kanit("Sefer emri",
                  "Sefer başlangıcı: bugünden {} gün sonra.".format(gun_sayisi),
                  bedel=1, kritik=True),
            Kanit("Bugünün kaydı", "Bugün {}.".format(gunler[baslangic_indeks]),
                  bedel=1, kritik=True),
            Kanit("Muhakeme notu",
                  "\"Haftanın günleri 7'lik bir döngüdür. 7 gün sonra aynı gündür, "
                  "14 gün sonra da. Bu yüzden yalnızca 7'ye bölümünden KALAN "
                  "önemlidir.\"", bedel=2, kritik=True),
            Kanit("Depo çizelgesi",
                  "Pazar: kapalı. Cumartesi: yarım gün. Diğer günler tam gün.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="{} gün sonrasının hangi gün olduğunu ne belirler?".format(gun_sayisi),
                dogru="Gün sayısının 7'ye bölümünden kalan.",
                yanlislar={
                    "Gün sayısının 7'ye bölümünün tam kısmı.":
                        "Bölümü aldın, kalanı değil. Tam kısım kaç tam hafta "
                        "geçtiğini söyler; tam haftalar günü değiştirmez. "
                        "Günü kaydıran şey KALAN.",
                    "Gün sayısının kendisi.":
                        "Haftanın tekrarını hesaba katmadın. Günler yedide bir "
                        "başa döner; bütün sayıyı ileri saymak gerekmez.",
                    "Gün sayısının 30'a bölümünden kalan.":
                        "Ayı ölçüt aldın. Gün adları aya göre değil, YEDİ "
                        "günlük haftaya göre döner.",
                    "Gün sayısının 2'ye bölümünden kalan.":
                        "İkiye böldün. İki günlük bir döngü yok; hafta yedi "
                        "günlüktür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Hafta 7 günlük kapalı bir döngüdür: 7, 14, 21 gün sonra hep aynı "
                    "gündeyiz. Bu yüzden tam haftalar hiçbir şey değiştirmez; günü "
                    "değiştiren tek şey artan kısımdır. Bölümün tam kısmı kaç hafta "
                    "geçtiğini söyler ve bu bilgi gün adını bulmakta işe yaramaz."
                ),
                ipuclari=[
                    "7 gün sonra hangi gündür? Ya 14 gün sonra?",
                    "Tam haftalar günü değiştiriyor mu?",
                ],
                puan=18,
                cozum=(
                    "Hafta 7 günlük döngü olduğu için tam haftalar günü değiştirmez.\n"
                    "{} = 7 x {} + {}\n"
                    "Yani {} tam hafta ve {} gün artıyor.\n"
                    "Bugün {} olduğuna göre {} gün ileri say: {}"
                ).format(gun_sayisi, gun_sayisi // 7, kalan, gun_sayisi // 7,
                         kalan, gunler[baslangic_indeks], kalan, gunler[hedef_indeks]),
            ),
            sayi_adimi(
                soru="{} sayısının 7'ye bölümünden kalan kaçtır?".format(gun_sayisi),
                cevap=kalan,
                aciklama="{} = 7 x {} + {}. Kalan {}.".format(
                    gun_sayisi, gun_sayisi // 7, kalan, kalan),
                ipuclari=["Gün sayısını 7'ye böl, kalanı al."],
                puan=10,
            ),
            secim_adimi(
                soru="Sefer hangi gün başlayacak?",
                dogru=gunler[hedef_indeks],
                # Şık üst sınırı beş; dördünden fazla yanlış gün yazarsak
                # teşhisi olan ama ekranda hiç görünmeyen şıklar kalır.
                yanlislar={
                    g: "Bugünden kalan kadar ileri sayınca bu güne "
                       "varılmıyor. Saymayı bugünden başlat ve kalanı bir "
                       "kez uygula."
                    for g in [x for x in gunler
                              if x != gunler[hedef_indeks]][:4]
                },
                rastgele=rastgele,
                aciklama=(
                    "Bugün {}; kalan {} olduğuna göre {} gün ileri sayılır ve {} "
                    "günü bulunur."
                ).format(gunler[baslangic_indeks], kalan, kalan, gunler[hedef_indeks]),
                ipuclari=["Bugünden başlayarak kalan kadar gün ileri say."],
                puan=14,
                cozum=(
                    "Kalan {} olduğu için bugünden {} gün ileri sayıyoruz:\n"
                    "{} -> {}\n"
                    "Sefer günü: {}"
                ).format(kalan, kalan, gunler[baslangic_indeks],
                         " -> ".join(gunler[(baslangic_indeks + i) % 7]
                                     for i in range(1, kalan + 1)) or "(aynı gün)",
                         gunler[hedef_indeks]),
            ),
        ],
        kapanis="Sefer günü {} olarak çizelgeye işlendi.".format(gunler[hedef_indeks]),
        odul={"itibar": 5, "erzak": 2},
    )
