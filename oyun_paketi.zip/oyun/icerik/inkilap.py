# -*- coding: utf-8 -*-
"""
Yakın tarih ve değişim görevleri.

Kronograf bu dersi doğal olarak taşıyor: aygıt bir belge parçası getiriyor,
üzerinde tarih ya da başlık yok, yalnızca kararlar yazılı. Öğrenci hangi
kongreye ya da hangi aşamaya ait olduğunu kararların içeriğinden çıkarıyor.

Bu, dersin ezber kısmını değil ayırt etme kısmını çalıştırır: Erzurum ile
Sivas kararlarını birbirinden ayıran şey tarih değil, kapsamdır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import model_adimi, secim_adimi, sirala_adimi, yorum_adimi


# ==========================================================================
# BELGEDEN AŞAMA TESPİTİ
# ==========================================================================

_BELGELER = [
    {
        "ad": "Amasya Genelgesi (Haziran 1919)",
        "kararlar": (
            "- Vatanın bütünlüğü ve milletin bağımsızlığı tehlikededir.\n"
            "- İstanbul Hükûmeti üzerine aldığı sorumluluğu yerine "
            "getirememektedir.\n"
            "- Milletin bağımsızlığını yine milletin azim ve kararı "
            "kurtaracaktır.\n"
            "- Sivas'ta millî bir kongre toplanacaktır."
        ),
        "ayirt_edici": ("Kurtuluşun yöntemini ilk kez ortaya koyan ve bir kongre "
                        "toplanmasını duyuran genelgedir; henüz kararlar alınmamış, "
                        "çağrı yapılmıştır."),
    },
    {
        "ad": "Erzurum Kongresi (Temmuz-Ağustos 1919)",
        "kararlar": (
            "- Millî sınırlar içinde vatan bir bütündür, bölünemez.\n"
            "- Kuvâ-yi Millîye'yi etkin, millî iradeyi hâkim kılmak esastır.\n"
            "- Manda ve himaye kabul edilemez.\n"
            "- Doğu illerinin haklarını korumak için çalışılacaktır."
        ),
        "ayirt_edici": ("Toplanışı bakımından BÖLGESEL, aldığı kararlar bakımından "
                        "millîdir. \"Doğu illeri\" ifadesi bölgesel niteliğini ele verir."),
    },
    {
        "ad": "Sivas Kongresi (Eylül 1919)",
        "kararlar": (
            "- Erzurum Kongresi kararları biraz genişletilerek kabul edilmiştir.\n"
            "- Bütün millî cemiyetler \"Anadolu ve Rumeli Müdafaa-i Hukuk "
            "Cemiyeti\" adı altında birleştirilmiştir.\n"
            "- Manda ve himaye kesin olarak reddedilmiştir.\n"
            "- Temsil Heyeti bütün vatanı temsil eder."
        ),
        "ayirt_edici": ("Hem toplanışı hem kararları bakımından MİLLÎDİR. "
                        "Cemiyetlerin tek çatı altında birleştirilmesi yalnızca "
                        "bu kongrede olmuştur."),
    },
]


@bulmaca(ders="inkilap", konu="milli_mucadele", kademeler=(6, 10), agirlik=1.5)
def belge_tespiti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Başlıksız bir karar metninden hangi aşamaya ait olduğunu çıkarma."""
    belge = rastgele.choice(_BELGELER)
    digerleri = [b for b in _BELGELER if b["ad"] != belge["ad"]]

    return Bulmaca(
        kod="ink-belge-tespiti",
        ders="inkilap",
        baslik="Başlıksız Karar",
        kademe=kademe,
        konu="milli_mucadele",
        kazanim="Millî Mücadele belgelerini içeriklerinden ayırt etme.",
        dikkat=6,
        brifing=(
            "Kronograf bir belge parçası getirdi. Üst kısmı yanmış: başlık da "
            "tarih de okunmuyor. Yalnızca kararlar sağlam kalmış:\n\n"
            "{}\n\n"
            "Arşive hangi belge olduğunu yazmamız gerekiyor. Tarih yok, imza "
            "yok; elimizde sadece kararların kendisi var."
        ).format(belge["kararlar"]),
        kanitlar=[
            Kanit("Belge metni", belge["kararlar"], bedel=1, kritik=True),
            Kanit("Karşılaştırma çizelgesi",
                  "AMASYA GENELGESİ: Kurtuluşun yöntemini duyurur, Sivas'ta "
                  "kongre toplanmasını ÇAĞIRIR. Karar organı değil, çağrıdır.\n\n"
                  "ERZURUM KONGRESİ: Toplanışı BÖLGESEL (doğu illeri), kararları "
                  "millîdir. Manda ve himaye reddedilir.\n\n"
                  "SİVAS KONGRESİ: Toplanışı da kararları da MİLLÎDİR. Bütün millî "
                  "cemiyetler tek çatı altında birleştirilir.",
                  bedel=2, kritik=True),
            Kanit("Arşivci notu",
                  "\"Bu üç belgeyi tarihle değil KAPSAMLA ayır. Metinde 'doğu "
                  "illeri' geçiyorsa bölgesel, 'bütün cemiyetler birleştirildi' "
                  "geçiyorsa millî, 'kongre toplanacaktır' geçiyorsa henüz "
                  "çağrı aşamasındadır.\"", bedel=2, kritik=True),
            Kanit("Belgenin kâğıdı",
                  "Kâğıt ve mürekkep aynı dönemin; hepsi 1919 yılına ait "
                  "olabilir. Kâğıttan ayrım yapmak mümkün değil.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu belgeyi tanımak için neye bakmak gerekir?",
                dogru="Kararların kapsamına: bölgesel mi, millî mi, yoksa henüz bir çağrı mı.",
                yanlislar={
                    "Belgenin kaç madde içerdiğine.":
                        "Madde sayısına baktın. Belgeleri ayıran şey kaç madde "
                        "oldukları değil, hangi KARARI ilk kez dile "
                        "getirdikleri.",
                    "Kullanılan kâğıdın ve mürekkebin cinsine.":
                        "Fiziksel özelliğe baktın. Bu bir belge sahteciliği "
                        "incelemesi değil; belgeyi tanıtan şey içeriği.",
                    "Cümlelerin uzunluğuna.":
                        "Üsluba baktın. Dönemin bütün belgeleri benzer dille "
                        "yazılmıştır.",
                    "Belgede geçen kişi adlarına.":
                        "Adlara baktın. Aynı kişiler birçok belgede geçer; "
                        "ayırt edici olan alınan kararın kendisi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Üç belge de 1919'a ait ve üçü de aynı amaca hizmet ediyor; bu "
                    "yüzden tarih ya da üslup ayırt etmez. Ayıran şey kapsamdır: "
                    "Amasya bir çağrıdır, Erzurum bölgesel toplanmıştır, Sivas bütün "
                    "cemiyetleri birleştirmiştir. Belgeyi tanımak, bu üç kapsamdan "
                    "hangisinin metinde göründüğünü görmektir."
                ),
                ipuclari=[
                    "Metinde bir bölge adı geçiyor mu?",
                    "Metin bir kongre topluyor mu, yoksa toplanmasını mı istiyor?",
                ],
                puan=20,
                cozum=(
                    "1) Metinde kapsam işaretlerini ara:\n"
                    "   - \"kongre toplanacaktır\" -> henüz ÇAĞRI (Amasya)\n"
                    "   - \"doğu illeri\" gibi bölge adı -> BÖLGESEL toplanış (Erzurum)\n"
                    "   - \"bütün cemiyetler birleştirilmiştir\" -> MİLLÎ (Sivas)\n"
                    "2) Bu belgede öne çıkan: {}\n\n"
                    "Sonuç: {}"
                ).format(belge["ayirt_edici"], belge["ad"]),
            ),
            secim_adimi(
                soru="Bu belge hangisidir?",
                dogru=belge["ad"],
                yanlislar=dict(
                    [(b["ad"], "{} belgesinin ayırt edici kararı bu metinde "
                               "geçmiyor. Çizelgedeki tanımı metinle "
                               "karşılaştır.".format(b["ad"])) for b in digerleri]
                    + [("Lozan Antlaşması (1923)",
                        "Lozan bir barış antlaşmasıdır ve Kurtuluş Savaşı'nın "
                        "SONUNDA imzalandı. Elindeki metin savaş öncesi "
                        "örgütlenme dönemine ait.")]
                ),
                rastgele=rastgele,
                aciklama=belge["ayirt_edici"],
                ipuclari=["Çizelgedeki üç tanımı metinle karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Erzurum Kongresi neden \"toplanışı bölgesel, kararları millî\" diye anılır?",
                dogru=("Doğu illerinin temsilcileriyle toplandığı hâlde bütün vatanı "
                       "ilgilendiren kararlar aldığı için."),
                yanlislar={
                    "Bütün illerin temsilcileriyle toplandığı için.":
                        "Toplanışı ülke geneli saydın. Erzurum'a yalnızca doğu "
                        "illerinin temsilcileri katıldı; bütün illeri toplayan "
                        "kongre Sivas'tır.",
                    "Yalnızca doğu illerini ilgilendiren kararlar aldığı için.":
                        "Kararları da bölgesel saydın. Oysa alınan kararlar "
                        "vatanın bütününü ilgilendiriyordu; ifadeyi ilginç "
                        "kılan tam da bu.",
                    "Kararları sonradan geçersiz sayıldığı için.":
                        "Kararları geçersiz saydın. Erzurum'da alınanlar Sivas "
                        "Kongresi'nde benimsendi ve sürdü.",
                    "İstanbul Hükûmeti tarafından toplandığı için.":
                        "Toplayanı yanlış belirledin. Kongre yerel "
                        "cemiyetlerin girişimiyle toplandı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kongreye katılanlar doğu illerinin temsilcileriydi; bu yönüyle "
                    "toplanış bölgeseldir. Ama alınan \"millî sınırlar içinde vatan "
                    "bir bütündür\" kararı bütün ülkeyi kapsar. Bir kongreyi "
                    "değerlendirirken kimin toplandığı ile neye karar verildiği ayrı "
                    "ayrı bakılması gereken iki şeydir."
                ),
                puan=12,
            ),
        ],
        kapanis="Belge \"{}\" olarak fişlendi ve arşive kaldırıldı.".format(belge["ad"]),
        odul={"itibar": 8},
    )


# ==========================================================================
# KRONOLOJİ
# ==========================================================================

@bulmaca(ders="inkilap", konu="kronoloji", kademeler=(6, 10))
def milli_mucadele_kronolojisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Millî Mücadele olaylarını sıraya dizme."""
    havuz = [
        ("Mondros Ateşkes Antlaşması'nın imzalanması", 1918.10),
        ("Mustafa Kemal'in Samsun'a çıkması", 1919.05),
        ("Amasya Genelgesi'nin yayımlanması", 1919.06),
        ("Erzurum Kongresi'nin toplanması", 1919.07),
        ("Sivas Kongresi'nin toplanması", 1919.09),
        ("TBMM'nin açılması", 1920.04),
        ("Sakarya Meydan Muharebesi", 1921.08),
        ("Büyük Taarruz'un başlaması", 1922.08),
        ("Lozan Antlaşması'nın imzalanması", 1923.07),
        ("Cumhuriyet'in ilan edilmesi", 1923.10),
    ]
    adet = 4 if kademe <= 7 else 5
    secilen = rastgele.sample(havuz, adet)
    karisik = list(secilen)
    rastgele.shuffle(karisik)
    secenekler = [ad for ad, _ in karisik]
    sirali = sorted(range(len(karisik)), key=lambda i: karisik[i][1])
    dogru_liste = " -> ".join(karisik[i][0] for i in sirali)

    return Bulmaca(
        kod="ink-kronoloji",
        ders="inkilap",
        baslik="Dağılan Zaman Şeridi",
        kademe=kademe,
        konu="kronoloji",
        kazanim="Millî Mücadele dönemi olaylarını kronolojik sıraya koyma.",
        dikkat=5,
        brifing=(
            "Arşivde Millî Mücadele için hazırlanmış bir zaman şeridi vardı; "
            "kartlar yere düşüp karışmış.\n\n"
            "Kartların üzerinde tarih yazmıyor, yalnızca olay adı var. Şeridin "
            "yeniden kurulması gerekiyor: sırasız bir zaman şeridi, hangi olayın "
            "hangisine yol açtığını göstermez."
        ),
        kanitlar=[
            Kanit("Dönem çizelgesi",
                  "1918: Mondros Ateşkesi, işgallerin başlaması\n"
                  "1919: Samsun'a çıkış, Amasya, Erzurum, Sivas\n"
                  "1920: TBMM'nin açılması\n"
                  "1921: Sakarya\n"
                  "1922: Büyük Taarruz\n"
                  "1923: Lozan, Cumhuriyet'in ilanı",
                  bedel=2, kritik=True),
            Kanit("Arşivci notu",
                  "\"Sıralamayı ezberden değil mantıktan da kurabilirsin: bir "
                  "meclis açılmadan antlaşma imzalanamaz, ateşkes olmadan işgal "
                  "başlamaz, savaş kazanılmadan barış görüşülmez.\"",
                  bedel=2, kritik=True),
            Kanit("Kart arkaları", "Hepsi boş; tarih yazılmamış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kartları sıraya dizerken hangi ölçüt işler?",
                dogru="Olayların birbirini gerektirme sırası ve tarihleri.",
                yanlislar={
                    "Olay adlarının uzunluğu.":
                        "Ad uzunluğunu ölçüt saydın. Bir olayın adının kaç "
                        "harf olduğunun ne zaman gerçekleştiğiyle ilgisi yok.",
                    "Olayların önem derecesi.":
                        "Önemi zamanla karıştırdın. Sıralama olayların "
                        "büyüklüğüne göre değil, TARİHİNE göre yapılır.",
                    "Olayların geçtiği şehirlerin alfabetik sırası.":
                        "Alfabeye baktın. Şehir adının sırası olayın tarihini "
                        "söylemez.",
                    "Kartların yerde bulunduğu sıra.":
                        "Bulunuş sırasını kanıt saydın. Kartlar karışmış "
                        "hâlde; sıralamayı olayların kendi tarihleri "
                        "belirler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kronoloji yalnızca tarih ezberi değildir; olaylar birbirini "
                    "gerektirir. Barış antlaşması, savaşın sonucundan sonra gelir; "
                    "kongreler, kurtuluş yönteminin duyurulmasından sonra toplanır. "
                    "Tarihi hatırlamasan bile bu bağlar sıralamayı büyük ölçüde verir."
                ),
                ipuclari=[
                    "Hangi olay diğerlerinin başlamasına sebep oldu?",
                    "Bir antlaşma, savaştan önce mi sonra mı imzalanır?",
                ],
                puan=16,
                cozum=(
                    "1) Önce kesin olarak bildiğin uçları koy: en erken ve en geç olay.\n"
                    "2) Aradakileri neden-sonuç bağıyla yerleştir: ateşkes -> işgal -> "
                    "örgütlenme -> meclis -> savaş -> barış -> yeni rejim.\n"
                    "3) Dönem çizelgesiyle denetle.\n\n"
                    "Doğru sıra: " + dogru_liste
                ),
            ),
            sirala_adimi(
                soru="Olayları en eskiden en yeniye sırala (numaraları sırayla yaz):",
                secenekler=secenekler,
                dogru_sira=sirali,
                aciklama="Doğru sıra: " + dogru_liste,
                ipuclari=[
                    "Dönem çizelgesindeki yıllara bak.",
                    "Aynı yıl içindeki olayları neden-sonuç bağıyla ayır.",
                ],
                puan=22,
            ),
            secim_adimi(
                soru="Bu sıralamadaki en erken olay hangisidir?",
                dogru=karisik[sirali[0]][0],
                yanlislar={
                    karisik[i][0]: "Bu olay kurduğun sıralamada daha sonra "
                                   "geliyor. En SOLDAKİ karta bak."
                    for i in sirali[1:]
                },
                rastgele=rastgele,
                aciklama="Sıralamanın başındaki olay: {}.".format(karisik[sirali[0]][0]),
                ipuclari=["Kurduğun sıranın en solundaki karta bak."],
                puan=10,
            ),
        ],
        kapanis="Zaman şeridi yeniden kuruldu ve duvara asıldı.",
        odul={"itibar": 7},
    )


# ==========================================================================
# NEDEN - SONUÇ
# ==========================================================================

@bulmaca(ders="inkilap", konu="neden_sonuc", kademeler=(7, 10))
def inkilap_neden_sonuc(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir gelişmenin nedeni ile sonucunu ayırma."""
    olaylar = [
        {
            "olay": "TBMM'nin açılması (1920)",
            "neden": "İstanbul'un işgal edilmesi ve Meclis-i Mebusan'ın kapatılması",
            "sonuc": "Millî iradeye dayanan yeni bir yönetim merkezinin doğması",
            "yanlis_nedenler": [
                "Lozan Antlaşması'nın imzalanması",
                "Cumhuriyet'in ilan edilmesi",
                "Büyük Taarruz'un kazanılması",
            ],
        },
        {
            "olay": "Sivas Kongresi'nin toplanması (1919)",
            "neden": "Millî cemiyetlerin dağınık çalışması ve tek çatı ihtiyacı",
            "sonuc": "Bütün millî cemiyetlerin tek bir cemiyet altında birleşmesi",
            "yanlis_nedenler": [
                "TBMM'nin açılmış olması",
                "Sakarya Savaşı'nın kazanılması",
                "Saltanatın kaldırılması",
            ],
        },
        {
            "olay": "Lozan Antlaşması'nın imzalanması (1923)",
            "neden": "Büyük Taarruz'un kazanılıp askerî üstünlüğün sağlanması",
            "sonuc": "Yeni Türk devletinin bağımsızlığının uluslararası olarak tanınması",
            "yanlis_nedenler": [
                "Cumhuriyet'in ilan edilmiş olması",
                "Mondros Ateşkesi'nin imzalanması",
                "Amasya Genelgesi'nin yayımlanması",
            ],
        },
    ]
    olay = rastgele.choice(olaylar)

    return Bulmaca(
        kod="ink-neden-sonuc",
        ders="inkilap",
        baslik="Öncesi ve Sonrası",
        kademe=kademe,
        konu="neden_sonuc",
        kazanim="Tarihsel olaylarda neden ile sonucu ayırt etme.",
        dikkat=5,
        brifing=(
            "Arşiv fişlerinde her olayın \"öncesi\" ve \"sonrası\" hanesi var. "
            "Elindeki fişte olay yazılı ama iki hane de boş:\n\n"
            "  {}\n\n"
            "Fişi tamamlaman gerekiyor. Bir hataya dikkat: sonradan olan her şey "
            "sonuç değildir; sonuç, o olayın YOL AÇTIĞI şeydir."
        ).format(olay["olay"]),
        kanitlar=[
            Kanit("Fiş", olay["olay"], bedel=1, kritik=True),
            Kanit("Arşiv yönergesi",
                  "\"NEDEN: olaydan önce var olan ve olayı hazırlayan durum.\n"
                  "SONUÇ: olaydan sonra ortaya çıkan ve olayın yol açtığı değişiklik.\n"
                  "Sonradan gerçekleşen her olay sonuç değildir; arada bir bağ "
                  "olmalıdır.\"", bedel=2, kritik=True),
            Kanit("Zaman şeridi",
                  "1918 Mondros -> 1919 kongreler -> 1920 TBMM -> 1921-22 savaşlar "
                  "-> 1923 Lozan ve Cumhuriyet", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir gelişmenin \"sonuç\" sayılması için ne gerekir?",
                dogru="Olaydan sonra gerçekleşmesi VE olayın ona yol açmış olması.",
                yanlislar={
                    "Yalnızca olaydan sonra gerçekleşmesi.":
                        "Zamanı tek koşul saydın. Sonra gerçekleşen her şey "
                        "sonuç değildir; arada bir NEDEN-SONUÇ bağı da "
                        "olmalı.",
                    "Olaydan önce gerçekleşmesi.":
                        "Yönü ters aldın. Önce gerçekleşen şey sonuç değil, "
                        "olsa olsa nedendir.",
                    "Aynı yıl içinde gerçekleşmesi.":
                        "Aynı yıla düşmeyi bağ saydın. Bir olayın sonucu "
                        "yıllar sonra ortaya çıkabilir.",
                    "Aynı kişilerin karıştığı bir olay olması.":
                        "Ortak kişiyi bağ saydın. Aynı kişiler birbiriyle "
                        "ilgisiz olaylarda da bulunabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zaman sırası tek başına yetmez. Cumhuriyet, Lozan'dan sonra "
                    "ilan edilmiştir ama Lozan'ın sonucu diye anılmaz; ikisi ayrı "
                    "gelişmelerdir. Sonuç ilan edebilmek için olayla arasında bir "
                    "yol açma bağı kurulabilmelidir - tarihte \"ardından geldi\" ile "
                    "\"yüzünden oldu\" farklı iddialardır."
                ),
                ipuclari=[
                    "Bu iki olay arasında bir sebep bağı kurabiliyor musun?",
                    "\"Sonra oldu\" ile \"bu yüzden oldu\" aynı şey mi?",
                ],
                puan=18,
                cozum=(
                    "Fişi doldururken iki soru sor:\n"
                    "  1) Bu olayı ne HAZIRLADI? -> neden hanesi\n"
                    "  2) Bu olay neye YOL AÇTI? -> sonuç hanesi\n\n"
                    "  Olay: {}\n"
                    "  Neden: {}\n"
                    "  Sonuç: {}"
                ).format(olay["olay"], olay["neden"], olay["sonuc"]),
            ),
            secim_adimi(
                soru="Bu olayın nedeni aşağıdakilerden hangisidir?",
                dogru=olay["neden"],
                yanlislar=olay["yanlis_nedenler"] + [olay["sonuc"]],
                rastgele=rastgele,
                aciklama=(
                    "Neden olaydan ÖNCE gelir ve onu hazırlar: {}. Şıklardaki diğer "
                    "gelişmeler ya olaydan sonradır ya da onunla sebep bağı yoktur."
                ).format(olay["neden"]),
                ipuclari=["Zaman şeridine bak: hangisi bu olaydan önce gerçekleşti?"],
                puan=16,
            ),
            secim_adimi(
                soru="Bu olayın sonucu aşağıdakilerden hangisidir?",
                dogru=olay["sonuc"],
                yanlislar=dict(
                    [(olay["neden"],
                      "Bu, olayın NEDENİ - yani onu başlatan şey. Sonuç ise "
                      "olayın kendisinden sonra gelen değişikliktir.")]
                    + [(y, "Bu gelişmenin bu olayla neden-sonuç bağı yok. "
                           "\"Bu olay olmasaydı gerçekleşmez miydi?\" diye "
                           "sor.") for y in olay["yanlis_nedenler"]]
                ),
                rastgele=rastgele,
                aciklama="Sonuç, olayın yol açtığı değişikliktir: {}".format(olay["sonuc"]),
                ipuclari=["Bu olay olmasaydı hangisi gerçekleşmezdi?"],
                puan=16,
            ),
        ],
        kapanis="Fişin iki hanesi de dolduruldu.",
        odul={"itibar": 7},
    )
