# -*- coding: utf-8 -*-
"""
Bilişim Teknolojileri görevleri - ilk meslek dersi modülü.

Bu dosya aynı zamanda MESLEK DERSİ YAZANLAR İÇİN ÖRNEKTİR. Meslek dersinin
diğerlerinden tek farkı, alan tablosunda "meslek_uretim" yoluna bağlı olması;
görev yazma kuralları birebir aynıdır:

  - Soru "kaç MB eder?" diye başlamaz. Üste bir iş düşer, öğrenci neyin
    bilinmediğini kendisi fark eder.
  - Önce MODELLEME adımı gelir: hangi bağıntı işliyor? Doğru sayıyı yanlış
    modelle bulmanın yolu yoktur.
  - Yanlış şıklar rastgele değildir: her biri sahada gerçekten yapılan bir
    hatadır ve teşhisi yanına yazılır. Öğrenci o şıkkı seçince hatanın adını
    duyar - "bilmiyorsun" değil, "şunu karıştırdın".

Kademe ölçeği: 1-4 ilkokul, 5-8 ortaokul, 9-12 lise, 13 üniversite.
Bilişim Teknolojileri ve Yazılım ortaokulda da okutulduğu için bir kısım görev
6. sınıftan itibaren açıktır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi,
    sirala_adimi, sy, yorum_adimi,
)


# ==========================================================================
# VERİ BOYUTU VE AKTARIM
# ==========================================================================

@bulmaca(ders="bilisim", konu="veri_boyutu", kademeler=(6, 11),
         etiketler=("birim_cevirme",), agirlik=1.2)
def telsiz_aktarimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Bit / bayt karışıklığı.

    Sahanın en eski tuzağı: hat hızı megaBİT, dosya megaBAYT ile ölçülür.
    Sekiz kat farkı gözden kaçıran öğrenci süreyi sekizde bir hesaplar.
    """
    # Hat hızını 8'in katı seçiyoruz ki bayta çevrildiğinde tam sayı çıksın.
    hiz_mbit = rastgele.choice([8, 16, 24, 32])
    hedef_saniye = rastgele.choice([15, 20, 30, 45, 60])
    boyut_mb = (hiz_mbit // 8) * hedef_saniye
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="bil-telsiz-aktarimi",
        ders="bilisim",
        baslik="Gece Kaydı",
        kademe=kademe,
        konu="veri_boyutu",
        kazanim="Veri büyüklüğü birimleri; bit ile bayt ayrımı; aktarım süresi "
                "hesabı.",
        dikkat=6,
        brifing=(
            "Kronograf odasının gece kaydı çıkarıldı: {} MB'lık tek bir dosya.\n\n"
            "{} dosyayı merkeze göndermek istiyor. Telsiz hattının etiketinde "
            "\"{} Mbit/s\" yazıyor.\n\n"
            "Nöbet değişimine az kaldı. Komutan gönderimin nöbet bitmeden "
            "tamamlanıp tamamlanmayacağını soruyor."
        ).format(sy(boyut_mb), kisi, hiz_mbit),
        kanitlar=[
            Kanit("Dosya bilgisi",
                  "Gece kaydı: {} MB (megabayt).".format(sy(boyut_mb)),
                  bedel=1, kritik=True),
            Kanit("Hat etiketi",
                  "Aktarım hızı: {} Mbit/s (megabit bölü saniye). Etikette "
                  "küçük harfle \"bit\" yazıyor.".format(hiz_mbit),
                  bedel=1, kritik=True),
            Kanit("Telsizci notu",
                  "\"Bir bayt sekiz bittir. Etiketteki hız bit cinsinden; dosya "
                  "bayt cinsinden. Bunları doğrudan bölerseniz yanılırsınız.\"",
                  bedel=2, kritik=True),
            Kanit("Nöbet çizelgesi",
                  "Nöbet değişimine {} saniye var.".format(hedef_saniye + 10),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Gönderim süresini hangi bağıntı verir?",
                dogru="Dosyayı 8 ile çarpıp hat hızına böleriz.",
                yanlislar={
                    "Dosyayı doğrudan hat hızına böleriz, çünkü ikisi de mega "
                    "cinsinden.":
                        "Bit ile baytı karıştırdın. Etiketteki hız megaBİT, "
                        "dosya ise megaBAYT. İkisi aynı birim değil; arada "
                        "8 kat var.",
                    "Dosyayı 8'e bölüp bite çevirir, sonra hat hızına böleriz.":
                        "Çevirmeyi ters yöne yaptın. Bayttan bite geçerken "
                        "sayı BÜYÜR, küçülmez: bir bayt sekiz bit eder.",
                    "Hat hızını dosya boyutuna böleriz.":
                        "Bölmeyi ters kurdun. Süre arıyorsun: taşınacak "
                        "miktarı, saniyede taşınan miktara bölersin.",
                    "Dosya ile hat hızını çarparız.":
                        "Çarpma büyüyen bir sayı verir; oysa hat hızlandıkça "
                        "sürenin küçülmesi gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Süre = taşınacak miktar ÷ birim zamanda taşınan miktar. "
                    "İki tarafın aynı birimde olması şart: {} MB = {} Mbit. "
                    "Sonra {} Mbit/s'ye bölünür.".format(
                        sy(boyut_mb), sy(boyut_mb * 8), hiz_mbit)),
                ipuclari=[
                    "Etikette \"Mbit\", dosyada \"MB\" yazıyor. Aynı şey mi?",
                    "Bir bayt sekiz bittir. Hangisini hangisine çevirmelisin?",
                ],
                cozum=(
                    "1) Birimleri eşitle: {} MB × 8 = {} Mbit.\n"
                    "2) Süre = miktar ÷ hız = {} ÷ {} = {} saniye.".format(
                        sy(boyut_mb), sy(boyut_mb * 8), sy(boyut_mb * 8),
                        hiz_mbit, sy(hedef_saniye))),
            ),
            sayi_adimi(
                soru="Gönderim kaç saniye sürer?",
                cevap=hedef_saniye,
                birim="saniye",
                aciklama="{} × 8 = {} Mbit; {} ÷ {} = {} saniye.".format(
                    sy(boyut_mb), sy(boyut_mb * 8), sy(boyut_mb * 8),
                    hiz_mbit, sy(hedef_saniye)),
                yaygin_yanlislar={
                    boyut_mb / hiz_mbit:
                        "8 ile çarpmayı atladın: dosyayı megabite çevirmeden "
                        "böldün. Bulduğun süre gerçeğin sekizde biri.",
                    boyut_mb * 8 * hiz_mbit:
                        "Bölmen gerekirken çarpmışsın. Hat hızlandıkça süre "
                        "kısalır; çarpma bunun tersini verir.",
                    hedef_saniye * 8:
                        "Sekizle iki kez uğraşmışsın: hem dosyayı çevirip hem "
                        "sonucu tekrar sekizle çarpmış olabilirsin.",
                },
                ipuclari=["Önce {} MB'ı megabite çevir.".format(sy(boyut_mb))],
                puan=14,
            ),
            yorum_adimi(
                soru="Merkez hattı iki katına çıkarırsa gönderim süresi ne olur?",
                dogru="Süre yarıya düşer.",
                yanlislar={
                    "İki katına çıkar.":
                        "Hız ile süreyi aynı yöne bağladın. Oysa hız artınca "
                        "süre kısalır: bunlar ters orantılıdır.",
                    "Değişmez; dosya aynı kalıyor.":
                        "Dosya aynı ama süreyi belirleyen dosya değil, dosya "
                        "ile hızın oranı.",
                    "Sekizde birine iner.":
                        "Sekiz sayısı birim çevirmeden geliyordu; hattın iki "
                        "katına çıkmasıyla ilgisi yok.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Süre = miktar ÷ hız. Miktar sabitken hız iki katına "
                    "çıkarsa süre yarılanır - ters orantı."),
            ),
        ],
        kapanis=(
            "Telsizci kâğıdın kenarına not düşüyor: \"Bundan sonra hat "
            "etiketini gören herkes önce büyük B mi küçük b mi diye baksın.\""),
        odul={"itibar": 3, "enerji": 2},
    )


# ==========================================================================
# İKİLİ SAYI SİSTEMİ
# ==========================================================================

@bulmaca(ders="bilisim", konu="ikili_sayi", kademeler=(6, 12), agirlik=1.1)
def sifre_panosu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İkilide basamak değeri. Yaygın hata: açık anahtarları saymak."""
    basamak = 6 if kademe <= 8 else 8
    deger = rastgele.randrange(2 ** (basamak - 1) + 1, 2 ** basamak - 1)
    ikili = format(deger, "0{}b".format(basamak))
    acik_sayisi = ikili.count("1")
    ters_deger = int(ikili[::-1], 2)
    anahtarlar = "  ".join(
        "{}:{}".format(basamak - i, "AÇIK" if h == "1" else "kapalı")
        for i, h in enumerate(ikili))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="bil-sifre-panosu",
        ders="bilisim",
        baslik="Kilitli Pano",
        kademe=kademe,
        konu="ikili_sayi",
        kazanim="İkili sayı sisteminde basamak değeri; ikiliden onluğa çevirme.",
        dikkat=5,
        brifing=(
            "Şifre odasındaki eski pano kilitlendi. Panonun üstünde {} anahtar "
            "var; bir kısmı açık, bir kısmı kapalı.\n\n"
            "{} kilidin yanındaki plakayı okuyor: \"Anahtar dizisinin sayı "
            "karşılığını çevir koluna gir.\"\n\n"
            "Anahtarların hangi sayıyı gösterdiği yazmıyor. Kolun tek deneme "
            "hakkı var; yanlış sayı panoyu bir güne kilitliyor."
        ).format(basamak, kisi),
        kanitlar=[
            Kanit("Pano görünümü", anahtarlar, bedel=1, kritik=True),
            Kanit("Plaka yazısı",
                  "\"En SAĞDAKİ anahtar 1 değerindedir. Sola gidildikçe her "
                  "anahtarın değeri iki katına çıkar: 1, 2, 4, 8, 16...\"",
                  bedel=2, kritik=True),
            Kanit("Eski tutanak",
                  "\"Geçen sefer açık anahtarların sayısını girdik, pano bir "
                  "gün kilitlendi. Anahtarın kaç tane olduğu değil, NEREDE "
                  "olduğu önemliymiş.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Anahtar dizisinin sayı karşılığı nasıl bulunur?",
                dogru=("Sağdan sola 1, 2, 4, 8... değer verilir; açıkların değeri "
                       "toplanır."),
                yanlislar={
                    "Açık anahtarların sayısı yazılır.":
                        "Adet ile değeri karıştırdın. İkili sayıda bir "
                        "basamağın kaç tane olduğu değil, HANGİ sırada "
                        "durduğu değerini belirler.",
                    "Soldan sağa her basamağa 1, 2, 4, 8... değeri verilir; açıklar "
                    "toplanır.":
                        "Basamak değerini ters yönde saydın. Değer en sağdan "
                        "başlar: en sağdaki 1'dir, sola gidildikçe büyür.",
                    "Açık anahtarların sıra numaraları toplanır, her sıra bir "
                    "değer taşır.":
                        "Sıra numarası ile basamak değeri farklı şeyler. "
                        "3. sıradaki anahtarın değeri 3 değil, 4'tür.",
                    "Açık anahtarlar çarpılır.":
                        "İkili sistemde basamaklar toplanır, çarpılmaz; "
                        "çarpma zaten kapalı basamak varken sıfır verirdi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İkili sayıda her basamağın sabit bir ağırlığı vardır ve "
                    "bu ağırlıklar sağdan sola ikişer katlanır. Açık basamağın "
                    "ağırlığı sayıya eklenir, kapalı basamağınki eklenmez."),
                ipuclari=[
                    "Plakada \"en sağdaki 1 değerindedir\" yazıyor. Nereden "
                    "saymaya başlamalısın?",
                    "Onluk sistemde de 305'teki 3, üç değil üç YÜZ eder.",
                ],
            ),
            sayi_adimi(
                soru="Çevir koluna hangi sayı girilmeli?",
                cevap=deger,
                aciklama="{} dizisi {} eder.".format(ikili, deger),
                # Ters okunuş bazı dizilerde sayının kendisine eşit çıkar
                # (palindrom); o zaman teşhis doğru cevaba yapışacağı için
                # listeye alınmaz.
                yaygin_yanlislar=dict(
                    [(acik_sayisi,
                      "Açık anahtarları saydın. İkilide adet değil, "
                      "basamağın yeri belirleyicidir.")]
                    + ([(ters_deger,
                         "Diziyi ters yönden okudun. Değer en sağdaki "
                         "basamaktan başlar.")] if ters_deger != deger else [])
                ),
                # Dizi 8'de biter, gerisini öğrenci ikiye katlayarak bulur.
                # Eskiden "..., 16, 32" diyordu: 6 anahtarlı panoda 32 bir
                # sonraki adımın ("en soldaki anahtar kaç eder?") doğru
                # cevabıydı -- ipucu sonraki soruyu veriyordu (GOREVLER B9.2,
                # `--denetle` 8. kural).
                ipuclari=["Değerleri sağdan sola yaz: 1, 2, 4, 8... Her "
                          "basamak bir öncekinin iki katıdır.",
                          "Yalnızca AÇIK olanların değerlerini topla."],
                puan=14,
            ),
            yorum_adimi(
                soru="En soldaki anahtar tek başına açık olsaydı sayı kaç olurdu?",
                dogru=sy(2 ** (basamak - 1)),
                yanlislar={
                    "1": "En soldaki anahtar en BÜYÜK değeri taşır; 1 en "
                         "sağdakinin değeridir.",
                    sy(basamak): "Anahtarın sıra numarasını yazdın; oysa "
                                 "sorulan onun değeri.",
                    sy(2 ** basamak): "Bir basamak fazla saydın: {} "
                                      "anahtarlı panoda en soldaki {} "
                                      "eder.".format(basamak, 2 ** (basamak - 1)),
                },
                rastgele=rastgele,
                aciklama="{} basamaklı dizide en soldaki basamağın ağırlığı "
                         "{}.".format(basamak, 2 ** (basamak - 1)),
            ),
        ],
        kapanis="Kol döndü, pano açıldı. Tutanağa \"adet değil, yer\" yazıldı.",
        odul={"cevher": 2, "itibar": 2},
    )


# ==========================================================================
# ARIZA ARAMA SIRASI (ALGORİTMA)
# ==========================================================================

@bulmaca(ders="bilisim", konu="algoritma_akisi", kademeler=(7, 12),
         etiketler=("sira_prosedur",))
def ariza_sirasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Algoritmanın kalbi: adımların sırası sonucu değiştirir."""
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    adimlar_dogru = [
        "Cihaza elektrik geliyor mu, ışığa bak",
        "Anten kablosu yerinde mi, elle kontrol et",
        "Kanal ve frekans ayarı doğru mu, ekrandan oku",
        "Yedek telsizle aynı yerden dene",
        "Merkeze arıza tutanağı geç",
    ]
    karisik = list(adimlar_dogru)
    rastgele.shuffle(karisik)
    sirali = [karisik.index(a) for a in adimlar_dogru]

    return Bulmaca(
        kod="bil-ariza-sirasi",
        ders="bilisim",
        baslik="Sessiz Telsiz",
        kademe=kademe,
        konu="algoritma_akisi",
        kazanim="Bir işi sıralı adımlara bölme; arıza aramada ucuzdan pahalıya "
                "ilerleme ilkesi.",
        dikkat=5,
        brifing=(
            "{} mevkiindeki telsiz sabahtan beri sessiz. Merkez cihazı "
            "değiştirmek için ekip yollamayı düşünüyor; ekip yolu yarım günde "
            "alıyor.\n\n"
            "Sen gitmeden önce yapılabilecekleri sıraya koymakla "
            "görevlendirildin. Elinde beş iş var ama hangisinin önce geleceği "
            "yazmıyor.\n\n"
            "Yanlış sıra pahalıya patlıyor: ekip yolda kaybolan yarım gün, "
            "prizden çıkmış bir fişe harcanmış olabilir."
        ).format(mevki),
        kanitlar=[
            Kanit("Bakım el kitabı",
                  "\"Arıza ararken önce ucuz, hızlı ve sık rastlanan sebebi "
                  "ele; pahalı ve nadir olanı sona bırak.\"", bedel=1,
                  kritik=True),
            Kanit("Geçen ayın kaydı",
                  "Altı arızanın dördü beslemeden, biri kablodan, biri yanlış "
                  "kanal ayarındandı. Cihazın kendisi hiç bozulmamıştı.",
                  bedel=2, kritik=True),
            Kanit("Yedek durumu",
                  "Üste bir yedek telsiz var; taşınabilir ama tek yedek.",
                  bedel=1),
            Kanit("Tutanak kuralı",
                  "Tutanak, arıza giderilse de giderilmese de en sonda yazılır; "
                  "yapılanların hepsi kayda geçmelidir.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Arıza aramasını hangi ilke sıraya koyar?",
                dogru=("Ucuz, hızlı ve sık sebepten pahalı, yavaş ve nadir olana "
                       "ilerlemek."),
                yanlislar={
                    "En pahalı ihtimali önce eleyip gerisini hızlı geçmek, en "
                    "büyük masrafı baştan kapatmak.":
                        "Pahalı ihtimali önce elemek, çoğu zaman gereksiz "
                        "masraf demek. Nadir bir sebep için yarım gün yol "
                        "harcamış olursun.",
                    "Adımları listede yazıldıkları sırayla uygulamak.":
                        "Liste sırası bir yöntem değil, yalnızca yazım sırası. "
                        "Algoritmanın sırasını maliyet ve olasılık belirler.",
                    "Hepsini aynı anda denemek, sonra hangisinin işe yaradığına "
                    "topluca bakmak.":
                        "Aynı anda denersen hangi adımın işe yaradığını "
                        "bilemezsin; arıza tekrarladığında yine baştan "
                        "başlarsın.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Arıza arama bir algoritmadır: her adım bir ihtimali eler. "
                    "Doğru sıra, en çok ihtimali en az maliyetle eleyen "
                    "sıradır. Geçen ayın kaydı da bunu söylüyor: arızaların "
                    "çoğu beslemeden."),
                ipuclari=[
                    "Hangi adım hiç yol gitmeden, saniyeler içinde yapılır?",
                    "Tutanak arızayı gidermez; yeri neresi olmalı?",
                ],
            ),
            sirala_adimi(
                soru="Adımları uygulanacakları sıraya diz (numaraları sırayla yaz):",
                secenekler=karisik,
                dogru_sira=sirali,
                aciklama=(
                    "Doğru sıra: besleme -> kablo -> ayar -> yedek cihaz -> "
                    "tutanak. Her adım bir öncekinden daha pahalı ve daha "
                    "nadir bir sebebi eler."),
                ipuclari=[
                    "Yerinden kalkmadan yapılabilen adımlar başa gelir.",
                    "Yedek telsiz tektir; onu boşa harcamadan önce ayarları "
                    "elemiş olman gerekir.",
                ],
                puan=20,
            ),
            yorum_adimi(
                soru="Bu sıralamayı izlemenin üsse asıl kazandırdığı nedir?",
                dogru=("Aynı arızada başkası da aynı sonuca varır; yöntem kişiye "
                       "bağlı kalmaz."),
                yanlislar={
                    "Arıza her zaman ilk adımda çözülür, çünkü en olası sebep en "
                    "başa konmuştur.":
                        "Sıralama arızayı ilk adımda çözmeyi değil, en az "
                        "maliyetle bulmayı garanti eder.",
                    "Tutanak yazma zorunluluğu ortadan kalkar; sıra zaten kaydın "
                    "yerine geçer.":
                        "Tutanak sıralamanın son adımı; kalkmıyor, yeri "
                        "belirleniyor.",
                    "Yedek telsize hiç ihtiyaç kalmaz.":
                        "Yedek telsiz listede duruyor; sırası değişti, "
                        "gereksizleşmedi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir algoritmanın değeri, aynı girdiyle aynı sonucu "
                    "vermesidir. Yazılı sıra olmadan her nöbetçi kendi "
                    "sezgisiyle arar; sonuç kişiye göre değişir."),
            ),
        ],
        kapanis=("Besleme kablosu prizden yarım parmak çıkmıştı. Ekip yola "
                 "çıkmadı; tutanağa yalnızca ilk adım yazıldı."),
        odul={"itibar": 3, "erzak": 2},
    )


# ==========================================================================
# YEDEKLEME
# ==========================================================================

@bulmaca(ders="bilisim", konu="yedekleme", kademeler=(8, 13),
         etiketler=("maliyet_fire",))
def yedek_araligi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yedek aralığı ile veri kaybı arasındaki bağıntı."""
    aralik = rastgele.choice([3, 4, 5, 7])
    yedek_sayisi = rastgele.randrange(3, 7)
    son_yedek_gunu = aralik * yedek_sayisi
    gecen = rastgele.randrange(1, aralik)
    ariza_gunu = son_yedek_gunu + gecen
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="bil-yedek-araligi",
        ders="bilisim",
        baslik="Sönmüş Disk",
        kademe=kademe,
        konu="yedekleme",
        kazanim="Yedekleme aralığı ile kabul edilen veri kaybı ilişkisi; "
                "yedeğin ayrı yerde tutulması.",
        dikkat=6,
        brifing=(
            "Arşiv diski {}. günün sabahı açılmadı. İçinde seferin başından "
            "beri tutulan bütün ölçüm kayıtları vardı.\n\n"
            "{} \"yedeğimiz var\" diyor. Yedek {} günde bir alınıyormuş ve "
            "sonuncusu {}. günde alınmış.\n\n"
            "Komutan tek bir şey soruyor: kaç günlük iş yeniden yapılacak?"
        ).format(ariza_gunu, kisi, aralik, son_yedek_gunu),
        kanitlar=[
            Kanit("Yedek çizelgesi",
                  "Yedek her {} günde bir alınır. Alınan son yedek: {}. "
                  "gün.".format(aralik, son_yedek_gunu), bedel=1, kritik=True),
            Kanit("Arıza kaydı",
                  "Disk {}. günün sabahı açılmadı; o güne kadarki bütün "
                  "kayıtlar diskteydi.".format(ariza_gunu), bedel=1,
                  kritik=True),
            Kanit("Yedek dolabı",
                  "Yedek kutusu arşivin YANINDAKİ odada duruyor. Aynı çatı, "
                  "aynı elektrik hattı.", bedel=2),
            Kanit("Teknisyen notu",
                  "\"Yedek, son alındığı ana kadarki hâli saklar. Ondan "
                  "sonrasını kimse saklamıyor.\"", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Kaybedilen iş hangi bağıntıyla bulunur?",
                dogru="Arıza günü ile son yedeğin alındığı gün arasındaki fark.",
                yanlislar={
                    "Yedekleme aralığının tamamı kaybolur.":
                        "Aralığın tamamını kayıp saydın. Kaybolan, son "
                        "yedekten SONRA geçen süredir; bu çoğu zaman "
                        "aralıktan kısadır.",
                    "Hiçbir şey kaybolmaz; yedek var.":
                        "Yedeğin varlığı kaybı sıfırlamaz. Yedek yalnızca "
                        "alındığı ana kadarki hâli saklar.",
                    "Sefer başından arıza gününe kadarki bütün süre kaybolur.":
                        "Bütün seferi kayıp saydın; oysa son yedeğe kadarki "
                        "kısım kutuda duruyor.",
                    "Yedek sayısı ile aralığın çarpımı kadar iş kaybolur.":
                        "Bu çarpım son yedeğin gününü verir - kaybı değil, "
                        "kurtarılanın sınırını.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yedek, alındığı anın fotoğrafıdır. O andan arızaya kadar "
                    "yapılan her iş yalnızca diskte durur. Kayıp = arıza günü "
                    "- son yedek günü = {} - {} = {} gün.".format(
                        ariza_gunu, son_yedek_gunu, gecen)),
                ipuclari=[
                    "Yedek hangi güne kadarki hâli saklıyor?",
                    "O günden arızaya kadar geçen sürede yapılan iş nerede "
                    "duruyordu?",
                ],
            ),
            sayi_adimi(
                soru="Kaç günlük iş yeniden yapılacak?",
                cevap=gecen,
                birim="gün",
                aciklama="{} - {} = {} gün.".format(
                    ariza_gunu, son_yedek_gunu, gecen),
                yaygin_yanlislar={
                    aralik: "Yedekleme aralığını yazdın. Aralık, iki yedek "
                            "arasındaki süredir; kayıp ise son yedekten "
                            "arızaya kadar geçen süredir.",
                    ariza_gunu: "Bütün seferi kayıp saydın; son yedeğe kadarki "
                                "kısım kurtarıldı.",
                    son_yedek_gunu: "Son yedeğin gününü yazdın; sorulan, o "
                                    "günden sonra geçen süre.",
                },
                puan=14,
            ),
            yorum_adimi(
                soru="Yedek kutusunun arşivin yanındaki odada durması neden sorun?",
                dogru="Sorun; yangın ya da su baskını ikisini birden vurur.",
                yanlislar={
                    "Sorun değil; yedek yakında olduğu için hızlı ulaşılır.":
                        "Hızlı ulaşmak işe yarar ama yedeğin varlık sebebi "
                        "asılla AYNI kazadan etkilenmemektir.",
                    "Sorun; kutu yakın olduğu için daha çabuk yıpranır.":
                        "Sorun yıpranma değil, aynı kazanın ikisini birden "
                        "alması.",
                    "Sorun; yedek her gün taşınmadığı için eskir.":
                        "Yedeğin eskimesi ayrı bir konu; buradaki risk "
                        "ikisinin aynı yerde durması.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yedeklemenin ilk kuralı ayrı yerde tutmaktır. Aynı çatı "
                    "altındaki iki kopya, tek bir yangında tek kopya kadar "
                    "işe yarar."),
            ),
        ],
        kapanis=("Yedek kutusu ertesi gün gözcü kulesine taşındı; çizelgeye "
                 "\"aralık kısaltılsın\" notu düşüldü."),
        odul={"itibar": 4, "cevher": 1},
    )


# ==========================================================================
# AĞDA ADRESLEME
# ==========================================================================

@bulmaca(ders="bilisim", konu="ag_adresleme", kademeler=(10, 13))
def alt_ag_bolumu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Alt ağda kullanılabilir adres sayısı. Klasik hata: -2'yi unutmak."""
    onek = rastgele.choice([26, 27, 28, 29])
    kalan_bit = 32 - onek
    toplam = 2 ** kalan_bit
    kullanilabilir = toplam - 2
    cihaz = rastgele.randrange(max(3, kullanilabilir - 8), kullanilabilir + 6)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="bil-alt-ag",
        ders="bilisim",
        baslik="Dar Ağ",
        kademe=kademe,
        konu="ag_adresleme",
        kazanim="Alt ağ öneki, adres sayısı ve kullanılabilir adres kavramı.",
        dikkat=6,
        brifing=(
            "{} mevkiindeki gözlem noktasına küçük bir ağ kuruluyor. Merkez "
            "tek bir blok ayırdı: /{} önekli bir alt ağ.\n\n"
            "Kurulum listesinde {} cihaz var: ölçüm aygıtları, iki telsiz "
            "köprüsü, bir yazıcı ve nöbetçi bilgisayarı.\n\n"
            "Teknisyen listeyi görünce duraksadı: \"Bu blok hepsine yeter mi, "
            "bir bakalım.\""
        ).format(mevki, onek, cihaz),
        kanitlar=[
            Kanit("Merkez tahsisi",
                  "Ayrılan blok: /{} önekli alt ağ.".format(onek), bedel=1,
                  kritik=True),
            Kanit("Adres kuralı",
                  "\"IPv4 adresi 32 bittir. Önek, başta sabit kalan bit "
                  "sayısıdır; geri kalan bitler adresleri üretir.\"", bedel=2,
                  kritik=True),
            Kanit("Yönetmelik maddesi",
                  "\"Her alt ağda iki adres cihaza verilemez: en baştaki ağ "
                  "adresi ve en sondaki yayın adresi.\"", bedel=2, kritik=True),
            Kanit("Kurulum listesi",
                  "Bağlanacak cihaz sayısı: {}.".format(cihaz), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu blokta cihazlara verilebilecek adres sayısını hangi "
                     "bağıntı verir?",
                dogru="2 üzeri (32 - önek), eksi ağ ve yayın adresi için 2.",
                yanlislar={
                    "2 üzeri (32 - önek); ağ ve yayın adresi de cihaza verilir.":
                        "Ağ ve yayın adreslerini düşmeyi unuttun. Bu iki adres "
                        "her alt ağda ayrılmıştır, hiçbir cihaza verilemez.",
                    "32 - önek kadar adres olur.":
                        "Bit sayısı ile adres sayısını karıştırdın. Kalan her "
                        "bit adres sayısını iki katına çıkarır; toplam bit "
                        "sayısı kadar değil.",
                    "2 üzeri önek kadar adres olur.":
                        "Üssü ters aldın. Adresleri üreten, sabit kalan önek "
                        "değil, geriye KALAN bitlerdir.",
                    "Önek kaç ise o kadar cihaz bağlanır.":
                        "Önek bir cihaz sayısı değil, adresin baştan kaç "
                        "bitinin sabit olduğunu söyleyen sayıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Adres 32 bit; /{} önekte baştaki {} bit sabittir, geriye "
                    "{} bit kalır. {} bit {} farklı adres üretir. Bunların "
                    "biri ağ adresi, biri yayın adresi olduğu için cihaza "
                    "{} tanesi verilebilir.".format(
                        onek, onek, kalan_bit, kalan_bit, toplam,
                        kullanilabilir)),
                ipuclari=[
                    "Adres 32 bit. Önek sabit kalan kısım; adresleri hangi "
                    "bitler üretiyor?",
                    "Yönetmelik iki adresi cihazlara yasaklıyor.",
                ],
                cozum=(
                    "1) Kalan bit = 32 - {} = {}\n"
                    "2) Toplam adres = 2^{} = {}\n"
                    "3) Kullanılabilir = {} - 2 = {}".format(
                        onek, kalan_bit, kalan_bit, toplam, toplam,
                        kullanilabilir)),
            ),
            sayi_adimi(
                soru="Bu alt ağda cihazlara kaç adres verilebilir?",
                cevap=kullanilabilir,
                birim="adres",
                aciklama="2^{} = {}; {} - 2 = {}.".format(
                    kalan_bit, toplam, toplam, kullanilabilir),
                yaygin_yanlislar={
                    toplam: "Ağ ve yayın adreslerini düşmedin. Toplam adres "
                            "sayısı doğru ama ikisi cihaza verilemez.",
                    kalan_bit: "Kalan bit sayısını yazdın; oysa her bit adres "
                               "sayısını ikiye katlar.",
                    toplam - 1: "Yalnızca bir adres düştün. Ayrılan iki adres "
                                "var: en baştaki ağ, en sondaki yayın adresi.",
                },
                puan=14,
            ),
            yorum_adimi(
                soru="Listedeki {} cihaz bu bloğa sığar mı?".format(cihaz),
                dogru=("Sığar; kullanılabilir adres hepsine yetiyor."
                       if cihaz <= kullanilabilir else
                       "Sığmaz; merkezden daha geniş blok istenmeli."),
                yanlislar={
                    ("Sığmaz; merkezden daha geniş blok istenmeli."
                     if cihaz <= kullanilabilir else
                     "Sığar; kullanılabilir adres hepsine yetiyor."):
                        ("Karşılaştırmayı ters kurdun: {} cihaz, {} "
                         "kullanılabilir adres.".format(cihaz, kullanilabilir)),
                    "Toplam adres sayısına baktığımızda sığar; ayrılan iki "
                    "adres cihazlara da açılabilir.":
                        "Ağ ve yayın adresleri isteğe bağlı değildir; "
                        "yönetmelik onları cihazlara kapatır.",
                    "Cihaz sayısı önemli değil; ağ kendini genişletir.":
                        "Alt ağ kendini genişletmez. Blok sabittir; sığmıyorsa "
                        "merkezden yeni tahsis istenir.",
                },
                rastgele=rastgele,
                aciklama="{} cihaz, {} kullanılabilir adres: {}".format(
                    cihaz, kullanilabilir,
                    "yeter." if cihaz <= kullanilabilir else "yetmez."),
            ),
        ],
        kapanis=("Teknisyen bloğu tahtaya çizdi: \"Bir alt ağda iki adres her "
                 "zaman evin kapısı ve zilidir; kimse orada oturmaz.\""),
        odul={"cevher": 3, "itibar": 2},
    )


# ==========================================================================
# SAYMA VE DÖNGÜ
# ==========================================================================

@bulmaca(ders="bilisim", konu="dongu_sayisi", kademeler=(7, 12), agirlik=1.1)
def olcum_turu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir eksik sayma (off-by-one). Yazılımın en eski hatası."""
    ilk = rastgele.randrange(4, 20)
    adet = rastgele.randrange(8, 20)
    son = ilk + adet - 1
    sure = rastgele.choice([3, 4, 5, 6])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="bil-olcum-turu",
        ders="bilisim",
        baslik="Kule Turu",
        kademe=kademe,
        konu="dongu_sayisi",
        kazanim="Aralıktaki öğe sayısını bulma; bir eksik sayma hatasından "
                "kaçınma; tekrar sayısı ile süre ilişkisi.",
        dikkat=5,
        brifing=(
            "Sınır hattındaki kuleler {} numaradan {} numaraya kadar "
            "numaralanmış. {} her kulede bir ölçüm alacak; hiçbirini "
            "atlamayacak.\n\n"
            "Merkez, turun ne kadar süreceğini şimdiden bilmek istiyor: "
            "her ölçüm {} dakika sürüyor.\n\n"
            "Kaç kule olduğu hiçbir yerde yazmıyor; yalnızca ilk ve son "
            "numara belli."
        ).format(ilk, son, kisi, sure),
        kanitlar=[
            Kanit("Hat çizelgesi",
                  "Kule numaraları: ilki {}, sonuncusu {}; arada eksik yok.".format(ilk, son),
                  bedel=1, kritik=True),
            Kanit("Ölçüm yönergesi",
                  "\"İLK ve SON kule dahil, her kulede bir ölçüm alınır.\"",
                  bedel=2, kritik=True),
            Kanit("Süre notu",
                  "Bir ölçüm {} dakika sürüyor. Kuleler arası yol süresi "
                  "hesaba katılmıyor.".format(sure), bedel=1),
            Kanit("Geçen ayın hatası",
                  "\"Geçen ay sayıyı çıkarma ile bulduk, son kule listeye "
                  "girmedi; oraya ikinci kez gitmek gerekti.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kaç kulede ölçüm alınacağını hangi bağıntı verir?",
                dogru="Son numaradan ilkini çıkarıp 1 eklemek.",
                yanlislar={
                    "Son numaradan ilk numarayı çıkarmak, aradaki fark kule "
                    "sayısıdır.":
                        "Bir eksik saydın. Çıkarma, aradaki ADIM sayısını "
                        "verir; uçlardan biri sayının dışında kalır. İki uç "
                        "da dahilse 1 eklemelisin.",
                    "İki numarayı toplamak.":
                        "Toplama numaraları birleştirir, aralarındaki öğe "
                        "sayısını vermez. Numaralar ad gibidir, miktar değil.",
                    "Son numarayı doğrudan kule sayısı saymak.":
                        "Numaralandırma 1'den başlamıyor: ilk kule {} "
                        "numaralı. Son numara ancak 1'den başlansaydı adet "
                        "olurdu.".format(ilk),
                    "İki numaranın farkını 2'ye bölmek.":
                        "Bölme burada bir şey elemiyor; aralıktaki her kuleye "
                        "gidilecek, atlanmıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Uçları dahil bir aralıkta öğe sayısı = son - ilk + 1. "
                    "Çıkarma yalnızca aradaki boşluk sayısını verir: {} ile "
                    "{} arasında {} boşluk ama {} kule vardır.".format(
                        ilk, son, adet - 1, adet)),
                ipuclari=[
                    "Küçük bir örnekle dene: 4'ten 6'ya kadar kaç kule var?",
                    "Yönerge \"ilk ve son dahil\" diyor. Çıkarma hangisini "
                    "dışarıda bırakır?",
                ],
            ),
            sayi_adimi(
                soru="Kaç kulede ölçüm alınacak?",
                cevap=adet,
                birim="kule",
                aciklama="{} - {} + 1 = {}.".format(son, ilk, adet),
                yaygin_yanlislar={
                    adet - 1: "Bir eksik saydın: uçlardan biri listenin "
                              "dışında kaldı. İki uç da dahil olduğunda "
                              "farka 1 eklenir.",
                    adet + 1: "Bir fazla saydın; 1'i iki kez eklemiş "
                              "olabilirsin.",
                    son: "Son numarayı adet sandın. İlk numara {}, "
                         "1 değil.".format(ilk),
                },
                puan=12,
            ),
            sayi_adimi(
                soru="Tur toplam kaç dakika sürer?",
                cevap=adet * sure,
                birim="dakika",
                aciklama="{} kule × {} dakika = {} dakika.".format(
                    adet, sure, adet * sure),
                yaygin_yanlislar={
                    (adet - 1) * sure:
                        "Kule sayısını bir eksik aldın; hata süreye de "
                        "taşındı. Yanlış sayı, sonraki her adımı bozar.",
                    adet + sure:
                        "Çarpmak yerine topladın. Her kulede ayrı bir ölçüm "
                        "var; süreler toplanır, yani sayı ile süre çarpılır.",
                },
                ipuclari=["Önce kule sayısını kesinleştir, sonra çarp."],
                puan=12,
            ),
            yorum_adimi(
                soru="Geçen ayki hata neden ikinci bir yolculuğa mal oldu?",
                dogru="Sayım bir eksik çıkınca son kule listeye girmedi.",
                yanlislar={
                    "Ölçüm süresi yanlış hesaplandığı için ekip geç kaldı.":
                        "Süre hatası turu uzatır ama kuleyi listeden "
                        "düşürmez. Eksik olan kulenin kendisiydi.",
                    "Kuleler yanlış numaralandığı için ekip kayboldu.":
                        "Numaralandırmada sorun yok; sorun numaraların nasıl "
                        "sayıldığında.",
                    "Ölçüm aygıtı bozuk olduğu için tekrar gidildi.":
                        "Kayıtta aygıt arızasından söz edilmiyor; sözü edilen "
                        "sayım yöntemi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir eksik sayma, yazılımda da sahada da aynı sonucu "
                    "verir: son öğe hiç işlenmez. Hata küçüktür, bedeli "
                    "değildir."),
            ),
        ],
        kapanis=("Çizelgenin başına kırmızıyla not düşüldü: \"İki uç da "
                 "dahilse fark + 1.\""),
        odul={"erzak": 2, "itibar": 3},
    )
