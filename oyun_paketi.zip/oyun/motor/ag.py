# -*- coding: utf-8 -*-
"""
Ağ katmanı. Ekran gibi bu da takılabilir.

NEDEN BÖYLE
-----------
TASARIM_NOTLARI §8: motor kalır, kabuk değişir. Ekranda öyle yaptık;
ağda yapmak ZORUNDAYIZ, çünkü oyun iki farklı yerde çalışıyor:

* Bilgisayarda normal CPython -- `urllib` var.
* Telefonda Pyodide -- `socket` YOK. Tarayıcının içindeyiz; dışarıya
  ancak sayfanın `fetch`i ile çıkılır, o da eşzamansızdır.

Oyun kodu ikisini de bilmemeli. Bildiği tek şey `ag.gonder(...)`.

SESSİZ BAŞARISIZLIK BİLEREK
---------------------------
Bu katmandaki her çağrı, ağ yoksa `None` döner ve hata FIRLATMAZ.
Sebep pedagojik: ağ sınıfta kesilir. Öğrenci bir soruyu çözerken oyunun
"bağlantı hatası" diye durması, çözmekte olduğu şeyi unutturur. Ağa bağlı
işlerin hepsi (el kaldırma, sınıf kodu doğrulama) oyunun YANINDA duran
işlerdir; hiçbiri oynamanın şartı değildir ve öyle kalmalıdır.

Bir şeyi ağa bağımlı kılmak isteyen önce bu paragrafı değiştirmeli.
"""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

# Sunucu adresi. Boşsa ağ YOK demektir ve her çağrı None döner -- oyunun
# varsayılan hâli budur. Öğretmen sunucu kurduysa sınıf kodunun yanında
# gelir (bkz. araclar/sinif.py) ya da elle ayarlanır.
_SUNUCU = ""

# Kaç saniye beklenir. Kısa: sınıfta ağ ya vardır ya yoktur, ikisinin
# arasında beklemek dersi böler.
ZAMAN_ASIMI = 4.0


class UrllibAgi:
    """Bilgisayarda çalışan varsayılan taşıyıcı."""

    def gonder(self, adres: str, veri: Optional[Dict[str, Any]],
               zaman_asimi: float) -> Optional[Dict[str, Any]]:
        import urllib.error
        import urllib.request

        govde = None
        basliklar = {"Accept": "application/json"}
        if veri is not None:
            govde = json.dumps(veri).encode("utf-8")
            basliklar["Content-Type"] = "application/json"
        istek = urllib.request.Request(adres, data=govde, headers=basliklar)
        try:
            with urllib.request.urlopen(istek, timeout=zaman_asimi) as yanit:
                ham = yanit.read().decode("utf-8")
        except Exception:              # noqa: BLE001 - bkz. modül açıklaması
            return None
        try:
            return json.loads(ham)
        except ValueError:
            return None


_AG = UrllibAgi()


def ag_ata(yeni_ag) -> None:
    """Taşıyıcıyı değiştirir. Tarayıcı kabuğu açılışta bunu çağırır."""
    global _AG
    _AG = yeni_ag


def sunucu_ata(adres: str) -> None:
    global _SUNUCU
    _SUNUCU = (adres or "").strip().rstrip("/")


def sunucu() -> str:
    return _SUNUCU


def acik_mi() -> bool:
    return bool(_SUNUCU)


def baslangicta_kur() -> str:
    """Sunucu adresini bulup kurar. Bulamazsa ağ kapalı kalır.

    İki yere bakılır, bu sırayla:
      1. `MERIDYEN_SINIF_SUNUCUSU` ortam değişkeni -- geçici denemeler için.
      2. `kayitlar/ag.json` içindeki `sinif_sunucusu` -- kalıcı ayar.

    Telefonda bu işi `mobil/ayarlar.json` yapıyor; oradaki değeri işçi
    okuyup `sunucu_ata` çağırıyor. İki yer var çünkü iki farklı kurulum
    var: okulun sunucusunu bilgisayarda öğretmen ayarlar, telefonlarda ise
    ayar sayfayla birlikte dağıtılır -- öğrenci adres yazmaz.
    """
    import os

    from oyun.motor import durum as durum_modulu

    adres = (os.environ.get("MERIDYEN_SINIF_SUNUCUSU") or "").strip()
    if not adres:
        yol = os.path.join(durum_modulu.KAYIT_KLASORU, "ag.json")
        try:
            import io
            with io.open(yol, encoding="utf-8") as dosya:
                adres = str(json.load(dosya).get("sinif_sunucusu") or "").strip()
        except Exception:          # noqa: BLE001 - ayar yoksa ağ da yok
            adres = ""
    sunucu_ata(adres)
    return adres


def gonder(yol: str, veri: Optional[Dict[str, Any]] = None,
           zaman_asimi: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """Sunucuya bir istek. Ağ yoksa ya da bir şey ters giderse None.

    `veri` None ise GET, doluysa POST olur.
    """
    if not _SUNUCU:
        return None
    adres = _SUNUCU + ("" if yol.startswith("/") else "/") + yol
    try:
        return _AG.gonder(adres, veri, zaman_asimi or ZAMAN_ASIMI)
    except Exception:                  # noqa: BLE001
        # Taşıyıcının kendisi patlasa bile oyun durmaz.
        return None
