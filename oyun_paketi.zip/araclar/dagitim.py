# -*- coding: utf-8 -*-
"""
Dağıtılabilir paketi kaynaktan üretir.

    python main.py --dagitim

NEDEN VAR
---------
Dağıtım paketi 8 Eylül 2026'ya kadar ELLE kuruluyordu. Sonucu şu oldu:
kökteki `Meridyen-Seferi-2026-09-08.zip` yalnızca kaynak koddu (gömülü
Python yok, açılış dosyası yok), "MOBIL" adını taşıyan paketin içinde ise
`mobil/` klasörü hiç yoktu. İkisi de sessiz hatalar; ancak paketi açıp
çalıştırmayı deneyen biri fark ederdi.

Elle yapılan iş tekrarlanamaz. Bu dosya o işi tekrarlanabilir yapıyor:
her çalıştırmada aynı yapı, güncel kaynaktan.

PAKETTE NE VAR
--------------
    MeridyenSeferi/
      OYUNU_BASLAT.bat        bilgisayarda oyna (çift tık)
      TELEFONDAN_OYNA.bat     telefonlar için sayfayı yayınla
      SINIF_SUNUCUSU.bat      sınıfı birbirine bağla (isteğe bağlı)
      OKU.txt                 üç satırlık başlangıç
      main.py, oyun/, araclar/
      mobil/                  telefonda çalışan sürüm
      python/                 gömülü Python 3.12 -- kurulum gerekmesin diye
      belgeler (README, SINIF_KURULUMU, TASARIM_NOTLARI)

GÖMÜLÜ PYTHON
-------------
`_gomulu_python/` klasöründen kopyalanır. O klasör sürüm kontrolünde
DEĞİL (22 MB ikili dosya) ama pakette olmak zorunda: alıcının Python
kurmasını beklemek, oyunun okulda kullanılmamasının en kolay yolu.
Klasör yoksa paket yine üretilir, uyarıyla -- kaynak paketi olarak işe
yarar, çift tıklanabilir olmaz.
"""
from __future__ import annotations

import io
import os
import shutil
import sys
import time
import zipfile

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GOMULU = os.path.join(KOK, "_gomulu_python")
CIKTI_KLASORU = os.path.join(os.path.dirname(KOK), "_paketler")

# Pakete girecek kaynak klasörleri.
KLASORLER = ("oyun", "araclar", "mobil")

BELGELER = ("README.md", "SINIF_KURULUMU.md", "TASARIM_NOTLARI.md",
            "ICERIK_EKLEME.md")

# Pakete GİRMEYECEKLER. Kayıtlar öğrencinin kendi verisi; testler ve
# geliştirme belgeleri alıcıyı ilgilendirmiyor.
DISLANAN = {"__pycache__", ".git", ".venv", ".pytest_cache", "kayitlar",
            "karneler", "geri_bildirim", "_gomulu_python", "testler",
            "_paketler"}


def _kopyalanir_mi(ad: str) -> bool:
    return ad not in DISLANAN and not ad.endswith((".pyc", ".tmp"))


def _klasor_kopyala(kaynak: str, hedef: str) -> int:
    sayi = 0
    for kok, klasorler, dosyalar in os.walk(kaynak):
        klasorler[:] = [k for k in klasorler if _kopyalanir_mi(k)]
        goreli = os.path.relpath(kok, kaynak)
        varis = hedef if goreli == "." else os.path.join(hedef, goreli)
        os.makedirs(varis, exist_ok=True)
        for dosya in dosyalar:
            if not _kopyalanir_mi(dosya):
                continue
            shutil.copy2(os.path.join(kok, dosya), os.path.join(varis, dosya))
            sayi += 1
    return sayi


BASLAT_BAT = """@echo off
chcp 65001 >nul
title Meridyen Seferi
cd /d "%~dp0"
python\\python.exe main.py
if errorlevel 1 pause
"""

TELEFON_BAT = """@echo off
chcp 65001 >nul
title Meridyen Seferi - telefondan oyna
cd /d "%~dp0"
echo.
echo  Telefonlar bu bilgisayardaki sayfayi acacak.
echo  Telefon ile bilgisayar AYNI kablosuz agda olmali.
echo.
echo  1) Asagida yazan https:// adresini telefonun tarayicisina yaz.
echo  2) Telefon "bu site guvenli degil" diyecek. BU NORMAL --
echo     sertifika bu bilgisayarda uretildi, tanidik degil.
echo     "Gelismis" ^> "Yine de devam et" de.
echo  3) Oyun acilir.
echo.
echo  Kapatmak icin bu pencerede Ctrl+C.
echo.
python\\python.exe mobil\\sunucu_ornegi.py
pause
"""

SINIF_BAT = """@echo off
chcp 65001 >nul
title Meridyen Seferi - sinif sunucusu
cd /d "%~dp0"
echo.
echo  Bu pencere yalnizca sinif kodunu dogrular ve el kaldirma
echo  bildirilerini sayar. Oyunu CALISTIRMAZ - oyun telefonda calisir.
echo.
echo  Gerekli degil: ayni agdaysaniz bu pencereye ihtiyaciniz yok.
echo  Ayrintilar icin SINIF_KURULUMU.md dosyasini oku.
echo.
python\\python.exe araclar\\sinif_sunucusu.py
pause
"""

OKU_TXT = """MERIDYEN SEFERI
===============

Bilgisayarda oynamak icin  : OYUNU_BASLAT.bat  (cift tikla)
Telefonlardan oynamak icin : TELEFONDAN_OYNA.bat
Sinifi birbirine baglamak  : SINIF_SUNUCUSU.bat  (istege bagli)

TELEFON HAKKINDA -- onceden bilinmezse vakit kaybettirir:
  * Dosyayi telefona kopyalayip tiklamak CALISMAZ. Oyunun soru
    sorabilmesi icin sayfanin bir ADRESTEN gelmesi gerekiyor.
  * TELEFONDAN_OYNA.bat bir https adresi verir. Telefon "bu site
    guvenli degil" uyarisi gosterir; normaldir, "Gelismis" >
    "Yine de devam et" denince oyun acilir.
  * Telefon ile bilgisayar ayni kablosuz agda olmali.

Python kurmana gerek yok; python\\ klasorunde geliyor.

Ilk defa aciyorsan OYUNU_BASLAT.bat yeter. Sinifa dagitacaksan once
SINIF_KURULUMU.md dosyasini oku -- ne gerekip ne gerekmedigi orada.

Kayitlar kayitlar\\ klasorunde tutulur; oyun disariya hicbir sey
gondermez.
"""


def paketle(etiket: str = "") -> str:
    """Paketi üretir ve zip yolunu döndürür."""
    from araclar.mobil_paket import guncel_mi, main as mobil_paketle

    # Mobil paket eskiyse telefon eski sürümü koşar. Sessizce yenileniyor:
    # bunu unutmak bu projede iki kez baştan geldi.
    if not guncel_mi():
        print("  mobil/oyun_paketi.zip eskiydi, yenileniyor...")
        mobil_paketle()

    tarih = time.strftime("%Y-%m-%d")
    ad = "MeridyenSeferi-{}{}".format(tarih, ("-" + etiket) if etiket else "")
    gecici = os.path.join(CIKTI_KLASORU, "_kurulum")
    icerik = os.path.join(gecici, "MeridyenSeferi")
    shutil.rmtree(gecici, ignore_errors=True)
    os.makedirs(icerik, exist_ok=True)

    toplam = 0
    for klasor in KLASORLER:
        kaynak = os.path.join(KOK, klasor)
        if os.path.isdir(kaynak):
            toplam += _klasor_kopyala(kaynak, os.path.join(icerik, klasor))

    for dosya in ("main.py",) + BELGELER:
        kaynak = os.path.join(KOK, dosya)
        if os.path.exists(kaynak):
            shutil.copy2(kaynak, os.path.join(icerik, dosya))
            toplam += 1

    if os.path.isdir(GOMULU):
        toplam += _klasor_kopyala(GOMULU, os.path.join(icerik, "python"))
        gomulu_var = True
    else:
        gomulu_var = False

    for dosya_adi, metin in (("OYUNU_BASLAT.bat", BASLAT_BAT),
                             ("TELEFONDAN_OYNA.bat", TELEFON_BAT),
                             ("SINIF_SUNUCUSU.bat", SINIF_BAT),
                             ("OKU.txt", OKU_TXT)):
        # .bat dosyaları CRLF ister; chcp 65001 ile UTF-8 okunuyor.
        with io.open(os.path.join(icerik, dosya_adi), "w",
                     encoding="utf-8", newline="\r\n") as d:
            d.write(metin)
        toplam += 1

    # Kayıt klasörü boş olarak gelsin: oyun ilk açılışta kendi oluşturur
    # ama klasörün varlığı "kayıtlarım nereye gidiyor" sorusunu peşinen
    # cevaplıyor.
    os.makedirs(os.path.join(icerik, "kayitlar"), exist_ok=True)
    with io.open(os.path.join(icerik, "kayitlar", "OKU.txt"), "w",
                 encoding="utf-8", newline="\r\n") as d:
        d.write("Kayitlar buraya yazilir. Bu klasoru silersen ilerleme gider.\n")

    os.makedirs(CIKTI_KLASORU, exist_ok=True)
    hedef = os.path.join(CIKTI_KLASORU, ad + ".zip")
    with zipfile.ZipFile(hedef, "w", zipfile.ZIP_DEFLATED) as zip_dosyasi:
        for kok, _, dosyalar in os.walk(gecici):
            for dosya in dosyalar:
                tam = os.path.join(kok, dosya)
                zip_dosyasi.write(tam, os.path.relpath(tam, gecici))
    shutil.rmtree(gecici, ignore_errors=True)

    print("Paket hazır: {}".format(hedef))
    print("  {} dosya, {:.1f} MB".format(toplam,
                                         os.path.getsize(hedef) / 1048576))
    if not gomulu_var:
        print()
        print("  !! UYARI: _gomulu_python/ yok. Paket ÇİFT TIKLANAMAZ;")
        print("     açan kişinin Python kurmuş olması gerekir.")
    return hedef


def eskileri_tasi(yeni: str) -> int:
    """Kökteki ve `_paketler/` içindeki eski Meridyen paketlerini arşive alır.

    Kuralı GOREVLER.md koyuyor: kökte her zaman yalnızca en güncel paket
    durur, eskisi silinmez -- `_paketler/eski/` altına taşınır. Sebep:
    5 Eylül'de yanlış paket dağıtıldı çünkü hangisinin güncel olduğu
    dosya adından anlaşılmıyordu.
    """
    arsiv = os.path.join(CIKTI_KLASORU, "eski")
    os.makedirs(arsiv, exist_ok=True)
    tasinan = 0
    for klasor in (os.path.dirname(KOK), CIKTI_KLASORU):
        for ad in os.listdir(klasor):
            yol = os.path.join(klasor, ad)
            if yol == yeni or not os.path.isfile(yol):
                continue
            dusuk = ad.lower()
            if not dusuk.endswith(".zip"):
                continue
            if "meridyen" not in dusuk:
                continue
            shutil.move(yol, os.path.join(arsiv, ad))
            tasinan += 1
    return tasinan


def main(etiket: str = "") -> int:
    hedef = paketle(etiket)
    tasinan = eskileri_tasi(hedef)
    if tasinan:
        print("  {} eski paket _paketler/eski/ altına taşındı".format(tasinan))
    return 0


if __name__ == "__main__":
    sys.path.insert(0, KOK)
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else ""))
