# -*- coding: utf-8 -*-
"""Atlas icin Natural Earth (kamu mali) verisini sadelestirir.

Kullanim (ham veri guvenilmeyen sayilir; `-I` ile calistir):

    python -I araclar/atlas_veri.py --ham _ham_veri --cikti os/atlas

Girdi (GeoJSON, github.com/nvkelso/natural-earth-vector/geojson):
    ne_110m_admin_0_countries.geojson   dunya
    ne_50m_admin_0_countries.geojson    Turkiye cevresi (kutu ile kirpilir)
    ne_10m_admin_1_states_provinces.geojson   yalniz admin == Turkey

Cikti (os/atlas/):
    dunya.json     {"ulkeler": [{"ad", "d"}]}   d = SVG yolu, birim: derece (boylam, enlem)
    cevre.json     Turkiye cevresindeki ulkeler (daha ince)
    turkiye.json   {"iller": [{"plaka", "ad", "bolge", "d"}]}
    merkezler.json {"merkezler": [{"plaka", "ad", "bolge", "x", "y"}]}

Yol koordinatlari DERECE cinsindendir (x = boylam, y = enlem). Arayuz y'yi
ters cevirir. Iller ve bolgeler plaka koduna gore elle yazilmis tablodan
gelir (ham verideki yazim hatalarina guvenilmez).
"""
from __future__ import annotations

import argparse
import json
import os
import sys

IL_ADLARI = {
    1: "Adana", 2: "Adıyaman", 3: "Afyonkarahisar", 4: "Ağrı", 5: "Amasya", 6: "Ankara", 7: "Antalya",
    8: "Artvin", 9: "Aydın", 10: "Balıkesir", 11: "Bilecik", 12: "Bingöl", 13: "Bitlis", 14: "Bolu",
    15: "Burdur", 16: "Bursa", 17: "Çanakkale", 18: "Çankırı", 19: "Çorum", 20: "Denizli",
    21: "Diyarbakır", 22: "Edirne", 23: "Elazığ", 24: "Erzincan", 25: "Erzurum", 26: "Eskişehir",
    27: "Gaziantep", 28: "Giresun", 29: "Gümüşhane", 30: "Hakkâri", 31: "Hatay", 32: "Isparta",
    33: "Mersin", 34: "İstanbul", 35: "İzmir", 36: "Kars", 37: "Kastamonu", 38: "Kayseri",
    39: "Kırklareli", 40: "Kırşehir", 41: "Kocaeli", 42: "Konya", 43: "Kütahya", 44: "Malatya",
    45: "Manisa", 46: "Kahramanmaraş", 47: "Mardin", 48: "Muğla", 49: "Muş", 50: "Nevşehir",
    51: "Niğde", 52: "Ordu", 53: "Rize", 54: "Sakarya", 55: "Samsun", 56: "Siirt", 57: "Sinop",
    58: "Sivas", 59: "Tekirdağ", 60: "Tokat", 61: "Trabzon", 62: "Tunceli", 63: "Şanlıurfa",
    64: "Uşak", 65: "Van", 66: "Yozgat", 67: "Zonguldak", 68: "Aksaray", 69: "Bayburt", 70: "Karaman",
    71: "Kırıkkale", 72: "Batman", 73: "Şırnak", 74: "Bartın", 75: "Ardahan", 76: "Iğdır",
    77: "Yalova", 78: "Karabük", 79: "Kilis", 80: "Osmaniye", 81: "Düzce",
}
BOLGE_ILLERI = {
    "Marmara": (10, 11, 16, 17, 22, 34, 39, 41, 54, 59, 77),
    "Ege": (3, 9, 20, 35, 43, 45, 48, 64),
    "Akdeniz": (1, 7, 15, 31, 32, 33, 46, 80),
    "İç Anadolu": (6, 18, 26, 38, 40, 42, 50, 51, 58, 66, 68, 70, 71),
    "Karadeniz": (5, 8, 14, 19, 28, 29, 37, 52, 53, 55, 57, 60, 61, 67, 69, 74, 78, 81),
    "Doğu Anadolu": (4, 12, 13, 23, 24, 25, 30, 36, 44, 49, 62, 65, 75, 76),
    "Güneydoğu Anadolu": (2, 21, 27, 47, 56, 63, 72, 73, 79),
}
IL_BOLGE = {p: b for b, ps in BOLGE_ILLERI.items() for p in ps}

# Turkiye cevresi: boylam 17..52, enlem 28..48
CEVRE_KUTU = (17.0, 28.0, 52.0, 48.0)


def _dik_uzaklik(p, a, b):
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    if dx == 0 and dy == 0:
        return ((p[0] - ax) ** 2 + (p[1] - ay) ** 2) ** 0.5
    t = ((p[0] - ax) * dx + (p[1] - ay) * dy) / (dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    return ((p[0] - (ax + t * dx)) ** 2 + (p[1] - (ay + t * dy)) ** 2) ** 0.5


def douglas_peucker(noktalar, tol):
    """Yinelemesiz Douglas-Peucker. noktalar: [(x, y), ...]"""
    n = len(noktalar)
    if n < 3:
        return list(noktalar)
    tut = [False] * n
    tut[0] = tut[-1] = True
    yigin = [(0, n - 1)]
    while yigin:
        i, j = yigin.pop()
        en, en_i = 0.0, -1
        for k in range(i + 1, j):
            d = _dik_uzaklik(noktalar[k], noktalar[i], noktalar[j])
            if d > en:
                en, en_i = d, k
        if en > tol and en_i > 0:
            tut[en_i] = True
            yigin.append((i, en_i))
            yigin.append((en_i, j))
    return [p for p, t in zip(noktalar, tut) if t]


def halka_sadelestir(halka, tol, hane):
    """Kapali halkayi sadelestirir; en az 3 koseli halka ya da None."""
    pts = [(float(p[0]), float(p[1])) for p in halka]
    if len(pts) > 1 and pts[0] == pts[-1]:
        pts = pts[:-1]
    if len(pts) < 3:
        return None
    # halkayi en uzak noktada ikiye bol, iki parcayi ayri sadelestir
    k = max(range(len(pts)), key=lambda i: (pts[i][0] - pts[0][0]) ** 2 + (pts[i][1] - pts[0][1]) ** 2)
    a = douglas_peucker(pts[:k + 1], tol)
    b = douglas_peucker(pts[k:] + [pts[0]], tol)
    s = a[:-1] + b[:-1]
    yuvar = [(round(x, hane), round(y, hane)) for x, y in s]
    temiz = [yuvar[0]]
    for p in yuvar[1:]:
        if p != temiz[-1]:
            temiz.append(p)
    if len(temiz) > 1 and temiz[0] == temiz[-1]:
        temiz.pop()
    if len(temiz) < 3:
        return None
    return temiz


def _alan(r):
    n = len(r)
    return abs(sum(r[i][0] * r[(i + 1) % n][1] - r[(i + 1) % n][0] * r[i][1] for i in range(n))) / 2


def _sayi(v, hane):
    s = ("%." + str(hane) + "f") % v
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def halkalar_yola(halkalar, hane):
    """[[(x,y)...], ...] -> SVG 'd' (mutlak M/L/Z, kompakt)."""
    parcalar = []
    for r in halkalar:
        p = ["M" + _sayi(r[0][0], hane) + " " + _sayi(r[0][1], hane)]
        for x, y in r[1:]:
            p.append("L" + _sayi(x, hane) + " " + _sayi(y, hane))
        p.append("Z")
        parcalar.append("".join(p))
    return "".join(parcalar)


def poligon_listesi(geom):
    """GeoJSON geometrisi -> [[halka, delik, ...], ...]"""
    if not geom:
        return []
    if geom["type"] == "Polygon":
        return [geom["coordinates"]]
    if geom["type"] == "MultiPolygon":
        return geom["coordinates"]
    return []


def geometriyi_yola(geom, tol, hane, kutu=None, min_alan=0.0):
    """Sadelestirilmis yol; kutu verilirse tamamen disindaki parcalar atilir."""
    halkalar = []
    for poli in poligon_listesi(geom):
        dis = poli[0]
        if kutu:
            xs = [p[0] for p in dis]
            ys = [p[1] for p in dis]
            if max(xs) < kutu[0] or min(xs) > kutu[2] or max(ys) < kutu[1] or min(ys) > kutu[3]:
                continue
        r0 = halka_sadelestir(dis, tol, hane)
        if r0 is None or _alan(r0) < min_alan:
            continue
        halkalar.append(r0)
        for delik in poli[1:]:
            rd = halka_sadelestir(delik, tol, hane)
            if rd is not None and _alan(rd) >= min_alan:
                halkalar.append(rd)
    return halkalar_yola(halkalar, hane) if halkalar else ""


def _oku(yol):
    with open(yol, encoding="utf-8") as f:
        return json.load(f)


def _ad_tr(p):
    return (p.get("NAME_TR") or p.get("name_tr") or p.get("NAME") or p.get("ADMIN") or "").strip()


def _yaz(yol, veri):
    with open(yol, "w", encoding="utf-8", newline="\n") as f:
        json.dump(veri, f, ensure_ascii=False, separators=(",", ":"))
        f.write("\n")
    return os.path.getsize(yol)


def dunya_uret(ham, cikti):
    d = _oku(os.path.join(ham, "ne_110m_admin_0_countries.geojson"))
    ulkeler = []
    for f in d["features"]:
        p = f["properties"]
        if (p.get("ADMIN") or "") == "Antarctica":
            continue
        yol = geometriyi_yola(f["geometry"], 0.12, 1, min_alan=0.05)
        if yol:
            ulkeler.append({"ad": _ad_tr(p), "d": yol})
    return _yaz(os.path.join(cikti, "dunya.json"), {"ulkeler": ulkeler})


def cevre_uret(ham, cikti):
    d = _oku(os.path.join(ham, "ne_50m_admin_0_countries.geojson"))
    ulkeler = []
    for f in d["features"]:
        p = f["properties"]
        yol = geometriyi_yola(f["geometry"], 0.02, 2, kutu=CEVRE_KUTU, min_alan=0.01)
        if yol:
            ulkeler.append({"ad": _ad_tr(p), "d": yol})
    return _yaz(os.path.join(cikti, "cevre.json"), {"kutu": list(CEVRE_KUTU), "ulkeler": ulkeler})


def plaka_kodu(p):
    iso = (p.get("iso_3166_2") or "")
    if iso.startswith("TR-"):
        try:
            return int(iso[3:])
        except ValueError:
            return None
    return None


def turkiye_uret(ham, cikti):
    d = _oku(os.path.join(ham, "ne_10m_admin_1_states_provinces.geojson"))
    iller, merkezler, goruldu = [], [], set()
    for f in d["features"]:
        p = f["properties"]
        if p.get("admin") != "Turkey":
            continue
        k = plaka_kodu(p)
        if k not in IL_ADLARI or k in goruldu:
            continue
        goruldu.add(k)
        yol = geometriyi_yola(f["geometry"], 0.005, 2, min_alan=0.001)
        iller.append({"plaka": k, "ad": IL_ADLARI[k], "bolge": IL_BOLGE[k], "d": yol})
        lon, lat = p.get("longitude"), p.get("latitude")
        merkezler.append({"plaka": k, "ad": IL_ADLARI[k], "bolge": IL_BOLGE[k],
                          "x": round(float(lon), 2), "y": round(float(lat), 2)})
    iller.sort(key=lambda x: x["plaka"])
    merkezler.sort(key=lambda x: x["plaka"])
    if len(iller) != 81:
        raise SystemExit("Ham veride 81 il bulunamadi: %d" % len(iller))
    b1 = _yaz(os.path.join(cikti, "turkiye.json"), {"bolgeler": list(BOLGE_ILLERI), "iller": iller})
    b2 = _yaz(os.path.join(cikti, "merkezler.json"), {"merkezler": merkezler})
    return b1, b2


def uret(ham, cikti):
    os.makedirs(cikti, exist_ok=True)
    boyutlar = {"dunya.json": dunya_uret(ham, cikti), "cevre.json": cevre_uret(ham, cikti)}
    t, m = turkiye_uret(ham, cikti)
    boyutlar["turkiye.json"] = t
    boyutlar["merkezler.json"] = m
    return boyutlar


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--ham", default="_ham_veri")
    ap.add_argument("--cikti", default=os.path.join("os", "atlas"))
    a = ap.parse_args(argv)
    for ad, b in uret(a.ham, a.cikti).items():
        print("%-16s %7.1f KB" % (ad, b / 1024))
    return 0


if __name__ == "__main__":
    sys.exit(main())
