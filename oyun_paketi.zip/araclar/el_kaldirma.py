# -*- coding: utf-8 -*-
"""
Sessiz el kaldırma.

NEDEN VAR
---------
Sınıfta el kaldırmak bir itiraftır. "Anlamadım" demek otuz kişinin önünde
söylenir ve bedeli öğrenmenin kendisinden büyüktür; çoğu öğrenci bu yüzden
hiç sormaz. Öğretmen de neyin anlaşılmadığını ancak sınav kâğıdında, yani
iş işten geçtikten sonra görür.

Bu, o bedeli kaldırır: öğrenci telefonundan sessizce bildirir, öğretmen
"üç kişi bu soruda takıldı" diye görür ve soruyu tahtaya yazıp anlatır.
Sınıf kimin sormadığını göremez, çünkü BURADA KİMSENİN ADI YOK.

TASARIMIN SINIRLARI (bilerek konuldu)
-------------------------------------
1. **Gönüllü.** Oyun kendiliğinden bildirmez. Otomatik olsaydı öğrenci
   gözetlendiğini hissederdi ve bir daha zorlandığı yerde durmazdı --
   kaçmayı öğrenirdi. Bildiriyi öğrenci başlatır.

2. **İsim yok. Hiç.** Bu dosya öğrenci kimliği SAKLAMAZ; yalnızca soru
   başına SAYI tutar. Bu bir gizlilik ayarı değil, veri modelinin kendisi:
   isim olmadığı için sızdırılamaz. Öğretmenin ekranı tahtaya yansısa bile
   kimse açığa çıkmaz. Kimin nerede zorlandığını öğretmek isteyen zaten
   sınıf raporunda var; o ayrı bir iş ve ayrı kalmalı.
   - Sınıf raporu  : zaman içindeki başarı, isimli, öğretmene özel.
   - El kaldırma   : "şunu şimdi anlat" sinyali, isimsiz, canlı.
   İkisini birleştirmek el kaldırmayı bir nota dönüştürürdü ve öğrenci
   bir daha kullanmazdı.

3. **Aynı öğrenci sayıyı şişiremez.** Ama bunu sunucuda kimlik tutarak
   engellemiyoruz -- kimlik tutmak 2. maddeyi bozardı. Bunun yerine
   öğrencinin KENDİ kaydı hangi soruları bildirdiğini hatırlıyor ve ikinci
   kez göndermiyor (bkz. `zaten_bildirdi`). Kararlı bir öğrenci bunu
   aşabilir; aşarsa da eline "öğretmen o soruyu anlatır" geçer. Ödül
   zararsız olduğu için önlem hafif tutuldu.

4. **Akış tek yönlü.** Öğrenciden öğretmene gider, geri bir şey dönmez.
   Sohbet olsaydı mesajların denetlenmesi gerekirdi (bkz. B25.2) ve
   oyunun sorumluluğu tamamen değişirdi.

NEREDE DURUYOR -- İKİ YOL VAR
-----------------------------
1. **Dosya** (varsayılan): `kayitlar/el_kaldirma/<SINIF KODU>.json`.
   Öğretmenle öğrenciler aynı klasörü görüyorsa (okul kablosuzu,
   paylaşılan dizin) bu yeter ve hiçbir kurulum istemez.

2. **Sunucu**: `oyun.motor.ag.sunucu_ata(...)` çağrıldıysa bildiri ağa
   gider (`araclar/sinif_sunucusu.py`). Öğrenciler kendi hücresel
   verileriyle bağlanıyorsa ortak klasör diye bir şey yoktur; sınıfı
   birbirine bağlayan tek şey öğretmenin kodu ve o kodu tanıyan bir
   buluşma noktasıdır.

Hangisi olursa olsun tutulan veri aynı: soru ve sayı. Sunucu da isim
tutmuyor -- gizlilik sözü taşıyıcıya bağlı değil.
"""
from __future__ import annotations

import io
import json
import os
import time
from typing import Any, Dict, List, Optional

from oyun.motor import ag, durum as durum_modulu

# Bir sınıfta aynı anda kaç farklı soru bekleyebilir. Sınır var çünkü
# öğretmen otuz maddelik bir listeyle bir şey yapamaz; ders süresi kadar
# iş görünmeli. Dolduğunda en az sayıya sahip ve en eski olan düşer.
AZAMI_BEKLEYEN = 12


def klasor() -> str:
    return os.path.join(durum_modulu.KAYIT_KLASORU, "el_kaldirma")


def _yol(kod: str) -> str:
    return os.path.join(klasor(), (kod or "").upper() + ".json")


def _oku(kod: str) -> Dict[str, Any]:
    yol = _yol(kod)
    if not os.path.exists(yol):
        return {"kod": (kod or "").upper(), "bekleyen": {}, "anlatilan": []}
    try:
        with io.open(yol, encoding="utf-8") as d:
            veri = json.load(d)
    except (OSError, ValueError):
        # Bozuk dosya yüzünden ders durmasın; boş sayılır.
        return {"kod": (kod or "").upper(), "bekleyen": {}, "anlatilan": []}
    veri.setdefault("bekleyen", {})
    veri.setdefault("anlatilan", [])
    return veri


def _yaz(kod: str, veri: Dict[str, Any]) -> None:
    os.makedirs(klasor(), exist_ok=True)
    yol = _yol(kod)
    gecici = yol + ".tmp"
    with io.open(gecici, "w", encoding="utf-8") as d:
        json.dump(veri, d, ensure_ascii=False, indent=1)
    os.replace(gecici, yol)


def _kacir(deger: str) -> str:
    """Sınıf kodu ve anahtar adres satırına giriyor; kaçırılmadan olmaz."""
    from urllib.parse import quote
    return quote(str(deger or ""), safe="")


def anahtar_uret(konu: str, baslik: str) -> str:
    """Aynı soruyu bildiren öğrenciler aynı satırda toplansın diye.

    Görev kimliği kullanılmıyor: her öğrencinin görevi ayrı üretiliyor,
    sayılar farklı. Toplanması gereken şey KONU ve SORUNUN METNİ.
    """
    return "{}|{}".format((konu or "?").strip(), (baslik or "").strip())[:200]


def el_kaldir(kod: str, konu: str, baslik: str,
              zaman: Optional[float] = None) -> int:
    """Bir bildiri ekler, o sorunun yeni sayısını döndürür.

    Kod yoksa (öğrenci sınıfa bağlı değilse) hiçbir şey yapmaz, 0 döner.

    Sunucu tanımlıysa bildiri oraya gider. Sebep: öğrenciler kendi hücresel
    verileriyle bağlanıyorsa ortak bir klasör yoktur, birbirlerini
    göremezler. Sunucu yoksa dosyaya yazılır -- aynı ağdaki bir sınıfta
    (okul kablosuzu, paylaşılan dizin) o kadarı yeter.
    """
    if not (kod or "").strip():
        return 0
    if ag.acik_mi():
        yanit = ag.gonder("/el", {"kod": kod, "konu": konu, "baslik": baslik})
        # Ağ sessizce düşerse dosyaya YAZMIYORUZ: öğretmen sunucuya bakıyor,
        # oradaki dosyaya değil. Yazsaydık bildiri kimsenin bakmadığı bir
        # yerde birikirdi ve öğrenci "bildirdim" sanırdı.
        return 1 if (yanit or {}).get("tamam") else 0
    veri = _oku(kod)
    anahtar = anahtar_uret(konu, baslik)
    kayit = veri["bekleyen"].get(anahtar)
    if kayit is None:
        kayit = {"konu": konu, "baslik": baslik, "sayi": 0, "ilk": 0.0}
        veri["bekleyen"][anahtar] = kayit
    simdi = time.time() if zaman is None else zaman
    kayit["sayi"] = int(kayit.get("sayi", 0)) + 1
    kayit["son"] = simdi
    if not kayit.get("ilk"):
        kayit["ilk"] = simdi

    if len(veri["bekleyen"]) > AZAMI_BEKLEYEN:
        # Az sayılı ve eski olan düşer; çok kişinin takıldığı soru kalır.
        dusen = sorted(veri["bekleyen"].items(),
                       key=lambda ç: (ç[1].get("sayi", 0), ç[1].get("son", 0)))
        for a, _ in dusen[:len(veri["bekleyen"]) - AZAMI_BEKLEYEN]:
            if a != anahtar:
                veri["bekleyen"].pop(a, None)

    _yaz(kod, veri)
    return int(kayit["sayi"])


def bekleyenler(kod: str, anahtar: str = "") -> List[Dict[str, Any]]:
    """Öğretmenin göreceği liste: çok takılınan önce."""
    if ag.acik_mi():
        yanit = ag.gonder("/bekleyen?kod={}&anahtar={}".format(
            _kacir(kod), _kacir(anahtar)))
        return list((yanit or {}).get("bekleyen") or [])
    veri = _oku(kod)
    liste = []
    for anahtar, kayit in veri["bekleyen"].items():
        satir = dict(kayit)
        satir["anahtar"] = anahtar
        liste.append(satir)
    liste.sort(key=lambda s: (-int(s.get("sayi", 0)), -float(s.get("son", 0))))
    return liste


def anlatildi(kod: str, anahtar: str, ogretmen_anahtari: str = "") -> bool:
    """Öğretmen tahtada anlattı: satır listeden düşer.

    Silmek yerine geçmişe alınıyor; öğretmen dersin sonunda neyin
    anlatıldığını görebilsin diye. Geçmişte de isim yok.
    """
    if ag.acik_mi():
        yanit = ag.gonder("/anlatildi", {"kod": kod, "satir": anahtar,
                                         "anahtar": ogretmen_anahtari})
        return bool((yanit or {}).get("tamam"))
    veri = _oku(kod)
    kayit = veri["bekleyen"].pop(anahtar, None)
    if kayit is None:
        return False
    kayit["anlatildi"] = time.time()
    veri["anlatilan"].append(kayit)
    veri["anlatilan"] = veri["anlatilan"][-50:]
    _yaz(kod, veri)
    return True


def temizle(kod: str, ogretmen_anahtari: str = "") -> int:
    """Ders bitti: bekleyenleri sıfırla. Kaç satır silindiğini döndürür."""
    if ag.acik_mi():
        onceki = len(bekleyenler(kod, ogretmen_anahtari))
        yanit = ag.gonder("/temizle", {"kod": kod,
                                       "anahtar": ogretmen_anahtari})
        return onceki if (yanit or {}).get("tamam") else 0
    veri = _oku(kod)
    sayi = len(veri["bekleyen"])
    veri["bekleyen"] = {}
    _yaz(kod, veri)
    return sayi


# --- öğrenci tarafı: aynı soruyu iki kez bildirmemek için --------------

def zaten_bildirdi(durum, konu: str, baslik: str) -> bool:
    liste = getattr(durum, "bildirilen_sorular", None) or []
    return anahtar_uret(konu, baslik) in liste


def bildirildi_isaretle(durum, konu: str, baslik: str) -> None:
    liste = list(getattr(durum, "bildirilen_sorular", None) or [])
    anahtar = anahtar_uret(konu, baslik)
    if anahtar not in liste:
        liste.append(anahtar)
    # Kayıt dosyası şişmesin; eski bildiriler zaten anlamını yitirmiş olur.
    durum.bildirilen_sorular = liste[-60:]
