# -*- coding: utf-8 -*-
"""Bir dosyayla başlayan, isteğe bağlı kısa çalışma oturumu."""
from copy import deepcopy
import time

from . import ders_programi as dp, ilerleme, terminal as ekran
from .modeller import BIRLIKTE, SERBEST
from .oturum import Oturum

AZAMI_DOSYA = 3
HEDEF_DAKIKA = 10


def kisa_hedef(durum):
    """Önce programdaki konuyu koru; program yoksa hafif ağırlıklı keşif."""
    program = dp.ogrenci_programi(durum)
    satir, aciklama = dp.ders_odagi(program)
    if satir is not None:
        return program, satir, aciklama
    adaylar = []
    rastgele = durum.rastgele("kisa-oneri")
    for ders in durum.aktif_dersler():
        aday = {"ders": ders, "ad": dp.DERS_ADLARI[ders], "konular": []}
        b, _ = dp.odakli_teklifler(durum, program, aday, rastgele, 1)
        if b:
            konu = b[0].konu
            adaylar.append(dict(aday, konular=[konu]))
    if adaylar:
        return program, rastgele.choice(adaylar), "Küçük bir keşif"
    return program, None, "Bu düzeyde kısa çalışma bulunamadı."


def kisa_sefer(durum):
    try:
        program, satir, aciklama = kisa_hedef(durum)
    except (ValueError, OSError) as sorun:
        ekran.hata("Program açılamadı: {}".format(sorun))
        ekran.bekle()
        return 0
    if satir is None:
        ekran.bilgi(aciklama)
        ekran.bekle()
        return 0
    # Devam seçimlerinde odağı koru; ders değişirse sonraki kısa sefere bırak.
    ilk_program = deepcopy(program)
    ilk_ders = dp.ders_odagi(ilk_program)[0]
    ekran.baslik("KISA SEFER", "kalin", "acik_cam")
    ekran.yaz("Küçük hedef: bir dosya. 5–10 dakika ayırabilirsin; süre sınırı yok. "
              "Bir dosya bitince bırakabilir veya devam edebilirsin.", "gri")
    ekran.yaz("{} · {}".format(aciklama, satir["ad"]), "acik_cam")
    baslangic = time.monotonic()
    tamamlanan = 0
    while tamamlanan < AZAMI_DOSYA:
        try:
            guncel = dp.ogrenci_programi(durum)
            if guncel != ilk_program or dp.ders_odagi(guncel)[0] != ilk_ders:
                ekran.bilgi("Ders odağı değişti. Sonraki kısa sefer güncel dersten başlayacak.")
                break
            teklifler, uyari = dp.odakli_teklifler(
                durum, program, satir, durum.rastgele("kisa-{}".format(tamamlanan)), 1)
        except (ValueError, OSError) as sorun:
            ekran.hata("Çalışma hazırlanamadı: {}".format(sorun))
            break
        if uyari:
            ekran.yaz(uyari, "acik_sari")
        if not teklifler:
            break
        b = teklifler[0]
        satir = dict(satir, konular=[b.konu])
        kd = durum.ders(b.ders).konu(b.konu)
        asama = kd.asama
        ekran.yaz("DOSYA {} · {}".format(tamamlanan + 1, b.baslik), "kalin")
        if not ekran.onayla("Bu dosyayı açalım mı?", True):
            break
        # Tamamlanmamış denemenin kaynak/ilerleme etkisi bu kısa çalışmada
        # tutulmaz. Her tamamlanan dosya ise hemen kalıcı kayda girer.
        dikkat_once = durum.dikkat
        sonuc = Oturum(b, oyuncu_adi=durum.goruntu_adi, ipucu_acik=True,
                       asama=asama, durum=durum).oyna()
        if sonuc.birakildi or not sonuc.tamamlandi:
            durum.dikkat = dikkat_once
            ekran.bilgi("Burada durabiliriz. Tamamladığın dosyalar kaydedildi.")
            break
        for mesaj in ilerleme.sonucu_isle(durum, sonuc, getattr(b, "uretici_adi", "")):
            ekran.yaz(mesaj, "gri")
        # Bir bağımsız denemede yardım gerektiğinde sonraki dosyada hemen
        # birlikte çalışma öner; cezaya veya beklemeye dönüşmesin.
        yardim_gerekti = asama == SERBEST and any(
            not s.dogru or s.deneme > 1 or s.destek_aldi for s in sonuc.adim_sonuclari)
        if yardim_gerekti:
            kd.asama = BIRLIKTE
            ekran.yaz("Sonraki dosyaya birlikte bakabiliriz.", "acik_cam")
        tamamlanan += 1
        durum.gunluk_ekle("Kısa sefer: {} dosyası tamamlandı.".format(b.baslik))
        durum.kaydet()
        ekran.basari("Küçük hedef tamam: {} dosya kaydedildi.".format(tamamlanan))
        if tamamlanan >= AZAMI_DOSYA or time.monotonic() - baslangic >= HEDEF_DAKIKA * 60:
            break
        if ekran.menu("Şimdi ne yapmak istersin?", ["Bugünlük yeter", "Aynı konudan bir dosya daha"]) == 0:
            break
    ekran.yaz("Hazır olduğunda buradan devam edebilirsin.", "gri")
    ekran.bekle()
    return tamamlanan
