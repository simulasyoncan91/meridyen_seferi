# -*- coding: utf-8 -*-
"""
Pilot dersi seçimi (B46.1 kararı, 29 Eylül 2026): "pilot lise; ders
seçilmediyse otomatik oyuncu ve kapsam ölçümüne göre en hazır lise dersi
seçilir ve kullanıcıya bildirilir."

    python main.py --pilot-secimi

Sonuç ve gerekçe: `PILOT_DERS_SECIMI.md`.

"EN HAZIR" NE DEMEK (ölçmeden ÖNCE yazıldı, 30 Eylül 2026)
-----------------------------------------------------------
Pilot (B31.7) tek konu, küçük grup, birkaç kısa oturum. Bir dersin pilota
hazır olması dört KAPIYI geçmesi, geçenler arasında da beş ölçüde öne
çıkmasıdır.

KAPILAR (biri tutmazsa ders elenir):
  K1 oynanabilirlik  : otomatik oyuncu (B46.5a) bulgusu 0.
  K2 ölçme geçerliği : şık sızıntısı lisede düşük -- doğru şık tek başına en
                       uzun olma oranı <= %10 ve kalıp (tek eksiz + tek ekli)
                       <= %10. Sızdıran ders ölçtüğünü sandığını ölçmez.
  K3 genişlik        : >= 8 lise üreticisi. Birkaç oturum + ertesi hafta
                       tekrar, aynı görevi tekrar etmeden en az bu kadar ister.
  K4 öğretmen eşlemesi: MEB konu haritası var (öğretmen önizlemesi kazanımı
                       gösterebilsin; pilot sonucu programa bağlanabilsin).
Ortaokul ders adları (fen, türkçe) lisede ayrı derslerdir; aday olamazlar.

SIRALAMA (kapıyı geçenler; her ölçüde sıra numarası, toplamı en küçük kazanır):
  S1 duvar ortancası (lisedeki ilk kademede; düşük iyi) -- girişin yüksekliği
  S2 lise duvar listesinin ilk 20'sindeki görev sayısı (düşük iyi) --
     pilottan önce yumuşatılması gereken iş
  S3 öğretmen gözü bekleyen madde (OYUN_DURUMU.md; düşük iyi)
  S4 MEB lise kapsamı, 9-12. sınıf satırlarında "hazır" oranı (yüksek iyi)
  S5 lise üretici sayısı (yüksek iyi)
Eşitlikte duvar ortancası düşük olan önce gelir.

DUYARLILIK: ölçülerin ağırlığı elle seçildi; `yazdir` her ölçüyü tek tek
çıkarıp kazananı yeniden hesaplar. Seçim bir ölçünün düşmesiyle değişiyorsa
bu açıkça yazılır -- karar "tek doğru" değil, gerekçesi görünen bir tercihtir.

Ölçü bir SEÇİM aracıdır, dersin kalitesi hakkında hüküm değildir: fizik
sıralamada geride kalıyorsa kötü olduğu için değil, girişi daha yüksek ve
öğretmen gözü bekleyen maddesi daha çok olduğu içindir.
"""
from __future__ import annotations

import collections
import io
import os
import re
import statistics
import sys
from typing import Dict, List, Optional, Tuple

LISE = (9, 12)

# Ortaokul ders adları: lisede karşılıkları ayrı derslerdir (fen -> fizik,
# kimya, biyoloji; türkçe -> edebiyat). Oyunda 9. sınıfa uzanan birkaç
# üreticileri var ama lise pilotunun dersi olamazlar.
ORTAOKUL_DERSLERI = ("fen", "turkce")

# Öğretmen gözü bekleyen maddeler -- OYUN_DURUMU.md "Öğretmen gözü gereken
# şıklar" (25-26 Eylül gözden geçirmesi). Asıl kaynak o dosya: `ogretmen_gozu()`
# onu okur; bu sözlük yalnız dosya yoksa (dağıtılmış paket) kullanılır ve
# 30 Eylül 2026'daki hâlinin anlık görüntüsüdür.
OGRETMEN_GOZU = {
    "din_kulturu": ["ahlaki_kavram"],
    "cografya": ["sozlesme_dosyasi", "boylam_saati", "akinti_yonu"],
    "fen": ["madde_ayirma", "sinirlayici_etmen", "enerji_piramidi"],
    "kimya": ["gaz_tupu", "us_pili"],
    "biyoloji": ["dolasim_semasi"],
    "turkce": ["sozcukte_anlam"],
    "matematik": ["alan_kesfi"],
    "mantik": ["sayi_orgusu", "tartma_bulmacasi"],
    "bilisim": ["alt_ag_bolumu"],
    "tarih": ["kronolojik_siralama", "sanayi_onerisi", "yuzyil_hesabi"],
    "fizik": ["pompa_secimi", "atolye_tablasi", "yuk_arabasi", "olay_arsivi",
              "iki_deney", "ray_arabalari"],
    "felsefe": ["bilgi_felsefesi", "_DUSUNUR_ARGUMANLARI"],
    "edebiyat": ["siir_sesi", "konusma_provasi"],
}
OGRETMEN_GOZU_BOLUMU = "## Öğretmen gözü gereken"

KAPI_SIZINTI = 0.10
KAPI_URETICI = 8
DUVAR_ILK = 20
OLCU_ADLARI = {
    "S1": "duvar ortancası",
    "S2": "duvar ilk 20",
    "S3": "öğretmen gözü",
    "S4": "MEB lise kapsamı",
    "S5": "üretici sayısı",
}


def _durum_dosyasi() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "OYUN_DURUMU.md")


def ogretmen_gozu(yol: Optional[str] = None) -> Tuple[Dict[str, List[str]], List[str]]:
    """OYUN_DURUMU.md'deki öğretmen gözü maddeleri, ders başına.

    Madde = bölümde `ters tırnak` içinde geçen üretici (ya da `_VERI` tablosu)
    adı; ders, adın kayıt defterindeki üreticisinden (tablo için tanımlandığı
    modülden) bulunur. Dönüş: ({ders: [ad, ...]}, çözülemeyen adlar).
    Dosya ya da bölüm yoksa `OGRETMEN_GOZU` anlık görüntüsü döner.
    """
    yol = yol or _durum_dosyasi()
    try:
        metin = io.open(yol, encoding="utf-8").read()
    except OSError:
        return {d: list(a) for d, a in OGRETMEN_GOZU.items()}, []
    bolum, icinde = [], False
    for satir in metin.splitlines():
        if satir.startswith(OGRETMEN_GOZU_BOLUMU):
            icinde = True
            continue
        if icinde and satir.startswith("## "):
            break
        if icinde:
            bolum.append(satir)
    if not bolum:
        return {d: list(a) for d, a in OGRETMEN_GOZU.items()}, []

    from oyun.motor import kayit_defteri
    kayit_defteri.icerigi_yukle()
    ad_ders = collections.defaultdict(set)
    modul_ders = collections.defaultdict(set)
    for kayit in kayit_defteri.tum_kayitlar():
        ad_ders[kayit.fonksiyon.__name__].add(kayit.ders)
        modul_ders[kayit.fonksiyon.__module__].add(kayit.ders)

    sonuc: Dict[str, List[str]] = collections.defaultdict(list)
    cozulemeyen: List[str] = []
    for ad in re.findall(r"`([A-Za-z_][A-Za-z0-9_]*)`", "\n".join(bolum)):
        dersler = ad_ders.get(ad, set())
        if not dersler:
            for modul, ders_kumesi in modul_ders.items():
                if hasattr(sys.modules.get(modul), ad):
                    dersler = dersler | ders_kumesi
        if len(dersler) != 1:
            if ad not in cozulemeyen:
                cozulemeyen.append(ad)
            continue
        ders = next(iter(dersler))
        if ad not in sonuc[ders]:
            sonuc[ders].append(ad)
    return dict(sonuc), cozulemeyen


def meb_lise_kapsami(ders: str) -> Optional[Tuple[int, int]]:
    """(hazır satır, toplam satır) 9-12. sınıf için; harita yoksa None."""
    from oyun.motor import konu_haritasi as kh
    if not kh.tablo() or ders not in kh.dersler():
        return None
    hazir = toplam = 0
    for sinif in range(LISE[0], LISE[1] + 1):
        k = kh.kapsam(ders, sinif)
        hazir += len(k["hazir"])
        toplam += sum(len(v) for v in k.values())
    return (hazir, toplam) if toplam else None


def sinif_kapsami(ders: str) -> Dict[int, int]:
    """Dersin her lise sınıfında görünen üretici sayısı (pilot sınıfı için)."""
    from oyun.motor import kayit_defteri
    kayit_defteri.icerigi_yukle()
    sayac = collections.Counter()
    for kayit in kayit_defteri.tum_kayitlar():
        if kayit.ders != ders:
            continue
        alt, ust = kayit.kademeler
        for sinif in range(LISE[0], LISE[1] + 1):
            if alt <= sinif <= ust:
                sayac[sinif] += 1
    return {s: sayac.get(s, 0) for s in range(LISE[0], LISE[1] + 1)}


def olc(tohum_sayisi: Optional[int] = None) -> Dict[str, Dict]:
    """Ders başına ölçüleri toplar (duvar, sızıntı, otomatik oyuncu, MEB).

    `tohum_sayisi` None ise her araç kendi varsayılanını kullanır (`--duvar`,
    `--sizinti`, `--otomatik-oyuncu` çıktılarıyla aynı sayılar).
    """
    from araclar import duvar, otomatik_oyuncu, sizinti

    def tohum(varsayilan: int) -> int:
        return varsayilan if tohum_sayisi is None else tohum_sayisi

    satirlar: Dict[str, Dict] = collections.defaultdict(dict)
    duvar_satirlari = duvar.tarama(tohum_sayisi=tohum(duvar.TOHUM_SAYISI), aralik=LISE)
    ilk = collections.Counter(o["ders"] for o in duvar_satirlari[:DUVAR_ILK])
    puanlar = collections.defaultdict(list)
    for o in duvar_satirlari:
        puanlar[o["ders"]].append(o["puan"])
    for ders, liste in puanlar.items():
        satirlar[ders].update(duvar_ortanca=statistics.median(liste),
                              duvar_ilk20=ilk.get(ders, 0))

    siz = sizinti.tarama(tohum_sayisi=tohum(sizinti.TOHUM_SAYISI), aralik=LISE)
    toplam = collections.defaultdict(lambda: collections.Counter())
    for u in siz["ureticiler"]:
        t = toplam[u["ders"]]
        t["adim"] += u["adim"]
        t["en_uzun"] += u["oran"] * u["adim"]
        t["kalip"] += (u["tek_eksiz"] + u["tek_ekli"]) * u["adim"]
    for ders, t in toplam.items():
        satirlar[ders].update(sizinti_en_uzun=t["en_uzun"] / t["adim"],
                              sizinti_kalip=t["kalip"] / t["adim"])

    oyuncu = otomatik_oyuncu.ders_ozeti(otomatik_oyuncu.tarama(
        tohum_sayisi=tohum(otomatik_oyuncu.TOHUM_SAYISI)))
    for ders, o in oyuncu.items():
        satirlar[ders].update(uretici=o["uretici"], oyuncu_bulgu=o["bulgu"],
                              oynanis=o["oynanis"])

    gozu, _ = ogretmen_gozu()
    for ders in list(satirlar):
        satirlar[ders]["ogretmen_gozu"] = len(gozu.get(ders, []))
        satirlar[ders]["meb"] = meb_lise_kapsami(ders)
        satirlar[ders].setdefault("sizinti_en_uzun", 0.0)
        satirlar[ders].setdefault("sizinti_kalip", 0.0)
    return dict(satirlar)


def kapilar(s: Dict) -> List[str]:
    """Dersin geçemediği kapılar (boş liste = hepsini geçti)."""
    kalan = []
    if s.get("oyuncu_bulgu", 1) != 0:
        kalan.append("K1")
    if s["sizinti_en_uzun"] > KAPI_SIZINTI or s["sizinti_kalip"] > KAPI_SIZINTI:
        kalan.append("K2")
    if s.get("uretici", 0) < KAPI_URETICI:
        kalan.append("K3")
    if s.get("meb") is None:
        kalan.append("K4")
    return kalan


def _meb_orani(s: Dict) -> float:
    return s["meb"][0] / s["meb"][1] if s.get("meb") else 0.0


OLCULER = {
    "S1": (lambda s: s["duvar_ortanca"], False),
    "S2": (lambda s: s["duvar_ilk20"], False),
    "S3": (lambda s: s["ogretmen_gozu"], False),
    "S4": (_meb_orani, True),
    "S5": (lambda s: s["uretici"], True),
}


def sirala(satirlar: Dict[str, Dict], haric: Tuple[str, ...] = ()
           ) -> List[Tuple[str, int, Dict[str, int]]]:
    """Kapıyı geçen lise dersleri, (ders, sıra toplamı, ölçü sıraları) listesi.

    Sıra "yarışma sırası": eşit değerler aynı sırayı alır (1, 1, 3).
    `haric` verilen ölçüler toplama girmez (duyarlılık denemesi).
    """
    adaylar = [d for d, s in satirlar.items()
               if d not in ORTAOKUL_DERSLERI and not kapilar(s)]
    siralar: Dict[str, Dict[str, int]] = {d: {} for d in adaylar}
    for ad, (deger, buyuk_iyi) in OLCULER.items():
        if ad in haric:
            continue
        for d in adaylar:
            v = deger(satirlar[d])
            daha_iyi = sum(1 for e in adaylar
                           if (deger(satirlar[e]) > v if buyuk_iyi
                               else deger(satirlar[e]) < v))
            siralar[d][ad] = 1 + daha_iyi
    sonuc = [(d, sum(siralar[d].values()), siralar[d]) for d in adaylar]
    sonuc.sort(key=lambda x: (x[1], satirlar[x[0]]["duvar_ortanca"]))
    return sonuc


def duyarlilik(satirlar: Dict[str, Dict]) -> Dict[str, str]:
    """Her ölçü tek tek çıkarılınca kazanan ders ({ölçü: ders})."""
    sonuc = {}
    for ad in OLCULER:
        sira = sirala(satirlar, haric=(ad,))
        sonuc[ad] = sira[0][0] if sira else ""
    return sonuc


def yazdir(tohum_sayisi: Optional[int] = None) -> int:
    satirlar = olc(tohum_sayisi)
    sira = sirala(satirlar)
    print("PİLOT DERSİ SEÇİMİ (9-12. sınıf) -- ölçüt: araclar/pilot_secimi.py")
    print()
    print("{:<12}{:>5}{:>8}{:>6}{:>7}{:>7}{:>6}{:>6}{:>11}  {}".format(
        "ders", "üret", "duvar", "ilk20", "uzun%", "kalıp%", "oyun", "öğrt",
        "MEB lise", "kapı"))
    for ders in sorted(satirlar, key=lambda d: -satirlar[d].get("uretici", 0)):
        s = satirlar[ders]
        meb = "{}/{}".format(*s["meb"]) if s.get("meb") else "harita yok"
        kapi = "ortaokul dersi" if ders in ORTAOKUL_DERSLERI else (
            ",".join(kapilar(s)) or "geçti")
        print("{:<12}{:>5}{:>8.1f}{:>6}{:>7.1f}{:>7.1f}{:>6}{:>6}{:>11}  {}".format(
            ders, s.get("uretici", 0), s.get("duvar_ortanca", 0.0),
            s.get("duvar_ilk20", 0), 100 * s["sizinti_en_uzun"],
            100 * s["sizinti_kalip"], s.get("oyuncu_bulgu", "-"),
            s["ogretmen_gozu"], meb, kapi))
    _, cozulemeyen = ogretmen_gozu()
    if cozulemeyen:
        print("UYARI: OYUN_DURUMU.md öğretmen gözü bölümünde derse bağlanamayan "
              "ad(lar): {}".format(", ".join(cozulemeyen)))
    print()
    print("SIRALAMA (kapıyı geçenler; sıra toplamı küçük olan önde)")
    for d, toplam, ayri in sira:
        print("  {:<12} {:>3}   {}".format(
            d, toplam, "  ".join("{} {}".format(k, v) for k, v in ayri.items())))
    if not sira:
        print("  kapıyı geçen ders yok")
        return 0
    secilen = sira[0][0]
    print()
    print("DUYARLILIK (bir ölçü çıkarılınca kazanan)")
    for ad, kazanan in duyarlilik(satirlar).items():
        print("  {} ({}) olmadan: {}{}".format(
            ad, OLCU_ADLARI[ad], kazanan, "" if kazanan == secilen else "  <-- DEĞİŞİYOR"))
    print()
    print("SEÇİLEN: {}".format(secilen))
    print("  sınıf başına üretici: {}".format(", ".join(
        "{}. sınıf {}".format(s, n) for s, n in sinif_kapsami(secilen).items())))
    return 0
