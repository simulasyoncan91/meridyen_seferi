# -*- coding: utf-8 -*-
"""
Elektrik-Elektronik görevleri.

Bu modülün görevlerinin çoğu "güç, iş ve verim" çekirdeğine bağlıdır
(`etiketler=("guc_verim",)`). Aynı çekirdek makine, motorlu araçlar ve tesisat
dallarında da işler; ittifak eşleştirmesi bu etiketten çalışacak.
Ayrıntı: TASARIM_NOTLARI.md

Kademe ölçeği: 1-4 ilkokul, 5-8 ortaokul, 9-12 lise, 13 üniversite.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi,
    sy, yorum_adimi,
)

SEBEKE_GERILIMI = 220


# ==========================================================================
# GÜÇ HESABI
# ==========================================================================

@bulmaca(ders="elektrik", konu="guc_hesabi", kademeler=(9, 12),
         etiketler=("guc_verim",), agirlik=1.2)
def jenerator_yuku(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Paralel yüklerin toplam gücü.

    Yaygın karışıklık: paralel bağlantıda GERİLİM ortaktır, akımlar toplanır.
    Öğrenci ikisini ters çevirdiğinde sayı büyür ve jeneratör yetiyor sanılır.
    """
    akimlar = rastgele.sample([4, 5, 6, 8, 9, 10], 3)
    toplam_akim = sum(akimlar)
    toplam_guc = SEBEKE_GERILIMI * toplam_akim          # W
    # Jeneratör bazen yeter bazen yetmez: ikisi de olsun ki cevap ezber olmasın.
    jenerator_kw = rastgele.choice([3, 4, 5, 6])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    adlar = ["su pompası", "aydınlatma hattı", "atölye tezgâhı"]

    return Bulmaca(
        kod="elk-jenerator-yuku",
        ders="elektrik",
        baslik="Gece Yükü",
        kademe=kademe,
        konu="guc_hesabi",
        kazanim="Paralel bağlı yüklerde ortak gerilim ve toplam akım; "
                "P = V × I ile toplam güç.",
        dikkat=6,
        brifing=(
            "Üssün geceleri jeneratörle beslenen bir hattı var. Bu gece hatta "
            "üç şey birden bağlı: {}.\n\n"
            "{} her birinin ampermetre değerini ayrı ayrı okumuş ama toplam "
            "yükü hesaplamamış. Jeneratörün etiketinde \"{} kW\" yazıyor.\n\n"
            "Nöbetçi jeneratörü çalıştırmadan önce sormaya geldi: bu yükü "
            "kaldırır mı?"
        ).format(", ".join(adlar), kisi, jenerator_kw),
        kanitlar=[
            Kanit("Ampermetre okumaları",
                  "{}: {} A\n{}: {} A\n{}: {} A".format(
                      adlar[0], akimlar[0], adlar[1], akimlar[1],
                      adlar[2], akimlar[2]),
                  bedel=1, kritik=True),
            Kanit("Hat etiketi",
                  "Hat gerilimi: {} V. Üç cihaz da AYNI hatta, birbirine "
                  "paralel bağlı.".format(SEBEKE_GERILIMI),
                  bedel=1, kritik=True),
            Kanit("Jeneratör plakası",
                  "Sürekli verebileceği güç: {} kW.".format(jenerator_kw),
                  bedel=1, kritik=True),
            Kanit("Ustanın notu",
                  "\"Paralel bağlantıda gerilim hepsinde aynıdır; değişen "
                  "akımdır. Gerilimleri toplayan bir hesap baştan yanlıştır.\"",
                  bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="Hattın toplam gücünü hangi yol verir?",
                dogru=("Akımları toplarız, ortak gerilimle çarparız; çünkü üç "
                       "cihaz da aynı gerilimi paylaşıyor."),
                yanlislar={
                    "Gerilimleri toplayıp toplam akımla çarparız.":
                        "Paralel bağlantıda gerilim toplanmaz, hepsinde "
                        "aynıdır. Gerilimi üç kez saymak gücü üç katına "
                        "çıkarır ve jeneratör yetmiyor sanılır.",
                    "Toplam akımı gerilime böleriz.":
                        "Akımı gerilime bölmek güç vermez. Bu bölme sana "
                        "direnç hakkında bir şey söyler; aradığın büyüklük o "
                        "değil.",
                    "En büyük yükü alıp jeneratör ona yetiyorsa yeter deriz.":
                        "Cihazlar sırayla değil, aynı anda çalışıyor. "
                        "Jeneratörün karşılaması gereken şey en büyük yük "
                        "değil, hepsinin toplamı.",
                    "Akımların ortalamasını alıp gerilimle çarparız.":
                        "Ortalama, üç cihazın birlikte çektiği akımı değil, "
                        "tek bir cihazın ortalamasını verir. Hat üçünü birden "
                        "besliyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Paralel bağlantıda gerilim ortaktır, akımlar toplanır. "
                    "Toplam akım {} A, gerilim {} V; güç = {} × {} = {} W "
                    "= {} kW.".format(
                        toplam_akim, SEBEKE_GERILIMI, SEBEKE_GERILIMI,
                        toplam_akim, toplam_guc, sy(toplam_guc / 1000.0))),
                ipuclari=[
                    "Üç cihaz da aynı hatta. Hangisi hepsinde aynı: gerilim "
                    "mi, akım mı?",
                    "Ortak olanı bir kez al, değişeni topla.",
                ],
                cozum=(
                    "1) Akımlar: {} + {} + {} = {} A\n"
                    "2) Güç = gerilim × toplam akım = {} × {} = {} W\n"
                    "3) {} W = {} kW".format(
                        akimlar[0], akimlar[1], akimlar[2], toplam_akim,
                        SEBEKE_GERILIMI, toplam_akim, toplam_guc,
                        toplam_guc, sy(toplam_guc / 1000.0))),
            ),
            sayi_adimi(
                soru="Hattın çektiği toplam güç kaç watt?",
                cevap=toplam_guc,
                birim="W",
                aciklama="{} × {} = {} W".format(
                    SEBEKE_GERILIMI, toplam_akim, toplam_guc),
                yaygin_yanlislar={
                    toplam_akim:
                        "Akımı yazdın, gücü değil. Amper ile watt farklı "
                        "büyüklükler; akımı gerilimle çarpman gerekiyor.",
                    SEBEKE_GERILIMI * max(akimlar):
                        "Yalnızca en büyük yükü hesapladın. Üç cihaz da aynı "
                        "anda çalışıyor.",
                    3 * SEBEKE_GERILIMI * toplam_akim:
                        "Gerilimi üç kez saymışsın. Paralel bağlantıda gerilim "
                        "ortaktır, cihaz sayısıyla çarpılmaz.",
                },
                ipuclari=["Önce üç ampermetre değerini topla."],
                puan=14,
            ),
            yorum_adimi(
                soru="Jeneratör bu yükü kaldırır mı?",
                dogru=("Kaldırır." if toplam_guc <= jenerator_kw * 1000
                       else "Kaldırmaz; bir cihazı sonraya bırakmak gerekir."),
                yanlislar={
                    ("Kaldırmaz; bir cihazı sonraya bırakmak gerekir."
                     if toplam_guc <= jenerator_kw * 1000 else "Kaldırır."):
                        ("Karşılaştırmayı ters kurdun: hat {} kW çekiyor, "
                         "jeneratör {} kW verebiliyor.".format(
                             sy(toplam_guc / 1000.0), jenerator_kw)),
                    "Kaldırır; jeneratörler etiketinin iki katını verebilir.":
                        "Plakadaki değer sürekli verebileceği güçtür, aşılırsa "
                        "jeneratör ısınır ve korumaya geçer.",
                    "Anlaşılmaz; ampermetre değerleri watt cinsinden değil.":
                        "Ampermetre akımı ölçer, gerilimi zaten biliyoruz; "
                        "ikisi birlikte gücü verir.",
                },
                rastgele=rastgele,
                aciklama="Hat {} kW, jeneratör {} kW: {}".format(
                    sy(toplam_guc / 1000.0), jenerator_kw,
                    "yeter." if toplam_guc <= jenerator_kw * 1000
                    else "yetmez."),
            ),
        ],
        kapanis=("Nöbetçi ampermetre değerlerini bakım defterine de yazdı; "
                 "bir dahaki gece hesap baştan yapılmayacak."),
        odul={"enerji": 3, "itibar": 2},
    )


# ==========================================================================
# GÜÇ MÜ, ENERJİ Mİ
# ==========================================================================

@bulmaca(ders="elektrik", konu="enerji_mi_guc_mu", kademeler=(9, 12),
         etiketler=("birim_cevirme",), agirlik=1.2)
def isitici_faturasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    kW ile kWh karışıklığı - sahanın en yaygın birim hatası.

    Güç bir hızdır, enerji ise o hızda geçirilen sürenin sonucudur. İkisini
    ayırt edemeyen öğrenci ısıtıcının gücünü doğrudan faturaya yazar.
    """
    guc_kw = rastgele.choice([1.5, 2.0, 2.5, 3.0])
    saat = rastgele.choice([4, 5, 6, 8])
    gun = rastgele.choice([10, 15, 20])
    gunluk_enerji = guc_kw * saat                       # kWh
    toplam_enerji = gunluk_enerji * gun                 # kWh
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="elk-isitici-faturasi",
        ders="elektrik",
        baslik="Kışlık Hesap",
        kademe=kademe,
        konu="enerji_mi_guc_mu",
        kazanim="Güç (kW) ile enerji (kWh) ayrımı; enerji = güç × süre.",
        dikkat=5,
        brifing=(
            "Revirin ısıtıcısı {} gündür çalışıyor. Etiketinde \"{} kW\" "
            "yazıyor.\n\n"
            "{} nöbet defterine her gün kaç saat çalıştığını yazmış: her gün "
            "{} saat.\n\n"
            "Komutan üssün enerji tüketimini çıkarıyor ve şunu soruyor: bu "
            "ısıtıcı toplam ne kadar enerji harcadı? Etiketteki sayı bu "
            "sorunun cevabı değil."
        ).format(gun, sy(guc_kw), kisi, saat),
        kanitlar=[
            Kanit("Isıtıcı etiketi",
                  "Güç: {} kW. Bu, çalıştığı HER AN çektiği güçtür.".format(
                      sy(guc_kw)),
                  bedel=1, kritik=True),
            Kanit("Nöbet defteri",
                  "Isıtıcı {} gün boyunca, günde {} saat çalıştırıldı.".format(
                      gun, saat),
                  bedel=1, kritik=True),
            Kanit("Sayaç kılavuzu",
                  "\"Sayaç kilovatsaat (kWh) sayar. 1 kWh, 1 kW gücün 1 saat "
                  "boyunca harcadığı enerjidir.\"",
                  bedel=2, kritik=True),
            Kanit("Depo notu",
                  "Revirde ayrıca bir gaz lambası da var; elektrik "
                  "harcamıyor.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Harcanan enerjiyi hangi bağıntı verir?",
                dogru="Gücü, çalıştığı toplam süreyle çarparız.",
                yanlislar={
                    "Etiketteki gücü doğrudan harcanan enerji olarak yazarız.":
                        "Güç ile enerjiyi karıştırdın. Güç bir hızdır: her an "
                        "ne kadar çektiğini söyler. Ne kadar harcandığını "
                        "bulmak için süreyle çarpman gerekir.",
                    "Gücü çalışma süresine böleriz.":
                        "Bölme burada küçülen bir sayı verir; oysa ısıtıcı ne "
                        "kadar uzun çalışırsa o kadar ÇOK enerji harcar.",
                    "Gücü ve süreyi toplarız.":
                        "Farklı birimler toplanmaz. Kilovat ile saati "
                        "toplamak, kilo ile metreyi toplamak gibidir.",
                    "Günlük süreyi gün sayısına böleriz.":
                        "Bu, günde kaç saat çalıştığını geri verir; zaten "
                        "elimizde olan bilgi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Enerji = güç × süre. Toplam süre {} × {} = {} saat; "
                    "{} kW × {} saat = {} kWh.".format(
                        gun, saat, gun * saat, sy(guc_kw), gun * saat,
                        sy(toplam_enerji))),
                ipuclari=[
                    "Etiketteki sayı \"her an\" ne kadar çektiğini söylüyor. "
                    "Toplamı bulmak için başka neye ihtiyacın var?",
                    "Sayaç kilovat değil, kilovatSAAT sayıyor.",
                ],
                cozum=(
                    "1) Toplam süre = {} gün × {} saat = {} saat\n"
                    "2) Enerji = {} kW × {} saat = {} kWh".format(
                        gun, saat, gun * saat, sy(guc_kw), gun * saat,
                        sy(toplam_enerji))),
            ),
            sayi_adimi(
                soru="Isıtıcı toplam kaç kWh enerji harcadı?",
                cevap=toplam_enerji,
                birim="kWh",
                aciklama="{} kW × {} saat = {} kWh".format(
                    sy(guc_kw), gun * saat, sy(toplam_enerji)),
                yaygin_yanlislar={
                    guc_kw:
                        "Etiketteki gücü yazdın. O, ısıtıcının her an çektiği "
                        "güç; toplam harcama değil.",
                    gunluk_enerji:
                        "Yalnızca BİR günün enerjisini buldun. Isıtıcı {} gün "
                        "çalıştı.".format(gun),
                    gun * saat:
                        "Toplam süreyi yazdın. Süre saat cinsinden; enerji "
                        "için onu güçle çarpman gerekiyor.",
                },
                ipuclari=["Önce toplam kaç saat çalıştığını bul."],
                puan=14,
            ),
            yorum_adimi(
                soru="Fatura hangisine göre gelir?",
                dogru="Harcanan enerjiye (kWh) göre.",
                yanlislar={
                    "Cihazın gücüne (kW) göre.":
                        "Güç, cihazın kaç saat çalıştığını bilmez. İki gün "
                        "çalışan ısıtıcı ile iki ay çalışan aynı faturayı "
                        "getirmezdi.",
                    "Cihaz sayısına göre.":
                        "Sayaç cihazları saymaz, geçen enerjiyi ölçer.",
                    "Çalışma süresine göre.":
                        "Süre tek başına yetmez: aynı süre boyunca çalışan "
                        "küçük bir lamba ile büyük bir ısıtıcı aynı enerjiyi "
                        "harcamaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sayaç kWh sayar; yani hem gücü hem süreyi birlikte "
                    "hesaba katan büyüklüğü."),
            ),
        ],
        kapanis=("Komutan deftere tek satır yazdırdı: \"Etikette kW yazar, "
                 "faturada kWh gelir. İkisi aynı şey değil.\""),
        odul={"enerji": 2, "itibar": 3},
    )


# ==========================================================================
# SİGORTA SEÇİMİ
# ==========================================================================

STANDART_SIGORTALAR = [6, 10, 16, 20, 25, 32, 40]


@bulmaca(ders="elektrik", konu="sigorta_secimi", kademeler=(9, 12),
         etiketler=("sira_prosedur",))
def sigorta_secimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Sigorta seçimi bir sıralama işidir: önce akım, sonra emniyet payı, sonra
    standart değerlerden ÜSTTEKİ en yakını.

    İki yönlü hata var: küçük seçmek (hat sürekli atar), büyük seçmek (kablo
    ısınır, sigorta koruma görevini yapmaz). İkincisi tehlikeli olandır.
    """
    akim = rastgele.choice([12, 14, 18, 22])
    guc = SEBEKE_GERILIMI * akim                       # W
    emniyetli = akim * 1.25
    secilen = min(s for s in STANDART_SIGORTALAR if s > emniyetli)
    altindaki = max(s for s in STANDART_SIGORTALAR if s < emniyetli)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="elk-sigorta-secimi",
        ders="elektrik",
        baslik="Atan Hat",
        kademe=kademe,
        konu="sigorta_secimi",
        kazanim="Hat akımının hesabı; emniyet payı; standart sigorta "
                "değerinden doğru olanı seçme.",
        dikkat=6,
        brifing=(
            "{} mevkiindeki atölyeye yeni bir hat çekiliyor. Hattın "
            "besleyeceği tezgâhların toplam gücü {} W, hat gerilimi {} V.\n\n"
            "Depoda hazır sigortalar var: {} amperlik. Usta \"büyüğünü tak, "
            "hiç atmaz\" diyor.\n\n"
            "Panoyu kapatmadan önce hangisinin takılacağına karar vermen "
            "gerekiyor. Yanlış seçim iki yönlü de sorun çıkarır."
        ).format(mevki, guc, SEBEKE_GERILIMI,
                 ", ".join(str(s) for s in STANDART_SIGORTALAR)),
        kanitlar=[
            Kanit("Hat bilgisi",
                  "Toplam güç: {} W. Gerilim: {} V.".format(
                      guc, SEBEKE_GERILIMI),
                  bedel=1, kritik=True),
            Kanit("Yönetmelik maddesi",
                  "\"Sigorta, hattın sürekli akımının en az 1,25 katını "
                  "taşımalı; bu değerin ÜSTÜNDEKİ en küçük standart değer "
                  "seçilir.\"",
                  bedel=2, kritik=True),
            Kanit("Kablo etiketi",
                  "Bu kesitteki kablo en çok {} A taşır; üstünde ısınır."
                  .format(secilen), bedel=2, kritik=True),
            Kanit("Depo listesi",
                  "Hazır sigortalar: {} A.".format(
                      ", ".join(str(s) for s in STANDART_SIGORTALAR)),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Sigorta seçimi hangi sırayla yapılır?",
                dogru=("Önce hattın akımını buluruz, emniyet payını ekleriz, "
                       "sonra bu değerin üstündeki en küçük standart sigortayı "
                       "seçeriz."),
                yanlislar={
                    "Depodaki en büyük sigortayı takarız, böylece hiç atmaz.":
                        "Sigortanın işi atmaktır. Kablonun taşıyabileceğinden "
                        "büyük sigorta, aşırı yükte kabloyu korumaz; kablo "
                        "sigortadan önce ısınır.",
                    "Hesaplanan akımın altındaki en yakın sigortayı seçeriz.":
                        "Küçük sigorta normal çalışmada bile atar. Hat sürekli "
                        "kesilir ve bir süre sonra sigorta köprülenir - asıl "
                        "tehlike oradan çıkar.",
                    "Gücü doğrudan sigorta değeri olarak alırız.":
                        "Güç watt, sigorta amper cinsindendir. Önce gücü "
                        "gerilime bölüp akıma çevirmen gerekir.",
                    "Kablo kesitine bakmadan tezgâh sayısına göre seçeriz.":
                        "Tezgâh sayısı değil, çektikleri toplam akım "
                        "belirleyicidir; iki küçük tezgâh bir büyükten az "
                        "çekebilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Akım = güç ÷ gerilim = {} ÷ {} = {} A. Emniyet payıyla "
                    "{} × 1,25 = {} A. Standart değerlerden bunun üstündeki "
                    "en küçüğü: {} A.".format(
                        guc, SEBEKE_GERILIMI, akim, akim, sy(emniyetli),
                        secilen)),
                ipuclari=[
                    "Sigorta amper cinsinden. Elindeki güç watt cinsinden.",
                    "Yönetmelik \"üstündeki en küçük standart değer\" diyor.",
                ],
                cozum=(
                    "1) Akım = {} ÷ {} = {} A\n"
                    "2) Emniyet payı = {} × 1,25 = {} A\n"
                    "3) {} A'nin üstündeki en küçük standart: {} A".format(
                        guc, SEBEKE_GERILIMI, akim, akim, sy(emniyetli),
                        sy(emniyetli), secilen)),
            ),
            sayi_adimi(
                soru="Hattın sürekli akımı kaç amper?",
                cevap=akim,
                birim="A",
                aciklama="{} ÷ {} = {} A".format(guc, SEBEKE_GERILIMI, akim),
                yaygin_yanlislar={
                    guc * SEBEKE_GERILIMI:
                        "Bölmen gerekirken çarpmışsın. Akım = güç ÷ gerilim.",
                    SEBEKE_GERILIMI / float(akim):
                        "Bölmeyi ters kurdun: gerilimi güce değil, gücü "
                        "gerilime böleceksin.",
                },
                ipuclari=["Güç = gerilim × akım bağıntısını akım için çöz."],
                puan=12,
            ),
            secim_adimi(
                soru="Hangi sigorta takılmalı?",
                dogru="{} A".format(secilen),
                yanlislar={
                    "{} A".format(altindaki):
                        "Bu değer emniyet payının altında kalıyor; hat normal "
                        "çalışmada bile atar.",
                    "{} A".format(STANDART_SIGORTALAR[-1]):
                        "Bu, kablonun taşıyabileceğinden büyük. Aşırı yükte "
                        "kablo yanar ama sigorta atmaz - korumasız hat demek.",
                    "{} A".format(STANDART_SIGORTALAR[0]):
                        "Çok küçük: hattın normal akımını bile taşımaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{} A emniyetli akımın üstündeki en küçük standart "
                    "değer, aynı zamanda kablonun taşıyabileceği sınır."
                    .format(secilen)),
                puan=14,
            ),
            yorum_adimi(
                soru="Ustanın dediği gibi en büyük sigorta takılsaydı ne olurdu?",
                dogru=("Aşırı yükte kablo ısınırdı ama sigorta atmazdı; "
                       "koruma ortadan kalkardı."),
                yanlislar={
                    "Hiçbir şey; sadece daha az arıza olurdu.":
                        "Sigortanın atmaması iyi bir şey değil. Atmıyorsa "
                        "hattı koruyan bir şey kalmamış demektir.",
                    "Sigorta daha çabuk yanardı.":
                        "Büyük sigorta daha geç atar, daha çabuk değil.",
                    "Tezgâhlar daha güçlü çalışırdı.":
                        "Sigorta cihazlara güç vermez, yalnızca aşırı akımda "
                        "hattı keser.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sigorta cihazı değil KABLOYU korur. Kablodan büyük "
                    "seçilen sigorta, koruması gereken şeyin yanmasına "
                    "seyirci kalır."),
            ),
        ],
        kapanis=("Panoya {} A takıldı. Usta homurdandı ama kablo etiketini "
                 "görünce sesini kesti.".format(secilen)),
        odul={"cevher": 2, "itibar": 3},
    )


# ==========================================================================
# VERİM VE KAYIP
# ==========================================================================

# (verim, mil gücü kW, şebekeden çekilen kW) - üçü de tam çıksın diye
# hazır seçilmiş üçlüler.
VERIM_UCLULERI = [
    (0.75, 3.0, 4.0),
    (0.75, 6.0, 8.0),
    (0.80, 4.0, 5.0),
    (0.80, 8.0, 10.0),
    (0.90, 9.0, 10.0),
    (0.90, 18.0, 20.0),
]


@bulmaca(ders="elektrik", konu="verim_ve_kayip", kademeler=(10, 13),
         etiketler=("guc_verim",))
def motor_verimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Verim = çıkan ÷ giren. Ters çevrilirse 1'den büyük çıkar; bu imkânsızdır
    ve öğrencinin kendi kendine yakalayabileceği bir kontroldür.
    """
    verim, mil_kw, cekilen_kw = rastgele.choice(VERIM_UCLULERI)
    kayip_kw = cekilen_kw - mil_kw
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="elk-motor-verimi",
        ders="elektrik",
        baslik="Isınan Motor",
        kademe=kademe,
        konu="verim_ve_kayip",
        kazanim="Verim = çıkan güç ÷ giren güç; kayıp gücün nereye gittiği.",
        dikkat=6,
        brifing=(
            "Su pompasının motoru elle tutulamayacak kadar ısınıyor. Arıza "
            "yok, pompa çalışıyor; ama {} \"bu ısı nereden geliyor\" diye "
            "soruyor.\n\n"
            "Elektrik panosundaki ölçüm, motorun şebekeden {} kW çektiğini "
            "gösteriyor. Makine dairesindeki ölçüm ise milden pompaya {} kW "
            "geçtiğini söylüyor.\n\n"
            "İki sayı tutmuyor. Komutan aradaki farkın nereye gittiğini "
            "öğrenmek istiyor."
        ).format(kisi, sy(cekilen_kw), sy(mil_kw)),
        kanitlar=[
            Kanit("Pano ölçümü",
                  "Motorun şebekeden çektiği güç: {} kW.".format(sy(cekilen_kw)),
                  bedel=1, kritik=True),
            Kanit("Mil ölçümü",
                  "Motorun mile verdiği güç: {} kW.".format(sy(mil_kw)),
                  bedel=1, kritik=True),
            Kanit("Motor kılavuzu",
                  "\"Verim, çıkan gücün girene oranıdır. Hiçbir motorda "
                  "verim 1'i (yani %100'ü) geçemez.\"",
                  bedel=2, kritik=True),
            Kanit("Bakım kaydı",
                  "Yataklar geçen ay yağlandı, kayış gergin. Mekanik bir "
                  "sorun bulunamadı.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Motorun verimini hangi bağıntı verir?",
                dogru="Mile verilen gücü, şebekeden çekilen güce böleriz.",
                yanlislar={
                    "Şebekeden çekilen gücü, mile verilen güce böleriz.":
                        "Bölmeyi ters kurdun. Bu bölme 1'den büyük bir sayı "
                        "verir; yani motor aldığından fazlasını veriyor olurdu. "
                        "Kendi sonucun sana yanlış olduğunu söylüyor.",
                    "İki gücü toplayıp ikiye böleriz.":
                        "Ortalama, iki ölçümün ortasını verir. Verim bir "
                        "ortalama değil, çıkanın girene ORANIdır.",
                    "İki güç arasındaki farkı alırız.":
                        "Fark sana kaybı verir - o da işe yarar ama verim "
                        "değildir. Verim bir orandır, bir güç değil.",
                    "Mile verilen gücü aradaki farka böleriz.":
                        "Payda yanlış. Verim, çıkanın GİRENE oranıdır; "
                        "kayba değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Verim = çıkan ÷ giren = {} ÷ {} = {} yani %{}. "
                    "Aradaki {} kW ısıya dönüşüyor; motorun ısınmasının "
                    "sebebi bu.".format(
                        sy(mil_kw), sy(cekilen_kw), sy(verim),
                        int(round(verim * 100)), sy(kayip_kw))),
                ipuclari=[
                    "Hangisi giren, hangisi çıkan? Elektrik hangi taraftan "
                    "giriyor?",
                    "Sonucun 1'den büyük çıkıyorsa bölmeyi ters kurmuşsundur.",
                ],
                cozum=(
                    "1) Kayıp = {} - {} = {} kW\n"
                    "2) Verim = {} ÷ {} = {} = %{}".format(
                        sy(cekilen_kw), sy(mil_kw), sy(kayip_kw),
                        sy(mil_kw), sy(cekilen_kw), sy(verim),
                        int(round(verim * 100)))),
            ),
            sayi_adimi(
                soru="Motorun verimi yüzde kaç?",
                cevap=round(verim * 100),
                birim="%",
                aciklama="{} ÷ {} = {} → %{}".format(
                    sy(mil_kw), sy(cekilen_kw), sy(verim),
                    int(round(verim * 100))),
                yaygin_yanlislar={
                    round(cekilen_kw / mil_kw * 100):
                        "Bölmeyi ters kurdun; %100'ü geçen bir verim çıktı. "
                        "Hiçbir motor aldığından fazlasını veremez.",
                    round(kayip_kw / cekilen_kw * 100):
                        "Bu, kayıp oranı. Verim ise kaybın değil, işe "
                        "dönüşen kısmın oranıdır.",
                },
                ipuclari=["Çıkan gücü girene böl, sonra 100 ile çarp."],
                puan=14,
            ),
            sayi_adimi(
                soru="Isıya dönüşen güç kaç kW?",
                cevap=kayip_kw,
                birim="kW",
                aciklama="{} - {} = {} kW".format(
                    sy(cekilen_kw), sy(mil_kw), sy(kayip_kw)),
                yaygin_yanlislar={
                    cekilen_kw + mil_kw:
                        "İki gücü topladın. Kayıp, girenle çıkan arasındaki "
                        "FARKtır.",
                    round(verim * 100):
                        "Verim yüzdesini yazdın; sorulan ise kaç kW ısıya "
                        "dönüştüğü.",
                },
                puan=12,
            ),
            yorum_adimi(
                soru="Motorun ısınması bir arıza belirtisi mi?",
                dogru=("Hayır; kaybın ısıya dönüşmesi her motorda olur. "
                       "Anormal olan, ısının beklenenden fazla olmasıdır."),
                yanlislar={
                    "Evet; ısınan motor mutlaka arızalıdır.":
                        "Verimi %100 olan motor yoktur; kaybın ısıya dönüşmesi "
                        "normaldir. Arıza belirtisi olan, beklenenden fazla "
                        "ısınmadır.",
                    "Hayır; motorlar ısınmaz, ölçüm hatalıdır.":
                        "İki ölçüm de tutarlı ve aradaki fark tam olarak "
                        "kayba eşit. Ölçüm hatası olsaydı fark açıklanamazdı.",
                    "Evet; çünkü verim %100'ün altında.":
                        "Hiçbir motorda verim %100 değildir. Bu ölçüt bütün "
                        "motorları arızalı sayardı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kayıp enerji yok olmaz, biçim değiştirir: sürtünme ve "
                    "direnç yüzünden ısıya döner."),
            ),
        ],
        kapanis=("Motorun havalandırma kanalı tozdan tıkalıymış. Isı aynı "
                 "kaldı ama artık dışarı atılabiliyor."),
        odul={"enerji": 2, "cevher": 2, "itibar": 2},
    )
