# -*- coding: utf-8 -*-
"""
Düşünme ve sorgulama görevleri.

Bu alandaki yorum soruları çoğunlukla aynı kalıptadır: bir metin verilir,
"bu parçada savunulan görüş hangisidir" diye sorulur. Yani zaten bir keşif
işidir - filozof adı ezberlemek değil, metindeki iddiayı tanımak.

Bu modül o kalıbı üssün arşivine taşır: Kronograf'ın getirdiği düşünce
parçaları, bir tartışma tutanağı, bir mektup. Öğrenci önce metnin hangi
soruyu yanıtladığını belirler, sonra görüşü adlandırır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import model_adimi, secim_adimi, yorum_adimi


# ==========================================================================
# BİLGİ FELSEFESİ
# ==========================================================================

_BILGI_GORUSLERI = [
    {
        "ad": "Rasyonalizm (akılcılık)",
        "metin": ("Duyularım beni sürekli yanıltıyor: uzaktaki kule yuvarlak "
                  "görünüyor, suya batan çubuk kırık görünüyor. Oysa üçgenin iç "
                  "açıları toplamının iki dik açı ettiğini hiçbir üçgen çizmeden, "
                  "yalnızca düşünerek biliyorum ve bu bilgi hiç yanıltmıyor. "
                  "Demek ki güvenilir bilgi duyulardan değil akıldan gelir."),
        "olcut": "Bilginin kaynağı akıldır; duyular yanıltıcıdır.",
        "neden": ("Metin duyuların yanılttığını örnekliyor ve deney gerektirmeyen "
                  "akıl bilgisini güvenilir sayıyor. Bilginin kaynağını akla "
                  "dayandıran görüş rasyonalizmdir."),
    },
    {
        "ad": "Empirizm (deneycilik)",
        "metin": ("İnsan zihni doğduğunda üzerine hiçbir şey yazılmamış boş bir "
                  "levha gibidir. Hiç kar görmemiş birine karın soğukluğunu "
                  "anlatamazsınız. Zihnimizdeki bütün kavramlar, önce duyularımıza "
                  "çarpan izlenimlerden gelir. Deneyimin vermediği hiçbir bilgi "
                  "zihinde bulunmaz."),
        "olcut": "Bilginin kaynağı deneyimdir; zihin doğuştan boştur.",
        "neden": ("\"Boş levha\" benzetmesi ve bütün kavramların duyu izlenimlerinden "
                  "türetilmesi empirizmin tanımıdır."),
    },
    {
        "ad": "Kritisizm (eleştirel felsefe)",
        "metin": ("Bilgi ne yalnızca akıldan ne de yalnızca deneyden doğar. "
                  "Duyular bize ham veriyi getirir; ama zihin bu veriyi kendi "
                  "kalıplarına dökmeseydi bir yığın karmaşadan başka bir şey "
                  "olmazdı. Kavramsız algılar kör, algısız kavramlar ise boştur; "
                  "bilgi ikisinin birleşmesidir."),
        "olcut": "Bilgi akıl ile deneyin birlikte çalışmasıyla oluşur.",
        "neden": ("Metin iki kaynağı da tek başına yetersiz sayıp bilgiyi ikisinin "
                  "birleşimine bağlıyor. Bu, kritisizmin temel savıdır."),
    },
    {
        "ad": "Septisizm (kuşkuculuk)",
        "metin": ("Bir şeyi bildiğimizi söylediğimizde, bunu neye dayanarak "
                  "söylüyoruz? Dayanağımızı da başka bir dayanakla kanıtlamamız "
                  "gerekir, onu da bir başkasıyla. Bu zincirin sonu yok. O hâlde "
                  "hiçbir konuda kesin bilgiye ulaşamayız; yargıyı askıya almak "
                  "en doğrusudur."),
        "olcut": "Kesin bilgiye ulaşmak mümkün değildir.",
        "neden": ("Sonsuz gerileme sorunu ve \"yargıyı askıya alma\" tutumu "
                  "septisizmin ayırt edici işaretleridir."),
    },
]


@bulmaca(ders="felsefe", konu="bilgi_felsefesi", kademeler=(9, 13), agirlik=1.4)
def bilgi_felsefesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Metinden bilgi görüşünü tanıma ve gerekçelendirme."""
    gorus = rastgele.choice(_BILGI_GORUSLERI)
    digerleri = [g for g in _BILGI_GORUSLERI if g["ad"] != gorus["ad"]]

    return Bulmaca(
        kod="fel-bilgi",
        ders="felsefe",
        baslik="Arşivdeki Düşünce",
        kademe=kademe,
        konu="bilgi_felsefesi",
        kazanim="Bilgi felsefesindeki temel yaklaşımları metinden tanıma.",
        dikkat=5,
        brifing=(
            "Kronograf bu sefer bir ses değil, bir defter sayfası getirdi. "
            "Sayfada imza yok, tarih yok; yalnızca bir düşünce var:\n\n"
            "\"{}\"\n\n"
            "Arşiv fişine bu parçanın hangi görüşü savunduğu yazılacak. Yazarın "
            "adını bilmiyoruz - zaten sorulan da o değil."
        ).format(gorus["metin"]),
        kanitlar=[
            Kanit("Felsefe el kitabı - bilginin kaynağı",
                  "RASYONALİZM: Bilginin kaynağı akıldır; duyular yanıltır. "
                  "Doğuştan gelen, deney gerektirmeyen bilgiler vardır.\n\n"
                  "EMPİRİZM: Bilginin kaynağı deneyimdir. Zihin doğuşta boş bir "
                  "levhadır; bütün kavramlar duyu izlenimlerinden gelir.\n\n"
                  "KRİTİSİZM: Akıl ve deney birlikte gerekir; biri olmadan diğeri "
                  "bilgi üretmez.\n\n"
                  "SEPTİSİZM: Kesin bilgi mümkün değildir; yargı askıya alınmalıdır.",
                  bedel=2, kritik=True),
            Kanit("Okuma notu",
                  "\"Metinde filozof adı geçmez. Görüşü tanımak için tek soru "
                  "yeter: bu metne göre bilgi NEREDEN geliyor?\"",
                  bedel=2, kritik=True),
            Kanit("Sayfanın arkası",
                  "Boş. Yalnızca kâğıdın kenarında soluk bir mürekkep lekesi var.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu metnin hangi görüşü savunduğunu anlamak için neye bakılmalı?",
                dogru="Metnin bilginin KAYNAĞI hakkında ne söylediğine.",
                yanlislar={
                    "Metnin hangi yüzyılda yazıldığına.":
                        "Tarihe baktın. Aynı yüzyılda birbirine taban tabana "
                        "zıt görüşler savunulur; görüşü belirleyen zaman "
                        "değil, İDDİA.",
                    "Metinde kaç örnek verildiğine.":
                        "Örnek sayısını ölçüt saydın. Örnekler iddiayı "
                        "destekler ama hangi görüş olduğunu söyleyen şey "
                        "iddianın kendisi.",
                    "Metnin dilinin ağır ya da sade olmasına.":
                        "Üsluba baktın. Aynı görüş hem ağır hem sade dille "
                        "anlatılabilir.",
                    "Metinde bir filozof adının geçip geçmediğine.":
                        "Ada baktın. Ad geçmeden de bir görüş savunulabilir; "
                        "ad geçse bile metin onu eleştiriyor olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bilgi felsefesi tek bir soruyu tartışır: doğru bilgi mümkün mü, "
                    "mümkünse kaynağı nedir? Görüşleri birbirinden ayıran da bu "
                    "sorunun cevabıdır. Metnin yazarı, dönemi ya da üslubu görüşü "
                    "belirlemez; önemli olan metindeki iddiadır."
                ),
                ipuclari=[
                    "Metne göre güvenilir bilgi nereden geliyor: akıldan mı, duyudan mı?",
                    "Ya da metin \"hiçbir yerden, çünkü kesin bilgi yok\" mu diyor?",
                ],
                puan=18,
                cozum=(
                    "1) Metinde bilginin kaynağı hakkında kurulan cümleyi bul.\n"
                    "2) El kitabındaki dört tanımla karşılaştır:\n"
                    "   - Yalnızca akıl -> Rasyonalizm\n"
                    "   - Yalnızca deney -> Empirizm\n"
                    "   - İkisi birlikte -> Kritisizm\n"
                    "   - Hiçbiri, kesin bilgi yok -> Septisizm\n"
                    "3) Bu metnin ölçütü: {}\n"
                    "4) {}\n\n"
                    "Sonuç: {}"
                ).format(gorus["olcut"], gorus["neden"], gorus["ad"]),
            ),
            secim_adimi(
                soru="Bu parçada savunulan görüş hangisidir?",
                dogru=gorus["ad"],
                yanlislar=dict(
                    [(g["ad"], "{} görüşünün ölçütü bu metinde geçmiyor. El "
                               "kitabındaki tanımı metnin iddiasıyla yan yana "
                               "koy.".format(g["ad"])) for g in digerleri]
                    + [("Pozitivizm",
                        "Pozitivizm bilginin yalnızca gözlem ve deneyle "
                        "kurulacağını söyler. Metnin ölçüt cümlesi bunu "
                        "savunmuyor.")]
                ),
                rastgele=rastgele,
                aciklama="{} {}".format(gorus["neden"], "Ölçüt: " + gorus["olcut"]),
                ipuclari=["El kitabındaki dört tanımı metinle tek tek karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Bu tür sorularda filozof adı bilmek neden yeterli değildir?",
                dogru=("Soru metindeki iddiayı tanımayı ister; adı bilen ama görüşü "
                       "tanımayan öğrenci metni eşleştiremez."),
                yanlislar={
                    "Filozof adlarını bilmek bütün görüşü açıklamaya yeter.":
                        "Adı görüşün yerine koydun. Ad bir etikettir; soru "
                        "etiketi değil, metindeki İDDİAYI tanımanı istiyor.",
                    "Filozofların görüşleri zamanla değiştiği için.":
                        "Sebebi filozofun kendi değişimine bağladın. Sorun "
                        "orada değil: ad bilen öğrenci de metni okumadan "
                        "eşleştiremez.",
                    "Metinler her zaman anonim yazıldığı için.":
                        "Metinlerin hepsi anonim değil. Ad yazsa bile o adı "
                        "bilmek, metnin ne savunduğunu bilmek demek değil.",
                    "Ad bilmek yeterlidir; bu soru tipi kolaydır.":
                        "Soruyu ezber sorusu saydın. Burada istenen tanıma "
                        "değil, metni ölçütle eşleştirme.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Descartes rasyonalisttir\" bilgisi, önüne konan adsız bir metni "
                    "tanımaya yetmez. Yetecek olan şey rasyonalizmin NE İDDİA ETTİĞİNİ "
                    "bilmektir. Bu yüzden felsefede ezberlenmesi gereken şey isimler "
                    "değil, iddiaların ayırt edici cümleleridir."
                ),
                puan=12,
            ),
        ],
        kapanis="Arşiv fişine \"{}\" yazıldı; gerekçe hanesine de metindeki ölçüt eklendi.".format(
            gorus["ad"]),
        odul={"itibar": 7},
    )


# ==========================================================================
# FELSEFENİN ALANLARI
# ==========================================================================

@bulmaca(ders="felsefe", konu="felsefe_alanlari", kademeler=(9, 13))
def felsefe_alanlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir soru hangi felsefe dalına ait?"""
    sorular = [
        {"soru": "Var olan her şeyin temelinde madde mi vardır?",
         "alan": "Varlık felsefesi (ontoloji)",
         "neden": "Sorulan şey neyin VAR olduğu ve varlığın niteliğidir."},
        {"soru": "İnsan kesin bilgiye ulaşabilir mi?",
         "alan": "Bilgi felsefesi (epistemoloji)",
         "neden": "Sorulan şey bilginin imkânı ve kaynağıdır."},
        {"soru": "Bir eylemi doğru ya da yanlış yapan nedir?",
         "alan": "Ahlak felsefesi (etik)",
         "neden": "Sorulan şey eylemin değeri, iyi-kötü ölçütüdür."},
        {"soru": "Bir yapıtı güzel kılan şey nedir?",
         "alan": "Sanat felsefesi (estetik)",
         "neden": "Sorulan şey güzelin ölçütü ve sanatın değeridir."},
        {"soru": "Devletin otoritesi neye dayanarak meşru olur?",
         "alan": "Siyaset felsefesi",
         "neden": "Sorulan şey iktidarın kaynağı ve meşruluğudur."},
        {"soru": "Bir akıl yürütmenin geçerli olması ne demektir?",
         "alan": "Mantık",
         "neden": "Sorulan şey çıkarımın biçimsel geçerliliğidir."},
    ]
    secilen = rastgele.choice(sorular)
    digerleri = [s["alan"] for s in sorular if s["alan"] != secilen["alan"]]
    rastgele.shuffle(digerleri)

    return Bulmaca(
        kod="fel-alanlar",
        ders="felsefe",
        baslik="Hangi Rafa",
        kademe=kademe,
        konu="felsefe_alanlari",
        kazanim="Felsefenin alt dallarını, sordukları soruya göre ayırt etme.",
        dikkat=5,
        brifing=(
            "Arşivin felsefe bölümü alt dallara göre raflanıyor. Elindeki fişte "
            "tek bir soru yazıyor:\n\n"
            "  \"{}\"\n\n"
            "Fişi doğru rafa koyman gerekiyor. Arşivci \"felsefe hepsi aynı şey, "
            "nereye koysak olur\" diyor; ama her dal başka bir soruyu tartışır."
        ).format(secilen["soru"]),
        kanitlar=[
            Kanit("Raf etiketleri",
                  "ONTOLOJİ: Ne vardır? Varlığın temeli nedir?\n"
                  "EPİSTEMOLOJİ: Bilgi mümkün mü? Kaynağı nedir?\n"
                  "ETİK: İyi nedir? Bir eylemi doğru yapan nedir?\n"
                  "ESTETİK: Güzel nedir? Sanatın değeri nedir?\n"
                  "SİYASET FELSEFESİ: İktidar neye dayanır? Adalet nedir?\n"
                  "MANTIK: Geçerli akıl yürütme nedir?",
                  bedel=2, kritik=True),
            Kanit("Fiş", secilen["soru"], bedel=1, kritik=True),
            Kanit("Arşivci notu",
                  "\"Dalı belirleyen konu değil, sorulan SORUDUR. Aynı konu "
                  "(örneğin sanat) hem estetiğin hem ahlakın hem de siyasetin "
                  "sorusu olabilir.\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir sorunun hangi felsefe dalına ait olduğunu ne belirler?",
                dogru="Sorunun neyi araştırdığı: varlığı mı, bilgiyi mi, değeri mi.",
                yanlislar={
                    "Soruda hangi kelimelerin geçtiği.":
                        "Kelime avına çıktın. Aynı kelime farklı dalların "
                        "sorusunda geçebilir; belirleyici olan sorunun NEYİ "
                        "araştırdığı.",
                    "Sorunun kim tarafından sorulduğu.":
                        "Soranı ölçüt saydın. Bir soruyu kimin sorduğu, onu "
                        "hangi dalın ilgilendirdiğini değiştirmez.",
                    "Sorunun ne kadar eski olduğu.":
                        "Tarihe baktın. Çok eski bir soru da bugünün "
                        "dallarından birine girer.",
                    "Sorunun cevabının bilinip bilinmediği.":
                        "Cevabın durumunu ölçüt saydın. Felsefede çoğu sorunun "
                        "kesin cevabı yoktur; bu onları dalsız bırakmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Felsefenin dalları konulara göre değil SORULARA göre ayrılır. "
                    "\"Sanat\" konusu estetiğin sorusudur (\"güzel nedir\"), ama aynı "
                    "sanat ahlakın da sorusu olabilir (\"sanat ahlaki sınır tanımalı mı\"). "
                    "Bu yüzden anahtar kelime aramak yanıltır; sorulan şeyi anlamak gerekir."
                ),
                ipuclari=[
                    "Bu soru neyin var olduğunu mu, nasıl bilindiğini mi, "
                    "değerini mi araştırıyor?",
                    "Raf etiketlerindeki soru kalıplarıyla karşılaştır.",
                ],
                puan=18,
                cozum=(
                    "Raf etiketlerindeki soru kalıplarını fişteki soruyla eşle:\n"
                    "  \"{}\"\n"
                    "{}\n\n"
                    "Sonuç: {}"
                ).format(secilen["soru"], secilen["neden"], secilen["alan"]),
            ),
            secim_adimi(
                soru="Bu soru hangi felsefe dalına aittir?",
                dogru=secilen["alan"],
                yanlislar=digerleri[:4],
                rastgele=rastgele,
                aciklama=secilen["neden"],
                ipuclari=["Raf etiketlerini fişle karşılaştır."],
                puan=16,
            ),
            yorum_adimi(
                soru="Aynı konu birden çok felsefe dalının sorusu olabilir mi?",
                dogru="Evet; dalları ayıran konu değil, o konuya sorulan sorudur.",
                yanlislar={
                    "Hayır; her konu tek bir dala aittir.":
                        "Dalları kapalı kutular saydın. Aynı konu farklı "
                        "sorularla farklı dallara girer: bilginin ne olduğu "
                        "ayrı, doğru eylemin ne olduğu ayrı sorudur.",
                    "Hayır; dallar birbirinden tamamen bağımsızdır.":
                        "Bağımsızlığı mutlaklaştırdın. Dallar farklı sorular "
                        "sorar ama aynı konuyu paylaşabilir.",
                    "Evet ama yalnızca mantık ile epistemolojide.":
                        "Doğru fikri iki dala hapsettin. Aynı örtüşme ahlak "
                        "ile siyaset felsefesi arasında da olur.",
                    "Evet; çünkü felsefenin dalları arasında fark yoktur.":
                        "Doğru sonuca yanlış gerekçeyle vardın. Dallar arasında "
                        "fark VAR; örtüşmeyi sağlayan şey farkın yokluğu değil, "
                        "aynı konuya farklı sorular sorulabilmesi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Adalet\" konusu siyaset felsefesinin de etiğin de sorusudur; "
                    "biri \"adil devlet nedir\", diğeri \"adil davranış nedir\" diye "
                    "sorar. Dallar konuları değil bakış açılarını böler. Bu ayrım "
                    "kavranmadan yapılan eşleştirmeler ezbere kalır."
                ),
                puan=12,
            ),
        ],
        kapanis="Fiş doğru rafa kondu.",
        odul={"itibar": 6},
    )


# ==========================================================================
# AHLAK FELSEFESİ
# ==========================================================================

_AHLAK_GORUSLERI = [
    {
        "ad": "Faydacılık (yararcılık)",
        "metin": ("Bir eylemin doğru olup olmadığını anlamak için sonuçlarına "
                  "bakmalıyız. En çok sayıda insana en çok mutluluğu sağlayan "
                  "eylem doğrudur. Az kişiye büyük yarar sağlayan bir eylem, "
                  "çok kişiye küçük yarar sağlayandan üstün değildir."),
        "olcut": "Ölçüt eylemin SONUCU; en çok kişinin en çok yararı.",
    },
    {
        "ad": "Ödev ahlakı",
        "metin": ("Bir eylemi ahlaklı yapan şey sonucu değil, hangi niyetle "
                  "yapıldığıdır. Doğruyu söylemek işime yaradığı için "
                  "söylüyorsam ahlaklı davranmış olmam; doğruyu, doğru olduğu "
                  "için söylemeliyim. Ahlak yasası koşulsuzdur, çıkara bağlanamaz."),
        "olcut": "Ölçüt eylemin NİYETİ ve ödeve uygunluğu; sonuç önemli değil.",
    },
    {
        "ad": "Hazcılık (hedonizm)",
        "metin": ("İnsan doğası gereği acıdan kaçar, hazza yönelir. İyi dediğimiz "
                  "şey haz veren, kötü dediğimiz şey acı verendir. Ahlakın amacı "
                  "acıyı en aza indirip dinginliğe ulaşmaktır."),
        "olcut": "Ölçüt haz ve acı; iyi olan haz verendir.",
    },
    {
        "ad": "Erdem etiği",
        "metin": ("Sorulması gereken \"hangi eylem doğru\" değil, \"nasıl bir "
                  "insan olmalıyım\" sorusudur. Cesaret korkaklık ile atılganlık "
                  "arasındaki ortadır. Ahlaklı olmak, bu orta hâlleri alışkanlık "
                  "hâline getirmektir."),
        "olcut": "Ölçüt kişinin karakteri ve erdemleri; aşırılıklar arasındaki orta.",
    },
]


@bulmaca(ders="felsefe", konu="ahlak_felsefesi", kademeler=(10, 13))
def ahlak_felsefesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Metinden ahlak görüşünü tanıma."""
    gorus = rastgele.choice(_AHLAK_GORUSLERI)
    digerleri = [g for g in _AHLAK_GORUSLERI if g["ad"] != gorus["ad"]]

    return Bulmaca(
        kod="fel-ahlak",
        ders="felsefe",
        baslik="Tutanaktaki Sav",
        kademe=kademe,
        konu="ahlak_felsefesi",
        kazanim="Ahlak felsefesindeki temel yaklaşımları metinden tanıma.",
        dikkat=5,
        brifing=(
            "Üste zor bir karar tartışıldı ve tutanağa geçen savlardan biri şu:\n\n"
            "\"{}\"\n\n"
            "Tutanak arşive girmeden önce bu savın hangi ahlak anlayışına "
            "dayandığı fişlenecek. Kim söylediği değil, neye dayandığı önemli."
        ).format(gorus["metin"]),
        kanitlar=[
            Kanit("Felsefe el kitabı - ahlak ölçütleri",
                  "FAYDACILIK: Ölçüt sonuçtur; en çok kişiye en çok yarar.\n"
                  "ÖDEV AHLAKI: Ölçüt niyettir; ödev koşulsuzdur, sonuca bakılmaz.\n"
                  "HAZCILIK: Ölçüt hazdır; iyi olan haz veren, kötü olan acı verendir.\n"
                  "ERDEM ETİĞİ: Ölçüt karakterdir; erdem aşırılıklar arasındaki ortadır.",
                  bedel=2, kritik=True),
            Kanit("Ayırt etme notu",
                  "\"Tek soru yeter: metin eylemi neye bakarak yargılıyor? "
                  "Sonucuna mı, niyetine mi, verdiği hazza mı, kişinin "
                  "karakterine mi?\"", bedel=2, kritik=True),
            Kanit("Tutanak kapağı",
                  "Toplantıda üç sav ileri sürülmüş; bu, ikincisi. Söyleyenin adı "
                  "karalanmış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir ahlak görüşünü tanımak için metinde ne aranır?",
                dogru="Eylemin neye bakarak yargılandığı: sonucuna mı, niyetine mi, hazza mı, karaktere mi.",
                yanlislar={
                    "Metnin olumlu mu olumsuz mu bir eylemden söz ettiği.":
                        "Eylemin iyiliğine baktın. Ahlak görüşünü belirleyen "
                        "şey eylemin kendisi değil, onu ÖLÇMEK için kullanılan "
                        "ölçüt.",
                    "Metinde kaç kişiden söz edildiği.":
                        "Kişi sayısını ölçüt saydın. Faydacılık çoğunluğa "
                        "bakar ama bir görüşü tanımak için sayı saymak "
                        "yetmez.",
                    "Metnin dinî bir dayanağı olup olmadığı.":
                        "Kaynağı ölçüt saydın. Aynı ölçüt hem dinî hem seküler "
                        "bir metinde savunulabilir.",
                    "Metnin hangi ülkede yazıldığı.":
                        "Coğrafyaya baktın. Ahlak görüşleri ülkelere göre "
                        "sınıflandırılmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ahlak felsefesindeki bütün görüşler aynı soruyu yanıtlar: "
                    "\"bir eylemi iyi yapan nedir?\" Ayrıldıkları yer verdikleri "
                    "ÖLÇÜTTÜR. O yüzden metinde aranacak şey ölçüt cümlesidir; "
                    "genellikle \"...bakmalıyız\", \"...olan doğrudur\" biçiminde geçer."
                ),
                ipuclari=[
                    "Metin \"sonuçlarına bakmalıyız\" mı diyor, \"niyetine\" mi?",
                    "Ölçüt cümlesini bul, gerisi kendiliğinden gelir.",
                ],
                puan=18,
                cozum=(
                    "1) Metindeki ÖLÇÜT cümlesini bul.\n"
                    "2) El kitabındaki dört ölçütle karşılaştır:\n"
                    "   - Sonuç ve toplam yarar -> Faydacılık\n"
                    "   - Niyet ve koşulsuz ödev -> Ödev ahlakı\n"
                    "   - Haz ve acı -> Hazcılık\n"
                    "   - Karakter ve orta yol -> Erdem etiği\n"
                    "3) Bu metnin ölçütü: {}\n\n"
                    "Sonuç: {}"
                ).format(gorus["olcut"], gorus["ad"]),
            ),
            secim_adimi(
                soru="Bu savın dayandığı ahlak anlayışı hangisidir?",
                dogru=gorus["ad"],
                yanlislar=dict(
                    [(g["ad"], "{} görüşünün ölçütü metindeki ölçüt cümlesiyle "
                               "uyuşmuyor. El kitabındaki tanımla yan yana "
                               "koy.".format(g["ad"])) for g in digerleri]
                    + [("Görecelilik (relativizm)",
                        "Görecelilik, doğrunun kişiden kişiye değiştiğini "
                        "söyler. Metin ise herkes için geçerli bir ölçüt "
                        "öne sürüyor.")]
                ),
                rastgele=rastgele,
                aciklama="Ölçüt: {} Bu ölçüt {} görüşünü tanımlar.".format(
                    gorus["olcut"], gorus["ad"]),
                ipuclari=["Metnin ölçüt cümlesini el kitabıyla eşleştir."],
                puan=18,
            ),
            yorum_adimi(
                soru="Faydacılık ile ödev ahlakı arasındaki temel ayrım nedir?",
                dogru="Biri eylemin sonucuna, diğeri niyetine bakar.",
                yanlislar={
                    "Biri bireyi, diğeri toplumu düşünür.":
                        "Ayrımı kapsama göre kurdun. İkisi de hem bireyi hem "
                        "toplumu konu edebilir; ayrım eylemin NEYE göre "
                        "değerlendirildiğinde.",
                    "Biri dine, diğeri akla dayanır.":
                        "Ayrımı kaynağa bağladın. Her iki görüş de akıl "
                        "yürütmeyle savunulur.",
                    "Biri eski, diğeri yeni bir görüştür.":
                        "Ayrımı tarihe bağladın. Yaş bir görüşün ölçütünü "
                        "belirlemez.",
                    "Aralarında anlamlı bir fark yoktur.":
                        "Farkı yok saydın. Aynı eylem, sonucuna bakan biri "
                        "için doğru, niyetine bakan biri için yanlış olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı eylem iki görüşe göre farklı yargılanabilir: yalan "
                    "söyleyerek birinin canını kurtarmak faydacıya göre doğrudur "
                    "(sonuç iyidir), ödev ahlakına göre sorunludur (yalan koşulsuz "
                    "yasaktır). Bu yüzden ayrım \"toplum mu birey mi\" değil, "
                    "\"sonuç mu niyet mi\" eksenindedir."
                ),
                puan=12,
            ),
        ],
        kapanis="Sav fişlendi ve tutanak arşive kaldırıldı.",
        odul={"itibar": 7},
    )


# ==========================================================================
# ARGÜMAN ÇÖZÜMLEME
# ==========================================================================

@bulmaca(ders="felsefe", konu="akil_yurutme", kademeler=(9, 13))
def akil_yurutme(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tümdengelim mi tümevarım mı; sonucun kesinliği buna bağlı."""
    ornekler = [
        {
            "metin": ("Bütün metaller ısıtılınca genleşir. Bakır bir metaldir. "
                      "O hâlde bakır ısıtılınca genleşir."),
            "tur": "Tümdengelim",
            "kesinlik": "Öncüller doğruysa sonuç KESİNDİR.",
            "neden": ("Genel bir kuraldan tek bir duruma inildi. Tümdengelimde "
                      "öncüller doğruysa sonucun yanlış olması imkânsızdır."),
        },
        {
            "metin": ("Bu üste ölçtüğümüz yüz kuşun hepsinin kanadı vardı. "
                      "O hâlde bütün kuşların kanadı vardır."),
            "tur": "Tümevarım",
            "kesinlik": "Öncüller doğru olsa bile sonuç yalnızca OLASIDIR.",
            "neden": ("Tek tek gözlemlerden genel bir yargıya çıkıldı. Yüz kuş "
                      "gözlemek, gözlenmemiş kuşlar hakkında kesinlik vermez."),
        },
        {
            "metin": ("Yağmur yağdığında zemin ıslanır. Bugün yağmur yağdı. "
                      "O hâlde zemin ıslandı."),
            "tur": "Tümdengelim",
            "kesinlik": "Öncüller doğruysa sonuç KESİNDİR.",
            "neden": ("Genel kural tek bir olaya uygulandı; öncüller kabul "
                      "edilirse sonuç zorunlu olarak çıkar."),
        },
        {
            "metin": ("Son beş kışta da dere şubatta taştı. O hâlde bu şubatta "
                      "da taşacak."),
            "tur": "Tümevarım",
            "kesinlik": "Öncüller doğru olsa bile sonuç yalnızca OLASIDIR.",
            "neden": ("Geçmiş gözlemlerden geleceğe genelleme yapıldı; güçlü bir "
                      "beklenti kurar ama kesinlik vermez."),
        },
    ]
    ornek = rastgele.choice(ornekler)

    return Bulmaca(
        kod="fel-akil-yurutme",
        ders="felsefe",
        baslik="Rapordaki Çıkarım",
        kademe=kademe,
        konu="akil_yurutme",
        kazanim="Tümdengelim ve tümevarımı ayırt etme; sonucun kesinlik derecesini değerlendirme.",
        dikkat=5,
        brifing=(
            "Merkeze gidecek raporda şöyle bir çıkarım var:\n\n"
            "  \"{}\"\n\n"
            "Komutan bu cümlenin altına \"kesindir\" mi yoksa \"beklenmektedir\" "
            "mi yazacağını soruyor. İkisi arasındaki fark, çıkarımın türünden "
            "geliyor."
        ).format(ornek["metin"]),
        kanitlar=[
            Kanit("Rapordaki çıkarım", ornek["metin"], bedel=1, kritik=True),
            Kanit("Mantık el kitabı",
                  "TÜMDENGELİM: Genelden özele gidilir. Öncüller doğruysa sonuç "
                  "ZORUNLU olarak doğrudur; yeni bilgi vermez, var olanı açar.\n\n"
                  "TÜMEVARIM: Özelden genele gidilir. Öncüller doğru olsa bile "
                  "sonuç OLASIDIR; yeni bilgi verir ama kesinlik vermez.",
                  bedel=2, kritik=True),
            Kanit("Yazışma kuralı",
                  "\"Raporda kesin olmayan bir sonuç 'kesindir' diye yazılamaz. "
                  "Olasılık bildiren çıkarımlar 'beklenmektedir' ifadesiyle "
                  "yazılır.\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bu çıkarımın yönü nedir?",
                dogru=("Genelden özele" if ornek["tur"] == "Tümdengelim"
                       else "Özelden genele"),
                yanlislar={
                    ("Özelden genele" if ornek["tur"] == "Tümdengelim"
                     else "Genelden özele"):
                        "Yönü ters okudun. Öncüllerin hangisinin geniş, "
                        "hangisinin dar olduğuna bak: genel bir kuraldan tek "
                        "bir duruma mı gidiliyor, yoksa tek tek durumlardan "
                        "genel bir kurala mı?",
                    "Özelden özele":
                        "Bu bir benzetmedir (analoji), çıkarımın yönü değil. "
                        "Buradaki öncüllerden biri genel bir ifade.",
                    "Genelden genele":
                        "İki ucu da genel saydın. Çıkarımın bir ucunda tek bir "
                        "duruma ait ifade var.",
                    "Çıkarımda bir yön yoktur":
                        "Yönü yok saydın. Akıl yürütmenin yönü tam da onu "
                        "hangi tür yapan şey.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çıkarımın yönü türünü, türü de sonucun kesinliğini belirler. "
                    "Genel bir kuralla başlayıp tek bir duruma inen çıkarım "
                    "tümdengelimdir; tek tek gözlemlerle başlayıp genel bir yargıya "
                    "çıkan çıkarım tümevarımdır."
                ),
                ipuclari=[
                    "İlk cümle genel bir kural mı, tek tek gözlem mi?",
                    "Sonuç cümlesi tek bir durumu mu, hepsini mi anlatıyor?",
                ],
                puan=18,
                cozum=(
                    "1) Öncüllere bak: genel kural mı, tekil gözlemler mi?\n"
                    "2) Sonuca bak: tekil bir durum mu, genel bir yargı mı?\n"
                    "3) Genelden tekile iniyorsa TÜMDENGELİM, tekilden genele "
                    "çıkıyorsa TÜMEVARIM.\n"
                    "4) {}\n\n"
                    "Bu çıkarım: {} - {}"
                ).format(ornek["neden"], ornek["tur"], ornek["kesinlik"]),
            ),
            secim_adimi(
                soru="Bu çıkarım hangi tür akıl yürütmedir?",
                dogru=ornek["tur"],
                yanlislar={
                    ("Tümevarım" if ornek["tur"] == "Tümdengelim" else "Tümdengelim"):
                        "Türü ters aldın. Bir önceki adımda belirlediğin yönle "
                        "eşleştir: genelden özele giden tümdengelim, özelden "
                        "genele giden tümevarımdır.",
                    "Analoji (benzetme)":
                        "Analoji iki ayrı durumu benzeterek sonuç çıkarır. "
                        "Burada bir genelleme ile tek bir durum arasında "
                        "bağ kuruluyor.",
                    "Tanım":
                        "Tanım bir kavramın ne olduğunu söyler; buradaki "
                        "cümleler öncüllerden sonuç çıkarıyor.",
                    "Sınıflandırma":
                        "Sınıflandırma öğeleri gruplara ayırır. Burada grup "
                        "değil, bir SONUÇ üretiliyor.",
                },
                rastgele=rastgele,
                aciklama=ornek["neden"],
                ipuclari=["Çıkarımın yönünü belirledin; el kitabındaki tanımla eşleştir."],
                puan=16,
            ),
            secim_adimi(
                soru="Rapora bu cümlenin altına ne yazılmalı?",
                dogru=("\"Kesindir\" - öncüller doğruysa sonuç zorunludur."
                       if ornek["tur"] == "Tümdengelim"
                       else "\"Beklenmektedir\" - sonuç olasıdır, kesin değildir."),
                yanlislar={
                    ("\"Beklenmektedir\" - sonuç olasıdır, kesin değildir."
                     if ornek["tur"] == "Tümdengelim"
                     else "\"Kesindir\" - öncüller doğruysa sonuç zorunludur."):
                        "Notu çıkarımın türüyle ters eşleştirdin. Tümdengelimde "
                        "sonuç zorunlu, tümevarımda olasıdır; belirlediğin "
                        "türle notu yan yana koy.",
                    "\"Belirsizdir\" - çıkarımdan hiçbir sonuç çıkmaz.":
                        "Çıkarımı sonuçsuz saydın. Her iki türde de bir sonuç "
                        "çıkar; değişen şey o sonucun ne kadar bağlayıcı "
                        "olduğu.",
                    "\"Yanlıştır\" - çıkarım geçersizdir.":
                        "Çıkarımı geçersiz ilan ettin. Öncüllerden sonuca "
                        "geçiş kurallıysa çıkarım geçerlidir; rapora yazılacak "
                        "not onun kesinlik derecesi.",
                    "Hiçbir not düşülmemeli.":
                        "Notu gereksiz saydın. Üst makam sonucun ne kadar "
                        "güvenilir olduğunu bilmeden karar veremez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{} Bu yüzden rapora {} ifadesi yazılır. Tümevarımsal bir sonucu "
                    "\"kesindir\" diye yazmak, elde olmayan bir güveni rapora "
                    "eklemek olur."
                ).format(ornek["kesinlik"],
                         "\"kesindir\"" if ornek["tur"] == "Tümdengelim"
                         else "\"beklenmektedir\""),
                ipuclari=["Bu tür çıkarımda sonuç zorunlu mu, olası mı?"],
                puan=14,
            ),
        ],
        kapanis="Rapordaki çıkarımın altına doğru ifade yazıldı.",
        odul={"itibar": 7},
    )
