# -*- coding: utf-8 -*-
"""Oyun motoru: icerikten bagimsiz altyapi."""
