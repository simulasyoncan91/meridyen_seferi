# -*- coding: utf-8 -*-
"""
Siber Nöbet: üssün kendini koruması (ilk halka: e-posta duvarı).

Kullanıcı (5 Kasım 2026): "Siber güvenlik artık evlerin dış kapı kilidi
gibi." / "Siber güvenlik bölümünü yavaşça güçlendirelim. İlk o mesaj gelip
denileni yaptığında önce bir azar işitsin. Sonra kendi güvenlik sistemleri
geliştirme açılsın. Bunu bloklar halinde derleyebilsinler." / "Gerçekten
siber güvenliği basit bir şekilde bırakmayalım."

AKIŞ
  1. OLTALAMA OLAYI: belli bir görev sayısından sonra Posta'ya sahte bir ileti
     gelir. Öğrenci ne yapacağını seçer. Bağlantıya gidip şifresini yazarsa
     Komutan'dan azar işitir ve iletinin ele veren işaretleri tek tek
     gösterilir. Bildirirse övülür. Her iki durumda Siber Nöbet açılır.
  2. SİBER NÖBET: öğrenci e-posta duvarını KURAL BLOKLARIYLA kurar:
         EĞER <alan> <karşılaştırma> <değer> İSE <eylem>
     Kurallar sırayla denenir, ilk uyan karar verir; hiçbiri uymazsa ileti
     geçer. Duvar, oyunun ileti setiyle sınanır: kaç sahte yakalandı, kaç
     sahte kaçtı, kaç gerçek ileti YANLIŞLIKLA durduruldu. Yanlış alarm da
     cezadır: her şeyi durduran duvar işe yaramaz.
  3. SONRAKİ HALKALAR (tasarım; bkz. plan belgesi): parola politikası ve
     tahmin süresi hesabı, ağ duvarı (Bilişim), kayıt analizi.

SINIRLAR
  * Yalnız SAVUNMA öğretilir. Saldırı tekniği yok.
  * Bütün adresler ve kurumlar KURMACA. Uzantılar (".üs", ".kom") gerçek
    alan adı uzantısı DEĞİL: hiçbiri gerçek bir siteye karşılık gelemez,
    alınıp kötüye kullanılamaz. Ders aynı kalır: alanın SONUNA bakılır.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

ESIK_GOREV = 6                 # oltalama olayı en erken bu görevde
GERCEK_ALAN = "meridyen.üs"


@dataclass(frozen=True)
class Ileti:
    kod: str
    gonderen: str
    adres: str
    konu: str
    metin: str
    baglanti: str = ""
    ek: str = ""
    sifre_istiyor: bool = False
    aciliyet: bool = False
    sahte: bool = False
    isaretler: Tuple[str, ...] = ()

    @property
    def gonderen_alani(self) -> str:
        return self.adres.split("@")[-1].lower()

    @property
    def baglanti_alani(self) -> str:
        if not self.baglanti:
            return ""
        return self.baglanti.split("://")[-1].split("/")[0].lower()

    @property
    def ek_turu(self) -> str:
        return self.ek.rsplit(".", 1)[-1].lower() if "." in self.ek else ""


ILK_OLTA = Ileti(
    kod="olta-hesap-kapanis",
    gonderen="Komutanlık Destek",
    adres="destek@meridyen-destek.kom",
    konu="ACİL: Üs hesabın 24 saat içinde kapatılacak",
    metin=("Sayın kaşif,\n\nÜs hesabında olağandışı hareket tespit edildi. "
           "Hesabının kapatılmaması için aşağıdaki bağlantıya girip üs "
           "şifreni onaylaman gerekiyor. Onaylamazsan bütün tesislerin ve "
           "rütben silinecek.\n\nhttps://meridyen-destek.kom/onayla\n\n"
           "Komutanlık Destek Birimi"),
    baglanti="https://meridyen-destek.kom/onayla",
    sifre_istiyor=True, aciliyet=True, sahte=True,
    isaretler=(
        "Gönderen adresi meridyen.üs değil, meridyen-destek.kom: adı benziyor ama alan başka.",
        "Şifre istiyor. Gerçek Komutanlık şifreni hiçbir zaman e-postayla sormaz.",
        "Acele ettiriyor ve korkutuyor: \"24 saat\", \"her şey silinecek\".",
        "Bağlantı da üssün alanına değil, yabancı bir alana gidiyor.",
    ),
)

ILETILER: Tuple[Ileti, ...] = (
    ILK_OLTA,
    Ileti("olta-harf-oyunu", "Meridyen Komuta", "komuta@rneridyen.üs",
          "Rütbe terfin onay bekliyor",
          "Terfini tamamlamak için giriş yap: https://rneridyen.üs/terfi",
          baglanti="https://rneridyen.üs/terfi", sifre_istiyor=True, sahte=True,
          isaretler=("\"rneridyen\": r ve n yan yana m gibi görünüyor; alan meridyen.üs değil.",)),
    Ileti("olta-ek-dosya", "Tesis Bakım", "bakim@tesis-bakim.kom",
          "Arıza raporu ekte", "Arıza raporunu açıp çalıştırın.",
          ek="ariza_raporu.exe", sahte=True,
          isaretler=("Rapor diye gelen dosya bir program (.exe).", "Gönderen üssün alanından değil.")),
    Ileti("olta-hediye", "Pazar Duyuru", "kampanya@pazar-firsat.kom",
          "Tebrikler! 500 itibar kazandın",
          "Ödülünü almak için bağlantıya gir ve şifreni yaz: https://pazar-firsat.kom/al",
          baglanti="https://pazar-firsat.kom/al", sifre_istiyor=True, aciliyet=True, sahte=True,
          isaretler=("Beklemediğin bir ödül.", "Şifre istiyor.", "Yabancı alan.")),
    Ileti("olta-sahte-ic", "Komutan Yardımcısı", "yardimci@meridyen.üs.giris.kom",
          "Hemen bak", "Şu bağlantıdan dosyaları kontrol et: https://meridyen.üs.giris.kom/dosya",
          baglanti="https://meridyen.üs.giris.kom/dosya", aciliyet=True, sahte=True,
          isaretler=("Adresin başı meridyen.üs gibi ama alanın sonu giris.kom: asıl alan sondadır.",)),
    # Gerçek iletiler: duvar bunları durdurmamalı.
    Ileti("gercek-terfi", "Komutan", "komutan@meridyen.üs", "Rütbe terfisi",
          "Raporların incelendi, terfin işlendi. Kâşif Günlüğü'nden bakabilirsin."),
    Ileti("gercek-guncelleme", "Üs Bilgisayarı", "sistem@meridyen.üs",
          "Meridyen OS güncellemesi",
          "Yeni sürüm yüklendi. Ayrıntı: https://meridyen.üs/surum",
          baglanti="https://meridyen.üs/surum"),
    Ileti("gercek-ogretmen", "Öğretmen", "ogretmen@meridyen.üs",
          "Bu haftanın konusu", "Bu hafta oran-orantı üzerinde çalışıyoruz."),
    Ileti("gercek-rapor", "Tesis Bakım", "bakim@meridyen.üs",
          "Haftalık bakım raporu", "Rapor ekte.", ek="bakim_raporu.pdf"),
    Ileti("gercek-acil", "Komutan", "komutan@meridyen.üs",
          "Fırtına uyarısı: bugün dışarı çıkma",
          "Fırtına bekleniyor, tesis kapıları kapalı tutulsun.", aciliyet=True),
)

# ---------------------------------------------------------------- bloklar
ALANLAR = {
    "gonderen_alani": "gönderen alanı",
    "baglanti_alani": "bağlantının alanı",
    "ek_turu": "ek dosya türü",
    "sifre_istiyor": "şifre istiyor",
    "aciliyet": "acele ettiriyor",
}
KARSILASTIRMALAR = {
    "esit": "eşittir",
    "esit_degil": "eşit değildir",
    "bitmiyor": "ile bitmiyor",
}
EYLEMLER = {"karantina": "karantinaya al", "uyar": "uyarıyla geçir", "gecir": "geçir"}
DEGER_ONERILERI = {
    "gonderen_alani": [GERCEK_ALAN],
    "baglanti_alani": [GERCEK_ALAN, ""],
    "ek_turu": ["exe", "pdf", ""],
    "sifre_istiyor": ["evet", "hayır"],
    "aciliyet": ["evet", "hayır"],
}


def _deger(ileti: Ileti, alan: str) -> str:
    v = getattr(ileti, alan)
    if isinstance(v, bool):
        return "evet" if v else "hayır"
    return str(v or "")


_KOSUL_EKI = {"esit": "ise", "esit_degil": "değilse", "bitmiyor": "ile bitmiyorsa"}


def kural_metni(kural: Dict[str, str]) -> str:
    """EĞER gönderen alanı "meridyen.üs" ile bitmiyorsa -> karantinaya al"""
    return "EĞER {} \"{}\" {} -> {}".format(
        ALANLAR[kural["alan"]], kural["deger"] or "(boş)",
        _KOSUL_EKI[kural["kosul"]], EYLEMLER[kural["eylem"]])


def kural_uyar_mi(kural: Dict[str, str], ileti: Ileti) -> bool:
    v = _deger(ileti, kural["alan"])
    hedef = (kural.get("deger") or "").lower()
    k = kural["kosul"]
    if k == "esit":
        return v == hedef
    if k == "esit_degil":
        return v != hedef
    if k == "bitmiyor":
        # "meridyen.üs ile bitmiyor": boş alan (bağlantı yok) uymaz.
        return bool(v) and not (v == hedef or v.endswith("." + hedef))
    return False


def karar(kurallar: List[Dict[str, str]], ileti: Ileti) -> str:
    for kural in kurallar:
        if kural_uyar_mi(kural, ileti):
            return kural["eylem"]
    return "gecir"


def duvari_sina(kurallar: List[Dict[str, str]],
                iletiler: Tuple[Ileti, ...] = ILETILER) -> Dict[str, Any]:
    """Duvarın karnesi. "uyar" sahtede yarım başarı, gerçekte zararsızdır."""
    yakalanan, uyarilan, kacan, yanlis_alarm = [], [], [], []
    for ileti in iletiler:
        k = karar(kurallar, ileti)
        if ileti.sahte:
            {"karantina": yakalanan, "uyar": uyarilan, "gecir": kacan}[k].append(ileti)
        elif k == "karantina":
            yanlis_alarm.append(ileti)
    sahte = sum(1 for i in iletiler if i.sahte)
    puan = (len(yakalanan) + 0.5 * len(uyarilan) - len(yanlis_alarm)) / float(sahte)
    yildiz = 3 if puan >= 0.999 else (2 if puan >= 0.7 else (1 if puan >= 0.4 else 0))
    return {"yakalanan": yakalanan, "uyarilan": uyarilan, "kacan": kacan,
            "yanlis_alarm": yanlis_alarm, "puan": round(max(0.0, puan), 2),
            "yildiz": yildiz}


# ------------------------------------------------------------------ durum
def durum_al(durum) -> Dict[str, Any]:
    veri = durum.ayarlar.get("siber")
    if not isinstance(veri, dict):
        veri = {"acik": False, "olta_goruldu": False, "kurallar": [], "en_iyi": 0}
        durum.ayarlar["siber"] = veri
    veri.setdefault("kurallar", [])
    return veri


def acik_mi(durum) -> bool:
    return bool((durum.ayarlar.get("siber") or {}).get("acik"))


@dataclass(frozen=True)
class Tuzak:
    """İlk tatbikat. Hep aynı e-posta olmasın (kullanıcı, 5 Kasım 2026):
    her öğrenciye kanalı da kurgusu da farklı bir tuzak düşer. Ortak ders:
    beklenmedik bir istek, acele, kimliği doğrulanamayan kaynak."""
    kod: str
    kanal: str                     # posta | telsiz | bellek | uyari
    baslik: str                    # ekrandaki kutu başlığı
    kimden: str
    metin: str
    secenekler: Tuple[Tuple[str, str], ...]   # (riskli, bildir, geç) sırasıyla
    azar: str
    isaretler: Tuple[str, ...]


_AZAR_SON = ("\n\nBu sefer tatbikattı; kaybın yok. Ama bir daha olmasın: "
             "üssün kendi savunmasını kurmanı istiyorum. Siber Nöbet artık açık.")

ILK_TUZAKLAR: Tuple[Tuzak, ...] = (
    Tuzak("posta-hesap-kapanis", "posta", "YENİ POSTA",
          "{} <{}>".format(ILK_OLTA.gonderen, ILK_OLTA.adres),
          "Konu: {}\n\n{}".format(ILK_OLTA.konu, ILK_OLTA.metin),
          (("Bağlantıya git, şifremi yazıp onayla", "hesap kapanmasın"),
           ("Komutanlığa bildir", "şüpheli ileti"),
           ("Sil", "boş ver")),
          "Az önce üssün kapısını yabancıya açtın.\n\nO ileti Komutanlık'tan "
          "gelmedi. Şifreni yazdığın sayfa da bizim değildi. Gerçek bir saldırı "
          "olsaydı şimdi tesislerin başkasının elindeydi." + _AZAR_SON,
          ILK_OLTA.isaretler),
    Tuzak("telsiz-sahte-teknisyen", "telsiz", "TELSİZ: AÇIK KANAL",
          "Kendini \"yeni bakım teknisyeni\" diye tanıtan bir ses",
          "\"Usta beni gönderdi, jeneratör arızalı. Acele etmem lazım; "
          "tesis panelinin şifresini söyler misin? Usta şimdi meşgul, onu "
          "arama, kızar.\"",
          (("Şifreyi söyle", "usta bekliyor"),
           ("Kimliğini Komuta'dan doğrulat", "şüpheli çağrı"),
           ("Cevap verme", "kanalı kapat")),
          "Şifreyi, yüzünü bile görmediğin birine verdin.\n\nÜsse yeni "
          "teknisyen gelmedi. O ses, Usta'nın adını kullanarak seni acele "
          "ettirdi ve kontrol etmeni engellemeye çalıştı. Buna sosyal "
          "mühendislik denir: kilidi kırmaz, sana açtırır." + _AZAR_SON,
          ("Kimliği doğrulanamıyor: açık kanalda herkes \"teknisyenim\" diyebilir.",
           "Şifre istiyor. Gerçek bakım ekibinin senin şifrene ihtiyacı yoktur.",
           "Acele ettiriyor ve tanıdık bir adı (Usta) kullanıyor.",
           "Kontrol etmeni engelliyor: \"onu arama, kızar\".")),
    Tuzak("bellek-gizli-liste", "bellek", "DEPO KAPISINDA BULUNAN",
          "Kimden olduğu belli değil",
          "Depo kapısının önünde küçük bir bellek buldun. Üzerinde el "
          "yazısıyla \"Rütbe listesi - GİZLİ\" yazıyor.",
          (("Üs bilgisayarına takıp aç", "ne var bakayım"),
           ("Güvenlik birimine teslim et", "kaynağı belli değil"),
           ("Olduğu yerde bırak", "dokunma")),
          "Kaynağını bilmediğin bir belleği üssün bilgisayarına taktın.\n\n"
          "Böyle bellekler takıldığı anda kendi kendine program çalıştırabilir. "
          "\"Gizli\" etiketi tam da seni meraklandırıp taktırmak için yazılmıştı." + _AZAR_SON,
          ("Kaynağı bilinmiyor: kimin bıraktığını bilmiyorsun.",
           "Etiket merak uyandırmak için seçilmiş: \"gizli\", \"rütbe listesi\".",
           "Takıldığı anda zarar verebilir; açmadan önce bile iş işten geçer.",
           "Doğru yol: dokunmadan, inceleyebilecek birime teslim etmek.")),
    Tuzak("uyari-sahte-guncelleme", "uyari", "EKRANDA BİR PENCERE",
          "\"Meridyen OS Guvenlik Merkezi\"",
          "UYARI! Meridyen OS'unuz GÜNCEL DEĞİL ve 3 virüs bulundu!\n"
          "Verileriniz 10 dakika içinde silinecek. Hemen Guncelle_Meridyen.exe "
          "dosyasını indirip çalıştırın.",
          (("Dosyayı indir ve çalıştır", "virüsler silinsin"),
           ("Güncellemeyi Meridyen OS'un kendi güncelleme yerinden denetle", "pencereye güvenme"),
           ("Pencereyi kapat", "yok say")),
          "Tanımadığın bir pencerenin verdiği dosyayı çalıştırdın.\n\n"
          "Meridyen OS güncellemeleri yalnızca sistemin kendi güncelleme "
          "yerinden gelir; hiçbir zaman bir uyarı penceresinden dosya "
          "indirtmez. Korkutup acele ettiren her pencere şüphelidir." + _AZAR_SON,
          ("Gerçek güncelleme, sistemin kendi güncelleme yerinden gelir; açılır pencereden değil.",
           "Korkutuyor ve süre veriyor: \"3 virüs\", \"10 dakika\".",
           "Çalıştırılabilir bir dosya (.exe) indirtmeye çalışıyor.",
           "Ad resmi görünmeye çalışıyor ama yazımı özensiz: \"Guvenlik\", \"Guncelle\".")),
)

_TUZAK_KOMUTAN = {
    "bildir": ("acik_yesil", "Doğru hamle. Bu bir tatbikattı ve sen kaynağı "
               "doğrulamadan adım atmadın.\n\nŞimdi bir adım öteye geçelim: bu "
               "tür saldırıları sen görmeden durduracak savunmayı kur. Siber "
               "Nöbet artık açık."),
    "sil": ("acik_cam", "Tuzağa düşmedin; ama bildirmek daha iyi olurdu. "
            "Bildirilen saldırı başkalarını da korur.\n\nBu bir tatbikattı. "
            "Şimdi üssün savunmasını kur: Siber Nöbet artık açık."),
}


def _tohum(durum) -> int:
    import hashlib
    kimlik = durum.kimlik() if hasattr(durum, "kimlik") else str(getattr(durum, "oyuncu", ""))
    return int(hashlib.sha256(("siber:" + str(kimlik)).encode("utf-8")).hexdigest()[:8], 16)


def ilk_tuzak(durum) -> Tuzak:
    """Öğrenciye düşen ilk tatbikat; aynı kayıtta hep aynı."""
    return ILK_TUZAKLAR[_tohum(durum) % len(ILK_TUZAKLAR)]


def olta_esigi(durum) -> int:
    """Tatbikat herkese aynı görevde gelmesin: ESIK_GOREV ile +3 arası."""
    return ESIK_GOREV + (_tohum(durum) // 7) % 4


def olta_zamani_mi(durum) -> bool:
    veri = durum.ayarlar.get("siber") or {}
    return (not veri.get("olta_goruldu")) and int(durum.oynanan_gorev or 0) >= olta_esigi(durum)


def olta_sonucu(durum, secim: str) -> Dict[str, Any]:
    """secim: "tikla" (riskli eylem) | "bildir" | "sil". Ekran metinlerini döner."""
    veri = durum_al(durum)
    tuzak = ilk_tuzak(durum)
    veri["olta_goruldu"] = True
    veri["acik"] = True
    veri["ilk_tepki"] = secim
    veri["ilk_tuzak"] = tuzak.kod
    if secim == "tikla":
        ton, metin = "acik_sari", tuzak.azar
    else:
        ton, metin = _TUZAK_KOMUTAN.get(secim, _TUZAK_KOMUTAN["sil"])
    return {"baslik": "KOMUTAN", "ton": ton, "metin": metin,
            "isaretler": list(tuzak.isaretler)}
