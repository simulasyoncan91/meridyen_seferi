# -*- coding: utf-8 -*-
"""
İçerik yazarken işe yarayan ortak yardımcılar.

Alt çizgiyle başladığı için kayıt defteri bu modülü "ders içeriği" saymaz;
yalnızca diğer içerik modülleri buradan yardımcı çeker.

En önemlisi `siklar()`: doğru şıkkın yerini karıştırır. Karıştırmazsan öğrenci
üç görev sonra "doğru cevap hep 1. şık" diye öğrenir ve oyun bozulur.
"""
from __future__ import annotations

import random
from typing import Dict, List, Mapping, Sequence, Tuple, Union

from oyun.motor.modeller import (
    Adim, COKLU, COZUM, ESLESTIR, METIN, MODEL, SAYI, SECIM, SIRALA, YORUM,
)

# --------------------------------------------------------------------------
# İsim havuzları - anlatının her seferinde aynı olmaması için
# --------------------------------------------------------------------------

PERSONEL = [
    "Onbaşı Demir", "Teknisyen Aylin", "Kâtip Sarp", "Ölçümcü Nehir",
    "Depocu Kerem", "Telsizci Reyhan", "Çavuş Bora", "Kayıtçı Elif",
    "Gözcü Tarık", "Aşçı Nurten", "Sürücü Mert", "Hemşire Bilge",
]

DEPO_ADLARI = ["Kuzey", "Güney", "Doğu", "Batı", "Yamaç", "Dere", "Kayalık", "Çukur"]

MEVKI_ADLARI = [
    "Karataş", "Akpınar", "Yelkaya", "Çamdibi", "Susuzkuyu", "Boğazderesi",
    "Kızılyar", "Serinova", "Taşköprü", "Gökbayır",
]

BIRIM_ADLARI = ["sandık", "kasa", "denk", "balya", "varil", "çuval"]


def ad_sec(rastgele: random.Random, havuz: Sequence[str], adet: int = 1) -> List[str]:
    """Havuzdan tekrarsız isim seçer."""
    return rastgele.sample(list(havuz), min(adet, len(havuz)))


# --------------------------------------------------------------------------
# Şık karıştırma
# --------------------------------------------------------------------------

# Yanlış şıklar iki biçimde yazılabilir:
#   ["yanlis 1", "yanlis 2"]                       -> yalnızca çeldirici
#   {"yanlis 1": "şunu karıştırdın...", ...}       -> çeldirici + teşhisi
# İkincisi tercih edilir: öğrenci o şıkkı seçtiğinde hatanın adını duyar.
Yanlislar = Union[Sequence[str], Mapping[str, str]]


def yanlis_metinleri(yanlislar: Yanlislar) -> List[str]:
    """Sözlük de liste de verilse, yanlış şık metinlerini döner."""
    return list(yanlislar.keys()) if isinstance(yanlislar, Mapping) else list(yanlislar)


def _teshis_sozlugu(yanlislar: Yanlislar) -> Dict[str, str]:
    if not isinstance(yanlislar, Mapping):
        return {}
    return {metin: teshis for metin, teshis in yanlislar.items() if teshis}


def siklar(rastgele: random.Random, dogru: str, yanlislar: Yanlislar,
           azami: int = 5) -> Tuple[List[str], int]:
    """
    Doğru şıkkı yanlışlarla karıştırır.
    (secenek_listesi, dogru_indeks) döner.

    `azami` şık sayısının üst sınırıdır. Görevler gerektiğinde beş seçeneğe
    kadar çıkabilir. Kaç şık çıkacağını yazarın
    verdiği yanlış sayısı belirler: 4 yanlış yazarsan 5 şıklı, 3 yazarsan
    4 şıklı soru olur.
    """
    yanlis_havuz = [y for y in yanlis_metinleri(yanlislar)
                    if y.strip() and y.strip() != dogru.strip()]
    # Aynı metnin iki kez girmesini engelle
    benzersiz: List[str] = []
    for aday in yanlis_havuz:
        if aday not in benzersiz:
            benzersiz.append(aday)
    secilen = benzersiz[:max(1, azami - 1)]
    liste = secilen + [dogru]
    rastgele.shuffle(liste)
    return liste, liste.index(dogru)


def coklu_siklar(rastgele: random.Random, dogrular: Sequence[str],
                 yanlislar: Sequence[str]) -> Tuple[List[str], List[int]]:
    """Birden çok doğrusu olan şık listesi kurar."""
    liste = list(dogrular) + list(yanlislar)
    rastgele.shuffle(liste)
    indeksler = sorted(liste.index(d) for d in dogrular)
    return liste, indeksler


# --------------------------------------------------------------------------
# Adım kısayolları
# --------------------------------------------------------------------------

def model_adimi(soru: str, dogru: str, yanlislar: Yanlislar,
                rastgele: random.Random, aciklama: str,
                ipuclari: Sequence[str] = (), puan: int = 15,
                cozum: str = "", cozum_bedeli: int = 2) -> Adim:
    """
    Modelleme adımı: "olayı hangi bağıntı anlatıyor?"
    Her bulmacada en az bir tane olmalı - oyunun ayırt edici yeri burası.

    `cozum` verilirse öğrenci oyun içinde dikkat harcayarak tam çözümü açabilir;
    öğrenci takıldığında ise bu metin çözümü öğretmek için gösterilir.
    """
    secenekler, indeks = siklar(rastgele, dogru, yanlislar)
    return Adim(
        soru=soru, tur=SECIM, rol=MODEL, secenekler=secenekler, cevap=indeks,
        aciklama=aciklama, ipuclari=list(ipuclari), puan=puan,
        cozum=cozum, cozum_bedeli=cozum_bedeli,
        yanlis_teshis={k: v for k, v in _teshis_sozlugu(yanlislar).items()
                       if k in secenekler and k != dogru},
    )


def sayi_adimi(soru: str, cevap, aciklama: str, birim: str = "",
               ipuclari: Sequence[str] = (), puan: int = 12,
               tolerans: float = 0.001, cozum: str = "",
               cozum_bedeli: int = 2,
               yaygin_yanlislar: Mapping = None) -> Adim:
    """
    Sayısal çözüm adımı.

    `yaygin_yanlislar`, o soruda beklenen hatalı sonuçları teşhisleriyle
    eşler: {toplam - alinan: "Eksileni geri koymadan böldün."} gibi. Öğrenci
    o sayıyı yazınca oyun hatanın adını koyar, doğru cevabı söylemeden.
    """
    return Adim(
        soru=soru, tur=SAYI, rol=COZUM, cevap=float(cevap), birim=birim,
        aciklama=aciklama, ipuclari=list(ipuclari), puan=puan, tolerans=tolerans,
        cozum=cozum, cozum_bedeli=cozum_bedeli,
        yanlis_teshis={str(sayi): metin
                       for sayi, metin in (yaygin_yanlislar or {}).items()},
    )


def secim_adimi(soru: str, dogru: str, yanlislar: Yanlislar,
                rastgele: random.Random, aciklama: str, rol: str = COZUM,
                ipuclari: Sequence[str] = (), puan: int = 12,
                cozum: str = "", cozum_bedeli: int = 2) -> Adim:
    secenekler, indeks = siklar(rastgele, dogru, yanlislar)
    return Adim(
        soru=soru, tur=SECIM, rol=rol, secenekler=secenekler, cevap=indeks,
        aciklama=aciklama, ipuclari=list(ipuclari), puan=puan,
        cozum=cozum, cozum_bedeli=cozum_bedeli,
        yanlis_teshis={k: v for k, v in _teshis_sozlugu(yanlislar).items()
                       if k in secenekler and k != dogru},
    )


def yorum_adimi(soru: str, dogru: str, yanlislar: Yanlislar,
                rastgele: random.Random, aciklama: str,
                ipuclari: Sequence[str] = (), puan: int = 10,
                cozum: str = "") -> Adim:
    """Sonucu üssün gerçekliğine bağlayan adım: 'bu sayı ne anlama geliyor?'"""
    return secim_adimi(soru, dogru, yanlislar, rastgele, aciklama,
                       rol=YORUM, ipuclari=ipuclari, puan=puan, cozum=cozum)


def metin_adimi(soru: str, cevap, aciklama: str, ipuclari: Sequence[str] = (),
                puan: int = 12, rol: str = COZUM, cozum: str = "") -> Adim:
    return Adim(
        soru=soru, tur=METIN, rol=rol, cevap=cevap, aciklama=aciklama,
        ipuclari=list(ipuclari), puan=puan, cozum=cozum,
    )


def coklu_adimi(soru: str, secenekler: Sequence[str], dogru_indeksler: Sequence[int],
                aciklama: str, ipuclari: Sequence[str] = (), puan: int = 15,
                rol: str = COZUM, cozum: str = "") -> Adim:
    return Adim(
        soru=soru, tur=COKLU, rol=rol, secenekler=list(secenekler),
        cevap=list(dogru_indeksler), aciklama=aciklama,
        ipuclari=list(ipuclari), puan=puan, cozum=cozum,
    )


def sirala_adimi(soru: str, secenekler: Sequence[str], dogru_sira: Sequence[int],
                 aciklama: str, ipuclari: Sequence[str] = (), puan: int = 15,
                 rol: str = COZUM, cozum: str = "") -> Adim:
    return Adim(
        soru=soru, tur=SIRALA, rol=rol, secenekler=list(secenekler),
        cevap=list(dogru_sira), aciklama=aciklama, ipuclari=list(ipuclari),
        puan=puan, cozum=cozum,
    )


# --------------------------------------------------------------------------
# Sayı biçimleme (anlatı içinde kullanmak için)
# --------------------------------------------------------------------------

def sy(deger) -> str:
    """Sayıyı Türkçe yazımıyla metne çevirir: 12.5 -> '12,5', 12.0 -> '12'."""
    try:
        sayi = float(deger)
    except (TypeError, ValueError):
        return str(deger)
    if abs(sayi - round(sayi)) < 1e-9:
        return str(int(round(sayi)))
    return ("{:.4f}".format(sayi)).rstrip("0").rstrip(".").replace(".", ",")


def zorluk_katsayisi(kademe: int) -> float:
    """Kademeye göre sayıları büyütmek için basit ölçek."""
    return 1.0 + 0.35 * max(0, kademe - 4)
