# -*- coding: utf-8 -*-
"""
Telsiz: sinif sunucusunun mesajlasma katmani (ucler `/telsiz/...`).

Kanallar (her biri ayri mesaj akisi):
  sinif    : ayni sinif kodunu girenler.
  okul     : ayni okuldaki (sinif kaydindaki okul adi ayni) siniflar. Okul
             ADI ogrenciye hic gosterilmez (B41); yalniz "Okul" yazar.
  ogretmen : ogrenci <-> ogretmen. Ogrenci YALNIZ kendi mesajlarini ve
             ogretmenin ona (ya da herkese) yazdiklarini gorur; baska
             ogrencinin ogretmene yazdigini goremez.
  ozel     : arkadas kanali. Acan ogrenciye bir FREKANS (ornek 147.250)
             cikar; arkadaslari numarayi girerek katilir. Ogrenci basina
             en cok OZEL_HAK acik kanal; kanal OZEL_OMRU_SAAT sonra kendiliginden
             kapanir. Kanal sinifa baglidir: baska sinifin frekansi calismaz.

GUVENLIK (ogrenciler resit degil; bunlar ZORUNLU)
-------------------------------------------------
* Ogretmen (sinif anahtari) sinifindaki BUTUN kanallari, ozel olanlar dahil,
  okur; kanal kapatir; mesaj siler; serbest yaziyi kapatip yalniz hazir
  mesajlara indirir; ozel kanal acmayi kapatir; bildirilenleri gorur.
* Her mesaj sunucuda suzulur (oyun/motor/telsiz_suzgec.py): telefon, e-posta,
  adres, kullanici adi, baglanti, TC no, kufur. Suzulen mesaj HICBIR YERE
  YAZILMAZ (icinde kisisel bilgi olabilir); yalniz sayac artar.
* Mesajlarda gercek ad yok; takma ad (yoksa "Kasif-xxxx") gorunur. Sunucu
  oyuncunun gercek adini ya da kayit kimligini hic gormez: istemci kimligi
  tuzlu ozet olarak yollar.
* Her mesajda "bildir": ogretmenin bildirilenler listesine duser.
* Hiz sinirlari (ogrenci ve sinif basina), mesaj boyu siniri, kanal basina
  mesaj siniri, frekans tahmini icin yanlis deneme siniri.
* Saklama: mesajlar MESAJ_OMRU_GUN gun sonra silinir ve okulun saklama suresini
  (okul_ayarlari.saklama_ayi) ASAMAZ. Mesajlar sinif sunucusunda kalir
  (KVKK_VERI_ENVANTERI); oyuncunun kayit dosyasina yazilmaz.

Bu dosya sunucu durumuna (`ortam` = araclar/sinif_sunucusu modulu) sadece
parametre olarak erisir: sunucu betik olarak calisinca `__main__` olur ve
ikinci bir kopya import edilseydi iki ayri veri deposu dogardi.
"""
from __future__ import annotations

import os
import random
import re
import time
from collections import deque
from typing import Any, Dict, List, Optional, Tuple

from oyun.motor import telsiz_suzgec

OZEL_HAK = 3                 # ogrenci basina en cok acik ozel kanal
OZEL_OMRU_SAAT = 48          # ozel kanal ne kadar acik kalir
OZEL_UYE_AZAMI = 8           # bir ozel kanaldaki en cok kisi
KATILIM_AZAMI = 6            # bir ogrencinin katilabildigi (kendi actiklari dahil) kanal
SINIF_OZEL_AZAMI = 80        # sinifta ayni anda acik ozel kanal
MESAJ_AZAMI_BOY = 200
KANAL_AZAMI_MESAJ = 200
MESAJ_OMRU_GUN = 30          # okul saklama suresinden kisa olan gecerli
HIZ_ARALIK = 1.0             # ayni ogrenci iki mesaj arasi (sn)
HIZ_PENCERE = (30.0, 12)     # 30 sn'de en cok 12 mesaj
SINIF_DAKIKA_AZAMI = 300
YANLIS_DENEME = (60.0, 8)    # 60 sn'de 8 yanlis frekans -> bekletilir
AZAMI_UYE = 300
AZAMI_BILDIRILEN = 100

HAZIR = [
    ("yardim", "Yardım lazım"),
    ("bitirdim", "Bu görevi bitirdim"),
    ("kanit", "Hangi kanıta baktın?"),
    ("birlikte", "Birlikte çalışalım mı?"),
    ("ipucu", "Bir ipucu verebilir misin?"),
    ("kontrol", "Cevabımı kontrol eder misin?"),
    ("anladim", "Anladım, teşekkürler"),
    ("anlamadim", "Anlamadım, tekrar anlatır mısın?"),
    ("aferin", "Aferin, güzel çözüm!"),
    ("hazirim", "Hazırım"),
    ("sonra", "Sonra konuşalım"),
    ("tesekkur", "Teşekkürler!"),
]
_HAZIR_SOZLUK = dict(HAZIR)

KANAL_ADLARI = {"sinif": "Sınıf", "okul": "Okul", "ogretmen": "Öğretmen"}

_SIMDI = time.time          # testler degistirir
_HIZ: Dict[Tuple[str, str], deque] = {}
_SINIF_HIZ: Dict[str, deque] = {}
_YANLIS: Dict[Tuple[str, str], deque] = {}
_SON_SUPUR = [0.0]


def simdi() -> float:
    return _SIMDI()


# ------------------------------------------------------------------ yardimci
def mesaj_omru_sn() -> float:
    gun = MESAJ_OMRU_GUN
    try:
        from araclar import okul_ayarlari
        gun = min(gun, okul_ayarlari.saklama_ayi() * 30)
    except Exception:          # noqa: BLE001 - ayar okunamazsa varsayilan
        pass
    return gun * 86400.0


def _yasak_dosyasi(ortam) -> str:
    d = getattr(ortam, "_DOSYA", "")
    return os.path.join(os.path.dirname(d), "telsiz_yasak.txt") if d else ""


def _okul_anahtari(ad: str) -> str:
    return re.sub(r"\s+", " ", telsiz_suzgec.kucuk(ad or "")).strip()


def _kimlik_gecerli(kimlik: Any) -> bool:
    return isinstance(kimlik, str) and re.fullmatch(r"[A-Za-z0-9_\-]{8,64}", kimlik) is not None


def frekans_coz(girdi: Any) -> str:
    """'147,250', '147 250', '147250' -> '147.250'; gecersizse ''."""
    d = re.sub(r"\D", "", str(girdi or ""))
    if len(d) != 6 or not "140" <= d[:3] <= "149":
        return ""
    return d[:3] + "." + d[3:]


def _bos_telsiz() -> Dict[str, Any]:
    return {"serbest": True, "ozel_acik": True, "uyeler": {},
            "kanallar": {"sinif": {"m": [], "no": 0}, "ogretmen": {"m": [], "no": 0}},
            "ozel": {}, "bildirilen": [], "suzulen": 0}


def _t(kayit: Dict[str, Any]) -> Dict[str, Any]:
    t = kayit.get("telsiz")
    if not isinstance(t, dict):
        t = kayit["telsiz"] = _bos_telsiz()
    for anahtar, deger in _bos_telsiz().items():          # eski kayitlara eksik alan
        t.setdefault(anahtar, deger)
    return t


def _okul_kanali(ortam, kayit: Dict[str, Any], olustur: bool = False) -> Optional[Dict[str, Any]]:
    anahtar = _okul_anahtari(kayit.get("okul", ""))
    if not anahtar:
        return None
    depo = ortam._VERI.setdefault("_okul", {}) if olustur else ortam._VERI.get("_okul", {})
    kanal = depo.get(anahtar)
    if kanal is None and olustur:
        kanal = depo[anahtar] = {"m": [], "no": 0}
    if kanal is not None:
        _supur_kanal(kanal, simdi() - mesaj_omru_sn())
    return kanal


# ------------------------------------------------------------------ saklama
def _supur_kanal(kanal: Dict[str, Any], sinir: float) -> None:
    kanal["m"] = [m for m in kanal.get("m", []) if m.get("t", 0) >= sinir][-KANAL_AZAMI_MESAJ:]


def _supur(ortam, kayit: Dict[str, Any], su_an: float) -> None:
    t = _t(kayit)
    sinir = su_an - mesaj_omru_sn()
    for k in t["kanallar"].values():
        _supur_kanal(k, sinir)
    for frekans in [f for f, o in t["ozel"].items() if o.get("bitis", 0) <= su_an]:
        t["ozel"].pop(frekans, None)                  # suresi dolan kanal kapanir
    for o in t["ozel"].values():
        _supur_kanal(o, sinir)
    t["bildirilen"] = [b for b in t["bildirilen"] if b.get("t", 0) >= sinir]
    for kimlik in [k for k, u in t["uyeler"].items() if u.get("son", 0) < sinir]:
        t["uyeler"].pop(kimlik, None)


def genel_supur(ortam, su_an: Optional[float] = None) -> None:
    """Butun siniflarin ve okul kanallarinin suresi dolanlarini temizler."""
    su_an = simdi() if su_an is None else su_an
    sinir = su_an - mesaj_omru_sn()
    for kod, kayit in list(ortam._VERI.items()):
        if kod == "_okul":
            for kanal in kayit.values():
                _supur_kanal(kanal, sinir)
        elif isinstance(kayit, dict) and "telsiz" in kayit:
            _supur(ortam, kayit, su_an)
    ortam._kaydet()


def _arada_supur(ortam) -> None:
    su_an = simdi()
    if su_an - _SON_SUPUR[0] > 300:
        _SON_SUPUR[0] = su_an
        genel_supur(ortam, su_an)


# ------------------------------------------------------------------ kimlik
def _takma_coz(ortam, t: Dict[str, Any], kimlik: str, istenen: Any) -> str:
    """Takma adi dogrular; kisisel bilgi/kufur/ogretmen taklidi ise 'Kasif-xxxx'."""
    varsayilan = "Kâşif-" + kimlik[:4].upper()
    ad = telsiz_suzgec.temizle(str(istenen or ""))[:24]
    if not ad or telsiz_suzgec.kucuk(ad) in ("öğretmen", "ogretmen", "hoca", "yönetici", "yonetici"):
        ad = varsayilan
    elif not telsiz_suzgec.takma_ad_uygun_mu(ad, _yasak_dosyasi(ortam)):
        ad = varsayilan
    kayitli = t["uyeler"].get(kimlik, {}).get("takma")
    if kayitli and telsiz_suzgec.kucuk(kayitli) == telsiz_suzgec.kucuk(ad):
        return kayitli
    kucuk_adlar = {telsiz_suzgec.kucuk(u.get("takma", "")) for k, u in t["uyeler"].items() if k != kimlik}
    if telsiz_suzgec.kucuk(ad) in kucuk_adlar:
        ad = "{}-{}".format(ad[:20], kimlik[:2].upper())
    return ad


def _ogrenci(ortam, veri: Dict[str, Any]):
    """Sinif + ogrenci dogrulamasi -> (kayit, t, kimlik, takma) ya da (hata, None, ..)."""
    kayit = ortam._sinif(veri.get("kod", ""))
    if kayit is None:
        return {"tamam": False, "neden": "sinif_yok"}, None, "", ""
    kimlik = veri.get("kimlik", "")
    if not _kimlik_gecerli(kimlik):
        return {"tamam": False, "neden": "kimlik_yok"}, None, "", ""
    t = _t(kayit)
    su_an = simdi()
    _supur(ortam, kayit, su_an)
    if kimlik not in t["uyeler"] and len(t["uyeler"]) >= AZAMI_UYE:
        return {"tamam": False, "neden": "sinif_dolu"}, None, "", ""
    takma = _takma_coz(ortam, t, kimlik, veri.get("takma"))
    t["uyeler"][kimlik] = {"takma": takma, "son": su_an}
    return kayit, t, kimlik, takma


def _hiz_asildi(kod: str, kimlik: str) -> bool:
    su_an = simdi()
    kayit = _HIZ.setdefault((kod, kimlik), deque())
    pencere, azami = HIZ_PENCERE
    while kayit and su_an - kayit[0] > pencere:
        kayit.popleft()
    sinif = _SINIF_HIZ.setdefault(kod, deque())
    while sinif and su_an - sinif[0] > 60:
        sinif.popleft()
    if (kayit and su_an - kayit[-1] < HIZ_ARALIK) or len(kayit) >= azami or len(sinif) >= SINIF_DAKIKA_AZAMI:
        return True
    kayit.append(su_an)
    sinif.append(su_an)
    return False


# ------------------------------------------------------------------ kanallar
def _kanal_ad(kanal_id: str) -> str:
    return KANAL_ADLARI.get(kanal_id) or "Özel " + kanal_id


def _kanal_bul(ortam, kayit, t, kanal_id: str, kimlik: Optional[str]):
    """Kanal sozlugunu dondurur. kimlik None = ogretmen (hepsini gorur)."""
    if kanal_id == "sinif":
        return t["kanallar"]["sinif"]
    if kanal_id == "ogretmen":
        return t["kanallar"]["ogretmen"]
    if kanal_id == "okul":
        return _okul_kanali(ortam, kayit, olustur=True)
    frekans = frekans_coz(kanal_id)
    o = t["ozel"].get(frekans) if frekans else None
    if o is None:
        return None
    if kimlik is not None and kimlik not in o["uyeler"]:
        return None
    return o


def _gorunur(m: Dict[str, Any], kanal_id: str, kimlik: str) -> bool:
    if kanal_id != "ogretmen":
        return True
    if m.get("k") == kimlik:
        return True
    return bool(m.get("ogr")) and (not m.get("kime") or kimlik.startswith(m["kime"]))


def _ogrenci_gorunumu(m: Dict[str, Any], kimlik: str) -> Dict[str, Any]:
    return {"no": m["no"], "t": m["t"], "takma": m["takma"], "metin": m["metin"],
            "benim": m.get("k") == kimlik, "ogretmen": bool(m.get("ogr")),
            "hazir": bool(m.get("hazir"))}


def _son_no(kanal: Optional[Dict[str, Any]], kanal_id: str, kimlik: str) -> int:
    if not kanal:
        return 0
    gor = [m["no"] for m in kanal["m"] if _gorunur(m, kanal_id, kimlik)]
    return gor[-1] if gor else 0


def _acik_ozel_sayisi(t: Dict[str, Any], kimlik: str) -> int:
    return sum(1 for o in t["ozel"].values() if o.get("sahip") == kimlik)


def _katildigi(t: Dict[str, Any], kimlik: str) -> List[str]:
    return sorted(f for f, o in t["ozel"].items() if kimlik in o["uyeler"])


def _ayar_ozeti(t: Dict[str, Any]) -> Dict[str, Any]:
    return {"serbest": bool(t["serbest"]), "ozel_acik": bool(t["ozel_acik"])}


# ------------------------------------------------------------------ ogrenci isleri
def kanallar(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        _arada_supur(ortam)
        kayit, t, kimlik, takma = _ogrenci(ortam, veri)
        if t is None:
            return 404, kayit
        liste = [{"id": "sinif", "ad": "Sınıf", "tur": "sinif",
                  "son": _son_no(t["kanallar"]["sinif"], "sinif", kimlik)}]
        if kayit.get("okul"):
            liste.append({"id": "okul", "ad": "Okul", "tur": "okul",
                          "son": _son_no(_okul_kanali(ortam, kayit), "okul", kimlik)})
        liste.append({"id": "ogretmen", "ad": "Öğretmen", "tur": "ogretmen",
                      "son": _son_no(t["kanallar"]["ogretmen"], "ogretmen", kimlik)})
        for f in _katildigi(t, kimlik):
            o = t["ozel"][f]
            liste.append({"id": f, "ad": o.get("ad") or "Özel kanal", "tur": "ozel",
                          "sahip": o["sahip"] == kimlik, "uye": len(o["uyeler"]),
                          "bitis": o["bitis"], "son": _son_no(o, f, kimlik)})
        ortam._kaydet()
        return 200, {"tamam": True, "ben": takma, "kanallar": liste, "ayar": _ayar_ozeti(t),
                     "hak": {"acilan": _acik_ozel_sayisi(t, kimlik), "azami": OZEL_HAK},
                     "hazir": [{"id": i, "metin": m} for i, m in HAZIR],
                     "azami_boy": MESAJ_AZAMI_BOY, "saat": simdi()}


def mesajlar(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t, kimlik, takma = _ogrenci(ortam, veri)
        if t is None:
            return 404, kayit
        kanal_id = str(veri.get("kanal", ""))
        kanal = _kanal_bul(ortam, kayit, t, kanal_id, kimlik) if kanal_id else None
        if kanal is None:
            return 200, {"tamam": False, "neden": "kanal_yok"}
        try:
            sonra = int(veri.get("sonra", -1))
        except (TypeError, ValueError):
            sonra = -1
        gor = [m for m in kanal["m"] if _gorunur(m, kanal_id, kimlik)]
        gor = [m for m in gor if m["no"] > sonra] if sonra >= 0 else gor[-50:]
        return 200, {"tamam": True, "mesajlar": [_ogrenci_gorunumu(m, kimlik) for m in gor],
                     "son": _son_no(kanal, kanal_id, kimlik), "ayar": _ayar_ozeti(t)}


def _mesaj_ekle(kanal: Dict[str, Any], **alanlar) -> Dict[str, Any]:
    kanal["no"] = kanal.get("no", 0) + 1
    m = dict(alanlar, no=kanal["no"], t=simdi())
    kanal["m"].append(m)
    del kanal["m"][:-KANAL_AZAMI_MESAJ]
    return m


def gonder(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t, kimlik, takma = _ogrenci(ortam, veri)
        if t is None:
            return 404, kayit
        kanal_id = str(veri.get("kanal", ""))
        kanal = _kanal_bul(ortam, kayit, t, kanal_id, kimlik) if kanal_id else None
        if kanal is None:
            return 200, {"tamam": False, "neden": "kanal_yok"}
        kod = (veri.get("kod") or "").strip().upper()
        hazir_id = veri.get("hazir")
        hazir = False
        if hazir_id:
            metin = _HAZIR_SOZLUK.get(str(hazir_id))
            if metin is None:
                return 200, {"tamam": False, "neden": "hazir_yok"}
            hazir = True
        else:
            if not t["serbest"]:
                return 200, {"tamam": False, "neden": "serbest_kapali",
                             "uyari": "Öğretmenin şu an yalnız hazır mesajlara izin veriyor."}
            metin = telsiz_suzgec.temizle(str(veri.get("metin") or ""))
            if len(metin) > MESAJ_AZAMI_BOY:
                return 200, {"tamam": False, "neden": "cok_uzun",
                             "uyari": "Mesaj çok uzun (en çok {} harf).".format(MESAJ_AZAMI_BOY)}
        if _hiz_asildi(kod, kimlik):
            return 200, {"tamam": False, "neden": "cok_hizli", "uyari": "Biraz yavaş: birazdan tekrar dene."}
        if not hazir:
            sonuc = telsiz_suzgec.incele(metin, _yasak_dosyasi(ortam))
            if not sonuc.ok:
                t["suzulen"] += 1                   # metin KAYDEDILMEZ
                ortam._kaydet()
                return 200, {"tamam": False, "neden": "suzuldu", "tur": sonuc.tur,
                             "uyari": sonuc.uyari}
        son = [m for m in kanal["m"][-5:] if m.get("k") == kimlik]
        if son and son[-1]["metin"] == metin and simdi() - son[-1]["t"] < 10:
            return 200, {"tamam": False, "neden": "tekrar", "uyari": "Aynı mesajı yeni gönderdin."}
        m = _mesaj_ekle(kanal, k=kimlik, takma=takma, metin=metin, hazir=int(hazir), s=kod)
        ortam._kaydet()
        return 200, {"tamam": True, "no": m["no"]}


def ozel_ac(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t, kimlik, takma = _ogrenci(ortam, veri)
        if t is None:
            return 404, kayit
        if not t["ozel_acik"]:
            return 200, {"tamam": False, "neden": "ozel_kapali",
                         "uyari": "Öğretmenin özel kanal açmayı şu an kapattı."}
        if _acik_ozel_sayisi(t, kimlik) >= OZEL_HAK:
            return 200, {"tamam": False, "neden": "hak_doldu",
                         "uyari": "En çok {} özel kanal açabilirsin. Birini kapat.".format(OZEL_HAK)}
        if len(_katildigi(t, kimlik)) >= KATILIM_AZAMI:
            return 200, {"tamam": False, "neden": "cok_kanal", "uyari": "Çok fazla kanaldasın."}
        if len(t["ozel"]) >= SINIF_OZEL_AZAMI:
            return 200, {"tamam": False, "neden": "sinif_dolu", "uyari": "Sınıfta açık özel kanal çok."}
        kullanilan = set(t["ozel"])
        frekans = ""
        rng = random.SystemRandom()
        for _ in range(60):
            n = rng.randrange(10000)
            aday = "{}.{:03d}".format(140 + n // 1000, n % 1000)
            if aday not in kullanilan:
                frekans = aday
                break
        if not frekans:
            return 200, {"tamam": False, "neden": "sinif_dolu"}
        ad = telsiz_suzgec.temizle(str(veri.get("ad") or ""))[:20]
        if ad and not telsiz_suzgec.incele(ad, _yasak_dosyasi(ortam)).ok:
            ad = ""
        su_an = simdi()
        t["ozel"][frekans] = {"ad": ad or "Özel kanal", "sahip": kimlik, "uyeler": [kimlik],
                              "acilis": su_an, "bitis": su_an + OZEL_OMRU_SAAT * 3600,
                              "m": [], "no": 0}
        ortam._kaydet()
        return 200, {"tamam": True, "frekans": frekans, "bitis": t["ozel"][frekans]["bitis"],
                     "kalan_hak": OZEL_HAK - _acik_ozel_sayisi(t, kimlik)}


def katil(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t, kimlik, takma = _ogrenci(ortam, veri)
        if t is None:
            return 404, kayit
        kod = (veri.get("kod") or "").strip().upper()
        su_an = simdi()
        denemeler = _YANLIS.setdefault((kod, kimlik), deque())
        while denemeler and su_an - denemeler[0] > YANLIS_DENEME[0]:
            denemeler.popleft()
        if len(denemeler) >= YANLIS_DENEME[1]:
            return 200, {"tamam": False, "neden": "cok_deneme",
                         "uyari": "Çok fazla yanlış numara denedin. Bir dakika bekle."}
        frekans = frekans_coz(veri.get("frekans"))
        o = t["ozel"].get(frekans) if frekans else None
        if o is None:
            denemeler.append(su_an)
            return 200, {"tamam": False, "neden": "bulunamadi",
                         "uyari": "Bu numarada açık bir kanal yok."}
        if kimlik not in o["uyeler"]:
            if len(o["uyeler"]) >= OZEL_UYE_AZAMI:
                return 200, {"tamam": False, "neden": "kanal_dolu", "uyari": "Kanal dolu."}
            if len(_katildigi(t, kimlik)) >= KATILIM_AZAMI:
                return 200, {"tamam": False, "neden": "cok_kanal", "uyari": "Çok fazla kanaldasın."}
            o["uyeler"].append(kimlik)
            ortam._kaydet()
        return 200, {"tamam": True, "frekans": frekans, "ad": o["ad"]}


def _kapat(t: Dict[str, Any], frekans: str) -> bool:
    return t["ozel"].pop(frekans, None) is not None


def kapat(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    """Ogrenci kendi actigi kanali kapatir (baskasininkini kapatamaz)."""
    with ortam._KILIT:
        kayit, t, kimlik, takma = _ogrenci(ortam, veri)
        if t is None:
            return 404, kayit
        frekans = frekans_coz(veri.get("frekans"))
        o = t["ozel"].get(frekans) if frekans else None
        if o is None or o["sahip"] != kimlik:
            return 200, {"tamam": False, "neden": "yetki_yok"}
        _kapat(t, frekans)
        ortam._kaydet()
        return 200, {"tamam": True}


def ayril(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t, kimlik, takma = _ogrenci(ortam, veri)
        if t is None:
            return 404, kayit
        frekans = frekans_coz(veri.get("frekans"))
        o = t["ozel"].get(frekans) if frekans else None
        if o is None or kimlik not in o["uyeler"]:
            return 200, {"tamam": False, "neden": "kanal_yok"}
        if o["sahip"] == kimlik:
            _kapat(t, frekans)                       # sahip ayrilirsa kanal kapanir
        else:
            o["uyeler"].remove(kimlik)
        ortam._kaydet()
        return 200, {"tamam": True}


def bildir(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t, kimlik, takma = _ogrenci(ortam, veri)
        if t is None:
            return 404, kayit
        kanal_id = str(veri.get("kanal", ""))
        kanal = _kanal_bul(ortam, kayit, t, kanal_id, kimlik) if kanal_id else None
        try:
            no = int(veri.get("no"))
        except (TypeError, ValueError):
            no = -1
        m = next((x for x in (kanal or {"m": []})["m"] if x["no"] == no and _gorunur(x, kanal_id, kimlik)), None)
        if m is None or m.get("k") == kimlik or m.get("ogr"):
            return 200, {"tamam": False, "neden": "mesaj_yok"}
        if any(b["kanal"] == kanal_id and b["mesaj_no"] == no and b["bildiren_uid"] == kimlik[:8]
               for b in t["bildirilen"]):
            return 200, {"tamam": True, "tekrar": True}
        if len(t["bildirilen"]) >= AZAMI_BILDIRILEN:
            del t["bildirilen"][0]
        t["bildirilen"].append({"id": "{}-{}".format(int(simdi()), len(t["bildirilen"])),
                                "kanal": kanal_id, "kanal_ad": _kanal_ad(kanal_id),
                                "mesaj_no": no, "metin": m["metin"], "takma": m["takma"],
                                "yazan_uid": (m.get("k") or "")[:8], "t": simdi(),
                                "bildiren": takma, "bildiren_uid": kimlik[:8]})
        ortam._kaydet()
        return 200, {"tamam": True}


# ------------------------------------------------------------------ ogretmen isleri
def _ogretmen(ortam, veri):
    kayit = ortam._sinif(veri.get("kod", ""))
    if kayit is None or not ortam._yetkili(kayit, veri.get("anahtar", "")):
        return None, None
    t = _t(kayit)
    _supur(ortam, kayit, simdi())
    return kayit, t


_YASAK = (403, {"tamam": False, "neden": "yetki_yok"})


def ogretmen_kanallar(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t = _ogretmen(ortam, veri)
        if t is None:
            return _YASAK
        liste = [{"id": "sinif", "ad": "Sınıf", "tur": "sinif", "mesaj": len(t["kanallar"]["sinif"]["m"])},
                 {"id": "ogretmen", "ad": "Öğretmen", "tur": "ogretmen",
                  "mesaj": len(t["kanallar"]["ogretmen"]["m"])}]
        ok = _okul_kanali(ortam, kayit)
        if kayit.get("okul"):
            liste.append({"id": "okul", "ad": "Okul", "tur": "okul", "mesaj": len(ok["m"]) if ok else 0})
        for f, o in sorted(t["ozel"].items()):
            adlar = [t["uyeler"].get(k, {}).get("takma", "?") for k in o["uyeler"]]
            liste.append({"id": f, "ad": o["ad"], "tur": "ozel", "mesaj": len(o["m"]),
                          "sahip": t["uyeler"].get(o["sahip"], {}).get("takma", "?"),
                          "uyeler": adlar, "bitis": o["bitis"]})
        uyeler = [{"takma": u["takma"], "uid": k[:8], "son": u["son"]} for k, u in t["uyeler"].items()]
        return 200, {"tamam": True, "kanallar": liste, "ayar": _ayar_ozeti(t),
                     "bildirilen": len(t["bildirilen"]), "suzulen": t["suzulen"],
                     "uyeler": sorted(uyeler, key=lambda u: u["takma"].lower()), "saat": simdi()}


def _ogretmen_kanal(ortam, kayit, t, kanal_id: str):
    return _kanal_bul(ortam, kayit, t, kanal_id, None) if kanal_id else None


def ogretmen_mesajlar(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t = _ogretmen(ortam, veri)
        if t is None:
            return _YASAK
        kanal_id = str(veri.get("kanal", ""))
        if kanal_id == "okul" and not kayit.get("okul"):
            return 200, {"tamam": False, "neden": "kanal_yok"}
        kanal = _ogretmen_kanal(ortam, kayit, t, kanal_id)
        if kanal is None:
            return 200, {"tamam": False, "neden": "kanal_yok"}
        try:
            sonra = int(veri.get("sonra", -1))
        except (TypeError, ValueError):
            sonra = -1
        gor = [m for m in kanal["m"] if m["no"] > sonra] if sonra >= 0 else kanal["m"][-100:]
        cikti = [{"no": m["no"], "t": m["t"], "takma": m["takma"], "metin": m["metin"],
                  "ogretmen": bool(m.get("ogr")), "hazir": bool(m.get("hazir")),
                  "uid": (m.get("k") or "")[:8], "kime": m.get("kime", "")} for m in gor]
        return 200, {"tamam": True, "mesajlar": cikti, "son": kanal.get("no", 0)}


def ogretmen_gonder(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t = _ogretmen(ortam, veri)
        if t is None:
            return _YASAK
        kanal_id = str(veri.get("kanal", ""))
        if kanal_id == "okul" and not kayit.get("okul"):
            return 200, {"tamam": False, "neden": "kanal_yok"}
        kanal = _ogretmen_kanal(ortam, kayit, t, kanal_id)
        metin = telsiz_suzgec.temizle(str(veri.get("metin") or ""))
        if kanal is None:
            return 200, {"tamam": False, "neden": "kanal_yok"}
        if not metin or len(metin) > MESAJ_AZAMI_BOY:
            return 200, {"tamam": False, "neden": "metin"}
        kime = re.sub(r"[^A-Za-z0-9_\-]", "", str(veri.get("kime") or ""))[:8]
        m = _mesaj_ekle(kanal, k="ogretmen", takma="Öğretmen", metin=metin, ogr=1,
                        kime=kime if kanal_id == "ogretmen" else "")
        ortam._kaydet()
        return 200, {"tamam": True, "no": m["no"]}


def ogretmen_kapat(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t = _ogretmen(ortam, veri)
        if t is None:
            return _YASAK
        frekans = frekans_coz(veri.get("frekans"))
        ok = bool(frekans) and _kapat(t, frekans)
        ortam._kaydet()
        return 200, {"tamam": ok}


def ogretmen_ayar(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t = _ogretmen(ortam, veri)
        if t is None:
            return _YASAK
        for alan in ("serbest", "ozel_acik"):
            if alan in veri:
                t[alan] = bool(veri[alan])
        ortam._kaydet()
        return 200, {"tamam": True, "ayar": _ayar_ozeti(t)}


def ogretmen_bildirilen(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t = _ogretmen(ortam, veri)
        if t is None:
            return _YASAK
        return 200, {"tamam": True, "bildirilen": list(reversed(t["bildirilen"]))}


def ogretmen_bildirilen_sil(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    with ortam._KILIT:
        kayit, t = _ogretmen(ortam, veri)
        if t is None:
            return _YASAK
        once = len(t["bildirilen"])
        t["bildirilen"] = [b for b in t["bildirilen"] if b["id"] != veri.get("id")]
        ortam._kaydet()
        return 200, {"tamam": len(t["bildirilen"]) < once}


def ogretmen_mesaj_sil(ortam, veri) -> Tuple[int, Dict[str, Any]]:
    """Mesaji siler. Okul kanalinda yalniz kendi sinifinin mesaji ya da kendi
    sinifinin bildirdigi mesaj silinebilir (baska sinifin ogretmeni degil)."""
    with ortam._KILIT:
        kayit, t = _ogretmen(ortam, veri)
        if t is None:
            return _YASAK
        kanal_id = str(veri.get("kanal", ""))
        kanal = _ogretmen_kanal(ortam, kayit, t, kanal_id)
        try:
            no = int(veri.get("no"))
        except (TypeError, ValueError):
            no = -1
        if kanal is None:
            return 200, {"tamam": False, "neden": "kanal_yok"}
        kod = (veri.get("kod") or "").strip().upper()
        for m in kanal["m"]:
            if m["no"] != no:
                continue
            if kanal_id == "okul":
                kendi = m.get("s") == kod or any(
                    b["kanal"] == "okul" and b["mesaj_no"] == no for b in t["bildirilen"])
                if not kendi:
                    return 200, {"tamam": False, "neden": "yetki_yok"}
            kanal["m"].remove(m)
            ortam._kaydet()
            return 200, {"tamam": True}
        return 200, {"tamam": False, "neden": "mesaj_yok"}


_OGRENCI_UCLARI = {
    ("GET", "/telsiz/kanallar"): kanallar,
    ("GET", "/telsiz/mesajlar"): mesajlar,
    ("POST", "/telsiz/gonder"): gonder,
    ("POST", "/telsiz/ozel_ac"): ozel_ac,
    ("POST", "/telsiz/katil"): katil,
    ("POST", "/telsiz/ayril"): ayril,
    ("POST", "/telsiz/kapat"): kapat,
    ("POST", "/telsiz/bildir"): bildir,
    ("GET", "/telsiz/ogretmen/kanallar"): ogretmen_kanallar,
    ("GET", "/telsiz/ogretmen/mesajlar"): ogretmen_mesajlar,
    ("GET", "/telsiz/ogretmen/bildirilen"): ogretmen_bildirilen,
    ("POST", "/telsiz/ogretmen/gonder"): ogretmen_gonder,
    ("POST", "/telsiz/ogretmen/kapat"): ogretmen_kapat,
    ("POST", "/telsiz/ogretmen/ayar"): ogretmen_ayar,
    ("POST", "/telsiz/ogretmen/bildirilen_sil"): ogretmen_bildirilen_sil,
    ("POST", "/telsiz/ogretmen/mesaj_sil"): ogretmen_mesaj_sil,
}


def uc_mu(yol: str) -> bool:
    return yol.startswith("/telsiz/")


def dispatch(ortam, yontem: str, yol: str, sorgu: Dict[str, str],
             govde: Dict[str, Any]) -> Tuple[int, Dict[str, Any]]:
    islev = _OGRENCI_UCLARI.get((yontem, yol))
    if islev is None:
        return 404, {"tamam": False}
    veri = dict(sorgu if yontem == "GET" else govde)
    return islev(ortam, veri)
