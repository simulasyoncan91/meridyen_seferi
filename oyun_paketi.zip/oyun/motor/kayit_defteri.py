# -*- coding: utf-8 -*-
"""
Bulmaca kayıt defteri (registry).

Oyuna yeni soru eklemenin tek yolu burasıdır ve tek satırlık bir iştir:

    from oyun.motor.kayit_defteri import bulmaca

    @bulmaca(ders="matematik", konu="denklem", kademeler=(6, 8))
    def depo_sayimi(rastgele, kademe):
        ...
        return Bulmaca(...)

Fonksiyon her çağrıldığında *yeni bir örnek* üretir: sayılar rastgeledir, yani
öğrenci aynı görevi ikinci kez oynadığında ezberi işe yaramaz. `rastgele`
tohumlanmış bir random.Random'dır; aynı tohum aynı bulmacayı verir, bu da
gösterimde tekrarlanabilirlik sağlar.
"""
from __future__ import annotations

import importlib
import pkgutil
import random
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from .modeller import Bulmaca, DERSLER, Sefer

Uretici = Callable[[random.Random, int], Bulmaca]


@dataclass
class UreticiKayit:
    fonksiyon: Uretici
    ders: str
    konu: str
    kademeler: Tuple[int, int]
    etiketler: Tuple[str, ...] = ()
    agirlik: float = 1.0
    ad: str = ""

    def kapsar(self, kademe: int) -> bool:
        return self.kademeler[0] <= kademe <= self.kademeler[1]


_KAYITLAR: List[UreticiKayit] = []
_YUKLENDI = False
YUKLEME_HATALARI: List[Tuple[str, str]] = []


def bulmaca(ders: str, konu: str, kademeler: Tuple[int, int] = (1, 13),
            etiketler: Sequence[str] = (), agirlik: float = 1.0):
    """Bir bulmaca üreticisini kayıt defterine ekleyen süsleyici."""
    if ders not in DERSLER:
        raise ValueError("Bilinmeyen ders: {} (geçerli: {})".format(ders, DERSLER))
    alt, ust = int(kademeler[0]), int(kademeler[1])
    if not (1 <= alt <= ust <= 13):
        raise ValueError("kademeler (alt, ust) ve 1..13 aralığında olmalı: {}".format(kademeler))
    def sarmala(fonksiyon: Uretici) -> Uretici:
        _KAYITLAR.append(UreticiKayit(
            fonksiyon=fonksiyon,
            ders=ders,
            konu=konu,
            kademeler=(alt, ust),
            etiketler=tuple(etiketler),
            agirlik=float(agirlik),
            ad=getattr(fonksiyon, "__name__", "?"),
        ))
        return fonksiyon

    return sarmala


def icerigi_yukle(zorla: bool = False) -> int:
    """
    oyun.icerik altındaki tüm modülleri içe aktarır. Kayıt sayısını döner.

    Bir modül hata verirse oyun çökmez: o modül atlanır, hata YUKLEME_HATALARI
    listesine yazılır. Yeni soru yazan bir öğrencinin yarım kalmış dosyası
    bütün oyunu kilitlemesin diye böyle.
    """
    global _YUKLENDI
    if _YUKLENDI and not zorla:
        return len(_KAYITLAR)
    from oyun import icerik

    del YUKLEME_HATALARI[:]
    for bilgi in pkgutil.iter_modules(icerik.__path__):
        if bilgi.name.startswith("_"):
            continue
        try:
            importlib.import_module("oyun.icerik." + bilgi.name)
        except Exception as sorun:
            YUKLEME_HATALARI.append((bilgi.name, "{}: {}".format(type(sorun).__name__, sorun)))
    _YUKLENDI = True
    return len(_KAYITLAR)


def tum_kayitlar() -> List[UreticiKayit]:
    icerigi_yukle()
    return list(_KAYITLAR)


def uygun_kayitlar(ders: Optional[str] = None, kademe: Optional[int] = None,
                   konu: Optional[str] = None,
                   etiket: Optional[str] = None) -> List[UreticiKayit]:
    icerigi_yukle()
    sonuc = []
    for kayit in _KAYITLAR:
        if ders and kayit.ders != ders:
            continue
        if kademe is not None and not kayit.kapsar(kademe):
            continue
        if konu and kayit.konu != konu:
            continue
        if etiket and etiket not in kayit.etiketler:
            continue
        sonuc.append(kayit)
    return sonuc


def konular(ders: str) -> List[str]:
    """Bir dersteki konu kodlarını tekrarsız ve sıralı döner (konu seçimi için)."""
    gorulen = []
    for kayit in uygun_kayitlar(ders=ders):
        if kayit.konu not in gorulen:
            gorulen.append(kayit.konu)
    return sorted(gorulen)


# İstenen kademe boşsa oyun en yakın dolu kademeye düşer. Bu düşüş sessizdir
# ve küçük farklarda faydalıdır. Ama sınırsız olursa zararlıdır: Keşif düzeyi
# seçen 2. sınıf öğrencisine, o alanda yalnızca lise içeriği yazıldığı için
# 9. sınıf görevi gelir ve çocuk oyunu bırakır. Bu yüzden düşüşe tavan koyuyoruz;
# tavanı aşan alan, o zorlukta hiç açılmaz.
EN_COK_KADEME_SAPMASI = 3


def _en_yakin_kademe(ders: str, kademe: int,
                     konu: Optional[str] = None) -> Optional[int]:
    """
    İstenen kademede içerik yoksa en yakın dolu kademeyi bulur.

    `konu` verilirse arama O KONUYLA sınırlanır. Bu ayrım önemli: bir konu
    yalnızca üst kademelerde yazılmış olabilir (örneğin "sözcükte anlam"
    5-11 arası). Konuyu göz ardı edip dersin genelinde en yakın kademeyi
    bulmak, o konuda hiç görev üretememeye yol açıyordu.

    Bulunan kademe istenenden EN_COK_KADEME_SAPMASI'ndan fazla uzaksa None
    döner: yaşına uymayan bir görev vermektense hiç vermemek yeğdir.
    """
    icerigi_yukle()
    dolu = set()
    for kayit in _KAYITLAR:
        if kayit.ders != ders:
            continue
        if konu and kayit.konu != konu:
            continue
        for k in range(kayit.kademeler[0], kayit.kademeler[1] + 1):
            dolu.add(k)
    if not dolu:
        return None
    en_yakin = min(dolu, key=lambda k: (abs(k - kademe), k))
    if abs(en_yakin - kademe) > EN_COK_KADEME_SAPMASI:
        return None
    return en_yakin


def kademede_acik_mi(ders: str, kademe: int, konu: Optional[str] = None) -> bool:
    """
    Bu alan (ya da konu) verilen kademede oynanabilir mi?

    Menüler bunu sorar: oynanamayacak bir masayı listede göstermek, öğrenciyi
    boş bir kapıya yollamaktır.
    """
    if uygun_kayitlar(ders=ders, kademe=kademe, konu=konu):
        return True
    return _en_yakin_kademe(ders, kademe, konu=konu) is not None


def uret(ders: str, kademe: int, rastgele: Optional[random.Random] = None,
         haric: Iterable[str] = (), konu: Optional[str] = None) -> Optional[Bulmaca]:
    """
    Verilen ders ve kademe için bir bulmaca üretir.

    `haric`, yakın zamanda görülmüş üretici adlarının listesidir; mümkünse
    bunlar seçilmez ki öğrenci arka arkaya aynı görevi almasın.
    """
    rastgele = rastgele or random.Random()
    adaylar = uygun_kayitlar(ders=ders, kademe=kademe, konu=konu)

    if not adaylar:
        # Önce konuyu koruyarak en yakın kademeyi ara; konu bulunamazsa
        # ancak o zaman dersin geneline düş.
        yedek = _en_yakin_kademe(ders, kademe, konu=konu)
        if yedek is not None:
            kademe = yedek
            adaylar = uygun_kayitlar(ders=ders, kademe=kademe, konu=konu)
        if not adaylar and konu:
            yedek = _en_yakin_kademe(ders, kademe)
            if yedek is not None:
                kademe = yedek
                adaylar = uygun_kayitlar(ders=ders, kademe=kademe)
        if not adaylar:
            return None

    haric = set(haric)
    taze = [k for k in adaylar if k.ad not in haric]
    havuz = taze or adaylar

    secilen = rastgele.choices(havuz, weights=[k.agirlik for k in havuz], k=1)[0]
    uretilen = secilen.fonksiyon(rastgele, kademe)
    if uretilen is None:
        return None
    # Üretici kademeyi kendi ayarlamadıysa istenen kademeyi işaretleyelim.
    uretilen.kademe = uretilen.kademe or kademe
    # Alanı KAYIT belirler, üreticinin içine yazdığı değer değil. Bir görev
    # üst üste iki @bulmaca ile iki dala birden kaydedilebiliyor; o zaman
    # fonksiyonun içindeki tek bir `ders` değeri ikisini birden anlatamaz.
    # Damgalamazsak elektrikçinin oynadığı ortak görevin ilerlemesi mobilyaya
    # yazılır. Bkz. TASARIM_NOTLARI.md §5
    uretilen.ders = ders
    setattr(uretilen, "uretici_adi", secilen.ad)
    return uretilen


# --------------------------------------------------------------------------
# Zaman seferleri
# --------------------------------------------------------------------------

SeferUretici = Callable[[random.Random, int], Sefer]


@dataclass
class SeferKaydi:
    fonksiyon: SeferUretici
    kod: str
    kademeler: Tuple[int, int]
    ad: str = ""

    def kapsar(self, kademe: int) -> bool:
        return self.kademeler[0] <= kademe <= self.kademeler[1]


_SEFERLER: List[SeferKaydi] = []


def sefer(kod: str, kademeler: Tuple[int, int] = (5, 13)):
    """
    Çok bölümlü bir zaman seferini kayıt defterine ekleyen süsleyici.

        @sefer(kod="tunc-cagi", kademeler=(6, 10))
        def tunc_cagi_seferi(rastgele, kademe):
            return Sefer(...)
    """
    alt, ust = int(kademeler[0]), int(kademeler[1])

    def sarmala(fonksiyon: SeferUretici) -> SeferUretici:
        _SEFERLER.append(SeferKaydi(
            fonksiyon=fonksiyon, kod=kod, kademeler=(alt, ust),
            ad=getattr(fonksiyon, "__name__", "?"),
        ))
        return fonksiyon

    return sarmala


def sefer_kayitlari(kademe: Optional[int] = None) -> List[SeferKaydi]:
    icerigi_yukle()
    if kademe is None:
        return list(_SEFERLER)
    return [s for s in _SEFERLER if s.kapsar(kademe)]


def sefer_uret(kademe: int, rastgele: Optional[random.Random] = None,
               haric: Iterable[str] = ()) -> Optional[Sefer]:
    """Kademeye uygun bir sefer üretir."""
    rastgele = rastgele or random.Random()
    adaylar = sefer_kayitlari(kademe)
    if not adaylar:
        adaylar = sefer_kayitlari()
    if not adaylar:
        return None
    haric = set(haric)
    taze = [s for s in adaylar if s.kod not in haric] or adaylar
    secilen = rastgele.choice(taze)
    uretilen = secilen.fonksiyon(rastgele, kademe)
    if uretilen is not None:
        setattr(uretilen, "uretici_adi", secilen.ad)
    return uretilen


def kapsama_raporu() -> Dict[str, Dict[int, int]]:
    """Hangi ders/kademe kombinasyonunda kaç üretici var? Boşlukları görmek için."""
    icerigi_yukle()
    rapor: Dict[str, Dict[int, int]] = {ders: {k: 0 for k in range(1, 14)} for ders in DERSLER}
    for kayit in _KAYITLAR:
        for k in range(kayit.kademeler[0], kayit.kademeler[1] + 1):
            rapor[kayit.ders][k] += 1
    return rapor
