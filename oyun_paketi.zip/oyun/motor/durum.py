# -*- coding: utf-8 -*-
"""
Oyun durumu ve kayıt dosyaları.

Durum tamamen JSON'a çevrilebilir tutuldu: harici kütüphane yok, kayıt dosyası
insan tarafından okunabilir. Öğretmen bir öğrencinin kayıt dosyasını açıp
hangi derste hangi kademede olduğunu çıplak gözle görebilir.
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from .modeller import (
    ANLATIM, BIRLIKTE, DERSLER, KADEME_ADLARI, SERBEST, ZORLUK_KADEME,
    kademe_zorlugu, sonraki_asama, onceki_asama,
)

# Kayıtlar varsayılan olarak proje klasörünün altındaki kayitlar/ dizinine
# yazılır. Okulda bilgisayarlar ortak kullanıldığı ve öğrenci her seferinde
# aynı makineye oturamadığı için, bu klasör MERIDYEN_KAYIT ortam değişkeniyle
# ağdaki ortak bir klasöre alınabilir:
#
#     set MERIDYEN_KAYIT=\\sunucu\ogrenci\meridyen      (Windows)
#     export MERIDYEN_KAYIT=/mnt/ortak/meridyen        (Linux)
#
# Böylece öğrenci hangi makineye otursa oturursa kendi seferinden devam eder.
# Dikkat havuzu ayarlari. Bkz. Durum.dikkat_tavani().
DIKKAT_BASLANGIC = 100      # hic konusu oturmamis ogrenci
DIKKAT_TABANI = 18          # her seyi oturtmus ogrenci
# Neden 18: olculdu (5 Eylul 2026). Bir bulmacanin TAM maliyeti (her kanit +
# her cozum) ortalama 10-12,5. Taban 10 olsaydi ustalasmis ogrenci tek bir
# bulmacada bile her seyi acamazdi ve dolum (1-6) tek bulmaca maliyetinin
# altinda kaldigi icin surekli acikta kalirdi.
#
# 25 onerildi, kullanici 18'i secti ve gerekcesi su: dikkat zamanla azaldigi
# icin ogrenci kendisi secici olmayi ogrenir, her soruda butun ipuclarini
# almaya calismaz, elindekini degerlendirmeye baslar. Yani taban "her seyi
# acabilecegin miktar" olmak zorunda degil -- ogrencinin kendi dikkati
# aradaki farki kapatir. Taban, "dogru yere bak" demeli; "hic bakma" degil.
EN_AZ_KONU_ICIN_TAVAN = 5   # bu kadar konu baslanmadan oran hesaplanmaz

# Bir konudaki ustaligin kac kademe yukariya kadar gecerli sayilacagi.
# Bkz. KonuDurumu.oturdugu_kademe ve Durum.oturmus_oran.
#
# Pedagojik gerekce: konu adi ayni kalsa da ayrinti kademeyle artar. 4. sinifta
# "kesirler"i oturtan ogrenci 7. sinif kesirlerini bilmez; ayni ad altinda
# bambaska bir is vardir. Ustalik damgasi olmayinca oturmus konu yillar
# boyunca birikiyor, oturmus_oran 1'e yaklasiyor ve dikkat tavani kalici
# olarak tabanda kaliyordu -- yani sinif atlamanin tavani yukselten duzeltici
# etkisi her yil biraz daha zayifliyordu (bkz. GOREVLER.md B19, Olcum 2).
#
# 2 secildi cunku bir-iki kademelik fark ayni konunun biraz derinlesmis hali
# sayilabilir; ucuncu kademeden sonrasi baska bir konudur ve yeniden
# ogrenilmesi gerekir.
USTALIK_KADEME_TOLERANSI = 2
# Gorev bitince verilen dikkat, gorevin zorluguna gore (1..5)
DIKKAT_DOLUM = {1: 1, 2: 2, 3: 3, 4: 4, 5: 6}

KAYIT_KLASORU = os.environ.get("MERIDYEN_KAYIT") or os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), "kayitlar")

# Koloni döngüsünün para birimi. Şu an yarım bir döngü: kaynaklar görev
# bitince kazanılıyor ama harcanacak yer neredeyse yok (tek gider
# oyun.GOREV_BEDELI). Koloni katmanı -tesis kurma, masa açma, arıza onarma-
# tam olarak bu boşluğu dolduracak.
#
# Yazarken uyulacak kural: kaynak YALNIZCA öğrenerek kazanılır ve YALNIZCA
# öğrenmeye harcanır. Paralel bir üs kurma optimizasyonu eklenirse oyun,
# ödev yapıştırılmış bir tıklama oyununa dönüşür.
# Gerekçesi: TASARIM_NOTLARI.md §3
KAYNAKLAR = ["erzak", "cevher", "enerji", "itibar"]

KAYNAK_ADLARI = {
    "erzak": "Erzak",
    "cevher": "Cevher",
    "enerji": "Enerji",
    "itibar": "İtibar",
}

KAYNAK_SIMGE = {
    "erzak": "E",
    "cevher": "C",
    "enerji": "J",
    "itibar": "İ",
}

# Görev sayısına bağlı sade rütbe sistemi. Eğitim ilerlemesini not gibi değil,
# üste verilen sorumluluk gibi hissettirir.
RUTBELER = [
    (0, "Aday Kâşif"),
    (3, "Saha Kâtibi"),
    (8, "İz Sürücü"),
    (15, "Sefer Uzmanı"),
    (28, "Meridyen Muhafızı"),
]


@dataclass
class KonuDurumu:
    """
    Tek bir konudaki ilerleme.

    Oyunun asıl birimi budur: öğrenci "matematikte" değil, "denklem kurmada"
    zorlanır. Aşama, o konuyu hangi destek düzeyinde çalıştığını gösterir.
    """
    asama: str = ANLATIM
    anlatim_sayisi: int = 0
    birlikte_sayisi: int = 0
    serbest_dogru: int = 0
    serbest_toplam: int = 0
    ustalik: float = 0.0
    ust_uste_zorlanma: int = 0
    # Konunun HANGI kademede oturdugu. 0 = hic olculmedi; eski kayitlar ve
    # henuz oturmamis konular buradadir. Ustaligin "hala gecerli" olup
    # olmadigina bu alan karar verir (bkz. USTALIK_KADEME_TOLERANSI).
    oturdugu_kademe: int = 0
    # Damganin vuruldugu andaki serbest deneme sayisi. Tek isi, konunun
    # damgadan SONRA yeniden calisilip calisilmadigini anlamak: serbest_toplam
    # bu sayidan buyukse ogrenci konuyu yeni kademede tekrar sinamis demektir
    # ve damga o kademeye tasinabilir. Bu olmadan bir konu, bir kez eski
    # kademede damgalandiktan sonra bir daha asla "oturmus" sayilamazdi.
    damga_serbest_toplam: int = 0
    son_calisma_gunu: str = ""
    tekrar_gunu: str = ""
    tekrar_basamagi: int = 0
    tekrar_kademesi: int = 0
    zorlanma: float = 0.0
    zorlanma_gozlemi: int = 0

    @property
    def tamamlandi(self) -> bool:
        """Kendi başına en az iki kez iyi geçtiyse konu oturmuş sayılır."""
        return self.asama == SERBEST and self.serbest_dogru >= 2 and self.ustalik >= 0.7

    @property
    def baslanmis(self) -> bool:
        return (self.anlatim_sayisi + self.birlikte_sayisi + self.serbest_toplam) > 0

    def kademeyi_damgala(self, kademe: int) -> bool:
        """
        Konu oturmussa, hangi kademede oturdugunu isaretler. Degistiyse True.

        Damga uc durumda yenilenir:

        1. `oturdugu_kademe == 0` -- hic olculmemis. ESKI KAYITLAR buraya
           duser ve ogrencinin MEVCUT kademesine yazilir. Aksi halde surumu
           yukselten her okul, butun eski ogrencilerin ustaligini bir gecede
           silmis ve dikkat tavanlarini tavana firlatmis olurdu.
        2. Damga zaten bu kademedeyse -- damga (ve serbest sayaci) tazelenir.
           Bu sik onemli: tazelenmezse ayni kademede yapilan calismalar,
           kademe yukseldiginde "yeni kademede tekrar sinandi" gibi sayilir ve
           konu hic calisilmadan bir ust kademeye tasinirdi.
        3. Damgadan bu yana serbest asamada yeni calisma yapilmissa -- konu bu
           kademede yeniden sinanmis ve yine oturmustur; damga tasinir.

        Yalnizca `tamamlandi` konular damgalanir: oturmamis bir konuya kademe
        yazmak, ilerideki gercek damgayi kirletir.
        """
        if not self.tamamlandi:
            return False
        if not (self.oturdugu_kademe <= 0
                or self.oturdugu_kademe == kademe
                or self.serbest_toplam > self.damga_serbest_toplam):
            return False
        degisti = self.oturdugu_kademe != int(kademe)
        self.oturdugu_kademe = int(kademe)
        self.damga_serbest_toplam = self.serbest_toplam
        return degisti


def ustalik_gecerli_mi(oturdugu_kademe: int, simdiki_kademe: int) -> bool:
    """
    Bir kademede oturmus konu, su anki kademede hala oturmus sayilir mi?

    Kural TEK YONLU: yalnizca damga su anki kademenin GERISINDE kalirsa
    ustalik eskir. Damga ileride olabilir (ders kademesi dustuyse) ve o durumda
    ustalik elbette gecerlidir -- daha zorunu bilen kolayini da bilir.
    """
    if oturdugu_kademe <= 0:
        return False        # olculmemis; damgalanmadan sayilmaz
    return int(simdiki_kademe) - int(oturdugu_kademe) <= USTALIK_KADEME_TOLERANSI


@dataclass
class DersDurumu:
    """Tek bir dersteki ilerleme."""
    kademe: int = 1
    ustalik: float = 0.5          # 0..1 arası kayan ortalama
    cozulen: int = 0
    toplam_puan: int = 0
    toplam_yildiz: int = 0
    seri: int = 0                 # üst üste iyi geçen görev sayısı
    kotu_seri: int = 0
    model_dogru: int = 0          # modelleme adımını ilk denemede geçme sayısı
    model_toplam: int = 0
    son_ureticiler: List[str] = field(default_factory=list)
    konu_puani: Dict[str, float] = field(default_factory=dict)
    # Yanlış teşhisi -> kaç kez görüldüğü. Tek seferlik dalgınlık ile yerleşmiş
    # bir karışıklığı ayırt eden şey tekrar sayısıdır; karne buna bakar.
    hata_turleri: Dict[str, int] = field(default_factory=dict)
    konular: Dict[str, KonuDurumu] = field(default_factory=dict)

    @property
    def model_orani(self) -> float:
        return 0.0 if self.model_toplam == 0 else self.model_dogru / self.model_toplam

    def konu(self, konu_kodu: str) -> KonuDurumu:
        if konu_kodu not in self.konular:
            self.konular[konu_kodu] = KonuDurumu()
        return self.konular[konu_kodu]


@dataclass
class Durum:
    """Bir öğrencinin tüm oyun durumu."""
    ad: str = "Kâşif"
    # Sınıf/şube: yalnızca öğretmen raporunu ve karneyi gruplamak için. Oyun
    # akışında hiçbir yerde kullanılmaz; boş bırakılabilir.
    sinif: str = ""
    # Öğrenci numarası. Okulda kayıt dosyasının KİMLİĞİ budur; evde oynayan
    # için boş kalır ve kimlik yine ada düşer. Aynı adlı iki öğrencinin
    # birbirinin kaydını ezmesini engelleyen tek şey bu alandır.
    numara: str = ""
    # Oyuncu tipi: "ev" ya da "okul". Sınıf ve numara ESKİDEN HERKESE
    # soruluyordu; mezun, yetişkin ya da evde oynayan biri için ikisi de
    # anlamsız. Artık açılışta tek soru soruluyor ve okul dışındakilere o iki
    # soru hiç gösterilmiyor. Bkz. oyun.py _yeni_oyun().
    tip: str = "ev"
    # Kayıt dosyasının adı. Boşsa kimlik eski kuralla türetilir (numara varsa
    # "sinif-numara", yoksa öğrencinin adı) - eski kayıtlar bu sayede aynen
    # açılmaya devam eder. Yeni açılan numarasız kayıtlar burayı doldurur;
    # böylece aynı adlı iki oyuncu birbirinin dosyasını EZMEZ.
    kayit_adi: str = ""
    # Sinif kodu ve okul: ogretmenin actigi siniftan geliyor (araclar/sinif.py).
    # Kod kaydedilince ogrenci hangi sinifa bagli oldugu BELLI olur; rapor ve
    # karne gruplamasi ileride ada gore degil koda gore yapilabilir -- ad
    # yazim hatasina acik, kod degil.
    sinif_kodu: str = ""
    okul: str = ""
    # Meslek dalı (bölüm). Akademik ders adları öğrenciye hiç gösterilmez ama
    # meslek dalı gösterilir: o öğrencinin kendi bölümüdür. Meslek masasına
    # ilk girişte sorulur ve hatırlanır. Meslek lisesinde olmayan için boş.
    dal: str = ""
    # PIN'in özeti - PIN'in kendisi hiçbir yerde saklanmaz. Bunun ne olduğu
    # konusunda dürüst olalım: sınıf arkadaşının merakla başkasının kaydını
    # açmasını engeller, kayıt dosyasını Gezgin'den açan birini engellemez.
    # Gerçek gizlilik isteniyorsa sunucu tarafında kimlik doğrulama gerekir.
    pin_ozeti: str = ""
    tohum: int = 0
    bolum: int = 0
    zorluk: int = 2
    kaynaklar: Dict[str, int] = field(default_factory=dict)
    dersler: Dict[str, DersDurumu] = field(default_factory=dict)
    gunluk: List[str] = field(default_factory=list)
    rozetler: List[str] = field(default_factory=list)
    tamamlanan_gorevler: List[str] = field(default_factory=list)
    ayarlar: Dict[str, Any] = field(default_factory=dict)
    # Sınıf kodu yoksa öğrencinin kendi okul programı. Sınıfa bağlı öğrenci
    # öğretmenin ortak programını okur; eski kayıtlar boş programla açılır.
    ders_programi: Dict[str, Any] = field(default_factory=dict)
    kesfedilen_konular: List[str] = field(default_factory=list)
    # Dikkat: ESKIDEN bulmaca basinaydi (Bulmaca.dikkat, varsayilan 6) ve her
    # gorevde sifirlaniyordu. Artik KALICI bir havuz. Sebep: "belirli surede
    # 1 dolsun" ancak havuzda anlamli; gorev basina sifirlanan bir sayida
    # dolum diye bir sey yok.
    #
    # Tavan ustalikla TERS orantili: yeni ogrenci 100 ile baslar ve kanit
    # acmakta comert davranabilir; konular oturdukca tavan DIKKAT_TABANI'na
    # (10) iner ve dogru yere bakmak zorunda kalir. Bu, TASARIM_NOTLARI §0'in
    # tersten okunusu: destek, ihtiyac azaldikca azalir -- ceza degil.
    # Sessiz el kaldirma: ogrencinin HANGI sorulari ogretmene bildirdigi.
    # Yalnizca burada, ogrencinin kendi kaydinda duruyor -- sinif dosyasinda
    # isim yok, sadece sayi var (araclar/el_kaldirma.py). Bunun tek isi ayni
    # soruyu iki kez bildirip sayiyi sismesini onlemek.
    bildirilen_sorular: List[str] = field(default_factory=list)
    dikkat: int = -1            # -1 = henuz kurulmadi, ilk kullanimda tavana esitlenir
    oynanan_gorev: int = 0
    ilk_oynama: float = 0.0
    son_oynama: float = 0.0
    # Sıralama "süreklilik" üzerinden yapılacak (kaç gün üst üste gelindi),
    # toplam süre üzerinden DEĞİL: toplam ölçülürse evinde bilgisayarı olan
    # öğrenci, yalnızca okul saatinde oynayabileni her zaman geçer ve sıralama
    # yeteneği değil imkânı ölçmeye başlar. Bunun için gün bazlı bir katılım
    # kaydı gerekiyor; henüz yok. Bkz. TASARIM_NOTLARI.md §2

    # ---------------------------------------------------------------- kurulum
    @classmethod
    def yeni(cls, ad: str, baslangic_kademesi: int = 5, tohum: Optional[int] = None,
             zorluk: Optional[int] = None, sinif: str = "", numara: str = "",
             pin: str = "", tip: str = "ev", kayit_adi: str = "") -> "Durum":
        secilen_zorluk = zorluk or kademe_zorlugu(baslangic_kademesi)
        # Yeni arayüz zorluk verir; eski eklentiler doğrudan kademe veriyorsa
        # o kesin değeri aynen koruruz.
        if zorluk is not None:
            baslangic_kademesi = ZORLUK_KADEME[secilen_zorluk]
        durum = cls(
            ad=ad or "Kâşif",
            sinif=(sinif or "").strip(),
            numara=(numara or "").strip(),
            tip=tip,
            kayit_adi=(kayit_adi or "").strip(),
            zorluk=secilen_zorluk,
            tohum=tohum if tohum is not None else random.randrange(1, 10 ** 9),
            kaynaklar={"erzak": 40, "cevher": 20, "enerji": 30, "itibar": 0},
            dersler={ders: DersDurumu(kademe=baslangic_kademesi) for ders in DERSLER},
            ayarlar={"yazim_hizi": 0.0, "zorluk": "uyarlanir", "ipucu_acik": True},
            ilk_oynama=time.time(),
            son_oynama=time.time(),
        )
        if pin:
            durum.pin_kur(pin)
        durum.gunluk_ekle("Meridyen Üssü'ne kayıt subayı olarak atandın.")
        return durum

    # ---------------------------------------------------------------- yardımcı
    def ders(self, ders_kodu: str) -> DersDurumu:
        if ders_kodu not in self.dersler:
            self.dersler[ders_kodu] = DersDurumu()
        return self.dersler[ders_kodu]

    def aktif_dersler(self) -> List[str]:
        """
        İçerik motorunun kullanabileceği alan kodları.

        Oyuncu bu teknik kodları görmez; arayüz onları dört öğrenme yolunda
        toplar. Ad eski kayıt ve eklenti uyumluluğu için korunmuştur.
        """
        return list(DERSLER)

    @property
    def sik_sayisi(self) -> int:
        """Görevlerin ortak şık üst sınırı."""
        return 5

    @property
    def zorluk_kademe_araligi(self):
        merkez = ZORLUK_KADEME.get(self.zorluk, 5)
        return (max(1, merkez - 2), min(13, merkez + 2))

    @property
    def zorluk_adi(self) -> str:
        from .modeller import ZORLUK_ADLARI
        return ZORLUK_ADLARI.get(self.zorluk, "Temel")

    def zorluk_ayarla(self, zorluk: int) -> None:
        """Bütün alanları seçilen zorluğun merkezine taşır."""
        self.zorluk = max(1, min(5, int(zorluk)))
        merkez = ZORLUK_KADEME[self.zorluk]
        for durum in self.dersler.values():
            durum.kademe = merkez

    def rastgele(self, etiket: str = "") -> random.Random:
        """
        Tohuma bağlı ama her görevde farklı bir rastgele üreteci.
        Aynı kayıt dosyası + aynı görev sırası = aynı sayılar (tekrarlanabilir).
        """
        return random.Random("{}|{}|{}".format(self.tohum, self.oynanan_gorev, etiket))

    def kaynak_ekle(self, odul: Dict[str, int]) -> Dict[str, int]:
        """Ödülü uygular, gerçekten eklenen miktarları döner."""
        uygulanan = {}
        for anahtar, miktar in (odul or {}).items():
            if anahtar not in KAYNAKLAR:
                continue
            onceki = self.kaynaklar.get(anahtar, 0)
            yeni = max(0, onceki + int(miktar))
            self.kaynaklar[anahtar] = yeni
            uygulanan[anahtar] = yeni - onceki
        return uygulanan

    def kaynak_yeter_mi(self, bedel: Dict[str, int]) -> bool:
        """
        Bir harcamanın karşılanıp karşılanmadığı.

        Şu an hiçbir yerden çağrılmıyor; koloni katmanı (tesis kurma, onarım,
        masa açma) yazıldığında giriş noktası burası olacak.
        Bkz. TASARIM_NOTLARI.md §3
        """
        return all(self.kaynaklar.get(a, 0) >= m for a, m in (bedel or {}).items())

    def gunluk_ekle(self, metin: str) -> None:
        damga = time.strftime("%d.%m %H:%M")
        self.gunluk.append("[{}] {}".format(damga, metin))
        if len(self.gunluk) > 200:
            del self.gunluk[:-200]

    def rozet_ekle(self, rozet: str) -> bool:
        if rozet in self.rozetler:
            return False
        self.rozetler.append(rozet)
        self.gunluk_ekle("Rozet kazanıldı: " + rozet)
        return True

    @property
    def ortalama_kademe(self) -> float:
        aktif = self.aktif_dersler()
        if not aktif:
            return 1.0
        return sum(self.ders(d).kademe for d in aktif) / len(aktif)

    def ozet_satiri(self) -> str:
        parcalar = ["{} {}".format(KAYNAK_ADLARI[a], self.kaynaklar.get(a, 0)) for a in KAYNAKLAR]
        return "  |  ".join(parcalar)

    @property
    def rutbe(self) -> str:
        uygun = [ad for esik, ad in RUTBELER if self.oynanan_gorev >= esik]
        return uygun[-1] if uygun else RUTBELER[0][1]

    @property
    def sonraki_rutbe(self):
        """(eşik, ad) ya da son rütbedeyse None."""
        for esik, ad in RUTBELER:
            if self.oynanan_gorev < esik:
                return esik, ad
        return None

    # ---------------------------------------------------------------- kayıt
    def sozluge(self) -> Dict[str, Any]:
        veri = asdict(self)
        veri["_surum"] = 1
        return veri

    @classmethod
    def sozlukten(cls, veri: Dict[str, Any]) -> "Durum":
        dersler = {}
        for ders_kodu, ham in (veri.get("dersler") or {}).items():
            alanlar = {a: ham[a] for a in DersDurumu.__dataclass_fields__ if a in ham}
            # Konular sözlüğü JSON'da düz sözlük olarak durur; nesneye çeviriyoruz.
            ham_konular = alanlar.pop("konular", None) or {}
            ders_durumu = DersDurumu(**alanlar)
            for konu_kodu, konu_ham in ham_konular.items():
                konu_alanlar = {a: konu_ham[a]
                                for a in KonuDurumu.__dataclass_fields__
                                if a in konu_ham}
                ders_durumu.konular[konu_kodu] = KonuDurumu(**konu_alanlar)
            dersler[ders_kodu] = ders_durumu
        for ders_kodu in DERSLER:
            dersler.setdefault(ders_kodu, DersDurumu())
        alanlar = {a: veri[a] for a in cls.__dataclass_fields__ if a in veri}
        alanlar["dersler"] = dersler
        durum = cls(**alanlar)
        if "kesfedilen_konular" not in veri:
            # Önceki sürümde çalışılmış konu adlarını yeniden kilitleme.
            durum.kesfedilen_konular = [ders + ":" + konu
                                       for ders, dd in dersler.items()
                                       for konu, kd in dd.konular.items() if kd.baslanmis]
        if "zorluk" not in veri:
            # Eski kayıttaki düzeyi silmeden, alanların
            # ortalama iç düzeyini yeni beşli ölçeğe taşıyoruz.
            ortalama = sum(d.kademe for d in dersler.values()) / max(1, len(dersler))
            durum.zorluk = kademe_zorlugu(int(round(ortalama)))
        for kaynak in KAYNAKLAR:
            durum.kaynaklar.setdefault(kaynak, 0)
        return durum

    # ------------------------------------------------------------- dikkat
    def ustaliklari_damgala(self) -> int:
        """
        Oturmus her konuya, hangi kademede oturdugunu isaretler.

        Damganin ASIL yazilma yeri burasidir. Konu oturma ani `ilerleme.py`
        icinde gecer ama orasi kademeyi damgalamaz; bu yuzden damga, oturmus
        konularin sayildigi ilk yerde -- yani her gorev sonrasi calisan
        `oturmus_oran` icinde -- toplu olarak vurulur. Bir gorev gecikmesi
        onemsiz: tavan zaten gorevden sonra yeniden hesaplanir.

        Ayni cagri eski kayitlari da onarir: `oturdugu_kademe == 0` olan
        oturmus konular ogrencinin mevcut kademesine yazilir.

        Kac konunun damgasi degisti, onu doner.
        """
        damgalanan = 0
        for ders in self.dersler.values():
            for konu in ders.konular.values():
                if konu.kademeyi_damgala(ders.kademe):
                    damgalanan += 1
        return damgalanan

    @property
    def oturmus_oran(self) -> float:
        """
        Baslanmis konularin ne kadari HALA oturmus? 0.0 - 1.0.

        "Hala" onemli: konu oturdugu kademeden `USTALIK_KADEME_TOLERANSI`
        kademeden fazla uzaklastiysa artik oturmus sayilmaz, yeniden
        ogrenilecek sayilir -- cunku ayrinti kademeyle artiyor. Boylece sinif
        atlayan ogrencinin dikkat tavani kendiliginden ve GUCLU bicimde
        yukselir; elle sifirlama gerekmez.
        """
        self.ustaliklari_damgala()
        baslanmis = oturmus = 0
        for ders in self.dersler.values():
            for konu in ders.konular.values():
                if konu.baslanmis:
                    baslanmis += 1
                    if konu.tamamlandi and ustalik_gecerli_mi(
                            konu.oturdugu_kademe, ders.kademe):
                        oturmus += 1
        if baslanmis < EN_AZ_KONU_ICIN_TAVAN:
            # Cok az konu varken oran gurultudur: iki konudan biri oturunca
            # ogrenci "yarisini biliyor" sayilip tavani yariya inmemeli.
            return 0.0
        return oturmus / baslanmis

    def dikkat_tavani(self) -> int:
        """Ustalikla ters orantili dikkat tavani."""
        oran = max(0.0, min(1.0, self.oturmus_oran))
        tavan = DIKKAT_BASLANGIC - (DIKKAT_BASLANGIC - DIKKAT_TABANI) * oran
        return int(round(tavan))

    def dikkati_hazirla(self) -> int:
        """Eski kayitlarda ve ilk aciliste havuzu tavana esitler."""
        if self.dikkat < 0:
            self.dikkat = self.dikkat_tavani()
        return self.dikkat

    def dikkat_ekle(self, zorluk: int) -> int:
        """Gorev bitince dikkat geri verir. Zor gorev daha cok verir.

        Kullanicinin istegi: "gorevin zorluguna gore dolum miktari artabilir."
        Bu §0'a uyuyor -- zorlanan ogrenci cezalandirilmiyor, kaynagini geri
        kazaniyor. Dolum gercek zamana degil GOREVE bagli: gercek zamana
        baglanirsa beklemek odullendirilir ve 40 dakikalik derste ise yaramaz.
        """
        self.dikkati_hazirla()
        kazanc = DIKKAT_DOLUM.get(int(zorluk), 1)
        tavan = self.dikkat_tavani()
        onceki = self.dikkat
        self.dikkat = min(tavan, self.dikkat + kazanc)
        return self.dikkat - onceki

    def dikkat_harca(self, bedel: int) -> bool:
        """Yeterliyse harcar ve True doner."""
        self.dikkati_hazirla()
        if self.dikkat < bedel:
            return False
        self.dikkat -= bedel
        return True

    # ---------------------------------------------------------------- kimlik
    def kimlik(self) -> str:
        """
        Kayıt dosyasını belirleyen ad.

        Numara varsa kimlik "sinif-numara" olur; okulda aynı adlı iki öğrenci
        bu sayede ayrı dosyalara yazar. Numara yoksa eski davranış korunur ve
        kimlik öğrencinin adıdır - evde oynayanın ya da eski kayıtların
        bozulmaması için.
        """
        if self.kayit_adi:
            return dosya_adi_yap(self.kayit_adi)
        if self.numara:
            parcalar = [p for p in ((self.sinif or "").strip(), self.numara) if p]
            return dosya_adi_yap("-".join(parcalar))
        return dosya_adi_yap(self.ad)

    def pin_kur(self, pin: str) -> None:
        self.pin_ozeti = pin_ozetle(pin, self.kimlik()) if pin else ""

    def pin_dogru_mu(self, pin: str) -> bool:
        """PIN konulmamışsa herkes girebilir; konulmuşsa eşleşmeli."""
        if not self.pin_ozeti:
            return True
        return pin_ozetle(pin, self.kimlik()) == self.pin_ozeti

    def dosya_yolu(self) -> str:
        return os.path.join(KAYIT_KLASORU, self.kimlik() + ".json")

    def kaydet(self) -> str:
        self.son_oynama = time.time()
        os.makedirs(KAYIT_KLASORU, exist_ok=True)
        yol = self.dosya_yolu()
        gecici = yol + ".tmp"
        with open(gecici, "w", encoding="utf-8") as dosya:
            json.dump(self.sozluge(), dosya, ensure_ascii=False, indent=2)
        os.replace(gecici, yol)  # yarıda kesilirse eski kayıt bozulmasın
        return yol


# --------------------------------------------------------------------------
# Kayıt dosyası işlemleri
# --------------------------------------------------------------------------

_GECERSIZ = '<>:"/\\|?*'


def dosya_adi_yap(ad: str) -> str:
    temiz = "".join("_" if h in _GECERSIZ else h for h in (ad or "kasif")).strip()
    temiz = temiz.replace(" ", "_")
    return temiz[:40] or "kasif"


def benzersiz_kayit_adi(ad: str) -> str:
    """
    Numarasız bir oyuncu için kayıt klasöründe boşta olan bir ad üretir.

    Neden gerekli: numarasız kayıtta kimlik öğrencinin ADIYDI. Aynı evde iki
    "Ali" oynarsa ikincisi birincinin dosyasına yazıyor ve ilerlemesi
    siliniyordu. Sınıf/numara sorusu okul dışındakilerden kaldırılınca bu
    durum istisna olmaktan çıkıp olağan hâle geldi.

    İlk oyuncu adını olduğu gibi alır ("ali"); ikincisi "ali-2" olur. Numara
    eklemek rastgele son ekten iyidir: dosya adı hâlâ insan okuyabilir ve
    öğretmen klasöre baktığında kimin kim olduğunu çıkarabilir.
    """
    taban = dosya_adi_yap(ad)
    aday = taban
    sayac = 2
    while os.path.exists(os.path.join(KAYIT_KLASORU, aday + ".json")):
        aday = "{}-{}".format(taban, sayac)
        sayac += 1
        if sayac > 999:          # olmaz ama sonsuz döngü de bırakılmaz
            return "{}-{}".format(taban, int(time.time()))
    return aday


def pin_ozetle(pin: str, tuz: str) -> str:
    """
    PIN'i geri çevrilemez bir özete indirger.

    Amaç kayıt dosyasını açan birinin PIN'i çıplak gözle okumaması. Bu bir
    güvenlik çözümü değildir: dosyaya yazma yetkisi olan kişi özeti silip
    PIN'i kaldırabilir. Okul ağında gerçek koruma isteniyorsa iş sunucuya
    taşınmalı.
    """
    ham = "{}|{}".format(tuz, (pin or "").strip())
    return hashlib.sha256(ham.encode("utf-8")).hexdigest()


def numarayla_bul(numara: str, sinif: str = "") -> List[Dict[str, Any]]:
    """Verilen öğrenci numarasına ait kayıt özetlerini döner."""
    aranan = (numara or "").strip().lower()
    if not aranan:
        return []
    bulunan = []
    for ozet in kayitlari_listele():
        if (ozet.get("numara") or "").strip().lower() != aranan:
            continue
        if sinif and sinif.strip().lower() not in (ozet.get("sinif") or "").lower():
            continue
        bulunan.append(ozet)
    return bulunan


def kayitlari_listele() -> List[Dict[str, Any]]:
    """Kayıt klasöründeki dosyaların özetini döner."""
    if not os.path.isdir(KAYIT_KLASORU):
        return []
    ozetler = []
    for dosya_adi in sorted(os.listdir(KAYIT_KLASORU)):
        if not dosya_adi.endswith(".json"):
            continue
        yol = os.path.join(KAYIT_KLASORU, dosya_adi)
        try:
            with open(yol, encoding="utf-8") as dosya:
                veri = json.load(dosya)
            # Klasörde öğrenci kaydı olmayan JSON'lar da bulunabilir
            # (öğretmen parolası gibi). Ada göre değil YAPIYA göre eliyoruz:
            # her öğrenci kaydında "dersler" sözlüğü vardır.
            if not isinstance(veri, dict) or "dersler" not in veri:
                continue
            ozetler.append({
                "dosya": dosya_adi,
                "ad": veri.get("ad", "?"),
                "sinif": veri.get("sinif", ""),
                "numara": veri.get("numara", ""),
                "sinif_kodu": veri.get("sinif_kodu", ""),
                "okul": veri.get("okul", ""),
                "pinli": bool(veri.get("pin_ozeti")),
                "bolum": veri.get("bolum", 0),
                "gorev": veri.get("oynanan_gorev", 0),
                "son": veri.get("son_oynama", 0),
                "yol": yol,
            })
        except Exception:
            continue
    ozetler.sort(key=lambda o: o.get("son", 0), reverse=True)
    return ozetler


def yukle(yol: str) -> Optional[Durum]:
    try:
        with open(yol, encoding="utf-8") as dosya:
            veri = json.load(dosya)
        return Durum.sozlukten(veri)
    except Exception:
        return None


def sil(yol: str) -> bool:
    try:
        os.remove(yol)
        return True
    except Exception:
        return False


def kademe_adi(kademe: int) -> str:
    return KADEME_ADLARI.get(int(kademe), str(kademe))
