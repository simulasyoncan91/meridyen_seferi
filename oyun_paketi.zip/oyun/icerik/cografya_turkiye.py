# -*- coding: utf-8 -*-
"""
Türkiye coğrafyası görevleri.

Buradaki hiçbir görev "Rize'de ne yetişir?" diye sormaz. Bunun yerine üssün
gerçek bir kararı vardır - nereden tedarik edelim, tesisi nereye kuralım,
hangi güzergâh daha ucuz - ve öğrenci kararı coğrafyayla gerekçelendirir.

Amaç bölge ezberi değil, ŞU SORUYU kurabilmek: bir ürün ya da kaynak neden
orada bulunur? Bu soruyu kuran öğrenci, hiç duymadığı bir ürün için de doğru
bölgeyi tahmin edebilir; ezberleyen öğrenci ise listede olmayan hiçbir şeyi
bilemez.

Olgusal kapsam kasten dar ve yerleşik tutuldu: ders kitabı düzeyinde,
yıllara göre değişmeyen bilgiler.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, coklu_siklar, model_adimi, sayi_adimi,
    secim_adimi, sy, yorum_adimi,
)

BOLGELER = ["Marmara", "Ege", "Akdeniz", "İç Anadolu", "Karadeniz",
            "Doğu Anadolu", "Güneydoğu Anadolu"]


# ==========================================================================
# TEDARİK: ÜRÜN HANGİ BÖLGEDEN ALINIR
# ==========================================================================

_URUNLER = [
    {
        "urun": "çay",
        "bolge": "Karadeniz",
        "sehir": "Rize",
        "kosul": ("Yılın her ayı yağışlı, kışı ılık geçen ve don olayı "
                  "görülmeyen bir iklim ister."),
        "neden": ("Çay bitkisi yıl boyu nem ister ve dona dayanmaz. Türkiye'de "
                  "bu koşulu yalnızca Doğu Karadeniz kıyısı sağlar; bu yüzden "
                  "çay tarımı orada toplanmıştır."),
    },
    {
        "urun": "fındık",
        "bolge": "Karadeniz",
        "sehir": "Giresun",
        "kosul": "Bol yağışlı, ılıman ve nemli bir kıyı iklimi ister.",
        "neden": ("Fındık yazın kurak geçen yerlerde verim vermez. Karadeniz "
                  "kıyısı yaz aylarında da yağış aldığı için üretim orada "
                  "yoğunlaşmıştır."),
    },
    {
        "urun": "zeytin",
        "bolge": "Ege",
        "sehir": "Ayvalık",
        "kosul": ("Yazı sıcak ve kurak, kışı ılık ve yağışlı geçen Akdeniz "
                  "iklimi ister; sert kışa dayanmaz."),
        "neden": ("Zeytin kış soğuğuna dayanamaz. Bu yüzden Ege ve Akdeniz "
                  "kıyılarında yetişir; İç Anadolu ve Doğu Anadolu'da kış "
                  "soğuğu ağacı öldürür."),
    },
    {
        "urun": "turunçgil (portakal, limon)",
        "bolge": "Akdeniz",
        "sehir": "Mersin",
        "kosul": "Kışı çok ılık geçen, don riski en düşük kıyıları ister.",
        "neden": ("Turunçgiller zeytinden bile soğuğa daha duyarlıdır. "
                  "Türkiye'de kışı en ılık geçen yer Akdeniz kıyısıdır; üretim "
                  "orada toplanır."),
    },
    {
        "urun": "buğday",
        "bolge": "İç Anadolu",
        "sehir": "Konya",
        "kosul": ("Geniş düzlükler ve ilkbaharda yağış ister; yazın kuraklığa "
                  "dayanır."),
        "neden": ("Buğday kuraklığa dayanıklıdır ve geniş, makineyle işlenebilen "
                  "düzlükler ister. İç Anadolu platoları bu iki koşulu birden "
                  "sağlar."),
    },
    {
        "urun": "pamuk",
        "bolge": "Güneydoğu Anadolu",
        "sehir": "Şanlıurfa",
        "kosul": ("Uzun ve sıcak bir yaz ile sulama suyu ister; yağışa değil "
                  "sulamaya dayanır."),
        "neden": ("Pamuk uzun sıcak yaz ister ama çok su tüketir. Güneydoğu "
                  "Anadolu'da yaz sıcaklığı yeterlidir ve GAP sulaması suyu "
                  "sağladığı için üretim burada büyümüştür."),
    },
]


@bulmaca(ders="cografya", konu="turkiye_tarim", kademeler=(5, 13), agirlik=1.4)
def tedarik_bolgesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Üs bir ürün alacak; hangi bölgeden alınacağı iklim koşuluyla bulunur."""
    urun = rastgele.choice(_URUNLER)
    digerleri = [b for b in BOLGELER if b != urun["bolge"]]
    rastgele.shuffle(digerleri)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-tr-tedarik",
        ders="cografya",
        baslik="Tedarik Kararı",
        kademe=kademe,
        konu="turkiye_tarim",
        kazanim="Türkiye'de tarım ürünlerinin dağılışı ile iklim koşulları arasındaki ilişki.",
        dikkat=6,
        brifing=(
            "Üs, yıllık {} alımını yapacak. {} \"en yakın şehirden alalım, "
            "nakliye ucuz olur\" diyor.\n\n"
            "Ama en yakın yerden almak, o ürünün orada yetişmesi anlamına "
            "gelmiyor. Yanlış bölgeden sipariş verilirse ya ürün bulunamaz ya "
            "da çok pahalıya gelir.\n\n"
            "Siparişin hangi bölgeye yazılacağını, ürünün ne istediğine bakarak "
            "bulmamız gerekiyor."
        ).format(urun["urun"], kisi),
        kanitlar=[
            Kanit("Ürün künyesi",
                  "{}: {}".format(urun["urun"].capitalize(), urun["kosul"]),
                  bedel=2, kritik=True),
            Kanit("Türkiye iklim özeti",
                  "KARADENİZ: Her mevsim yağışlı, ılıman, nemli.\n"
                  "EGE ve AKDENİZ: Yaz sıcak-kurak, kış ılık-yağışlı "
                  "(Akdeniz iklimi). Akdeniz kışı daha ılık.\n"
                  "İÇ ANADOLU: Karasal; yaz kurak, kış soğuk, yağış az.\n"
                  "DOĞU ANADOLU: Yüksek ve sert karasal; kış çok soğuk ve uzun.\n"
                  "GÜNEYDOĞU ANADOLU: Yaz çok sıcak ve uzun, yağış az; "
                  "sulama belirleyici.\n"
                  "MARMARA: Geçiş iklimi; sanayi ve nüfus yoğun.",
                  bedel=2, kritik=True),
            Kanit("Satın alma kuralı",
                  "\"Bir ürün, iklim koşullarını sağlayan bölgede ucuzdur. "
                  "Sağlamayan bölgede ya hiç yoktur ya da seradan gelir ve "
                  "pahalıdır.\"", bedel=2, kritik=True),
            Kanit("Nakliye çizelgesi",
                  "En yakın büyük şehir üsse 90 km. Bölgeler arası nakliye "
                  "maliyeti, üretim maliyetinin yanında küçük kalıyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Siparişin hangi bölgeye verileceğini ne belirler?",
                dogru="Ürünün istediği iklimi hangi bölgenin sağladığı.",
                yanlislar={
                    "Üsse en yakın bölgenin hangisi olduğu; yakın olan ucuz gelir.":
                        "Yakınlığı tek ölçüt saydın. Yakın bölge o ürünü "
                        "yetiştiremiyorsa mesafenin bir anlamı kalmaz; önce "
                        "ürünün istediği iklim gelir.",
                    "Hangi bölgenin nüfusunun daha kalabalık olduğu; çok insan çok üretir.":
                        "Nüfusu üretimle karıştırdın. Kalabalık bir bölge "
                        "tüketici olabilir; ürünü yetiştiren yer olması "
                        "gerekmez.",
                    "Hangi bölgenin yüzölçümünün daha büyük olduğu.":
                        "Genişliği ölçüt saydın. Geniş ama uygun olmayan bir "
                        "arazide o ürün yetişmez; belirleyici olan iklim ve "
                        "toprak.",
                    "Hangi bölgede daha çok fabrika bulunduğu.":
                        "Sanayiyi tarımla karıştırdın. Fabrika sayısı işlenmiş "
                        "ürün için anlamlı; tarım ürününü belirleyen doğal "
                        "koşullar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarım ürünlerinin dağılışını belirleyen ana etmen iklimdir. "
                    "Yakınlık nakliyeyi ucuzlatır ama ürünü var etmez; kışı sert "
                    "bir bölgeye zeytin siparişi vermek, mesafe ne olursa olsun "
                    "sonuç vermez. Bu yüzden önce 'nerede yetişir', sonra "
                    "'oradan nasıl getiririm' diye sorulur."
                ),
                ipuclari=[
                    "Ürün künyesindeki koşulu oku, sonra iklim özetiyle eşleştir.",
                    "Hangi bölgede bu koşullar bir arada bulunur?",
                ],
                puan=18,
                cozum=(
                    "1) Ürünün istediği koşul: {}\n"
                    "2) İklim özetindeki satırları tek tek bu koşulla karşılaştır.\n"
                    "3) Koşulu sağlayan tek bölge: {}\n"
                    "4) {}\n\n"
                    "Sipariş {} bölgesine, özellikle {} çevresine yazılır."
                ).format(urun["kosul"], urun["bolge"], urun["neden"],
                         urun["bolge"], urun["sehir"]),
            ),
            secim_adimi(
                soru="Sipariş hangi bölgeye yazılmalı?",
                dogru=urun["bolge"],
                yanlislar=digerleri[:4],
                rastgele=rastgele,
                aciklama=urun["neden"],
                ipuclari=["İklim özetiyle ürün künyesini yan yana koy."],
                puan=16,
            ),
            yorum_adimi(
                soru="Aynı ürünü uygun olmayan bir bölgeden almak istesek ne olurdu?",
                dogru="Ya bulunamazdı ya da seradan geldiği için pahalıya mal olurdu.",
                yanlislar={
                    "Fiyat değişmezdi; ürün her yerde aynı fiyattır.":
                        "Fiyatı sabit saydın. Uygun olmayan bölgede üretim "
                        "zorlaşır; verim düşer ve birim maliyet yükselir.",
                    "Daha ucuz olurdu; yeni satıcı çıkınca rekabet artardı.":
                        "Rekabeti tek etken saydın. Ürün orada zaten zor "
                        "yetişiyorsa arz kısıtlıdır; rekabet fiyatı "
                        "düşürmez.",
                    "Ürün daha kaliteli olurdu; zor koşulda yetişen ürün dayanıklıdır.":
                        "Yönü ters aldın. İklimine uymayan yerde yetişen ürün "
                        "genellikle daha düşük verimli ve kalitesiz olur.",
                    "Hiçbir fark olmazdı, çünkü iklim tarımı etkilemez.":
                        "İklimi devre dışı bıraktın. Tarımda ürün seçimini "
                        "belirleyen ilk şey sıcaklık ve yağış rejimidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Doğal koşulların sağladığı üstünlüğe karşı üretim yapmak "
                    "mümkündür ama pahalıdır: sera, ısıtma, sulama, koruma "
                    "masrafı çıkar. Ülkelerin ve bölgelerin belli ürünlerde "
                    "uzmanlaşmasının sebebi tam olarak budur."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Sipariş {} bölgesine, {} çevresine yazıldı. Nakliye biraz uzun "
            "sürecek ama fiyat farkı bunu fazlasıyla karşılıyor."
        ).format(urun["bolge"], urun["sehir"]),
        odul={"erzak": 7, "itibar": 4},
    )


# ==========================================================================
# BÖLGE TANIMA
# ==========================================================================

_BOLGE_IZLERI = [
    {
        "bolge": "Karadeniz",
        "izler": [
            "Yaz aylarında bile yağış görülüyor; kuru geçen ay yok.",
            "Dağlar kıyıya paralel uzanıyor ve yamaçlar gür ormanla kaplı.",
            "Tarlalarda mısır, bahçelerde fındık var.",
            "Yerleşmeler dağınık; her ev kendi bahçesinin içinde.",
        ],
        "ayirt": "Yaz yağışı ve gür orman: Türkiye'de bunu yalnızca Karadeniz sağlar.",
    },
    {
        "bolge": "İç Anadolu",
        "izler": [
            "Ufka kadar ağaçsız, kısa otlu düzlükler uzanıyor.",
            "Gece ile gündüz arasındaki sıcaklık farkı çok büyük.",
            "Ekilen ürün ağırlıkla buğday ve şeker pancarı.",
            "Yağış az ve ilkbaharda toplanıyor.",
        ],
        "ayirt": "Bozkır + karasal iklim + tahıl tarımı birleşimi İç Anadolu'yu verir.",
    },
    {
        "bolge": "Doğu Anadolu",
        "izler": [
            "Ortalama yükselti çok fazla; geniş düzlük neredeyse yok.",
            "Kış uzun ve çok sert; kar yerde aylarca kalıyor.",
            "Tarım kısıtlı; geçim büyük ölçüde küçükbaş hayvancılığa dayanıyor.",
            "Yaz otlakları (yaylalar) yoğun kullanılıyor.",
        ],
        "ayirt": "Yükseklik + sert kış + hayvancılık ağırlığı Doğu Anadolu'yu gösterir.",
    },
    {
        "bolge": "Akdeniz",
        "izler": [
            "Kış ılık ve yağışlı, yaz sıcak ve kurak geçiyor.",
            "Kıyı boyunca turunçgil bahçeleri ve seralar var.",
            "Hemen arkada yüksek dağlar (Toroslar) yükseliyor.",
            "Turizm hareketliliği yaz aylarında zirve yapıyor.",
        ],
        "ayirt": "Turunçgil ve sera + kıyıya paralel yüksek dağlar Akdeniz'i gösterir.",
    },
    {
        "bolge": "Güneydoğu Anadolu",
        "izler": [
            "Yaz çok uzun ve çok sıcak; yağış oldukça az.",
            "Tarım büyük ölçüde sulamaya bağlı.",
            "Pamuk, kırmızı mercimek ve Antep fıstığı yetiştiriliyor.",
            "Geniş platolar var, yükselti Doğu Anadolu kadar fazla değil.",
        ],
        "ayirt": "Sulamaya dayalı pamuk-mercimek tarımı ve uzun sıcak yaz burayı ayırır.",
    },
]


@bulmaca(ders="cografya", konu="turkiye_bolgeleri", kademeler=(5, 13), agirlik=1.4)
def bolge_tanima(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Keşif raporundaki izlerden bölgeyi çıkarma."""
    hedef = rastgele.choice(_BOLGE_IZLERI)
    digerleri = [b["bolge"] for b in _BOLGE_IZLERI if b["bolge"] != hedef["bolge"]]
    rastgele.shuffle(digerleri)
    izler = list(hedef["izler"])
    rastgele.shuffle(izler)

    return Bulmaca(
        kod="cog-tr-bolge",
        ders="cografya",
        baslik="Adı Silinmiş Rapor",
        kademe=kademe,
        konu="turkiye_bolgeleri",
        kazanim="Türkiye'nin coğrafi bölgelerini doğal ve beşerî özelliklerinden tanıma.",
        dikkat=6,
        brifing=(
            "Keşif ekibinin gönderdiği raporun üst kısmı ıslanmış; bölge adı "
            "okunmuyor. Gözlemler ise sağlam kalmış:\n\n"
            + "\n".join("  - " + iz for iz in izler) + "\n\n"
            "Bu rapor tedarik planına işlenecek, ama hangi bölgeye ait olduğu "
            "yazılmadan hiçbir işe yaramaz."
        ),
        kanitlar=[
            Kanit("Keşif raporu", "\n".join("- " + iz for iz in izler),
                  bedel=1, kritik=True),
            Kanit("Bölge ayırt etme çizelgesi",
                  "KARADENİZ: her mevsim yağışlı, gür orman, fındık-çay-mısır.\n"
                  "EGE: Akdeniz iklimi, zeytin-incir-üzüm, kıyıya dik dağlar.\n"
                  "AKDENİZ: kışı en ılık, turunçgil ve sera, Toroslar.\n"
                  "İÇ ANADOLU: bozkır, karasal iklim, buğday-şeker pancarı.\n"
                  "DOĞU ANADOLU: en yüksek ve en soğuk, hayvancılık, yaylalar.\n"
                  "GÜNEYDOĞU: uzun sıcak yaz, sulamalı tarım, pamuk-mercimek-fıstık.\n"
                  "MARMARA: geçiş iklimi, sanayi ve nüfusta ilk sırada.",
                  bedel=2, kritik=True),
            Kanit("Rapor yazarının notu",
                  "\"Tek bir gözleme bakıp karar vermeyin; birçok bölge yağış "
                  "alır. Gözlemlerin KESİŞTİĞİ yeri arayın.\"",
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bölgeyi bulmak için gözlemler nasıl kullanılmalı?",
                dogru="Hepsini birden sağlayan bölge aranmalı.",
                yanlislar={
                    "En çarpıcı tek gözleme göre karar verilmeli.":
                        "Tek gözleme yaslandın. Bir gözlem birden çok bölgeye "
                        "uyabilir; bölgeyi daraltan şey gözlemlerin "
                        "KESİŞİMİdir.",
                    "Gözlemlerin ortalaması alınmalı.":
                        "Ortalama sayılar için geçerlidir. Bunlar nitel "
                        "gözlem; ortalaması alınmaz, birlikte okunur.",
                    "İlk yazılan gözlem esas alınmalı.":
                        "Sırayı ölçüt saydın. Defterdeki yazım sırasının "
                        "gözlemin değeriyle ilgisi yok.",
                    "En kısa gözlem en güvenilir olduğu için o kullanılmalı.":
                        "Kısalığı güvenilirlik saydın. Uzunluk bir ölçüt "
                        "değil; her gözlem bölgeyi ne kadar daralttığına göre "
                        "değerlidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Coğrafi bölge tanımada yöntem elemedir: her gözlem bazı "
                    "bölgeleri eler. \"Yağış alıyor\" tek başına Karadeniz'i "
                    "vermez - Akdeniz de kışın yağış alır. Ama \"YAZIN da yağış "
                    "alıyor\" Karadeniz dışındaki hepsini eler. Gözlemlerin "
                    "kesişimi tek bölgeye iner."
                ),
                ipuclari=[
                    "Her gözlemin hangi bölgeleri elediğini tek tek düşün.",
                    "Elemeden sonra geriye kaç bölge kalıyor?",
                ],
                puan=18,
                cozum=(
                    "Gözlemleri eleme aracı gibi kullan:\n"
                    + "\n".join("  - {}".format(iz) for iz in hedef["izler"])
                    + "\n\nAyırt edici nokta: {}\n\nSonuç: {} Bölgesi."
                ).format(hedef["ayirt"], hedef["bolge"]),
            ),
            secim_adimi(
                soru="Rapor hangi bölgeye aittir?",
                dogru=hedef["bolge"],
                yanlislar=digerleri[:4],
                rastgele=rastgele,
                aciklama=hedef["ayirt"],
                ipuclari=["Çizelgedeki satırları gözlemlerle karşılaştır."],
                puan=16,
            ),
            yorum_adimi(
                soru="Yalnızca \"yağış alıyor\" bilgisiyle karar verilebilir miydi?",
                dogru="Hayır; birçok bölge yağış alır, ayırt eden ise yağışın MEVSİMİ.",
                yanlislar={
                    "Evet; yağış tek başına bölgeyi belirler.":
                        "Tek ölçüte indirgedin. Türkiye'de birden çok bölge "
                        "yağış alır; ayırt etmek için başka gözlem gerekir.",
                    "Hayır; yağış coğrafyada hiç kullanılmaz.":
                        "Ters uca gittin. Yağış çok işe yarar; yetersiz olan "
                        "şey onu TEK BAŞINA kullanmak.",
                    "Evet; en yağışlı bölge her zaman Karadeniz'dir, başka bilgi gerekmez.":
                        "Bir bölgeyi ezber cevap yaptın. En yağışlı olmak ile "
                        "yağış almak farklı şeyler; eldeki gözlem yalnızca "
                        "ikincisini söylüyor.",
                    "Hayır; yalnızca yükselti bilgisi kullanılabilir.":
                        "Bu kez başka bir tek ölçüte geçtin. Sorun ölçütün "
                        "hangisi olduğu değil, tek başına yetmemesi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Akdeniz kışın bol yağış alır ama yazı kurudur; Karadeniz her "
                    "mevsim yağışlıdır. Yani ayırt eden şey yağışın MİKTARI kadar "
                    "REJİMİDİR. Coğrafyada tek sayıya bakmak neredeyse her zaman "
                    "yanıltır; dağılıma bakmak gerekir."
                ),
                puan=12,
            ),
        ],
        kapanis="Raporun başlığı yeniden yazıldı: {} Bölgesi.".format(hedef["bolge"]),
        odul={"itibar": 6, "erzak": 3},
    )


# ==========================================================================
# TESİS YERİ SEÇİMİ - "verimlilik"
# ==========================================================================

_TESISLER = [
    {
        "tesis": "şeker fabrikası",
        "hammadde": "şeker pancarı",
        "dogru": "Hammadde kaynağına yakın kurulur.",
        "bolge": "İç Anadolu",
        "neden": ("Şeker pancarı ağır, hacimli ve çabuk bozulan bir üründür; "
                  "taşımak pahalıdır ve şeker oranı yolda düşer. Bu yüzden "
                  "fabrika pancar tarlalarının yanına kurulur."),
    },
    {
        "tesis": "çay işleme tesisi",
        "hammadde": "yaş çay yaprağı",
        "dogru": "Hammadde kaynağına yakın kurulur.",
        "bolge": "Doğu Karadeniz",
        "neden": ("Yaş çay yaprağı toplandıktan sonra saatler içinde işlenmezse "
                  "bozulur. Bu yüzden tesis çay bahçelerinin arasına kurulur."),
    },
    {
        "tesis": "ekmek fırını",
        "hammadde": "un",
        "dogru": "Tüketiciye (pazara) yakın kurulur.",
        "bolge": "Marmara",
        "neden": ("Un dayanıklıdır ve kolay taşınır; ama ekmek çabuk bayatlar. "
                  "Bu yüzden fırın hammaddeye değil, tüketiciye yakın kurulur."),
    },
    {
        "tesis": "demir-çelik tesisi",
        "hammadde": "demir cevheri ve kömür",
        "dogru": "Hammadde ve enerji kaynağına yakın kurulur.",
        "bolge": "Batı Karadeniz (Zonguldak havzası)",
        "neden": ("Demir-çelik üretimi hem çok fazla cevher hem çok fazla kömür "
                  "tüketir. İkisi de ağırdır; tesis bu yüzden kaynağa, özellikle "
                  "kömür havzasına yaklaşır."),
    },
]


@bulmaca(ders="cografya", konu="sanayi_yer_secimi", kademeler=(7, 13))
def tesis_yeri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tesis nereye kurulur: hammaddeye mi, pazara mı?"""
    tesis = rastgele.choice(_TESISLER)
    secenek_havuzu = [
        "Hammadde kaynağına yakın kurulur.",
        "Tüketiciye (pazara) yakın kurulur.",
        "Hammadde ve enerji kaynağına yakın kurulur.",
    ]
    yanlislar = [s for s in secenek_havuzu if s != tesis["dogru"]]
    yanlislar += ["İşçi ücretlerinin en düşük olduğu yere kurulur.",
                  "Ülkenin merkezine kurulur."]

    return Bulmaca(
        kod="cog-tr-tesis",
        ders="cografya",
        baslik="Tesis Nereye",
        kademe=kademe,
        konu="sanayi_yer_secimi",
        kazanim="Sanayi tesislerinin yer seçiminde hammadde, pazar ve enerji etmenleri.",
        dikkat=6,
        brifing=(
            "Üs, bölgeye bir {} kuracak. Yatırım büyük ve yer seçimi bir kez "
            "yapılıyor; yanlış yere kurulan tesis ömrü boyunca zarar eder.\n\n"
            "Komisyonda iki görüş var: biri \"hammaddenin yanına kuralım\", "
            "diğeri \"tüketicinin yanına kuralım\" diyor.\n\n"
            "İkisi de her zaman doğru değil. Karar, taşınması pahalı olan şeyin "
            "hangisi olduğuna bağlı."
        ).format(tesis["tesis"]),
        kanitlar=[
            Kanit("Tesis künyesi",
                  "Kurulacak tesis: {}\nİşlenecek hammadde: {}".format(
                      tesis["tesis"], tesis["hammadde"]),
                  bedel=1, kritik=True),
            Kanit("Sanayi yer seçimi ilkesi",
                  "\"Tesis, taşınması PAHALI ya da RİSKLİ olan tarafa yaklaşır.\n"
                  "- Hammadde ağır, hacimli ya da çabuk bozuluyorsa: hammaddeye.\n"
                  "- Ürün çabuk bozuluyor ya da taşıması zorsa: pazara.\n"
                  "- Üretim çok enerji yiyorsa: enerji kaynağına.\"",
                  bedel=2, kritik=True),
            Kanit("Hammadde özellikleri",
                  {"şeker pancarı": "Ağır ve hacimli; bekledikçe şeker oranı düşer.",
                   "yaş çay yaprağı": "Toplandıktan birkaç saat sonra bozulmaya başlar.",
                   "un": "Dayanıklı, kolay taşınır, uzun süre bozulmaz.",
                   "demir cevheri ve kömür": "İkisi de çok ağır ve çok miktarda tüketilir.",
                   }[tesis["hammadde"]],
                  bedel=2, kritik=True),
            Kanit("Ürün özellikleri",
                  {"şeker fabrikası": "Şeker dayanıklıdır, kolay taşınır.",
                   "çay işleme tesisi": "Kuru çay dayanıklıdır, kolay taşınır.",
                   "ekmek fırını": "Ekmek birkaç saat içinde bayatlar.",
                   "demir-çelik tesisi": "Çelik ağırdır ama dayanıklıdır.",
                   }[tesis["tesis"]],
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Tesisin yerini belirleyen temel ilke nedir?",
                dogru="Taşınması pahalı ya da riskli olan tarafa yaklaşmak.",
                yanlislar={
                    "Her zaman hammaddenin yanına kurmak.":
                        "Tek bir kuralı her tesise uyguladın. Hammadde "
                        "işlenince ağırlık KAYBEDİYORSA doğru; kazanıyorsa "
                        "tesis pazara yaklaşır.",
                    "Her zaman tüketicinin yanına kurmak; satış orada yapılır.":
                        "Bu da tek yönlü bir kural. Taşınması pahalı ve "
                        "işlenince küçülen hammaddede pazara yakınlık zarar "
                        "ettirir.",
                    "Ülkenin coğrafi merkezine kurmak.":
                        "Haritanın ortasını seçtin. Merkez, taşıma maliyetini "
                        "kendiliğinden azaltmaz; belirleyici olan neyin "
                        "taşındığı.",
                    "Arazi fiyatının en ucuz olduğu yere kurmak; arsa en büyük giderdir.":
                        "Tek kalemi hesaba kattın. Ucuz arazide kazandığını "
                        "taşımada kaybedebilirsin.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tek bir kural yoktur; karar hammadde ile ürünün "
                    "özelliklerini karşılaştırmaktan çıkar. Pancar ağır ve "
                    "bozulur, şeker dayanıklıdır: fabrika pancara gider. Un "
                    "dayanıklı, ekmek bayatlar: fırın tüketiciye gider. Aynı "
                    "ilke iki farklı sonuç verir."
                ),
                ipuclari=[
                    "Hammadde mi daha zor taşınıyor, ürün mü?",
                    "Hangisi bekleyince bozuluyor?",
                ],
                puan=20,
                cozum=(
                    "1) Hammaddeye bak: {} \n"
                    "2) Ürüne bak: taşıması ve saklaması nasıl?\n"
                    "3) Hangisi daha pahalı/riskli taşınıyorsa tesis ona yaklaşır.\n"
                    "4) {}\n\n"
                    "Sonuç: {} ({} çevresi)"
                ).format(
                    {"şeker pancarı": "ağır, hacimli, bekledikçe şeker oranı düşüyor",
                     "yaş çay yaprağı": "birkaç saatte bozuluyor",
                     "un": "dayanıklı ve kolay taşınıyor",
                     "demir cevheri ve kömür": "ikisi de çok ağır ve çok tüketiliyor",
                     }[tesis["hammadde"]],
                    tesis["neden"], tesis["dogru"], tesis["bolge"]),
            ),
            secim_adimi(
                soru="Bu tesis için doğru karar hangisidir?",
                dogru=tesis["dogru"],
                yanlislar=yanlislar[:4],
                rastgele=rastgele,
                aciklama=tesis["neden"],
                ipuclari=["Hammadde ve ürün kartlarını yan yana koy."],
                puan=16,
            ),
            secim_adimi(
                soru="Bu tesis hangi bölgeye kurulmalı?",
                dogru=tesis["bolge"],
                yanlislar={
                    b: "{} Bu ilkeye göre {} bölgesi uygun değil.".format(
                        tesis["neden"], b)
                    for b in ["İç Anadolu", "Doğu Karadeniz", "Marmara",
                              "Batı Karadeniz (Zonguldak havzası)",
                              "Güneydoğu Anadolu"]
                    if b != tesis["bolge"]
                },
                rastgele=rastgele,
                aciklama=(
                    "{} Bu yüzden tesis {} bölgesine kurulur."
                ).format(tesis["neden"], tesis["bolge"]),
                ipuclari=["Belirlediğin ilkeyi Türkiye haritasına uygula: "
                          "bu hammadde/pazar nerede?"],
                puan=14,
            ),
        ],
        kapanis="Tesis yeri kararı gerekçesiyle birlikte kayda geçti.",
        odul={"cevher": 6, "itibar": 6},
    )


# ==========================================================================
# YER ALTI KAYNAKLARI
# ==========================================================================

@bulmaca(ders="cografya", konu="yer_alti_kaynaklari", kademeler=(8, 13))
def kaynak_haritasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Hangi kaynak nereden çıkar; ve neden 'her yerden' çıkmaz."""
    kaynaklar = [
        {"kaynak": "taş kömürü", "yer": "Zonguldak (Batı Karadeniz)",
         "not": "Türkiye'nin işletilen tek taş kömürü havzasıdır."},
        {"kaynak": "demir cevheri", "yer": "Divriği (Sivas)",
         "not": "Türkiye'nin en önemli demir yataklarındandır."},
        {"kaynak": "krom", "yer": "Guleman (Elazığ)",
         "not": "Türkiye krom üretiminde önemli bir üreticidir."},
        {"kaynak": "bor", "yer": "Kırka, Emet, Bigadiç çevresi (İç Batı Anadolu)",
         "not": "Türkiye dünya bor rezervlerinin büyük bölümüne sahiptir."},
    ]
    kaynak = rastgele.choice(kaynaklar)
    digerleri = [k["yer"] for k in kaynaklar if k["yer"] != kaynak["yer"]]

    return Bulmaca(
        kod="cog-tr-kaynak",
        ders="cografya",
        baslik="Sipariş Fişi",
        kademe=kademe,
        konu="yer_alti_kaynaklari",
        kazanim="Türkiye'de başlıca yer altı kaynaklarının dağılışı.",
        dikkat=5,
        brifing=(
            "Üs, atölye için {} sipariş edecek. Sipariş fişinde çıkarıldığı "
            "yerin yazılması gerekiyor; merkez fişi yer adı olmadan işleme "
            "almıyor.\n\n"
            "Kâtip \"en yakın madenden yazalım\" diyor. Ama yer altı "
            "kaynakları tarım ürünleri gibi değildir: nerede oluştuysa oradan "
            "çıkar, istenen yere taşınamaz."
        ).format(kaynak["kaynak"]),
        kanitlar=[
            Kanit("Sipariş fişi",
                  "İstenen: {}\nÇıkarıldığı yer: (boş)".format(kaynak["kaynak"]),
                  bedel=1, kritik=True),
            Kanit("Maden dağılış çizelgesi",
                  "Taş kömürü: Zonguldak (Batı Karadeniz)\n"
                  "Demir cevheri: Divriği (Sivas)\n"
                  "Krom: Guleman (Elazığ)\n"
                  "Bor: Kırka, Emet, Bigadiç çevresi (İç Batı Anadolu)",
                  bedel=2, kritik=True),
            Kanit("Jeoloji notu",
                  "\"Madenler, yer kabuğunun oluşum geçmişine bağlı olarak "
                  "belirli yerlerde toplanır. Bu yüzden dağılışları tesadüfi "
                  "değildir ve değiştirilemez.\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Yer altı kaynaklarının dağılışını ne belirler?",
                dogru="Yer kabuğunun oluşum geçmişi; maden oluştuğu yerdedir.",
                yanlislar={
                    "İklim koşulları; sıcak bölgelerde daha çok maden bulunur.":
                        "İklimi yer altına taşıdın. Madenler milyonlarca yıl "
                        "önceki JEOLOJİK olaylarla oluştu; bugünkü hava "
                        "koşullarıyla ilgisi yok.",
                    "Nüfus yoğunluğu; kalabalık yerlerde daha çok maden çıkarılır.":
                        "Sebeple sonucu ters çevirdin. Maden bulunduğu için "
                        "orada nüfus artabilir; kalabalık maden yaratmaz.",
                    "Ulaşım imkânları; yol geçen yerlerde maden bulunur.":
                        "Yolu sebep saydın. Yol çoğu zaman madene ULAŞMAK için "
                        "sonradan yapılır.",
                    "Tarım ürünlerinin dağılışı.":
                        "Yüzeydeki tarımla yer altındaki yatakları "
                        "ilişkilendirdin. İkisini belirleyen etkenler "
                        "birbirinden bağımsız.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarım ürünlerinin yerini iklim belirler ve sera gibi "
                    "yöntemlerle bir ölçüde değiştirilebilir. Madenler ise "
                    "jeolojik geçmişin ürünüdür: yer kabuğunda milyonlarca yıl "
                    "içinde oluştukları yerde bulunurlar. Ulaşım ve nüfus "
                    "madenin çıkarılmasını kolaylaştırır ama madeni var etmez."
                ),
                ipuclari=[
                    "Bir madeni istediğin yerde yetiştirebilir misin?",
                    "Tarım ürünüyle maden arasındaki temel fark ne?",
                ],
                puan=18,
                cozum=(
                    "1) Maden, oluşum geçmişine bağlı olarak sabit bir yerdedir.\n"
                    "2) Çizelgeden bu kaynağın satırını bul.\n"
                    "3) {}: {}\n"
                    "4) {}"
                ).format(kaynak["kaynak"].capitalize(), kaynak["yer"], kaynak["not"]),
            ),
            secim_adimi(
                soru="Fişe hangi yer yazılmalı?",
                dogru=kaynak["yer"],
                yanlislar=digerleri,
                rastgele=rastgele,
                aciklama="{} {}".format(kaynak["not"], "Çizelgedeki ilgili satır budur."),
                ipuclari=["Maden dağılış çizelgesini oku."],
                puan=14,
            ),
            yorum_adimi(
                soru="Neden bir madeni \"daha yakın bir yerden\" alamıyoruz?",
                dogru=("Maden yalnızca oluştuğu yerde bulunur; yakınlık onu var etmez."),
                yanlislar={
                    "Devlet başka yerden almayı yasakladığı için; engel idari bir karar.":
                        "Engeli idari bir yasak sandın. Sorun izin değil, o "
                        "madenin yakında BULUNMAMASI.",
                    "Yakın yerlerdeki madenler daha düşük kaliteli olduğu için.":
                        "Kalite sorunu varsaydın. Yakında o madenden hiç yok; "
                        "kaliteli ya da kalitesiz diye bir seçenek bile "
                        "oluşmuyor.",
                    "Nakliye şirketleri anlaşma yapmadığı için.":
                        "Sorunu taşımacılığa bağladın. Nakliye ancak var olan "
                        "bir madeni taşıyabilir.",
                    "Aslında alınabilir; sadece daha pahalı olur, para her engeli aşar.":
                        "Yer altı kaynağı para ile taşınabilir bir şey değil; "
                        "yatak nerede oluştuysa oradadır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tedarik kararında iki farklı kısıt vardır: tarımda 'yetişir mi' "
                    "sorusu iklime, madencilikte 'var mı' sorusu jeolojiye bağlıdır. "
                    "İkincisinde seçenek yoktur - bu yüzden madene dayalı sanayi "
                    "kaynağın yanına kurulur."
                ),
                puan=12,
            ),
        ],
        kapanis="Sipariş fişi \"{}\" yazılarak merkeze gönderildi.".format(kaynak["yer"]),
        odul={"cevher": 7, "itibar": 4},
    )
