# -*- coding: utf-8 -*-
"""
Toplumsal düzen ve yurttaşlık görevleri.

Çerçeve: Meridyen Üssü bir devlet kurumu gibi işler; yazışmalar, yetki
sınırları ve itiraz yolları vardır. Öğrenci burada madde ezberlemez, bir
işlemin hangi kurala göre yürüdüğünü çıkarır.

Kapsam kasten dar tutuldu: yalnızca yıllara göre değişmeyen, ders kitabı
düzeyinde yerleşmiş konular. Sık değişen sayısal ayrıntılar (kurul üye
sayıları, süreler) bilerek dışarıda bırakıldı.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import PERSONEL, ad_sec, model_adimi, secim_adimi, sirala_adimi, yorum_adimi


# ==========================================================================
# NORMLAR HİYERARŞİSİ
# ==========================================================================

@bulmaca(ders="vatandaslik", konu="normlar_hiyerarsisi", kademeler=(9, 13),
         agirlik=1.3)
def normlar_hiyerarsisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki kural çelişiyor; hangisinin üstün olduğu bulunacak."""
    basamaklar = ["Anayasa", "Kanun", "Yönetmelik", "Genelge"]
    karisik = list(basamaklar)
    rastgele.shuffle(karisik)
    dogru_sira = [karisik.index(b) for b in basamaklar]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="vat-normlar",
        ders="vatandaslik",
        baslik="Çelişen İki Yazı",
        kademe=kademe,
        konu="normlar_hiyerarsisi",
        kazanim="Normlar hiyerarşisi; alt düzenlemenin üst kurala aykırı olamayacağı.",
        dikkat=6,
        brifing=(
            "Üsse aynı hafta iki yazı geldi ve ikisi birbirini tutmuyor.\n\n"
            "Biri bir kanun maddesine dayanıyor; diğeri bir kurumun kendi "
            "çıkardığı yönetmeliğe. Yönetmelik, kanunun izin verdiği bir işlemi "
            "yasaklıyor.\n\n"
            "{} \"son gelen yazı geçerlidir, tarihine bakalım\" diyor. Ama "
            "hangisinin uygulanacağını tarih değil, başka bir şey belirliyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Birinci yazı",
                  "Dayanak: Kanun. İşlemin yapılabileceğini belirtiyor. "
                  "Tarihi daha eski.", bedel=1, kritik=True),
            Kanit("İkinci yazı",
                  "Dayanak: Yönetmelik. Aynı işlemi yasaklıyor. Tarihi daha yeni.",
                  bedel=1, kritik=True),
            Kanit("Hukuk el kitabı - normlar hiyerarşisi",
                  "Kurallar bir piramit oluşturur. Yukarıdan aşağıya:\n"
                  "  Anayasa > Kanun > Yönetmelik > Genelge\n"
                  "Alt sıradaki bir düzenleme, üst sıradakine AYKIRI olamaz. "
                  "Aykırıysa geçersizdir.", bedel=2, kritik=True),
            Kanit("Hukuk el kitabı - dayanak",
                  "\"Yönetmelikler kanunları uygulamak için çıkarılır; kanunun "
                  "izin verdiğini yasaklayamaz, yasakladığını serbest bırakamaz.\"",
                  bedel=2, kritik=True),
            Kanit("Evrak kayıt defteri",
                  "İki yazının da geliş tarihi kayıtlı. Aralarında on gün var.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İki kural çeliştiğinde hangisinin uygulanacağını ne belirler?",
                dogru="Kuralların hiyerarşideki basamağı; üstteki kural üstündür.",
                yanlislar={
                    "Kuralın tarihi; sonradan çıkan kural önce çıkanı geçersiz kılar.":
                        "Tarihi tek ölçüt saydın. Yeni tarihli olmak ancak "
                        "AYNI düzeydeki kurallar arasında geçerlidir; alt "
                        "düzey bir kural, üstündekini tarihi yeni diye "
                        "geçersiz kılamaz.",
                    "Kuralı çıkaran kurumun büyüklüğü.":
                        "Kurumun büyüklüğüne baktın. Belirleyici olan kurumun "
                        "boyu değil, kuralın hukuk basamağındaki YERİ.",
                    "Kuralın daha ayrıntılı yazılmış olması.":
                        "Ayrıntıyı üstünlük saydın. Ayrıntılı bir yönetmelik "
                        "de kanuna aykırı olamaz.",
                    "İşlemi yapacak görevlinin tercihi.":
                        "Kararı kişiye bıraktın. Hukukun sıradüzeni tam da "
                        "bunu önlemek için var.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Sonraki kural öncekini kaldırır\" ilkesi yalnızca AYNI "
                    "basamaktaki kurallar için geçerlidir: yeni bir kanun eski bir "
                    "kanunu değiştirebilir. Farklı basamaklarda ise tarih değil "
                    "hiyerarşi belirler; yeni çıkmış bir yönetmelik eski bir kanunu "
                    "aşamaz, çünkü yönetmeliğin varlık sebebi zaten o kanundur."
                ),
                ipuclari=[
                    "Yönetmelik neye dayanarak çıkarılır?",
                    "Bir kural, kendisine dayanak olan kuralı geçersiz kılabilir mi?",
                ],
                puan=20,
                cozum=(
                    "1) İki yazının DAYANAĞINI bul: biri kanun, biri yönetmelik.\n"
                    "2) Piramitteki yerlerine bak: Kanun, Yönetmelik'in üstündedir.\n"
                    "3) Alt basamak üst basamağa aykırı olamaz; aykırı olan hüküm "
                    "uygulanmaz.\n"
                    "4) Tarih burada ölçüt değildir - tarih yalnızca aynı basamaktaki "
                    "iki kural çeliştiğinde işe yarar.\n\n"
                    "Sonuç: kanuna dayanan birinci yazı uygulanır."
                ),
            ),
            sirala_adimi(
                soru="Kuralları üstten alta doğru sırala (numaraları sırayla yaz):",
                secenekler=karisik,
                dogru_sira=dogru_sira,
                aciklama=("Doğru sıra: Anayasa - Kanun - Yönetmelik - Genelge. "
                          "Her basamak, kendisinden üsttekine dayanır ve ona aykırı olamaz."),
                ipuclari=[
                    "En üstte, diğer bütün kuralların dayandığı metin vardır.",
                    "Genelge bir kurumun kendi iç işleyişi için çıkardığı en alt düzenlemedir.",
                ],
                puan=18,
            ),
            secim_adimi(
                soru="Bu durumda hangi yazı uygulanmalıdır?",
                dogru="Kanuna dayanan birinci yazı; kanuna aykırı yönetmelik uygulanmaz.",
                yanlislar={
                    "Yönetmeliğe dayanan ikinci yazı, çünkü tarihi daha yenidir ve eskisinin yerini alır.":
                        "Yeni tarihi üstünlük saydın. Yönetmelik kanunun "
                        "altındadır; ne kadar yeni olursa olsun ona aykırı "
                        "hüküm getiremez.",
                    "İkisi de uygulanmaz; çelişki giderilinceye kadar yeni bir yazı beklenir.":
                        "İşi durdurdun. Çelişki zaten çözülebilir: üst "
                        "basamaktaki kural uygulanır.",
                    "İkisi de uygulanır, görevli seçer.":
                        "İki çelişen kural aynı anda uygulanamaz; hangisinin "
                        "geçerli olduğunu görevlinin tercihi değil, "
                        "sıradüzen belirler.",
                    "Genelge çıkarılana kadar işlem durdurulur.":
                        "Yeni bir belge beklemeye gerek yok; elindeki iki "
                        "kuraldan hangisinin üstün olduğu zaten belli.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yönetmelik kanunun izin verdiği bir işlemi yasaklayamaz. Aykırı "
                    "yönetmelik hükmü uygulanmaz ve iptali için yargıya başvurulabilir. "
                    "Tarihinin yeni olması bu sonucu değiştirmez."
                ),
                ipuclari=["Piramitte hangisi üstte?"],
                puan=14,
            ),
        ],
        kapanis="İşlem kanuna göre yapıldı; aykırı yönetmelik maddesi için kuruma bildirim yazıldı.",
        odul={"itibar": 8},
    )


# ==========================================================================
# KUVVETLER AYRILIĞI
# ==========================================================================

@bulmaca(ders="vatandaslik", konu="kuvvetler_ayriligi", kademeler=(9, 13))
def kuvvetler_ayriligi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir işin hangi erke ait olduğu, işin niteliğinden çıkarılacak."""
    islemler = [
        {
            "is": "Yeni bir kanun kabul edilmesi",
            "erk": "Yasama",
            "neden": "Kural koymak, kaldırmak ve değiştirmek yasama işidir.",
        },
        {
            "is": "Kanunun uygulanması için yönetmelik çıkarılması",
            "erk": "Yürütme",
            "neden": "Konulmuş kuralı hayata geçirmek yürütmenin işidir.",
        },
        {
            "is": "İki taraf arasındaki uyuşmazlığın karara bağlanması",
            "erk": "Yargı",
            "neden": "Uyuşmazlığı kurala göre çözmek ve hüküm vermek yargı işidir.",
        },
        {
            "is": "Bütçenin görüşülüp kabul edilmesi",
            "erk": "Yasama",
            "neden": "Bütçe kanunla kabul edilir; kanun yapmak yasamanın işidir.",
        },
    ]
    islem = rastgele.choice(islemler)

    return Bulmaca(
        kod="vat-kuvvetler",
        ders="vatandaslik",
        baslik="Yetki Kimde",
        kademe=kademe,
        konu="kuvvetler_ayriligi",
        kazanim="Yasama, yürütme ve yargı erklerinin işlevlerini ayırt etme.",
        dikkat=5,
        brifing=(
            "Üsse gelen bir dosyanın hangi makama gönderileceği tartışmalı. "
            "Dosyadaki iş şu:\n\n"
            "  \"{}\"\n\n"
            "Kâtip \"en yetkili makama gönderelim, o dağıtır\" diyor. Ama "
            "devlette işler makamın büyüklüğüne göre değil, işin NİTELİĞİNE "
            "göre dağıtılır."
        ).format(islem["is"]),
        kanitlar=[
            Kanit("Dosya özeti", islem["is"], bedel=1, kritik=True),
            Kanit("Anayasa el kitabı - erkler",
                  "YASAMA: kural koyar, değiştirir, kaldırır (kanun yapar).\n"
                  "YÜRÜTME: konulmuş kuralları uygular, işleri yürütür.\n"
                  "YARGI: uyuşmazlıkları kurala göre çözer, hüküm verir.",
                  bedel=2, kritik=True),
            Kanit("Hukuk devleti ilkesi",
                  "\"Erkler birbirinden ayrıdır ve birbirinin işini yapamaz. "
                  "Bu ayrım keyfîliği önlemek içindir.\"", bedel=2, kritik=True),
            Kanit("Kâtibin notu",
                  "\"Bana kalırsa hepsi devlet, fark etmez.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir işin hangi erke ait olduğunu ne belirler?",
                dogru="İşin niteliği: kural koymak, uygulamak ya da uyuşmazlık çözmek.",
                yanlislar={
                    "İşi yapacak makamın devlet içindeki büyüklüğü; en üst makam hepsini yapar.":
                        "Makamın büyüklüğüne baktın. Erk ayrımı makamların "
                        "boyutuna göre değil, YAPILAN İŞİN türüne göredir: "
                        "kural koymak, uygulamak, yargılamak.",
                    "İşin ne kadar acil olduğu.":
                        "Aciliyeti ölçüt saydın. Acil bir iş de kural koymak, "
                        "uygulamak ya da yargılamak olabilir.",
                    "İşin kaç kişiyi ilgilendirdiği.":
                        "Kapsamı ölçüt saydın. Tek kişiyi ilgilendiren bir "
                        "yargı kararı da yargı erkine aittir.",
                    "İşin bütçeye etkisinin büyüklüğü.":
                        "Parayı ölçüt saydın. Bütçe büyüklüğü işin türünü "
                        "değiştirmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kuvvetler ayrılığında ölçüt makam değil işlevdir. Aynı konu "
                    "üç erki de ilgilendirebilir: trafik kuralını yasama koyar, "
                    "yürütme uygular, kurala uyulmadığında yargı karara bağlar. "
                    "Bu yüzden \"kim daha yetkili\" sorusu değil \"bu iş hangi türden\" "
                    "sorusu sorulur."
                ),
                ipuclari=[
                    "Bu iş yeni bir kural mı koyuyor?",
                    "Yoksa var olan bir kuralı mı uyguluyor?",
                ],
                puan=18,
                cozum=(
                    "İşi üç soruyla ele:\n"
                    "  1) Yeni bir kural koyuyor/değiştiriyor mu? -> YASAMA\n"
                    "  2) Var olan kuralı uyguluyor, işi yürütüyor mu? -> YÜRÜTME\n"
                    "  3) Taraflar arasında uyuşmazlığı çözüp hüküm veriyor mu? -> YARGI\n\n"
                    "Bu dosyadaki iş: \"{}\"\n"
                    "{}\n"
                    "Sonuç: {} erki."
                ).format(islem["is"], islem["neden"], islem["erk"]),
            ),
            secim_adimi(
                soru="Bu iş hangi erke aittir?",
                dogru=islem["erk"],
                yanlislar=dict(
                    [(e, "{} erkinin işi kural koymak, uygulamak ya da "
                         "yargılamaktan biri; bu olay o tanıma uymuyor. El "
                         "kitabındaki üç tanımı işle karşılaştır.".format(e))
                     for e in ["Yasama", "Yürütme", "Yargı"] if e != islem["erk"]]
                    + [("Üçü birlikte karar verir",
                        "Erkleri birleştirdin. Ayrılığın sebebi tam da "
                        "üçünün aynı elde toplanmamasıdır.")]
                ),
                rastgele=rastgele,
                aciklama=islem["neden"],
                ipuclari=["El kitabındaki üç tanımı işle karşılaştır."],
                puan=16,
            ),
            yorum_adimi(
                soru="Erklerin ayrı olması neden önemlidir?",
                dogru="Kuralı koyan, uygulayan ve denetleyen ayrı olunca keyfîlik önlenir.",
                yanlislar={
                    "İşlerin daha hızlı bitmesini sağlar.":
                        "Hızı amaç saydın. Erklerin ayrılığı çoğu zaman işi "
                        "YAVAŞLATIR; amacı hız değil, denetim.",
                    "Devletin daha az personel çalıştırmasını sağlar, çünkü her erk kendi işine bakar.":
                        "Ayrılık daha az değil, daha çok kurum demektir. "
                        "Amaç tasarruf değil.",
                    "Bütçeden tasarruf edilmesini sağlar.":
                        "Amacı maliyete bağladın. Erk ayrımı bir güvenlik "
                        "düzeneğidir, bir bütçe tedbiri değil.",
                    "Kanunların daha kısa yazılmasını sağlar.":
                        "Metin uzunluğuyla ilgisi yok. Ayrılığın konusu "
                        "kanunun biçimi değil, kimin uyguladığı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı makam hem kuralı koyup hem uygulayıp hem de "
                    "uyuşmazlığı karara bağlarsa, kendi işlemini kendi denetlemiş "
                    "olur. Ayrım hızı artırmaz - tam tersine yavaşlatır; amacı "
                    "verim değil denetimdir."
                ),
                puan=12,
            ),
        ],
        kapanis="Dosya, niteliğine uygun makama gönderildi.",
        odul={"itibar": 7},
    )


# ==========================================================================
# HAKLARIN SINIFLANDIRILMASI
# ==========================================================================

@bulmaca(ders="vatandaslik", konu="temel_haklar", kademeler=(9, 13))
def haklarin_turleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir talebin hangi hak grubuna girdiği, devletten ne istendiğinden çıkar."""
    talepler = [
        {
            "talep": "Kimsenin haberleşmesinin izinsiz dinlenmemesi",
            "grup": "Kişi hakları (koruyucu haklar)",
            "neden": ("Devletten bir şey YAPMAMASI isteniyor: karışmaması, "
                      "dokunmaması. Koruyucu hakların ayırt edici özelliği budur."),
        },
        {
            "talep": "Herkesin parasız ilköğretimden yararlanabilmesi",
            "grup": "Sosyal ve ekonomik haklar (isteme hakları)",
            "neden": ("Devletten bir edim, bir hizmet İSTENİYOR. Bu haklar devletin "
                      "olanakları ölçüsünde yerine getirdiği isteme haklarıdır."),
        },
        {
            "talep": "Vatandaşların seçimlerde oy kullanabilmesi",
            "grup": "Siyasi haklar (katılma hakları)",
            "neden": ("Yönetime KATILMA talebidir. Siyasi haklar vatandaşın devlet "
                      "yönetiminde söz sahibi olmasını sağlar."),
        },
        {
            "talep": "Herkesin dilekçeyle yetkili makamlara başvurabilmesi",
            "grup": "Siyasi haklar (katılma hakları)",
            "neden": ("Dilekçe hakkı, vatandaşın yönetime katılma ve denetleme "
                      "yollarından biridir."),
        },
        {
            "talep": "Kimsenin işkenceye ve kötü muameleye uğramaması",
            "grup": "Kişi hakları (koruyucu haklar)",
            "neden": ("Devletin karışmaması, dokunmaması istenen bir alandır; "
                      "koruyucu haklar grubuna girer."),
        },
    ]
    talep = rastgele.choice(talepler)
    gruplar = ["Kişi hakları (koruyucu haklar)",
               "Sosyal ve ekonomik haklar (isteme hakları)",
               "Siyasi haklar (katılma hakları)"]

    return Bulmaca(
        kod="vat-haklar",
        ders="vatandaslik",
        baslik="Dilekçe Kutusu",
        kademe=kademe,
        konu="temel_haklar",
        kazanim="Temel hak ve hürriyetlerin sınıflandırılması.",
        dikkat=5,
        brifing=(
            "Üssün dilekçe kutusundan çıkan talepler türlerine göre "
            "dosyalanacak. Elindeki dilekçede şu talep var:\n\n"
            "  \"{}\"\n\n"
            "Dosyalama üç klasöre yapılıyor ve yanlış klasöre konan dilekçe "
            "aylarca kayboluyor."
        ).format(talep["talep"]),
        kanitlar=[
            Kanit("Dilekçe metni", talep["talep"], bedel=1, kritik=True),
            Kanit("Sınıflandırma kılavuzu",
                  "KİŞİ HAKLARI (koruyucu): devletin KARIŞMAMASI istenir. "
                  "Kişi dokunulmazlığı, özel hayatın gizliliği, konut "
                  "dokunulmazlığı, haberleşme hürriyeti.\n\n"
                  "SOSYAL VE EKONOMİK HAKLAR (isteme): devletten bir HİZMET, "
                  "bir edim istenir. Eğitim, sağlık, çalışma, konut, sosyal güvenlik.\n\n"
                  "SİYASİ HAKLAR (katılma): yönetime KATILMA sağlanır. Seçme "
                  "ve seçilme, siyasi parti kurma, dilekçe, kamu hizmetine girme.",
                  bedel=2, kritik=True),
            Kanit("Ayırt etme notu",
                  "\"Tek soruyla ayrılır: devletten ne isteniyor? Karışmamasını mı, "
                  "bir hizmet vermesini mi, yönetime katılmayı mı?\"",
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir hakkın hangi gruba girdiğini ne belirler?",
                dogru="Devletten ne beklendiği: karışmama, hizmet ya da katılım olanağı.",
                yanlislar={
                    "Hakkın anayasada kaçıncı maddede yazdığı.":
                        "Madde numarasına baktın. Sıra numarası bir "
                        "sınıflandırma ölçütü değil; belirleyici olan hakkın "
                        "devletten NE İSTEDİĞİ.",
                    "Hakkın ne kadar önemli olduğu, çünkü en önemliler ayrı grupta toplanır.":
                        "Önemi ölçüt saydın. Hakların hepsi önemlidir; gruplar "
                        "önem sırasına göre değil, niteliğe göre kurulur.",
                    "Hakkın kaç kişiyi ilgilendirdiği; herkesi ilgilendiren hak bir grupta toplanır.":
                        "Kapsamı ölçüt saydın. Herkesi ilgilendiren haklar "
                        "farklı gruplara dağılır.",
                    "Hakkın ne zaman tanındığı.":
                        "Tarihe baktın. Tanınma zamanı hakkın türünü "
                        "değiştirmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sınıflandırmanın ölçütü devletin ÜSTLENDİĞİ YÜKÜMLÜLÜKTÜR. "
                    "Koruyucu haklarda devlet çekilir; isteme haklarında bir edim "
                    "üstlenir; katılma haklarında vatandaşa yönetimde yer açar. "
                    "Madde numarası ya da önem sırası sınıflandırmayı belirlemez."
                ),
                ipuclari=[
                    "Bu talep devletten bir şey YAPMASINI mı istiyor, YAPMAMASINI mı?",
                    "Yönetime katılmayla ilgisi var mı?",
                ],
                puan=18,
                cozum=(
                    "Tek soruyla ayır: \"Devletten ne isteniyor?\"\n"
                    "  - Karışmasın, dokunmasın -> KİŞİ HAKLARI\n"
                    "  - Bir hizmet versin, bir edimde bulunsun -> SOSYAL VE EKONOMİK\n"
                    "  - Yönetime katılmamı sağlasın -> SİYASİ HAKLAR\n\n"
                    "Bu dilekçede: \"{}\"\n{}\n"
                    "Sonuç: {}"
                ).format(talep["talep"], talep["neden"], talep["grup"]),
            ),
            secim_adimi(
                soru="Bu talep hangi hak grubuna girer?",
                dogru=talep["grup"],
                yanlislar=dict(
                    [(g, "{} grubunun tanımı bu talebin istediğiyle "
                         "uyuşmuyor. Kılavuzdaki tanımları dilekçeyle "
                         "karşılaştır.".format(g))
                     for g in gruplar if g != talep["grup"]]
                    + [("Hiçbiri; dilekçedeki şey bir hak değil, yalnızca bir talep",
                        "Hak ile talebi karşı karşıya koydun. Dilekçe bir "
                        "talebin biçimi; içinde ileri sürülen şey yine bir "
                        "haktır.")]
                ),
                rastgele=rastgele,
                aciklama=talep["neden"],
                ipuclari=["Kılavuzdaki üç tanımı dilekçeyle karşılaştır."],
                puan=16,
            ),
            yorum_adimi(
                soru="Sosyal ve ekonomik haklar neden \"devletin olanakları ölçüsünde\" yerine getirilir?",
                dogru="Devletten kaynak gerektiren bir edim istedikleri için.",
                yanlislar={
                    "Daha az önemli oldukları için.":
                        "Sınırı önemsizliğe bağladın. Bu haklar daha az "
                        "önemli değil; devletten KAYNAK gerektirdikleri için "
                        "olanaklarla sınırlı.",
                    "Anayasada sonradan eklendikleri için.":
                        "Tarihe bağladın. Ne zaman yazıldıkları, nasıl yerine "
                        "getirildiklerini belirlemez.",
                    "Yalnızca bazı vatandaşları, örneğin muhtaç olanları ilgilendirdikleri için.":
                        "Kapsamı daralttın. Eğitim ve sağlık herkesi "
                        "ilgilendirir; sınır kapsamdan değil maliyetten "
                        "geliyor.",
                    "Mahkemeye taşınamadıkları, yani dava konusu olamadıkları için.":
                        "Yargı yolunu kapattın. Bu haklar da dava konusu "
                        "olabilir; sınır, devletin edim gücüyle ilgili.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir kişinin haberleşmesine karışmamak devlete para "
                    "harcatmaz; ama herkese parasız eğitim vermek okul, öğretmen ve "
                    "bütçe gerektirir. Bu yüzden isteme haklarında anayasa devlete "
                    "kademeli bir yükümlülük yükler. Bu, hakkın değersiz olduğu "
                    "anlamına gelmez; yerine getirilme biçiminin farklı olduğu anlamına gelir."
                ),
                puan=12,
            ),
        ],
        kapanis="Dilekçe doğru klasöre kondu ve ilgili birime havale edildi.",
        odul={"itibar": 7},
    )


# ==========================================================================
# HUKUK KURALLARININ AYIRT EDİCİ ÖZELLİĞİ
# ==========================================================================

@bulmaca(ders="vatandaslik", konu="sosyal_duzen_kurallari", kademeler=(8, 13))
def sosyal_duzen_kurallari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Hukuk kuralını ahlak, din ve görgü kurallarından ayıran şey: yaptırım."""
    ornekler = [
        {
            "olay": "Sözleşmeye uymayan yükleniciden tazminat alınması",
            "tur": "Hukuk kuralı",
            "neden": ("Devlet gücüyle uygulanan, maddi ve örgütlü bir yaptırımı "
                      "(tazminat) var. Hukuk kuralını ayıran şey budur."),
        },
        {
            "olay": "Yaşlı birine oturacak yer verilmesi",
            "tur": "Görgü kuralı",
            "neden": ("Uyulmadığında ayıplanma dışında bir yaptırım yoktur; "
                      "devlet zorla uygulatmaz."),
        },
        {
            "olay": "Verilen sözün tutulması gerektiği inancı",
            "tur": "Ahlak kuralı",
            "neden": ("Yaptırımı vicdani rahatsızlık ve toplumsal kınamadır; "
                      "manevi ve örgütsüzdür."),
        },
    ]
    ornek = rastgele.choice(ornekler)

    return Bulmaca(
        kod="vat-sosyal-duzen",
        ders="vatandaslik",
        baslik="Yaptırım Kimde",
        kademe=kademe,
        konu="sosyal_duzen_kurallari",
        kazanim="Hukuk kurallarını diğer sosyal düzen kurallarından ayırt etme.",
        dikkat=5,
        brifing=(
            "Üste bir anlaşmazlık çıktı ve olayın \"kural ihlali\" sayılıp "
            "sayılmayacağı tartışılıyor. Olay şu:\n\n"
            "  \"{}\"\n\n"
            "Bazıları \"bu ayıp\" diyor, bazıları \"bu suç\". İkisi aynı şey "
            "değil ve hangisi olduğuna karar vermeden dosya açılamıyor."
        ).format(ornek["olay"]),
        kanitlar=[
            Kanit("Olay özeti", ornek["olay"], bedel=1, kritik=True),
            Kanit("Sosyal düzen kuralları çizelgesi",
                  "HUKUK: yaptırımı maddi ve ÖRGÜTLÜDÜR; devlet gücüyle uygulanır "
                  "(ceza, tazminat, iptal).\n"
                  "AHLAK: yaptırımı manevidir; vicdan ve kınama.\n"
                  "DİN: yaptırımı uhrevidir.\n"
                  "GÖRGÜ: yaptırımı ayıplanmadır.",
                  bedel=2, kritik=True),
            Kanit("Ayırt etme notu",
                  "\"Bir kuralın hukuk kuralı olup olmadığını konusu değil "
                  "YAPTIRIMI belirler. Aynı davranış hem ahlaka hem hukuka aykırı "
                  "olabilir; ölçüt, devletin zorla uygulatıp uygulatmadığıdır.\"",
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir kuralın hukuk kuralı olup olmadığını ne belirler?",
                dogru="Devlet gücüyle uygulanan örgütlü bir yaptırımı olması.",
                yanlislar={
                    "Kuralın yazılı olması.":
                        "Yazılı olmayı ölçüt saydın. Görgü kuralları da "
                        "yazılabilir; hukuk kuralını ayıran şey devletin "
                        "arkasındaki YAPTIRIM.",
                    "Kuralın herkes tarafından bilinmesi; bilinen kurala herkes uymak zorundadır.":
                        "Bilinirliği ölçüt saydın. Bilinmeyen bir kanun da "
                        "hukuk kuralıdır.",
                    "Kuralın ahlaka uygun olması.":
                        "Ahlakı ölçüt saydın. İkisi çoğu zaman örtüşür ama "
                        "hukuk kuralını tanımlayan şey ahlaka uygunluk değil.",
                    "Kuralın çok eski olması.":
                        "Eskiliği ölçüt saydın. Dün çıkmış bir kanun da hukuk "
                        "kuralıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ölçüt yaptırımdır. \"Yalan söyleme\" hem ahlak kuralıdır hem de "
                    "mahkemede yalan tanıklık biçiminde hukuk kuralıdır; ikisini "
                    "ayıran konu değil, arkasında devlet zoru olup olmadığıdır. "
                    "Yazılı olmak da yetmez: bir kurumun görgü rehberi yazılıdır ama "
                    "hukuk kuralı değildir."
                ),
                ipuclari=[
                    "Bu kurala uyulmazsa ne olur? Kim ne yapar?",
                    "Yaptırımı uygulayan bir devlet organı var mı?",
                ],
                puan=18,
                cozum=(
                    "Sor: \"Uyulmazsa ne olur ve bunu kim uygular?\"\n"
                    "  - Devlet organı ceza/tazminat/iptal uyguluyorsa -> HUKUK\n"
                    "  - Yalnızca vicdan sızlıyorsa -> AHLAK\n"
                    "  - Yalnızca ayıplanıyorsa -> GÖRGÜ\n\n"
                    "Bu olayda: \"{}\"\n{}\n"
                    "Sonuç: {}"
                ).format(ornek["olay"], ornek["neden"], ornek["tur"]),
            ),
            secim_adimi(
                soru="Bu olay hangi tür kuralla ilgilidir?",
                dogru=ornek["tur"],
                yanlislar={
                    t: "{} türünün yaptırımı bu olaydakiyle uyuşmuyor. "
                       "Çizelgedeki yaptırım sütununa bak.".format(t)
                    for t in ["Hukuk kuralı", "Ahlak kuralı", "Görgü kuralı",
                              "Din kuralı"] if t != ornek["tur"]
                },
                rastgele=rastgele,
                aciklama=ornek["neden"],
                ipuclari=["Çizelgedeki yaptırım türlerini olayla karşılaştır."],
                puan=16,
            ),
            yorum_adimi(
                soru="Aynı davranış hem ahlaka hem hukuka aykırı olabilir mi?",
                dogru="Evet; konu çakışabilir, ayrım yaptırımdadır.",
                yanlislar={
                    "Hayır; bir davranış yalnızca bir kural türüne girebilir.":
                        "Türleri birbirini dışlar saydın. Hırsızlık hem "
                        "ahlaka hem hukuka aykırıdır; ayrım konuda değil "
                        "yaptırımda.",
                    "Hayır; hukuk kuralları ahlakla ilgilenmez.":
                        "İkisini tamamen ayırdın. Hukukun pek çok kuralı "
                        "ahlaki bir kaygıdan doğar.",
                    "Evet ama yalnızca yazılı ahlak kurallarında.":
                        "Yazılı olmayı şart koştun. Ahlak kuralları çoğunlukla "
                        "yazısızdır ve yine de hukukla çakışabilir.",
                    "Evet ama bu durumda hukuk kuralı geçersiz olur.":
                        "Çakışmayı çelişki saydın. İki kural aynı yönde "
                        "olduğunda biri ötekini geçersiz kılmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Hırsızlık hem ahlaka aykırıdır hem suçtur. Kural türleri "
                    "birbirini dışlamaz; aynı davranışı farklı yaptırımlarla ele "
                    "alırlar. Bu yüzden \"bu ahlaki bir mesele, hukuki değil\" cümlesi "
                    "çoğu zaman yanlış bir ayrım kurar."
                ),
                puan=12,
            ),
        ],
        kapanis="Olayın türü belirlendi ve dosya buna göre açıldı.",
        odul={"itibar": 6},
    )
