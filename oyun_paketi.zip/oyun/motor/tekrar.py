# -*- coding: utf-8 -*-
"""Konu başına günlere yayılan hatırlama. Süre/seri kaybı cezası yok.

1, 3, 7, 14 gün pilotta ayarlanacak başlangıç aralıklarıdır. Bir günde
aynı konuyu çok kez çözmek aralığı büyütmez. Yardımlı çalışmadan sonra
ertesi gün yeniden bakılır; bu plan tek başına ustalık kanıtı değildir.
"""
from datetime import date, timedelta

from .ders_programi import simdi
from .modeller import SERBEST

ARALIKLAR = (1, 3, 7, 14)


def _tarih(metin):
    try:
        return date.fromisoformat(metin)
    except (TypeError, ValueError):
        return None


def tekrari_planla(durum, sonuc, bugun=None):
    if sonuc.birakildi or not sonuc.tamamlandi:
        return
    bugun = bugun or simdi().date()
    konu = durum.ders(sonuc.ders).konu(sonuc.konu)
    son = _tarih(konu.son_calisma_gunu)
    if son and bugun < son:
        return  # Bilgisayar saati geri alındığında öğrenme takvimini geriletme.
    plan = _tarih(konu.tekrar_gunu)
    bagimsiz = (sonuc.asama == SERBEST and bool(sonuc.adim_sonuclari)
                and all(s.dogru and s.deneme == 1 and not s.destek_aldi
                        for s in sonuc.adim_sonuclari))
    basamak = max(0, min(len(ARALIKLAR) - 1, konu.tekrar_basamagi))
    yeni_duzey = konu.tekrar_kademesi != sonuc.kademe
    if not bagimsiz or not plan or yeni_duzey:
        basamak = 0
        konu.tekrar_gunu = (bugun + timedelta(days=ARALIKLAR[0])).isoformat()
    elif son and bugun > son and bugun >= plan:
        basamak = min(basamak + 1, len(ARALIKLAR) - 1)
        konu.tekrar_gunu = (bugun + timedelta(days=ARALIKLAR[basamak])).isoformat()
    # Aynı gün veya planlanan günden önceki başarılı çalışmada tarih korunur.
    konu.tekrar_basamagi = basamak
    konu.tekrar_kademesi = sonuc.kademe
    konu.son_calisma_gunu = bugun.isoformat()


def zamani_gelen_konular(durum, ders=None, bugun=None):
    """(ders, konu) çiftleri: en eski tekrar tarihi önce. Eski kayıt uydurulmaz."""
    bugun = bugun or simdi().date()
    bulunan = []
    for kod, dd in durum.dersler.items():
        if ders and ders != kod:
            continue
        for konu, kd in dd.konular.items():
            plan, son = _tarih(kd.tekrar_gunu), _tarih(kd.son_calisma_gunu)
            if plan and son and son < bugun and plan <= bugun:
                bulunan.append((plan, kod, konu))
    return [(kod, konu) for _, kod, konu in sorted(bulunan)]
