# -*- coding: utf-8 -*-
"""
İnanç, kültür ve ahlaki düşünme görevleri.

İçerik ders kitabı düzeyinde ve bilgi verici tutuldu: ibadetlerin hesaplanma
kuralları, ahlaki kavramların tanımları ve dinler hakkında olgusal bilgiler.
Metinler bir inancı savunmaz ya da eleştirmez; müfredatta öğretildiği biçimde
aktarır.

Hesaplamalı görevler (zekât gibi) bu derste keşif formatına çok uygun: kural
bellidir ama hangi malın hesaba katılacağını öğrenci kendisi çıkarır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi, sy, yorum_adimi,
)


# ==========================================================================
# ZEKÂT HESABI
# ==========================================================================

@bulmaca(ders="din_kulturu", konu="ibadetler", kademeler=(7, 12), agirlik=1.3)
def zekat_hesabi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Hangi malın hesaba katılacağı bulunur, sonra kırkta bir uygulanır.

    11 Eylül 2026 DÜZELTMESİ (ChatGPT incelemesi; GOREVLER B36):
    * Oturulan evin değeri nakit birikimden İKİNCİ KEZ düşülüyordu; oysa
      ev zaten birikimin parçası değil. Artık hesaba hiç girmiyor.
    * "Üç ay önce eline geçen para bu yıl katılmaz" kesin bir kural gibi
      veriliyordu. Yıl içinde gelen paranın o yılın hesabına nasıl gireceği
      konusunda görüşler farklı. Yerine tartışmasız bir kalem kondu: henüz
      ELE GEÇMEMİŞ ödeme -- sahip olunmayan mal hesaba girmez.
    * Nisap sonuca bağlanmıyordu ve TL tutarları gerçek nisabın altında
      kalabiliyordu. Artık her kalem GRAM ALTIN: nisap (80,18 g) fiyattan
      bağımsız karşılaştırılır; borç düşülünce kalan her zaman nisabın üstünde.
    Din Kültürü öğretmenine onaylatılacak.
    """
    kalan = rastgele.randrange(90, 240)          # borç düşülünce kalan, gram
    borc = rastgele.randrange(10, 41)
    birikim = kalan + borc
    ev = rastgele.choice([900, 1200, 1500, 2100])  # oturulan ev ve eşya
    alacak = rastgele.randrange(45, 71)          # henüz eline geçmedi
    zekata_tabi = kalan
    zekat = zekata_tabi / 40.0
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="din-zekat",
        ders="din_kulturu",
        baslik="Hesaptaki Pay",
        kademe=kademe,
        konu="ibadetler",
        kazanim="Zekâtın hesaplanma ölçütleri; zekâta tabi malın belirlenmesi.",
        dikkat=6,
        brifing=(
            "{}, yıl sonunda vereceği zekâtı hesaplamak için üsse danıştı. "
            "Kâğıdındaki kalemleri, fiyatlar değişince şaşmasın diye gram altın "
            "cinsinden yazmış; hangilerinin hesaba katılacağını bilmiyor.\n\n"
            "\"Toplamın kırkta birini versem olmaz mı?\" diyor. Ama önce hangi "
            "toplamın alınacağına karar vermek gerekiyor: her mal zekâta tabi "
            "değil.\n\n"
            "Hesabı doğru çıkarmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Mal dökümü (gram altın)",
                  "Bir yıldır elinde duran birikim: {} g\n"
                  "Ödenmemiş borç: {} g\n"
                  "Oturduğu ev ve kullandığı eşya: {} g değerinde\n"
                  "Gelecek ay alacağı ödeme (henüz eline geçmedi): {} g".format(
                      birikim, borc, ev, alacak),
                  bedel=2, kritik=True),
            Kanit("İlmihal notu - zekâtın şartları",
                  "Zekât, dinen zengin sayılacak kadar (nisap miktarı) mala sahip "
                  "olan kişiye gerekir. Hesaba giren malda şunlar aranır:\n"
                  "  1) Kişinin elinde ve tam mülkiyetinde olması\n"
                  "  2) Temel ihtiyaçlardan (oturulan ev, kullanılan eşya) olmaması\n"
                  "  3) Borç düşüldükten sonra nisaba ulaşması\n"
                  "  4) Nisaba ulaşan malın üzerinden bir (kamerî) yıl geçmesi",
                  bedel=2, kritik=True),
            Kanit("İlmihal notu - oran",
                  "Zekât oranı kırkta birdir (1/40), yani yüzde iki buçuk.",
                  bedel=1, kritik=True),
            Kanit("Nisap açıklaması",
                  "Nisap, zekâtın gerekli olması için gereken en az mal "
                  "miktarıdır: 80,18 gram altın ya da bu değerde para. Borç "
                  "düşüldükten sonra kalan mal bunun altındaysa zekât gerekmez.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Zekât hangi miktar üzerinden hesaplanır?",
                dogru="Borç düşülünce kalan, temel ihtiyaç dışı, bir yıl elde duran mal.",
                yanlislar={
                    "Elindeki bütün malın toplamı üzerinden, çünkü hepsi ona ait.":
                        "Bütün varlığı hesaba kattın. Zekât, borç düşüldükten "
                        "sonra ARTAN ve temel ihtiyaç dışında kalan mal "
                        "üzerinden hesaplanır.",
                    "Henüz eline geçmemiş ödeme de eklenerek, çünkü o para nasılsa gelecek.":
                        "Alacağı ekledin. Zekât elde bulunan, tam sahip olunan "
                        "mal üzerinden hesaplanır; henüz eline geçmemiş ödeme "
                        "bu şartı taşımıyor.",
                    "Borçlar eklendikten sonraki toplam üzerinden; borç da bir kalemdir.":
                        "Borcu artı yönde işledin. Borç, zekâta esas maldan "
                        "DÜŞÜLÜR; eklenmez.",
                    "Oturduğu ev ve eşya dahil, sahip olduğu bütün varlık üzerinden.":
                        "Temel ihtiyacı hesaba kattın. Oturulan ev asli "
                        "ihtiyaçtır ve zekât matrahına girmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zekât, kişinin gerçekten \"artan\" malı üzerinden hesaplanır. "
                    "Önce borç düşülür (o mal aslında başkasınındır). Oturulan ev "
                    "ve kullanılan eşya temel ihtiyaçtır; birikimin parçası değildir "
                    "ve hesaba hiç girmez. Henüz ele geçmemiş ödeme de sahip olunan "
                    "mal sayılmaz. Kalan miktar nisabın (80,18 g altın) üstündeyse "
                    "kırkta biri verilir."
                ),
                ipuclari=[
                    "İlmihal notundaki şartları dökümdeki kalemlere tek tek uygula.",
                    "Ev birikimin içinde mi, yoksa ayrı bir kalem mi?",
                ],
                puan=20,
                cozum=(
                    "1) Bir yıldır elde duran birikim: {} g (hesaba girer)\n"
                    "2) Borç düşülür: -{} g\n"
                    "3) Ev ve eşya: temel ihtiyaç, birikimin parçası değil; "
                    "hesaba GİRMEZ\n"
                    "4) Gelecek ayki ödeme: henüz elde değil; hesaba GİRMEZ\n\n"
                    "Zekâta tabi miktar: {} - {} = {} g (nisabın, 80,18 g'ın üstünde)\n"
                    "Zekât: {} / 40 = {} g"
                ).format(birikim, borc, birikim, borc, sy(zekata_tabi),
                         sy(zekata_tabi), sy(zekat)),
            ),
            sayi_adimi(
                soru="Zekâta tabi miktar kaç gram altın?",
                cevap=zekata_tabi,
                birim="g",
                aciklama=("{} - {} = {} g. Ev ve eşya temel ihtiyaç olduğu için, "
                          "gelecek ayki ödeme de henüz elde olmadığı için "
                          "katılmaz.").format(birikim, borc, sy(zekata_tabi)),
                ipuclari=[
                    "Birikimden borcu çıkar.",
                    "Evi ve henüz eline geçmemiş ödemeyi hiç işleme katma.",
                ],
                yaygin_yanlislar={
                    birikim: "Borcu düşmeyi unuttun: o kısım aslında başkasına ait.",
                    kalan + alacak: "Henüz eline geçmemiş ödemeyi ekledin; sahip "
                                    "olunmayan mal hesaba girmez.",
                    kalan - ev: "Evi birikimden düştün. Ev birikimin parçası "
                                "değil; hesaba hiç girmez.",
                },
                puan=16,
            ),
            sayi_adimi(
                soru="Verilmesi gereken zekât kaç gram altın?",
                cevap=zekat,
                birim="g",
                aciklama=("{} / 40 = {} g (yüzde iki buçuk). Kalan miktar nisabın "
                          "üstünde olduğu için zekât gerekir.").format(
                    sy(zekata_tabi), sy(zekat)),
                ipuclari=["Bulduğun miktarı kırka böl."],
                tolerans=0.01,
                puan=14,
            ),
            yorum_adimi(
                soru="Gelecek ay alacağı ödeme neden bu yılın hesabına katılmadı?",
                dogru="Henüz eline geçmediği, yani tam sahip olunmadığı için.",
                yanlislar={
                    "Miktarı az olduğu için; küçük ödemeler hesaba girmez.":
                        "Sebebi miktara bağladın. Miktar ne olursa olsun bu "
                        "ödeme henüz kişinin elinde değil.",
                    "Borç sayıldığı için, borç da zekâta esas maldan düşülür.":
                        "Ödemeyi borç saydın. Tersine, bu ona yapılacak bir "
                        "ödeme; dışarıda kalma sebebi henüz elde olmaması.",
                    "Temel ihtiyaç sayıldığı için.":
                        "Temel ihtiyaç saydın. Sorun malın türü değil, henüz "
                        "kişinin eline geçmemiş olması.",
                    "Zekâta hiçbir zaman tabi olmadığı için.":
                        "Ödemeyi kalıcı olarak muaf saydın. Eline geçtiğinde "
                        "diğer malıyla birlikte değerlendirilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Zekât, kişinin elinde bulunan ve tam sahip olduğu mal üzerinden "
                    "hesaplanır. Henüz ele geçmemiş ödeme bu şartı taşımaz. Yıl "
                    "içinde ele geçen paranın o yılın hesabına nasıl gireceği "
                    "konusunda farklı görüşler vardır; bunu Din Kültürü "
                    "öğretmenine sorabilirsin."
                ),
                puan=12,
            ),
        ],
        kapanis="Hesap yapıldı; {} zekâtını doğru miktar üzerinden ayırdı.".format(kisi),
        odul={"itibar": 7, "erzak": 3},
    )


# ==========================================================================
# AHLAKİ KAVRAMLAR
# ==========================================================================

@bulmaca(ders="din_kulturu", konu="ahlaki_degerler", kademeler=(5, 11))
def ahlaki_kavram(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir davranışın hangi ahlaki değeri örneklediği bulunacak."""
    ornekler = [
        {
            "olay": ("Kendisine bırakılan kapalı zarfı, içinde ne olduğunu merak "
                     "etmesine rağmen açmadan sahibine teslim etti."),
            "deger": "Emanet",
            "neden": ("Kendisine bırakılan bir şeyi korumak ve olduğu gibi geri "
                      "vermek emanet kavramının tanımıdır."),
        },
        {
            "olay": ("Kendi arkadaşının haksız olduğunu görünce, arkadaşı "
                     "olmasına rağmen karşı tarafı haklı buldu."),
            "deger": "Adalet",
            "neden": ("Yakınlık gözetmeden hakkı sahibine vermek adaletin "
                      "ayırt edici özelliğidir."),
        },
        {
            "olay": ("Hata yaptığını kimse fark etmemişken kendisi gidip "
                     "durumu bildirdi."),
            "deger": "Dürüstlük",
            "neden": ("Çıkarına aykırı olduğu hâlde doğruyu söylemek dürüstlüktür."),
        },
        {
            "olay": ("Uzun süre sonuç alamamasına rağmen işi bırakmadı, "
                     "öfkelenip başkalarını suçlamadı."),
            "deger": "Sabır",
            "neden": ("Zorluk karşısında dayanma ve dengeyi koruma sabırdır."),
        },
        {
            "olay": ("Yardıma ihtiyacı olan birini gördüğünde, tanımadığı hâlde "
                     "kendi işini erteleyip yardım etti."),
            "deger": "Merhamet",
            "neden": ("Başkasının sıkıntısını hissedip harekete geçmek merhamettir."),
        },
    ]
    ornek = rastgele.choice(ornekler)
    digerleri = [o["deger"] for o in ornekler if o["deger"] != ornek["deger"]]
    rastgele.shuffle(digerleri)

    return Bulmaca(
        kod="din-ahlaki-kavram",
        ders="din_kulturu",
        baslik="Tutanaktaki Davranış",
        kademe=kademe,
        konu="ahlaki_degerler",
        kazanim="Ahlaki kavramları davranış örnekleriyle eşleştirme.",
        dikkat=5,
        brifing=(
            "Üssün aylık değerlendirme tutanağına örnek davranışlar yazılıyor. "
            "Her davranışın yanına hangi değeri gösterdiği not edilecek.\n\n"
            "Elindeki kayıt şu:\n\n"
            "  \"{}\"\n\n"
            "Birden çok değer akla gelebilir; ama davranışı asıl belirleyen tek "
            "bir ölçüt var."
        ).format(ornek["olay"]),
        kanitlar=[
            Kanit("Davranış kaydı", ornek["olay"], bedel=1, kritik=True),
            Kanit("Değerler kılavuzu",
                  "ADALET: Yakınlık gözetmeden hakkı sahibine vermek.\n"
                  "EMANET: Kendisine bırakılanı koruyup olduğu gibi "
                  "geri vermek.\n"
                  "DÜRÜSTLÜK: Çıkarına aykırı olsa da doğruyu söylemek.\n"
                  "SABIR: Zorluk karşısında dayanmak, dengeyi korumak.\n"
                  "MERHAMET: Başkasının sıkıntısını hissedip yardıma geçmek.",
                  bedel=2, kritik=True),
            Kanit("Değerlendirme notu",
                  "\"Bir davranışta birden çok güzel yan bulunabilir. Fişe, "
                  "davranışı asıl AYIRT EDEN değer yazılır: kişi neyi yapmasa da "
                  "olurdu, ama yaptı?\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir davranışın hangi değeri gösterdiğini ne belirler?",
                dogru="Kişinin hangi zorluğa rağmen ne yaptığı.",
                yanlislar={
                    "Davranışın kaç kişiyi etkilediği.":
                        "Kapsamı ölçüt saydın. Tek kişiye yapılan bir iyilik "
                        "de aynı değeri gösterir; belirleyici olan davranışın "
                        "NİTELİĞİ.",
                    "Davranışın ne kadar sürdüğü.":
                        "Süreyi ölçüt saydın. Bir anlık bir davranış da bir "
                        "değeri açıkça gösterebilir.",
                    "Kişinin o sırada nerede bulunduğu.":
                        "Yeri ölçüt saydın. Aynı davranış her yerde aynı "
                        "değere işaret eder.",
                    "Davranışın alışkanlık hâline gelip gelmediği.":
                        "Tekrarı şart koştun. Bir kez yapılan davranış da "
                        "hangi değere dayandığını gösterir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı davranış birden çok değere yakın durabilir. Ayırt edici "
                    "soru şudur: kişi neyi yapmamakta serbestti, buna rağmen ne "
                    "yaptı? Kapalı zarfı açmamak merhamet değil emanettir; çünkü "
                    "zorlandığı şey merak ve fırsattı."
                ),
                ipuclari=[
                    "Kişi burada neyi yapmamayı seçti?",
                    "Kılavuzdaki beş tanımı olayla tek tek karşılaştır.",
                ],
                puan=16,
                cozum=(
                    "1) Olayda kişinin karşı koyduğu şeyi bul (merak, çıkar, "
                    "yakınlık, zorluk, ilgisizlik).\n"
                    "2) Kılavuzdaki tanımlardan hangisi bu karşı koyuşu anlatıyor?\n"
                    "3) {}\n\n"
                    "Sonuç: {}"
                ).format(ornek["neden"], ornek["deger"]),
            ),
            secim_adimi(
                soru="Bu davranış hangi değeri gösterir?",
                dogru=ornek["deger"],
                yanlislar=digerleri[:4],
                rastgele=rastgele,
                aciklama=ornek["neden"],
                ipuclari=["Kılavuzdaki tanımları olayla karşılaştır."],
                puan=16,
            ),
            yorum_adimi(
                soru="Bir davranış aynı anda birden çok değeri gösterebilir mi?",
                dogru="Evet; ama fişe asıl ayırt eden değer yazılır.",
                yanlislar={
                    "Hayır; her davranış tek bir değere karşılık gelir.":
                        "Değerleri tek tek eşleştirdin. Bir yardım aynı anda "
                        "hem cömertlik hem merhamet gösterebilir.",
                    "Hayır; değerler birbirini dışlar.":
                        "Değerleri birbirine rakip saydın. Çoğu davranışta "
                        "birkaçı bir arada bulunur.",
                    "Evet; bu durumda hepsi fişe yazılır.":
                        "Doğru başlayıp yanlış bitirdin. Birden çok değer "
                        "gösterebilir ama fişe, davranışın en belirgin "
                        "dayanağı yazılır.",
                    "Evet; ama o zaman davranış değersiz sayılır.":
                        "Çokluğu değersizlik saydın. Birden çok değere "
                        "dayanan davranış daha güçlüdür, daha zayıf değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Değerler iç içe geçer: adaletli davranan kişi çoğu zaman dürüst "
                    "de davranır. Burada \"en uygun\" seçenek istenir; bu "
                    "yüzden hepsini birden işaretlemek değil, ayırt edici olanı seçmek "
                    "gerekir."
                ),
                puan=12,
            ),
        ],
        kapanis="Davranış tutanağa değeriyle birlikte işlendi.",
        odul={"itibar": 6},
    )


# ==========================================================================
# DİNLER HAKKINDA BİLGİ
# ==========================================================================

@bulmaca(ders="din_kulturu", konu="dinler_bilgisi", kademeler=(7, 12))
def dinler_bilgisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kronograf'ın getirdiği kayıt hangi dine ait? Olgusal ayırt etme."""
    dinler = [
        {
            "ad": "İslam",
            "kitap": "Kur'an-ı Kerim",
            "mabet": "cami",
            "isaret": ("Kayıtta günde beş vakit topluca kılınan bir ibadetten ve "
                       "ay takvimine göre tutulan bir aylık oruçtan söz ediliyor."),
        },
        {
            "ad": "Hristiyanlık",
            "kitap": "İncil",
            "mabet": "kilise",
            "isaret": ("Kayıtta haftalık ibadetin pazar günü yapıldığı ve "
                       "vaftiz adı verilen bir törenden söz ediliyor."),
        },
        {
            "ad": "Yahudilik",
            "kitap": "Tevrat",
            "mabet": "sinagog",
            "isaret": ("Kayıtta cumartesi gününün dinlenme ve ibadet günü olarak "
                       "tutulduğundan söz ediliyor."),
        },
    ]
    din = rastgele.choice(dinler)
    digerleri = [d for d in dinler if d["ad"] != din["ad"]]

    return Bulmaca(
        kod="din-dinler-bilgisi",
        ders="din_kulturu",
        baslik="Adı Yazılmamış Kayıt",
        kademe=kademe,
        konu="dinler_bilgisi",
        kazanim="Dinler hakkında temel bilgiler; kutsal kitap ve ibadet yeri eşleştirmesi.",
        dikkat=5,
        brifing=(
            "Kronograf bir topluluğun ibadet düzenini anlatan bir kayıt getirdi. "
            "Kayıtta dinin adı geçmiyor; yalnızca uygulamalar anlatılıyor:\n\n"
            "  \"{}\"\n\n"
            "Arşiv fişine hangi dine ait olduğu yazılacak. Kayıt bir inancı "
            "değerlendirmiyor, yalnızca uygulamaları aktarıyor; fişe de öyle "
            "yazılacak."
        ).format(din["isaret"]),
        kanitlar=[
            Kanit("Kayıt metni", din["isaret"], bedel=1, kritik=True),
            Kanit("Dinler bilgi çizelgesi",
                  "İSLAM - Kutsal kitap: Kur'an-ı Kerim - İbadet yeri: cami\n"
                  "  Günde beş vakit namaz, ramazan ayında oruç.\n\n"
                  "HRİSTİYANLIK - Kutsal kitap: İncil - İbadet yeri: kilise\n"
                  "  Haftalık ibadet pazar günü, vaftiz töreni.\n\n"
                  "YAHUDİLİK - Kutsal kitap: Tevrat - İbadet yeri: sinagog\n"
                  "  Cumartesi (Şabat) dinlenme ve ibadet günü.",
                  bedel=2, kritik=True),
            Kanit("Arşivci notu",
                  "\"Kayıtlar uygulamaları anlatır; fişe de olgu yazılır. "
                  "Değerlendirme yapmak arşivcinin işi değildir.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kaydın hangi dine ait olduğunu ne belirler?",
                dogru="Anlatılan ibadet düzeninin bilinen uygulamalarla eşleşmesi.",
                yanlislar={
                    "Kaydın ne kadar uzun olduğu.":
                        "Uzunluğu ölçüt saydın. Kısa bir kayıt da ayırt edici "
                        "bir uygulamayı anlatabilir.",
                    "Kayıttaki kişi sayısı.":
                        "Kişi sayısını ölçüt saydın. Belirleyici olan kaç kişi "
                        "olduğu değil, NE YAPTIKLARI.",
                    "Kaydın hangi coğrafyadan geldiği; her din kendi bölgesinde yaşanır.":
                        "Coğrafyayı ölçüt saydın. Dinler tek bir bölgeye bağlı "
                        "değildir; aynı yerde birden çok inanç yaşar.",
                    "Kaydın hangi dilde yazıldığı.":
                        "Dili ölçüt saydın. Aynı din farklı dillerde yazılır; "
                        "ayırt edici olan ibadetin biçimi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ayırt edici bilgi, ibadetin ZAMANI ve BİÇİMİDİR: haftalık ibadet "
                    "günü, oruç düzeni, tören adları. Coğrafya ve dil yanıltıcıdır; "
                    "aynı dinin mensupları farklı ülkelerde ve dillerde yaşar."
                ),
                ipuclari=[
                    "Kayıtta hangi gün ya da hangi zaman düzeni geçiyor?",
                    "Çizelgedeki üç satırla karşılaştır.",
                ],
                puan=16,
                cozum=(
                    "1) Kayıttaki ibadet zamanını ve biçimini işaretle.\n"
                    "2) Çizelgedeki üç dinin uygulamalarıyla karşılaştır.\n"
                    "3) Eşleşen satır: {} (kutsal kitap: {}, ibadet yeri: {})\n\n"
                    "Sonuç: {}"
                ).format(din["ad"], din["kitap"], din["mabet"], din["ad"]),
            ),
            secim_adimi(
                soru="Bu kayıt hangi dine aittir?",
                dogru=din["ad"],
                yanlislar=dict(
                    [(d["ad"], "{} inancının ibadet düzeni kayıttakiyle "
                               "uyuşmuyor. Çizelgedeki satırı karşılaştır."
                               .format(d["ad"])) for d in digerleri]
                    + [("Belirlenemez",
                        "Kayıt yeterince ayırt edici: anlatılan uygulama "
                        "çizelgedeki tek bir satırla eşleşiyor.")]
                ),
                rastgele=rastgele,
                aciklama="Kayıttaki uygulama {} ile eşleşiyor.".format(din["ad"]),
                ipuclari=["Çizelgedeki ibadet düzenleriyle karşılaştır."],
                puan=14,
            ),
            secim_adimi(
                soru="Bu dinin kutsal kitabı ve ibadet yeri hangisidir?",
                dogru="{} - {}".format(din["kitap"], din["mabet"]),
                yanlislar=dict(
                    [("{} - {}".format(d["kitap"], d["mabet"]),
                      "Bu ikili {} inancına ait. Bir önceki adımda "
                      "belirlediğin dinin satırına bak.".format(d["ad"]))
                     for d in digerleri]
                    + [("{} - {}".format(din["kitap"], digerleri[0]["mabet"]),
                        "Kutsal kitabı doğru seçtin ama ibadet yerini başka "
                        "bir satırdan aldın. İkisi aynı satırda olmalı.")]
                ),
                rastgele=rastgele,
                aciklama="{} dininde kutsal kitap {}, ibadet yeri {}dir.".format(
                    din["ad"], din["kitap"], din["mabet"]),
                ipuclari=["Çizelgedeki ilgili satırı oku."],
                puan=14,
            ),
        ],
        kapanis="Kayıt fişlendi ve arşive kaldırıldı.",
        odul={"itibar": 6},
    )
