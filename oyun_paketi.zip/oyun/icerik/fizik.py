# -*- coding: utf-8 -*-
"""
Fizik görevleri (lise, 9-13).

Çerçeve: üssün KUVVET ATÖLYESİ. Vinçler, palangalar, kaldırma düzenekleri.
Ortaokulun Laboratuvarı ile ayrımı şu: orada "hangi büyüklük işin içinde"
sorulur, burada düzeneğin kendisi bilinmeyendir - kurulum okunur, kazancın
nereden geldiği bulunur, hesap ondan sonra gelir.

Fen Bilimleri (ortaokul) kaldırılmadı; bu modül onun üstüne biner.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import PERSONEL, ad_sec, model_adimi, sayi_adimi, sy, yorum_adimi


# ==========================================================================
# MEKANİK AVANTAJ - palangada kuvvet ve yol
# ==========================================================================

@bulmaca(ders="fizik", konu="makara", kademeler=(9, 13), agirlik=1.2)
def palanga_kazanci(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Palangada kuvvet kazancı 2n; kuvvetten kazanılan yoldan kaybedilir."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    hareketli = rastgele.choice([2, 3])
    kazanc = 2 * hareketli
    # Yükü kazancın katı seç: bölme tam çıksın, hesap değil kurulum sınansın.
    kuvvet = rastgele.choice([45, 60, 75, 90])          # N
    yuk = kazanc * kuvvet                               # N
    yukseklik = rastgele.choice([3, 4, 5, 6])           # m
    ip_yolu = kazanc * yukseklik                        # m
    is_miktari = yuk * yukseklik                        # J

    return Bulmaca(
        kod="fizik-palanga-kazanci",
        ders="fizik",
        baslik="Ambardaki Palanga",
        kademe=kademe,
        konu="makara",
        kazanim="Basit makinelerde mekanik avantaj; kuvvet kazancı ile yol "
                "kaybının işi değiştirmemesi.",
        dikkat=6,
        brifing=(
            "{} ambardaki ağır sandığı üst kata çıkaracak ama tek başına "
            "kaldıramıyor. Duvarda asılı duran palangayı takmış.\n\n"
            "Şimdi tartışma çıktı: biri \"makara taktık, artık iş yarıya "
            "indi\" diyor; bir başkası \"makara ne yapsın, ağırlık ağırlıktır\" "
            "diyor.\n\n"
            "Halatı çekecek olan kişi ise tek bir şey sormuş: kaç newton "
            "asılacağım ve kaç metre halat çekeceğim? Kimse cevap veremedi."
        ).format(kisi),
        kanitlar=[
            Kanit("Palanga etiketi",
                  "Düzenek: {} hareketli, {} sabit makara.\n"
                  "Sabit makaralar tavana, hareketli makaralar yükün "
                  "üzerindeki tek bloğa bağlı. Tek ve esnemeyen ipin bir ucu tavana sabit; ip makaralar arasında sırayla dolaşıyor. Yük bloğunu taşıyan dikey ip kolları her hareketli makaranın iki yanında; serbest uç aşağı çekiliyor.".format(hareketli, hareketli),
                  bedel=2, kritik=True),
            Kanit("Tartı fişi",
                  "Sandığın ağırlığı: {} N".format(yuk), bedel=1, kritik=True),
            Kanit("Vinç çizelgesi",
                  "Sandık zeminden {} metre yukarı çıkacak.".format(yukseklik),
                  bedel=1, kritik=True),
            Kanit("Fizik el kitabı",
                  "\"Palangada yükü taşıyan ip kolu sayısı kadar kuvvetten "
                  "kazanılır. İpin ucu tavana bağlı bu düzende n hareketli makara için kuvvet "
                  "kazancı 2n'dir. Sabit makara kuvveti küçültmez, yalnızca "
                  "çekme yönünü değiştirir. Kuvvetten kazanılan oran kadar "
                  "yoldan kaybedilir; sürtünme ve makara ağırlıkları ihmal "
                  "edilir.\"", bedel=2, kritik=True),
            Kanit("Halat deposu kaydı",
                  "Ambarda bu düzeneğe yetecek uzunlukta halat var; halat ideal modelde kütlesiz ve esnemez kabul ediliyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu düzeneğin kuvvetten kazancını ne belirler?",
                dogru=("Yükü taşıyan ip kolu sayısı: bu düzende her hareketli makara iki "
                       "taşıyıcı kola sahiptir, kazanç 2n olur."),
                yanlislar={
                    "Toplam makara sayısı; sabit makaralar da kuvvetten kazandırır.":
                        "Sabit makarayı da kazanca kattın. Sabit makara hareketli blokta değildir; tek başına kuvvet kazandırmaz ve çekme yönünü "
                        "değiştirir; kuvveti küçültmez.",
                    "Halatın uzunluğu; uzun halatla daha az kuvvet gerekir.":
                        "Halat uzunluğunu kuvvetle karıştırdın. Uzunluk çekme "
                        "YOLUNU belirler, gereken kuvveti değil.",
                    "Yükün ağırlığı; ağır yükte kazanç kendiliğinden büyür.":
                        "Kazancı yüke bağladın. Kazanç kurulumdan gelir; aynı "
                        "palanga hafif yükte de ağır yükte de aynı oranda "
                        "kazandırır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sandığı havada tutan şey, hareketli makaralardan geçip yükü "
                    "taşıyan ip kollarıdır. Her hareketli makara yükü iki kola "
                    "paylaştırır; bu kurulumda n hareketli makarada kazanç 2n olur. "
                    "Sabit makaralar kuvveti tavana aktarır; hareketli bloğu doğrudan destekleyen ip kollarına eklenmez. "
                    "İpin serbest ucunu aşağı çekmeyi sağlar; çekme yönünü "
                    "değiştirir."
                ),
                ipuclari=[
                    "Sandığı havada tutan ip kollarını say; tavana bağlı olanı sayma.",
                    "Bir hareketli makara yükü kaç kola paylaştırıyor?",
                ],
                cozum=(
                    "1) Düzenekte hareketli makara sayısı n okunur.\n"
                    "2) Yükü taşıyan ip kolu sayısı 2n'dir; kuvvet kazancı da budur.\n"
                    "3) Sabit makaralar sayıya girmez, yalnızca yön değiştirir.\n"
                    "Bu düzenekte n = {} olduğuna göre kazanç 2 × {} = {}'dir."
                ).format(hareketli, hareketli, kazanc),
                puan=18,
            ),
            sayi_adimi(
                soru="Sandığı dengede tutmak için halata kaç newton asılmalı?",
                cevap=kuvvet,
                birim="N",
                aciklama=(
                    "Ağırlık, yükü taşıyan {} ip koluna eşit paylaşılır: "
                    "{} N ÷ {} = {} N."
                ).format(kazanc, yuk, kazanc, kuvvet),
                yaygin_yanlislar={
                    yuk: "Palangayı hiç hesaba katmadın; yazdığın sayı sandığın "
                         "kendi ağırlığı. Düzenek tam da bu sayıyı küçültmek "
                         "için kuruldu.",
                    yuk / float(hareketli):
                        "Hareketli makara sayısına böldün ama her makara yükü "
                        "İKİ kola paylaştırıyor. Bölmen gereken sayı n değil, 2n.",
                },
                ipuclari=[
                    "Ağırlık, yükü taşıyan kollara eşit dağılır.",
                    "Ağırlığı kuvvet kazancına böl.",
                ],
                tolerans=0.5,
                puan=14,
            ),
            sayi_adimi(
                soru="Sandık {} metre yükselecek. Halattan kaç metre çekmek "
                     "gerekir?".format(yukseklik),
                cevap=ip_yolu,
                birim="m",
                aciklama=(
                    "Kuvvetten kazanılan oran kadar yoldan kaybedilir: "
                    "{} × {} m = {} m halat çekilir."
                ).format(kazanc, yukseklik, ip_yolu),
                yaygin_yanlislar={
                    yukseklik: "Halat yolunu yükün yoluyla aynı saydın. Öyle "
                               "olsaydı kuvvet bedavaya küçülürdü; kazandığın "
                               "oranı yoldan geri verirsin.",
                    yukseklik * hareketli:
                        "Yolu n katı aldın ama kuvveti 2n'ye bölmüştün. "
                        "Kuvvette kullandığın oranın aynısı yolda da geçerli.",
                },
                ipuclari=[
                    "Kuvvette kazandığın oranı düşün; yol o oranda uzar.",
                ],
                tolerans=0.05,
                puan=14,
            ),
            yorum_adimi(
                soru="Palanga sayesinde yapılan İŞ de azalıyor mu?",
                dogru=("Hayır; kuvvet küçülürken yol aynı oranda uzuyor, iş "
                       "değişmiyor."),
                yanlislar={
                    "Evet; kuvvet kaç kat küçüldüyse iş de o kat küçülür.":
                        "Kuvveti işle aynı şey saydın. İş, kuvvetle YOLUN "
                        "çarpımıdır; kuvvet küçülürken yol büyüdüğü için "
                        "çarpım yerinde kalıyor.",
                    "Evet; makara sistemi eksik kalan enerjiyi kendisi üretir.":
                        "Düzeneğe enerji kaynağı yükledin. Makara enerji "
                        "üretmez; var olan enerjiyi daha küçük kuvvetle, daha "
                        "uzun yola yayar.",
                    "Hayır; iş artar, çünkü halatı çok daha uzun çekiyoruz.":
                        "Yalnızca yolun uzamasına baktın. Yol uzarken kuvvet "
                        "aynı oranda küçüldü; ikisi birbirini götürüyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İş = kuvvet × yol. Palangasız kaldırsaydık: {} N × {} m = {} J. "
                    "Palangayla: {} N × {} m = {} J. İki sayı aynı. Basit makine "
                    "işi azaltmaz, yalnızca aynı işi insanın kaldırabileceği "
                    "büyüklükte parçalara böler."
                ).format(yuk, yukseklik, sy(is_miktari),
                         kuvvet, ip_yolu, sy(kuvvet * ip_yolu)),
                puan=12,
            ),
        ],
        kapanis=(
            "Sandık düzgün bir hızla üst kata çıktı. Palanganın yanına küçük "
            "bir levha asıldı: \"Kuvvetten kazandığını yoldan ödersin.\""
        ),
        odul={"cevher": 5, "enerji": 6},
    )
