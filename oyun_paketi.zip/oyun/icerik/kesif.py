# -*- coding: utf-8 -*-
"""
Keşif düzeyi (ilkokul) görevleri.

Bu görevler bilerek tek dosyada toplandı. Sebebi bakım: oyunun en zayıf yeri
uzun süre bu düzeydi (dört öğrenme yolunda toplam dokuz üretici) ve boşluğun
ders dosyalarına dağılmış hâlde takip edilmesi zordu. Buradaki her üretici
kademeler=(1, 4) aralığında çalışır; ders ataması her zamanki gibi
@bulmaca(ders=...) ile yapılır, yani oyun açısından hiçbir fark yoktur.

Bu düzeyde yazım kuralları biraz daha sıkıdır:

  * Sayılar küçük ve tam kalır; bölme yapılıyorsa kalansızdır.
  * En çok üç adım: modelleme + çözüm, gerekiyorsa kısa bir yorum.
  * Brifing kısa cümlelerle yazılır; çocuk paragrafı gözüyle taramaz, okur.
  * Yanlış şıklar çocuğun gerçekten yaptığı hatalardır ve teşhisi yanındadır:
    "yanlış" demek yerine "şunu karıştırdın" demek, bu yaşta tek işe yarayan
    geri bildirimdir.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    DEPO_ADLARI, MEVKI_ADLARI, PERSONEL, ad_sec, model_adimi, sayi_adimi,
    secim_adimi, sirala_adimi, sy, yorum_adimi,
)


# ==========================================================================
# DİL VE ANLATIM
# ==========================================================================

@bulmaca(ders="turkce", konu="sozcukte_anlam", kademeler=(1, 4), agirlik=1.3)
def kayip_kelime(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı anlama gelen sözcüğü bağlamdan seçme.

    HER ÇİFT KENDİ DURUMUYLA GELİR. Eskiden beş çiftin hepsi aynı "ıslak
    zemin" notuna takılıyordu: "gizli/saklı" seçilince not "Sandıkların altı
    ___. Yere koymayın." diyor, açıklama da "ikisi de ıslaklığı anlatır"
    diyordu. Doğru dil sezgisini kullanan öğrenci oyunla çatışıyordu
    (ChatGPT incelemesi, 11 Eylül 2026; GOREVLER B36). Kural: not, kanıt,
    ipucu, geri bildirim ve açıklama AYNI durumu anlatır.
    """
    durumlar = [
        dict(sozcuk="ıslak", es="yaş", zit="kuru", baska1="sıcak", baska2="ağır",
             not_metni="Sandıkların altı ___. Yere koymayın.",
             eski="Çuvalların altı ıslak, kaldırın.",
             kanit_adi="Depo zemini",
             kanit="Zeminde su birikintisi var. Dün gece yağmur yağmış.",
             anlam="ıslaklığı",
             ipucu="Zeminde ne var?",
             zit_sonuc="\"kuru\" yazsaydık sandıkları ıslak zemine koyardık",
             ihmal_sonuc="sandıkların ıslanmasına",
             baska_neden="zemindeki suyla",
             kapanis="Sandıklar rafa kaldırıldı. Not yeniden yazılıp asıldı."),
        dict(sozcuk="çabuk", es="hızlı", zit="yavaş", baska1="sessiz", baska2="uzak",
             not_metni="Fırtına geliyor. Çadırları ___ toplayın.",
             eski="Sel geliyordu, malzemeyi çabuk taşıdık.",
             kanit_adi="Gözlem kulesi",
             kanit="Kara bulutlar bir saat içinde kampın üstünde olacak; "
                   "rüzgâr sertleşiyor.",
             anlam="acele etmek gerektiğini",
             ipucu="Fırtına ne zaman gelecek?",
             zit_sonuc="\"yavaş\" yazsaydık çadırları fırtınaya yakalatırdık",
             ihmal_sonuc="çadırların fırtınaya yakalanmasına",
             baska_neden="fırtınanın yaklaşmasıyla",
             kapanis="Çadırlar fırtınadan önce toplandı. Not yeniden yazılıp asıldı."),
        dict(sozcuk="büyük", es="kocaman", zit="küçücük", baska1="eski", baska2="boyalı",
             not_metni="Bu sandık ___. Dar kapıdan sokmayın.",
             eski="Geçen ay gelen kazan da büyük, yan kapıdan soktuk.",
             kanit_adi="Kapı ölçüsü",
             kanit="Dar kapı yetmiş santim. Sandığı iki kişi kollarını açınca "
                   "ancak sarabiliyor.",
             anlam="iriliği",
             ipucu="Sandık kapıya göre nasıl?",
             zit_sonuc="\"küçücük\" yazsaydık sandığı dar kapıya zorlardık",
             ihmal_sonuc="sandığın kapıya sıkışmasına",
             baska_neden="sandığın boyuyla",
             kapanis="Sandık yan kapıdan girdi. Not yeniden yazılıp asıldı."),
        dict(sozcuk="zor", es="güç", zit="kolay", baska1="güzel", baska2="sessiz",
             not_metni="Bu yokuşu dolu arabayla çıkmak ___. Yükü ikiye bölün.",
             eski="Geçen kış aynı yokuşu zor aşmıştık.",
             kanit_adi="Yol raporu",
             kanit="Yokuş dik ve taşlı. Dünkü araba yarı yolda durup geri kaydı.",
             anlam="zorluğu",
             ipucu="Dün yokuşta ne olmuş?",
             zit_sonuc="\"kolay\" yazsaydık yükü bölmeden yokuşa sürerdik",
             ihmal_sonuc="arabanın yokuşta kalmasına",
             baska_neden="yokuşun dikliğiyle",
             kapanis="Yük ikiye bölündü, iki seferde çıkıldı. Not yeniden yazılıp asıldı."),
        dict(sozcuk="gizli", es="saklı", zit="açık", baska1="temiz", baska2="yakın",
             not_metni="Yedek anahtarın yeri ___. Kimseye söylemeyin.",
             eski="Geçen ay kasanın şifresini de gizli tutmuştuk.",
             kanit_adi="Depo kuralı",
             kanit="Yedek anahtarın yerini yalnızca iki sorumlu bilir; yeri "
                   "deftere yazılmaz.",
             anlam="bir şeyin başkalarınca bilinmemesi gerektiğini",
             ipucu="Notun devamı ne istiyor?",
             zit_sonuc="\"açık\" yazsaydık anahtarın yerini herkese söylerdik",
             ihmal_sonuc="yedek anahtarın herkesin eline geçmesine",
             baska_neden="kimseye söylememe uyarısıyla",
             kapanis="Yedek anahtar yerinde kaldı. Not yeniden yazılıp asıldı."),
    ]
    d = rastgele.choice(durumlar)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="tur-kayip-kelime",
        ders="turkce",
        baslik="Silinmiş Sözcük",
        kademe=kademe,
        konu="sozcukte_anlam",
        kazanim="Eş anlamlı sözcüğü bağlam içinde seçme.",
        dikkat=4,
        brifing=(
            "{} bir not bırakmış. Notun ortasındaki bir sözcüğün üstüne su "
            "dökülmüş, okunmuyor.\n\n"
            "Notta şöyle yazıyor: \"{}\"\n\n"
            "{} akşama kadar dönmeyecek. Notu doğru anlamamız gerekiyor."
        ).format(kisi, d["not_metni"], kisi),
        kanitlar=[
            Kanit("Notun sağlam kısmı", "\"{}\"".format(d["not_metni"]),
                  bedel=1, kritik=True),
            Kanit(d["kanit_adi"], d["kanit"], bedel=1, kritik=True),
            Kanit("Aynı kişinin eski bir notu",
                  "Geçen sefer aynı kişi \"{}\" sözcüğünü kullanmış: "
                  "\"{}\"".format(d["sozcuk"], d["eski"]),
                  bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="Silinen sözcüğü nasıl buluruz?",
                dogru="Cümlenin gerisine bakıp anlamı tutan sözcüğü koyarız.",
                yanlislar={
                    "Aklımıza gelen ilk sözcüğü koyarız; ilk tahmin çoğu zaman doğrudur.":
                        "Cümleye herhangi bir sözcük değil, anlamı tutan "
                        "sözcük girer. Aklına gelen ilk sözcük cümleyi bozabilir.",
                    "Cümlenin tersini söyleyen bir sözcük koyarız.":
                        "Zıt anlamlı sözcük koyarsan not sana yanlış işi "
                        "yaptırır: {}.".format(d["zit_sonuc"]),
                    "Sözcüğü boş bırakıp notu yok sayarız.":
                        "Not bir uyarı. Anlamadan geçmek, {} yol açar.".format(
                            d["ihmal_sonuc"]),
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir sözcüğün anlamını cümle belirler. Notun uyarısı ile "
                    "\"{}\" kanıtı birlikte okunduğunda, boşluğa hangi anlamda "
                    "bir sözcük geleceği anlaşılır.").format(d["kanit_adi"]),
                ipuclari=["Cümlenin devamı ne istiyor?", d["ipucu"]],
            ),
            secim_adimi(
                soru="Boşluğa hangi sözcük gelmeli?",
                dogru=d["es"],
                yanlislar={
                    d["zit"]: "Bu sözcük tam tersini söylüyor. Cümleyi bir daha "
                              "oku: notun istediği bunun tersi.",
                    d["baska1"]: "Bu sözcük cümleye uyuyor gibi duruyor ama "
                                 "{} ilgisi yok.".format(d["baska_neden"]),
                    d["baska2"]: "Bu sözcük başka bir şeyi anlatıyor; buradaki "
                                 "uyarının sebebi değil.",
                },
                rastgele=rastgele,
                aciklama="\"{}\" ile \"{}\" aynı anlama gelir; ikisi de {} "
                         "anlatır.".format(d["sozcuk"], d["es"], d["anlam"]),
                ipuclari=["Eski notta geçen sözcük \"{}\" idi.".format(d["sozcuk"])],
                puan=12,
            ),
        ],
        kapanis=d["kapanis"],
        odul={"itibar": 2, "erzak": 1},
    )


@bulmaca(ders="turkce", konu="metinde_bilgi", kademeler=(1, 4), agirlik=1.2)
def liste_okuma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Okuduğunu bulma: metnin söylediği ile söylemediğini ayırma."""
    esyalar = ["battaniye", "fener", "ip", "kazma", "matara"]
    rastgele.shuffle(esyalar)
    goturulen = esyalar[:3]
    kalan = esyalar[3:]
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="tur-liste-okuma",
        ders="turkce",
        baslik="Çantada Ne Var",
        kademe=kademe,
        konu="metinde_bilgi",
        kazanim="Kısa bir metinden doğrudan bilgi çıkarma; metinde geçmeyeni "
                "eklememe.",
        dikkat=4,
        brifing=(
            "Keşif ekibi sabah {} yönüne gitti. Gitmeden önce çantaya ne "
            "koyduklarını bir kâğıda yazmışlar.\n\n"
            "Öğleden sonra telsizle \"ipimiz var mı\" diye soruyorlar. "
            "Kâğıt masanın üstünde duruyor.\n\n"
            "Yanlış cevap verirsek ekip geri dönmek zorunda kalır."
        ).format(mevki),
        kanitlar=[
            Kanit("Ekibin kâğıdı",
                  "Çantaya konanlar: {}.".format(", ".join(goturulen)),
                  bedel=1, kritik=True),
            Kanit("Depo rafı",
                  "Rafta duranlar: {}.".format(", ".join(kalan) or "hiçbir şey"),
                  bedel=1),
            Kanit("Telsiz kaydı",
                  "\"Elimizde ne var, kâğıda göre söyleyin. Tahmin istemiyoruz.\"",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Ekibin sorusunu neye bakarak cevaplarız?",
                dogru="Ekibin yazdığı kâğıtta o eşyanın olup olmadığına bakarız.",
                yanlislar={
                    "Depo rafında ne kaldığına bakıp tahmin ederiz.":
                        "Rafta olmayan her şey çantada demek değil. Kâğıt "
                        "zaten çantadakileri yazmış; tahmine gerek yok.",
                    "Ekibin böyle bir sefere neyi götürmesi gerektiğini düşünürüz.":
                        "Gerekeni değil, GÖTÜRÜLENİ soruyorlar. Ne olması "
                        "gerektiği ile ne olduğu ayrı şeyler.",
                    "Geçen seferki çantaya bakarız.":
                        "Geçen seferki liste bugünkü çantayı anlatmaz; elimizde "
                        "bugünün kâğıdı var.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir metin ne yazıyorsa onu söyler. Bilgi metinde varsa "
                    "kesindir; yoksa bizim tahminimizdir ve telsizde tahmin "
                    "istenmiyor."),
                ipuclari=["Ekibin kendi yazdığı kâğıt masada duruyor."],
            ),
            secim_adimi(
                soru="Telsize ne cevap verilmeli?",
                dogru=("Kâğıtta ip {}.".format(
                    "yazıyor, ellerinde var" if "ip" in goturulen
                    else "yazmıyor, ellerinde yok")),
                yanlislar={
                    ("Kâğıtta ip {}.".format(
                        "yazmıyor, ellerinde yok" if "ip" in goturulen
                        else "yazıyor, ellerinde var")):
                        "Kâğıdı ters okudun. Listeyi bir daha, sözcük sözcük "
                        "tara.",
                    "Kesin vardır, her ekip ip taşır.":
                        "Bu bir tahmin. Telsizde tahmin değil, kâğıttaki bilgi "
                        "isteniyor.",
                    "Rafta ip görünmüyorsa çantadadır.":
                        "Rafta olmaması çantada olduğunu göstermez; başka bir "
                        "yerde de olabilir.",
                },
                rastgele=rastgele,
                aciklama="Kâğıtta yazanlar: {}.".format(", ".join(goturulen)),
                puan=12,
            ),
        ],
        kapanis="Telsize kâğıttaki bilgi okundu. Ekip yoluna devam etti.",
        odul={"itibar": 2},
    )


@bulmaca(ders="turkce", konu="olay_sirasi", kademeler=(1, 4))
def gunun_sirasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Anlatıda olay sırası: önce ne oldu, sonra ne oldu."""
    olaylar = [
        "Sabah zil çaldı, herkes avluda toplandı",
        "Depodan sandıklar arabaya yüklendi",
        "Araba kuzey kapısından çıktı",
        "Akşam boş arabayla geri dönüldü",
    ]
    karisik = list(olaylar)
    rastgele.shuffle(karisik)
    sirali = [karisik.index(o) for o in olaylar]

    return Bulmaca(
        kod="tur-gunun-sirasi",
        ders="turkce",
        baslik="Karışmış Günlük",
        kademe=kademe,
        konu="olay_sirasi",
        kazanim="Bir anlatıdaki olayları oluş sırasına dizme.",
        dikkat=4,
        brifing=(
            "Günlüğü tutan kâtip dün akşam aceleyle yazmış; satırlar karışmış.\n\n"
            "Komutan günlüğü okuyup \"bu gün nasıl geçti\" diye soracak. "
            "Karışık satırlarla anlatılan gün, olduğundan başka görünüyor.\n\n"
            "Satırları doğru sıraya dizmen gerekiyor."
        ),
        kanitlar=[
            Kanit("Karışmış satırlar",
                  "\n".join("- " + o for o in karisik), bedel=1, kritik=True),
            Kanit("Nöbetçi ifadesi",
                  "\"Sabah zil çalmadan kimse avluya çıkmaz. Araba da yüklenmeden "
                  "kapıdan çıkamaz.\"", bedel=2, kritik=True),
            Kanit("Kapı defteri",
                  "Arabanın çıkışı öğleden önce, dönüşü akşam yazılmış.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Satırları neye göre sıraya dizeriz?",
                dogru="Hangi olayın öbürünü mümkün kıldığına bakarız.",
                yanlislar={
                    "Satırların kâğıttaki yazılış sırasına göre, çünkü yazan öyle yazmış.":
                        "Kâğıttaki sıra zaten karışık; onu doğru kabul edersek "
                        "hatayı olduğu gibi bırakırız.",
                    "En uzun satırdan en kısaya doğru.":
                        "Bir cümlenin uzunluğunun olay sırasıyla ilgisi yok.",
                    "Alfabe sırasına göre.":
                        "Alfabe sırası sözlükte işe yarar; günü anlatan bir "
                        "metinde zaman sırası geçerlidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Olaylar birbirine bağlıdır: yüklenmemiş araba kapıdan "
                    "çıkamaz, çıkmamış araba geri dönemez. Bu bağ sırayı "
                    "kendiliğinden verir."),
                ipuclari=["Araba çıkmadan önce ne olmuş olmalı?"],
            ),
            sirala_adimi(
                soru="Satırları oluş sırasına diz (numaraları sırayla yaz):",
                secenekler=karisik,
                dogru_sira=sirali,
                aciklama="Doğru sıra: zil -> yükleme -> çıkış -> dönüş.",
                ipuclari=["Gün sabah başlar.",
                          "Boş arabayla dönmek en son olabilir."],
                puan=16,
            ),
        ],
        kapanis="Günlük temize çekildi; gün olduğu gibi göründü.",
        odul={"itibar": 2, "erzak": 1},
    )


# ==========================================================================
# SAYILAR VE DÜZEN
# ==========================================================================

@bulmaca(ders="matematik", konu="eksilen_sayim", kademeler=(1, 4), agirlik=1.3)
def kile_sayimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Toplama ve çıkarma; bilinmeyen başlangıç sayısı."""
    kalan = rastgele.randrange(12, 30)
    alinan = rastgele.randrange(4, 12)
    baslangic = kalan + alinan
    depo = ad_sec(rastgele, DEPO_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-kile-sayimi",
        ders="matematik",
        baslik="Eksilen Çuval",
        kademe=kademe,
        konu="eksilen_sayim",
        kazanim="Toplama ve çıkarma ile bilinmeyen başlangıç değerini bulma.",
        dikkat=4,
        brifing=(
            "{} deposunda sabah sayım yapılmamış. Şimdi rafta {} çuval var.\n\n"
            "{} öğlen depodan {} çuval alıp mutfağa götürmüş. Bunu deftere "
            "yazmış ama sabahki sayıyı yazmamış.\n\n"
            "Komutan sabah kaç çuval olduğunu soruyor."
        ).format(depo, kalan, kisi, alinan),
        kanitlar=[
            Kanit("Şimdiki sayım", "Rafta duran: {} çuval.".format(kalan),
                  bedel=1, kritik=True),
            Kanit("Mutfak fişi",
                  "Mutfağa götürülen: {} çuval. Başka çıkış yok.".format(alinan),
                  bedel=1, kritik=True),
            Kanit("Depo kapısı",
                  "Gün içinde depoya yeni çuval GİRMEMİŞ.", bedel=1,
                  kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Sabahki sayıyı nasıl buluruz?",
                dogru="Kalana götürülenleri geri ekleriz.",
                yanlislar={
                    "Şimdi kalandan götürülenleri çıkarırız.":
                        "Çıkarmayı ters yöne yaptın. Çuvallar zaten çıktı; "
                        "geri saymak için onları eklemen gerekir.",
                    "Götürülenleri şimdi kalanla çarparız, sabahki sayı böyle büyür.":
                        "Çarpma, eşit grupları birleştirir. Burada eşit grup "
                        "yok, bir eksilme var.",
                    "Sadece götürülen sayıyı söyleriz.":
                        "Götürülen, sabahki toplamın yalnızca bir parçası; "
                        "rafta kalanlar da sabah oradaydı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Depoya giriş olmadığına göre sabahki toplam, şu an "
                    "kalanlar ile çıkanların toplamıdır: {} + {} = {}.".format(
                        kalan, alinan, baslangic)),
                ipuclari=["Mutfağa giden çuvallar sabah neredeydi?"],
            ),
            sayi_adimi(
                soru="Sabah depoda kaç çuval vardı?",
                cevap=baslangic,
                birim="çuval",
                aciklama="{} + {} = {}".format(kalan, alinan, baslangic),
                yaygin_yanlislar={
                    kalan - alinan:
                        "Eklemek yerine çıkardın. Çuvallar depodan ÇIKTI; geri "
                        "saymak için eklemelisin.",
                    kalan: "Şimdiki sayıyı yazdın. Sabah, mutfağa gidenler de "
                           "raftaydı.",
                    alinan: "Yalnızca götürülenleri yazdın; rafta kalanları "
                            "eklemeyi unuttun.",
                },
                puan=12,
            ),
        ],
        kapanis="Deftere sabah sayısı da yazıldı; bir daha aynı soru sorulmayacak.",
        odul={"erzak": 2, "itibar": 1},
    )


@bulmaca(ders="matematik", konu="esit_paylastirma", kademeler=(1, 4), agirlik=1.2)
def nobet_paylasimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kalansız bölme; eşit paylaştırma."""
    kisi_sayisi = rastgele.choice([3, 4, 5, 6])
    pay = rastgele.randrange(4, 12)
    toplam = kisi_sayisi * pay

    return Bulmaca(
        kod="mat-nobet-paylasimi",
        ders="matematik",
        baslik="Eşit Pay",
        kademe=kademe,
        konu="esit_paylastirma",
        kazanim="Eşit paylaştırma; bölme işleminin anlamı.",
        dikkat=4,
        brifing=(
            "Akşam nöbetine {} kişi çıkacak. Mutfak nöbetçiler için {} "
            "peksimet ayırmış.\n\n"
            "Aşçı \"herkese eşit dağıtın, elde kalmasın\" diyor. Kimin kaç "
            "peksimet alacağı yazmıyor.\n\n"
            "Eşit olmazsa nöbet yerinde tartışma çıkıyor; bu yüzden sayı "
            "önceden belli olmalı."
        ).format(kisi_sayisi, toplam),
        kanitlar=[
            Kanit("Mutfak teslimi", "Ayrılan peksimet: {}.".format(toplam),
                  bedel=1, kritik=True),
            Kanit("Nöbet çizelgesi",
                  "Akşam nöbetine çıkacak kişi sayısı: {}.".format(kisi_sayisi),
                  bedel=1, kritik=True),
            Kanit("Aşçının notu",
                  "\"Eşit dağıtın, elde peksimet kalmasın.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Herkesin payını nasıl buluruz?",
                dogru="Toplam peksimeti kişi sayısına böleriz.",
                yanlislar={
                    "Kişi sayısını toplam peksimete böleriz.":
                        "Bölmeyi ters kurdun. Paylaştırılan şey peksimet; o "
                        "yüzden peksimet bölünür, kişi değil.",
                    "Toplam peksimetten kişi sayısını çıkarırız.":
                        "Çıkarma bir eksilmeyi anlatır. Burada eksilme değil, "
                        "eşit parçalara ayırma var.",
                    "Toplam peksimeti kişi sayısıyla çarparız.":
                        "Çarpma sayıyı büyütür; oysa paylaştıkça kişi başına "
                        "düşen küçülür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Eşit paylaştırma bölmedir: {} peksimet {} kişiye "
                    "bölünür.".format(toplam, kisi_sayisi)),
                ipuclari=["Paylaştırılan şey hangisi: peksimet mi, kişi mi?"],
            ),
            sayi_adimi(
                soru="Bir kişiye kaç peksimet düşer?",
                cevap=pay,
                birim="peksimet",
                aciklama="{} ÷ {} = {}".format(toplam, kisi_sayisi, pay),
                yaygin_yanlislar={
                    toplam - kisi_sayisi:
                        "Bölmek yerine çıkardın. Çıkarma eşit pay vermez.",
                    toplam: "Toplamı yazdın; sorulan bir KİŞİYE düşen sayı.",
                },
                puan=12,
            ),
            yorum_adimi(
                soru="Nöbete bir kişi daha katılırsa ne olur?",
                dogru="Kişi başına düşen peksimet azalır.",
                yanlislar={
                    "Kişi başına düşen artar.":
                        "Aynı peksimet daha çok kişiye bölünüyor; pay büyüyemez.",
                    "Değişmez, herkes yine aynı sayıyı alır.":
                        "Toplam sabitken kişi sayısı artarsa pay küçülür.",
                    "Toplam peksimet sayısı da kendiliğinden artar.":
                        "Mutfak ayrılan sayıyı değiştirmedi; elimizdeki "
                        "peksimet aynı.",
                },
                rastgele=rastgele,
                aciklama="Aynı toplamı daha çok kişiye bölmek, payı küçültür.",
                puan=8,
            ),
        ],
        kapanis="Peksimetler eşit dağıtıldı; nöbet sessiz geçti.",
        odul={"erzak": 2},
    )


@bulmaca(ders="mantik", konu="oruntu", kademeler=(1, 4), agirlik=1.2)
def isaret_dizisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Örüntüyü fark etme: kural bulunmadan sıradaki bulunamaz."""
    baslangic = rastgele.randrange(2, 8)
    artis = rastgele.choice([2, 3, 4, 5])
    dizi = [baslangic + artis * i for i in range(4)]
    sonraki = dizi[-1] + artis
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="man-isaret-dizisi",
        ders="mantik",
        baslik="Yol İşaretleri",
        kademe=kademe,
        konu="oruntu",
        kazanim="Sayı örüntüsündeki kuralı bulma ve devam ettirme.",
        dikkat=4,
        brifing=(
            "{} yolunda taşlara sayılar kazınmış. Keşif ekibi ilk dört taşı "
            "görmüş: {}.\n\n"
            "Beşinci taş çalılıkların içinde kalmış, görünmüyor. Ekip taşı "
            "aramadan önce üstünde hangi sayının yazdığını bilmek istiyor.\n\n"
            "Yanlış sayıyı ararlarsa yanlış yerde kazı yaparlar."
        ).format(mevki, ", ".join(str(s) for s in dizi)),
        kanitlar=[
            Kanit("Görülen taşlar",
                  "Sırayla: {}.".format(", ".join(str(s) for s in dizi)),
                  bedel=1, kritik=True),
            Kanit("Ekip notu",
                  "\"Taşlar arasındaki mesafe hep aynı. Sayılar da düzenli "
                  "artıyor gibi.\"", bedel=1, kritik=True),
            Kanit("Eski harita",
                  "Haritada bu yolda toplam altı taş işaretli.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Beşinci taştaki sayıyı nasıl buluruz?",
                dogru="Ardışık taşlar arasındaki farkı son sayıya ekleriz.",
                yanlislar={
                    "Son iki sayıyı toplarız, çünkü her taş öncekilerden doğar.":
                        "Toplama başka bir kural üretir. Buradaki dizide her "
                        "adımda aynı sayı EKLENİYOR; ikisini toplamak diziyi "
                        "birden büyütür.",
                    "İlk sayıyı ikiyle çarparız.":
                        "İlk sayının tek başına bir anlamı yok; kuralı "
                        "belirleyen, sayılar arasındaki fark.",
                    "Sayıları büyükten küçüğe sıralarız.":
                        "Dizi zaten sıralı. Sorulan, sıradaki sayının kaç "
                        "olduğu.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Örüntüde önce KURAL bulunur, sonra kural uygulanır. "
                    "Buradaki kural: her taşta sayı {} artıyor.".format(artis)),
                ipuclari=["İlk iki sayı arasındaki fark kaç?",
                          "Aynı fark diğerlerinde de var mı?"],
            ),
            sayi_adimi(
                soru="Beşinci taşta hangi sayı yazıyor?",
                cevap=sonraki,
                aciklama="Her adımda {} artıyor: {} + {} = {}".format(
                    artis, dizi[-1], artis, sonraki),
                yaygin_yanlislar={
                    dizi[-1] + dizi[-2]:
                        "Son iki sayıyı topladın. Dizi toplayarak değil, her "
                        "adımda aynı sayıyı ekleyerek ilerliyor.",
                    dizi[-1] + 1:
                        "Birer birer saydın. Farkı ölç: sayılar birer birer "
                        "artmıyor.",
                },
                puan=12,
            ),
        ],
        kapanis="Ekip doğru sayıyı arayıp taşı çalılığın dibinde buldu.",
        odul={"cevher": 2, "itibar": 1},
    )


# ==========================================================================
# DOĞA VE YAŞAM
# ==========================================================================

@bulmaca(ders="fen", konu="canlilarin_ihtiyaci", kademeler=(1, 4), agirlik=1.3)
def solan_fideler(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Değişkeni ayırma: iki saksı arasındaki tek farkı bulma."""
    gun = rastgele.randrange(4, 9)

    return Bulmaca(
        kod="fen-solan-fideler",
        ders="fen",
        baslik="Solan Fideler",
        kademe=kademe,
        konu="canlilarin_ihtiyaci",
        kazanim="Canlıların temel ihtiyaçları; iki durumu karşılaştırırken tek "
                "farkı bulma.",
        dikkat=4,
        brifing=(
            "Üssün serasında iki sıra fide var. {} gün önce ikisi de aynı gün "
            "ekildi, aynı topraktan, aynı tohumdan.\n\n"
            "Pencere kenarındaki sıra yeşil ve dik duruyor. Duvar dibindeki "
            "sıra sarardı, yapraklar sarkmış.\n\n"
            "Bahçıvan \"toprağı değiştirelim\" diyor. Komutan önce sebebin "
            "bulunmasını istiyor."
        ).format(gun),
        kanitlar=[
            Kanit("Sulama defteri",
                  "İki sıra da her gün aynı miktarda sulandı. Eksik gün yok.",
                  bedel=1, kritik=True),
            Kanit("Toprak torbası",
                  "İki sıraya da aynı torbadan toprak konuldu.", bedel=1,
                  kritik=True),
            Kanit("Sera düzeni",
                  "Pencere kenarı gün boyu aydınlık. Duvar dibine güneş hiç "
                  "vurmuyor.", bedel=2, kritik=True),
            Kanit("Sıcaklık ölçümü",
                  "Seranın iki ucunda sıcaklık aynı ölçüldü.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Sarı fidelerin sebebini nasıl buluruz?",
                dogru="İki sırada AYNI olmayan tek şeyi ararız.",
                yanlislar={
                    "Sarı fidelerin bulunduğu toprağı değiştiririz.":
                        "Bu bir çözüm denemesi, sebep bulma değil. Üstelik "
                        "defter iki sıranın toprağının aynı torbadan geldiğini "
                        "söylüyor.",
                    "İki sıraya da daha çok su veririz; susuz kalmış olabilirler.":
                        "Sulama zaten iki sırada da aynı. Aynı olan bir şey, "
                        "farkı açıklayamaz.",
                    "Sarı fideleri söküp yenisini ekeriz.":
                        "Sebebi bulmadan yenisini ekersek aynı yerde aynı şey "
                        "olur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki durum karşılaştırılırken aynı olan şeyler sebep "
                    "olamaz. Su aynı, toprak aynı, sıcaklık aynı; geriye tek "
                    "fark kalıyor: ışık."),
                ipuclari=["Defterlere bak: hangi şeyler iki sırada da aynı?",
                          "Geriye aynı olmayan ne kalıyor?"],
            ),
            secim_adimi(
                soru="Fidelerin sararmasının sebebi nedir?",
                dogru="Duvar dibine hiç güneş vurmaması.",
                yanlislar={
                    "Duvar dibindeki fidelerin az sulanması.":
                        "Sulama defteri iki sıranın eşit sulandığını yazıyor.",
                    "Toprağın kötü olması.":
                        "İki sıraya da aynı torbadan toprak konuldu; toprak "
                        "farkı yok.",
                    "Duvar dibinin daha soğuk olması; duvar dibi hep soğuktur.":
                        "Sıcaklık iki uçta da aynı ölçüldü.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bitkiler besinini ışıkla üretir. Işık olmayınca yaprak "
                    "sararır ve fide zayıflar."),
                puan=12,
            ),
            yorum_adimi(
                soru="Bahçıvana ne önerilmeli?",
                dogru="Sarı sırayı ışık alan yere taşımak.",
                yanlislar={
                    "Toprağı değiştirmek; yeni toprak fideyi güçlendirir.":
                        "Toprak zaten aynı; değiştirmek fideyi ışıksız "
                        "bırakmaya devam eder.",
                    "Daha sık sulamak; sararan yaprak su ister.":
                        "Eksik olan su değil ışık; fazla su kökü çürütebilir.",
                    "Fideleri sökmek.":
                        "Fideler hasta değil, yeri yanlış. Yer değişince "
                        "toparlanırlar.",
                },
                rastgele=rastgele,
                aciklama="Sebep ışıksa çözüm de ışıkla ilgili olmalı.",
                puan=8,
            ),
        ],
        kapanis="Sarı sıra pencere önüne taşındı. Üç gün sonra yapraklar dikildi.",
        odul={"erzak": 2, "itibar": 2},
    )


@bulmaca(ders="fen", konu="maddenin_hali", kademeler=(1, 4))
def donmus_matara(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Isı ile hâl değişimi; gözlemden sonuca."""
    gece_sicakligi = -rastgele.randrange(2, 9)

    return Bulmaca(
        kod="fen-donmus-matara",
        ders="fen",
        baslik="Açılmayan Matara",
        kademe=kademe,
        konu="maddenin_hali",
        kazanim="Suyun katı, sıvı hâlleri ve sıcaklıkla değişimi.",
        dikkat=4,
        brifing=(
            "Gözcü sabah kuleden indi. Mataradan su içemediğini söylüyor: "
            "matara ağzına kadar dolu ama hiç su akmıyor.\n\n"
            "Matarada delik yok, kapak da açılıyor. İçinde bir şey var ama "
            "dökülmüyor.\n\n"
            "Aşçı \"mataran bozulmuş\" diyor. Gözcü emin değil."
        ),
        kanitlar=[
            Kanit("Gece ölçümü",
                  "Gece sıcaklığı: {} derece.".format(gece_sicakligi), bedel=1,
                  kritik=True),
            Kanit("Matara",
                  "Matara sağlam, kapak açılıyor. İçerisi buz gibi soğuk, dışı "
                  "nemli.", bedel=1, kritik=True),
            Kanit("Kule şartları",
                  "Matara bütün gece kulenin dış korkuluğunda asılı kalmış.",
                  bedel=1),
            Kanit("Mutfak notu",
                  "Aynı sudan mutfakta duran testi sabah normal aktı.", bedel=2,
                  kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Suyun neden akmadığını nasıl anlarız?",
                dogru="Suyun gece kaç derecede kaldığına bakarız.",
                yanlislar={
                    "Matarayı sallayıp ne olduğuna bakarız; tıkanmışsa açılır.":
                        "Sallamak bir gözlem değil, deneme. Elimizde gece "
                        "sıcaklığı gibi bir ölçüm varken tahmine gerek yok.",
                    "Mataranın eski olup olmadığına bakarız; eski matara tıkanır.":
                        "Matara sağlam ve kapağı açılıyor; sorun kabın kendisi "
                        "değil, içindekinin durumu.",
                    "Suyu değiştirip yeniden doldururuz.":
                        "Aynı suyun mutfakta duran kısmı normal aktı; su "
                        "bozuk değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı su iki yerde farklı davranıyorsa fark suda değil, "
                    "bulunduğu ortamdadır. Ortamı ayıran şey sıcaklık."),
                ipuclari=["Mutfaktaki su akıyor, kuledeki akmıyor. İkisinin "
                          "farkı ne?"],
            ),
            secim_adimi(
                soru="Matarada ne olmuş?",
                dogru="Su donmuş, katı hâle geçmiş.",
                yanlislar={
                    "Su buharlaşıp bitmiş.":
                        "Matara ağzına kadar dolu; içindeki gitmemiş, hâli "
                        "değişmiş.",
                    "Su matarada sızarak azalmış.":
                        "Matarada delik yok ve matara dolu.",
                    "Suyun içine toprak karışıp koyulaşmış.":
                        "Toprak karışsa su yine akardı; akmamasının sebebi "
                        "katılaşması.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Su sıfırın altında donar ve katı hâle geçer. Katı su "
                    "kabın şeklini alır ama akmaz."),
                puan=12,
            ),
            yorum_adimi(
                soru="Gözcü yarın ne yaparsa aynı şey olmaz?",
                dogru="Matarayı içeride, yanında tutar.",
                yanlislar={
                    "Matarayı daha çok doldurur; dolu matara donmaz.":
                        "Miktar değil sıcaklık belirleyici; dolu matara da "
                        "donar.",
                    "Mataranın kapağını açık bırakır; açık kaptaki su donmaz.":
                        "Açık kapak donmayı engellemez, üstelik su kirlenir.",
                    "Daha büyük bir matara alır.":
                        "Büyük matara da aynı soğukta donar.",
                },
                rastgele=rastgele,
                aciklama="Donmayı engelleyen şey, suyu donma sıcaklığının "
                         "üstünde tutmaktır.",
                puan=8,
            ),
        ],
        kapanis="Matara ocağın yanına alındı; öğlene doğru su yeniden aktı.",
        odul={"erzak": 1, "itibar": 2},
    )


@bulmaca(ders="cografya", konu="yon_bulma", kademeler=(1, 4), agirlik=1.2)
def golge_yonu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yön bulma: güneşin hareketinden yön çıkarma."""
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="cog-golge-yonu",
        ders="cografya",
        baslik="Pusulasız Sabah",
        kademe=kademe,
        konu="yon_bulma",
        kazanim="Güneşin doğuş yönünden yararlanarak yön belirleme.",
        dikkat=4,
        brifing=(
            "Keşif ekibinin pusulası dün {} mevkiinde düştü. Sabah üsse "
            "dönmeleri gerekiyor ama hangi yöne yürüyeceklerini "
            "bilmiyorlar.\n\n"
            "Üs, kamp yerinin batısında kalıyor. Ekipte harita var, pusula "
            "yok.\n\n"
            "Yanlış yöne yürürlerse akşama kadar üsse ulaşamazlar."
        ).format(mevki),
        kanitlar=[
            Kanit("Sabah gözlemi",
                  "Güneş sabah çadırın arkasından doğdu; çadırın gölgesi ileri "
                  "doğru uzanıyor.", bedel=1, kritik=True),
            Kanit("Genel bilgi",
                  "Güneş her sabah doğu yönünden doğar.", bedel=1, kritik=True),
            Kanit("Harita",
                  "Üs, kamp yerinin BATISINDA işaretli.", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Pusulasız yön nasıl bulunur?",
                dogru="Güneşin doğduğu yön doğudur; öbür yönler ona göre bulunur.",
                yanlislar={
                    "Rüzgârın estiği yön kuzeydir; rüzgâr hep aynı yönden eser.":
                        "Rüzgâr her gün başka yönden eser; sabit bir yön "
                        "işareti değildir.",
                    "Yokuş aşağı olan yön daima güneydir, çünkü eğim yönü gösterir.":
                        "Arazinin eğimi ile yönlerin ilgisi yok; her tepe "
                        "başka yöne bakabilir.",
                    "Gölge her zaman kuzeyi gösterir; güneş hep güneyde durur.":
                        "Gölgenin yönü güneşin yerine göre gün boyu değişir; "
                        "önce güneşin nerede olduğunu bilmek gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Güneşin doğuşu sabit bir işarettir: doğduğu taraf "
                    "doğudur. Doğu bilinince karşısı batı olur."),
                ipuclari=["Sabah güneş hangi yönden doğar?"],
            ),
            secim_adimi(
                soru="Ekip üsse gitmek için hangi yöne yürümeli?",
                dogru="Güneşe sırtını dönüp ilerlemeli.",
                yanlislar={
                    "Güneşe doğru yürümeli.":
                        "Güneşe doğru yürümek doğuya gitmektir; üs batıda "
                        "kalıyor, ters yöne gidersin.",
                    "Gölgesine basarak geri yürümeli.":
                        "Sabah gölge batıya uzanır; gölgeye ters yürümek yine "
                        "doğuya gitmek olur.",
                    "Kampın etrafında dönüp iz aramalı.":
                        "İz aramak vakit kaybettirir; elde güneş gibi kesin "
                        "bir işaret varken gerekmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sabah güneş doğudadır. Sırtını güneşe dönen kişi batıya "
                    "bakar; üs de batıda."),
                puan=12,
            ),
        ],
        kapanis="Ekip öğleden önce üssün kulesini gördü.",
        odul={"itibar": 3},
    )


# ==========================================================================
# İNSAN VE TOPLUM
# ==========================================================================

@bulmaca(ders="tarih", konu="gecmisin_izleri", kademeler=(1, 4), agirlik=1.3)
def eski_ocak(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kanıttan geçmişe: eşya ne anlatır?"""
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="tar-eski-ocak",
        ders="tarih",
        baslik="Taşların Arasında",
        kademe=kademe,
        konu="gecmisin_izleri",
        kazanim="Geçmişe dair bilgiye kanıtlardan ulaşma; eşyanın ne anlattığını "
                "okuma.",
        dikkat=4,
        brifing=(
            "{} yakınında toprak kayınca taşlar ortaya çıktı. Taşlar bir "
            "çember oluşturuyor; ortası simsiyah.\n\n"
            "Çemberin yanında kırık bir çanak parçası ve yanmış hayvan "
            "kemikleri var.\n\n"
            "Kâtip \"burada ne olmuş\" diye soruyor. Kimse görmediği bir "
            "geçmiş hakkında konuşacağız; elimizde yalnızca bunlar var."
        ).format(mevki),
        kanitlar=[
            Kanit("Taş çemberi",
                  "Taşlar düzgün bir daire yapıyor; ortadaki toprak yanmaktan "
                  "kararmış.", bedel=1, kritik=True),
            Kanit("Çanak parçası",
                  "Elle yapılmış, pişmiş toprak. Kenarında yemek isi var.",
                  bedel=1, kritik=True),
            Kanit("Kemikler",
                  "Hayvan kemikleri; uçları ateşte kararmış.", bedel=1,
                  kritik=True),
            Kanit("Çevre",
                  "Yakınlarda başka yapı ya da duvar izi yok.", bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="Burada ne olduğunu nasıl anlarız?",
                dogru="Eşyaların birlikte ne işe yaradığına bakar, ortak açıklama ararız.",
                yanlislar={
                    "En eski görünen eşyaya bakıp ötekileri saymayız; asıl hikâyeyi o anlatır.":
                        "Tek bir eşya yarım bir hikâye anlatır. Kanıtlar "
                        "birlikte okunduğunda anlam kazanır.",
                    "Bugün aynı yerde ne yapıldığına bakarız; yerin işi pek değişmez.":
                        "Bugünkü kullanım, geçmişteki kullanımı göstermez; "
                        "yer aynı olsa da zaman değişti.",
                    "Hikâyeyi kendimiz uydurup eşyaları ona uydururuz.":
                        "Bu, tarih değil hayal olur. Önce kanıt, sonra "
                        "açıklama gelir - tersi değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tarih, kalan izlerden okunur. Üç kanıtı birden açıklayan "
                    "en yalın hikâye, doğruya en yakın olandır."),
                ipuclari=["Kararmış toprak neyi gösterir?",
                          "Çanak ve kemikler ateşin yanında ne arıyor?"],
            ),
            secim_adimi(
                soru="Bu taşlar en çok neye benziyor?",
                dogru="Yemek pişirilen bir ocağa.",
                yanlislar={
                    "Bir mezara; eşyalar ölünün yanına konmuş olabilir.":
                        "Mezarda yanmış toprak ve yemek isli çanak beklenmez; "
                        "ateşin izi buranın kullanıldığını gösteriyor.",
                    "Bir su kuyusuna; taşlar daire biçiminde dizilmiş.":
                        "Kuyunun ortası kararmaz, ıslak olur. Buradaki iz "
                        "ateşin izi.",
                    "Bir sınır taşı dizisine.":
                        "Sınır taşları sıra hâlinde uzanır, daire yapmaz ve "
                        "yanmış toprak bırakmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Daire biçiminde dizilmiş taşlar, ortadaki kararmış "
                    "toprak, isli çanak ve yanmış kemikler bir arada ancak tek "
                    "şeyi anlatır: burada ateş yakılıp yemek pişirilmiş."),
                puan=14,
            ),
        ],
        kapanis="Kâtip deftere yazdı: \"Buluntu: ocak yeri. Dayanak: üç kanıt.\"",
        odul={"itibar": 3, "cevher": 1},
    )


@bulmaca(ders="vatandaslik", konu="ortak_yasam_kurallari", kademeler=(1, 4),
         agirlik=1.2)
def kuyruk_kurali(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kuralın sebebi: kural, kimin işine yaradığıyla anlaşılır."""
    kisi_sayisi = rastgele.randrange(12, 25)

    return Bulmaca(
        kod="vat-kuyruk-kurali",
        ders="vatandaslik",
        baslik="Mutfak Kuyruğu",
        kademe=kademe,
        konu="ortak_yasam_kurallari",
        kazanim="Ortak yaşam kurallarının sebebini kavrama; kuralın herkesi "
                "koruduğunu görme.",
        dikkat=4,
        brifing=(
            "Akşam yemeğinde mutfağın önü karıştı. {} kişi aynı anda "
            "pencereye yüklendi; kimse kimin önce geldiğini bilemedi.\n\n"
            "İki kişi hiç yemek alamadan geri döndü. Aşçı yarım saat fazladan "
            "çalıştı.\n\n"
            "Komutan bir kural yazılmasını istiyor ama önce sorunun ne "
            "olduğunun anlaşılmasını bekliyor."
        ).format(kisi_sayisi),
        kanitlar=[
            Kanit("Nöbetçi ifadesi",
                  "\"Herkes aynı anda geldi. Sıra olmayınca en arkadakiler hiç "
                  "yaklaşamadı.\"", bedel=1, kritik=True),
            Kanit("Mutfak kaydı",
                  "Yemek herkese yetecek kadardı; eksik pişirilmemişti.",
                  bedel=1, kritik=True),
            Kanit("Önceki akşam",
                  "Dün aynı sayıda kişi vardı ama sıra olunmuştu; kimse aç "
                  "kalmadı.", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Sorunun sebebini nasıl buluruz?",
                dogru="Dün ile bugün arasında değişen tek şeyi buluruz.",
                yanlislar={
                    "Yemeğin az pişirildiğini varsayarız.":
                        "Mutfak kaydı yemeğin yettiğini söylüyor. Kayıtla "
                        "çelişen bir varsayımla başlanmaz.",
                    "Aç kalanların geç gelip yemek bittikten sonra sıraya girdiğini varsayarız.":
                        "Nöbetçi herkesin aynı anda geldiğini söylüyor; geç "
                        "kalan yok.",
                    "Mutfağın küçük olduğunu söyleriz.":
                        "Mutfak dün de aynı büyüklükteydi ve sorun çıkmamıştı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Dün ve bugün kişi sayısı, yemek miktarı ve mutfak aynıydı. "
                    "Değişen tek şey sıra olunup olunmaması."),
                ipuclari=["Dün ne farklıydı?"],
            ),
            secim_adimi(
                soru="Yazılacak kural ne olmalı?",
                dogru="Yemek alınırken geliş sırasına göre sıraya girilir.",
                yanlislar={
                    "Yemek yalnızca nöbetçi olmayanlara verilir.":
                        "Bu kural bazılarını yemekten mahrum eder; sorun ise "
                        "sıra yokluğuydu, kişi ayrımı değil.",
                    "Mutfak iki kat fazla yemek pişirir.":
                        "Yemek zaten yetiyordu; fazla pişirmek israf olur ve "
                        "kalabalığı çözmez.",
                    "Yemek dağıtımı iptal edilir, herkes kendi yemeğini alır.":
                        "Bu, düzeni kurmak yerine ortak düzeni kaldırmak olur; "
                        "karışıklık büyür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İyi kural, sorunun sebebine dokunur ve herkesi korur. "
                    "Sıra kuralı, en arkadakinin de yemek almasını güvence "
                    "altına alır."),
                puan=12,
            ),
            yorum_adimi(
                soru="Bu kural en çok kimin işine yarar?",
                dogru="En arkada kalanın; sırası ona da gelir.",
                yanlislar={
                    "En önde duranın, çünkü kural onun yerini güvenceye alır.":
                        "En öndeki kural olmadan da alıyordu. Kural asıl, "
                        "kuralsızlıkta kaybedeni korur.",
                    "Aşçının; daha az yemek pişirir.":
                        "Pişen yemek miktarı değişmiyor; değişen dağıtımın "
                        "düzeni.",
                    "Kimsenin; kurallar yalnızca işi yavaşlatır.":
                        "Dün sıra olunduğunda kimse aç kalmamıştı; kural işi "
                        "yavaşlatmadı, düzene soktu.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kuralların çoğu, kuralsızlıkta en çok zarar göreni "
                    "korumak için vardır."),
                puan=8,
            ),
        ],
        kapanis="Kural mutfağın kapısına asıldı. Ertesi akşam kimse aç kalmadı.",
        odul={"itibar": 3, "erzak": 1},
    )


@bulmaca(ders="din_kulturu", konu="yardimlasma", kademeler=(1, 4))
def kar_altinda_komsu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yardımlaşmanın ölçüsü: ihtiyaç kadar ve incitmeden."""
    hane = rastgele.randrange(3, 8)

    return Bulmaca(
        kod="din-kar-altinda",
        ders="din_kulturu",
        baslik="Yolu Kapanan Ev",
        kademe=kademe,
        konu="yardimlasma",
        kazanim="Yardımlaşma ve komşuluk; yardımın ihtiyaç ölçüsünde ve "
                "incitmeden yapılması.",
        dikkat=4,
        brifing=(
            "Üssün aşağısındaki {} haneli köyün yolu kar yüzünden kapandı. "
            "Bir hanede yaşlı bir kadın yalnız yaşıyor; odunu bitmiş.\n\n"
            "Üste odun var. Nöbetçiler ne yapacaklarını soruyor: kimisi "
            "\"bütün köye dağıtalım\" diyor, kimisi \"karışmayalım\".\n\n"
            "Komutan kararın gerekçesiyle birlikte yazılmasını istiyor."
        ).format(hane),
        kanitlar=[
            Kanit("Köy bilgisi",
                  "Diğer hanelerin odunu var; yalnızca bir hane odunsuz.",
                  bedel=1, kritik=True),
            Kanit("Yaşlı kadının haberi",
                  "\"Kimseyi zora sokmayın, ben idare ederim\" diye haber "
                  "yollamış.", bedel=2, kritik=True),
            Kanit("Hava raporu",
                  "Soğuk üç gün daha sürecek; yol iki gün içinde açılmayacak.",
                  bedel=1, kritik=True),
            Kanit("Üs deposu",
                  "Üssün odunu iki haneyi bir hafta ısıtacak kadar fazla var.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Doğru kararı nasıl veririz?",
                dogru="İhtiyacı olana ve yardımın onu incitmeyeceğine bakarız.",
                yanlislar={
                    "Kimin bizden yardım istediğine bakarız; istemeyenin ihtiyacı yok demektir.":
                        "İhtiyacı olan herkes yardım istemez; yaşlı kadın "
                        "\"idare ederim\" diye haber yolladı ama odunu yok.",
                    "Herkese eşit dağıtırız, kimse alınmasın.":
                        "Eşit dağıtım burada adil değil: odunu olan haneye "
                        "odun vermek, ihtiyacı olana daha az kalması demek.",
                    "Karışmayız; herkes kendi işini görsün.":
                        "Yolun kapalı olduğu ve soğuğun üç gün süreceği "
                        "biliniyorken karışmamak, bilerek seyretmek olur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yardım, ihtiyacın olduğu yere ve ihtiyaç kadar yapılır. "
                    "Ölçüsü kaçan yardım ya israf olur ya da karşısındakini "
                    "küçük düşürür."),
                ipuclari=["Kimin odunu yok?",
                          "\"İdare ederim\" demek, ihtiyacı yok demek mi?"],
            ),
            secim_adimi(
                soru="Ne yapılmalı?",
                dogru="Odunsuz haneye, duyurmadan yetecek kadar odun bırakılmalı.",
                yanlislar={
                    "Bütün köye eşit odun dağıtılmalı ki kimse ayrı tutulmuş sayılmasın.":
                        "Odunu olan haneye odun götürmek ihtiyacı olana "
                        "azaltır; eşitlik her zaman adalet değildir.",
                    "Kadın \"idare ederim\" dediği için hiçbir şey yapılmamalı.":
                        "Bu söz çoğu zaman kimseye yük olmama isteğidir; hava "
                        "raporu ihtiyacın gerçek olduğunu gösteriyor.",
                    "Odun köy meydanında herkesin önünde teslim edilmeli.":
                        "İhtiyaç karşılanır ama kişi mahcup edilir. Yardımın "
                        "görünür olması gerekmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İhtiyaç gerçek, kaynak yeterli, kişi mahcup edilmiyor: "
                    "üçü birden sağlandığında yardım yerini bulur."),
                puan=14,
            ),
        ],
        kapanis=("Odunlar akşam kapının önüne bırakıldı. Kimse kimseye bir şey "
                 "söylemedi."),
        odul={"itibar": 4},
    )
