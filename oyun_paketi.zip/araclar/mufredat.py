# -*- coding: utf-8 -*-
"""
Konu haritası kapsama raporu.

    python main.py --konu-haritasi            bütün dersler
    python main.py --konu-haritasi fizik      tek ders, sınıf sınıf

NE SÖYLER: MEB programındaki kaç konu satırının oyunda gerçekten karşılığı
var, kaçında ad var ama içerik o sınıf düzeyini kapsamıyor, kaçı boş. İçerik
yazma sırasını buradan seçiyoruz: en çok sınıfta/sürümde geçen boş konu önce.

Rapor bir kapsam ÖLÇÜMÜ değil, eşleşme sayımıdır: bir satırda "karşılığı var"
demek o kazanımın tam ölçüldüğü anlamına gelmez.
"""
from __future__ import annotations

import collections
from typing import Dict, List, Tuple

from oyun.motor import konu_haritasi as kh
from oyun.motor.modeller import DERS_ADLARI

DURUM_ADLARI = {"hazir": "hazır", "kademe_disi": "kademe dışı", "bos": "boş"}

# Bir oyun konusu kaç harita satırını karşılıyorsa eşleme o kadar KABA olur.
# Bu eşiğin üstünde "hazır" sayısı içerik kapsaması değil BECERİ eşlemesi
# demektir: satırın kendi konusundan soru gelmez, genel bir beceri sorusu
# gelir. 13 Eylül 2026'da tarih haritası eklenince çıktı: 112 satırın 95'i
# "hazır" görünüyordu ama hepsini 7 konu karşılıyordu; `neden_sonuc` tek
# başına 135 satır-konu çiftinde geçiyordu.
KABA_ESLEME_ESIGI = 8


def esleme_kabaligi(ders: str) -> Tuple[int, List[Tuple[str, int]]]:
    """(hazır satırları karşılayan farklı oyun konusu, en çok yüklenenler).

    Sayım satır-konu çifti üzerinden: bir satır iki konu iddia ediyorsa
    ikisi de sayılır. Amaç kapsama ölçmek değil, "hazır" sayısının hangi
    dar kümeye dayandığını göstermek.
    """
    sayac = collections.Counter()
    for satir in kh.satirlar(ders=ders or None):
        for _, konu in satir.oyunda_hazir():
            sayac[konu] += 1
    return len(sayac), sayac.most_common(3)


def _yuzde(pay: int, toplam: int) -> str:
    return "%{:.0f}".format(100.0 * pay / toplam) if toplam else "-"


def bosluk_sirasi(ders: str = "") -> List[Tuple[str, int, List[int]]]:
    """Karşılığı olmayan konular, kaç satırda geçtiklerine göre sıralı.

    (önerilen kod, satır sayısı, sınıflar) döner. Sınıf listesi sayı olarak
    sıralanır: metin sıralaması "10, 11, 12, 9" diye yazıyordu.
    """
    sayac: Dict[Tuple[str, str], List[int]] = {}
    for satir in kh.satirlar(ders=ders or None):
        if satir.oyunda_hazir():
            continue
        sayac.setdefault((satir.ders, satir.kod), []).append(satir.sinif)
    sirali = sorted(sayac.items(), key=lambda x: (-len(x[1]), x[0]))
    return [(kod, len(siniflar), sorted(set(siniflar)))
            for (_, kod), siniflar in sirali]


def yazdir(ders: str = "", bosluk_adet: int = 20) -> int:
    tablo = kh.tablo()
    if not tablo:
        print("Konu haritası okunamadı: {}".format(kh.YUKLEME_HATASI or "dosya yok"))
        print("Beklenen yer: {}".format(kh.veri_yolu()))
        return 1
    dersler = [ders] if ders else kh.dersler()
    bilinmeyen = [d for d in dersler if d not in kh.dersler()]
    if bilinmeyen:
        print("Haritada olmayan ders: {}".format(", ".join(bilinmeyen)))
        print("Haritadaki dersler: {}".format(", ".join(kh.dersler())))
        return 1

    print("KONU HARİTASI KAPSAMASI ({} satır, {} ders)".format(
        len(tablo), len(kh.dersler())))
    print("Kaynak: MEB öğretim programları; tablo öğretmen incelemesinden geçmedi.")
    genel = {"hazir": 0, "kademe_disi": 0, "bos": 0}
    for d in dersler:
        print("\n{} ({})".format(DERS_ADLARI.get(d, d), d))
        for surum in kh.surumler(d):
            print("  {}".format(kh.SURUM_ADLARI.get(surum, surum)))
            for sinif in kh.siniflar(d, surum):
                k = kh.kapsam(d, sinif, surum)
                toplam = sum(len(v) for v in k.values())
                for anahtar in genel:
                    genel[anahtar] += len(k[anahtar])
                print("    {}. sınıf: {:>3} satır  hazır {:>3} ({:>4})  "
                      "kademe dışı {:>2}  boş {:>3}".format(
                          sinif, toplam, len(k["hazir"]),
                          _yuzde(len(k["hazir"]), toplam),
                          len(k["kademe_disi"]), len(k["bos"])))

    print("\nEŞLEME GENİŞLİĞİ (hazır satırlar kaç farklı oyun konusuna dayanıyor)")
    for d in dersler:
        farkli, yuklu = esleme_kabaligi(d)
        hazir = len(kh.kapsam(d)["hazir"])
        if not hazir:
            continue
        oran = hazir / max(1, farkli)
        print("  {:<12} {:>3} hazır satır  <-  {:>2} farklı konu   en yüklü: {}".format(
            d, hazir, farkli,
            ", ".join("{} ({})".format(k, n) for k, n in yuklu)))
        if oran > KABA_ESLEME_ESIGI:
            # Bir ondalık basamak şart: 8,19 tam sayıya yuvarlanınca "8" yazıyordu
            # ve eşik de 8 olduğu için uyarı kendi gerekçesiyle çelişiyordu.
            print("     ! KABA EŞLEME: konu başına {:.1f} satır (eşik {}). Bu bir "
                  "BECERİ eşlemesi; satırın".format(oran, KABA_ESLEME_ESIGI))
            print("       kendi konusundan soru gelmez, genel beceri sorusu gelir.")

    toplam = sum(genel.values())
    print("\nTOPLAM: {} satır  hazır {} ({})  kademe dışı {}  boş {}".format(
        toplam, genel["hazir"], _yuzde(genel["hazir"], toplam),
        genel["kademe_disi"], genel["bos"]))

    bosluklar = bosluk_sirasi(ders)
    if bosluklar:
        print("\nİÇERİK BOŞLUKLARI (en çok satırda geçen {} tanesi)".format(
            min(bosluk_adet, len(bosluklar))))
        for kod, adet, siniflar in bosluklar[:bosluk_adet]:
            print("  {:<28} {:>2} satır  sınıflar: {}".format(
                kod, adet, ", ".join(str(s) for s in siniflar)))
        print("  ... toplam {} farklı boş konu".format(len(bosluklar)))
    return 0


def main(ders: str = "") -> int:
    return yazdir(ders)


if __name__ == "__main__":
    import sys
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else ""))
