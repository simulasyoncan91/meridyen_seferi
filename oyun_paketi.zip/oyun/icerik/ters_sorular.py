# -*- coding: utf-8 -*-
"""
Ters sorular: sonuç bilinir, yol bulunur.

Kullanıcı (5 Kasım 2026): "Tersten hesaplamak hiç aklıma gelmemişti. Sadece
kimyada da değil. Fizikte bir vinç ağırlık kaldırması için bir makara sistemi
tasarlanmış ve makara sisteminin bütün özellikleri verilmiştir. İpin gittiği
yol, uygulanan kuvvet ve yükün ağırlığı rastgele şekillerde istenebilir. Ya da
matematikte bir işlem sonucu verilir ve istenen şekilde sorunun tekrar
yazılması istenir."

İKİ ÜRETİCİ
  * mat-islemi-geri-kur : hesap kaydında yalnız sonuç ve kullanılan sayılar
    kalmış. Öğrenci işlemi yeniden yazar (IFADE adımı: birden çok doğru yol
    kabul edilir), sonra bir koşulla ikinci kez yazar ("son işlem çıkarma
    olsun"). Koşul, üretici tarafından ÇÖZÜCÜYLE sınanır: çözümü olmayan
    koşul hiç sorulmaz.
  * fizik-palanga-tasarim : aynı palanga bağıntısı (F · 2n = G, ip yolu =
    2n · h) ama bilinmeyen her seferinde başka: kuvvet, yük, ip yolu, yükseklik
    ya da TASARIM (en az kaç hareketli makara?). Öğrenci formülü ezberleyip
    hep aynı yönde kullanamaz; bağıntıyı okuması gerekir.

Bağlamlar üssün gerçek işlerinden: tarla, tesis onarımı, sevkiyat. "Depo"
kelimesi bilerek yok (bkz. oyun turu notu, 5 Kasım 2026).
"""
from __future__ import annotations

import math
import random
from fractions import Fraction

from oyun.motor import ifade
from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Adim, Bulmaca, COZUM, IFADE, Kanit

from ._ortak import PERSONEL, ad_sec, model_adimi, sayi_adimi

# ==========================================================================
# MATEMATİK - işlemi geri kur
# ==========================================================================

_BAGLAMLAR = [
    ("tarla", "Tarla ekibinin hasat hesabı", "kasa domates"),
    ("onarim", "Atölyenin onarım hesabı", "civata"),
    ("sevkiyat", "Sınır kapısına giden sevkiyat hesabı", "koli"),
    ("enerji", "Güneş panellerinin günlük hesabı", "birim enerji"),
]


def _sayilar_ve_hedef(rastgele: random.Random, kademe: int):
    """Tam sayı sonucu olan bir işlem kurar; (sayılar, hedef, örnek)."""
    adet = 3 if kademe <= 5 else 4
    izinli = "+-*" if kademe <= 5 else "+-*/"
    for _ in range(200):
        sayilar = [rastgele.randrange(2, 10) for _ in range(adet)]
        tum = ifade.tum_ifadeler(sayilar, izinli)
        adaylar = [d for d in tum if d.denominator == 1 and 10 <= d <= 60 + 10 * kademe]
        if not adaylar:
            continue
        # Çok kolay hedefleri (yalnız toplamayla bulunan) eleyelim.
        toplam = sum(sayilar)
        adaylar = [d for d in adaylar if d != toplam] or adaylar
        hedef = int(rastgele.choice(sorted(adaylar)))
        ornek = ifade.kosula_uyan(sayilar, hedef, {"yasak": [i for i in "+-*/" if i not in izinli]})
        if ornek:
            return sayilar, hedef, ornek, izinli
    sayilar = [2, 3, 4] if adet == 3 else [2, 3, 4, 5]
    hedef = 2 * 3 * 4 if adet == 3 else (2 + 3) * 4 + 5
    return sayilar, hedef, ifade.kosula_uyan(sayilar, hedef), izinli


def _ikinci_kosul(rastgele: random.Random, sayilar, hedef, izinli):
    """Çözümü OLAN bir koşul seçer; yoksa None."""
    adaylar = [{"son_islem": i} for i in izinli] + \
              [{"yasak": [i] + [j for j in "+-*/" if j not in izinli]} for i in izinli]
    rastgele.shuffle(adaylar)
    for kosul in adaylar:
        if "yasak" not in kosul:
            kosul["yasak"] = [j for j in "+-*/" if j not in izinli]
        ornek = ifade.kosula_uyan(sayilar, hedef, kosul)
        if ornek:
            return kosul, ornek
    return None


@bulmaca(ders="matematik", konu="islem_kurma", kademeler=(7, 13), agirlik=1.0)
def islemi_geri_kur(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sonuç ve sayılar verilir; işlem öğrenci tarafından kurulur."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    _kod, defter, nesne = rastgele.choice(_BAGLAMLAR)
    sayilar, hedef, ornek, izinli = _sayilar_ve_hedef(rastgele, kademe)
    ikinci = _ikinci_kosul(rastgele, sayilar, hedef, izinli)
    sayi_metni = ", ".join(str(s) for s in sayilar)
    islem_metni = ", ".join(ifade.ISLEM_ADLARI[i] for i in izinli)

    # Model adımı: hedefe hangi düşünceyle yaklaşılır? Doğru şık her zaman
    # geçerli bir strateji; yanlışlar yaygın hatalar.
    adimlar = [
        model_adimi(
            soru="Hesabı yeniden kurmaya nereden başlamak en akıllıca?",
            dogru=("Hedefe bakıp ona yakın bir ara sonuç aramak: hangi iki "
                   "sayı birleşince hedefe ({}) yaklaşır, kalanlar farkı kapatır mı?"
                   ).format(hedef),
            yanlislar={
                "Sayıları sırayla soldan sağa toplamak; kayıttaki sıra işlem sırasıdır.":
                    "Kayıttaki sıra yalnız sayıların listesi. İşlem sırasını "
                    "sen kuruyorsun; sırayla toplamak çoğu zaman hedefi tutturmaz.",
                "En büyük sayıyla başlayıp hep çarpmak; sonuç büyükse çarpma vardır.":
                    "Büyük sonuç çarpma ister ama hep çarpmak hedefi aşar. "
                    "Önce hedefe ne kadar uzak olduğuna bakmak gerekir.",
                "Rastgele denemek; işlemin bir mantığı olmaz.":
                    "Deneme yanılma da bir yol ama kör deneme uzun sürer. "
                    "Hedeften geriye doğru düşünmek aramayı kısaltır.",
            },
            rastgele=rastgele,
            aciklama=("Ters soruda hedef bilinir. Hedeften geriye bakmak, yani "
                      "\"{} sayısı hangi iki sayının sonucu olabilir?\" diye "
                      "sormak, olasılıkları hızla daraltır.").format(hedef),
            ipuclari=["Hedef sayıyı çarpanlarına ayırmak ya da ona en yakın "
                      "çarpımı bulmak iyi bir başlangıç."],
            puan=12,
        ),
        Adim(
            soru=("Kayıttaki sayıların ({}) her birini TAM BİR KEZ kullanarak "
                  "{} sonucunu veren işlemi yaz. Kullanabileceğin işlemler: {}; "
                  "parantez serbest.").format(sayi_metni, hedef, islem_metni),
            tur=IFADE, rol=COZUM,
            cevap={"hedef": hedef, "sayilar": list(sayilar), "kosul":
                   {"yasak": [i for i in "+-*/" if i not in izinli]}, "ornek": ornek},
            aciklama=("Birden fazla doğru yol var; senin yolun da sayıları "
                      "birer kez kullanıp hedefe ({}) ulaşıyorsa doğrudur. Bir örnek: "
                      "{} = {}.").format(hedef, ornek, hedef),
            ipuclari=["Parantez, önce yapılacak işlemi seçmeni sağlar.",
                      "Örnek yazım: (3+5)×2 ya da 9-4:2"],
            cozum=("1) Hedef {} sayısına bakılır.\n"
                   "2) Ona yakın bir ara sonuç aranır.\n"
                   "3) Kalan sayılar farkı kapatacak şekilde eklenir.\n"
                   "Bir çözüm: {} = {}").format(hedef, ornek, hedef),
            puan=16,
        ),
    ]
    if ikinci:
        kosul, ornek2 = ikinci
        adimlar.append(Adim(
            soru=("Denetçi aynı hesabı başka bir yoldan da görmek istiyor: "
                  "yine {} sayılarıyla {} sonucuna ulaş, ama {}."
                  ).format(sayi_metni, hedef, ifade.kosul_metni(kosul)),
            tur=IFADE, rol=COZUM,
            cevap={"hedef": hedef, "sayilar": list(sayilar), "kosul": kosul,
                   "ornek": ornek2},
            aciklama=("Aynı sonuca birden çok yoldan varılabilir. Koşula uyan "
                      "bir yol: {} = {}.").format(ornek2, hedef),
            ipuclari=["İlk yazdığın işlemi koşula göre nasıl değiştirebilirsin?"],
            cozum="Bir çözüm: {} = {}".format(ornek2, hedef),
            puan=16,
        ))

    return Bulmaca(
        kod="mat-islemi-geri-kur",
        ders="matematik",
        baslik="Silinen Hesap",
        kademe=kademe,
        konu="islem_kurma",
        kazanim="İşlem önceliği ve parantez; verilen sonuca giden işlemi "
                "kurma, aynı sonuca farklı yollardan ulaşma.",
        dikkat=5,
        brifing=(
            "{defter} telsiz paraziti yüzünden bozulmuş. {kisi} kayda baktığında "
            "yalnız iki şey okunabiliyor: kullanılan sayılar ve en alttaki "
            "sonuç, {hedef} {nesne}.\n\n"
            "Hesabın kendisi silinmiş. Denetim yarın; denetçi sonucun nereden "
            "geldiğini görmeden imza atmıyor."
        ).format(defter=defter, kisi=kisi, hedef=hedef, nesne=nesne),
        kanitlar=[
            Kanit("Bozuk kayıt",
                  "Okunabilen sayılar: {}\nSonuç: {}".format(sayi_metni, hedef),
                  bedel=1, kritik=True),
            Kanit("Hesap kuralları",
                  "Her sayı hesapta bir kez geçmiş. Kullanılan işlemler: {}. "
                  "Parantez ve işlem önceliği geçerli.".format(islem_metni),
                  bedel=1, kritik=True),
            Kanit("Eski bir kayıt",
                  "Geçen haftaki benzer hesap: (4+2)×3 = 18. Aynı sayılarla "
                  "4+2×3 = 10 çıkıyor; parantez sonucu değiştiriyor.",
                  bedel=1),
        ],
        adimlar=adimlar,
        kapanis="Hesap yeniden kuruldu; denetçi kaydı imzaladı.",
        odul={"itibar": 4, "enerji": 2},
    )


# ==========================================================================
# FİZİK - palangada bilinmeyen her seferinde başka
# ==========================================================================

_BILINMEYENLER = ("kuvvet", "yuk", "ip_yolu", "yukseklik", "tasarim")


@bulmaca(ders="fizik", konu="makara", kademeler=(9, 13), agirlik=1.0)
def palanga_tasarim(rastgele: random.Random, kademe: int) -> Bulmaca:
    """F · 2n = G ve ip yolu = 2n · h; bilinmeyen rastgele seçilir."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    bilinmeyen = rastgele.choice(_BILINMEYENLER)
    n = rastgele.choice([2, 3] if bilinmeyen == "tasarim" else [1, 2, 3])
    kazanc = 2 * n
    kuvvet = rastgele.choice([40, 50, 60, 75, 80, 90])
    yuk = kazanc * kuvvet
    h = rastgele.choice([2, 3, 4, 5, 6])
    ip = kazanc * h

    if bilinmeyen == "tasarim":
        # Yük kazancın tam katı OLMASIN: en az kaç makara sorusu yuvarlama ister.
        yuk = kazanc * kuvvet - rastgele.choice([10, 20, 30])
        gerekli = math.ceil(yuk / (2.0 * kuvvet))
        n_bilgi = "Henüz kurulmadı; kaç hareketli makara takılacağı senin kararın."
    else:
        gerekli = n
        n_bilgi = "{} hareketli makara, {} sabit makara.".format(n, n)

    verilen = {
        "kuvvet": "Halatı çekecek kişinin güvenle uygulayabileceği kuvvet: {} N".format(kuvvet),
        "yuk": "Kaldırılacak yükün ağırlığı: {} N".format(yuk),
        "ip_yolu": "Çekilen halat uzunluğu: {} m".format(ip),
        "yukseklik": "Yükün çıkacağı yükseklik: {} m".format(h),
    }
    sorular = {
        "kuvvet": ("Yükü dengede tutmak için halata kaç newton uygulanmalı?",
                   kuvvet, "N", "G ÷ 2n = {} ÷ {} = {} N".format(yuk, kazanc, kuvvet),
                   {yuk: "Palangayı hesaba katmadın: bu yükün kendi ağırlığı.",
                    yuk / float(n): "n'e böldün; her hareketli makara İKİ kol ekler, 2n'e bölmelisin."}),
        "yuk": ("Bu düzenekle en fazla kaç newtonluk yük dengede tutulabilir?",
                yuk, "N", "F × 2n = {} × {} = {} N".format(kuvvet, kazanc, yuk),
                {kuvvet: "Kazancı unuttun: palanga kuvveti çoğaltır.",
                 kuvvet * n: "n ile çarptın; kazanç 2n."}),
        "ip_yolu": ("Yük {} m yükselince kaç metre halat çekilmiş olur?".format(h),
                    ip, "m", "2n × h = {} × {} = {} m".format(kazanc, h, ip),
                    {h: "Kuvvetten kazanılan yoldan kaybedilir; ip yükten daha çok yol alır.",
                     h / float(kazanc): "Ters çevirdin: ip yolu yük yolundan KISA değil, uzun."}),
        "yukseklik": ("{} m halat çekildiğine göre yük kaç metre yükselmiştir?".format(ip),
                      h, "m", "ip yolu ÷ 2n = {} ÷ {} = {} m".format(ip, kazanc, h),
                      {ip: "Halatın tamamı yük kadar yükselmez; 2n'e bölünür.",
                       ip * kazanc: "Çarptın; yük, çekilen halattan daha AZ yol alır."}),
        "tasarim": ("Bu kuvvetle yükü kaldırmak için EN AZ kaç hareketli makara gerekir?",
                    gerekli, "", "2n × F ≥ G → n ≥ {} ÷ (2 × {}) = {:.2f}; tam sayıya "
                    "yukarı yuvarlanır: {}".format(yuk, kuvvet, yuk / (2.0 * kuvvet), gerekli),
                    {max(1, gerekli - 1): "Aşağı yuvarladın; o zaman kuvvet yetmez. Yukarı yuvarlanmalı.",
                     math.ceil(yuk / float(kuvvet)): "Her makarayı tek kol saydın; hareketli makara iki kol ekler."}),
    }
    soru, cevap, birim, hesap, yanlislar = sorular[bilinmeyen]
    yanlislar = {k: v for k, v in yanlislar.items() if k != cevap}
    # Bilinmeyen kanıtlarda görünmez; tasarımda yol bilgisi gereksiz.
    gizli = {"tasarim": {"ip_yolu", "yukseklik"}}.get(bilinmeyen, {bilinmeyen})
    kanitlar = [Kanit("Palanga planı", n_bilgi + " İpin bir ucu tavana sabit; "
                      "ip makaralar arasında sırayla dolaşıyor, serbest uç aşağı çekiliyor.",
                      bedel=2, kritik=True)]
    for ad in ("kuvvet", "yuk", "yukseklik", "ip_yolu"):
        if ad in gizli:
            continue
        kanitlar.append(Kanit({"kuvvet": "Ekip notu", "yuk": "Tartı fişi",
                               "yukseklik": "Vinç çizelgesi", "ip_yolu": "Halat sayacı"}[ad],
                              verilen[ad], bedel=1, kritik=True))
    kanitlar.append(Kanit("Fizik el kitabı",
                          "\"İpin ucu tavana bağlı palangada n hareketli makara için "
                          "kuvvet kazancı 2n'dir: F × 2n = G. Kuvvetten kazanılan "
                          "oran kadar yoldan kaybedilir: ip yolu = 2n × h. Sürtünme "
                          "ve makara ağırlıkları ihmal edilir.\"", bedel=2, kritik=True))

    bilinen_ad = {"kuvvet": "kuvvet", "yuk": "yük", "ip_yolu": "ip yolu",
                  "yukseklik": "yükseklik", "tasarim": "makara sayısı"}[bilinmeyen]
    return Bulmaca(
        kod="fizik-palanga-tasarim",
        ders="fizik",
        baslik="Vinç Tasarımı",
        kademe=kademe,
        konu="makara",
        kazanim="Palangada F × 2n = G ve ip yolu = 2n × h bağıntılarını her "
                "yönde kullanma; bilinenden bilinmeyene giden bağıntıyı seçme.",
        dikkat=6,
        brifing=(
            "Tesis onarımında ağır parçalar kaldırılacak. {} vinç için bir "
            "palanga hazırlıyor ama planın bir kısmı eksik: bu kez bilinmeyen "
            "{}.\n\n"
            "Elindeki kayıtlardan hangisinin işine yarayacağını sen seçeceksin."
        ).format(kisi, bilinen_ad),
        kanitlar=kanitlar,
        adimlar=[
            model_adimi(
                soru="Bilinmeyen {} olduğuna göre hangi bağıntı ve hangi yön kullanılmalı?".format(bilinen_ad),
                dogru={
                    "kuvvet": "F × 2n = G bağıntısı; G'yi 2n'e bölerek F bulunur.",
                    "yuk": "F × 2n = G bağıntısı; F'yi 2n ile çarparak G bulunur.",
                    "ip_yolu": "ip yolu = 2n × h; yükseklik 2n ile çarpılır.",
                    "yukseklik": "ip yolu = 2n × h; ip yolu 2n'e bölünür.",
                    "tasarim": "F × 2n ≥ G eşitsizliği; n en az G ÷ 2F olmalı, yukarı yuvarlanır.",
                }[bilinmeyen],
                yanlislar={
                    "Makara sayısı fark etmez; kuvvet her zaman yükün yarısıdır.":
                        "Yarıya inmesi yalnız tek hareketli makara için doğru; kazanç 2n.",
                    "Kuvvet ve ip yolu birlikte artar; ikisini de 2n ile çarp.":
                        "Kuvvetten kazanılan yoldan kaybedilir: biri 2n'e bölünürken diğeri 2n ile çarpılır.",
                    "Sabit makaraları da sayarak kazancı toplam makara sayısı al.":
                        "Sabit makara kuvvet kazandırmaz, yalnız yön değiştirir.",
                },
                rastgele=rastgele,
                aciklama="Aynı iki bağıntı her yönde kullanılır; önemli olan bilinenle "
                         "bilinmeyeni doğru tarafa koymak.",
                ipuclari=["Bilinmeyen bir kuvvet mi, bir uzunluk mu, yoksa bir sayı mı?"],
                puan=16,
            ),
            sayi_adimi(
                soru=soru, cevap=cevap, birim=birim,
                aciklama=hesap,
                yaygin_yanlislar=yanlislar,
                ipuclari=["El kitabındaki iki bağıntıdan hangisi bilinmeyeni içeriyor?"],
                cozum=hesap,
                puan=14,
            ),
        ],
        kapanis="Palanga planı tamamlandı; vinç ekibi işe başladı.",
        odul={"cevher": 2, "itibar": 3},
    )


# ==========================================================================
# MATEMATİK - kural merdiveni: sayıları öğrenci seçer, kurallar daraltır
# ==========================================================================
#
# Kullanıcı (5 Kasım 2026): "Sonuca giden her yol çalışırsa 58 sonucuna
# ulaşmak için 58+0 ile 57+1 yazıp geçebilirler. Bunun yerine kurallar
# ekleyebiliriz: 4 sayı toplanacak, sayılar birbirinin aynısı olmayıp
# birbirine de yakın olacak. Önce ortalamayı bulacak... Seçenekleri yavaş
# yavaş daraltmalıyız. Sonra çarpma işlemi ve parantez içinde çıkarma gibi
# şeyler ekleyerek daha karmaşık olasılıklar bulmaları sağlanabilir."
#
# ÜÇ BASAMAK (kademeye göre):
#   1 (3-5) : 4 farklı, birbirine yakın sayının TOPLAMI. Önce ortalama sorulur.
#   2 (6-7) : 4 farklı sayı; en az bir çarpma ve bir toplama.
#   3 (8-9) : 4 farklı sayı; parantez içinde bir çıkarma, sonucu çarpmaya girer.
# Her basamağın hedefi, kuralı sağlayan bir örnekten TÜRETİLİR: çözümsüz
# soru üretilemez. Örnek çözüm öğrenciye ancak sonunda gösterilir.

# --------------------------------------------------------- kural merdiveni
# Kullanıcı (5 Kasım 2026): "58 sonucuna 58+0 yazıp geçebilirler; kurallar
# ekleyelim, seçenekleri yavaş yavaş daraltalım." Verdiği örnek (4 yakın sayı,
# sonra çarpma, sonra parantezde çıkarma) bir ÖRNEKTİ, şart değil: kurallar
# burada bir havuzdan karışık seçilir. Kademe büyüdükçe havuz genişler ve
# aynı anda geçerli kural sayısı artar; iki öğrenci aynı kural setini nadiren
# görür.

# İşlem kalıpları: (ad, en düşük kademe, kurucu). Kurucu sayı listesini alır,
# (yazı, gereken işlemler, yapı ilişkileri) döner ya da uygun değilse None.
def _k_toplam(s):
    return "+".join(map(str, s)), {"+"}, []


def _k_carp_topla(s):
    a, b, *kalan = s
    return "{}×{}+{}".format(a, b, "+".join(map(str, kalan))), {"*", "+"}, []


def _k_carp_cikar(s):
    a, b, c, *kalan = s
    if a * b <= c:
        return None
    yazi = "{}×{}-{}".format(a, b, c) + "".join("+{}".format(x) for x in kalan)
    return yazi, {"*", "-"} | ({"+"} if kalan else set()), []


def _k_parantez_cikar(s):
    a, b, c, *kalan = s
    if a <= b:
        return None
    yazi = "({}-{})×{}".format(a, b, c) + "".join("+{}".format(x) for x in kalan)
    return yazi, {"*", "-"} | ({"+"} if kalan else set()), [("*", "-")]


def _k_parantez_topla(s):
    a, b, c, *kalan = s
    yazi = "({}+{})×{}".format(a, b, c) + "".join("-{}".format(x) for x in kalan)
    return yazi, {"*", "+"} | ({"-"} if kalan else set()), [("*", "+")]


def _k_iki_carpim(s):
    a, b, c, d, *kalan = s
    yazi = "{}×{}+{}×{}".format(a, b, c, d) + "".join("+{}".format(x) for x in kalan)
    return yazi, {"*", "+"}, []


_KALIPLAR = [
    ("toplam", 3, 3, _k_toplam),
    ("carp_topla", 4, 3, _k_carp_topla),
    ("carp_cikar", 5, 3, _k_carp_cikar),
    ("iki_carpim", 6, 4, _k_iki_carpim),
    ("parantez_cikar", 7, 3, _k_parantez_cikar),
    ("parantez_topla", 7, 3, _k_parantez_topla),
]   # (ad, en düşük kademe, en az sayı adedi, kurucu)

# Sayı kuralları ve açıldıkları kademe.
_OZELLIK_KADEMESI = {"cift": 3, "tek": 4, "sifirsiz": 4, "kat3": 5, "kat5": 5, "asal": 7}


def _kural_sayisi(kademe: int) -> int:
    """Temel kurallar (adet, en küçük) dışında kaç ek kural."""
    return 1 if kademe <= 4 else (2 if kademe <= 7 else 3)


def _merdiven_kur(rastgele, kademe):
    """(hedef, koşul, örnek çözüm, kalıp adı) üretir."""
    kaliplar = [k for k in _KALIPLAR if k[1] <= kademe]
    for _ in range(200):
        ad, _k, en_az, kurucu = rastgele.choice(kaliplar)
        adet = rastgele.randint(max(en_az, 3), 4 if kademe <= 5 else 5)
        kosul = {"serbest": True, "adet": adet, "en_kucuk": 2}
        ek_sayisi = _kural_sayisi(kademe)
        secenekler = ["farkli", "yayilim", "en_buyuk", "ozellik"]
        # Sıralı yazım yalnız düz toplamda doğal; ötekilerde işlem kuralları.
        secenekler += ["artan"] if ad == "toplam" else ["gerekli", "yasak", "son"]
        ekler = rastgele.sample(secenekler, min(ek_sayisi, len(secenekler)))

        # Sayı havuzu
        alt, ust = 2, (20 if kademe <= 5 else 30)
        if "en_buyuk" in ekler:
            ust = rastgele.choice([9, 12, 15])
            kosul["en_buyuk"] = ust
        ozellikler = []
        if "ozellik" in ekler:
            uygun = [o for o, k in _OZELLIK_KADEMESI.items() if k <= kademe]
            ozellikler = [rastgele.choice(uygun)]
            kosul["ozellik"] = ozellikler
        havuz = [n for n in range(alt, ust + 1)
                 if all(ifade.SAYI_OZELLIKLERI[o][1](n) for o in ozellikler)]
        farkli = "farkli" in ekler or "yayilim" in ekler or "artan" in ekler
        if farkli:
            kosul["farkli"] = True
        if "yayilim" in ekler:
            genislik = rastgele.choice([4, 5, 6, 8])
            if len(havuz) < adet:
                continue
            bas = rastgele.choice(havuz)
            havuz = [n for n in havuz if bas <= n <= bas + genislik]
            kosul["yayilim"] = genislik
        if (farkli and len(havuz) < adet) or not havuz:
            continue
        sayilar = (rastgele.sample(havuz, adet) if farkli
                   else [rastgele.choice(havuz) for _ in range(adet)])
        if "artan" in ekler:
            sayilar.sort()
            kosul["artan"] = True
        kur = kurucu(sayilar)
        if kur is None:
            continue
        yazi, islemler, yapi = kur
        if yapi:
            kosul["yapi"] = yapi
        yapida = {i for cift in yapi for i in cift}
        if "gerekli" in ekler or (ad != "toplam" and not yapi):
            gerekli = sorted(islemler - {"+"} - yapida) or sorted(islemler - yapida)
            if gerekli:
                kosul["gerekli"] = gerekli
        yasak = [i for i in "+-*/" if i not in islemler]
        if ad == "toplam" or "yasak" in ekler:
            kosul["yasak"] = yasak
        elif "/" in yasak:
            kosul["yasak"] = ["/"]
        hedef_f, _kul, _isl, son = ifade.coz(yazi)
        if hedef_f.denominator != 1 or not (10 <= hedef_f <= 400):
            continue
        if "son" in ekler:
            kosul["son_islem"] = son
        hedef = int(hedef_f)
        if ifade.denetle(yazi, hedef, [], kosul)[0]:
            return hedef, kosul, yazi, ad
    raise RuntimeError("kural merdiveni kurulamadı")


# Bağlamlar kalıptan bağımsız: aynı kural seti farklı hikâyelerle gelir.
_MERDIVEN_HIKAYE = [
    ("Fide dikimi", "{kisi}, tarlaya toplam {hedef} fide dikecek. Sıra sayısı "
     "ve her sıraya kaç fide gideceği kurallara bağlı."),
    ("Sevkiyat listesi", "{kisi}, sınır kapısına giden sevkiyatın {hedef} "
     "koli tuttuğunu biliyor ama listeyi kaybetmiş. Listeyi kurallara uyacak "
     "şekilde yeniden kurman gerek."),
    ("Enerji raporu", "{kisi}, haftalık enerji raporunda {hedef} birim "
     "yazmalı. Raporu oluşturan hesabı kurallara uygun kurmalısın."),
    ("Su tankları", "{kisi}, üsse {hedef} litre su ayıracak. Tankların "
     "dolumu kurallara göre planlanıyor."),
    ("Nöbet çizelgesi", "{kisi}, bu ay toplam {hedef} saatlik nöbet "
     "dağıtacak. Saatleri kurallara uyan bir hesapla göster."),
    ("Maden vagonları", "{kisi}, cevher hattına {hedef} ton yük gönderecek. "
     "Vagon yüklerini kurallara uygun bir işlemle planla."),
]


@bulmaca(ders="matematik", konu="islem_kurma", kademeler=(3, 13), agirlik=1.1)
def hedef_merdiveni(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sonuç verilir; öğrenci kurallara uyan sayıları ve işlemi kendisi seçer."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    hedef, kosul, ornek, kalip = _merdiven_kur(rastgele, kademe)
    baslik, hikaye = rastgele.choice(_MERDIVEN_HIKAYE)
    kural = ifade.kosul_metni(kosul)
    adet = kosul["adet"]

    adimlar = []
    if kalip == "toplam":
        ortalama = Fraction(hedef, adet)
        adimlar.append(model_adimi(
            soru="Yalnız toplamayla {} sayı seçeceksen işe nereden başlarsın?".format(adet),
            dogru="Hedefi sayı adedine bölüp ortalamayı bulmak; sayılar onun çevresinde seçilir.",
            yanlislar={
                "En büyük sayıyı seçip kalanı ötekilere dağıtmak.":
                    "Önce çok büyük bir sayı seçersen öteki kurallara yer kalmayabilir.",
                "Bir sayıyı hedefe çok yakın, ötekileri en küçük seçmek.":
                    "En küçük sınırı ve öteki kurallar bu yolu çoğu zaman kapatır.",
                "Sayıları rastgele seçip toplamı sonra düzeltmek.":
                    "Olur ama uzun sürer; ortalama nereye bakacağını baştan söyler.",
            },
            rastgele=rastgele,
            aciklama="Toplam = ortalama × sayı adedi; ortalama başlangıç noktasıdır.",
            puan=10,
        ))
        adimlar.append(sayi_adimi(
            soru="Sayı başına ortalama kaç düşer? (Ondalıklı olabilir.)",
            cevap=float(ortalama), tolerans=0.01,
            aciklama="{} ÷ {} = {}".format(hedef, adet, str(round(float(ortalama), 2)).replace(".", ",")),
            puan=8,
        ))
    else:
        adimlar.append(model_adimi(
            soru="Bu kurallarla hedefe ulaşmanın en sağlam yolu hangisi?",
            dogru=("Önce kuralın istediği işlemle (çarpma ya da parantez) hedefe "
                   "yakın bir ara sonuç kurmak, kalan farkı öteki sayılarla kapatmak."),
            yanlislar={
                "Önce sayıları seçip hangi işlemin çıkacağına sonra bakmak.":
                    "Kurallar işlemi de bağlıyor; sayılar işleme göre seçilmeli.",
                "Çok büyük iki sayıyı çarpıp sonra çok çıkarmak.":
                    "Hedefi çok aşarsan kalan sayılarla geri dönemeyebilirsin.",
                "Kuralları sonra kontrol etmek; önce sonucu tutturmak.":
                    "Sonuç doğru olsa da tek bir kural bozulursa işlem geçmez.",
            },
            rastgele=rastgele,
            aciklama="Büyük adımı çarpma atar, ince ayarı toplama ve çıkarma yapar.",
            puan=12,
        ))
    adimlar.append(Adim(
        soru="Sonucu {} olan işlemi yaz. Kurallar: {}.".format(hedef, kural),
        tur=IFADE, rol=COZUM,
        cevap={"hedef": hedef, "sayilar": [], "kosul": kosul, "ornek": ifade.okunur(ornek)},
        aciklama="Kurallara uyan her yol doğru. Bir örnek: {} = {}.".format(
            ifade.okunur(ornek), hedef),
        ipuclari=["Kuralları tek tek kontrol et: sayı adedi, sayıların özelliği, işlemler."],
        cozum="Bir çözüm: {} = {}".format(ifade.okunur(ornek), hedef),
        puan=16,
    ))
    return Bulmaca(
        kod="mat-hedef-merdiveni-{}".format(kalip),
        ders="matematik",
        baslik=baslik,
        kademe=kademe,
        konu="islem_kurma",
        kazanim=("Verilen sonuca kurallara uyan işlemle ulaşma; ortalama, "
                 "sayı özellikleri, işlem önceliği ve parantez."),
        dikkat=4,
        brifing=hikaye.format(kisi=kisi, hedef=hedef) +
        "\n\nKurallar kayıt defterinde yazılı; sayıları sen seçeceksin.",
        kanitlar=[Kanit("Kayıt defteri", "Hedef: {}\nKurallar: {}".format(hedef, kural),
                        bedel=1, kritik=True)],
        adimlar=adimlar,
        kapanis="Hesap kurallara uygun kuruldu.",
        odul={"erzak": 2, "itibar": 3},
    )
