# -*- coding: utf-8 -*-
"""
Düşünme ve sorgulama görevleri.

Bu alandaki yorum soruları çoğunlukla aynı kalıptadır: bir metin verilir,
"bu parçada savunulan görüş hangisidir" diye sorulur. Yani zaten bir keşif
işidir - filozof adı ezberlemek değil, metindeki iddiayı tanımak.

Bu modül o kalıbı üssün arşivine taşır: Kronograf'ın getirdiği düşünce
parçaları, bir tartışma tutanağı, bir mektup. Öğrenci önce metnin hangi
soruyu yanıtladığını belirler, sonra görüşü adlandırır.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi, secim_adimi, sirala_adimi,
    yorum_adimi,
)


# ==========================================================================
# BİLGİ FELSEFESİ
# ==========================================================================

_BILGI_GORUSLERI = [
    {
        "ad": "Rasyonalizm (akılcılık)",
        "metin": ("Duyularım beni sürekli yanıltıyor: uzaktaki kule yuvarlak "
                  "görünüyor, suya batan çubuk kırık görünüyor. Oysa üçgenin iç "
                  "açıları toplamının iki dik açı ettiğini hiçbir üçgen çizmeden, "
                  "yalnızca düşünerek biliyorum ve bu bilgi hiç yanıltmıyor. "
                  "Demek ki güvenilir bilgi duyulardan değil akıldan gelir."),
        "olcut": "Bilginin kaynağı akıldır; duyular yanıltıcıdır.",
        "neden": ("Metin duyuların yanılttığını örnekliyor ve deney gerektirmeyen "
                  "akıl bilgisini güvenilir sayıyor. Bilginin kaynağını akla "
                  "dayandıran görüş rasyonalizmdir."),
    },
    {
        "ad": "Empirizm (deneycilik)",
        "metin": ("İnsan zihni doğduğunda üzerine hiçbir şey yazılmamış boş bir "
                  "levha gibidir. Hiç kar görmemiş birine karın soğukluğunu "
                  "anlatamazsınız. Zihnimizdeki bütün kavramlar, önce duyularımıza "
                  "çarpan izlenimlerden gelir. Deneyimin vermediği hiçbir bilgi "
                  "zihinde bulunmaz."),
        "olcut": "Bilginin kaynağı deneyimdir; zihin doğuştan boştur.",
        "neden": ("\"Boş levha\" benzetmesi ve bütün kavramların duyu izlenimlerinden "
                  "türetilmesi empirizmin tanımıdır."),
    },
    {
        "ad": "Kritisizm (eleştirel felsefe)",
        "metin": ("Bilgi ne yalnızca akıldan ne de yalnızca deneyden doğar. "
                  "Duyular bize ham veriyi getirir; ama zihin bu veriyi kendi "
                  "kalıplarına dökmeseydi bir yığın karmaşadan başka bir şey "
                  "olmazdı. Kavramsız algılar kör, algısız kavramlar ise boştur; "
                  "bilgi ikisinin birleşmesidir."),
        "olcut": "Bilgi akıl ile deneyin birlikte çalışmasıyla oluşur.",
        "neden": ("Metin iki kaynağı da tek başına yetersiz sayıp bilgiyi ikisinin "
                  "birleşimine bağlıyor. Bu, kritisizmin temel savıdır."),
    },
    {
        "ad": "Septisizm (kuşkuculuk)",
        "metin": ("Bir şeyi bildiğimizi söylediğimizde, bunu neye dayanarak "
                  "söylüyoruz? Dayanağımızı da başka bir dayanakla kanıtlamamız "
                  "gerekir, onu da bir başkasıyla. Bu zincirin sonu yok. O hâlde "
                  "hiçbir konuda kesin bilgiye ulaşamayız; yargıyı askıya almak "
                  "en doğrusudur."),
        "olcut": "Kesin bilgiye ulaşmak mümkün değildir.",
        "neden": ("Sonsuz gerileme sorunu ve \"yargıyı askıya alma\" tutumu "
                  "septisizmin ayırt edici işaretleridir."),
    },
]


@bulmaca(ders="felsefe", konu="bilgi_felsefesi", kademeler=(9, 13), agirlik=1.4)
def bilgi_felsefesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Metinden bilgi görüşünü tanıma ve gerekçelendirme."""
    gorus = rastgele.choice(_BILGI_GORUSLERI)
    digerleri = [g for g in _BILGI_GORUSLERI if g["ad"] != gorus["ad"]]

    return Bulmaca(
        kod="fel-bilgi",
        ders="felsefe",
        baslik="Arşivdeki Düşünce",
        kademe=kademe,
        konu="bilgi_felsefesi",
        kazanim="Bilgi felsefesindeki temel yaklaşımları metinden tanıma.",
        dikkat=5,
        brifing=(
            "Kronograf bu sefer bir ses değil, bir defter sayfası getirdi. "
            "Sayfada imza yok, tarih yok; yalnızca bir düşünce var:\n\n"
            "\"{}\"\n\n"
            "Arşiv fişine bu parçanın hangi görüşü savunduğu yazılacak. Yazarın "
            "adını bilmiyoruz - zaten sorulan da o değil."
        ).format(gorus["metin"]),
        kanitlar=[
            Kanit("Felsefe el kitabı - bilginin kaynağı",
                  "RASYONALİZM: Bilginin kaynağı akıldır; duyular yanıltır. "
                  "Doğuştan gelen, deney gerektirmeyen bilgiler vardır.\n\n"
                  "EMPİRİZM: Bilginin kaynağı deneyimdir. Zihin doğuşta boş bir "
                  "levhadır; bütün kavramlar duyu izlenimlerinden gelir.\n\n"
                  "KRİTİSİZM: Akıl ve deney birlikte gerekir; biri olmadan diğeri "
                  "bilgi üretmez.\n\n"
                  "SEPTİSİZM: Kesin bilgi mümkün değildir; yargı askıya alınmalıdır.",
                  bedel=2, kritik=True),
            Kanit("Okuma notu",
                  "\"Metinde filozof adı geçmez. Görüşü tanımak için tek soru "
                  "yeter: bu metne göre bilgi NEREDEN geliyor?\"",
                  bedel=2, kritik=True),
            Kanit("Sayfanın arkası",
                  "Boş. Yalnızca kâğıdın kenarında soluk bir mürekkep lekesi var.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu metnin hangi görüşü savunduğunu anlamak için neye bakılmalı?",
                dogru="Metnin bilginin KAYNAĞI hakkında ne söylediğine.",
                yanlislar={
                    "Metnin hangi yüzyılda yazıldığına.":
                        "Tarihe baktın. Aynı yüzyılda birbirine taban tabana "
                        "zıt görüşler savunulur; görüşü belirleyen zaman "
                        "değil, İDDİA.",
                    "Metinde kaç örnek verildiğine.":
                        "Örnek sayısını ölçüt saydın. Örnekler iddiayı "
                        "destekler ama hangi görüş olduğunu söyleyen şey "
                        "iddianın kendisi.",
                    "Metnin dilinin ağır ya da sade olmasına.":
                        "Üsluba baktın. Aynı görüş hem ağır hem sade dille "
                        "anlatılabilir.",
                    "Metinde bir filozof adının geçip geçmediğine; ad görüşü ele verir.":
                        "Ada baktın. Ad geçmeden de bir görüş savunulabilir; "
                        "ad geçse bile metin onu eleştiriyor olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bilgi felsefesi tek bir soruyu tartışır: doğru bilgi mümkün mü, "
                    "mümkünse kaynağı nedir? Görüşleri birbirinden ayıran da bu "
                    "sorunun cevabıdır. Metnin yazarı, dönemi ya da üslubu görüşü "
                    "belirlemez; önemli olan metindeki iddiadır."
                ),
                ipuclari=[
                    "Metne göre güvenilir bilgi nereden geliyor: akıldan mı, duyudan mı?",
                    "Ya da metin \"hiçbir yerden, çünkü kesin bilgi yok\" mu diyor?",
                ],
                puan=18,
                cozum=(
                    "1) Metinde bilginin kaynağı hakkında kurulan cümleyi bul.\n"
                    "2) El kitabındaki dört tanımla karşılaştır:\n"
                    "   - Yalnızca akıl -> Rasyonalizm\n"
                    "   - Yalnızca deney -> Empirizm\n"
                    "   - İkisi birlikte -> Kritisizm\n"
                    "   - Hiçbiri, kesin bilgi yok -> Septisizm\n"
                    "3) Bu metnin ölçütü: {}\n"
                    "4) {}\n\n"
                    "Sonuç: {}"
                ).format(gorus["olcut"], gorus["neden"], gorus["ad"]),
            ),
            secim_adimi(
                soru="Bu parçada savunulan görüş hangisidir?",
                dogru=gorus["ad"],
                yanlislar=dict(
                    [(g["ad"], "{} görüşünün ölçütü bu metinde geçmiyor. El "
                               "kitabındaki tanımı metnin iddiasıyla yan yana "
                               "koy.".format(g["ad"])) for g in digerleri]
                    + [("Pozitivizm",
                        "Pozitivizm bilginin yalnızca gözlem ve deneyle "
                        "kurulacağını söyler. Metnin ölçüt cümlesi bunu "
                        "savunmuyor.")]
                ),
                rastgele=rastgele,
                aciklama="{} {}".format(gorus["neden"], "Ölçüt: " + gorus["olcut"]),
                ipuclari=["El kitabındaki dört tanımı metinle tek tek karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Bu tür sorularda filozof adı bilmek neden yeterli değildir?",
                dogru="Soru metindeki iddiayı tanımayı ister; adı bilmek iddiayı bilmek değildir.",
                yanlislar={
                    "Filozof adlarını bilmek bütün görüşü açıklamaya yeter.":
                        "Adı görüşün yerine koydun. Ad bir etikettir; soru "
                        "etiketi değil, metindeki İDDİAYI tanımanı istiyor.",
                    "Filozofların görüşleri zamanla değiştiği için; genç ve yaşlı filozof farklı düşünür.":
                        "Sebebi filozofun kendi değişimine bağladın. Sorun "
                        "orada değil: ad bilen öğrenci de metni okumadan "
                        "eşleştiremez.",
                    "Metinler her zaman anonim yazıldığı için.":
                        "Metinlerin hepsi anonim değil. Ad yazsa bile o adı "
                        "bilmek, metnin ne savunduğunu bilmek demek değil.",
                    "Ad bilmek yeterlidir; bu soru tipi kolaydır.":
                        "Soruyu ezber sorusu saydın. Burada istenen tanıma "
                        "değil, metni ölçütle eşleştirme.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Descartes rasyonalisttir\" bilgisi, önüne konan adsız bir metni "
                    "tanımaya yetmez. Yetecek olan şey rasyonalizmin NE İDDİA ETTİĞİNİ "
                    "bilmektir. Bu yüzden felsefede ezberlenmesi gereken şey isimler "
                    "değil, iddiaların ayırt edici cümleleridir."
                ),
                puan=12,
            ),
        ],
        kapanis="Arşiv fişine \"{}\" yazıldı; gerekçe hanesine de metindeki ölçüt eklendi.".format(
            gorus["ad"]),
        odul={"itibar": 7},
    )


# ==========================================================================
# FELSEFENİN ALANLARI
# ==========================================================================

@bulmaca(ders="felsefe", konu="felsefe_alanlari", kademeler=(9, 13))
def felsefe_alanlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir soru hangi felsefe dalına ait?"""
    sorular = [
        {"soru": "Var olan her şeyin temelinde madde mi vardır?",
         "alan": "Varlık felsefesi (ontoloji)",
         "neden": "Sorulan şey neyin VAR olduğu ve varlığın niteliğidir."},
        {"soru": "İnsan kesin bilgiye ulaşabilir mi?",
         "alan": "Bilgi felsefesi (epistemoloji)",
         "neden": "Sorulan şey bilginin imkânı ve kaynağıdır."},
        {"soru": "Bir eylemi doğru ya da yanlış yapan nedir?",
         "alan": "Ahlak felsefesi (etik)",
         "neden": "Sorulan şey eylemin değeri, iyi-kötü ölçütüdür."},
        {"soru": "Bir yapıtı güzel kılan şey nedir?",
         "alan": "Sanat felsefesi (estetik)",
         "neden": "Sorulan şey güzelin ölçütü ve sanatın değeridir."},
        {"soru": "Devletin otoritesi neye dayanarak meşru olur?",
         "alan": "Siyaset felsefesi",
         "neden": "Sorulan şey iktidarın kaynağı ve meşruluğudur."},
        {"soru": "Bir akıl yürütmenin geçerli olması ne demektir?",
         "alan": "Mantık",
         "neden": "Sorulan şey çıkarımın biçimsel geçerliliğidir."},
    ]
    secilen = rastgele.choice(sorular)
    digerleri = [s["alan"] for s in sorular if s["alan"] != secilen["alan"]]
    rastgele.shuffle(digerleri)

    return Bulmaca(
        kod="fel-alanlar",
        ders="felsefe",
        baslik="Hangi Rafa",
        kademe=kademe,
        konu="felsefe_alanlari",
        kazanim="Felsefenin alt dallarını, sordukları soruya göre ayırt etme.",
        dikkat=5,
        brifing=(
            # Konu adı başta söylenmez (TASARIM_NOTLARI: keşif sonunda
            # adlandırma). Eskiden brifing "arşivin felsefe bölümü alt
            # dallara göre raflanıyor" diyordu (ChatGPT incelemesi, B36).
            "Arşivin düşünce yazıları, sordukları soruya göre raflanıyor. "
            "Elindeki fişte tek bir soru yazıyor:\n\n"
            "  \"{}\"\n\n"
            "Fişi doğru rafa koyman gerekiyor. Arşivci \"bunların hepsi aynı "
            "şey, nereye koysak olur\" diyor; ama her raf başka bir soruyu "
            "tartışır."
        ).format(secilen["soru"]),
        kanitlar=[
            Kanit("Raf etiketleri",
                  "ONTOLOJİ: Ne vardır? Varlığın temeli nedir?\n"
                  "EPİSTEMOLOJİ: Bilgi mümkün mü? Kaynağı nedir?\n"
                  "ETİK: İyi nedir? Bir eylemi doğru yapan nedir?\n"
                  "ESTETİK: Güzel nedir? Sanatın değeri nedir?\n"
                  "SİYASET FELSEFESİ: İktidar neye dayanır? Adalet nedir?\n"
                  "MANTIK: Geçerli akıl yürütme nedir?",
                  bedel=2, kritik=True),
            Kanit("Fiş", secilen["soru"], bedel=1, kritik=True),
            Kanit("Arşivci notu",
                  "\"Dalı belirleyen konu değil, sorulan SORUDUR. Aynı konu "
                  "(örneğin sanat) hem estetiğin hem ahlakın hem de siyasetin "
                  "sorusu olabilir.\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir sorunun hangi felsefe dalına ait olduğunu ne belirler?",
                dogru="Sorunun neyi araştırdığı: varlığı mı, bilgiyi mi, değeri mi.",
                yanlislar={
                    "Soruda hangi kelimelerin geçtiği; \"bilgi\" geçen soru bilgi felsefesidir.":
                        "Kelime avına çıktın. Aynı kelime farklı dalların "
                        "sorusunda geçebilir; belirleyici olan sorunun NEYİ "
                        "araştırdığı.",
                    "Sorunun kim tarafından sorulduğu; ahlakçının sorusu ahlak felsefesidir.":
                        "Soranı ölçüt saydın. Bir soruyu kimin sorduğu, onu "
                        "hangi dalın ilgilendirdiğini değiştirmez.",
                    "Sorunun ne kadar eski olduğu.":
                        "Tarihe baktın. Çok eski bir soru da bugünün "
                        "dallarından birine girer.",
                    "Sorunun cevabının bilinip bilinmediği.":
                        "Cevabın durumunu ölçüt saydın. Felsefede çoğu sorunun "
                        "kesin cevabı yoktur; bu onları dalsız bırakmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Felsefenin dalları konulara göre değil SORULARA göre ayrılır. "
                    "\"Sanat\" konusu estetiğin sorusudur (\"güzel nedir\"), ama aynı "
                    "sanat ahlakın da sorusu olabilir (\"sanat ahlaki sınır tanımalı mı\"). "
                    "Bu yüzden anahtar kelime aramak yanıltır; sorulan şeyi anlamak gerekir."
                ),
                ipuclari=[
                    "Bu soru neyin var olduğunu mu, nasıl bilindiğini mi, "
                    "değerini mi araştırıyor?",
                    "Raf etiketlerindeki soru kalıplarıyla karşılaştır.",
                ],
                puan=18,
                cozum=(
                    "Raf etiketlerindeki soru kalıplarını fişteki soruyla eşle:\n"
                    "  \"{}\"\n"
                    "{}\n\n"
                    "Sonuç: {}"
                ).format(secilen["soru"], secilen["neden"], secilen["alan"]),
            ),
            secim_adimi(
                soru="Bu soru hangi felsefe dalına aittir?",
                dogru=secilen["alan"],
                yanlislar=digerleri[:4],
                rastgele=rastgele,
                aciklama=secilen["neden"],
                ipuclari=["Raf etiketlerini fişle karşılaştır."],
                puan=16,
            ),
            yorum_adimi(
                soru="Aynı konu birden çok felsefe dalının sorusu olabilir mi?",
                dogru="Evet; dalları ayıran konu değil, sorulan sorudur.",
                yanlislar={
                    "Hayır; her konu tek bir dala aittir, sanat yalnız estetiğin konusudur.":
                        "Dalları kapalı kutular saydın. Aynı konu farklı "
                        "sorularla farklı dallara girer: bilginin ne olduğu "
                        "ayrı, doğru eylemin ne olduğu ayrı sorudur.",
                    "Hayır; dallar birbirinden tamamen bağımsızdır.":
                        "Bağımsızlığı mutlaklaştırdın. Dallar farklı sorular "
                        "sorar ama aynı konuyu paylaşabilir.",
                    "Evet ama yalnızca mantık ile epistemolojide.":
                        "Doğru fikri iki dala hapsettin. Aynı örtüşme ahlak "
                        "ile siyaset felsefesi arasında da olur.",
                    "Evet; çünkü felsefenin dalları arasında fark yoktur.":
                        "Doğru sonuca yanlış gerekçeyle vardın. Dallar arasında "
                        "fark VAR; örtüşmeyi sağlayan şey farkın yokluğu değil, "
                        "aynı konuya farklı sorular sorulabilmesi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Adalet\" konusu siyaset felsefesinin de etiğin de sorusudur; "
                    "biri \"adil devlet nedir\", diğeri \"adil davranış nedir\" diye "
                    "sorar. Dallar konuları değil bakış açılarını böler. Bu ayrım "
                    "kavranmadan yapılan eşleştirmeler ezbere kalır."
                ),
                puan=12,
            ),
        ],
        kapanis="Fiş doğru rafa kondu.",
        odul={"itibar": 6},
    )


# ==========================================================================
# AHLAK FELSEFESİ
# ==========================================================================

_AHLAK_GORUSLERI = [
    {
        "ad": "Faydacılık (yararcılık)",
        "metin": ("Bir eylemin doğru olup olmadığını anlamak için sonuçlarına "
                  "bakmalıyız. En çok sayıda insana en çok mutluluğu sağlayan "
                  "eylem doğrudur. Az kişiye büyük yarar sağlayan bir eylem, "
                  "çok kişiye küçük yarar sağlayandan üstün değildir."),
        "olcut": "Ölçüt eylemin SONUCU; en çok kişinin en çok yararı.",
    },
    {
        "ad": "Ödev ahlakı",
        "metin": ("Bir eylemi ahlaklı yapan şey sonucu değil, hangi niyetle "
                  "yapıldığıdır. Doğruyu söylemek işime yaradığı için "
                  "söylüyorsam ahlaklı davranmış olmam; doğruyu, doğru olduğu "
                  "için söylemeliyim. Ahlak yasası koşulsuzdur, çıkara bağlanamaz."),
        "olcut": "Ölçüt eylemin NİYETİ ve ödeve uygunluğu; sonuç önemli değil.",
    },
    {
        "ad": "Hazcılık (hedonizm)",
        "metin": ("İnsan doğası gereği acıdan kaçar, hazza yönelir. İyi dediğimiz "
                  "şey haz veren, kötü dediğimiz şey acı verendir. Ahlakın amacı "
                  "acıyı en aza indirip dinginliğe ulaşmaktır."),
        "olcut": "Ölçüt haz ve acı; iyi olan haz verendir.",
    },
    {
        "ad": "Erdem etiği",
        "metin": ("Sorulması gereken \"hangi eylem doğru\" değil, \"nasıl bir "
                  "insan olmalıyım\" sorusudur. Cesaret korkaklık ile atılganlık "
                  "arasındaki ortadır. Ahlaklı olmak, bu orta hâlleri alışkanlık "
                  "hâline getirmektir."),
        "olcut": "Ölçüt kişinin karakteri ve erdemleri; aşırılıklar arasındaki orta.",
    },
]


@bulmaca(ders="felsefe", konu="ahlak_felsefesi", kademeler=(10, 13))
def ahlak_felsefesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Metinden ahlak görüşünü tanıma."""
    gorus = rastgele.choice(_AHLAK_GORUSLERI)
    digerleri = [g for g in _AHLAK_GORUSLERI if g["ad"] != gorus["ad"]]

    return Bulmaca(
        kod="fel-ahlak",
        ders="felsefe",
        baslik="Tutanaktaki Sav",
        kademe=kademe,
        konu="ahlak_felsefesi",
        kazanim="Ahlak felsefesindeki temel yaklaşımları metinden tanıma.",
        dikkat=5,
        brifing=(
            "Üste zor bir karar tartışıldı ve tutanağa geçen savlardan biri şu:\n\n"
            "\"{}\"\n\n"
            "Tutanak arşive girmeden önce bu savın hangi ahlak anlayışına "
            "dayandığı fişlenecek. Kim söylediği değil, neye dayandığı önemli."
        ).format(gorus["metin"]),
        kanitlar=[
            Kanit("Felsefe el kitabı - ahlak ölçütleri",
                  "FAYDACILIK: Ölçüt sonuçtur; en çok kişiye en çok yarar.\n"
                  "ÖDEV AHLAKI: Ölçüt niyettir; ödev koşulsuzdur, sonuca bakılmaz.\n"
                  "HAZCILIK: Ölçüt hazdır; iyi olan haz veren, kötü olan acı verendir.\n"
                  "ERDEM ETİĞİ: Ölçüt karakterdir; erdem aşırılıklar arasındaki ortadır.",
                  bedel=2, kritik=True),
            Kanit("Ayırt etme notu",
                  "\"Tek soru yeter: metin eylemi neye bakarak yargılıyor? "
                  "Sonucuna mı, niyetine mi, verdiği hazza mı, kişinin "
                  "karakterine mi?\"", bedel=2, kritik=True),
            Kanit("Tutanak kapağı",
                  "Toplantıda üç sav ileri sürülmüş; bu, ikincisi. Söyleyenin adı "
                  "karalanmış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir ahlak görüşünü tanımak için metinde ne aranır?",
                dogru="Eylemin neye bakarak yargılandığı: sonuç, niyet, haz ya da karakter.",
                yanlislar={
                    "Metnin olumlu mu olumsuz mu bir eylemden söz ettiği; eylemi övmek ya da kınamak görüşü belirler.":
                        "Eylemin iyiliğine baktın. Ahlak görüşünü belirleyen "
                        "şey eylemin kendisi değil, onu ÖLÇMEK için kullanılan "
                        "ölçüt.",
                    "Metinde kaç kişiden söz edildiği.":
                        "Kişi sayısını ölçüt saydın. Faydacılık çoğunluğa "
                        "bakar ama bir görüşü tanımak için sayı saymak "
                        "yetmez.",
                    "Metnin dinî bir dayanağı olup olmadığı.":
                        "Kaynağı ölçüt saydın. Aynı ölçüt hem dinî hem seküler "
                        "bir metinde savunulabilir.",
                    "Metnin hangi ülkede yazıldığı.":
                        "Coğrafyaya baktın. Ahlak görüşleri ülkelere göre "
                        "sınıflandırılmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ahlak felsefesindeki bütün görüşler aynı soruyu yanıtlar: "
                    "\"bir eylemi iyi yapan nedir?\" Ayrıldıkları yer verdikleri "
                    "ÖLÇÜTTÜR. O yüzden metinde aranacak şey ölçüt cümlesidir; "
                    "genellikle \"...bakmalıyız\", \"...olan doğrudur\" biçiminde geçer."
                ),
                ipuclari=[
                    "Metin \"sonuçlarına bakmalıyız\" mı diyor, \"niyetine\" mi?",
                    "Ölçüt cümlesini bul, gerisi kendiliğinden gelir.",
                ],
                puan=18,
                cozum=(
                    "1) Metindeki ÖLÇÜT cümlesini bul.\n"
                    "2) El kitabındaki dört ölçütle karşılaştır:\n"
                    "   - Sonuç ve toplam yarar -> Faydacılık\n"
                    "   - Niyet ve koşulsuz ödev -> Ödev ahlakı\n"
                    "   - Haz ve acı -> Hazcılık\n"
                    "   - Karakter ve orta yol -> Erdem etiği\n"
                    "3) Bu metnin ölçütü: {}\n\n"
                    "Sonuç: {}"
                ).format(gorus["olcut"], gorus["ad"]),
            ),
            secim_adimi(
                soru="Bu savın dayandığı ahlak anlayışı hangisidir?",
                dogru=gorus["ad"],
                yanlislar=dict(
                    [(g["ad"], "{} görüşünün ölçütü metindeki ölçüt cümlesiyle "
                               "uyuşmuyor. El kitabındaki tanımla yan yana "
                               "koy.".format(g["ad"])) for g in digerleri]
                    + [("Görecelilik (relativizm)",
                        "Görecelilik, doğrunun kişiden kişiye değiştiğini "
                        "söyler. Metin ise herkes için geçerli bir ölçüt "
                        "öne sürüyor.")]
                ),
                rastgele=rastgele,
                aciklama="Ölçüt: {} Bu ölçüt {} görüşünü tanımlar.".format(
                    gorus["olcut"], gorus["ad"]),
                ipuclari=["Metnin ölçüt cümlesini el kitabıyla eşleştir."],
                puan=18,
            ),
            yorum_adimi(
                soru="Faydacılık ile ödev ahlakı arasındaki temel ayrım nedir?",
                dogru="Biri sonuca, diğeri niyete bakar.",
                yanlislar={
                    "Biri bireyi, diğeri toplumu düşünür; fayda toplumun, ödev bireyin işidir.":
                        "Ayrımı kapsama göre kurdun. İkisi de hem bireyi hem "
                        "toplumu konu edebilir; ayrım eylemin NEYE göre "
                        "değerlendirildiğinde.",
                    "Biri dine, diğeri akla dayanır.":
                        "Ayrımı kaynağa bağladın. Her iki görüş de akıl "
                        "yürütmeyle savunulur.",
                    "Biri eski, diğeri yeni bir görüştür.":
                        "Ayrımı tarihe bağladın. Yaş bir görüşün ölçütünü "
                        "belirlemez.",
                    "Aralarında anlamlı bir fark yoktur.":
                        "Farkı yok saydın. Aynı eylem, sonucuna bakan biri "
                        "için doğru, niyetine bakan biri için yanlış olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı eylem iki görüşe göre farklı yargılanabilir: yalan "
                    "söyleyerek birinin canını kurtarmak faydacıya göre doğrudur "
                    "(sonuç iyidir), ödev ahlakına göre sorunludur (yalan koşulsuz "
                    "yasaktır). Bu yüzden ayrım \"toplum mu birey mi\" değil, "
                    "\"sonuç mu niyet mi\" eksenindedir."
                ),
                puan=12,
            ),
        ],
        kapanis="Sav fişlendi ve tutanak arşive kaldırıldı.",
        odul={"itibar": 7},
    )


# ==========================================================================
# ARGÜMAN ÇÖZÜMLEME
# ==========================================================================

@bulmaca(ders="felsefe", konu="akil_yurutme", kademeler=(9, 13))
def akil_yurutme(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tümdengelim mi tümevarım mı; sonucun kesinliği buna bağlı."""
    ornekler = [
        {
            "metin": ("Bütün metaller ısıtılınca genleşir. Bakır bir metaldir. "
                      "O hâlde bakır ısıtılınca genleşir."),
            "tur": "Tümdengelim",
            "kesinlik": "Öncüller doğruysa sonuç KESİNDİR.",
            "neden": ("Genel bir kuraldan tek bir duruma inildi. Tümdengelimde "
                      "öncüller doğruysa sonucun yanlış olması imkânsızdır."),
        },
        {
            "metin": ("Bu üste ölçtüğümüz yüz kuşun hepsinin kanadı vardı. "
                      "O hâlde bütün kuşların kanadı vardır."),
            "tur": "Tümevarım",
            "kesinlik": "Öncüller doğru olsa bile sonuç yalnızca OLASIDIR.",
            "neden": ("Tek tek gözlemlerden genel bir yargıya çıkıldı. Yüz kuş "
                      "gözlemek, gözlenmemiş kuşlar hakkında kesinlik vermez."),
        },
        {
            "metin": ("Yağmur yağdığında zemin ıslanır. Bugün yağmur yağdı. "
                      "O hâlde zemin ıslandı."),
            "tur": "Tümdengelim",
            "kesinlik": "Öncüller doğruysa sonuç KESİNDİR.",
            "neden": ("Genel kural tek bir olaya uygulandı; öncüller kabul "
                      "edilirse sonuç zorunlu olarak çıkar."),
        },
        {
            "metin": ("Son beş kışta da dere şubatta taştı. O hâlde bu şubatta "
                      "da taşacak."),
            "tur": "Tümevarım",
            "kesinlik": "Öncüller doğru olsa bile sonuç yalnızca OLASIDIR.",
            "neden": ("Geçmiş gözlemlerden geleceğe genelleme yapıldı; güçlü bir "
                      "beklenti kurar ama kesinlik vermez."),
        },
    ]
    ornek = rastgele.choice(ornekler)

    return Bulmaca(
        kod="fel-akil-yurutme",
        ders="felsefe",
        baslik="Rapordaki Çıkarım",
        kademe=kademe,
        konu="akil_yurutme",
        kazanim="Tümdengelim ve tümevarımı ayırt etme; sonucun kesinlik derecesini değerlendirme.",
        dikkat=5,
        brifing=(
            "Merkeze gidecek raporda şöyle bir çıkarım var:\n\n"
            "  \"{}\"\n\n"
            "Komutan bu cümlenin altına \"kesindir\" mi yoksa \"beklenmektedir\" "
            "mi yazacağını soruyor. İkisi arasındaki fark, çıkarımın türünden "
            "geliyor."
        ).format(ornek["metin"]),
        kanitlar=[
            Kanit("Rapordaki çıkarım", ornek["metin"], bedel=1, kritik=True),
            Kanit("Mantık el kitabı",
                  "TÜMDENGELİM: Genelden özele gidilir. Öncüller doğruysa sonuç "
                  "ZORUNLU olarak doğrudur; yeni bilgi vermez, var olanı açar.\n\n"
                  "TÜMEVARIM: Özelden genele gidilir. Öncüller doğru olsa bile "
                  "sonuç OLASIDIR; yeni bilgi verir ama kesinlik vermez.",
                  bedel=2, kritik=True),
            Kanit("Yazışma kuralı",
                  "\"Raporda kesin olmayan bir sonuç 'kesindir' diye yazılamaz. "
                  "Olasılık bildiren çıkarımlar 'beklenmektedir' ifadesiyle "
                  "yazılır.\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bu çıkarımın yönü nedir?",
                dogru=("Genelden özele" if ornek["tur"] == "Tümdengelim"
                       else "Özelden genele"),
                yanlislar={
                    ("Özelden genele" if ornek["tur"] == "Tümdengelim"
                     else "Genelden özele"):
                        "Yönü ters okudun. Öncüllerin hangisinin geniş, "
                        "hangisinin dar olduğuna bak: genel bir kuraldan tek "
                        "bir duruma mı gidiliyor, yoksa tek tek durumlardan "
                        "genel bir kurala mı?",
                    "Özelden özele":
                        "Bu bir benzetmedir (analoji), çıkarımın yönü değil. "
                        "Buradaki öncüllerden biri genel bir ifade.",
                    "Genelden genele":
                        "İki ucu da genel saydın. Çıkarımın bir ucunda tek bir "
                        "duruma ait ifade var.",
                    "Çıkarımda bir yön yoktur":
                        "Yönü yok saydın. Akıl yürütmenin yönü tam da onu "
                        "hangi tür yapan şey.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çıkarımın yönü türünü, türü de sonucun kesinliğini belirler. "
                    "Genel bir kuralla başlayıp tek bir duruma inen çıkarım "
                    "tümdengelimdir; tek tek gözlemlerle başlayıp genel bir yargıya "
                    "çıkan çıkarım tümevarımdır."
                ),
                ipuclari=[
                    "İlk cümle genel bir kural mı, tek tek gözlem mi?",
                    "Sonuç cümlesi tek bir durumu mu, hepsini mi anlatıyor?",
                ],
                puan=18,
                cozum=(
                    "1) Öncüllere bak: genel kural mı, tekil gözlemler mi?\n"
                    "2) Sonuca bak: tekil bir durum mu, genel bir yargı mı?\n"
                    "3) Genelden tekile iniyorsa TÜMDENGELİM, tekilden genele "
                    "çıkıyorsa TÜMEVARIM.\n"
                    "4) {}\n\n"
                    "Bu çıkarım: {} - {}"
                ).format(ornek["neden"], ornek["tur"], ornek["kesinlik"]),
            ),
            secim_adimi(
                soru="Bu çıkarım hangi tür akıl yürütmedir?",
                dogru=ornek["tur"],
                yanlislar={
                    ("Tümevarım" if ornek["tur"] == "Tümdengelim" else "Tümdengelim"):
                        "Türü ters aldın. Bir önceki adımda belirlediğin yönle "
                        "eşleştir: genelden özele giden tümdengelim, özelden "
                        "genele giden tümevarımdır.",
                    "Analoji (benzetme)":
                        "Analoji iki ayrı durumu benzeterek sonuç çıkarır. "
                        "Burada bir genelleme ile tek bir durum arasında "
                        "bağ kuruluyor.",
                    "Tanım":
                        "Tanım bir kavramın ne olduğunu söyler; buradaki "
                        "cümleler öncüllerden sonuç çıkarıyor.",
                    "Sınıflandırma":
                        "Sınıflandırma öğeleri gruplara ayırır. Burada grup "
                        "değil, bir SONUÇ üretiliyor.",
                },
                rastgele=rastgele,
                aciklama=ornek["neden"],
                ipuclari=["Çıkarımın yönünü belirledin; el kitabındaki tanımla eşleştir."],
                puan=16,
            ),
            secim_adimi(
                soru="Rapora bu cümlenin altına ne yazılmalı?",
                dogru=("\"Kesindir\" - öncüller doğruysa sonuç zorunludur."
                       if ornek["tur"] == "Tümdengelim"
                       else "\"Beklenmektedir\" - sonuç olasıdır, kesin değildir."),
                yanlislar={
                    ("\"Beklenmektedir\" - sonuç olasıdır, kesin değildir."
                     if ornek["tur"] == "Tümdengelim"
                     else "\"Kesindir\" - öncüller doğruysa sonuç zorunludur."):
                        "Notu çıkarımın türüyle ters eşleştirdin. Tümdengelimde "
                        "sonuç zorunlu, tümevarımda olasıdır; belirlediğin "
                        "türle notu yan yana koy.",
                    "\"Belirsizdir\" - çıkarımdan hiçbir sonuç çıkmaz.":
                        "Çıkarımı sonuçsuz saydın. Her iki türde de bir sonuç "
                        "çıkar; değişen şey o sonucun ne kadar bağlayıcı "
                        "olduğu.",
                    "\"Yanlıştır\" - çıkarım geçersizdir.":
                        "Çıkarımı geçersiz ilan ettin. Öncüllerden sonuca "
                        "geçiş kurallıysa çıkarım geçerlidir; rapora yazılacak "
                        "not onun kesinlik derecesi.",
                    "Hiçbir not düşülmemeli.":
                        "Notu gereksiz saydın. Üst makam sonucun ne kadar "
                        "güvenilir olduğunu bilmeden karar veremez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{} Bu yüzden rapora {} ifadesi yazılır. Tümevarımsal bir sonucu "
                    "\"kesindir\" diye yazmak, elde olmayan bir güveni rapora "
                    "eklemek olur."
                ).format(ornek["kesinlik"],
                         "\"kesindir\"" if ornek["tur"] == "Tümdengelim"
                         else "\"beklenmektedir\""),
                ipuclari=["Bu tür çıkarımda sonuç zorunlu mu, olası mı?"],
                puan=14,
            ),
        ],
        kapanis="Rapordaki çıkarımın altına doğru ifade yazıldı.",
        odul={"itibar": 7},
    )


# ==========================================================================
# GEÇERLİLİK VE DOĞRULUK (B37 -- müfredat haritası)
#
# Haritada iki satır bu görevi bekliyordu:
#   `mantik_argumantasyon` (2026, 10. sınıf) -- "Akıl ilkeleri, önerme,
#       çıkarım, safsata ve öncül"
#   `akil_yurutme_kavramlari` (2018, 10. sınıf) -- konusu kelimesi kelimesine
#       "doğruluk ve geçerlilik"
# İkisi de `akil_yurutme`ye kaba eşlenmişti; o görev tümdengelim/tümevarım
# ayrımını ölçüyor, geçerliliği ölçmüyor.
#
# Ortak `yaygin_yanlis`: "Sonucun doğru olmasını çıkarımın geçerli olmasıyla
# karıştırmak; kişiye saldırıyı kanıt saymak."
#
# TASARIMIN KALBİ -- AYNI BİÇİMDE İKİ ÇIKARIM:
#   Bütün kedigiller memelidir. Aslan bir memelidir. O hâlde aslan kedigildir.
#   Bütün kedigiller memelidir. Köpek bir memelidir. O hâlde köpek kedigildir.
# Biri doğru sonuca, öteki yanlış sonuca varıyor -- ama İKİSİ DE AYNI ŞEKİLDE
# GEÇERSİZ. Aslanın kedigil çıkması biçimden değil tesadüften. Yanılgıyı en
# net bu çift kırıyor: sonucun doğruluğu geçerliliği belirleseydi, aynı
# biçimdeki iki çıkarımdan biri geçerli öteki geçersiz olurdu.
#
# Kullanılan geçersiz biçim tek ve bilinçli seçildi (orta terimin
# dağıtılmaması): "Bütün A'lar B'dir. C bir B'dir. O hâlde C bir A'dır."
# Geçerli biçim de tek: "Bütün A'lar B'dir. C bir A'dır. O hâlde C bir B'dir."
# İki biçimle sınırlı kalmak geçerliliği tartışmasız kılıyor.
# ==========================================================================

# Aynı GEÇERSİZ biçim, biri doğru biri yanlış sonuçlu.
_GECERSIZ_CIFTLER = [
    {
        "dogru": ("Bütün kedigiller memelidir. Aslan bir memelidir. "
                  "O hâlde aslan bir kedigildir."),
        "yanlis": ("Bütün kedigiller memelidir. Köpek bir memelidir. "
                   "O hâlde köpek bir kedigildir."),
        "karsi": "köpek de memelidir ama kedigil değildir",
    },
    {
        "dogru": ("Güneş sistemindeki bütün gezegenler Güneş'in etrafında döner. "
                  "Mars Güneş'in etrafında döner. O hâlde Mars bir gezegendir."),
        "yanlis": ("Güneş sistemindeki bütün gezegenler Güneş'in etrafında döner. "
                   "Halley Kuyruklu Yıldızı Güneş'in etrafında döner. "
                   "O hâlde Halley bir gezegendir."),
        "karsi": "kuyruklu yıldızlar da Güneş'in etrafında döner ama gezegen değildir",
    },
    {
        "dogru": ("Üssün bütün güneş panelleri elektrik üretir. Çatıdaki "
                  "fotovoltaik modül elektrik üretir. O hâlde çatıdaki modül "
                  "bir güneş panelidir."),
        "yanlis": ("Üssün bütün güneş panelleri elektrik üretir. Rüzgâr türbini "
                   "elektrik üretir. O hâlde rüzgâr türbini bir güneş panelidir."),
        "karsi": "rüzgâr türbini de elektrik üretir ama güneş paneli değildir",
    },
]

# GEÇERLİ biçim, ama öncüllerden en az biri yanlış ve sonuç yine de doğru.
_GECERLI_YANLIS_ONCUL = [
    {
        "metin": ("Bütün balıklar memelidir. Yunus bir balıktır. "
                  "O hâlde yunus bir memelidir."),
        "yanlis_oncul": "iki öncül de yanlış: balıklar memeli değildir, yunus balık değildir",
    },
    {
        "metin": ("Bütün metaller oda sıcaklığında sıvıdır. Cıva bir metaldir. "
                  "O hâlde cıva oda sıcaklığında sıvıdır."),
        "yanlis_oncul": "ilk öncül yanlış: metallerin çoğu oda sıcaklığında katıdır",
    },
]

# Tek çıkarım sınıflandırmasının dört şıkkı. Hangisinin doğru olduğu örneğin
# türüne bağlı; ikisi hükmü doğru ama GEREKÇESİ yanlış.
_G_GECERLI = "Geçerli: sonuç, öncüllerin biçiminden zorunlu olarak çıkıyor"
_G_GECERSIZ = "Geçersiz: sonuç öncüllerden zorunlu olarak çıkmıyor"
_G_SONUC_DOGRU = "Geçerli: çünkü sonucu doğru; doğru sonuca varan çıkarım geçerlidir"
_G_ONCUL_YANLIS = "Geçersiz: çünkü öncüllerinden biri yanlış"


@bulmaca(ders="felsefe", konu="mantik_argumantasyon", kademeler=(9, 13), agirlik=1.3)
def tartisma_tutanagi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Geçerlilik ile doğruluğu ayırt etmek; kişiye saldırı safsatası."""
    cift_sira = list(range(len(_GECERSIZ_CIFTLER)))
    rastgele.shuffle(cift_sira)
    cift = _GECERSIZ_CIFTLER[cift_sira[0]]            # 3. adımın çifti

    # 2. adım: iki tuzaktan biri. Doğru sonuçlu geçersiz örnek seçilirse,
    # 3. adımdaki çiftten FARKLI bir çiftten alınır -- öğrenci aynı metni
    # iki kez görmesin.
    tek_tur = rastgele.choice(["gecersiz_dogru", "gecerli_yanlis_oncul"])
    if tek_tur == "gecersiz_dogru":
        tek_metin = _GECERSIZ_CIFTLER[cift_sira[1]]["dogru"]
        tek_dogru = _G_GECERSIZ
        tek_yanlislar = {
            _G_GECERLI:
                "Sonuç öncüllerden zorunlu olarak çıkmıyor: bir şeyin memeli "
                "(ya da Güneş'in etrafında dönen, elektrik üreten) olması onu o "
                "gruba sokmaz. Aynı biçimle yanlış bir sonuca da varılabilir.",
            _G_SONUC_DOGRU:
                "Sonucun doğru olmasını çıkarımın geçerli olmasıyla karıştırdın. "
                "Sonuç doğru ama öncüllerden çıkmıyor; doğruluğu tesadüf.",
            _G_ONCUL_YANLIS:
                "Hüküm doğru ama gerekçe yanlış: bu çıkarımın iki öncülü de "
                "doğru. Geçersizliğin sebebi öncüller değil, biçim.",
        }
    else:
        ornek = rastgele.choice(_GECERLI_YANLIS_ONCUL)
        tek_metin = ornek["metin"]
        tek_dogru = _G_GECERLI
        tek_yanlislar = {
            _G_GECERSIZ:
                "Bu çıkarım geçerli: öncüller doğru KABUL EDİLSEYDİ sonuç "
                "zorunlu olarak doğru olurdu. Geçerlilik öncüllerin gerçekten "
                "doğru olup olmadığına bakmaz.",
            _G_SONUC_DOGRU:
                "Hüküm doğru ama gerekçe yanlış: geçerliliği sonucun doğru "
                "olması belirlemiyor. Aynı biçimle yanlış bir sonuca da geçerli "
                "olarak varılabilir.",
            _G_ONCUL_YANLIS:
                "Geçerliliği sağlamlıkla karıştırdın. Öncül yanlışsa çıkarım "
                "SAĞLAM değildir ama biçimi hâlâ GEÇERLİDİR ({}).".format(
                    ornek["yanlis_oncul"]),
        }

    oneren = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fel-tartisma-tutanagi",
        ders="felsefe",
        baslik="Tartışma Tutanağı",
        kademe=kademe,
        konu="mantik_argumantasyon",
        kazanim="Bir çıkarımın geçerliliğini sonucunun doğruluğundan ayırt etme; "
                "kişiye saldırı safsatasını tanıma.",
        dikkat=7,
        brifing=(
            "Üs konseyinin dünkü toplantısının tutanağı arşive geldi. "
            "Toplantıda epey tartışılmış ve bazı kararlar \"sonuç doğru "
            "çıktığına göre akıl yürütme de doğruydu\" diye alınmış.\n\n"
            "Arşiv görevlisi olarak tutanaktaki çıkarımları incelemen "
            "gerekiyor: hangileri gerçekten sağlam bir akıl yürütmeye "
            "dayanıyor, hangileri yalnızca doğru bir sonuca rastlamış?"
        ),
        kanitlar=[
            Kanit("Tutanak -- birinci not",
                  "\"{}\"".format(tek_metin), bedel=1, kritik=True),
            Kanit("Tutanak -- iki çıkarım",
                  "A: \"{}\"\nB: \"{}\"".format(cift["dogru"], cift["yanlis"]),
                  bedel=2, kritik=True),
            Kanit("Tutanak -- itiraz",
                  "{} atölyeye arıtma tesisi kurulmasını önerdi ve gerekçesini "
                  "sundu. Toplantıdaki biri şöyle karşılık verdi: \"Bu kişi geçen "
                  "ay jeneratörü yanlış bağlamıştı. Onun önerisine güvenilmez; "
                  "öneri yanlıştır.\"".format(oneren),
                  bedel=1, kritik=True),
            Kanit("Mantık notu",
                  "GEÇERLİ bir çıkarımda öncüller doğru kabul edilirse sonuç "
                  "ZORUNLU olarak doğrudur. SAĞLAM bir çıkarım ise hem geçerli "
                  "hem de öncülleri gerçekten doğru olan çıkarımdır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir çıkarımın GEÇERLİ olması ne demektir?",
                dogru="Öncüller doğru kabul edilirse sonucun zorunlu olarak doğru olması",
                yanlislar={
                    "Sonucunun doğru olması; amaç zaten doğru sonuca ulaşmaktır":
                        "Sonucun doğru olmasını çıkarımın geçerli olmasıyla "
                        "karıştırdın. Doğru bir sonuca geçersiz bir yoldan da "
                        "varılabilir.",
                    "Öncüllerinin gerçekten doğru olması; yanlış öncülden geçerli çıkarım kurulamaz":
                        "Bu SAĞLAMLIK için gerekir, geçerlilik için değil. "
                        "Yanlış öncüllerle de geçerli bir çıkarım kurulabilir.",
                    "Toplantıdakilerin çoğunun sonuca katılması":
                        "Çoğunluğun kabulü bir çıkarımı geçerli yapmaz; buna "
                        "çoğunluğa başvurma safsatası denir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Geçerlilik, çıkarımın İÇERİĞİNE değil BİÇİMİNE bakar: "
                    "öncüller doğru olsaydı sonuç doğru olmak ZORUNDA mıydı? "
                    "Bir sonucun gerçekte doğru olup olmadığı ayrı bir sorudur. "
                    "Bu yüzden geçersiz bir çıkarımın sonucu doğru, geçerli bir "
                    "çıkarımın sonucu yanlış olabilir."
                ),
                ipuclari=[
                    "Mantık notunu oku: geçerlilik ile sağlamlık aynı şey mi?",
                    "Öncüller doğru kabul edildiğinde sonuç ne olmak zorunda?",
                ],
                cozum=(
                    "Geçerli: öncüller doğruysa sonuç zorunlu olarak doğru.\n"
                    "Sağlam: geçerli + öncüller gerçekten doğru.\n"
                    "Sonucun doğruluğu geçerliliği belirlemez."
                ),
            ),
            secim_adimi(
                soru="Tutanaktaki birinci not hakkında hangisi doğrudur?",
                dogru=tek_dogru,
                yanlislar=tek_yanlislar,
                rastgele=rastgele,
                aciklama=(
                    "Hem hükme hem gerekçeye bak. İki şıkta hüküm doğru ama "
                    "gerekçe yanlış -- bu konudaki karışıklığı tam olarak "
                    "onlar yakalıyor."
                ),
                ipuclari=["Öncülleri doğru kabul et: sonuç zorunlu olarak çıkıyor mu?"],
                puan=12,
            ),
            secim_adimi(
                soru="Tutanaktaki A ve B çıkarımları hakkında hangisi doğrudur?",
                dogru="Aynı biçimdeler ve ikisi de geçersiz; A'nın sonucu tesadüfen doğru",
                yanlislar={
                    "A geçerli, B geçersiz; çünkü A'nın sonucu doğru, B'ninki yanlış":
                        "Sonucun doğru olmasını geçerlilikle karıştırdın. İkisinin "
                        "biçimi AYNI; biçim aynıysa geçerlilik de aynı olmalı.",
                    "İkisi de geçerli; çünkü aynı biçimdeler ve A'nın sonucu doğru çıktı":
                        "Aynı biçimde olduklarını doğru gördün ama o biçim "
                        "geçersiz. B bunun kanıtı: aynı biçim yanlış bir sonuca "
                        "varıyor.",
                    "Karşılaştırılamazlar; konuları farklı olan çıkarımların biçimi de farklıdır":
                        "Geçerlilik konuya değil biçime bakar. Konuları farklı "
                        "olsa da biçimleri aynı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "B, A'nın KARŞI ÖRNEĞİ: aynı biçimle, öncülleri doğru olduğu "
                    "hâlde yanlış bir sonuca varılabiliyorsa, o biçim sonucu "
                    "garanti etmiyor demektir -- yani geçersizdir. Burada: {}."
                ).format(cift["karsi"]),
                ipuclari=["A ile B'nin biçimini yan yana koy: ne değişiyor, ne aynı kalıyor?"],
                puan=14,
            ),
            yorum_adimi(
                soru="Tutanaktaki itiraz hakkında hangisi doğrudur?",
                dogru="Kişiye saldırı: gerekçeyi değil kişiyi hedef alıyor, geçmiş hata öneriyi çürütmez",
                yanlislar={
                    "Haklı bir itiraz: hata yapmış birinin önerileri de güvenilmezdir.":
                        "Kişiye saldırıyı kanıt saydın. Önerinin doğru ya da "
                        "yanlış olduğu, gerekçesine bakılarak anlaşılır; onu "
                        "kimin yaptığına bakılarak değil.",
                    "Haklı bir itiraz: jeneratör de arıtma da teknik konu olduğu için geçmiş hata ilgilidir.":
                        "İlgili görünmesi itirazı geçerli yapmıyor. İtiraz yine "
                        "önerinin gerekçesine hiç dokunmuyor.",
                    "Öneriyi çürütür, çünkü itiraz eden kişi konseyin en deneyimli üyesidir.":
                        "Bu da başka bir safsata: otoriteye başvurma. İtiraz "
                        "edenin deneyimi, itirazın içeriğini doğru yapmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kişiye saldırı (ad hominem) safsatasında bir iddia, "
                    "gerekçesi yerine onu ileri süren kişi üzerinden reddedilir. "
                    "İtiraz kişi hakkında doğru bir bilgi içerebilir -- "
                    "jeneratör gerçekten yanlış bağlanmış olabilir -- ama bu, "
                    "arıtma önerisinin gerekçesi hakkında hiçbir şey söylemez."
                ),
                puan=12,
            ),
        ],
        kapanis=("Arşiv notu: sonuç doğru çıktı diye akıl yürütme doğru sayılmaz; "
                 "kişiye saldırı da bir öneriyi çürütmez."),
        odul={"itibar": 6, "erzak": 1, "enerji": 1},
    )


# ==========================================================================
# ARGÜMAN YAPISI: SIRALAMA DEĞİL TEMELLENDİRME (B37.15 -- müfredat haritası)
#
# 2018 programı, 10. sınıf: "Felsefi metinde kavram, problem, görüş ve
# gerekçe". Haritada `akil_yurutme`ye kaba eşlenmişti; o görev tümdengelim/
# tümevarım ölçüyor. Felsefenin EN YÜKLÜ yanılgısı (6 satır) bu:
#
#   "Filozof görüşlerini sıralamayı kendi argümanını kurmak sanmak; tezi
#    gerekçeyle ilişkilendirmemek."
#
# İKİ TASLAK, AYNI SORU:
#   A -- görüşleri peş peşe sıralar, "farklı görüşler vardır" diye biter.
#        Tez yok, gerekçe yok. Yanılgının ta kendisi.
#   B -- bir tez koyar, gerekçelendirir, filozofu bir GEREKÇEYİ desteklemek
#        için kullanır ve bir itirazı karşılar.
#
# ATIF DİKKATİ: öğrenciye yanlış atıf öğretmek bu görevin en kolay hatası
# olurdu. Görüşler yalnız iyi yerleşmiş, tartışmasız özetlerle ve DOLAYLI
# anlatımla veriliyor; uydurma doğrudan alıntı yok:
#   Aristoteles -- dağıtıcı adalet: herkese hak ettiği ölçüde
#   Marx        -- "herkesten yeteneğine göre, herkese ihtiyacına göre"
#   Leopold     -- toprak etiği: insan, doğa topluluğunun bir üyesidir
# "İnsan merkezci yaklaşım" bir kişiye değil genel bir tutuma atfediliyor.
# ==========================================================================

_TASLAKLAR = [
    {
        "soru": "Üs erzağı herkese eşit mi dağıtılmalı, yoksa üsse katkıya göre mi?",
        "a": [
            "Aristoteles adaleti, herkese hak ettiği ölçüde vermek olarak görür.",
            "Marx ise \"herkesten yeteneğine göre, herkese ihtiyacına göre\" "
            "ilkesini savunur.",
            "Bazı düşünürler de kaynakların tamamen eşit paylaşılmasını ister.",
            "Görüldüğü gibi bu konuda farklı görüşler vardır.",
        ],
        "tez": ("Üste temel erzak herkese eşit, ek erzak ise katkıya göre "
                "dağıtılmalıdır."),
        "gerekce": ("Çünkü temel erzak hayatta kalmak için gereklidir ve kimsenin "
                    "hayatta kalması katkısına bağlı tutulamaz."),
        "alinti": ("Aristoteles'in adaleti hak edilene göre vermek olarak görmesi, "
                   "ek payın katkıya bağlanmasını destekler."),
        "gerekce2": ("Ek erzağı katkıya bağlamak ise fazladan emeği ödüllendirir "
                     "ve üssün işlemesini sağlar."),
        "itiraz": ("Hastalanıp çalışamayanların ek paydan yoksun kalacağı itiraz "
                   "edilebilir; ama temel pay onların ihtiyacını zaten güvenceye alır."),
    },
    {
        "soru": "Üs genişlemek için yakındaki ormanı kesmeli mi?",
        "a": [
            "Aldo Leopold, doğayı insanın yalnızca kullandığı bir mülk değil, "
            "parçası olduğu bir topluluk olarak görür.",
            "İnsan merkezci yaklaşıma göre ise doğa, insanın ihtiyaçları için vardır.",
            "Kimi düşünürler de doğanın kendi başına değerli olduğunu söyler.",
            "Bu konuda pek çok farklı görüş olduğu görülmektedir.",
        ],
        "tez": ("Üs, ormanı kesmek yerine zaten açık olan araziye "
                "genişlemelidir."),
        "gerekce": ("Çünkü orman, üssün kullandığı suyu tutan ve toprağı "
                    "erozyondan koruyan bir sistemdir."),
        "alinti": ("Leopold'un doğayı parçası olduğumuz bir topluluk olarak "
                   "görmesi, ormanı kesmenin üssün kendi dayanağını zayıflatacağı "
                   "fikrini destekler."),
        "gerekce2": ("Açık araziye genişlemek biraz daha pahalı olsa da ormanın "
                     "sağladığı korumayı kaybetmekten ucuzdur."),
        "itiraz": ("Açık arazinin uzak olduğu için taşımayı zorlaştıracağı itiraz "
                   "edilebilir; ama bu maliyet geçicidir, ormanın kaybı kalıcıdır."),
    },
]


@bulmaca(ders="felsefe", konu="felsefi_metin_cozumleme", kademeler=(9, 13), agirlik=1.3)
def deneme_taslaklari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Görüş sıralamak ile argüman kurmak; tez, gerekçe ve alıntının rolü."""
    t = rastgele.choice(_TASLAKLAR)
    yazar_a, yazar_b = ad_sec(rastgele, PERSONEL, 2)
    taslak_a = " ".join(t["a"])
    taslak_b = " ".join([t["tez"], t["gerekce"], t["alinti"], t["gerekce2"], t["itiraz"]])

    return Bulmaca(
        kod="fel-deneme-taslaklari",
        ders="felsefe",
        baslik="Deneme Taslakları",
        kademe=kademe,
        konu="felsefi_metin_cozumleme",
        kazanim="Felsefi bir metinde görüş sıralamayı argüman kurmaktan ayırt "
                "etme; tez, gerekçe ve alıntının işlevini belirleme.",
        dikkat=7,
        brifing=(
            "Üs bülteninin bu sayısında şu soru tartışılacak:\n\n"
            "    \"{}\"\n\n"
            "İki deneme taslağı geldi, ama bültende yalnız birine yer var. "
            "Yayın kurulu \"hangisi daha çok filozof anıyorsa o daha felsefi\" "
            "diye düşünüyor. Taslakları okuyup hangisinin gerçekten bir "
            "argüman kurduğunu bulmamız gerekiyor."
        ).format(t["soru"]),
        kanitlar=[
            Kanit("Taslak A -- {}".format(yazar_a), taslak_a, bedel=2, kritik=True),
            Kanit("Taslak B -- {}".format(yazar_b), taslak_b, bedel=2, kritik=True),
            Kanit("Yayın kurulu notu",
                  "Felsefi bir denemede bir TEZ (savunulan görüş), onu destekleyen "
                  "GEREKÇELER ve karşı görüşlere yanıt beklenir. Başka düşünürlerin "
                  "görüşleri bu yapının İÇİNDE kullanılabilir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Felsefi bir metinde ARGÜMAN ne demektir?",
                dogru="Bir tezin, onu destekleyen gerekçelere bağlandığı yapı",
                yanlislar={
                    "Konuyla ilgili filozofların görüşlerinin sıralanması; felsefe, filozofları bilmektir":
                        "Görüş sıralamayı argüman kurmak sandın. Görüşleri "
                        "aktarmak, onlardan hangisini neden savunduğunu "
                        "göstermek değildir.",
                    "Yazarın konu hakkındaki kişisel fikrini belirtmesi":
                        "Fikir belirtmek yetmez; fikrin GEREKÇESİ olmadan argüman "
                        "olmaz. Felsefe yalnız kişisel görüş değildir.",
                    "Konuyla ilgili doğru bilgilerin eksiksiz aktarılması":
                        "Bilgi aktarmak da argüman değil. Argüman bir şeyi "
                        "SAVUNUR ve neden savunduğunu gösterir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Argümanın iki zorunlu parçası var: bir TEZ ve onu taşıyan "
                    "GEREKÇELER. İkisi arasındaki bağ -- 'çünkü' -- argümanı bir "
                    "görüş listesinden ayıran şey. Filozofların görüşleri bir "
                    "argümanda kullanılabilir, ama argümanın yerine geçemez."
                ),
                ipuclari=[
                    "Yayın kurulu notuna bak: bir denemede ne bekleniyor?",
                    "Bir görüşü aktarmak ile bir görüşü savunmak aynı şey mi?",
                ],
                cozum=(
                    "Argüman = tez + tezi destekleyen gerekçeler.\n"
                    "Görüş sıralamak: tez yok, gerekçe yok.\n"
                    "Kişisel fikir: tez var, gerekçe yok."
                ),
            ),
            secim_adimi(
                soru="Taslak A'da bir argüman var mı?",
                dogru="Hayır: görüşler sıralanmış ama yazarın tezi ve gerekçesi yok.",
                yanlislar={
                    "Evet: birden çok filozofun görüşüne yer verilmiş.":
                        "Filozof sayısı argümanın ölçüsü değil. Taslak A hiçbir "
                        "görüşü savunmuyor; \"farklı görüşler vardır\" diye bitiyor.",
                    "Evet: görüşler doğru ve düzgün aktarılmış.":
                        "Doğru aktarmak argüman kurmak değil. Yazar kendi hangi "
                        "görüşü savunduğunu hiç söylemiyor.",
                    "Hayır: çünkü felsefi bir denemede filozof görüşü kullanılmamalı.":
                        "Hüküm doğru ama gerekçe yanlış. Filozof görüşü "
                        "kullanılabilir -- Taslak B de kullanıyor. Sorun, A'da "
                        "görüşlerin bir tezi desteklemek için değil, yalnız "
                        "sıralanmak için orada olması.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Taslak A'nın son cümlesi durumu özetliyor: \"farklı görüşler "
                    "vardır.\" Bu bir tez değil, bir gözlem. Soruya bir cevap "
                    "vermiyor, yalnız başkalarının verdiği cevapları listeliyor."
                ),
                ipuclari=["Taslak A soruya bir cevap veriyor mu?"],
                puan=12,
            ),
            secim_adimi(
                soru="Taslak B'nin TEZİ hangi cümledir?",
                dogru=t["tez"],
                yanlislar={
                    t["gerekce"]:
                        "Bu bir GEREKÇE: \"çünkü\" ile başlıyor ve bir şeyin NEDEN "
                        "öyle olması gerektiğini açıklıyor. Tez, gerekçelendirilen "
                        "iddianın kendisi.",
                    t["alinti"]:
                        "Bu cümle bir düşünürün görüşünü bir GEREKÇEYİ desteklemek "
                        "için kullanıyor. Tez değil, tezi taşıyan yapının parçası.",
                    t["itiraz"]:
                        "Bu bir itiraz ve ona verilen yanıt. Tezi savunan bir "
                        "hamle ama tezin kendisi değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tez, metnin cevap verdiği soruya verdiği cevaptır. Öteki "
                    "cümlelerin hepsi o cevaba hizmet ediyor: biri nedenini "
                    "söylüyor, biri bir düşünürle destekliyor, biri bir itirazı "
                    "karşılıyor."
                ),
                ipuclari=["Bültenin sorusuna doğrudan cevap veren cümle hangisi?"],
                puan=12,
            ),
            yorum_adimi(
                soru="Taslak B'de düşünürden yapılan alıntı yazıda hangi işi görüyor?",
                dogru="Bir gerekçeyi destekliyor; yazarın tezinin yerine geçmiyor.",
                yanlislar={
                    "Yazının tezi o; yazar düşünürün görüşünü aktarıyor.":
                        "Görüş aktarmakla tez kurmayı karıştırdın. Yazarın tezi "
                        "kendi cümlesi; düşünür o tezi taşıyan bir gerekçeye destek.",
                    "Yazarın karşı çıktığı görüşü gösteriyor; alıntı hep çürütülmek için yapılır.":
                        "Alıntı karşı çıkılan bir görüş değil; tersine yazarın "
                        "bir gerekçesini \"destekler\" diye sunuluyor.",
                    "Metne bir işlev katmıyor; çıkarılsa hiçbir şey değişmez.":
                        "Çıkarılırsa gerekçelerden biri desteksiz kalır. Alıntı "
                        "burada süs değil, bir dayanak.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki taslak da düşünürlere yer veriyor; fark, onları NASIL "
                    "kullandıklarında. A'da düşünürler metnin kendisi -- sıralanıp "
                    "bırakılıyorlar. B'de bir gerekçeye destek oluyorlar ve "
                    "yazarın kendi tezine hizmet ediyorlar. Yayın kurulunun "
                    "\"çok filozof anan daha felsefi\" ölçütü bu yüzden yanlış."
                ),
                puan=12,
            ),
        ],
        kapanis=("Bülten kararı: Taslak B -- daha az düşünür anıyor ama bir tez "
                 "savunuyor ve gerekçelendiriyor. Taslak A'nın yazarına not: "
                 "görüşleri sırala, sonra hangisini neden savunduğunu yaz."),
        odul={"itibar": 6, "erzak": 1, "enerji": 1},
    )


# ==========================================================================
# KURUL METNİ: GÖRÜŞ SIRALAMAK ARGÜMAN KURMAK DEĞİLDİR (B37.16)
#
# 2026 programının altı 11. sınıf satırı (akıl-inanç, edebiyat-felsefe, hayatın
# anlamı, hukuk, teknoloji, çevre) aynı yaygın yanlışı paylaşıyor:
#
#   "Filozof görüşlerini sıralamayı kendi argümanını kurmak sanmak; tezi
#    gerekçeyle ilişkilendirmemek."
#
# Bağlamları da aynı kalıpta: "Sefer kuruluna <konu> hakkında tez, gerekçe ve
# karşı görüş içeren felsefi metin sunma". 2018 programının iki 10. sınıf
# satırı (`alternatif_gorus`, `felsefi_deneme`: "Alıntı sıralamayı argüman
# geliştirmek sanmak") da buraya ek karşılıkla bağlanıyor.
#
# `deneme_taslaklari` iki taslağı karşılaştırıyordu. Bu görev metni PARÇALARINA
# ayırtıyor: taslakta kaç cümle tez ya da gerekçe (çoğu kez sıfır ya da
# gerekçesiz tek tez), argümanın parçaları hangileri, hangi sırayla dizilir.
#
# ATIF DİKKATİ: düşünür görüşleri iyi yerleşmiş özetlerle ve dolaylı anlatımla
# veriliyor; uydurma doğrudan alıntı yok.
# ==========================================================================

_KURUL_KONULARI = (
    {
        "alan": "akıl ve inanç",
        "soru": "Seferde tehlike karşısında akıl ile inanç birbirini dışlar mı?",
        "aktarimlar": (
            "İbn Rüşd'e göre akıl ile vahiy çatışmaz; doğru, doğruya aykırı olamaz.",
            "Kierkegaard inancı akılla temellendirilemeyen bir sıçrama olarak görür.",
            "Thomas Aquinas'a göre bazı inanç konuları akılla kanıtlanabilir, bazıları "
            "yalnız vahiyle bilinir.",
        ),
        "tez": "Akıl ve inanç birbirini dışlamaz; farklı sorulara yanıt verir.",
        "gerekce": ("Çünkü akıl tehlikeden nasıl korunulacağını hesaplar, inanç ise zor "
                    "anda neden sürdürüleceğine dair anlam ve güç verir."),
        "karsi": ("İnancın, aklın durmamızı söylediği yerde bizi ilerlemeye itebileceği "
                  "itiraz edilebilir."),
        "yanit": ("Ama inanç hesabın yerine değil, hesaptan sonra sürdürme gücü olarak "
                  "kullanıldığında çatışma doğmaz."),
    },
    {
        "alan": "edebiyat ve felsefe",
        "soru": "Seferin anlatı kitaplığı felsefi bir değer taşır mı?",
        "aktarimlar": (
            "Platon, şairlerin hakikatten uzak taklitler ürettiğini düşünür.",
            "Aristoteles'e göre şiir, olanı değil olabilecek olanı anlattığı için "
            "tarihten daha felsefidir.",
            "Sartre varoluşçu düşüncelerini romanlarında da işlemiştir.",
        ),
        "tez": "Edebî anlatılar felsefi değer taşır.",
        "gerekce": ("Çünkü bir öykü, soyut bir ilkenin bir insanın hayatında nasıl sonuç "
                    "verdiğini gösterir."),
        "karsi": "Öykülerin kanıt değil kurmaca olduğu itiraz edilebilir.",
        "yanit": ("Ama öykü bir olguyu kanıtlamak için değil, bir düşünceyi sınamak için "
                  "kullanılır; bu da felsefenin işidir."),
    },
    {
        "alan": "hayatın anlamı",
        "soru": "Seferin anlamı yalnız hedefe ulaşmak mıdır?",
        "aktarimlar": (
            "Aristoteles'e göre insan hayatının amacı mutluluktur.",
            "Camus, hayatın kendiliğinden bir anlamı olmadığını, insanın bu saçmaya "
            "başkaldırarak yaşaması gerektiğini söyler.",
            "Nietzsche insanın kendi değerlerini yaratması gerektiğini savunur.",
        ),
        "tez": ("Seferin anlamı yalnız hedefe ulaşmak değil, yol boyunca birlikte "
                "üretilen emek ve öğrenmedir."),
        "gerekce": ("Çünkü hedefe ulaşılamasa bile ekibin öğrendikleri ve kurduğu "
                    "dayanışma geriye kalır."),
        "karsi": "Hedefe ulaşmayan bir seferin boşa gittiği itiraz edilebilir.",
        "yanit": ("Ama sonraki seferler bu seferin kayıtları ve deneyimiyle yola "
                  "çıkacağı için emek boşa gitmez."),
    },
    {
        "alan": "hukuk ve adalet",
        "soru": "Üssün ortak su kuralı adil mi olmalı: herkese eşit pay mı?",
        "aktarimlar": (
            "Aristoteles adaleti herkese hak ettiği ölçüde vermek olarak görür.",
            "Hobbes'a göre kurallar, herkesin herkese karşı savaşını önlemek için "
            "yapılan bir sözleşmeye dayanır.",
            "Rawls'a göre adil kurallar, kimin hangi konumda olacağını bilmeden "
            "seçilecek kurallardır.",
        ),
        "tez": "Ortak su kuralı temel ihtiyaçta eşit pay, ağır işte ek pay vermelidir.",
        "gerekce": ("Çünkü hayatta kalmak için gereken su kimsenin emeğine bağlanamaz, "
                    "ama ağır iş daha çok su harcatır."),
        "karsi": "Ek payın kötüye kullanılabileceği itiraz edilebilir.",
        "yanit": "Ama ek pay kayda geçen iş saatine bağlanırsa denetlenebilir.",
    },
    {
        "alan": "teknoloji",
        "soru": "Üssün erzak dağıtımı otomatik karar sistemine bırakılmalı mı?",
        "aktarimlar": (
            "Bacon bilginin güç olduğunu ve doğayı insanın hizmetine sokacağını savunur.",
            "Heidegger teknolojinin dünyayı yalnız kullanılacak bir kaynak gibi "
            "görmemize yol açtığını düşünür.",
            "Hans Jonas teknolojinin gücü arttıkça sorumluluğumuzun da gelecek "
            "kuşakları kapsayacak biçimde büyüdüğünü söyler.",
        ),
        "tez": "Otomatik sistem öneri vermeli, son kararı kurul vermelidir.",
        "gerekce": ("Çünkü sistem hızlı hesaplar ama beklenmedik durumları ve kişilerin "
                    "özel ihtiyaçlarını tartamaz."),
        "karsi": ("İnsan kararının sistemden daha yavaş ve taraflı olabileceği itiraz "
                  "edilebilir."),
        "yanit": ("Ama kurul sistemin önerisinden ancak gerekçesini yazarak ayrılabilirse "
                  "hem hız hem denetim korunur."),
    },
    {
        "alan": "çevre",
        "soru": "Üs yakındaki gölden sınırsız su çekebilir mi?",
        "aktarimlar": (
            "Aldo Leopold doğayı insanın parçası olduğu bir topluluk olarak görür.",
            "Peter Singer acı çekebilen her canlının çıkarının ahlaken hesaba "
            "katılması gerektiğini söyler.",
            "İnsan merkezci yaklaşıma göre doğa insanın ihtiyaçları için vardır.",
        ),
        "tez": "Üs gölden yalnız gölün yenilenebildiği kadar su çekmelidir.",
        "gerekce": ("Çünkü göl yalnız üssün değil, çevresindeki canlıların ve gelecekteki "
                    "seferlerin de su kaynağıdır."),
        "karsi": "Üssün ihtiyacı acil olduğunda sınırın hayati olabileceği itiraz edilebilir.",
        "yanit": "Ama göl tükenirse üssün kendisi de susuz kalır; sınır üssü de korur.",
    },
)
_KURUL_KAPANIS = "Görüldüğü gibi bu konuda farklı görüşler vardır."


@bulmaca(ders="felsefe", konu="hukuk_felsefesi_metin", kademeler=(10, 13), agirlik=1.3)
def kurul_metni(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Argüman: tez, gerekçe, karşı görüş, yanıt; düşünür görüşü ancak gerekçeye bağlanınca iş görür."""
    k = rastgele.choice(_KURUL_KONULARI)
    gerekcesiz_tez = rastgele.random() < 0.5
    if gerekcesiz_tez:
        taslak = list(rastgele.sample(k["aktarimlar"], 2)) + [k["tez"], _KURUL_KAPANIS]
    else:
        taslak = list(k["aktarimlar"]) + [_KURUL_KAPANIS]
    tez_gerekce = 1 if gerekcesiz_tez else 0
    arguman = [k["tez"], k["gerekce"], k["karsi"], k["yanit"]]
    havuz = arguman + list(k["aktarimlar"])
    rastgele.shuffle(havuz)
    arguman_ind = [n for n, c in enumerate(havuz) if c in arguman]
    sira_kar = list(arguman)
    rastgele.shuffle(sira_kar)
    dogru_sira = [sira_kar.index(c) for c in arguman]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fel-kurul-metni",
        ders="felsefe",
        baslik="Kurul Metni",
        kademe=kademe,
        konu="hukuk_felsefesi_metin",
        kazanim="Felsefi bir metinde tez, gerekçe, karşı görüş ve yanıtı ayırt etme; "
                "düşünür görüşlerini sıralamayı kendi argümanını kurmaktan ayırma; "
                "tezi gerekçeyle ilişkilendirerek metni sıraya koyma.",
        dikkat=7,
        brifing=(
            "Sefer kurulu {} üzerine bir soruyu tartışacak:\n\n  {}\n\n"
            "{} kurula sunulacak metni hazırladı ve şöyle dedi: \"Metnim hazır: "
            "düşünürlerin görüşlerini sıraladım, argüman budur.\"\n\n"
            "Metin kurula gitmeden önce içinde gerçekten bir argüman olup olmadığını "
            "incelememiz gerekiyor."
        ).format(k["alan"], k["soru"], kisi),
        kanitlar=[
            Kanit("Personelin taslağı", "\n".join(taslak), bedel=1, kritik=True),
            Kanit("Cümle havuzu", "\n".join(havuz), bedel=1, kritik=True),
            Kanit("Kurul yönergesi",
                  "Kurula sunulan metin bir tez koyar, onu gerekçeyle destekler, bir "
                  "karşı görüşü ele alır ve ona yanıt verir. Düşünür görüşleri ancak bir "
                  "gerekçeyi desteklemek için kullanılır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Felsefi bir metinde argüman kurmak ne demektir?",
                dogru="Tez koyup gerekçelerle desteklemek, karşı görüşü ele alıp yanıtlamak",
                yanlislar={
                    "Konuyla ilgili düşünürlerin görüşlerini sırayla aktarmak":
                        "Filozof görüşlerini sıralamayı kendi argümanını kurmak sandın. "
                        "Sıralama bir tez ya da gerekçe içermez.",
                    "Bir tez yazmak yeterlidir; gerekçe gerekmez":
                        "Tezi gerekçeyle ilişkilendirmedin; gerekçesiz tez yalnız bir "
                        "iddiadır.",
                    "Karşı görüşlerden hiç söz etmemek; karşı görüşü anmak okuru tezden uzaklaştırır":
                        "Karşı görüşü ele almak argümanı güçlendirir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Argüman, bir iddiayı gerekçelerle destekleyen düşünce yoludur. "
                    "Düşünürlerin görüşleri bu yolda bir gerekçeyi güçlendirebilir; ama "
                    "yalnız sıralandıklarında metin hiçbir şey savunmaz."
                ),
                ipuclari=[
                    "Personelin taslağında kendi görüşünü savunan bir cümle var mı?",
                    "Kurul yönergesi metinden neler istiyor?",
                ],
                cozum="Tez -> gerekçe -> karşı görüş -> yanıt",
            ),
            sayi_adimi(
                soru="Personelin taslağındaki {} cümleden kaç tanesi bir tez ya da "
                     "gerekçedir?".format(len(taslak)),
                cevap=tez_gerekce,
                aciklama=("Taslakta yalnız gerekçesiz bir tez var; öteki cümleler aktarım ve "
                          "genel bir kapanış." if gerekcesiz_tez else
                          "Taslakta ne tez ne gerekçe var; cümlelerin hepsi aktarım ya da "
                          "genel bir kapanış."),
                yaygin_yanlislar={
                    len(taslak):
                        "Filozof görüşlerini sıralamayı kendi argümanını kurmak sandın; "
                        "aktarımlar tez ya da gerekçe değildir.",
                },
                ipuclari=["\"... göre\", \"... savunur\" diye biten cümleler kimin görüşü?"],
                puan=10,
            ),
            coklu_adimi(
                soru="Cümle havuzundaki hangi cümleler kurul metninin argümanını oluşturur "
                     "(tez, gerekçe, karşı görüş, yanıt)? (numaraları virgülle yaz)",
                secenekler=havuz,
                dogru_indeksler=arguman_ind,
                aciklama="Tez, gerekçe, karşı görüş ve yanıt argümanı kurar; aktarımlar kendi başına kurmaz.",
                ipuclari=["Kendi görüşünü savunan ya da ona itiraz eden cümleleri seç."],
                puan=12,
            ),
            sirala_adimi(
                soru="Argümanın cümlelerini kurul metnindeki sıraya koy.",
                secenekler=sira_kar,
                dogru_sira=dogru_sira,
                aciklama="Önce tez, sonra onu destekleyen gerekçe, sonra karşı görüş ve ona yanıt.",
                ipuclari=["\"Çünkü\" ile başlayan cümle neyi destekliyor? \"Ama\" neye yanıt veriyor?"],
                puan=12,
            ),
            secim_adimi(
                soru="Düşünürlerin görüşleri kurul metninde nasıl kullanılmalı?",
                dogru="Kendi tezine bağlanan bir gerekçeyi desteklemek için",
                yanlislar={
                    "Metnin kendisi olarak; ne kadar çok görüş, o kadar güçlü argüman":
                        "Filozof görüşlerini sıralamayı kendi argümanını kurmak sandın.",
                    "Hiç kullanılmamalı, felsefe alıntıyla yapılmaz":
                        "Düşünürler gerekçeyi güçlendirebilir; sorun yalnız sıralanmaları.",
                    "Tezin yerine; tez yazmak yerine bir düşünürün sözü konmalı":
                        "Tezi gerekçeyle ilişkilendirmedin; tez senin iddiandır.",
                },
                rastgele=rastgele,
                aciklama=("Bir düşünürün görüşü, gerekçene bağlandığında argümanı güçlendirir; "
                          "tek başına sıralandığında metin bir şey savunmaz."),
                ipuclari=["Kurul yönergesinin son cümlesini oku."],
                puan=10,
            ),
        ],
        kapanis=("Metin düzeltildi: taslakta {} tez ya da gerekçe vardı; kurula tez, "
                 "gerekçe, karşı görüş ve yanıttan oluşan dört cümlelik bir argüman "
                 "sunuldu.").format(tez_gerekce),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# DÜŞÜNÜR DOSYASI: SÖZÜ TEKRAR ETMEK ARGÜMANI DEĞERLENDİRMEK DEĞİLDİR (B37.16)
#
# 2018 programının beş 11. sınıf satırı (Antik, Orta Çağ, Aydınlanma, Modern,
# Çağdaş dönem "argüman ve yazı") aynı yaygın yanlışı paylaşıyor:
#
#   "Düşünürün sözünü tekrar etmeyi argümanı değerlendirmek sanmak; kendi
#    görüşünü gerekçesiz bırakmak."
#
# DÜZENEK: her dönemden bir argüman öncül-sonuç biçiminde (Sokrates, Gazâlî,
# Locke, Bacon, Popper). Personelin "değerlendirme" notu sözü tekrar ediyor ve
# "Bence de doğru." diye bitiyor. Seferden bir olay argümanın bir öncülünü
# sınıyor; öğrenci öncülleri ayırır, olayın neyi sınadığını bulur ve gerekçeli
# görüşü seçer.
#
# ATIF DİKKATİ: argümanlar iyi yerleşmiş özetlerdir; doğrudan alıntı yok.
# ==========================================================================

_DUSUNUR_ARGUMANLARI = (
    {
        "donem": "Antik Çağ", "dusunur": "Sokrates",
        "onculler": ("Kimse bile bile kötülük yapmaz.",
                     "Kötülük yapan, neyin iyi olduğunu bilmiyordur."),
        "sonuc": "Erdem bilgidir; iyiyi bilen iyi davranır.",
        "tekrar": ("Sokrates'e göre erdem bilgidir.",
                   "Sokrates, iyiyi bilenin iyi davranacağını söyler.",
                   "Ona göre kimse bile bile kötülük yapmaz."),
        "olay": ("Depocu, erzakı gizlice almanın yanlış olduğunu bildiğini söyledi; ama "
                 "açlığa dayanamayıp aldı."),
        "sinama": "İyiyi bilmenin iyi davranmaya yetmediğini gösterir; ikinci öncülü sorgulatır",
        "gorus": ("Bilgi erdem için gerekli ama yeterli değildir; çünkü depocu bildiği iyiye "
                  "rağmen yanlış davrandı"),
    },
    {
        "donem": "Orta Çağ", "dusunur": "Gazâlî",
        "onculler": ("Duyular yanılabilir.",
                     "Aklın vardığı bazı sonuçlar da birbiriyle çelişebilir."),
        "sonuc": "Kesin bilgiye yalnız duyu ve akılla değil, iç sezgiyle ulaşılır.",
        "tekrar": ("Gazâlî'ye göre duyular yanılabilir.",
                   "Gazâlî kesin bilginin iç sezgiyle elde edildiğini söyler.",
                   "Ona göre akıl da bazen çelişkiye düşer."),
        "olay": ("İki gözcü aynı sezgiyle iki farklı yolu \"kesin doğru yol\" diye gösterdi; "
                 "hangisinin doğru olduğu ancak haritayla anlaşıldı."),
        "sinama": "Sezgilerin de çelişebildiğini gösterir; sonucun kesinlik iddiasını sorgulatır",
        "gorus": ("Sezgi tek başına kesinlik vermez; çünkü iki gözcünün sezgileri çelişti ve "
                  "ancak haritayla sınandı"),
    },
    {
        "donem": "Aydınlanma", "dusunur": "Locke",
        "onculler": ("Zihin doğuştan boş bir levhadır.",
                     "Zihne giren her düşünce duyular ve iç gözlem yoluyla gelir."),
        "sonuc": "Bütün bilgi deneyden gelir.",
        "tekrar": ("Locke'a göre zihin doğuştan boş bir levhadır.",
                   "Locke bütün bilginin deneyden geldiğini söyler.",
                   "Ona göre doğuştan düşünce yoktur."),
        "olay": ("Üsteki çocuklar hiçbir üçgeni ölçmeden, yalnız düşünerek her üçgenin iç "
                 "açılarının toplamının aynı olması gerektiğini gösterdi."),
        "sinama": "Ölçmeden kazanılan bir bilgi gösterir; sonucun \"bütün\" iddiasını sorgulatır",
        "gorus": ("Bilginin çoğu deneyden gelir ama bütünü değil; çünkü çocuklar üçgen "
                  "bilgisine ölçmeden ulaştı"),
    },
    {
        "donem": "Modern Çağ", "dusunur": "Francis Bacon",
        "onculler": ("Doğayı tanıyan onu kullanabilir.",
                     "Doğayı kullanabilen insan hayatını iyileştirir."),
        "sonuc": "Bilgi güçtür; bilim insanın doğa üzerindeki gücünü artırmalıdır.",
        "tekrar": ("Bacon'a göre bilgi güçtür.",
                   "Bacon bilimin insanın doğa üzerindeki gücünü artırması gerektiğini "
                   "söyler.",
                   "Ona göre doğayı tanıyan onu kullanabilir."),
        "olay": ("Üs yeni pompayla gölden daha çok su çekti; ertesi yaz göl çekildi ve "
                 "balıklar öldü."),
        "sinama": "Doğayı kullanmanın hayatı hep iyileştirmediğini gösterir; ikinci öncülü sorgulatır",
        "gorus": ("Bilgi güçtür ama güç kendiliğinden iyilik getirmez; çünkü pompa gölün "
                  "çekilmesine yol açtı"),
    },
    {
        "donem": "Çağdaş dönem", "dusunur": "Karl Popper",
        "onculler": ("Hiçbir sayıda gözlem genel bir önermeyi kesin olarak doğrulayamaz.",
                     "Tek bir karşı örnek genel bir önermeyi yanlışlayabilir."),
        "sonuc": "Bilimsel bir kuram yanlışlanabilir olmalı ve yanlışlanmaya çalışılarak sınanmalıdır.",
        "tekrar": ("Popper'a göre bilimsel kuram yanlışlanabilir olmalıdır.",
                   "Popper, tek bir karşı örneğin genel bir önermeyi yanlışlayabileceğini "
                   "söyler.",
                   "Ona göre gözlemler kuramı kesin doğrulayamaz."),
        "olay": ("Ölçümcü, kuramın öngörmediği bir sıcaklık okudu; ekip kuramı bırakmadan "
                 "önce termometreyi yeniden denetledi."),
        "sinama": "Gözlemin de hatalı olabileceğini gösterir; ikinci öncülün uygulanışını sorgulatır",
        "gorus": ("Yanlışlama bilimi güçlendirir ama tek gözlem hemen yetmez; çünkü termometre "
                  "de hatalı olabilir"),
    },
)
_DUSUNUR_ONAY = "Bence de doğru."


@bulmaca(ders="felsefe", konu="antik_arguman_ve_yazi", kademeler=(11, 13), agirlik=1.3)
def dusunur_dosyasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Argümanı değerlendirmek: öncülleri ayırmak, sınamak ve gerekçeli görüş bildirmek."""
    a = rastgele.choice(_DUSUNUR_ARGUMANLARI)
    itirazli = rastgele.random() < 0.5
    if itirazli:
        not_cumleleri = list(rastgele.sample(a["tekrar"], 2)) + [
            _DUSUNUR_ONAY, "Ama şu olay bir öncülü sorgulatıyor: " + a["olay"]]
    else:
        not_cumleleri = list(a["tekrar"]) + [_DUSUNUR_ONAY]
    degerlendirme = 1 if itirazli else 0
    parcalar = list(a["onculler"]) + [a["sonuc"]]
    rastgele.shuffle(parcalar)
    oncul_ind = [n for n, p in enumerate(parcalar) if p in a["onculler"]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fel-dusunur-dosyasi",
        ders="felsefe",
        baslik="Düşünür Dosyası",
        kademe=kademe,
        konu="antik_arguman_ve_yazi",
        kazanim="Bir düşünürün argümanını öncül ve sonuçlarına ayırma; argümanı bir "
                "karşı örnekle sınama; düşünürün sözünü tekrar etmek yerine gerekçeli "
                "bir görüş bildirme.",
        dikkat=7,
        brifing=(
            "Arşivin {} rafından bir argüman dosyası çıktı (düşünür: {}); kurul "
            "bir değerlendirme notu istiyor.\n\n"
            "{} notu yazdı ve şöyle dedi: \"Değerlendirmem hazır: düşünürün ne "
            "dediğini eksiksiz yazdım, sonuna da katıldığımı ekledim.\"\n\n"
            "Not kurula gitmeden önce gerçekten bir değerlendirme olup olmadığını "
            "incelememiz gerekiyor."
        ).format(a["donem"], a["dusunur"], kisi),
        kanitlar=[
            Kanit("Argüman dosyası", "\n".join(parcalar), bedel=1, kritik=True),
            Kanit("Personelin notu", "\n".join(not_cumleleri), bedel=1, kritik=True),
            Kanit("Sefer kaydı", a["olay"], bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir düşünürün argümanını değerlendirmek ne demektir?",
                dogru="Öncülleri ve çıkarımı sınayıp gerekçeli bir görüş bildirmek",
                yanlislar={
                    "Düşünürün sözünü eksiksiz tekrar etmek; doğru aktarmak değerlendirmenin kendisidir":
                        "Düşünürün sözünü tekrar etmeyi argümanı değerlendirmek sandın.",
                    "Düşünür ünlü olduğu için argümanı doğru kabul etmek":
                        "Ün bir gerekçe değildir; argüman kendi öncülleriyle sınanır.",
                    "\"Katılıyorum\" ya da \"katılmıyorum\" demek yeterlidir":
                        "Kendi görüşünü gerekçesiz bıraktın; görüş gerekçeyle değer kazanır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Değerlendirme, argümanın içine girmektir: hangi öncüllere dayanıyor, "
                    "sonuç onlardan çıkıyor mu, öncüller bir örnekle sınanınca ayakta "
                    "kalıyor mu? Ardından kendi görüşünü gerekçesiyle söylersin."
                ),
                ipuclari=[
                    "Personelin notunda düşünürün söylemediği bir şey var mı?",
                    "\"Bence de doğru\" bir gerekçe mi?",
                ],
                cozum="Öncüller -> sonuç -> sınama (örnek) -> gerekçeli görüş",
            ),
            coklu_adimi(
                soru="Dosyadaki cümlelerden hangileri argümanın öncülüdür? "
                     "(numaraları virgülle yaz)",
                secenekler=parcalar,
                dogru_indeksler=oncul_ind,
                aciklama="Sonuç: {}".format(a["sonuc"]),
                ipuclari=["Hangi cümle ötekilerden çıkarılıyor? O sonuçtur."],
                puan=12,
            ),
            sayi_adimi(
                soru="Personelin notundaki {} cümleden kaç tanesi sözü tekrar etmenin ya da "
                     "gerekçesiz onayın ötesinde bir değerlendirmedir?".format(len(not_cumleleri)),
                cevap=degerlendirme,
                aciklama=("Yalnız son cümle bir öncülü bir olayla sınıyor."
                          if itirazli else
                          "Hiçbiri: cümleler sözü tekrar ediyor, sonuncusu gerekçesiz bir onay."),
                yaygin_yanlislar={
                    len(not_cumleleri):
                        "Düşünürün sözünü tekrar etmeyi argümanı değerlendirmek sandın.",
                },
                ipuclari=["\"... göre\" ve \"... söyler\" cümleleri kimin düşüncesi?"],
                puan=10,
            ),
            secim_adimi(
                soru="Sefer kaydındaki olay argümanı nasıl sınar?",
                dogru=a["sinama"][:1].upper() + a["sinama"][1:],
                yanlislar={
                    "Hiç sınamaz; {} gibi bir düşünür söylediyse tek bir olay önemsizdir".format(a["dusunur"]):
                        "Düşünürün sözünü tekrar etmeyi argümanı değerlendirmek sandın; "
                        "argüman örneklerle sınanır.",
                    "Olay argümanı kesin olarak kanıtlar; aynı konudan söz eden her örnek argümanı destekler":
                        "Olay argümanı desteklemiyor; bir öncülünü sorgulatıyor.",
                },
                rastgele=rastgele,
                aciklama="Bir karşı örnek, argümanın bir öncülünü ya da sonucun kapsamını sorgulatır.",
                ipuclari=["Olay, öncüllerden hangisiyle çatışıyor?"],
                puan=10,
            ),
            yorum_adimi(
                soru="Kurula sunulacak gerekçeli görüş hangisidir?",
                dogru=a["gorus"],
                yanlislar={
                    ("{} haklıdır, çünkü {} böyle söylemiştir; tarihe geçmiş, herkesçe saygı gören bir düşünür "
                     "yanılmaz").format(a["dusunur"], a["dusunur"]):
                        "Düşünürün sözünü tekrar etmeyi argümanı değerlendirmek sandın; "
                        "bu bir gerekçe değil.",
                    "Bence yanlış.":
                        "Kendi görüşünü gerekçesiz bıraktın.",
                },
                rastgele=rastgele,
                aciklama="Gerekçeli görüş bir iddia koyar ve \"çünkü\" ile bir örneğe dayanır.",
                ipuclari=["\"Çünkü\" içeren ve olaya dayanan cümleyi ara."],
                puan=12,
            ),
        ],
        kapanis=("Not düzeltildi: taslakta {} değerlendirme cümlesi vardı; kurula "
                 "öncülleri sınanmış ve gerekçeli bir görüş sunuldu.").format(degerlendirme),
        odul={"itibar": 5, "cevher": 2},
    )


# ==========================================================================
# PAYLAŞIM TARTIŞMASI: MİKTAR SORUSUNDAN FELSEFİ SORUYA (B37.16)
#
# `felsefi_soru_uretimi` tek satırlıktı (2018: 10). Bağlam: "Depodaki paylaşım
# tartışmasını yalnız miktar sorusundan adalet hakkında felsefi soruya
# dönüştürme". `yaygin_yanlis`:
#
#   "Sonucun doğru olmasını çıkarımın geçerli olmasıyla karıştırmak; kişiye
#    saldırıyı kanıt saymak."
#
# DÜZENEK: depo tutanağı. Miktar soruları hesapla yanıtlanır (kişi başı pay);
# felsefi sorular adalet ve hakkı sorgular. Tutanakta bir geçersiz çıkarım
# (sonucu doğru olsa bile) ve kişiye yönelik itirazlar var.
#
# YANILGININ SAYISAL KARŞILIĞI: kişiye yönelik itiraz sayısını 0 saymak
# (hepsini öneriye karşı kanıt sanmak).
# ==========================================================================

_PAYLASIM_SORULARI = (
    ("Depoda kaç kilo un var?", False),
    ("Un eşit bölünürse kişi başı kaç kilo düşer?", False),
    ("Un kaç gün yeter?", False),
    ("Adil paylaşım her zaman eşit paylaşım mıdır?", True),
    ("Pay ihtiyaca göre mi, emeğe göre mi belirlenmeli?", True),
    ("Ortak bir kaynak üzerinde kimin ne hakkı vardır?", True),
)
# (itiraz, kişiye yönelik mi)
_PAYLASIM_ITIRAZLARI = (
    ("Öneriyi yapan kişi geçen ay nöbeti kaçırdı; o hâlde önerisi yanlıştır.", True),
    ("Bu öneriyi getiren üsse daha yeni geldi; paylaşımdan ne anlar?", True),
    ("Öneri sahibi de ek pay alacak; bu yüzden öneri yanlıştır.", True),
    ("Ek pay ağır işe bağlanırsa kimin ağır iş yaptığı kayda geçmeli; yoksa pay "
     "denetlenemez.", False),
    ("Hastalara ek pay verilirse un daha erken biter; ek pay miktarı sınırlanmalı.", False),
)


@bulmaca(ders="felsefe", konu="felsefi_soru_uretimi", kademeler=(10, 13), agirlik=1.2)
def paylasim_tartismasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Miktar sorusu hesapla, felsefi soru gerekçeyle yanıtlanır; geçerlilik ve kişiye saldırı."""
    un = rastgele.choice((96, 120, 144))
    kisi_sayisi = rastgele.choice((8, 12))
    pay = un // kisi_sayisi
    sorular = list(_PAYLASIM_SORULARI)
    rastgele.shuffle(sorular)
    soru_metinleri = [s for s, _ in sorular]
    felsefi = [n for n, (_, f) in enumerate(sorular) if f]
    kisiye = [i for i in _PAYLASIM_ITIRAZLARI if i[1]]
    oneriye = [i for i in _PAYLASIM_ITIRAZLARI if not i[1]]
    kac_kisiye = rastgele.choice((1, 2))
    itirazlar = rastgele.sample(kisiye, kac_kisiye) + rastgele.sample(oneriye, 3 - kac_kisiye)
    rastgele.shuffle(itirazlar)
    kisi, ornek_kisi = ad_sec(rastgele, PERSONEL, 2)

    return Bulmaca(
        kod="fel-paylasim-tartismasi",
        ders="felsefe",
        baslik="Paylaşım Tartışması",
        kademe=kademe,
        konu="felsefi_soru_uretimi",
        kazanim="Bir paylaşım tartışmasını miktar sorusundan adalet hakkında felsefi "
                "soruya dönüştürme; çıkarımın geçerliliğini sonucun doğruluğundan "
                "ayırma; kişiye yönelik itirazı kanıt saymama.",
        dikkat=7,
        brifing=(
            "Depoda {} kilo un var; {} kişi arasında paylaştırılacak ve hastalara ek "
            "pay önerisi tartışılıyor.\n\n"
            "{} tutanağa şunu yazdı: \"Tartışacak bir şey yok: unu kişi sayısına "
            "bölersek iş biter. Zaten öneriye yapılan itirazların hepsi haklı; öneriyi "
            "yapan kişinin geçmişine bakmak yeter.\"\n\n"
            "Tutanak kurula gitmeden önce hangi soruların hesapla, hangilerinin "
            "gerekçeyle yanıtlanacağını ayırmamız gerekiyor."
        ).format(un, kisi_sayisi, kisi),
        kanitlar=[
            Kanit("Tutanaktaki sorular", "\n".join(soru_metinleri), bedel=1, kritik=True),
            Kanit("Tutanaktaki itirazlar", "\n".join(i for i, _ in itirazlar), bedel=1, kritik=True),
            Kanit("Tutanaktaki çıkarım",
                  "\"Bütün yorgun personel ek pay almalı. {} ek pay aldı. O hâlde {} "
                  "yorgundu.\" (Kayıtlara göre {} gerçekten yorgundu.)".format(ornek_kisi, ornek_kisi, ornek_kisi),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Miktar sorusu ile felsefi soru arasındaki fark nedir?",
                dogru="Miktar sorusu hesapla yanıtlanır; felsefi soru adalet gibi kavramları sorgular",
                yanlislar={
                    "Fark yoktur; her soru sonunda bir hesapla çözülür":
                        "Unu bölmek kişi başı payı verir ama o payın adil olup olmadığını "
                        "söylemez.",
                    "Felsefi soru daha büyük sayılar içeren sorudur; hesap zorlaştıkça soru felsefileşir":
                        "Felsefi soruyu ayıran sayı değil, sorguladığı kavramdır.",
                    "Felsefi sorunun cevabı, soranın kim olduğuna göre belirlenir":
                        "Kişiye saldırıyı kanıt saydın; cevap gerekçelere göre belirlenir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Kişi başı kaç kilo?\" sorusunun tek bir doğru cevabı vardır. \"Adil "
                    "pay nedir?\" sorusu ise eşitlik, ihtiyaç ve emek gibi kavramların "
                    "tartışılmasını ister; cevabın gücü gerekçelerinden gelir."
                ),
                ipuclari=[
                    "Hangi soruları bir terazi ve hesap makinesiyle yanıtlayabilirsin?",
                    "Hangi sorular \"adil\", \"hak\" gibi kavramlar içeriyor?",
                ],
                cozum="Miktar: hesapla. Felsefi: kavramı sorgula, gerekçe ver.",
            ),
            coklu_adimi(
                soru="Tutanaktaki sorulardan hangileri felsefi sorudur? (numaraları virgülle yaz)",
                secenekler=soru_metinleri,
                dogru_indeksler=felsefi,
                aciklama="Adalet, eşitlik, ihtiyaç, emek ve hak kavramlarını sorgulayan sorular felsefidir.",
                ipuclari=["Cevabı bir sayı olmayan soruları ara."],
                puan=12,
            ),
            sayi_adimi(
                soru="Un eşit bölünürse kişi başı kaç kilo düşer?",
                cevap=pay,
                birim="kg",
                aciklama=("{} ÷ {} = {} kg. Bu miktar sorusunun cevabıdır; payın adil olup "
                          "olmadığını söylemez.").format(un, kisi_sayisi, pay),
                ipuclari=["Un miktarını kişi sayısına böl."],
                puan=8,
            ),
            secim_adimi(
                soru="Tutanaktaki çıkarım için hangisi doğrudur?",
                dogru="Geçersizdir: sonuç öncüllerden zorunlu olarak çıkmaz",
                yanlislar={
                    "Geçerlidir, çünkü sonucu gerçekten doğru":
                        "Sonucun doğru olmasını çıkarımın geçerli olmasıyla karıştırdın. "
                        "Hasta biri de ek pay almış olabilir.",
                    "Geçerlidir, çünkü öncüller doğru ve sonuç onlardan sonra geliyor":
                        "Öncüller doğru olsa bile sonuç onlardan zorunlu olarak çıkmıyor.",
                    "Değerlendirilemez; çünkü kişiyle ilgilidir":
                        "Çıkarımın biçimi kişiden bağımsız incelenebilir.",
                },
                rastgele=rastgele,
                aciklama=("\"Yorgun olan ek pay alır\" demek, \"ek pay alan yorgundur\" demek "
                          "değildir: ek pay hastalar gibi başka nedenlerle de alınabilir."),
                ipuclari=["Ek pay almanın başka bir nedeni olabilir mi?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Tutanaktaki üç itirazdan kaç tanesi önerinin gerekçesine değil, "
                     "öneriyi yapan kişiye yöneliktir?",
                cevap=kac_kisiye,
                aciklama="Kişiye yönelik: {}".format(" / ".join(i for i, k in itirazlar if k)),
                yaygin_yanlislar={
                    0:
                        "Kişiye saldırıyı kanıt saydın; öneri sahibinin geçmişi önerinin "
                        "doğruluğunu göstermez.",
                },
                ipuclari=["Hangi itiraz önerinin kendisinden değil, öneriyi yapandan söz ediyor?"],
                puan=10,
            ),
        ],
        kapanis=("Tutanak düzeltildi: kişi başı {} kg hesapla bulundu; \"adil pay nedir?\" "
                 "sorusu kurulda gerekçelerle tartışılacak. {} kişiye yönelik itiraz "
                 "kanıt sayılmadı.").format(pay, kac_kisiye),
        odul={"itibar": 4, "erzak": 2},
    )


# ==========================================================================
# DÜŞÜNÜR HARİTASI: COĞRAFYA GÖRÜŞÜN TEK NEDENİ DEĞİLDİR (B37.16)
#
# `filozof_cografyalari` tek satırlıktı (2018: 11). Bağlam: "Sefer arşivindeki
# düşünür kayıtlarını kaynaklarıyla dünya ve Türkiye haritasına yerleştirme".
# `yaygin_yanlis`:
#
#   "Filozofun yaşadığı coğrafyayı görüşünün tek nedeni saymak; görevi
#    isim-yer ezberine indirgemek."
#
# DÜZENEK: 20. yüzyıl düşünür kartları. Her düşünür birden çok şehirde yaşadı
# (göç, eğitim, sürgün); aynı şehirde yaşayanlar farklı görüşler savundu
# (Viyana: Popper ve Wittgenstein; Paris: Sartre, Arendt, Topçu). Görüşü
# okumalar, hocalar ve yaşanan olaylar da biçimlendirdi.
#
# YANILGININ SAYISAL KARŞILIĞI: bir düşünüre tek şehir yazmak (1).
# ==========================================================================

# (ad, yaşadığı şehirler sırayla, görüş, etki)
_DUSUNUR_KARTLARI = (
    ("Karl Popper", ("Viyana", "Christchurch", "Londra"),
     "Bilimsel kuramlar yanlışlanabilir olmalıdır.",
     "Einstein'ın riskli öngörülerini, her şeyi açıklayan iddialarla karşılaştırdı."),
    ("Ludwig Wittgenstein", ("Viyana", "Cambridge"),
     "Felsefi sorunların çoğu dilin yanlış kullanımından doğar.",
     "Cambridge'de Russell ile mantık çalıştı."),
    ("Hannah Arendt", ("Königsberg", "Paris", "New York"),
     "Kötülük, sıradan insanların düşünmeden itaat etmesinden de doğabilir.",
     "Nazi Almanyası'ndan kaçtı; Eichmann davasını izledi."),
    ("Jean-Paul Sartre", ("Paris", "Berlin"),
     "Varoluş özden önce gelir; insan kendini seçimleriyle yapar.",
     "Berlin'de Husserl'in fenomenolojisini inceledi."),
    ("Nurettin Topçu", ("İstanbul", "Strazburg", "Paris"),
     "Ahlaki eylem, kişinin kendi iradesiyle kötülüğe başkaldırmasıdır.",
     "Fransa'da Blondel'in hareket felsefesini okudu."),
    ("Edward Said", ("Kudüs", "Kahire", "New York"),
     "Batı'nın Doğu hakkında ürettiği bilgi çoğu zaman gücün aracı olmuştur.",
     "Foucault'nun bilgi ile iktidar üzerine çalışmalarını okudu."),
)


@bulmaca(ders="felsefe", konu="filozof_cografyalari", kademeler=(11, 13), agirlik=1.2)
def dusunur_haritasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Düşünürün coğrafyası görüşünün etkenlerinden biridir; tek nedeni değildir."""
    sehir = rastgele.choice(("Viyana", "Paris"))
    orada = [d for d in _DUSUNUR_KARTLARI if sehir in d[1]]
    diger = [d for d in _DUSUNUR_KARTLARI if sehir not in d[1]]
    kartlar = rastgele.sample(orada, 2) + rastgele.sample(diger, 2)
    rastgele.shuffle(kartlar)
    adlar = [d[0] for d in kartlar]
    orada_ind = [n for n, d in enumerate(kartlar) if sehir in d[1]]
    odak = rastgele.choice(kartlar)
    sehir_sayisi = len(set(odak[1]))
    ikili = [d for d in kartlar if sehir in d[1]]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fel-dusunur-haritasi",
        ders="felsefe",
        baslik="Düşünür Haritası",
        kademe=kademe,
        konu="filozof_cografyalari",
        kazanim="20. yüzyıl düşünürlerini yaşadıkları coğrafyalarla kaynaklı olarak "
                "haritaya yerleştirme; coğrafyayı görüşün tek nedeni saymama; aynı "
                "şehirde farklı, farklı şehirlerde benzer görüşlerin doğabildiğini gösterme.",
        dikkat=7,
        brifing=(
            "Sefer arşivindeki düşünür kartları dünya haritasına yerleştirilecek.\n\n"
            "{} haritaya her düşünür için tek bir iğne batırdı ve not düştü: \"Her "
            "düşünürün görüşü yaşadığı şehirden doğar. Bir isim, bir şehir: harita "
            "bu kadar.\"\n\n"
            "Harita asılmadan önce kartları kaynaklarıyla incelememiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Düşünür kartları",
                  "\n".join("{}: {} | Görüş: {} | Etki: {}".format(
                      d[0], " -> ".join(d[1]), d[2], d[3]) for d in kartlar),
                  bedel=1, kritik=True),
            Kanit("Arşiv notu",
                  "Bir düşünürün görüşünü yaşadığı yer kadar okudukları, hocaları, "
                  "tartıştığı kişiler ve tanık olduğu olaylar da biçimlendirir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir düşünürün yaşadığı coğrafya görüşü için ne ifade eder?",
                dogru="Etkenlerden biridir; okumalar, hocalar ve olaylarla birlikte ele alınır",
                yanlislar={
                    "Görüşünün tek nedenidir; düşünür yaşadığı toplumun sesidir":
                        "Filozofun yaşadığı coğrafyayı görüşünün tek nedeni saydın. "
                        "Kartlardaki etkiler okuma ve olaylardan da söz ediyor.",
                    "Hiçbir önemi yoktur; akıl her yerde aynı çalıştığı için düşünceler yerden bağımsızdır":
                        "Arendt'in göçü ya da Sartre'ın Berlin'deki okumaları gibi yer "
                        "değiştirmeler görüşleri etkiledi.",
                    "Her düşünür yalnız doğduğu şehirde yaşar ve çalışır":
                        "Kartlardaki düşünürlerin hepsi birden çok şehirde yaşadı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Coğrafya bir düşünürün karşılaştığı sorunları ve olanakları "
                    "belirleyebilir; ama aynı şehir farklı düşünürler, farklı şehirler "
                    "benzer sorular doğurabilir. Görüşü açıklamak için etkilerin hepsine "
                    "bakılır."
                ),
                ipuclari=[
                    "Kartlarda düşünürlerin kaç şehri var?",
                    "Etki bölümünde yer dışında neler yazıyor?",
                ],
                cozum="Harita: her düşünür için bütün şehirler + görüş + etki",
            ),
            sayi_adimi(
                soru="Karta göre {} kaç farklı şehirde yaşadı?".format(odak[0]),
                cevap=sehir_sayisi,
                aciklama="{}: {}.".format(odak[0], ", ".join(odak[1])),
                yaygin_yanlislar={
                    1:
                        "Görevi isim-yer ezberine indirgedin: bir isme bir şehir yazdın.",
                },
                ipuclari=["Karttaki oklarla bağlanan şehirleri say."],
                puan=10,
            ),
            coklu_adimi(
                soru="Hangi düşünürler hayatlarının bir döneminde {} şehrinde yaşadı? "
                     "(numaraları virgülle yaz)".format(sehir),
                secenekler=adlar,
                dogru_indeksler=orada_ind,
                aciklama="{} şehrinde yaşayanlar: {}.".format(sehir, ", ".join(d[0] for d in ikili)),
                ipuclari=["Her kartın şehir listesine bak."],
                puan=12,
            ),
            secim_adimi(
                soru="{} ile {} aynı şehirde yaşadı. Görüşleri için hangisi doğrudur?".format(
                    ikili[0][0], ikili[1][0]),
                dogru="Farklı görüşler savundular; görüşleri okumalar ve tartışmalarla biçimlendi",
                yanlislar={
                    "Aynı şehirde yaşadıkları için aynı görüşü savundular; aynı ortam aynı düşünceyi doğurur":
                        "Filozofun yaşadığı coğrafyayı görüşünün tek nedeni saydın; "
                        "kartlardaki görüşler farklı.",
                    "Hiçbir zaman aynı şehirde bulunmadılar":
                        "Kartlarda ikisinin de şehir listesinde {} var.".format(sehir),
                },
                rastgele=rastgele,
                aciklama="Görüşler: {} / {}".format(ikili[0][2], ikili[1][2]),
                ipuclari=["İki kartın görüş bölümünü karşılaştır."],
                puan=10,
            ),
            yorum_adimi(
                soru="{} görüşünü açıklarken hangisi kartlara uygundur?".format(odak[0]),
                dogru="Şu etki de önemlidir: {}".format(odak[3].rstrip(".")),
                yanlislar={
                    "Görüşü yalnız {} şehrinin ürünüdür: düşünceyi yer belirler".format(odak[1][0]):
                        "Filozofun yaşadığı coğrafyayı görüşünün tek nedeni saydın.",
                    "Görüşün yeriyle ya da okumalarıyla hiçbir ilgisi yoktur; düşünce yalnız aklın ürünüdür":
                        "Kartta görüşü etkileyen bir okuma ya da olay yazıyor.",
                },
                rastgele=rastgele,
                aciklama="Karttaki etki: {}".format(odak[3]),
                ipuclari=["Kartın etki bölümünü oku."],
                puan=10,
            ),
        ],
        kapanis=("Harita düzeltildi: her düşünür bütün şehirleriyle, görüşü ve etkileriyle "
                 "yerleştirildi; {} {} şehirle haritada."
                 ).format(odak[0], sehir_sayisi),
        odul={"itibar": 4, "cevher": 2},
    )
