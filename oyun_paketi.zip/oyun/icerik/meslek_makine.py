# -*- coding: utf-8 -*-
"""
Makine ve Tasarım görevleri.

Görevlerin çoğu "güç, iş ve verim" çekirdeğine bağlıdır; aynı çekirdek
elektrik dalında da işler. Makineci gücü moment ve devirle, elektrikçi gerilim
ve akımla ölçer - ikisi aynı büyüklüğe iki dilden bakar. İttifak mekaniğinin
dayandığı yer burasıdır. Ayrıntı: TASARIM_NOTLARI.md

Kademe ölçeği: 1-4 ilkokul, 5-8 ortaokul, 9-12 lise, 13 üniversite.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi,
    sy, yorum_adimi,
)

# P(kW) = M(Nm) x n(dev/dak) / KATSAYI
KATSAYI = 9550


# ==========================================================================
# MOMENT VE DEVİR
# ==========================================================================

@bulmaca(ders="makine", konu="moment_devir", kademeler=(10, 13),
         etiketler=("guc_verim",), agirlik=1.2)
def vinc_gucu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    P = M x n / 9550.

    Katsayıyı atlayan öğrenci bin kat büyük bir sayı bulur ve bunu fark
    etmezse "vinç için 47 bin kW motor" gibi bir sonucu kâğıda yazar.
    """
    devir = rastgele.choice([955, 1910])
    guc_kw = rastgele.choice([3, 4, 5, 6, 8])
    moment = KATSAYI * guc_kw // devir          # 955 -> 10P, 1910 -> 5P
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mak-vinc-gucu",
        ders="makine",
        baslik="Ağır Yük",
        kademe=kademe,
        konu="moment_devir",
        kazanim="Döner harekette güç, moment ve devir ilişkisi; "
                "P = M × n / 9550.",
        dikkat=6,
        brifing=(
            "Depo vinci yenilenecek. Eski vincin motoru yandı ve plakası "
            "okunmuyor; yerine ne alınacağı belli değil.\n\n"
            "{} vinci sökmeden önce iki ölçüm almış: mil {} Nm moment "
            "taşıyor ve dakikada {} devir dönüyor.\n\n"
            "Satın alma listesine yazılacak tek bir sayı var: motorun kaç "
            "kilovat olması gerektiği. Ölçümler moment ve devir cinsinden; "
            "liste ise kilovat istiyor."
        ).format(kisi, moment, devir),
        kanitlar=[
            Kanit("Mil ölçümü",
                  "Moment: {} Nm. Devir: {} dev/dak.".format(moment, devir),
                  bedel=1, kritik=True),
            Kanit("Makine el kitabı",
                  "\"Döner harekette güç: P (kW) = M (Nm) × n (dev/dak) ÷ "
                  "9550. Katsayı, dakikayı saniyeye ve watt'ı kilovata "
                  "çeviren sabittir.\"",
                  bedel=2, kritik=True),
            Kanit("Eski fatura",
                  "Bir önceki motor 10 yıl önce alınmış; fiyat yazıyor, güç "
                  "yazmıyor.", bedel=1),
            Kanit("Depo şefi",
                  "\"Elimizde 3, 4, 5, 6 ve 8 kW motorlar var. Ara değer "
                  "yok.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Motorun gücünü hangi bağıntı verir?",
                dogru="Momenti devirle çarpar, 9550'ye böleriz.",
                yanlislar={
                    "Momenti devire böleriz.":
                        "Bölme burada küçülen bir sayı verir. Oysa aynı "
                        "momentte daha hızlı dönen mil DAHA çok güç ister; "
                        "moment ile devir birlikte artar.",
                    "Momenti devirle çarparız, başka işlem yapmayız.":
                        "Katsayıyı atladın. Çarpımın birimi Nm × dev/dak; bu "
                        "kilovat değil. 9550'ye bölmeden sonuç bin kat büyük "
                        "çıkar.",
                    "Devri momente böleriz.":
                        "Bölmeyi ters kurdun; çıkan sayı ne güç ne de başka "
                        "bir anlamlı büyüklük olur.",
                    "Momenti 9550 ile çarparız.":
                        "9550 bölen bir katsayıdır, çarpan değil. Ayrıca "
                        "devir hesaba hiç girmemiş olur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Döner harekette güç hem kuvvetin kolu (moment) hem de "
                    "hızın (devir) çarpımıyla artar. 9550 katsayısı birimleri "
                    "kilovata çevirir: {} × {} ÷ 9550 = {} kW.".format(
                        moment, devir, guc_kw)),
                ipuclari=[
                    "Aynı momentte iki kat hızlı dönen mil, iki kat mı iş "
                    "yapar yoksa yarısı mı?",
                    "El kitabındaki katsayı ne işe yarıyor?",
                ],
                cozum=(
                    "1) M × n = {} × {} = {}\n"
                    "2) P = {} ÷ 9550 = {} kW".format(
                        moment, devir, moment * devir, moment * devir,
                        guc_kw)),
            ),
            sayi_adimi(
                soru="Motor kaç kilovat olmalı?",
                cevap=guc_kw,
                birim="kW",
                aciklama="{} × {} ÷ 9550 = {} kW".format(
                    moment, devir, guc_kw),
                yaygin_yanlislar={
                    moment * devir:
                        "9550'ye bölmeyi atladın. Bulduğun sayı kilovat "
                        "değil; bu değerde bir motor hiçbir depoda yok.",
                    round(moment / float(devir), 4):
                        "Momenti devire böldün. Çarpman gerekiyordu: hız "
                        "arttıkça gereken güç de artar.",
                    guc_kw * 10:
                        "Katsayıyı 955 olarak almış olabilirsin; el kitabında "
                        "9550 yazıyor.",
                },
                ipuclari=["Önce moment ile devri çarp, sonra katsayıya böl."],
                puan=14,
            ),
            yorum_adimi(
                soru="Vinç yarı devirle çalıştırılırsa aynı yükü kaldırmak "
                     "için moment ne olmalı?",
                dogru="İki katına çıkmalı.",
                yanlislar={
                    "Yarıya inmeli.":
                        "Devir ile momenti aynı yöne bağladın. Güç sabitken "
                        "biri düşerse öteki yükselir; ikisi ters orantılıdır.",
                    "Değişmemeli.":
                        "Devir yarıya inerken moment sabit kalırsa güç de "
                        "yarıya iner; o zaman aynı yük kaldırılamaz.",
                    "Dört katına çıkmalı.":
                        "İlişki doğrusal: devir yarıya inince moment iki kat "
                        "olur, dört kat değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "P = M × n ÷ 9550 bağıntısında güç sabit tutulursa moment "
                    "ile devir ters orantılıdır. Vinçlerde ağır yük bu yüzden "
                    "yavaş kaldırılır."),
            ),
        ],
        kapanis=("Listeye {} kW yazıldı. Depo şefi \"ara değer yok\" dediği "
                 "için hesabın tam çıkması işe yaradı.".format(guc_kw)),
        odul={"cevher": 3, "itibar": 2},
    )


# ==========================================================================
# DİŞLİ ORANI
# ==========================================================================

@bulmaca(ders="makine", konu="disli_orani", kademeler=(9, 12),
         etiketler=("oran_olcek",), agirlik=1.2)
def disli_kutusu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Dişli kutusunda devir düşerken moment artar.

    En sık hata ikisini aynı yöne çevirmek: "devir üçte bire indi, moment de
    üçte bire iner" diyen öğrenci makineyi hiç kaldıramayacak şekilde seçer.
    """
    kucuk_dis = rastgele.choice([15, 20, 25])
    oran = rastgele.choice([2, 3, 4])
    buyuk_dis = kucuk_dis * oran
    cikis_devri = rastgele.choice([150, 200, 250, 300])
    giris_devri = cikis_devri * oran
    giris_moment = rastgele.choice([12, 15, 18, 24])
    cikis_moment = giris_moment * oran
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="mak-disli-kutusu",
        ders="makine",
        baslik="Yavaşlayan Mil",
        kademe=kademe,
        konu="disli_orani",
        kazanim="Dişli oranı; devir ile momentin ters orantısı.",
        dikkat=5,
        brifing=(
            "{} mevkiindeki değirmenin taşı çok hızlı dönüyor ve unu "
            "yakıyor. Motor değiştirilmeyecek; araya bir dişli kutusu "
            "konacak.\n\n"
            "Motor mili dakikada {} devir dönüyor ve {} Nm moment veriyor. "
            "Kutuya {} dişli bir küçük çark ile {} dişli bir büyük çark "
            "takıldı.\n\n"
            "Taşın yeni devri ve ona binecek moment hesaplanmadan kutu "
            "bağlanmayacak; yanlış moment mili büker."
        ).format(mevki, giris_devri, giris_moment, kucuk_dis, buyuk_dis),
        kanitlar=[
            Kanit("Motor mili",
                  "Devir: {} dev/dak. Moment: {} Nm.".format(
                      giris_devri, giris_moment),
                  bedel=1, kritik=True),
            Kanit("Dişli kutusu",
                  "Motor tarafındaki çark {} dişli, taş tarafındaki çark {} "
                  "dişli.".format(kucuk_dis, buyuk_dis),
                  bedel=1, kritik=True),
            Kanit("Atölye kuralı",
                  "\"Küçük çarktan büyük çarka geçilirken devir düşer, moment "
                  "aynı oranda ARTAR. Dişli kutusu güç üretmez, gücü başka "
                  "biçimde dağıtır.\"",
                  bedel=2, kritik=True),
            Kanit("Taş bilgisi",
                  "Değirmen taşı en çok {} Nm momente dayanır.".format(
                      cikis_moment + rastgele.choice([6, 12, 18])),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Dişli kutusundan sonra devir ve moment nasıl değişir?",
                dogru="Devir oran kadar düşer, moment o oranda artar.",
                yanlislar={
                    "İkisi de dişli oranı kadar düşer; yavaşlayan mil zayıflar.":
                        "Devir ile momenti aynı yöne çevirdin. İkisi birden "
                        "düşseydi güç de düşerdi; oysa dişli kutusu güç "
                        "kaybetmek için değil, gücü başka biçimde vermek için "
                        "var.",
                    "İkisi de dişli oranı kadar artar.":
                        "İkisi birden artsaydı kutu güç üretiyor olurdu. Bir "
                        "dişli kutusu güç üretemez.",
                    "Devir artar, moment düşer; büyük çark küçükten hızlı döner.":
                        "Yönü ters aldın. Küçük çarktan BÜYÜK çarka "
                        "geçiliyor; büyük çark daha yavaş döner.",
                    "Devir düşer, moment değişmez.":
                        "Moment sabit kalsaydı güç, devirle birlikte düşerdi. "
                        "Kutu gücü korur; moment artarak devrin düşüşünü "
                        "dengeler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Dişli oranı = {} ÷ {} = {}. Devir {} ÷ {} = {} dev/dak'ya "
                    "düşer; moment {} × {} = {} Nm'ye çıkar. Güç iki tarafta "
                    "da aynı kalır.".format(
                        buyuk_dis, kucuk_dis, oran, giris_devri, oran,
                        cikis_devri, giris_moment, oran, cikis_moment)),
                ipuclari=[
                    "Büyük çark bir tur atarken küçük çark kaç tur atar?",
                    "Kutu güç üretmiyorsa, devir düşünce ne yükselmeli?",
                ],
                cozum=(
                    "1) Oran = {} ÷ {} = {}\n"
                    "2) Çıkış devri = {} ÷ {} = {} dev/dak\n"
                    "3) Çıkış momenti = {} × {} = {} Nm".format(
                        buyuk_dis, kucuk_dis, oran, giris_devri, oran,
                        cikis_devri, giris_moment, oran, cikis_moment)),
            ),
            sayi_adimi(
                soru="Taş dakikada kaç devir dönecek?",
                cevap=cikis_devri,
                birim="dev/dak",
                aciklama="{} ÷ {} = {} dev/dak".format(
                    giris_devri, oran, cikis_devri),
                yaygin_yanlislar={
                    giris_devri * oran:
                        "Oranla çarptın. Büyük çarka geçiliyor; devir "
                        "düşmeli, yükselmemeli.",
                    giris_devri:
                        "Giriş devrini yazdın. Dişli kutusu tam olarak bu "
                        "sayıyı değiştirmek için takıldı.",
                },
                ipuclari=["Önce dişli oranını bul: büyük çark ÷ küçük çark."],
                puan=12,
            ),
            sayi_adimi(
                soru="Taşa binen moment kaç Nm olacak?",
                cevap=cikis_moment,
                birim="Nm",
                aciklama="{} × {} = {} Nm".format(
                    giris_moment, oran, cikis_moment),
                yaygin_yanlislar={
                    round(giris_moment / float(oran), 4):
                        "Momenti de böldün. Devir düşerken moment ARTAR; "
                        "ikisi ters yönde değişir.",
                    giris_moment:
                        "Giriş momentini yazdın. Devir değişirken momentin "
                        "sabit kalması gücün düşmesi demek olurdu.",
                },
                puan=12,
            ),
            yorum_adimi(
                soru="Dişli kutusu değirmene güç mü kazandırdı?",
                dogru="Hayır; gücü korudu, devri düşürüp momenti artırdı.",
                yanlislar={
                    "Evet, moment arttığı için değirmene giden güç de arttı.":
                        "Moment arttı ama devir aynı oranda düştü. Gücü "
                        "belirleyen ikisinin çarpımı; o değişmedi.",
                    "Hayır; hem devir hem moment düştüğü için güç azaldı.":
                        "Moment düşmedi, arttı. Düşen yalnızca devir.",
                    "Evet; dişli kutuları motorun verimini yükseltir.":
                        "Dişli kutusu verimi yükseltmez, hatta sürtünme "
                        "yüzünden bir miktar düşürür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Giriş gücü ile çıkış gücü aynıdır: biri {} × {}, öteki "
                    "{} × {} - iki çarpım da eşit. Değişen, gücün dağılımı."
                    .format(giris_moment, giris_devri, cikis_moment,
                            cikis_devri)),
            ),
        ],
        kapanis=("Taş yavaşladı, un yanmadı. Değirmenci kutuya \"sihir yok, "
                 "oran var\" diye bir kâğıt yapıştırdı."),
        odul={"erzak": 3, "cevher": 1},
    )


# ==========================================================================
# VERİM ZİNCİRİ
# ==========================================================================

# Ardışık iki organın verimleri; çarpımları temiz çıksın diye hazır seçildi.
# (0,90 - 0,90) çifti bilerek yok: ortalaması ile en kötüsü aynı sayıya
# denk geliyor ve iki ayrı teşhis tek anahtarda çakışıyordu.
VERIM_CIFTLERI = [
    (0.95, 0.80),
    (0.90, 0.80),
    (0.85, 0.80),
    (0.80, 0.75),
    (0.95, 0.60),
]


@bulmaca(ders="makine", konu="verim_zinciri", kademeler=(10, 13),
         etiketler=("guc_verim",))
def aktarma_zinciri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Ardışık verimler ÇARPILIR; toplanmaz, ortalaması alınmaz.

    Zincirin toplam verimi en zayıf halkasından da düşüktür - öğrencilerin
    çoğunun sezgisine ters gelen nokta budur.
    """
    kayis, reduktor = rastgele.choice(VERIM_CIFTLERI)
    toplam = round(kayis * reduktor, 4)
    motor_kw = rastgele.choice([10, 20])
    cikan_kw = round(motor_kw * toplam, 4)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mak-aktarma-zinciri",
        ders="makine",
        baslik="Yetmeyen Motor",
        kademe=kademe,
        konu="verim_zinciri",
        kazanim="Ardışık aktarma organlarında toplam verim; verimlerin "
                "çarpılması.",
        dikkat=6,
        brifing=(
            "Kereste atölyesindeki testere, motor yeni olmasına rağmen kalın "
            "kütükte duruyor. Motor plakasında {} kW yazıyor ve motor sağlam.\n\n"
            "{} aktarmayı inceledi: güç motordan testereye önce bir kayışla, "
            "sonra bir redüktörle geçiyor. İkisinin de kendi verimi var.\n\n"
            "Testerenin gerçekte kaç kilovatla döndüğü hiçbir yerde yazmıyor. "
            "Yeni motor almadan önce bunu bilmek gerekiyor."
        ).format(motor_kw, kisi),
        kanitlar=[
            Kanit("Kayış etiketi",
                  "Kayış aktarmasının verimi: {} (yani %{}).".format(
                      sy(kayis), int(round(kayis * 100))),
                  bedel=1, kritik=True),
            Kanit("Redüktör plakası",
                  "Redüktörün verimi: {} (yani %{}).".format(
                      sy(reduktor), int(round(reduktor * 100))),
                  bedel=1, kritik=True),
            Kanit("Makine el kitabı",
                  "\"Ardışık organlarda toplam verim, tek tek verimlerin "
                  "ÇARPIMIdır. Her organ, kendisine ULAŞAN gücün bir kısmını "
                  "geçirir.\"",
                  bedel=2, kritik=True),
            Kanit("Motor plakası",
                  "Motor gücü: {} kW. Motor geçen ay revizyondan çıktı."
                  .format(motor_kw), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Zincirin toplam verimini hangi işlem verir?",
                dogru="İki verimi çarparız.",
                yanlislar={
                    "İki verimi toplarız.":
                        "Verimleri topladın; sonuç 1'i geçiyor, yani "
                        "aktarma kendisine gelenden fazlasını veriyor olurdu. "
                        "Bu imkânsız.",
                    "İki verimin ortalamasını alırız.":
                        "Ortalama, iki organın ortasını verir. Oysa güç "
                        "ikisinden SIRAYLA geçiyor: ikincisi, birincisinden "
                        "arta kalanı işliyor.",
                    "En düşük verimi alırız, zinciri o belirler.":
                        "Zincirin toplam verimi en zayıf halkadan da "
                        "DÜŞÜKtür; çünkü ondan önceki halka da bir miktar "
                        "kaybetmiştir.",
                    "İki verimin farkını alırız.":
                        "Fark bir verim değildir; iki organ birbirinden "
                        "çıkarılmaz, art arda dizilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Güç önce kayıştan geçiyor ve {} ile çarpılıyor; kalan, "
                    "redüktöre giriyor ve {} ile çarpılıyor. Toplam: {} × {} "
                    "= {} yani %{}.".format(
                        sy(kayis), sy(reduktor), sy(kayis), sy(reduktor),
                        sy(toplam), int(round(toplam * 100)))),
                ipuclari=[
                    "Güç iki organdan aynı anda mı geçiyor, sırayla mı?",
                    "İkinci organ, birinciden ÇIKAN gücü işliyor.",
                ],
                cozum=(
                    "1) Toplam verim = {} × {} = {}\n"
                    "2) Testereye ulaşan güç = {} × {} = {} kW".format(
                        sy(kayis), sy(reduktor), sy(toplam),
                        motor_kw, sy(toplam), sy(cikan_kw))),
            ),
            sayi_adimi(
                soru="Zincirin toplam verimi yüzde kaç?",
                cevap=round(toplam * 100),
                birim="%",
                aciklama="{} × {} = {} → %{}".format(
                    sy(kayis), sy(reduktor), sy(toplam),
                    int(round(toplam * 100))),
                yaygin_yanlislar={
                    round((kayis + reduktor) * 100):
                        "Verimleri topladın; %100'ü aşan bir sonuç çıktı ve "
                        "bu imkânsız.",
                    round((kayis + reduktor) / 2 * 100):
                        "Ortalama aldın. Güç iki organdan sırayla geçiyor; "
                        "ortalama değil çarpım gerekir.",
                    round(min(kayis, reduktor) * 100):
                        "En zayıf halkayı yazdın. Toplam verim ondan da "
                        "düşüktür, çünkü diğer halka da kaybediyor.",
                },
                ipuclari=["İki verimi çarp, sonra 100 ile çarp."],
                puan=14,
            ),
            sayi_adimi(
                soru="Testereye ulaşan güç kaç kW?",
                cevap=cikan_kw,
                birim="kW",
                aciklama="{} × {} = {} kW".format(
                    motor_kw, sy(toplam), sy(cikan_kw)),
                yaygin_yanlislar={
                    motor_kw:
                        "Motor gücünü yazdın. Aktarma boyunca kayıp olduğu "
                        "için testereye bu gücün tamamı ulaşmıyor.",
                    round(motor_kw * min(kayis, reduktor), 4):
                        "Yalnızca bir organın verimini uyguladın; güç iki "
                        "organdan da geçiyor.",
                },
                puan=12,
            ),
            yorum_adimi(
                soru="Motoru büyütmek doğru çözüm mü?",
                dogru=("Önce zayıf halka düzeltilmeli; yoksa büyük motor da boşa "
                       "çalışır."),
                yanlislar={
                    "Evet; daha büyük motor sorunu kesin çözer, aktarmaya bakmak "
                    "gerekmez.":
                        "Verim bir ORAN olduğu için büyük motorda da aynı "
                        "yüzde kaybolur. Kayıp büyür, sorun kalır.",
                    "Hayır; motor gücünün testereyle ilgisi yok.":
                        "İlgisi var, ama tek başına belirleyici değil: "
                        "testereye ulaşan güç motor gücü ile verimin "
                        "çarpımıdır.",
                    "Evet; verim motor büyüdükçe kendiliğinden yükselir.":
                        "Verimi belirleyen kayış ve redüktör; motorun "
                        "büyüklüğü onları değiştirmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Verim oran olduğu için büyük motor kaybı da büyütür. "
                    "Ucuz çözüm zayıf halkayı (burada %{}) iyileştirmektir."
                    .format(int(round(min(kayis, reduktor) * 100)))),
            ),
        ],
        kapanis=("Redüktörün yağı bitmişti. Yağ tamamlanınca testere kütüğü "
                 "aynı motorla kesti."),
        odul={"cevher": 2, "erzak": 2, "itibar": 2},
    )


# ==========================================================================
# TOLERANS
# ==========================================================================

@bulmaca(ders="makine", konu="tolerans_kabul", kademeler=(9, 12),
         etiketler=("tolerans",))
def parca_kabulu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Tolerans iki yönlüdür: nominal ölçünün hem altı hem üstü kabul aralığına
    girer. Tek yönlü sayan öğrenci sağlam parçaları hurdaya ayırır.
    """
    nominal = rastgele.choice([24, 36, 48, 60])
    tolerans = rastgele.choice([0.1, 0.2, 0.5])
    alt = round(nominal - tolerans, 3)
    ust = round(nominal + tolerans, 3)
    # Sapma bazen aralığın içinde bazen dışında olsun; cevap ezberlenmesin.
    sapma = rastgele.choice([-1.5, -0.5, 0.5, 1.5]) * tolerans
    olculen = round(nominal + sapma, 3)
    kabul = alt <= olculen <= ust
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mak-parca-kabulu",
        ders="makine",
        baslik="Kabul Masası",
        kademe=kademe,
        konu="tolerans_kabul",
        kazanim="Nominal ölçü ve tolerans; kabul aralığının iki yönlü "
                "kurulması.",
        dikkat=5,
        brifing=(
            "Atölye bu hafta yirmi mil işledi. Teknik resimde mil çapı için "
            "{} mm ve yanında \"± {} mm\" yazıyor.\n\n"
            "{} kumpasla ölçüm yapıyor. Elindeki parçada {} mm okundu.\n\n"
            "Parça kabul mü, hurda mı? Yanlış karar iki türlü zarar: sağlam "
            "parçayı atmak da bozuğu montaja göndermek de."
        ).format(nominal, sy(tolerans), kisi, sy(olculen)),
        kanitlar=[
            Kanit("Teknik resim",
                  "Mil çapı: {} mm ± {} mm.".format(nominal, sy(tolerans)),
                  bedel=1, kritik=True),
            Kanit("Kumpas okuması",
                  "Ölçülen değer: {} mm.".format(sy(olculen)),
                  bedel=1, kritik=True),
            Kanit("Kalite yönergesi",
                  "\"± işareti toleransın İKİ YÖNLÜ olduğunu gösterir: "
                  "nominal ölçünün hem altındaki hem üstündeki sapma kabul "
                  "sınırları içindedir.\"",
                  bedel=2, kritik=True),
            Kanit("Tezgâh kaydı",
                  "Tezgâh bu hafta ayarlanmadı; önceki parçalar da benzer "
                  "değerler verdi.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Parçanın kabul edilip edilmeyeceğine nasıl karar veririz?",
                dogru=("Nominal ± tolerans sınırlarını bulur, ölçü arada mı diye "
                       "bakarız."),
                yanlislar={
                    "Ölçülen değer nominal ölçüye eşit değilse hurdaya "
                    "ayırırız.":
                        "Tam nominal ölçüde parça işlemek mümkün değildir; "
                        "tolerans zaten bunun için vardır. Bu kural bütün "
                        "parçaları hurdaya gönderirdi.",
                    "Yalnızca üst sınıra bakarız; altında kalması sorun "
                    "değildir.":
                        "Toleransı tek yönlü saydın. ± işareti iki yönü de "
                        "bağlar; fazla ince mil de yatağına oturmaz.",
                    "Toleransı nominal ölçünün yüzdesi olarak alır, ölçüyü bu "
                    "yüzde payla kıyaslarız.":
                        "Resimde \"± 0,2 mm\" gibi bir uzunluk yazıyor, yüzde "
                        "değil. Birimi milimetre.",
                    "Ölçüyü bir kez daha alıp iki okumanın ortalamasını "
                    "kullanırız.":
                        "Tekrar ölçmek iyidir ama karar kuralını değiştirmez; "
                        "yine kabul aralığıyla karşılaştırman gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kabul aralığı = {} - {} ile {} + {} arası, yani {} mm ile "
                    "{} mm. Ölçülen {} mm bu aralığın {}.".format(
                        nominal, sy(tolerans), nominal, sy(tolerans),
                        sy(alt), sy(ust), sy(olculen),
                        "içinde" if kabul else "dışında")),
                ipuclari=[
                    "\"±\" işareti kaç yön anlatıyor?",
                    "Önce iki sınırı yaz, sonra ölçümü aralarına koy.",
                ],
                cozum=(
                    "1) Alt sınır = {} - {} = {} mm\n"
                    "2) Üst sınır = {} + {} = {} mm\n"
                    "3) Ölçülen {} mm → {}".format(
                        nominal, sy(tolerans), sy(alt),
                        nominal, sy(tolerans), sy(ust),
                        sy(olculen), "kabul" if kabul else "hurda")),
            ),
            sayi_adimi(
                soru="Kabul aralığının üst sınırı kaç mm?",
                cevap=ust,
                birim="mm",
                aciklama="{} + {} = {} mm".format(
                    nominal, sy(tolerans), sy(ust)),
                yaygin_yanlislar={
                    nominal:
                        "Nominal ölçüyü yazdın; toleransı eklemeyi unuttun.",
                    alt:
                        "Alt sınırı yazdın. Sorulan üst sınır: toleransı "
                        "çıkarmak değil eklemek gerekiyor.",
                    round(nominal + 2 * tolerans, 3):
                        "Toleransı iki kez eklemişsin. Aralığın genişliği iki "
                        "tolerans kadardır ama ÜST sınır nominale bir tolerans "
                        "eklenerek bulunur.",
                },
                puan=12,
            ),
            secim_adimi(
                soru="Bu parça ne olmalı?",
                dogru="Kabul edilmeli." if kabul else "Hurdaya ayrılmalı.",
                yanlislar={
                    ("Hurdaya ayrılmalı." if kabul else "Kabul edilmeli."):
                        ("Ölçülen {} mm, kabul aralığı {} - {} mm. "
                         "Karşılaştırmayı bir daha yap.".format(
                             sy(olculen), sy(alt), sy(ust))),
                    "Tezgâh ayarlanıp parça yeniden işlenmeli.":
                        "Karar kuralı ölçüme bakar. Tezgâh ayarı ayrı bir "
                        "konu; bu parçanın kabulünü değiştirmez.",
                    "Montaja gönderilip orada denenmeli.":
                        "Kabul kararı montajda değil kabul masasında verilir; "
                        "yanlış parçayı montaja göndermek arızayı sonraya "
                        "taşır.",
                },
                rastgele=rastgele,
                aciklama="Ölçülen {} mm, aralık {} - {} mm: {}.".format(
                    sy(olculen), sy(alt), sy(ust),
                    "içeride" if kabul else "dışarıda"),
                puan=14,
            ),
            yorum_adimi(
                soru="Kumpasın kendi ölçüm hatası varsa bu karar ne olur?",
                dogru="Sınıra yakın ölçümlerde karar güvenilmez; ölçüm tekrarlanmalı.",
                yanlislar={
                    "Değişmez; kumpas her zaman doğru ölçer.":
                        "Her ölçü aletinin bir hata payı vardır; kumpas da "
                        "istisna değil.",
                    "Bütün parçalar hurdaya ayrılmalı.":
                        "Alet hatası bütün ölçümleri geçersiz kılmaz; yalnızca "
                        "sınıra yakın olanları şüpheli hâle getirir.",
                    "Tolerans büyütülerek sorun çözülür, çünkü kumpas hatası da "
                    "payın içine girer.":
                        "Toleransı büyütmek parçanın işe yaraması için gereken "
                        "sınırı değiştirmez; yalnızca kötü parçayı kabul eder.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ölçüm hatası, aralığın kenarında bir belirsizlik bandı "
                    "yaratır. Ortada kalan değerler güvenlidir; sınıra yakın "
                    "olanlar tekrar ölçülür."),
            ),
        ],
        kapanis=("Kabul masasına iki sınırı gösteren bir levha asıldı; "
                 "ölçümü alan herkes artık aralığı görüyor."),
        odul={"cevher": 2, "itibar": 3},
    )
