# -*- coding: utf-8 -*-
"""
Alıştırma merdiveni: bir konuda takılan öğrenciye basitten ortaya doğru
kısa bir soru dizisi.

NEDEN AYRI BİR MODÜL
--------------------
`oturum.py` 900 satırı geçti. Merdiveni oraya gömmek onu daha da
karmaşıklaştırırdı; üstelik merdiven normal görev akışının bir varyantı
değil, AYRI bir şey: puanı yok, ödülü yok, yarıda bırakmak serbest.

NEDEN VAR
---------
Kullanıcının isteği: "basitten ortalamaya doğru 4-5 soru sırayla ekleriz
ve öğrenci yapamadığı zaman direkt çıkma seçeneği olsun."

Bugüne kadar takılan öğrenciye söylenen şey "bu konuya bir daha bak"tı —
ama nereye bakacağı söylenmiyordu. Merdiven o boşluğu dolduruyor: konu
aynı, kademe düşük başlıyor ve adım adım yükseliyor.

TASARIM_NOTLARI §0 SINIRLARI
----------------------------
1. **İlerleme yalnızca OLUMLU yönde işlenir.** Merdivende başarmak konuyu
   ilerletir; başaramamak GERİLETMEZ. Zorlanan öğrenciyi, yardım istediği
   için cezalandırmak §0'ın tam tersidir.
2. **Her adımda çıkış var** ve çıkmak bir başarısızlık değil. Merdiven
   yarıda bırakılırsa o ana kadar geçilen basamaklar sayılır.
3. **Puan ve ödül yok.** Merdiven bir ölçme değil, bir çalışma.
"""
from __future__ import annotations

import random
from typing import List, Optional

from . import ilerleme
from . import terminal as ekran
from .kayit_defteri import uret
from .modeller import BIRLIKTE, Bulmaca
from .terminal import S

# Kaç basamak ve kademe nasıl yükselir. Kullanıcının istegi "4-5 soru".
BASAMAK_SAYISI = 4
# İlk basamak, takılınan kademenin bu kadar altından başlar.
BASLANGIC_DUSUSU = 3


def merdiven_uret(ders: str, konu: str, kademe: int,
                  rastgele: Optional[random.Random] = None,
                  basamak: int = BASAMAK_SAYISI) -> List[Bulmaca]:
    """Aynı konudan, kademesi artan bulmacalar üretir.

    Üretilemeyen basamak sessizce atlanır: bir konunun her kademede
    içeriği olmayabilir ve bu yüzden merdiven hiç açılmasın istemeyiz.
    Aynı bulmaca iki kez gelmesin diye görülen üretici adları haric tutulur.
    """
    rnd = rastgele or random.Random()
    alt = max(1, kademe - BASLANGIC_DUSUSU)
    ust = max(alt, kademe)
    if basamak <= 1:
        kademeler = [alt]
    else:
        adim = (ust - alt) / float(basamak - 1)
        kademeler = [int(round(alt + adim * i)) for i in range(basamak)]

    bulmacalar: List[Bulmaca] = []
    gorulen: list = []
    for kd in kademeler:
        # Birkac deneme: `haric` "mumkunse secilmez" demek, garanti degil.
        # Dar bir konuda ayni uretici arka arkaya gelebiliyor ve merdivende
        # ayni soruyu iki kez gormek calisma degil, bikkinlik uretir.
        for _ in range(4):
            b = uret(ders=ders, kademe=kd, konu=konu, rastgele=rnd)
            if b is None:
                break
            # `uret` bilinmeyen bir konuyu SESSIZCE yok sayip baska konudan
            # bulmaca donduruyor. Normal akista bu makul bir geri dusme ama
            # merdivende degil: ogrenciye "bu konuyu calisalim" deyip baska
            # konudan soru vermek, yardim degil kafa karistirmadir.
            if getattr(b, "konu", None) != konu:
                b = None
                break
            # KADEME DE DENETLENMELI. `uret()` istenen kademede icerik
            # yoksa YUKARI KIRPIYOR: kademe 5'te takilan ogrenciye, konusu
            # yalnizca 8-12'de bulunan bir uretici kademe 8 bulmaca
            # dondurebiliyor. Sonuc: "basitten baslayarak calisalim" deyip
            # DAHA ZOR soru vermek.
            #
            # Bagimsiz bir test (8 Eylul 2026) bunu 270 merdivende olctu:
            # ilk basamak %31,9 ihtimalle takilinan kademeden ZOR, %8,9
            # ihtimalle ayni. Ornek: turkce/anlatim_bozuklugu 5 -> [8].
            #
            # Ayni koruma `oturum.py:_ornek_uret` icinde ZATEN VARDI
            # (`ornek.kademe >= b.kademe` ise reddet); merdivene konmamisti.
            # Bos merdiven, yalan soyleyen merdivenden iyidir.
            if b.kademe >= kademe:
                b = None
                break
            # AYNI kademede ayni uretici tekrar gelirse yeniden dene.
            # Ama ayni uretici FARKLI kademede gelmesi kusur DEGIL: dar bir
            # konunun tek ureticisi olabilir ve o uretici her kademede baska
            # bir bulmaca uretir -- ayni problem tipi, artan zorluk. Iyi bir
            # merdiven zaten boyledir.
            if (b.kod, b.kademe) in gorulen:
                continue
            break
        if b is None:
            continue
        bulmacalar.append(b)
        gorulen.append((b.kod, b.kademe))
    return bulmacalar


def merdiveni_oyna(durum, ders: str, konu: str, kademe: int) -> int:
    """Merdiveni oynatır ve geçilen basamak sayısını döner.

    Dönen sayı yalnızca bilgi amaçlı; hiçbir yerde puana çevrilmiyor.
    """
    from .oturum import Oturum

    bulmacalar = merdiven_uret(ders, konu, kademe, durum.rastgele("merdiven"))
    if not bulmacalar:
        ekran.bilgi("Bu konu için basamaklı alıştırma bulunamadı.")
        ekran.bekle()
        return 0

    ekran.temizle()
    ekran.baslik("ALIŞTIRMA MERDİVENİ", "kalin", "acik_cam")
    ekran.yaz()
    ekran.kutu(
        "Aynı konudan {} soru; kolaydan başlayıp yükseliyor.\n\n"
        "Puan yok, ödül yok — bu bir çalışma. İstediğin basamakta "
        "\"x\" ile çıkabilirsin, geçtiğin basamaklar sayılır.".format(
            len(bulmacalar)),
        konu.replace("_", " ").upper(), "beyaz")
    if not ekran.onayla("Başlayalım mı?", True):
        return 0

    gecilen = 0
    for sira, bulmaca in enumerate(bulmacalar, 1):
        ekran.yaz()
        ekran.yaz("BASAMAK {}/{}".format(sira, len(bulmacalar)),
                  "kalin", "acik_mor")
        # BIRLIKTE asamasi: merdiven bir olcme degil, destekli calisma.
        oturum = Oturum(bulmaca, oyuncu_adi=durum.goruntu_adi, ipucu_acik=True,
                        asama=BIRLIKTE, durum=durum)
        sonuc = oturum.oyna()
        # `sonucu_ozetle` puani asamadan bagimsiz basiyor; BIRLIKTE'de
        # azami_puan 0 oldugu icin her basamak "0/0 puan" ile bitiyordu.
        # Merdivende puan zaten YOK (calisma, olcme degil) -- ozet
        # basilmiyor, yerine sade bir satir konuyor.
        if sonuc.birakildi:
            pass
        else:
            dogru = sum(1 for a in sonuc.adim_sonuclari if a.dogru)
            ekran.yaz()
            ekran.yaz("Basamak bitti: {}/{} adım.".format(
                dogru, len(sonuc.adim_sonuclari)), "acik_cam")

        if sonuc.birakildi:
            ekran.yaz()
            ekran.yaz("Merdivenden indin. {} basamak geçtin; onlar "
                      "sayılıyor.".format(gecilen), "acik_sari")
            ekran.bekle()
            break

        # §0: YALNIZCA olumlu yonde isle. Basaramamak konuyu geriletmez.
        #
        # DIKKAT -- burada bir hata vardi ve merdiveni tamamen issiz
        # birakiyordu: olcut `sonuc.oran >= 0.5` idi. Ama merdiven BIRLIKTE
        # asamasinda oynuyor ve o asamada adimlar PUANLANMIYOR; yani
        # `azami_puan = 0` ve `oran` HER ZAMAN 0.0 (modeller.py, oran
        # ozelligi). Kapi hicbir zaman acilmiyordu: ilerleme islenmiyor,
        # "tepeye ciktin" hic cikmiyor, dort basamagi da dogru bilen
        # ogrenciye "0 basamak gectin" deniyordu.
        #
        # Olcut artik puana degil ADIM SONUCLARINA bakiyor: adimlarin
        # yarisindan cogu dogruysa basamak gecilmis sayilir. Puanin olmadigi
        # bir asamada puana bakmak zaten yanlisti.
        adimlar = sonuc.adim_sonuclari
        dogru_adim = sum(1 for a in adimlar if a.dogru)
        gecti = bool(adimlar) and dogru_adim * 2 >= len(adimlar)
        if gecti:
            gecilen += 1
            ilerleme.sonucu_isle(durum, sonuc)
        durum.kaydet()
        if sira < len(bulmacalar):
            ekran.bekle()

    if gecilen == len(bulmacalar):
        ekran.yaz()
        ekran.yaz("Merdivenin tepesine çıktın. Bu konu artık daha kolay "
                  "gelecek.", "acik_yesil")
        ekran.bekle()
    return gecilen
