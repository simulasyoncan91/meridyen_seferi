# -*- coding: utf-8 -*-
"""
Yabancı dilde bağlam ve iletişim görevleri.

Bu görevlerin çoğu ezber kelime değil, BAĞLAM sorusudur: kısa bir
diyalog ya da cümle verilir, boşluğa ne geleceği metnin içindeki ipuçlarından
çıkarılır. Bu, oyunun keşif mantığıyla doğrudan örtüşüyor.

Görevlerin çerçevesi: üsse gelen yabancı heyetle yazışmalar.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import model_adimi, secim_adimi, yorum_adimi


# ==========================================================================
# ZAMAN UYUMU
# ==========================================================================

@bulmaca(ders="ingilizce", konu="zaman_uyumu", kademeler=(5, 10), agirlik=1.3)
def zaman_uyumu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Cümledeki zaman ifadesi hangi zamanı gerektiriyor?"""
    durumlar = [
        {
            "cumle": "We ___ the new equipment yesterday.",
            "isaret": "yesterday",
            "dogru": "tested",
            "zaman": "Simple Past (geçmiş zaman)",
            "yanlislar": ["test", "are testing", "will test", "have tested"],
            "neden": ("\"yesterday\" bitmiş ve zamanı belli bir geçmişi gösterir; "
                      "bu durumda Simple Past kullanılır."),
        },
        {
            "cumle": "The team ___ the report right now.",
            "isaret": "right now",
            "dogru": "is writing",
            "zaman": "Present Continuous (şimdiki zaman)",
            "yanlislar": ["writes", "wrote", "will write", "has written"],
            "neden": ("\"right now\" tam şu anda süren bir eylemi gösterir; "
                      "Present Continuous kullanılır."),
        },
        {
            "cumle": "Our supply truck ___ every Monday.",
            "isaret": "every Monday",
            "dogru": "arrives",
            "zaman": "Simple Present (geniş zaman)",
            "yanlislar": ["arrived", "is arriving", "will arrive", "has arrived"],
            "neden": ("\"every Monday\" düzenli tekrar eden bir olayı gösterir; "
                      "Simple Present kullanılır."),
        },
        {
            "cumle": "The delegation ___ next week.",
            "isaret": "next week",
            "dogru": "will visit",
            "zaman": "Future (gelecek zaman)",
            "yanlislar": ["visited", "visits", "was visiting", "has visited"],
            "neden": "\"next week\" gelecekteki bir zamanı gösterir; Future kullanılır.",
        },
    ]
    durum = rastgele.choice(durumlar)

    return Bulmaca(
        kod="ing-zaman-uyumu",
        ders="ingilizce",
        baslik="Yazışmadaki Boşluk",
        kademe=kademe,
        konu="zaman_uyumu",
        kazanim="Zaman zarflarıyla fiil zamanı arasındaki uyumu kurma.",
        dikkat=5,
        brifing=(
            "Üsse gelecek yabancı heyete gönderilecek yazının bir cümlesinde "
            "boşluk kalmış:\n\n"
            "  \"{}\"\n\n"
            "Kâtip \"hangisini yazsam olur\" diyor. Ama cümlenin içinde, hangi "
            "zamanın kullanılacağını söyleyen bir işaret var; onu bulmak "
            "gerekiyor."
        ).format(durum["cumle"]),
        kanitlar=[
            Kanit("Cümle", durum["cumle"], bedel=1, kritik=True),
            Kanit("Zaman işaretleri tablosu",
                  "yesterday, last week, in 2019, ... ago  -> Simple Past\n"
                  "now, right now, at the moment           -> Present Continuous\n"
                  "every day/week, usually, always         -> Simple Present\n"
                  "tomorrow, next week, soon               -> Future (will)\n"
                  "already, just, yet, since, for          -> Present Perfect",
                  bedel=2, kritik=True),
            Kanit("Yazışma kuralı",
                  "\"Cümlede zaman zarfı varsa fiil ona uymak zorundadır. Zarf, "
                  "zamanı seçen taraftır.\"", bedel=2, kritik=True),
            Kanit("Sözlük",
                  "test: denemek / write: yazmak / arrive: varmak / "
                  "visit: ziyaret etmek", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Boşluğa hangi zamanın geleceğini ne belirler?",
                dogru="Cümledeki zaman ifadesi.",
                yanlislar={
                    "Cümlenin öznesi.":
                        "Özneye baktın. Özne fiilin çekimini etkiler ama hangi "
                        "ZAMANIN kullanılacağını belirlemez.",
                    "Cümlenin uzunluğu.":
                        "Uzunluğa baktın. Zamanı belirleyen şey cümlenin boyu "
                        "değil, içindeki zaman ifadesi.",
                    "Fiilin anlamı.":
                        "Fiilin anlamına baktın. Aynı fiil bütün zamanlarda "
                        "kullanılabilir.",
                    "Cümlenin olumlu ya da olumsuz olması.":
                        "Olumluluğa baktın. Olumsuz cümle de aynı zamanda "
                        "kurulabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İngilizcede zaman zarfı ile fiil zamanı birbirine bağlıdır. "
                    "\"yesterday\" varsa fiil geçmiş olmak zorundadır; özne kim olursa "
                    "olsun bu değişmez. Bu yüzden bu tür sorularda önce zarf aranır, "
                    "sonra şıklara bakılır - tersi yapılırsa şıklar arasında kaybolunur."
                ),
                ipuclari=[
                    "Cümlede bir zaman ifadesi var mı? Onu işaretle.",
                    "Tabloda o ifadenin karşısında hangi zaman yazıyor?",
                ],
                puan=16,
                cozum=(
                    "1) Cümledeki zaman ifadesini bul: \"{}\"\n"
                    "2) Tabloda karşılığına bak: {}\n"
                    "3) Şıklardan bu zamana uyan tek biçimi seç.\n"
                    "4) {}\n\n"
                    "Doğru biçim: {}"
                ).format(durum["isaret"], durum["zaman"], durum["neden"], durum["dogru"]),
            ),
            secim_adimi(
                soru="Cümledeki zaman ifadesi hangisidir?",
                dogru=durum["isaret"],
                yanlislar={
                    x: "\"{}\" bu cümlede geçmiyor. Cümleyi okurken \"ne "
                       "zaman?\" sorusuna cevap veren sözü ara.".format(x)
                    for x in ["yesterday", "right now", "every Monday",
                              "next week", "for two years"]
                    if x != durum["isaret"]
                },
                rastgele=rastgele,
                aciklama="Cümledeki zaman ifadesi \"{}\" ve bu {} gerektirir.".format(
                    durum["isaret"], durum["zaman"]),
                ipuclari=["Cümleyi okurken \"ne zaman?\" sorusuna cevap veren sözü ara."],
                puan=12,
            ),
            secim_adimi(
                soru="Boşluğa hangisi gelmelidir?",
                dogru=durum["dogru"],
                yanlislar=durum["yanlislar"],
                rastgele=rastgele,
                aciklama="{} Doğru biçim: {}".format(durum["neden"], durum["dogru"]),
                ipuclari=["Belirlediğin zamana uyan tek şıkkı seç."],
                puan=16,
            ),
        ],
        kapanis="Yazı tamamlandı ve heyete gönderildi.",
        odul={"itibar": 6},
    )


# ==========================================================================
# BAĞLAMDAN ANLAM
# ==========================================================================

@bulmaca(ders="ingilizce", konu="baglamdan_anlam", kademeler=(6, 11))
def baglamdan_anlam(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bilinmeyen kelimenin anlamı cümlenin geri kalanından çıkarılacak."""
    durumlar = [
        {
            "metin": ("The road was completely blocked by snow, so the convoy "
                      "had to postpone the journey until Friday."),
            "kelime": "postpone",
            "dogru": "ertelemek",
            "yanlislar": ["hızlandırmak", "iptal etmek", "başlatmak", "kısaltmak"],
            "ipucu_metin": ("\"until Friday\" ifadesi yolculuğun cuma gününe "
                            "bırakıldığını gösteriyor: iptal değil, ileri atma."),
        },
        {
            "metin": ("We had very little water left, so we decided to reduce "
                      "the daily amount for each person."),
            "kelime": "reduce",
            "dogru": "azaltmak",
            "yanlislar": ["artırmak", "ölçmek", "paylaşmak", "depolamak"],
            "ipucu_metin": ("\"very little water left\" azlık bildiriyor; böyle bir "
                            "durumda günlük miktar artırılmaz, azaltılır."),
        },
        {
            "metin": ("The old generator was noisy and broken, so the team "
                      "decided to replace it with a new one."),
            "kelime": "replace",
            "dogru": "değiştirmek",
            "yanlislar": ["tamir etmek", "satmak", "temizlemek", "taşımak"],
            "ipucu_metin": ("\"with a new one\" ifadesi eskinin yerine yenisinin "
                            "konduğunu gösteriyor."),
        },
    ]
    durum = rastgele.choice(durumlar)

    return Bulmaca(
        kod="ing-baglam",
        ders="ingilizce",
        baslik="Sözlüksüz Okuma",
        kademe=kademe,
        konu="baglamdan_anlam",
        kazanim="Bilinmeyen sözcüğün anlamını bağlamdan çıkarma.",
        dikkat=5,
        brifing=(
            "Heyetten gelen yazıda bir cümle var ve içinde kimsenin bilmediği "
            "bir kelime geçiyor:\n\n"
            "  \"{}\"\n\n"
            "Sözlük depoda kilitli ve anahtar kayıp. Ama cümlenin geri kalanı "
            "kelimenin ne demek olduğunu ele veriyor.\n\n"
            "Bilinmeyen kelime: \"{}\""
        ).format(durum["metin"], durum["kelime"]),
        kanitlar=[
            Kanit("Yazının cümlesi", durum["metin"], bedel=1, kritik=True),
            Kanit("Okuma yöntemi notu",
                  "\"Bilinmeyen kelimeyi anlamak için cümlenin geri kalanına bak: "
                  "kelimeden önce ve sonra ne söyleniyor? Özellikle 'so', "
                  "'because', 'but' gibi bağlaçlar sebep-sonuç ilişkisini açar.\"",
                  bedel=2, kritik=True),
            Kanit("Bilinen kelimeler",
                  "blocked: kapalı / snow: kar / until: -e kadar / "
                  "little: az / left: kalan / old: eski / broken: bozuk / "
                  "new: yeni", bedel=1, kritik=True),
            Kanit("Bağlam ipucu", durum["ipucu_metin"], bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bilinmeyen bir kelimenin anlamı nasıl çıkarılır?",
                dogru="Cümledeki bilinen sözcüklerden ve bağlaçların kurduğu ilişkiden.",
                yanlislar={
                    "Kelimenin uzunluğuna bakarak.":
                        "Uzunluğa baktın. Kelimenin kaç harfli olduğu anlamı "
                        "hakkında hiçbir şey söylemez.",
                    "Kelimenin Türkçedeki benzer sesli karşılığını arayarak, çünkü çoğu kelime ortaktır.":
                        "Ses benzerliğine güvendin. Bu çoğu zaman yanıltır: "
                        "kulağa benzeyen kelimeler bambaşka anlamlara gelir.",
                    "Cümledeki ilk kelimeye bakarak.":
                        "Tek bir kelimeye baktın. Anlamı veren şey cümlenin "
                        "TAMAMININ kurduğu bağlam.",
                    "Kelime hangi harfle başlıyorsa ona göre tahmin ederek.":
                        "Baş harfi ölçüt saydın. Harf ile anlam arasında bir "
                        "bağ yok.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sınavda bilinmeyen kelime çıkması kural dışı değil, kuralın "
                    "kendisidir; soru zaten bunu ölçer. Bağlaçlar bu işin anahtarıdır: "
                    "\"so\" sonuç, \"because\" sebep, \"but\" karşıtlık kurar. Bu ilişkiyi "
                    "gören öğrenci kelimeyi bilmeden anlamını daraltabilir."
                ),
                ipuclari=[
                    "Cümlede \"so\" ya da \"because\" var mı? Neyi neye bağlıyor?",
                    "Kelimenin öncesindeki durum ne? Sonrasında ne oluyor?",
                ],
                puan=18,
                cozum=(
                    "1) Cümlenin bildiğin kısmını Türkçeye çevir.\n"
                    "2) Bağlacın kurduğu ilişkiyi belirle (sebep/sonuç/karşıtlık).\n"
                    "3) Bilinmeyen kelimenin yerine anlamlı bir Türkçe karşılık koy "
                    "ve cümlenin tutup tutmadığına bak.\n"
                    "4) {}\n\n"
                    "Sonuç: \"{}\" = {}"
                ).format(durum["ipucu_metin"], durum["kelime"], durum["dogru"]),
            ),
            secim_adimi(
                soru="\"{}\" kelimesi ne anlama geliyor?".format(durum["kelime"]),
                dogru=durum["dogru"],
                yanlislar=durum["yanlislar"],
                rastgele=rastgele,
                aciklama=durum["ipucu_metin"],
                ipuclari=["Her şıkkı cümleye yerleştir; hangisi anlamlı kalıyor?"],
                puan=16,
            ),
            yorum_adimi(
                soru="Sınavda bilinmeyen kelime görünce ne yapmak gerekir?",
                dogru="Cümlenin geri kalanından anlamı daraltmak, boş bırakmamak.",
                yanlislar={
                    "Soruyu hemen boş bırakmak.":
                        "Bilinmeyen kelimeyi çıkmaz saydın. Cümlenin geri "
                        "kalanı çoğu zaman anlamı daraltmaya yeter.",
                    "Rastgele bir şık işaretlemek.":
                        "Tahmine geçtin. Bağlamı okumak, rastgele seçmekten "
                        "her zaman daha iyi sonuç verir.",
                    "Kelimenin Türkçe benzerini aramak.":
                        "Ses benzerliğine güvendin; bu yöntem sık sık yanlış "
                        "anlama götürür.",
                    "Cümleyi hiç okumadan şıklara bakmak; tanıdık görünen şık çoğu zaman doğrudur.":
                        "Sırayı ters kurdun. Şıklar ancak cümlenin ne dediğini "
                        "bildikten sonra ayırt edilebilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bağlamdan anlam çıkarma öğrenilebilir bir beceridir ve iletişimde "
                    "çok işe yarayan alışkanlıklardan biridir. Metnin tamamını "
                    "anlamadan da doğru şıkka ulaşmak çoğu zaman mümkündür; yeter ki "
                    "cümledeki ilişki görülsün."
                ),
                puan=10,
            ),
        ],
        kapanis="Yazı sözlüksüz çözüldü; anahtarın aranması ayrıca not edildi.",
        odul={"itibar": 5},
    )


# ==========================================================================
# DİYALOG TAMAMLAMA
# ==========================================================================

@bulmaca(ders="ingilizce", konu="diyalog", kademeler=(5, 10))
def diyalog_tamamlama(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Boş bırakılan cevabı, sorunun türünden çıkarma."""
    durumlar = [
        {
            "soru_cumlesi": "How often do you check the generator?",
            "dogru": "Twice a week.",
            "yanlislar": ["In the storage room.", "Because it is old.",
                          "Yes, I do.", "It was last year."],
            "tur": "sıklık sorusu (how often)",
            "neden": ("\"How often\" sıklık sorar; cevabı bir sıklık ifadesi olmalıdır "
                      "(twice a week, every day gibi)."),
        },
        {
            "soru_cumlesi": "Where did you find the missing box?",
            "dogru": "Behind the kitchen door.",
            "yanlislar": ["Twice a week.", "Because it was too heavy to carry.",
                          "Yes, I did.", "Next Monday."],
            "tur": "yer sorusu (where)",
            "neden": "\"Where\" yer sorar; cevabı bir yer bildirmelidir.",
        },
        {
            "soru_cumlesi": "Why is the road closed?",
            "dogru": "Because of the heavy snow.",
            "yanlislar": ["At six o'clock this morning.", "Behind the hill.",
                          "Yes, it is.", "Three times."],
            "tur": "sebep sorusu (why)",
            "neden": "\"Why\" sebep sorar; cevabı \"because\" ile başlayan bir sebep olmalıdır.",
        },
    ]
    durum = rastgele.choice(durumlar)

    return Bulmaca(
        kod="ing-diyalog",
        ders="ingilizce",
        baslik="Telsizdeki Konuşma",
        kademe=kademe,
        konu="diyalog",
        kazanim="Soru sözcüğüne uygun cevabı seçme.",
        dikkat=4,
        brifing=(
            "Yabancı heyetle yapılan telsiz konuşmasının dökümünde bir cevap "
            "eksik kalmış:\n\n"
            "  Heyet: \"{}\"\n"
            "  Üs   : ___\n\n"
            "Dökümü tamamlamamız gerekiyor. Cevabın ne olacağını sorunun kendisi "
            "belirliyor."
        ).format(durum["soru_cumlesi"]),
        kanitlar=[
            Kanit("Konuşma dökümü",
                  "Heyet: \"{}\"\nÜs: (eksik)".format(durum["soru_cumlesi"]),
                  bedel=1, kritik=True),
            Kanit("Soru sözcükleri tablosu",
                  "What  -> ne (nesne/eylem)\n"
                  "Where -> nerede (yer)\n"
                  "When  -> ne zaman (zaman)\n"
                  "Why   -> neden (sebep - cevap genelde \"Because...\")\n"
                  "How often -> ne sıklıkta (sıklık)\n"
                  "Do/Does/Did ile başlayan sorular -> Yes/No cevabı alır",
                  bedel=2, kritik=True),
            Kanit("Telsizci notu",
                  "\"Cevap, sorunun istediği bilgi türünde olmalı. Doğru bilgi "
                  "ama yanlış türde bir cevap da hatalıdır.\"", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Doğru cevabı seçmek için önce neye bakılır?",
                dogru="Soru sözcüğüne ve istediği bilgi türüne.",
                yanlislar={
                    "Cevap şıklarının uzunluğuna.":
                        "Şık uzunluğuna baktın. Uzun şık daha doğru değildir; "
                        "önce sorunun NE SORDUĞUNA bakılır.",
                    "Cevapta, soruda geçen tanıdık bir kelime olup olmadığına.":
                        "Tanıdık kelimeye yöneldin. Bilinen kelime içeren şık "
                        "çoğu zaman tuzaktır.",
                    "Sorunun kaç kelime olduğuna.":
                        "Soru uzunluğuna baktın; bunun cevapla ilgisi yok.",
                    "Konuşmanın hangi konuda geçtiğine.":
                        "Konuya baktın. Konu şıkların hepsinde ortak olabilir; "
                        "ayırt edici olan sorunun sorduğu bilgi türü.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Soru sözcüğü cevabın TÜRÜNÜ belirler: \"where\" yer ister, "
                    "\"why\" sebep ister. Şıklar arasında konuyla ilgili ama yanlış "
                    "türde cevaplar bulunur; bunlar tam da bu ayrımı sınamak için "
                    "konur. Doğru bilgi, yanlış türdeyse yanlıştır."
                ),
                ipuclari=[
                    "Soru hangi kelimeyle başlıyor?",
                    "Tabloda o kelimenin karşısında ne yazıyor?",
                ],
                puan=16,
                cozum=(
                    "1) Sorunun ilk kelimesine bak: bu bir {}.\n"
                    "2) {}\n"
                    "3) Şıkları tek tek ele: konuyla ilgili ama yer/zaman/sebep "
                    "türü tutmayan cevaplar elenir.\n\n"
                    "Doğru cevap: {}"
                ).format(durum["tur"], durum["neden"], durum["dogru"]),
            ),
            secim_adimi(
                soru="Boşluğa hangi cevap gelmelidir?",
                dogru=durum["dogru"],
                yanlislar=durum["yanlislar"],
                rastgele=rastgele,
                aciklama=durum["neden"],
                ipuclari=["Sorunun istediği bilgi türüne uymayan şıkları ele."],
                puan=16,
            ),
            yorum_adimi(
                soru="Şıklarda konuyla ilgili ama yanlış türde cevaplar neden bulunur?",
                dogru="Soru sözcüğüne bakmadan tanıdık kelimeye atlayanı ayırmak için.",
                yanlislar={
                    "Soruyu uzatmak için.":
                        "Çeldiricileri dolgu saydın. Onlar boşluk doldurmaz; "
                        "belirli bir hatayı yakalamak için konur.",
                    "Rastgele seçildikleri için.":
                        "Rastgele saydın. Konuyla ilgili ama yanlış türde bir "
                        "şık, dinlemeden konuya bakıp seçen öğrenciyi "
                        "ayıklamak için oradadır.",
                    "Her soruda beş şık olması gerektiği için; boşluklar konuyla doldurulur.":
                        "Sayıyı gerekçe saydın. Şık sayısı bir biçim kuralı; "
                        "çeldiricinin İÇERİĞİNİ açıklamaz.",
                    "Öğrencinin kelime bilgisini ölçmek için.":
                        "Ölçüleni yanlış belirledin. Bu tür çeldirici kelime "
                        "bilgisini değil, sorunun ne sorduğunu anlayıp "
                        "anlamadığını ölçer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çeldiriciler rastgele değildir; belirli bir hatayı yakalamak için "
                    "yazılır. Burada yakalanmak istenen hata, soruyu okumadan tanıdık "
                    "bir kelime görüp işaretlemektir. Bunu bilmek, şıklara bakış "
                    "biçimini değiştirir."
                ),
                puan=10,
            ),
        ],
        kapanis="Konuşma dökümü tamamlandı ve dosyaya kondu.",
        odul={"itibar": 5},
    )
