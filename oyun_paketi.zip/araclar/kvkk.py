# -*- coding: utf-8 -*-
"""
Verinin yaşam döngüsü: saklama süresi ve silme yolları (B36.16, KVKK).

Bu modül EKRANSIZDIR: dosyaları bulur ve siler, ne yaptığını söyler.
Ekranlar öğretmen masasında (araclar/ogretmen.py) ve oyuncunun ayarlar
menüsünde (oyun/motor/oyun.py). Dört silme yolu da aynı işlevden geçer,
böylece "hangi dosyalar birlikte gider" tek yerde tanımlı:

    kaydi_sil(yol)
      * öğrenci kaydı                     kayitlar/<kimlik>.json
      * yarım kalmış yazım ve yeni sürüm yedeği (<kayıt>.tmp, .yeni-surum.bak)
      * öğretmen bildirimleri            kayitlar/bildiriler/<kimlik>.json
      * hata kayıtları                    kayitlar/hatalar/hata-...-<kimlik>.txt
      * karne                             karneler/<ad>_karne.html
        -- AYNI KARNE DOSYASINA düşen başka bir kayıt kaldıysa dokunulmaz:
           karne dosya adı öğrencinin ADINDAN türer, iki "Ada Yılmaz" aynı
           dosyayı paylaşır.
      * geri bildirim paketleri           geri_bildirim/*.zip
        -- yalnız İÇİNDE bu öğrencinin kayıt dosyası olan paketler (paket
           adı gönderenin adından türer; ada değil içeriğe bakılır).

HİÇBİR ŞEY SESSİZCE SİLİNMEZ. Saklama süresi yalnız bir LİSTE üretir
(`suresi_dolanlar`); silme öğretmenin açık onayıyla yapılır. Kullanıcı
kararı (29 Eylül 2026): 12 ay oynanmayan kayıt silinir, süre ayarlanabilir
(araclar/okul_ayarlari.py).

TELEFON: telefondaki kayıt tarayıcının kendi deposundadır; öğretmen masası
onu göremez, dolayısıyla ne saklama listesine ne sınıf silmeye girer.
Oradaki tek yol öğrencinin kendi "Kaydımı sil"idir (silme `durum.sil`
üzerinden tarayıcı deposuna da işlenir).

SINIF SUNUCUSU öğrenci kaydı tutmaz (sınıf adı, okul adı, anonim el kaldırma
sayıları); saklama kuralının orada sileceği bir öğrenci verisi yok. Sınıf
kapatılırken sunucudaki sınıf da öğretmen anahtarıyla silinir.

HUKUKİ NOT: aşağıdaki aydınlatma metni TASLAKTIR. Hukuki uygunluk kararı
okulun ve bir hukukçunun işidir; Claude hukuki onay veremez.
"""
from __future__ import annotations

import calendar
import io
import json
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional

from oyun.motor import durum as durum_modulu

# --------------------------------------------------------------------------
# Aydınlatma metni (TASLAK)
# --------------------------------------------------------------------------

AYDINLATMA_ETIKETI = ("TASLAK -- hukukçu/okul görüşü bekliyor; "
                      "Claude hukuki onay veremez")

# KVKK_VERI_ENVANTERI.md §7 ile AYNI metin (ay = 12 yazılarak). İkisinin
# ayrışmaması testle kilitli (testler/test_kvkk.py).
AYDINLATMA_TASLAGI = (
    "Meridyen Seferi bir eğitim oyunudur. Oyunda öğrencinin adı, sınıfı, "
    "okul numarası ve oyun içindeki ilerlemesi (çözdüğü görevler, yaptığı "
    "hatalar, kazandığı rozetler) saklanır. Bu bilgiler, öğretmenin "
    "öğrencinin nerede zorlandığını görmesi ve karne hazırlaması içindir. "
    "Kimlik numarası, telefon, e-posta, fotoğraf veya konum istenmez."
    "\n\n"
    "Bilgiler okulun bilgisayarında ya da öğrencinin kendi telefonunda "
    "durur; reklam veya analiz şirketlerine gönderilmez. Sınıfta "
    "“anlamadım” bildirimleri isimsiz sayılır. Sınıf sunucusu "
    "kullanılıyorsa sunucuya yalnızca sınıfın adı, okulun adı ve hangi "
    "soruda kaç kişinin “anlamadım” dediği gider; öğrencinin adı gitmez. "
    "Geri bildirim "
    "paketi yalnızca oyuncu isterse oluşturulur ve kendiliğinden hiçbir "
    "yere gönderilmez."
    "\n\n"
    "Saklama süresi: {ay} ay boyunca oynanmayan kayıtlar öğretmen masasında "
    "listelenir ve öğretmenin onayıyla silinir. Bu süreyi okul yönetimi "
    "değiştirebilir. Hiçbir kayıt haber verilmeden, kendiliğinden silinmez."
    "\n\n"
    "Kayıt bu süreden önce de silinebilir: öğrenci oyunda “Teçhizat ve "
    "Ayarlar > Kaydımı sil” ile kendi kaydını siler (adını aynen yazarak, "
    "PIN koyduysa PIN'iyle); veli ya da öğrenci öğretmenden silinmesini "
    "isteyebilir; öğretmen ders yılı sonunda bir sınıfın bütün kayıtlarını "
    "birlikte silebilir."
    "\n\n"
    "Kayıtla birlikte öğrencinin karne dosyası, öğretmenin bıraktığı "
    "bildirimler, oyunun hata kayıtları ve öğrencinin oluşturduğu geri "
    "bildirim paketleri de silinir. Silinen kayıt geri "
    "getirilemez. Daha önce yazdırılmış ya da başka bir yere kopyalanmış "
    "karneler bu silmeden etkilenmez."
    "\n\n"
    "Oyun telefonda oynanıyorsa kayıt yalnızca o telefonda durur; öğretmen "
    "bu kaydı göremez ve silemez. Telefondaki kayıt oyundaki “Kaydımı sil” "
    "ile ya da tarayıcının site verileri temizlenerek silinir."
    "\n\n"
    "Sorularınız için: [OKUL İLETİŞİM]. Veri sorumlusu: [okul ve hukukçu "
    "görüşüyle belirlenecek]."
)


def aydinlatma_metni(ay: Optional[int] = None) -> str:
    from araclar import okul_ayarlari
    if ay is None:
        ay = okul_ayarlari.saklama_ayi()
    return AYDINLATMA_TASLAGI.format(ay=ay)


# --------------------------------------------------------------------------
# Saklama süresi
# --------------------------------------------------------------------------

def _sayi(deger: Any) -> float:
    if isinstance(deger, bool):
        return 0.0
    try:
        sayi = float(deger)
    except (TypeError, ValueError):
        return 0.0
    return sayi if sayi == sayi and sayi > 0 else 0.0     # NaN ve eksi yok


def son_oynama_zamani(ozet: Dict[str, Any]) -> float:
    """Kaydın son oynanma zamanı; bilinmiyorsa 0.

    `son_oynama` kayıtta varsa o. ESKİ kayıtta yoksa (ya da bozuksa) dosyanın
    değişim zamanı ile `ilk_oynama`nın büyüğü: kayıt oyun her kaydettiğinde
    yeniden yazıldığı için dosya zamanı son oynamanın iyi bir alt sınırıdır.
    Hata yönü güvenli taraftadır: dosya kopyalanıp zamanı yenilenirse kayıt
    daha GENÇ görünür, erken silinmez.
    """
    son = _sayi(ozet.get("son"))
    if son:
        return son
    adaylar = [_sayi(ozet.get("ilk"))]
    try:
        adaylar.append(_sayi(os.path.getmtime(ozet.get("yol") or "")))
    except OSError:
        pass
    return max(adaylar)


def ay_once(simdi: float, ay: int) -> float:
    """`simdi`den takvimce `ay` ay önceki an (31 Mart - 1 ay = 28/29 Şubat)."""
    t = time.localtime(simdi)
    yil, ay_no = divmod(t.tm_year * 12 + (t.tm_mon - 1) - int(ay), 12)
    ay_no += 1
    gun = min(t.tm_mday, calendar.monthrange(yil, ay_no)[1])
    return time.mktime((yil, ay_no, gun, t.tm_hour, t.tm_min, t.tm_sec,
                        0, 0, -1))


def suresi_dolanlar(simdi: Optional[float] = None, ay: Optional[int] = None,
                    ozetler: Optional[List[Dict[str, Any]]] = None
                    ) -> List[Dict[str, Any]]:
    """Saklama süresi boyunca oynanmamış kayıtların özetleri.

    Her özete `son_gercek` (hesapta kullanılan zaman) ve `tahmini` (zaman
    kayıttan değil dosyadan geldiyse True) eklenir. Son oynaması hiç
    bilinmeyen kayıt LİSTEYE GİRMEZ: bilmediğimiz şeyi silmeyiz.
    """
    from araclar import okul_ayarlari
    ay = (okul_ayarlari.saklama_ayi() if ay is None
          else okul_ayarlari.saklama_ayi_coz(ay))
    esik = ay_once(time.time() if simdi is None else simdi, ay)
    if ozetler is None:
        ozetler = durum_modulu.kayitlari_listele()
    dolan = []
    for ozet in ozetler:
        zaman = son_oynama_zamani(ozet)
        if 0 < zaman < esik:
            dolan.append(dict(ozet, son_gercek=zaman,
                              tahmini=not _sayi(ozet.get("son"))))
    dolan.sort(key=lambda o: o["son_gercek"])
    return dolan


# --------------------------------------------------------------------------
# Silme
# --------------------------------------------------------------------------

@dataclass
class SilmeSonucu:
    yol: str
    ad: str = ""
    basarili: bool = False
    silinen: List[str] = field(default_factory=list)
    silinemeyen: List[str] = field(default_factory=list)
    karne_korundu: bool = False      # aynı karne dosyasını kullanan biri kaldı


def _karne_anahtari(ad: str) -> str:
    """İki adın AYNI karne dosyasına düşüp düşmediğini söyleyen anahtar.

    Karşılaştırma dosya adı üzerinden ve büyük/küçük harf duyarsız: Windows'ta
    "ada_yılmaz_karne.html" ile "Ada_Yılmaz_karne.html" aynı dosyadır.
    Şüphede karne KORUNUR -- başkasının karnesini silmek geri alınamaz.
    """
    return durum_modulu.dosya_adi_yap(ad).casefold()


def karne_yolu(ad: str) -> str:
    from araclar.karne import karne_klasoru
    return os.path.join(karne_klasoru(),
                        "{}_karne.html".format(durum_modulu.dosya_adi_yap(ad)))


def _hata_dosyasi_mi(dosya_adi: str, kimlik: str) -> bool:
    from oyun.motor.cokme import kimlige_ait_mi
    return kimlige_ait_mi(dosya_adi, kimlik)


def _kaldir(yol: str, sonuc: SilmeSonucu) -> None:
    try:
        os.remove(yol)
    except FileNotFoundError:
        return
    except OSError:
        sonuc.silinemeyen.append(yol)
        return
    sonuc.silinen.append(yol)


def kaydi_sil(yol: str) -> SilmeSonucu:
    """Bir öğrencinin kaydını ve ona bağlı dosyaları kalıcı olarak siler.

    Kayıt dosyası silinemezse başka HİÇBİR ŞEYE dokunulmaz: kayıt duruyorsa
    karnesini ya da bildirimini silmek öğrenciyi yarım bırakır.
    """
    from oyun.motor import bildiri
    from oyun.motor.cokme import hata_klasoru

    sonuc = SilmeSonucu(yol=yol)
    ham: Dict[str, Any] = {}
    try:
        with io.open(yol, encoding="utf-8") as dosya:
            okunan = json.load(dosya)
        if isinstance(okunan, dict):
            ham = okunan
    except (OSError, ValueError):
        pass
    sonuc.ad = str(ham.get("ad") or "")

    # Kimlik: dosya adı esas. Kayıttan hesaplanan farklıysa (eski kayıt,
    # elle taşınmış dosya) o da temizlenir; ikisi de bu öğrenciye ait.
    kimlikler = [os.path.splitext(os.path.basename(yol))[0]]
    if ham:
        try:
            hesaplanan = durum_modulu.Durum.sozlukten(ham).kimlik()
        except Exception:          # noqa: BLE001 - bozuk kayıt da silinebilmeli
            hesaplanan = ""
        if hesaplanan and hesaplanan not in kimlikler:
            kimlikler.append(hesaplanan)

    if os.path.exists(yol):
        if not durum_modulu.sil(yol):
            sonuc.silinemeyen.append(yol)
            return sonuc
        sonuc.silinen.append(yol)

    # Hesaplanan kimlikle adlandırılmış BAŞKA bir kayıt duruyorsa o kimliğin
    # bildirimleri ve hata kayıtları onundur; dokunulmaz.
    klasor_kayit = os.path.dirname(yol) or durum_modulu.KAYIT_KLASORU
    kimlikler = kimlikler[:1] + [
        k for k in kimlikler[1:]
        if not os.path.exists(os.path.join(klasor_kayit, k + ".json"))]

    for ek in (".tmp", durum_modulu.YENI_SURUM_YEDEGI):
        _kaldir(yol + ek, sonuc)

    for kimlik in kimlikler:
        bildiri_yolu = os.path.join(bildiri.bildiri_klasoru(), kimlik + ".json")
        if os.path.exists(bildiri_yolu):
            if bildiri.bildirileri_sil(kimlik):
                sonuc.silinen.append(bildiri_yolu)
            else:
                sonuc.silinemeyen.append(bildiri_yolu)

    klasor = hata_klasoru()
    try:
        hata_adlari = sorted(os.listdir(klasor))
    except OSError:
        hata_adlari = []
    for ad in hata_adlari:
        if any(_hata_dosyasi_mi(ad, k) for k in kimlikler):
            _kaldir(os.path.join(klasor, ad), sonuc)

    if sonuc.ad:
        karne = karne_yolu(sonuc.ad)
        if os.path.exists(karne):
            anahtar = _karne_anahtari(sonuc.ad)
            if any(_karne_anahtari(o.get("ad", "")) == anahtar
                   for o in durum_modulu.kayitlari_listele()):
                sonuc.karne_korundu = True
            else:
                _kaldir(karne, sonuc)

    for paket in geri_bildirim_paketleri(kimlikler):
        _kaldir(paket, sonuc)

    sonuc.basarili = not os.path.exists(yol)
    return sonuc


def geri_bildirim_paketleri(kimlikler: Iterable[str]) -> List[str]:
    """İçinde bu kimliklerden birinin kayıt dosyası olan geri bildirim paketleri.

    Paket adı gönderenin ADINDAN türer ("geribildirim-Ada_Yılmaz-...zip");
    iki Ada'nın paketleri adla ayrılamaz. Paketin içine bakılır: her paket
    yalnız oluşturan öğrencinin kaydını taşır (`kayitlar/<kimlik>.json`,
    bkz. geri_bildirim.paket_olustur). Açılamayan paket şüphelidir ama
    kimin olduğu bilinmez -- dokunulmaz.
    """
    import zipfile

    from araclar import geri_bildirim

    # Büyük/küçük harf DUYARLI: telefonda "ali" ile "Ali" iki ayrı kayıt
    # olabilir; şüphede paket korunur.
    arananlar = {"kayitlar/{}.json".format(k) for k in kimlikler if k}
    klasor = geri_bildirim.paket_klasoru()
    try:
        adlar = sorted(os.listdir(klasor))
    except OSError:
        return []
    bulunan = []
    for ad in adlar:
        if not ad.lower().endswith(".zip"):
            continue
        yol = os.path.join(klasor, ad)
        try:
            with zipfile.ZipFile(yol) as paket:
                icindekiler = {n.replace("\\", "/") for n in paket.namelist()}
        except (OSError, zipfile.BadZipFile):
            continue
        if icindekiler & arananlar:
            bulunan.append(yol)
    return bulunan


def toplu_sil(yollar: Iterable[str]) -> List[SilmeSonucu]:
    """Kayıtları sırayla siler. Aynı adlı kayıtların SONUNCUSU silinince
    ortak karne de gider (her silmeden sonra kalanlara yeniden bakılır)."""
    return [kaydi_sil(yol) for yol in yollar]


# --------------------------------------------------------------------------
# Sınıf bazında (yıl sonu)
# --------------------------------------------------------------------------

def _kod(kod: str) -> str:
    return (kod or "").strip().upper()


def sinif_kayitlari(kod: str, ozetler: Optional[List[Dict[str, Any]]] = None
                    ) -> List[Dict[str, Any]]:
    """Bu sınıf koduna bağlı öğrenci kayıtları (ada göre)."""
    kod = _kod(kod)
    if not kod:
        return []
    if ozetler is None:
        ozetler = durum_modulu.kayitlari_listele()
    bulunan = [o for o in ozetler if _kod(o.get("sinif_kodu", "")) == kod]
    return sorted(bulunan, key=lambda o: ((o.get("ad") or "").casefold(),
                                          o.get("numara") or ""))


def bilinen_siniflar() -> List[Dict[str, Any]]:
    """Silme ekranının sınıf listesi: tanımlı sınıflar + kayıtlarda geçen,
    tanımı bu klasörde olmayan kodlar (sınıf başka makinede açılmış olabilir).
    """
    from araclar.sinif import siniflari_listele
    ozetler = durum_modulu.kayitlari_listele()
    liste = []
    gorulen = set()
    for kayit in siniflari_listele():
        kod = _kod(kayit.get("kod", ""))
        if not kod or kod in gorulen:
            continue
        gorulen.add(kod)
        liste.append({"kod": kod, "ad": kayit.get("ad", ""), "tanimli": True,
                      "ogrenci": len(sinif_kayitlari(kod, ozetler))})
    for ozet in ozetler:
        kod = _kod(ozet.get("sinif_kodu", ""))
        if kod and kod not in gorulen:
            gorulen.add(kod)
            liste.append({"kod": kod, "ad": ozet.get("sinif", ""),
                          "tanimli": False,
                          "ogrenci": len(sinif_kayitlari(kod, ozetler))})
    return liste


def kodsuz_kayit_sayisi(ozetler: Optional[List[Dict[str, Any]]] = None) -> int:
    """Hiçbir sınıf koduna bağlı olmayan kayıtlar (sınıf silmeye girmez)."""
    if ozetler is None:
        ozetler = durum_modulu.kayitlari_listele()
    return sum(1 for o in ozetler if not _kod(o.get("sinif_kodu", "")))


def sinif_kayitlarini_sil(kod: str) -> List[SilmeSonucu]:
    return toplu_sil([o["yol"] for o in sinif_kayitlari(kod)])


def sinifi_kapat(kod: str) -> Dict[str, Any]:
    """Sınıfın kendisini kaldırır: tanım, ders programı, el kaldırma sayıları
    ve (varsa) sunucudaki kaydı. Öğrenci kayıtlarına DOKUNMAZ.

    Sunucuya önce gidilir: silme isteği öğretmen anahtarını ister ve anahtar
    yalnız yerel sınıf dosyasında durur. Sunucu `sunucu` alanında:
    True silindi, False reddetti, None ulaşılamadı ya da sunucu yok.
    """
    from araclar import el_kaldirma
    from araclar.sinif import _dosya_yolu, ogretmen_anahtari
    from oyun.motor import ag
    from oyun.motor import ders_programi

    kod = _kod(kod)
    sonuc: Dict[str, Any] = {"kod": kod, "silinen": [], "silinemeyen": [],
                             "sunucu": None}
    if not kod:
        return sonuc
    if ag.acik_mi():
        anahtar = ogretmen_anahtari(kod)
        if anahtar:
            yanit = ag.gonder("/sinif_sil", {"kod": kod, "anahtar": anahtar})
            if isinstance(yanit, dict):
                sonuc["sunucu"] = bool(yanit.get("tamam"))
    yollar = [_dosya_yolu(kod), os.path.join(el_kaldirma.klasor(), kod + ".json")]
    try:
        yollar.append(ders_programi._program_yolu(kod))
    except ValueError:
        pass                        # biçimi bozuk kod: programı olamaz
    bos = SilmeSonucu(yol="")
    for yol in yollar:
        _kaldir(yol, bos)
    sonuc["silinen"], sonuc["silinemeyen"] = bos.silinen, bos.silinemeyen
    return sonuc
