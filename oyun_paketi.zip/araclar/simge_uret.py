"""Uygulama simgesini PNG olarak uretir.

NEDEN VAR
---------
`mobil/simge.svg` guzel ama her tarayici PWA simgesi olarak SVG kabul
etmiyor; Android'de "ana ekrana ekle" bazen sessizce cikmiyor. PNG her
yerde calisiyor.

Disaridan kutuphane yok (Pillow yok). PNG'yi elle yaziyoruz: zlib + struct
yeterli. Cizim 4 kat buyuk yapilip kucultuluyor -- kenarlar boylece
puruzsuz cikiyor (supersampling).

Kullanim:  python araclar/simge_uret.py
"""

import math
import pathlib
import struct
import zlib

ZEMIN = (0x10, 0x13, 0x1a)
CIZGI = (0x7f, 0xd1, 0xc1)
NOKTA = (0xff, 0xd4, 0x79)

KAT = 4  # supersampling carpani


def _karistir(alt, ust, oran):
    """Iki rengi oranla karistirir. oran=1 ise tamamen ust renk."""
    return tuple(round(a + (u - a) * oran) for a, u in zip(alt, ust))


def _yuvarlak_kose_icinde(x, y, en, yaricap):
    """Yuvarlatilmis karenin icinde miyiz?"""
    kx = min(x, en - 1 - x)
    ky = min(y, en - 1 - y)
    if kx >= yaricap or ky >= yaricap:
        return True
    dx, dy = yaricap - kx, yaricap - ky
    return dx * dx + dy * dy <= yaricap * yaricap


def _cember_uzerinde(x, y, mx, my, rx, ry, kalinlik):
    """Elips cizgisinin uzerinde miyiz? (dolgu degil, sadece kenar)"""
    if rx <= 0 or ry <= 0:
        return False
    # Elipse normalize edilmis uzaklik; 1.0 tam kenar.
    d = math.hypot((x - mx) / rx, (y - my) / ry)
    # Kalinligi piksele cevirmek icin en kucuk yaricapi olcek aliyoruz.
    pay = kalinlik / 2 / min(rx, ry)
    return abs(d - 1.0) <= pay


def _piksel(x, y, en):
    """Bir pikselin rengi. Cizim 192 birimlik tasarima gore olcekleniyor."""
    o = en / 192.0
    if not _yuvarlak_kose_icinde(x, y, en, 42 * o):
        return None  # saydam

    renk = ZEMIN
    mx = my = en / 2.0

    # Solgun boylam elipsi (SVG'de opacity .65)
    if _cember_uzerinde(x, y, mx, my, 26 * o, 58 * o, 5 * o):
        renk = _karistir(renk, CIZGI, 0.65)
    # Dis cember
    if _cember_uzerinde(x, y, mx, my, 58 * o, 58 * o, 6 * o):
        renk = CIZGI
    # Dikey eksen
    if abs(x - mx) <= 3 * o and abs(y - my) <= 58 * o:
        renk = CIZGI
    # Merkez nokta
    if math.hypot(x - mx, y - my) <= 8 * o:
        renk = NOKTA
    return renk


def simge_uret(en):
    """en x en boyutunda RGBA piksel satirlari uretir."""
    buyuk = en * KAT
    ham = [[_piksel(x + 0.5, y + 0.5, buyuk) for x in range(buyuk)]
           for y in range(buyuk)]

    satirlar = []
    for y in range(en):
        satir = bytearray()
        for x in range(en):
            top_r = top_g = top_b = top_a = 0
            for dy in range(KAT):
                for dx in range(KAT):
                    p = ham[y * KAT + dy][x * KAT + dx]
                    if p is not None:
                        top_r += p[0]
                        top_g += p[1]
                        top_b += p[2]
                        top_a += 255
            n = KAT * KAT
            gorunur = top_a // 255
            if gorunur:
                satir += bytes((top_r // gorunur, top_g // gorunur,
                                top_b // gorunur, top_a // n))
            else:
                satir += b"\0\0\0\0"
        satirlar.append(bytes(satir))
    return satirlar


def png_yaz(yol, en, satirlar):
    """RGBA satirlarini PNG dosyasina yazar."""
    def parca(tur, veri):
        govde = tur + veri
        return (struct.pack(">I", len(veri)) + govde
                + struct.pack(">I", zlib.crc32(govde) & 0xFFFFFFFF))

    # Her satirin basina filtre baytini koyuyoruz (0 = filtresiz).
    veri = b"".join(b"\0" + s for s in satirlar)
    basSat = struct.pack(">IIBBBBB", en, en, 8, 6, 0, 0, 0)  # 8 bit, RGBA
    pathlib.Path(yol).write_bytes(
        b"\x89PNG\r\n\x1a\n"
        + parca(b"IHDR", basSat)
        + parca(b"IDAT", zlib.compress(veri, 9))
        + parca(b"IEND", b"")
    )


def main():
    klasor = pathlib.Path(__file__).resolve().parent.parent / "mobil"
    for en in (192, 512):
        yol = klasor / f"simge-{en}.png"
        png_yaz(yol, en, simge_uret(en))
        print(f"{yol.name}  {yol.stat().st_size / 1024:.1f} KB")


if __name__ == "__main__":
    main()
