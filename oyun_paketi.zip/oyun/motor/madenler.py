# -*- coding: utf-8 -*-
"""
Madenler, külçeler, alaşımlar: TEK TABLO. (GOREVLER B28, 11 Eylül 2026)

Kullanıcı: "cevher deyince hangisi? demir, bakır, krom? bunları ayırmak
lazım." Kararı da kullanıcı verdi (11 Eylül): oyundaki "cevher" kaynağı
HAM TAŞ olarak kalır. Zincir:

    ham taş --(işleme)--> maden --(ergitme)--> külçe --(karıştırma)--> alaşım

Bu dosya zincirin YAPISINI kuruyor; oyun henüz kullanmıyor (içerikten
önce yapı). Kural (`ALAN_TANIMLARI` gibi): madenle, külçeyle, alaşımla
ilgili her şey bu tablolardan türer; başka dosyada liste yazılmaz.

SINIF İLERLEDİKÇE AÇILIR. Kullanıcının 5 Eylül tarifi: ilkokulda demir,
bakır, kömür, kireç taşı; titanyum, işlemenin zorluğu ve kimyası yüzünden
liseye saklanır. `acilis_kademesi` bunu tutar; `isleme` (1-5) cevherden
metale giden yolun ne kadar zor olduğunu -- hikâyede ve sorularda kullanılır.

Kömür, kireç taşı ve kükürt metal cevheri değildir; `tur` alanı ayırır ve
yalnızca metaller külçe olur. Kömür ile kireç taşının işi yüksek fırındadır
(bkz. KULCE_KATKILARI).

§3 UYARISI (GOREVLER B28): madenler yalnızca ÖĞRENMEYE açılan şeyleri
satın alabilir. "Üretimi artıran yükseltme" gibi kendi içine kapanan bir
ağaç kurulursa oyun, ödev yapıştırılmış bir tıklama oyununa kayar.
"""
from __future__ import annotations

from typing import Dict, List, NamedTuple, Optional, Tuple


class Maden(NamedTuple):
    kod: str
    ad: str
    cevher: str           # doğada bulunduğu mineral ya da kayaç
    tur: str              # "metal", "enerji", "yapi", "endustri"
    acilis_kademesi: int
    isleme: int           # 1 kolay ... 5 çok zor
    ne_icin: str


TURLER = ("metal", "enerji", "yapi", "endustri")

MADENLER: List[Maden] = [
    # İlkokul (1-4)
    Maden("demir", "Demir", "hematit, manyetit", "metal", 1, 2,
          "alet, çivi, çelik"),
    Maden("bakir", "Bakır", "kalkopirit", "metal", 1, 2,
          "elektrik teli, kap kacak"),
    Maden("komur", "Kömür", "kömür damarı", "enerji", 1, 1,
          "yakıt; yüksek fırında demiri cevherinden ayırmak"),
    Maden("kirec_tasi", "Kireç taşı", "kalker", "yapi", 1, 1,
          "kireç, harç, çimento; yüksek fırında cürufu ayırmak"),
    # Ortaokul (5-8)
    Maden("cinko", "Çinko", "sfalerit", "metal", 5, 2,
          "demiri pastan korumak (galvaniz), pirinç alaşımı"),
    Maden("kalay", "Kalay", "kasiterit", "metal", 5, 2,
          "tunç (bronz) alaşımı, lehim"),
    Maden("kukurt", "Kükürt", "doğal kükürt", "endustri", 5, 2,
          "sülfürik asit, gübre"),
    Maden("aluminyum", "Alüminyum", "boksit", "metal", 6, 4,
          "hafif gövde, kablo; elektrolizle, çok enerji harcanarak elde edilir"),
    Maden("kobalt", "Kobalt", "kobaltit", "metal", 7, 3,
          "pil, sert alaşım"),
    # Lise (9-12)
    Maden("krom", "Krom", "kromit", "metal", 9, 3,
          "paslanmaz çelik, kaplama"),
    Maden("nikel", "Nikel", "pentlandit", "metal", 9, 3,
          "paslanmaz çelik, pil"),
    Maden("titanyum", "Titanyum", "ilmenit, rutil", "metal", 10, 5,
          "hafif ve sağlam gövde; çok reaktif, Kroll süreciyle elde edilir"),
    Maden("nadir_toprak", "Nadir toprak elementleri", "bastnazit", "metal", 11, 5,
          "güçlü mıknatıs, elektronik; birbirinden ayırmak çok zor"),
]

MADEN_KODLARI = [m.kod for m in MADENLER]
_DIZIN: Dict[str, Maden] = {m.kod: m for m in MADENLER}


def maden(kod: str) -> Optional[Maden]:
    return _DIZIN.get(kod)


def acik_madenler(kademe: int) -> List[Maden]:
    """Bu kademede açık olan madenler, tablodaki sırayla."""
    return [m for m in MADENLER if m.acilis_kademesi <= int(kademe)]


# ------------------------------------------------------------------ külçe
def kulceye_donusur(kod: str) -> bool:
    """Yalnızca metaller külçe olur; kömür yakar, kireç taşı katkıdır."""
    m = maden(kod)
    return m is not None and m.tur == "metal"


# Külçe dökülürken gereken katkılar. Şimdilik yalnızca demir: yüksek fırında
# kömür hem yakıttır hem cevherdeki oksijeni alır (indirgen); kireç taşı
# taştaki toprağı cüruf olarak ayırır. Miktarlar zincirin sayısal parçasında
# (GOREVLER B28.11) gelecek; burada yalnızca NEYİN gerektiği duruyor.
KULCE_KATKILARI: Dict[str, Tuple[str, ...]] = {
    "demir": ("komur", "kirec_tasi"),
}


# ----------------------------------------------------------------- alaşım
class Alasim(NamedTuple):
    kod: str
    ad: str
    bilesim: Dict[str, float]   # maden kodu -> kütle oranı (toplam 1)
    acilis_kademesi: int
    ne_icin: str


# Oranlar yaygın bileşimlerin yuvarlanmış hâli; gerçek alaşımlar bir aralıkta
# değişir ve küçük katkılar içerir. Çelikte "kömür" karbonun kaynağıdır.
# Açılış kademesi, bileşenlerin en geç açılanından önce olamaz (teste bağlı).
ALASIMLAR: List[Alasim] = [
    Alasim("celik", "Çelik", {"demir": 0.98, "komur": 0.02}, 3,
           "sağlam alet ve yapı; demire az miktarda karbon katılır"),
    Alasim("tunc", "Tunç (bronz)", {"bakir": 0.88, "kalay": 0.12}, 5,
           "çan, heykel; bir çağa adını veren alaşım"),
    Alasim("pirinc", "Pirinç", {"bakir": 0.65, "cinko": 0.35}, 5,
           "musluk, vida, üflemeli çalgılar"),
    Alasim("duralumin", "Duralümin", {"aluminyum": 0.95, "bakir": 0.05}, 7,
           "hafif ve sağlam gövde"),
    Alasim("paslanmaz_celik", "Paslanmaz çelik",
           {"demir": 0.74, "krom": 0.18, "nikel": 0.08}, 9,
           "pas tutmayan kap ve alet; krom yüzeyde koruyucu bir katman oluşturur"),
]

ALASIM_KODLARI = [a.kod for a in ALASIMLAR]


def alasim(kod: str) -> Optional[Alasim]:
    return next((a for a in ALASIMLAR if a.kod == kod), None)


def acik_alasimlar(kademe: int) -> List[Alasim]:
    return [a for a in ALASIMLAR if a.acilis_kademesi <= int(kademe)]
