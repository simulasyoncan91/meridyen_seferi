# -*- coding: utf-8 -*-
"""
Söz ve anlatım görevleri.

Bu görevlerin çoğu tanıma sorusudur: bir dize verilir, hangi söz
sanatı; bir paragraf verilir, hangi anlatım biçimi; bir şiirin özellikleri
verilir, hangi nazım biçimi. Yani zaten "özellikten türe git" biçiminde
kurulmuştur - oyunun keşif adımına birebir oturur.

Bu modülde şiir ve metin örnekleri oyun için yazılmıştır; gerçek bir şaire
ait değildir. Ölçülen şey metnin kime ait olduğu değil, taşıdığı özelliktir.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import model_adimi, secim_adimi, yorum_adimi


# ==========================================================================
# SÖZ SANATLARI
# ==========================================================================

_SANATLAR = [
    {
        "dize": "Rüzgâr bütün gece pencereyi dövdü, sabaha kadar susmadı.",
        "sanat": "Kişileştirme (teşhis)",
        "olcut": "İnsana ait bir davranış (dövmek, susmak) insan dışı bir varlığa verilmiş.",
    },
    {
        "dize": "Yüzü, karanlıkta görünen bir fener gibi aydınlıktı.",
        "sanat": "Benzetme (teşbih)",
        "olcut": ("İki varlık \"gibi\" edatıyla, ortak bir yön (aydınlık olma) "
                  "üzerinden birbirine benzetilmiş."),
    },
    {
        "dize": "Sevincinden yerinde duramıyor, dünyayı sığdıramıyordu içine.",
        "sanat": "Abartma (mübalağa)",
        "olcut": "Bir duygu, gerçekte olamayacak ölçüde büyütülerek anlatılmış.",
    },
    {
        "dize": "Ağlarım, hatıra geldikçe gülüştüklerimiz.",
        "sanat": "Karşıtlık (tezat)",
        "olcut": "Birbirinin karşıtı iki durum (ağlamak - gülmek) bir arada verilmiş.",
    },
    {
        "dize": "Bütün üs, komutanın haberini bekliyordu.",
        "sanat": "Ad aktarması (mecaz-ı mürsel)",
        "olcut": ("\"Üs\" sözcüğü binayı değil içindeki insanları anlatıyor: "
                  "parça-bütün ilişkisiyle bir ad başka bir şeyin yerine kullanılmış."),
    },
]


@bulmaca(ders="edebiyat", konu="soz_sanatlari", kademeler=(10, 13), agirlik=1.4)
def soz_sanatlari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Dizeden söz sanatını tanıma."""
    sanat = rastgele.choice(_SANATLAR)
    digerleri = [s["sanat"] for s in _SANATLAR if s["sanat"] != sanat["sanat"]]
    rastgele.shuffle(digerleri)

    return Bulmaca(
        kod="ede-soz-sanatlari",
        ders="edebiyat",
        baslik="Defterdeki Dize",
        kademe=kademe,
        konu="soz_sanatlari",
        kazanim="Söz sanatlarını dizedeki özelliklerinden tanıma.",
        dikkat=5,
        brifing=(
            "Arşivde bulunan bir defterin arasından tek bir dize çıktı. "
            "Şairi belli değil, hangi şiirden koptuğu da:\n\n"
            "  \"{}\"\n\n"
            "Arşiv fişine dizede kullanılan söz sanatı yazılacak. Şairi bilmek "
            "gerekmiyor; dizenin kendisi yeterli."
        ).format(sanat["dize"]),
        kanitlar=[
            Kanit("Dize", sanat["dize"], bedel=1, kritik=True),
            Kanit("Söz sanatları kılavuzu",
                  "BENZETME (teşbih): İki varlık ortak bir yön üzerinden "
                  "birbirine benzetilir. Genellikle \"gibi, kadar, sanki\" bulunur.\n\n"
                  "KİŞİLEŞTİRME (teşhis): İnsana ait özellik ya da davranış, "
                  "insan dışı bir varlığa verilir.\n\n"
                  "ABARTMA (mübalağa): Bir durum gerçekte olamayacak ölçüde "
                  "büyütülür ya da küçültülür.\n\n"
                  "KARŞITLIK (tezat): Birbirine karşıt kavramlar bir arada kullanılır.\n\n"
                  "AD AKTARMASI (mecaz-ı mürsel): Bir sözcük, benzetme amacı "
                  "OLMADAN başka bir şeyin yerine kullanılır (parça-bütün, "
                  "iç-dış, yer-insan ilişkisiyle).",
                  bedel=2, kritik=True),
            Kanit("Ayırt etme notu",
                  "\"Benzetme ile ad aktarmasını karıştırma: benzetmede iki varlık "
                  "arasında BENZERLİK kurulur, ad aktarmasında benzerlik yoktur, "
                  "ilgi vardır (parça-bütün, yer-insan gibi).\"",
                  bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir dizedeki söz sanatını tanımak için neye bakılır?",
                dogru="Sözcükler arasında kurulan ilişkinin türüne: benzerlik mi, karşıtlık mı, aktarma mı.",
                yanlislar={
                    "Dizenin kaç heceli olduğuna.":
                        "Hece sayısına baktın. Hece ölçüsü nazımla ilgilidir; "
                        "söz sanatını belirleyen şey sözcükler arasında "
                        "kurulan İLİŞKİ.",
                    "Dizenin hangi şaire ait olduğuna.":
                        "Şaire baktın. Aynı şair farklı sanatlar kullanır; "
                        "sanat dizenin kendisinden okunur.",
                    "Dizede kaç sözcük bulunduğuna.":
                        "Sözcük saydın. Sanat sözcük sayısıyla değil, "
                        "aralarındaki anlam bağıyla belirlenir.",
                    "Dizenin duygusal olup olmadığına.":
                        "Duyguyu ölçüt saydın. Duygusuz bir dizede de söz "
                        "sanatı bulunabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Söz sanatları, sözcükler arasında kurulan ilişkiye göre "
                    "adlandırılır. Benzerlik varsa teşbih, insana ait özellik "
                    "aktarılmışsa teşhis, karşıtlık varsa tezat, benzerlik olmadan "
                    "bir ad başkasının yerine geçmişse mecaz-ı mürseldir. Hece sayısı "
                    "ve şair adı nazım bilgisiyle ilgilidir, söz sanatıyla değil."
                ),
                ipuclari=[
                    "Dizede iki şey birbirine benzetiliyor mu?",
                    "İnsana ait bir davranış, insan olmayan bir şeye mi verilmiş?",
                ],
                puan=18,
                cozum=(
                    "1) Dizedeki sözcükler arasında kurulan ilişkiyi belirle.\n"
                    "2) Kılavuzdaki beş tanımla karşılaştır:\n"
                    "   - \"gibi/kadar/sanki\" ve ortak yön -> Benzetme\n"
                    "   - insana ait davranış, insan dışı varlıkta -> Kişileştirme\n"
                    "   - gerçekte olamayacak büyütme -> Abartma\n"
                    "   - karşıt kavramlar bir arada -> Karşıtlık\n"
                    "   - benzerliksiz yer değiştirme -> Ad aktarması\n"
                    "3) Bu dizedeki ölçüt: {}\n\n"
                    "Sonuç: {}"
                ).format(sanat["olcut"], sanat["sanat"]),
            ),
            secim_adimi(
                soru="Bu dizede hangi söz sanatı vardır?",
                dogru=sanat["sanat"],
                yanlislar=digerleri[:4],
                rastgele=rastgele,
                aciklama="{} Bu ölçüt {} sanatını tanımlar.".format(
                    sanat["olcut"], sanat["sanat"]),
                ipuclari=["Kılavuzdaki beş tanımı dizeyle tek tek karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Benzetme ile ad aktarması arasındaki temel fark nedir?",
                dogru="Benzetmede varlıklar arasında benzerlik kurulur; ad aktarmasında benzerlik yoktur, başka bir ilgi vardır.",
                yanlislar={
                    "Benzetme şiirde, ad aktarması düzyazıda kullanılır.":
                        "Ayrımı türe bağladın. İkisi de hem şiirde hem "
                        "düzyazıda geçer; fark KURULAN İLİŞKİDE.",
                    "Benzetme eski, ad aktarması yeni bir sanattır.":
                        "Ayrımı tarihe bağladın. İkisi de çok eski "
                        "sanatlardır.",
                    "Benzetmede iki sözcük, ad aktarmasında üç sözcük bulunur.":
                        "Ayrımı sözcük sayısına indirdin. Belirleyici olan "
                        "sayı değil, sözcükler arasındaki bağın benzerlik mi "
                        "yoksa yakınlık/parça-bütün ilişkisi mi olduğu.",
                    "Aralarında anlamlı bir fark yoktur.":
                        "Farkı yok saydın. Benzetmede iki ayrı şey benzerlik "
                        "kurar; ad aktarmasında bir şey, kendisiyle ilgili "
                        "başka bir şeyin yerine geçer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Aslan gibi adam\" benzetmedir: adamla aslan arasında cesaret "
                    "benzerliği kurulur. \"Sobayı yaktık\" ad aktarmasıdır: soba ile "
                    "odun arasında benzerlik yok, kap-içindeki ilişkisi var. Bu ayrım "
                    "Bu ayrım, metnin nasıl kurulduğunu anlamanın anahtarıdır."
                ),
                puan=12,
            ),
        ],
        kapanis="Dize fişlendi ve arşivin şiir bölümüne kondu.",
        odul={"itibar": 7},
    )


# ==========================================================================
# ANLATIM BİÇİMLERİ
# ==========================================================================

_ANLATIMLAR = [
    {
        "metin": ("Kapıdan girince dar bir koridor karşılıyordu insanı. Duvarlar "
                  "soluk yeşile boyanmıştı, boya yer yer kabarmıştı. Sağdaki "
                  "pencereden giren ışık, yerdeki tozu görünür kılıyordu."),
        "bicim": "Betimleyici anlatım",
        "olcut": ("Görüntü ayrıntılarıyla resmediliyor; olay yok, zaman akmıyor. "
                  "Okuyanın gözünde bir görüntü canıyor."),
    },
    {
        "metin": ("Kapıyı açtı, koridora çıktı. Merdivenleri ikişer ikişer indi. "
                  "Aşağıda kimse yoktu; dışarı fırladı ve arabaya atlayıp yola koyuldu."),
        "bicim": "Öyküleyici anlatım",
        "olcut": ("Olaylar zaman sırasına göre birbirini izliyor; kişi, eylem ve "
                  "akış var."),
    },
    {
        "metin": ("Yükseltinin artmasıyla sıcaklık düzenli olarak azalır. Bunun "
                  "sebebi, havanın yeryüzünden yansıyan ısıyla ısınmasıdır. "
                  "Yerden uzaklaştıkça bu ısı kaynağından da uzaklaşılmış olur."),
        "bicim": "Açıklayıcı anlatım",
        "olcut": ("Bir konu hakkında bilgi veriliyor, sebebi öğretiliyor; "
                  "tartışma ya da savunma yok."),
    },
    {
        "metin": ("Kimileri okumanın artık gereksizleştiğini, her bilginin bir "
                  "tıkla bulunabildiğini söylüyor. Oysa bilgiye ulaşmakla onu "
                  "anlamak aynı şey değildir. Bu görüşü savunanlar, aradaki farkı "
                  "gözden kaçırıyor."),
        "bicim": "Tartışmacı anlatım",
        "olcut": ("Bir görüş aktarılıp çürütülüyor ve karşısına yazarın görüşü "
                  "konuyor."),
    },
]


@bulmaca(ders="edebiyat", konu="anlatim_bicimleri", kademeler=(9, 13))
def anlatim_bicimleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Paragraftan anlatım biçimini tanıma."""
    anlatim = rastgele.choice(_ANLATIMLAR)
    digerleri = [a["bicim"] for a in _ANLATIMLAR if a["bicim"] != anlatim["bicim"]]

    return Bulmaca(
        kod="ede-anlatim-bicimi",
        ders="edebiyat",
        baslik="Rapordaki Paragraf",
        kademe=kademe,
        konu="anlatim_bicimleri",
        kazanim="Anlatım biçimlerini metnin özelliklerinden ayırt etme.",
        dikkat=5,
        brifing=(
            "Arşivde bulunan bir raporun paragrafları türlerine göre "
            "sınıflandırılıyor. Elindeki paragraf şu:\n\n"
            "\"{}\"\n\n"
            "Paragrafın hangi anlatım biçimiyle yazıldığını belirlemen "
            "gerekiyor. Konusu değil, ANLATMA BİÇİMİ soruluyor."
        ).format(anlatim["metin"]),
        kanitlar=[
            Kanit("Paragraf", anlatim["metin"], bedel=1, kritik=True),
            Kanit("Anlatım biçimleri kılavuzu",
                  "ÖYKÜLEYİCİ: Olaylar zaman sırasıyla anlatılır; kişi, eylem, "
                  "akış vardır. \"Sonra, ardından\" gibi bağlantılar bulunur.\n\n"
                  "BETİMLEYİCİ: Görüntü ayrıntılarıyla resmedilir; zaman akmaz, "
                  "olay yoktur. Sıfatlar yoğundur.\n\n"
                  "AÇIKLAYICI: Bilgi verilir, öğretilir. Yazar tarafsızdır, "
                  "kendi görüşünü savunmaz.\n\n"
                  "TARTIŞMACI: Bir görüş çürütülür ve yazarın görüşü savunulur. "
                  "\"Oysa, ancak, ne var ki\" gibi karşıtlık bağlaçları bulunur.",
                  bedel=2, kritik=True),
            Kanit("Ayırt etme notu",
                  "\"Açıklayıcı ile tartışmacıyı karıştırma: ikisi de bilgi "
                  "verebilir, ama tartışmacıda bir KARŞI GÖRÜŞ vardır ve yazar "
                  "onunla hesaplaşır.\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Anlatım biçimini belirlerken hangi soru sorulur?",
                dogru="Metin ne yapıyor: olay mı anlatıyor, görüntü mü çiziyor, bilgi mi veriyor, görüş mü savunuyor.",
                yanlislar={
                    "Metin hangi konuda yazılmış.":
                        "Konuya baktın. Aynı konu betimlemeyle de "
                        "tartışmayla da yazılabilir; belirleyici olan metnin "
                        "NE YAPTIĞI.",
                    "Metin kaç cümleden oluşuyor.":
                        "Uzunluğa baktın. Anlatım biçimi cümle sayısıyla "
                        "belirlenmez.",
                    "Metinde hangi zaman kipi kullanılmış.":
                        "Kip iyi bir ipucudur ama tek başına yetmez; öyküleyici "
                        "olmayan metinler de geçmiş zaman kullanabilir.",
                    "Metin kim tarafından yazılmış.":
                        "Yazara baktın. Aynı yazar farklı anlatım biçimleri "
                        "kullanır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Anlatım biçimi konuyla ilgili değildir: aynı konu (örneğin bir "
                    "koridor) betimlenebilir, öykülenebilir ya da açıklanabilir. "
                    "Belirleyici olan metnin OKUYUCUYA NE YAPTIĞIDIR - gösteriyor mu, "
                    "anlatıyor mu, öğretiyor mu, ikna etmeye mi çalışıyor."
                ),
                ipuclari=[
                    "Metinde zaman akıyor mu, yoksa bir an mı duruyor?",
                    "Yazar bir karşı görüşle hesaplaşıyor mu?",
                ],
                puan=18,
                cozum=(
                    "1) Metinde olay ve zaman akışı var mı? Varsa ÖYKÜLEYİCİ.\n"
                    "2) Zaman durmuş, görüntü ayrıntılanıyorsa BETİMLEYİCİ.\n"
                    "3) Bilgi veriliyor, sebep öğretiliyorsa AÇIKLAYICI.\n"
                    "4) Bir görüş çürütülüp karşısına yazarın görüşü konuyorsa "
                    "TARTIŞMACI.\n\n"
                    "Bu paragrafta: {}\n\nSonuç: {}"
                ).format(anlatim["olcut"], anlatim["bicim"]),
            ),
            secim_adimi(
                soru="Bu paragraf hangi anlatım biçimiyle yazılmıştır?",
                dogru=anlatim["bicim"],
                yanlislar=digerleri + ["Söyleşmeye bağlı anlatım"],
                rastgele=rastgele,
                aciklama=anlatim["olcut"],
                ipuclari=["Kılavuzdaki dört tanımı paragrafla karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Aynı konu farklı anlatım biçimleriyle yazılabilir mi?",
                dogru="Evet; anlatım biçimini konu değil, yazarın amacı belirler.",
                yanlislar={
                    "Hayır; her konunun tek bir uygun anlatım biçimi vardır.":
                        "Konuyu biçime kilitledin. Bir savaş hem "
                        "öyküleyerek hem açıklayarak hem tartışarak "
                        "anlatılabilir.",
                    "Hayır; anlatım biçimi metnin uzunluğuna göre belirlenir.":
                        "Uzunluğu belirleyici saydın. Kısa bir metin de "
                        "tartışmacı olabilir.",
                    "Evet ama yalnızca edebî metinlerde.":
                        "Doğru fikri tek türe hapsettin. Bilgilendirici "
                        "metinlerde de aynı konu farklı biçimlerde yazılır.",
                    "Evet; çünkü anlatım biçimleri arasında fark yoktur.":
                        "Doğru sonuca yanlış gerekçeyle vardın. Biçimler "
                        "arasında fark VAR; aynı konunun farklı biçimlerle "
                        "yazılabilmesi bu farkı ortadan kaldırmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir deprem betimlenebilir (yıkılan duvarlar, toz), öykülenebilir "
                    "(o gece neler oldu), açıklanabilir (fay hattı nasıl kırılır) ya "
                    "da tartışılabilir (yapı denetimi yeterli mi). Konu aynı, amaç "
                    "farklıdır. Bu yüzden soruda konuya bakmak yanıltır."
                ),
                puan=12,
            ),
        ],
        kapanis="Paragraf sınıflandırıldı ve rapor dosyasına eklendi.",
        odul={"itibar": 7},
    )


# ==========================================================================
# NAZIM BİÇİMLERİ
# ==========================================================================

_NAZIMLAR = [
    {
        "ad": "Koşma",
        "ozellikler": (
            "- Nazım birimi: dörtlük\n"
            "- Dörtlük sayısı: 3-5\n"
            "- Ölçü: hece ölçüsü, 11'li (6+5 ya da 4+4+3)\n"
            "- Kafiye düzeni: abab / cccb / dddb\n"
            "- Son dörtlükte şairin adı (mahlas) geçiyor\n"
            "- Konu: sevgi, doğa, ayrılık"
        ),
        "olcut": ("Dörtlük + 11'li hece ölçüsü + son dörtlükte mahlas: bu üçlü "
                  "yalnızca koşmada bir arada bulunur."),
    },
    {
        "ad": "Mani",
        "ozellikler": (
            "- Nazım birimi: tek dörtlük\n"
            "- Ölçü: hece ölçüsü, 7'li\n"
            "- Kafiye düzeni: aaxa (üçüncü dize serbest)\n"
            "- İlk iki dize doldurma, asıl anlam son iki dizede\n"
            "- Söyleyeni belli değil (anonim)"
        ),
        "olcut": ("Tek dörtlük + 7'li hece + aaxa düzeni + anonim olması "
                  "maniyi tanımlar."),
    },
    {
        "ad": "Gazel",
        "ozellikler": (
            "- Nazım birimi: beyit\n"
            "- Beyit sayısı: 5-15\n"
            "- Ölçü: aruz ölçüsü\n"
            "- Kafiye düzeni: aa / ba / ca / da\n"
            "- Son beyitte şairin mahlası bulunur\n"
            "- Konu: aşk, güzellik, şarap"
        ),
        "olcut": ("Beyit birimi + aruz ölçüsü + aa/ba/ca kafiye düzeni gazeli "
                  "tanımlar; dörtlük ve hece ölçüsü kullanılmaz."),
    },
]


@bulmaca(ders="edebiyat", konu="nazim_bicimleri", kademeler=(10, 13))
def nazim_bicimleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Verilen özelliklerden nazım biçimini tanıma."""
    nazim = rastgele.choice(_NAZIMLAR)
    digerleri = [n["ad"] for n in _NAZIMLAR if n["ad"] != nazim["ad"]]

    return Bulmaca(
        kod="ede-nazim-bicimi",
        ders="edebiyat",
        baslik="İnceleme Fişi",
        kademe=kademe,
        konu="nazim_bicimleri",
        kazanim="Nazım biçimlerini yapı özelliklerinden ayırt etme.",
        dikkat=5,
        brifing=(
            "Arşivdeki bir şiirin inceleme fişi doldurulmuş ama en üstteki "
            "\"nazım biçimi\" hanesi boş bırakılmış. Fişte şunlar yazıyor:\n\n"
            "{}\n\n"
            "Şiirin kendisi kayıp; elimizde yalnızca bu fiş var. Yine de nazım "
            "biçimini belirleyebiliriz: bu özellikler bir arada yalnızca tek bir "
            "biçimde bulunur."
        ).format(nazim["ozellikler"]),
        kanitlar=[
            Kanit("İnceleme fişi", nazim["ozellikler"], bedel=1, kritik=True),
            Kanit("Nazım biçimleri çizelgesi",
                  "KOŞMA (Halk edebiyatı): dörtlük, 11'li hece, abab-cccb-dddb, "
                  "son dörtlükte mahlas.\n\n"
                  "MANİ (Halk edebiyatı, anonim): tek dörtlük, 7'li hece, aaxa.\n\n"
                  "GAZEL (Divan edebiyatı): beyit, aruz ölçüsü, aa-ba-ca-da, "
                  "son beyitte mahlas.\n\n"
                  "SEMAİ (Halk edebiyatı): dörtlük, 8'li hece.",
                  bedel=2, kritik=True),
            Kanit("Ayırt etme notu",
                  "\"İlk bakılacak yer NAZIM BİRİMİDİR: dörtlük mü beyit mi? "
                  "Beyitse Divan edebiyatındasın, dörtlükse Halk edebiyatında. "
                  "Sonra ölçüye bak: hece mi aruz mu?\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Nazım biçimini belirlemeye nereden başlanır?",
                dogru="Nazım biriminden: dörtlük mü beyit mi olduğuna bakılır, sonra ölçüye geçilir.",
                yanlislar={
                    "Şiirin konusundan.":
                        "Konudan başladın. Aynı konu farklı nazım biçimleriyle "
                        "yazılır; ilk bakılacak şey birim ve UYAK DÜZENİ.",
                    "Şiirin uzunluğundan.":
                        "Uzunluktan başladın. Uzunluk ipucu verir ama "
                        "belirleyici olan dizelerin nasıl kümelendiği.",
                    "Şairin yaşadığı yüzyıldan.":
                        "Tarihten başladın. Yüzyıl olasılıkları daraltır ama "
                        "biçimi şiirin kendi yapısı söyler.",
                    "Şiirde geçen sözcüklerin sayısından.":
                        "Sözcük saydın. Nazım biçimini belirleyen şey sözcük "
                        "değil, dize ve uyak düzeni.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Nazım birimi tek başına havuzu ikiye böler: beyit kullanan "
                    "biçimler Divan edebiyatına (gazel, kaside), dörtlük kullananlar "
                    "Halk edebiyatına (koşma, mani, semai) aittir. Ölçü ikinci "
                    "eleyicidir: aruz Divan'a, hece Halk'a işaret eder. Konu ise en "
                    "zayıf ölçüttür; aşk her iki gelenekte de işlenir."
                ),
                ipuclari=[
                    "Fişte \"nazım birimi\" satırına bak.",
                    "Dörtlükse hangi gelenek, beyitse hangi gelenek?",
                ],
                puan=18,
                cozum=(
                    "1) Nazım birimi: dörtlük -> Halk edebiyatı, beyit -> Divan.\n"
                    "2) Ölçü: hece -> Halk, aruz -> Divan (birinci adımı doğrular).\n"
                    "3) Hece sayısı ve kafiye düzeniyle daralt:\n"
                    "   - 11'li + abab/cccb + mahlas -> Koşma\n"
                    "   - 7'li + aaxa + anonim + tek dörtlük -> Mani\n"
                    "   - aruz + aa/ba/ca + mahlas -> Gazel\n"
                    "4) Bu fişte: {}\n\n"
                    "Sonuç: {}"
                ).format(nazim["olcut"], nazim["ad"]),
            ),
            secim_adimi(
                soru="Bu fiş hangi nazım biçimine aittir?",
                dogru=nazim["ad"],
                yanlislar=digerleri + ["Semai", "Kaside"],
                rastgele=rastgele,
                aciklama=nazim["olcut"],
                ipuclari=["Çizelgedeki satırları fişle tek tek karşılaştır."],
                puan=18,
            ),
            yorum_adimi(
                soru="Şiirin konusu neden nazım biçimini belirlemekte zayıf bir ölçüttür?",
                dogru="Aynı konu farklı geleneklerde ve farklı biçimlerde işlenebildiği için.",
                yanlislar={
                    "Şiirlerin konusu genellikle belirsiz olduğu için.":
                        "Konuyu belirsiz saydın. Çoğu şiirin konusu bellidir; "
                        "sorun konunun birden çok biçimde işlenebilmesi.",
                    "Konu her zaman son dörtlükte açıklandığı için.":
                        "Böyle bir kural yok ve olsa bile nazım biçimini "
                        "belirlemezdi.",
                    "Nazım biçimlerinin konusu yoktur.":
                        "Çok ileri gittin. Bazı biçimler belirli konularla "
                        "anılır; zayıflığı budur ki bu bir zorunluluk değil.",
                    "Konu yalnızca Divan edebiyatında önemlidir.":
                        "Ayrımı edebiyat dönemine bağladın. Konu her dönemde "
                        "vardır; her dönemde de tek başına biçimi belirlemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aşk hem koşmanın hem gazelin konusudur; bu yüzden \"aşk "
                    "anlatılıyorsa gazeldir\" gibi bir kestirme yol yanıltır. Yapı "
                    "özellikleri (birim, ölçü, kafiye düzeni) ise biçimden biçime "
                    "değişir ve kesin ayrım sağlar."
                ),
                puan=12,
            ),
        ],
        kapanis="Fişin boş hanesi dolduruldu: {}.".format(nazim["ad"]),
        odul={"itibar": 7},
    )
