# -*- coding: utf-8 -*-
"""
Telsiz mesaj suzgeci. SAF Python: sunucu (araclar/sinif_sunucusu.py) ve
istemci (terminal, Pyodide) ayni dosyayi kullanir; agdan, dosyadan
(istege bagli yasak listesi disinda) ve oyun durumundan habersizdir.

NEDEN VAR
---------
Telsiz'i kullananlar reşit degil. Uc sey ENGELLENIR, mesaj hic gonderilmez
ve gondericiye nedeni soylenir:

  1. Kisisel bilgi: telefon (TR biçimleri), e-posta, @kullanici, baglanti
     (URL), TC kimlik no (sağlama toplamli), IBAN, adres ipuclari,
     sosyal medya hesabi paylasma/isteme.
  2. Uygunsuz soz: kisa bir Turkce liste (telsiz_sozcukler.py + okulun kendi
     `kayitlar/telsiz_yasak.txt` dosyasi).

SINIRLARI (durust olalim)
-------------------------
Bu bir SUZGEC, kalkan degil. "s1kt1r" gibi harf degisimlerini yakalariz;
ama baska dilde kufru ya da cok ustu kapali bir numarayi gecirebilir.
Bu yuzden her mesajda "bildir" dugmesi ve ogretmenin kanallari gormesi var;
suzgec ilk savunma, tek degil. Yanlis pozitif de pahali (ogrenci
kullanmaz); "3,14", "x=5", "amino asit", "147.250" gibi masum metinler
testle SUZULMEZ diye sabitlendi.
"""
from __future__ import annotations

import os
import re
from collections import namedtuple
from typing import Dict, Tuple

from . import telsiz_sozcukler as _liste

Sonuc = namedtuple("Sonuc", "ok tur neden uyari")

TUR_KISISEL = "kisisel"
TUR_UYGUNSUZ = "uygunsuz"

_UYARI_KISISEL = {
    "telefon": "Telefon numarası paylaşılmaz.",
    "eposta": "E-posta adresi paylaşılmaz.",
    "kullanici": "Sosyal medya kullanıcı adı paylaşılmaz.",
    "sosyal": "Sosyal medya hesabı paylaşılmaz ya da istenmez.",
    "baglanti": "Bağlantı (internet adresi) paylaşılmaz.",
    "tc": "Kimlik numarası paylaşılmaz.",
    "iban": "Banka bilgisi paylaşılmaz.",
    "adres": "Ev ya da okul adresi paylaşılmaz.",
}
UYARI_UYGUNSUZ = "Bu söz Telsiz'de kullanılamaz. Nazik bir dille yeniden yaz."
UYARI_SON = " Mesajın gönderilmedi."

# ------------------------------------------------------------ normallestirme
_ASCII = str.maketrans({"ç": "c", "ğ": "g", "ı": "i", "ö": "o", "ş": "s", "ü": "u",
                        "â": "a", "î": "i", "û": "u"})
_LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s",
                       "7": "t", "@": "a", "$": "s", "!": "i"})


def kucuk(metin: str) -> str:
    """Turkce kucuk harf (I->ı, İ->i); Python'un varsayilani bunu bozar."""
    return (metin or "").replace("İ", "i").replace("I", "ı").lower()


def _ascii(metin: str) -> str:
    return kucuk(metin).translate(_ASCII)


def _tekrar_sil(s: str) -> str:
    return re.sub(r"(.)\1+", r"\1", s)


_HARF = r"[^\W\d_]"
_AYIRICILI = re.compile(r"(?<!" + _HARF + r")(?:" + _HARF + r"[\s.\-_*]+){3,}" + _HARF + r"(?!" + _HARF + r")")


def _kelime_normal(metin: str) -> str:
    """Kufur denetimi icin: ASCII, leet cozulmus, tekrarsiz, ayirici birlesik."""
    s = _ascii(metin)
    s = _AYIRICILI.sub(lambda m: re.sub(r"[\s.\-_*]+", "", m.group(0)), s)
    parca = []
    for belirtec in re.findall(r"[a-z0-9@$!]+", s):
        if re.search(r"[a-z]", belirtec):
            belirtec = belirtec.translate(_LEET)
        parca.append(_tekrar_sil(re.sub(r"[^a-z0-9]", "", belirtec)))
    return " ".join(p for p in parca if p)


# ------------------------------------------------------------ yasak listeleri
def _liste_kur() -> Tuple[frozenset, Tuple[str, ...], Tuple[str, ...]]:
    tam = frozenset(_tekrar_sil(s) for s in _liste.TAM)
    onek = tuple(_tekrar_sil(s) for s in _liste.ONEK)
    ibare = tuple(_tekrar_sil(s) for s in _liste.IBARE)
    return tam, onek, ibare


_TAM, _ONEK, _IBARE = _liste_kur()
_EK_ONBELLEK: Dict[str, Tuple[float, frozenset, Tuple[str, ...]]] = {}


def ek_sozcukler(yol: str) -> Tuple[frozenset, Tuple[str, ...]]:
    """Okulun kendi listesi: her satira bir sozcuk; '#' yorum; sonu '*' = onek."""
    if not yol:
        return frozenset(), ()
    try:
        zaman = os.path.getmtime(yol)
    except OSError:
        return frozenset(), ()
    kayit = _EK_ONBELLEK.get(yol)
    if kayit and kayit[0] == zaman:
        return kayit[1], kayit[2]
    tam, onek = set(), []
    try:
        with open(yol, encoding="utf-8") as d:
            for satir in d:
                satir = satir.split("#", 1)[0].strip()
                if not satir:
                    continue
                if satir.endswith("*") and len(satir) > 4:
                    onek.append(_tekrar_sil(_kelime_normal(satir[:-1]).replace(" ", "")))
                else:
                    tam.add(_tekrar_sil(_kelime_normal(satir).replace(" ", "")))
    except (OSError, UnicodeDecodeError):
        return frozenset(), ()
    _EK_ONBELLEK[yol] = (zaman, frozenset(tam), tuple(onek))
    return frozenset(tam), tuple(onek)


def uygunsuz(metin: str, ek_dosya: str = "") -> bool:
    normal = _kelime_normal(metin)
    if not normal:
        return False
    ek_tam, ek_onek = ek_sozcukler(ek_dosya)
    tam = _TAM | ek_tam
    onek = _ONEK + ek_onek
    for b in normal.split():
        if b in tam or any(b.startswith(o) for o in onek):
            return True
    dolgu = " " + normal + " "
    for ib in _IBARE:
        if re.search(r"(?<![a-z])" + re.escape(ib), dolgu):
            return True
    return False


# ------------------------------------------------------------ kisisel bilgi
_ADAY_TELEFON = re.compile(r"(?<![\w.,])(?:\+\s*)?\d(?:[\s.\-()/]*\d){9,12}(?!\d)")
_TELEFON_BICIMLERI = {
    (3, 3, 2, 2), (3, 3, 4), (4, 3, 2, 2), (4, 3, 4), (3, 7), (4, 7), (4, 3, 3),
    (2, 3, 3, 2, 2), (2, 3, 7), (1, 3, 3, 2, 2), (1, 3, 7),
}
_RAKAM_SOZ = {"sifir", "bir", "iki", "uc", "dort", "bes", "alti", "yedi", "sekiz", "dokuz"}
_EPOSTA = re.compile(
    r"[\w.%+\-]{2,}\s*(?:@|\(\s*at\s*\)|\[\s*at\s*\])\s*[\w\-]+"
    r"(?:\s*(?:\.|\(\s*nokta\s*\)|\bnokta\b|\bdot\b)\s*[a-z]{2,})+")
_EPOSTA_AT = re.compile(r"\b[\w.]{3,}\s+at\s+(?:gmail|hotmail|outlook|yahoo|yandex|icloud)\b")
_KULLANICI = re.compile(r"(?<![\w@])@[\w.]{3,30}")
_BAGLANTI = re.compile(
    r"(?:https?://|www\.)\S+|"
    r"\b[\w\-]+\.(?:com|net|org|edu|io|me|gg|ly|tv|xyz|info|app|link|tr)\b")
_IBAN = re.compile(r"\btr\s?\d{2}(?:\s?\d{4}){5}\s?\d{2}\b")
_SOSYAL = re.compile(r"\b(?:insta(?:gram)?|snap(?:chat)?|tik\s?tok|whats?app|discord|"
                     r"telegram|twitter|facebook|ask\.?fm)\b")
_SOSYAL_ISTEK = {"adim", "adresim", "ismim", "hesabim", "hesabimi", "hesap", "kullanici",
                 "nick", "nickim", "numaram", "numara", "ekle", "ekleyin", "bul", "yaz",
                 "ara", "takip"}
_SOKAK = re.compile(r"\b(?:mahalle(?:si|sinde|m)?|mah|sokak(?:i|ta)?|cadde(?:si|sinde)?|"
                    r"bulvar(?:i)?|apartman(?:i)?|apt)\b")
_NO_IPUCU = re.compile(r"\bno\s*[:.]?\s*\d+|\bdaire\b|\bkat\s*[:.]?\s*\d+|\b\d+\s*/\s*\d+\b")
_OTURMA = {"oturuyorum", "oturuyoruz", "evim", "evimiz", "adresim", "adresimiz",
           "yasiyorum", "yasiyoruz", "evimin"}


def _tc_gecerli(d: str) -> bool:
    if len(d) != 11 or d[0] == "0" or not d.isdigit():
        return False
    s = [int(c) for c in d]
    d10 = ((s[0] + s[2] + s[4] + s[6] + s[8]) * 7 - (s[1] + s[3] + s[5] + s[7])) % 10
    return s[9] == d10 and s[10] == sum(s[:10]) % 10


def _telefon_mu(d: str) -> bool:
    if len(d) == 12 and d.startswith("90"):
        d = "0" + d[2:]
    if re.fullmatch(r"0?5\d{9}", d):
        return True
    if re.fullmatch(r"0[2-4]\d{9}", d):
        return True
    return bool(re.fullmatch(r"0?85\d{8}|08[05]0\d{7}", d))


def kisisel_bilgi(metin: str) -> str:
    """Kisisel bilgi turu ('telefon', 'eposta', ...) ya da '' (yoksa)."""
    ham = kucuk(metin or "")
    if not ham.strip():
        return ""
    ascii_ = _ascii(metin).replace("'", " ").replace("’", " ")
    for m in _ADAY_TELEFON.finditer(ham):
        aday = m.group(0)
        d = re.sub(r"\D", "", aday)
        gruplar = tuple(len(g) for g in re.findall(r"\d+", aday))
        surekli = len(gruplar) == 1
        sekilli = (surekli or gruplar in _TELEFON_BICIMLERI
                   or (len(gruplar) >= 10 and set(gruplar) == {1}))
        if not sekilli:
            continue
        if surekli and _tc_gecerli(d):
            return "tc"
        if _telefon_mu(d):
            return "telefon"
    # Rakamlarin sozcukle yazilmasi ("sifir bes uc iki ...")
    kosu = 0
    for b in re.findall(r"[a-z]+", ascii_):
        kosu = kosu + 1 if b in _RAKAM_SOZ else 0
        if kosu >= 10:
            return "telefon"
    if _EPOSTA.search(ham) or _EPOSTA_AT.search(ascii_):
        return "eposta"
    if _IBAN.search(ham):
        return "iban"
    if _BAGLANTI.search(ham):
        return "baglanti"
    if _KULLANICI.search(ham):
        return "kullanici"
    sozcukler = set(re.findall(r"[a-z]+", ascii_))
    if _SOSYAL.search(ascii_) and (sozcukler & _SOSYAL_ISTEK or re.search(r"[:=]", ham)):
        return "sosyal"
    if _SOKAK.search(ascii_) and (_NO_IPUCU.search(ascii_) or sozcukler & _OTURMA):
        return "adres"
    if re.search(r"\badres(?:im|imiz)?\s*[:=]", ascii_):
        return "adres"
    return ""


# ------------------------------------------------------------ ana giris
def temizle(metin: str) -> str:
    """Kontrol karakterlerini atar, bosluklari tek bosluga indirir."""
    s = re.sub(r"[\x00-\x08\x0b-\x1f\x7f​-‏‪-‮⁦-⁩]", "", str(metin or ""))
    return re.sub(r"[ \t\r\n]+", " ", s).strip()


def incele(metin: str, ek_dosya: str = "") -> Sonuc:
    """Mesaj gonderilebilir mi? Sonuc(ok, tur, neden, uyari)."""
    temiz = temizle(metin)
    if not temiz:
        return Sonuc(False, "bos", "bos", "Boş mesaj gönderilemez.")
    tur = kisisel_bilgi(temiz)
    if tur:
        return Sonuc(False, TUR_KISISEL, tur, _UYARI_KISISEL[tur] + UYARI_SON)
    if uygunsuz(temiz, ek_dosya):
        return Sonuc(False, TUR_UYGUNSUZ, "uygunsuz", UYARI_UYGUNSUZ + UYARI_SON)
    return Sonuc(True, "", "", "")


def takma_ad_uygun_mu(ad: str, ek_dosya: str = "") -> bool:
    """Takma ad olarak kullanilabilir mi (kisisel bilgi/kufur icermesin)."""
    return incele(ad, ek_dosya).ok
