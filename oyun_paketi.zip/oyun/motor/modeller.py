# -*- coding: utf-8 -*-
"""
Bulmaca veri modeli.

Bu dosya oyunun pedagojik omurgasıdır. Klasik soru bankalarından farkı şu:
bir bulmaca "x + 12 = y, x kaçtır?" diye sormaz. Bunun yerine üç katman kurar:

    1) BRIFING  - olay anlatılır, ama hangi büyüklüklerin bilinmediği söylenmez.
    2) KANITLAR - oyuncu defterleri, tanıkları, ölçümleri tek tek inceler.
                  Her inceleme "dikkat" harcar; yani hepsini açmak bedava değil.
    3) ADIMLAR  - önce MODELLEME adımı ("olayı hangi bağıntı anlatıyor?"),
                  sonra ÇÖZÜM adımı ("o hâlde sayı kaç?"), gerekirse YORUM adımı
                  ("bu sonuç üsse ne söyler?").

Modelleme adımı bu oyunun ayırt edici yeri: öğrenci denklemi kendisi seçer.
Yanlış modeli seçip doğru sayıyı bulmak mümkün değildir.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# Kademe haritası: oyunun "sınıf" ölçeği.
#   1-4  ilkokul, 5-8 ortaokul, 9-12 lise, 13 üniversite
KADEME_ADLARI = {
    1: "1. Sınıf", 2: "2. Sınıf", 3: "3. Sınıf", 4: "4. Sınıf",
    5: "5. Sınıf", 6: "6. Sınıf", 7: "7. Sınıf", 8: "8. Sınıf",
    9: "9. Sınıf", 10: "10. Sınıf", 11: "11. Sınıf", 12: "12. Sınıf",
    13: "Üniversite",
}

KADEME_KUSAGI = {
    "ilkokul": (1, 4),
    "ortaokul": (5, 8),
    "lise": (9, 12),
    "universite": (13, 13),
}

# Oyuncunun gördüğü tek seviye ölçeği. İçerideki 1..13 kademe değerleri,
# mevcut binlerce görevin hangi yaşta anlaşılır olduğunu korumak için kalır;
# arayüzde sınıf ve sınav adı yerine bu beş basamak gösterilir.
ZORLUKLAR = [1, 2, 3, 4, 5]
ZORLUK_ADLARI = {
    1: "Keşif",
    2: "Temel",
    3: "Gelişen",
    4: "İleri",
    5: "Ustalık",
}
ZORLUK_ACIKLAMALARI = {
    1: "somut örnekler, kısa adımlar ve yoğun destek",
    2: "gündelik ilişkiler ve temel çıkarımlar",
    3: "birden fazla bilgiyi birleştirme",
    4: "soyut modelleme ve ayrıntılı yorum",
    5: "karmaşık, disiplinler arası görevler",
}
ZORLUK_KADEME = {1: 2, 2: 5, 3: 8, 4: 11, 5: 13}


def kademe_zorlugu(kademe: int) -> int:
    """Eski/iç kademe değerini oyuncuya görünen 1..5 zorluğa çevirir."""
    if kademe <= 3:
        return 1
    if kademe <= 6:
        return 2
    if kademe <= 9:
        return 3
    if kademe <= 12:
        return 4
    return 5

# --------------------------------------------------------------------------
# Alan tanımları
# --------------------------------------------------------------------------
#
# Oyuna yeni bir ders eklemenin TEK yeri burasıdır - meslek dersleri dahil.
# Bir satır eklemek yeterli: ders listesi, öğrenme yolu, rapor kısaltmaları,
# üssün içindeki birim adı ve ekran rengi hep bu tablodan türer. Aşağıdaki
# sözlüklerin hiçbirine elle dokunulmaz.
#
#   ad         : akademik ad - öğretmen raporunda ve karnede görünür
#   birim      : üssün kendi dili - oyuncunun ekranda gördüğü ad
#   birim_kisa : dar tablolarda birim adının kısası
#   kisa       : rapor sütunu için üç harflik kısaltma
#   renk       : terminal.RENKLER içindeki bir ad (aynı renk tekrar edebilir)
#   yol        : YOL_TANIMLARI içindeki öğrenme yolu kodu
#
# Yeni bir meslek dersi eklemek için: buraya bir satır, oyun/icerik altına da
# aynı `ders=` koduyla bir modül. Ayrıntı: ICERIK_EKLEME.md

ALAN_TANIMLARI = {
    "turkce": {
        "ad": "Türkçe", "birim": "Yazı İşleri", "birim_kisa": "Yazı",
        "kisa": "Tür", "renk": "acik_cam", "yol": "dil_anlatim",
    },
    "matematik": {
        "ad": "Matematik", "birim": "Sayım ve Depo", "birim_kisa": "Depo",
        "kisa": "Mat", "renk": "acik_mavi", "yol": "sayilar_duzen",
    },
    "fen": {
        "ad": "Fen Bilimleri", "birim": "Laboratuvar", "birim_kisa": "Lab",
        "kisa": "Fen", "renk": "acik_mor", "yol": "doga_yasam",
    },
    # Fen Bilimleri ortaokulun bütünleşik dersidir ve öyle kalır. Lisede aynı
    # konu üç ayrı derse ayrılır; Tarih'ten İnkılap'ın, Türkçe'den Edebiyat'ın
    # ayrılmasıyla aynı desen. Üçü de Fen'le aynı yolda (doga_yasam) durur,
    # yalnızca içerikleri üst kademelere (9-13) yazılır.
    "biyoloji": {
        "ad": "Biyoloji", "birim": "Canlılar Bölmesi", "birim_kisa": "Canlı",
        "kisa": "Biy", "renk": "acik_yesil", "yol": "doga_yasam",
    },
    "fizik": {
        "ad": "Fizik", "birim": "Kuvvet Atölyesi", "birim_kisa": "Kuvvet",
        "kisa": "Fiz", "renk": "acik_mavi", "yol": "doga_yasam",
    },
    "kimya": {
        "ad": "Kimya", "birim": "Tepkime Masası", "birim_kisa": "Tepkime",
        "kisa": "Kim", "renk": "acik_mor", "yol": "doga_yasam",
    },
    "tarih": {
        "ad": "Tarih", "birim": "Kronograf Arşivi", "birim_kisa": "Arşiv",
        "kisa": "Tar", "renk": "acik_sari", "yol": "insan_toplum",
    },
    "cografya": {
        "ad": "Coğrafya", "birim": "Arazi ve Keşif", "birim_kisa": "Arazi",
        "kisa": "Coğ", "renk": "acik_yesil", "yol": "doga_yasam",
    },
    "edebiyat": {
        "ad": "Edebiyat", "birim": "Kütüphane", "birim_kisa": "Kitap",
        "kisa": "Ede", "renk": "camgobegi", "yol": "dil_anlatim",
    },
    "felsefe": {
        "ad": "Felsefe", "birim": "Şura Odası", "birim_kisa": "Şura",
        "kisa": "Fel", "renk": "mor", "yol": "insan_toplum",
    },
    "din_kulturu": {
        "ad": "Din Kültürü", "birim": "Kültür ve İnanç Masası",
        "birim_kisa": "Kültür", "kisa": "Din", "renk": "sari",
        "yol": "insan_toplum",
    },
    "vatandaslik": {
        "ad": "Vatandaşlık", "birim": "Yönetmelik Masası", "birim_kisa": "Yönt.",
        "kisa": "Vat", "renk": "mavi", "yol": "insan_toplum",
    },
    "inkilap": {
        "ad": "İnkılap Tarihi", "birim": "Yakın Tarih Arşivi",
        "birim_kisa": "Tarih", "kisa": "İnk", "renk": "kirmizi",
        "yol": "insan_toplum",
    },
    "ingilizce": {
        "ad": "İngilizce", "birim": "Dış Yazışma", "birim_kisa": "Dış",
        "kisa": "İng", "renk": "yesil", "yol": "dil_anlatim",
    },
    "mantik": {
        "ad": "Muhakeme", "birim": "Şifre Odası", "birim_kisa": "Şifre",
        "kisa": "Muh", "renk": "beyaz", "yol": "sayilar_duzen",
    },
    # ---- meslek dalları ----
    # Alan = meslek DALI (öğrencinin kendi bölümü), etiket = ortak ÇEKİRDEK.
    # Bir görev birden çok dalda geçerliyse üst üste iki @bulmaca ile iki dala
    # birden kaydedilir; içerik bir kez yazılır. Ayrıntı: TASARIM_NOTLARI.md
    "bilisim": {
        "ad": "Bilişim Teknolojileri", "birim": "Telsiz ve Veri Odası",
        "birim_kisa": "Veri", "kisa": "Bil", "renk": "acik_yesil",
        "yol": "meslek_uretim",
    },
    "elektrik": {
        "ad": "Elektrik-Elektronik", "birim": "Enerji Hattı",
        "birim_kisa": "Hat", "kisa": "Elk", "renk": "acik_sari",
        "yol": "meslek_uretim",
    },
    "makine": {
        "ad": "Makine ve Tasarım", "birim": "Makine Dairesi",
        "birim_kisa": "Makine", "kisa": "Mak", "renk": "acik_mavi",
        "yol": "meslek_uretim",
    },
    "mobilya": {
        "ad": "Mobilya ve İç Mekân", "birim": "Marangozhane",
        "birim_kisa": "Ahşap", "kisa": "Mob", "renk": "camgobegi",
        "yol": "meslek_uretim",
    },
}

# Meslek dallarını birbirine bağlayan ortak beceri çekirdekleri. Görev
# üreticileri bunlarla etiketlenir; ittifak eşleştirmesi "aynı çekirdeği
# paylaşan farklı dal" kuralıyla buradan çalışacak. Bkz. TASARIM_NOTLARI.md
MESLEK_CEKIRDEKLERI = {
    "birim_cevirme": "Ölçü ve birim çevirme",
    "oran_olcek": "Oran, ölçek ve karışım",
    "guc_verim": "Güç, iş ve verim",
    "maliyet_fire": "Maliyet ve fire",
    "sira_prosedur": "Sıra, prosedür ve güvenlik",
    "tolerans": "Ölçüm hatası ve tolerans",
}

# --------------------------------------------------------------------------
# Öğrenme yolları
# --------------------------------------------------------------------------
#
# Ders adları arayüzden kaldırıldı; oyuncu ekranda "Matematik" değil "Sayım ve
# Depo" görür. Sebep basit: ekranda ders adı gördüğü anda oyun oynadığını değil
# ödev yaptığını sanıyor ve kapatıyor. Akademik adlar veride durur; öğretmen
# raporunda ve karnede kullanılır.
#
# `secmeli` olan yollar herkese açılmaz: meslek dersleri yalnızca o bölümün
# öğrencisini ilgilendirir, ortaokul öğrencisinin karnesini kalabalıklaştırmaz.

YOL_TANIMLARI = {
    "dil_anlatim": {
        "ad": "Dil ve Anlatım",
        "aciklama": "anlama, yorumlama ve kendini doğru ifade etme",
    },
    "sayilar_duzen": {
        "ad": "Sayılar ve Düzen",
        "aciklama": "örüntüleri fark etme, ilişki kurma ve hesaplama",
    },
    "doga_yasam": {
        "ad": "Doğa ve Yaşam",
        "aciklama": "doğal olayları, canlıları ve çevreyi anlama",
    },
    "insan_toplum": {
        "ad": "İnsan ve Toplum",
        "aciklama": "olayları, düşünceleri ve toplumsal düzeni yorumlama",
    },
    "meslek_uretim": {
        "ad": "Meslek ve Üretim",
        "aciklama": "bir işi kurallarına göre planlama, ölçme ve teslim etme",
        "secmeli": True,
    },
}

# --------------------------------------------------------------------------
# Tablodan türeyenler - elle düzenlenmez
# --------------------------------------------------------------------------

DERSLER = list(ALAN_TANIMLARI)
DERS_ADLARI = {kod: bilgi["ad"] for kod, bilgi in ALAN_TANIMLARI.items()}
BIRIM_ADLARI = {kod: bilgi["birim"] for kod, bilgi in ALAN_TANIMLARI.items()}
BIRIM_KISA = {kod: bilgi["birim_kisa"] for kod, bilgi in ALAN_TANIMLARI.items()}
DERS_KISA = {kod: bilgi["kisa"] for kod, bilgi in ALAN_TANIMLARI.items()}
# Derslerin renk imzaları - oyuncu hangi masada olduğunu renkten de anlasın.
DERS_RENGI = {kod: bilgi["renk"] for kod, bilgi in ALAN_TANIMLARI.items()}

OGRENME_YOLLARI = {
    yol_kodu: {
        "ad": bilgi["ad"],
        "aciklama": bilgi["aciklama"],
        "secmeli": bool(bilgi.get("secmeli")),
        "alanlar": [kod for kod, alan in ALAN_TANIMLARI.items()
                    if alan["yol"] == yol_kodu],
    }
    for yol_kodu, bilgi in YOL_TANIMLARI.items()
}

# Tanım tablosundaki bir yazım hatası oyunu sessizce bozmasın: alanı olmayan
# yol ya da yolu olmayan alan, oyun açılırken değil, içe aktarılırken patlasın.
_yolsuz = [kod for kod, alan in ALAN_TANIMLARI.items()
           if alan["yol"] not in YOL_TANIMLARI]
if _yolsuz:
    raise ValueError("Tanımsız öğrenme yolu kullanan alanlar: {}".format(_yolsuz))


def birim_adi(ders: str) -> str:
    return BIRIM_ADLARI.get(ders, DERS_ADLARI.get(ders, ders))


def birim_kisa(ders: str) -> str:
    return BIRIM_KISA.get(ders, ders[:4])


def yol_alanlari(yol_kodu: str) -> List[str]:
    return list(OGRENME_YOLLARI.get(yol_kodu, {}).get("alanlar", []))


def alan_yolu(ders: str) -> str:
    """Bir alanın hangi öğrenme yolunda göründüğü."""
    return ALAN_TANIMLARI.get(ders, {}).get("yol", "")


def secmeli_yol_mu(yol_kodu: str) -> bool:
    """Meslek dersleri gibi, herkese açılmayan yollar."""
    return bool(OGRENME_YOLLARI.get(yol_kodu, {}).get("secmeli"))

# Adım türleri
SECIM = "secim"        # tek doğru şıklı seçim
COKLU = "coklu"        # birden çok doğru şık (hepsi bulunmalı)
SAYI = "sayi"          # sayısal cevap (tolerans ile)
METIN = "metin"        # serbest metin (Türkçe duyarlı karşılaştırma)
SIRALA = "sirala"      # verilenleri doğru sıraya dizme
ESLESTIR = "eslestir"  # ikili eşleştirme

# --------------------------------------------------------------------------
# Öğretim aşamaları
# --------------------------------------------------------------------------
#
# Bir konu üç aşamada öğretilir. Aynı görev üreticisi üç aşamada da kullanılır
# ama her seferinde YENİ SAYILARLA üretilir; böylece öğrenci ezberlediği için
# değil, anladığı için ilerler.
#
#   ANLATIM   : Görev çözülmüş hâlde gösterilir. Öğrenci cevap vermez, izler.
#   BİRLİKTE  : Yeni bir örnek. Oyun her adımda yolu gösterir, kararı öğrenci
#               verir. Yanlış cevabın bedeli yoktur; doğru bulunana kadar
#               yardım artar.
#   SERBEST   : Öğrenci tek başına çözer. Puan burada anlam kazanır.

ANLATIM = "anlatim"
BIRLIKTE = "birlikte"
SERBEST = "serbest"

ASAMALAR = [ANLATIM, BIRLIKTE, SERBEST]

ASAMA_ADLARI = {
    ANLATIM: "Nasıl yapılıyor",
    BIRLIKTE: "Yanındayım",
    SERBEST: "Sen hallet",
}

ASAMA_ACIKLAMALARI = {
    ANLATIM: ("Bu işi daha önce yapan biri aynısını senin için baştan sona "
              "yapıyor. Sen izle; cevap vermen gerekmiyor."),
    BIRLIKTE: ("Aynı iş, başka sayılarla. Nasıl ilerleyeceğimizi sen söyle - "
               "takılırsan yanındayım, yanlışın bir bedeli yok."),
    SERBEST: ("Bu dosya sende. Takılırsan yardım isteyebilirsin ama istemen "
              "gerekiyor."),
}

ASAMA_SIMGESI = {
    ANLATIM: "1",
    BIRLIKTE: "2",
    SERBEST: "3",
}


def sonraki_asama(asama: str) -> str:
    """Bir üst aşamayı döner; en üstteyse aynısını döner."""
    if asama not in ASAMALAR:
        return ANLATIM
    sira = ASAMALAR.index(asama)
    return ASAMALAR[min(sira + 1, len(ASAMALAR) - 1)]


def onceki_asama(asama: str) -> str:
    """Bir alt aşamayı döner; en alttaysa aynısını döner."""
    if asama not in ASAMALAR:
        return ANLATIM
    sira = ASAMALAR.index(asama)
    return ASAMALAR[max(sira - 1, 0)]


# Adım rolleri
MODEL = "model"    # "olayı hangi bağıntı anlatıyor?"
COZUM = "cozum"    # "o hâlde sayı/cevap nedir?"
YORUM = "yorum"    # "bu sonuç ne anlama geliyor?"

ROL_ETIKETI = {
    MODEL: "KARAR",
    COZUM: "İŞLEM",
    YORUM: "DEĞERLENDİRME",
}


@dataclass
class Kanit:
    """
    Oyuncunun inceleyebileceği bir bilgi kaynağı.

    Bir kanıt tek başına cevabı vermez; birkaçı birleşince bilinmeyen ortaya
    çıkar. `bedel` dikkat puanı cinsindendir: her şeyi açmak yerine doğru yere
    bakmayı ödüllendirir. `kritik` işaretli kanıt olmadan bulmaca çözülemez
    (ipucu sisteminde oyuncuyu oraya yönlendirmek için kullanılır).
    """
    etiket: str
    icerik: str
    bedel: int = 1
    kritik: bool = False


@dataclass
class Adim:
    """Bulmacanın tek bir sorusu."""
    soru: str
    tur: str = SAYI
    rol: str = COZUM
    secenekler: List[str] = field(default_factory=list)
    cevap: Any = None
    tolerans: float = 0.001
    birim: str = ""
    ipuclari: List[str] = field(default_factory=list)
    aciklama: str = ""          # cevaptan sonra gösterilen "neden böyle" metni
    # Yanlış cevabın TEŞHİSİ: "ne bilmiyorsun" değil, "neyi karıştırdın".
    #   Şıklı adımda anahtar, yanlış şıkkın metnidir (şıklar karıştığı için
    #   numara kullanılamaz). Sayısal adımda anahtar, o yaygın yanlış sayıdır.
    #   "*" anahtarı, eşleşme bulunamayan her yanlış için son sözdür.
    # Öğrenci hangi hatayı yaptığını duyar; karnede de hata türü olarak birikir.
    yanlis_teshis: Dict[str, str] = field(default_factory=dict)
    puan: int = 10
    ipucu_bedeli: int = 3       # her ipucu puandan bu kadar götürür

    # Tam çözüm: öğrenci takıldığında öğretimi sürdüren çözüm kutusu.
    # İpucundan farkı, işlemi baştan sona göstermesidir. Bu yüzden bedava
    # değildir: oyuncu dikkat puanı harcayarak açar (bkz. Oturum).
    cozum: str = ""
    cozum_bedeli: int = 2       # dikkat puanı cinsinden

    def __post_init__(self) -> None:
        if self.tur in (SECIM, COKLU, SIRALA) and not self.secenekler:
            raise ValueError("'{}' türü şıksız olamaz: {}".format(self.tur, self.soru[:40]))
        if self.tur == SECIM and not isinstance(self.cevap, int):
            raise ValueError("SECIM adımının cevabı şık indeksi (int) olmalı.")
        if self.tur in (COKLU, SIRALA) and not isinstance(self.cevap, (list, tuple)):
            raise ValueError("'{}' adımının cevabı liste olmalı.".format(self.tur))


@dataclass
class Bulmaca:
    """Bir görev: brifing + kanıtlar + adımlar."""
    kod: str
    ders: str
    baslik: str
    kademe: int
    konu: str
    brifing: str
    adimlar: List[Adim]
    kanitlar: List[Kanit] = field(default_factory=list)
    kapanis: str = ""
    odul: Dict[str, int] = field(default_factory=dict)
    kazanim: str = ""           # müfredat karşılığı - öğretmene gösterilir
    dikkat: int = 6             # bu bulmacada harcanabilir dikkat puanı

    @property
    def azami_puan(self) -> int:
        return sum(adim.puan for adim in self.adimlar)

    @property
    def ders_adi(self) -> str:
        return DERS_ADLARI.get(self.ders, self.ders.title())

    @property
    def kademe_adi(self) -> str:
        return KADEME_ADLARI.get(self.kademe, str(self.kademe))

    def dogrula(self) -> List[str]:
        """İçerik yazarları için kendi kendini denetleme. Sorun listesi döner."""
        sorunlar = []
        if not self.adimlar:
            sorunlar.append("{}: hiç adım yok".format(self.kod))
        if self.ders not in DERSLER:
            sorunlar.append("{}: bilinmeyen ders '{}'".format(self.kod, self.ders))
        if not (1 <= self.kademe <= 13):
            sorunlar.append("{}: kademe 1-13 aralığı dışında".format(self.kod))
        if len(self.brifing) < 40:
            sorunlar.append("{}: brifing fazla kısa, hikâye kurulmamış".format(self.kod))
        for sira, adim in enumerate(self.adimlar, 1):
            if adim.cevap is None:
                sorunlar.append("{} adım {}: cevap yok".format(self.kod, sira))
            if adim.tur == SECIM and not (0 <= int(adim.cevap) < len(adim.secenekler)):
                sorunlar.append("{} adım {}: cevap indeksi şık sayısını aşıyor".format(self.kod, sira))
            if adim.tur == COKLU:
                for indeks in adim.cevap:
                    if not (0 <= int(indeks) < len(adim.secenekler)):
                        sorunlar.append("{} adım {}: geçersiz şık indeksi".format(self.kod, sira))
            if adim.tur == SIRALA and sorted(adim.cevap) != list(range(len(adim.secenekler))):
                sorunlar.append("{} adım {}: sıralama cevabı tüm şıkları kapsamıyor".format(self.kod, sira))
            if not adim.aciklama:
                sorunlar.append("{} adım {}: açıklama yok (öğrenci neden öğrenemez)".format(self.kod, sira))
        if not any(adim.rol == MODEL for adim in self.adimlar):
            sorunlar.append("{}: modelleme adımı yok - bu bir keşif bulmacası değil".format(self.kod))
        return sorunlar


@dataclass
class Sefer:
    """
    Tek bir kurgunun içinde birden çok dersi dolaşan görev zinciri.

    Kronograf oyuncuyu bir çağa bırakır. Orada sırayla:
      - hangi çağda olduğu bulunur      (tarih)
      - nerede olunduğu bulunur          (coğrafya)
      - çağa uygun bir hesap yapılır     (matematik / fen)
      - üst makama rapor yazılır         (Türkçe)

    Her bölüm kendi dersinin normal bir görevidir; bu yüzden puanlama, konu
    takibi ve uyarlanır zorluk olduğu gibi işler. Sefer yalnızca onları tek
    bir anlatının içine dizer - öğrenci derslerin birbirinden kopuk olmadığını
    burada görür.
    """
    kod: str
    baslik: str
    donem: str                       # "MÖ 1300 - Tunç Çağı Anadolu" gibi
    giris: str
    bolumler: List["Bulmaca"]
    baglantilar: List[str] = field(default_factory=list)  # bölümler arası metin
    kapanis: str = ""
    odul: Dict[str, int] = field(default_factory=dict)
    kademe: int = 7

    @property
    def dersler(self) -> List[str]:
        gorulen = []
        for bolum in self.bolumler:
            if bolum.ders not in gorulen:
                gorulen.append(bolum.ders)
        return gorulen

    def dogrula(self) -> List[str]:
        sorunlar = []
        if len(self.bolumler) < 2:
            sorunlar.append("{}: sefer en az iki bölüm içermeli".format(self.kod))
        if len(self.dersler) < 2:
            sorunlar.append("{}: sefer en az iki farklı ders dolaşmalı".format(self.kod))
        if len(self.giris) < 60:
            sorunlar.append("{}: sefer girişi fazla kısa".format(self.kod))
        for bolum in self.bolumler:
            sorunlar.extend(bolum.dogrula())
        return sorunlar


@dataclass
class AdimSonucu:
    dogru: bool
    puan: int
    deneme: int
    kullanilan_ipucu: int
    rol: str = COZUM
    verilen_cevap: str = ""
    cozum_gordu: bool = False
    ornek_gordu: bool = False

    @property
    def destek_aldi(self) -> bool:
        return bool(self.kullanilan_ipucu or self.cozum_gordu or self.ornek_gordu)


@dataclass
class BulmacaSonucu:
    """Bir bulmaca oturumunun sonucu."""
    bulmaca_kodu: str
    ders: str
    kademe: int
    konu: str
    puan: int
    azami_puan: int
    adim_sonuclari: List[AdimSonucu] = field(default_factory=list)
    acilan_kanit: int = 0
    tamamlandi: bool = False
    birakildi: bool = False
    asama: str = "serbest"
    # Bu görevde öğrenciye gösterilen yanlış teşhisleri. Karnede "tekrarlayan
    # hata" olarak birikir: tek seferlik dalgınlık ile yerleşmiş bir kavram
    # karışıklığını ancak tekrar sayısı ayırt eder.
    teshisler: List[str] = field(default_factory=list)

    @property
    def oran(self) -> float:
        return 0.0 if self.azami_puan == 0 else self.puan / self.azami_puan

    @property
    def yildiz(self) -> int:
        oran = self.oran
        if oran >= 0.9:
            return 3
        if oran >= 0.65:
            return 2
        if oran >= 0.35:
            return 1
        return 0

    @property
    def ilk_denemede_dogru(self) -> int:
        return sum(1 for s in self.adim_sonuclari if s.dogru and s.deneme == 1 and not s.destek_aldi)

    def model_basarisi(self) -> Optional[bool]:
        """
        Modelleme adımlarını ipucusuz ve ilk denemede geçti mi?
        Asıl ölçmek istediğimiz beceri bu: olayı doğru bağıntıya oturtabilmek.
        Modelleme adımı yoksa None döner.
        """
        modeller = [s for s in self.adim_sonuclari if s.rol == MODEL]
        if not modeller:
            return None
        return all(s.dogru and s.deneme == 1 and not s.destek_aldi for s in modeller)
