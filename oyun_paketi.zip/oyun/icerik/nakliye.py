# -*- coding: utf-8 -*-
"""
İkmal konvoyu görevleri.

NEREDEN GELDİ
-------------
Kullanıcının kendi fikri (5 Eylül 2026): "madenlerin ve erzakların olduğu
konumlardan nakliye istenmesini yapabiliriz". 9 Eylül'de birlikte
tasarlandı; bu dosya o tasarımın uygulaması (B9.9 / B17.1).

Kurgu üsse birebir oturuyor: Meridyen Üssü'ne gelen ikmal konvoyu, "Sayım
ve Depo" birimiyle aynı dünya. Ayrı bir evren kurmuyoruz.

ÇEKİRDEK BECERİ: KALANLI BÖLME
------------------------------
Yarım araç olmaz, yarım sefer olmaz -- ikisi de YUKARI yuvarlanır.
Öğrencilerin en sık kaçırdığı yer burası ve bu dosyanın asıl konusu o.
`math.ceil` her yerde açıkça yazılıyor ki çözüm metinleri de aynı şeyi
anlatsın.

AYIRT EDİCİ HATA
----------------
"Toplam yük ÷ araç kapasitesi" ile "toplam yol ÷ hız" karıştırılıyor.
İkisi de bölme, ikisi de büyük sayı bölü küçük sayı; ama biri KAÇ ARAÇ,
diğeri KAÇ SAAT veriyor. MODEL adımlarındaki yanlış şıklar bilerek bu
karışıklığı hedefliyor.

BEŞ EKSEN KURALI (ICERIK_EKLEME.md §2c)
---------------------------------------
Bir görevde tek eksen yükselir. Bu ailedeki dağılım:

    kademe 4-6   : tek sefer, tam bölünen sayılar        (taban)
    kademe 7-9   : kalanlı bölme                          (+zincir)
    kademe 8-11  : bir aldatmaca (tutarlı ama gereksiz)   (+fazla veri)
    kademe 10-13 : cevabı "veri eksik" olan görev         (+belirsizlik)

Son ailedeki görev bilerek cevapsızdır: doğru cevap bir sayı değil bir
teşhistir. Oyunun açılış cümlesi zaten bu -- "Burada kimse sana neyin
bilinmediğini söylemeyecek."
"""
from __future__ import annotations

import math
import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    DEPO_ADLARI, MEVKI_ADLARI, PERSONEL, ad_sec, metin_adimi, model_adimi,
    sayi_adimi, sy, yorum_adimi,
)

# Araç türleri: (tekil ad, taşıdığı yükün adı, kapasite birimi)
ARACLAR = [
    ("kamyon", "erzak", "ton"),
    ("tır", "malzeme", "ton"),
    ("kargo gemisi", "yük", "ton"),
    ("yük treni", "cevher", "ton"),
    ("nakliye mekiği", "ikmal", "ton"),
]


def _saat_metni(dakika: int) -> str:
    """Dakikayı 24 saatlik saat biçimine çevirir: 620 -> "10:20".

    DİKKAT: gün taşmasını GİZLER (1820 -> "06:20"). Çizelgesi ertesi güne
    sarkabilen görevlerde `_gun_saat_metni` kullan, yoksa cevap kalkıştan
    önceymiş gibi görünür.
    """
    dakika %= 24 * 60
    return "{:02d}:{:02d}".format(dakika // 60, dakika % 60)


def _gun_saat_metni(dakika: int) -> str:
    """Gün taşmasını AÇIKÇA yazar: 1820 -> "ertesi gün 06:20".

    NEDEN AYRI BİR İŞLEV
    --------------------
    9 Eylül'de çizelgenin ertesi güne sarkması bir HATA sayılıp sayılar
    kısıtlanmıştı: "en erken 06:20" çıkıyordu, kalkış 07:00 iken.

    Kullanıcı haklı olarak itiraz etti: gün değişimi gizlenecek bir şey
    değil, ÖĞRETİLECEK bir şey. 24 saatlik saat okumak ve gün sınırını
    geçmek gerçek bir beceri; nakliye de gerçek hayatta gece devam eder.

    Ama bir şartla: **kasıtlı ve belli olmalı.** Soru "saat kaçta" değil
    "hangi gün, saat kaçta" diye sorulmalı ve cevap gün bilgisini
    taşımalı. Yoksa öğrenci kendi hatası sanır -- ki ilk hâlinde tam
    olarak bu oluyordu.
    """
    gun, kalan = divmod(dakika, 24 * 60)
    saat = "{:02d}:{:02d}".format(kalan // 60, kalan % 60)
    if gun == 0:
        return "aynı gün " + saat
    if gun == 1:
        return "ertesi gün " + saat
    return "{}. gün {}".format(gun + 1, saat)


# Bir iş günü: çizelge bunu aşarsa görev üretilmez.
#
# NEDEN VAR: `_saat_metni` 24 saate göre başa dönüyor. Çizelge ertesi güne
# sarkarsa "en erken 06:20" gibi bir cevap çıkıyordu -- kalkış 07:00 iken.
# Öğrenci için anlamsız, üstelik kalkıştan ÖNCE görünüyor. (9 Eylül 2026)
#
# Ertesi güne sarkan bir konvoyu doğru anlatmak "ertesi gün 06:20" demeyi
# gerektirir; o da bu ailenin öğrettiği şeye bir şey katmadan soruyu
# uzatır. Bu yüzden sayılar aynı güne sığacak şekilde seçiliyor.
GUN_SONU = 24 * 60


def _sure_metni(dakika: int) -> str:
    """Süreyi okunur biçime: 280 -> "4 saat 40 dakika"."""
    saat, kalan = divmod(dakika, 60)
    if saat and kalan:
        return "{} saat {} dakika".format(saat, kalan)
    if saat:
        return "{} saat".format(saat)
    return "{} dakika".format(kalan)


# ==========================================================================
# TABAN — tek sefer, tam bölünen sayılar (kademe 4-6)
# ==========================================================================

@bulmaca(ders="matematik", konu="nakliye", kademeler=(4, 6), agirlik=1.1)
def ilk_konvoy(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tek sefer, tam bölünen sayılar. Tek iş: yükü kapasiteye bölmek.

    Beş eksenin hepsi tabanda (ICERIK_EKLEME.md §2c). Aldatmaca yok,
    eksik veri yok, zincir tek adım. Burada öğretilen tek şey hangi
    sayının hangisine bölüneceği.
    """
    arac, yuk_adi, birim = rastgele.choice(ARACLAR)
    kapasite = rastgele.choice([8, 10, 12, 15, 20])
    arac_sayisi = rastgele.randrange(3, 8)
    toplam = kapasite * arac_sayisi          # tam bölünüyor: kalan yok
    depo = ad_sec(rastgele, DEPO_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="nak-ilk-konvoy",
        ders="matematik",
        baslik="İlk Konvoy",
        kademe=kademe,
        konu="nakliye",
        kazanim="Toplam yükü araç kapasitesine bölerek araç sayısını bulma.",
        dikkat=4,
        brifing=(
            "{} deposundan üsse {} {} {} gelecek. {} bütün araçları "
            "hazırlamış ama kaçını yollayacağını yazmamış.\n\n"
            "Her {} tam yükte {} {} taşıyor. Komutan konvoyun tek seferde "
            "gitmesini istiyor."
        ).format(depo, sy(toplam), birim, yuk_adi, kisi, arac, sy(kapasite), birim),
        kanitlar=[
            Kanit("Sipariş fişi",
                  "İstenen: {} {} {}".format(sy(toplam), birim, yuk_adi),
                  bedel=1, kritik=True),
            Kanit("Araç kartı",
                  "{} başına tam yük: {} {}".format(
                      arac.capitalize(), sy(kapasite), birim),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Kaç araç gerektiğini bulmak için ne yapmalı?",
                dogru="Toplam yükü bir aracın kapasitesine bölmeli.",
                yanlislar=[
                    "Bir aracın kapasitesini toplam yüke bölmeli.",
                    "Toplam yükten kapasiteyi çıkarmalı.",
                    "Toplam yükü kapasiteyle çarpmalı.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Her araç aynı miktarı taşıyor. Toplam yükün içinde kaç "
                    "tane \"bir araçlık yük\" olduğunu soruyoruz; bu bölmedir."
                ),
                cozum=(
                    "Bir araç {} {} taşıyor. Toplam {} {} var.\n"
                    "Soru şu: {} {}, her biri {} {} olan kaç parçaya ayrılır?\n"
                    "{} ÷ {} = {} araç."
                ).format(sy(kapasite), birim, sy(toplam), birim,
                         sy(toplam), birim, sy(kapasite), birim,
                         sy(toplam), sy(kapasite), sy(arac_sayisi)),
            ),
            sayi_adimi(
                soru="Konvoyda kaç {} olmalı?".format(arac),
                cevap=arac_sayisi,
                birim=arac,
                aciklama="{} ÷ {} = {}".format(
                    sy(toplam), sy(kapasite), sy(arac_sayisi)),
                cozum=(
                    "{} ÷ {} = {}\n"
                    "Sayı tam bölündü, artan yük yok; {} araç yeter."
                ).format(sy(toplam), sy(kapasite), sy(arac_sayisi),
                         sy(arac_sayisi)),
            ),
        ],
        kapanis=(
            "{} {} yola çıktı. Sevkiyat subayı defterine \"tek sefer, "
            "artan yok\" diye yazdı."
        ).format(sy(arac_sayisi), arac),
        odul={"erzak": 6, "itibar": 2},
    )


# ==========================================================================
# KALANLI BÖLME — bu ailenin asıl dersi (kademe 7-9)
# ==========================================================================

@bulmaca(ders="matematik", konu="nakliye", kademeler=(7, 9), agirlik=1.3)
def artan_yuk(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yük tam bölünmüyor. Yarım araç olmaz -- yukarı yuvarlanır.

    Yükselen tek eksen: zincir derinliği (bölme + yuvarlama kararı).
    Aldatmaca yok, eksik veri yok; öğrencinin bütün dikkati artan yükte
    kalsın diye.
    """
    arac, yuk_adi, birim = rastgele.choice(ARACLAR)
    kapasite = rastgele.choice([12, 14, 16, 18, 25])
    tam_arac = rastgele.randrange(4, 9)
    artan = rastgele.randrange(1, kapasite - 1)      # asla 0: kalan olmalı
    toplam = kapasite * tam_arac + artan
    gereken = math.ceil(toplam / kapasite)           # = tam_arac + 1
    depo = ad_sec(rastgele, DEPO_ADLARI, 1)[0]

    return Bulmaca(
        kod="nak-artan-yuk",
        ders="matematik",
        baslik="Artan Yük",
        kademe=kademe,
        konu="nakliye",
        kazanim="Kalanlı bölme; bölümü yukarı yuvarlayarak araç sayısı bulma.",
        dikkat=5,
        brifing=(
            "{} deposundan {} {} {} yollanacak. Konvoydaki her {} tam "
            "yükte {} {} alıyor.\n\n"
            "Sevkiyat subayı hesabı yapmış ve kâğıdın kenarına \"{} küsur "
            "araç\" yazıp bırakmış. Komutan bu cevabı kabul etmiyor: "
            "\"Bana küsur araç gönderemezsin.\""
        ).format(depo, sy(toplam), birim, yuk_adi, arac,
                 sy(kapasite), birim, sy(tam_arac)),
        kanitlar=[
            Kanit("Sevkiyat emri",
                  "Yollanacak: {} {}".format(sy(toplam), birim),
                  bedel=1, kritik=True),
            Kanit("Araç kartı",
                  "Tam yük: {} {}. Fazla yükleme yasak.".format(
                      sy(kapasite), birim),
                  bedel=1, kritik=True),
            Kanit("Depo görevlisinin notu",
                  "\"Artan yükü bir sonraki sefere bırakamayız, hepsi bugün "
                  "gidecek.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bölme işleminden çıkan küsuru ne yapmalı?",
                dogru="Yukarı yuvarlamalı; artan yük de bir araç ister.",
                yanlislar={
                    "Aşağı yuvarlamalı; küsur bir araç etmez.":
                        "Aşağı yuvarladın; artan {} {} yerde kalır. Küsur ne "
                        "kadar küçük olsa da o yükü taşıyacak bir araç "
                        "gerekir.".format(sy(artan), birim),
                    "En yakın tam sayıya yuvarlamalı; küsur yarımdan azsa atılır.":
                        "Olağan yuvarlama kuralını uyguladın. Burada küsur "
                        "gerçek bir yük; yarımdan az da olsa gidecek.",
                    "Artanı öteki araçlara paylaştırmalı; ek araç gerekmez.":
                        "Artanı dolu araçlara eklemeye çalıştın; araç kartı "
                        "fazla yüklemeyi yasaklıyor. Tam dolu araca yük "
                        "eklenemez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Artan {} {} de gidecek ve onu taşıyacak bir araç lazım. "
                    "Yarım araç diye bir şey yok, o yüzden hep YUKARI "
                    "yuvarlanır."
                ).format(sy(artan), birim),
                cozum=(
                    "{} ÷ {} = {} tam araç, {} {} artıyor.\n"
                    "Artan yük de gidecek; onu taşıyacak araç yarım olamaz.\n"
                    "Bu yüzden sonuç yukarı yuvarlanır: {} araç.\n\n"
                    "Aşağı yuvarlasaydık {} {} yerde kalırdı."
                ).format(sy(toplam), sy(kapasite), sy(tam_arac),
                         sy(artan), birim, sy(gereken), sy(artan), birim),
            ),
            sayi_adimi(
                soru="Kaç {} yollanmalı?".format(arac),
                cevap=gereken,
                birim=arac,
                aciklama="{} ÷ {} = {} küsur -> {}".format(
                    sy(toplam), sy(kapasite), sy(tam_arac), sy(gereken)),
                cozum=(
                    "{} ÷ {} = {}, kalan {}.\n"
                    "{} araç tam dolar, {} {} artar.\n"
                    "Artan için bir araç daha: {} + 1 = {}."
                ).format(sy(toplam), sy(kapasite), sy(tam_arac), sy(artan),
                         sy(tam_arac), sy(artan), birim,
                         sy(tam_arac), sy(gereken)),
            ),
            yorum_adimi(
                soru="Son araç nasıl gidecek?",
                dogru="Yalnızca artan yükle, kısmen dolu.",
                yanlislar=[
                    "Diğerleri gibi tam yükle; her araç kapasitesiyle gider.",
                    "Hiç yüklenmeden, yedek olarak.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "İlk {} araç {} {} taşıyor, son araca yalnızca artan "
                    "{} {} kalıyor. Boş yer taşımak da nakliyenin bir parçası."
                ).format(sy(tam_arac), sy(kapasite), birim, sy(artan), birim),
            ),
        ],
        kapanis=(
            "{} araç yola çıktı; sonuncusu yarı boş. Komutan defterin "
            "kenarındaki \"küsur\" yazısını karaladı."
        ).format(sy(gereken)),
        odul={"erzak": 8, "itibar": 3},
    )


# ==========================================================================
# ALDATMACA — tutarlı ama gereksiz veri (kademe 8-11)
# ==========================================================================

@bulmaca(ders="matematik", konu="nakliye", kademeler=(8, 11), agirlik=1.2)
def sefer_saati(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kaç sefer + bitiş saati. İçinde bir aldatmaca var.

    Yükselen tek eksen: fazla veri. Mesafe VERİLİYOR ve tutarlı
    (süreyle uyumlu bir hız veriyor) ama sonuca dokunmuyor -- süre zaten
    kalkış/varış saatinden çıkıyor.

    İyi aldatmaca kullanılabilir ama gereksizdir: öğrenci onu
    "hesaplayamıyorum" diye değil, "soruya dokunmuyor" diye elemeli.
    (ICERIK_EKLEME.md §2c)
    """
    arac, yuk_adi, birim = rastgele.choice(ARACLAR)
    kapasite = rastgele.choice([10, 12, 15, 20])
    arac_sayisi = rastgele.randrange(4, 8)
    sefer = rastgele.choice([2, 3])
    toplam = kapasite * arac_sayisi * sefer          # tam bölünüyor

    kalkis = rastgele.choice([5, 6, 7]) * 60
    bosaltma = rastgele.choice([30, 45])
    yukleme = rastgele.choice([30, 45])
    # Yol süresi, çizelge aynı güne sığacak şekilde seçiliyor (bkz. GUN_SONU).
    tur_disi = kalkis + bosaltma
    # GUN_SONU - 1: esitlik de tasma sayilir. Tam 1440'a oturan bir cizelge
    # saat 00:00 veriyordu -- teknik olarak "ayni gun" ama ogrenciye gece
    # yarisini gosteriyor.
    en_uzun_yol = (GUN_SONU - 1 - tur_disi
                   - (sefer - 1) * (bosaltma + yukleme)) // (2 * sefer - 1)
    yol = max(90, min(rastgele.choice([150, 180, 210, 240]), en_uzun_yol))
    # Hız 60 seçilirse mesafe ile süre AYNI sayı çıkıyor ve aldatmaca
    # olduğu belli oluyor; 60 dışarıda.
    hiz = rastgele.choice([70, 80, 90])
    mesafe = int(round(hiz * yol / 60.0))            # tutarlı ama gereksiz

    # Son yükün boşaltılıp bittiği an.
    tur = yol + bosaltma + yol + yukleme             # gidiş+boşalt+dönüş+yükle
    bitis = kalkis + (sefer - 1) * tur + yol + bosaltma
    depo = ad_sec(rastgele, DEPO_ADLARI, 1)[0]

    return Bulmaca(
        kod="nak-sefer-saati",
        ders="matematik",
        baslik="Sefer Saati",
        kademe=kademe,
        konu="nakliye",
        kazanim="Kaç sefer gerektiğini bulup zaman çizelgesi kurma.",
        dikkat=6,
        brifing=(
            "{} deposundan {} {} {} gelecek. Konvoyda {} {} var, her biri "
            "{} {} taşıyor.\n\n"
            "Konvoy yüklü çıktı, çıkış saati {}; {} deposuyla üs arası {} km ve "
            "yol {} sürüyor. Boşaltma {}, yeniden yükleme {}.\n\n"
            "Komutan son yükün ne zaman inmiş olacağını soruyor."
        ).format(depo, sy(toplam), birim, yuk_adi, sy(arac_sayisi), arac,
                 sy(kapasite), birim, _saat_metni(kalkis), depo, sy(mesafe),
                 _sure_metni(yol), _sure_metni(bosaltma), _sure_metni(yukleme)),
        kanitlar=[
            Kanit("Sipariş fişi", "Toplam: {} {}".format(sy(toplam), birim),
                  bedel=1, kritik=True),
            Kanit("Konvoy listesi",
                  "{} {}, her biri {} {}".format(
                      sy(arac_sayisi), arac, sy(kapasite), birim),
                  bedel=1, kritik=True),
            Kanit("Yol defteri",
                  "Çıkış {}. Tek yön {}. Dönüş de aynı sürüyor.".format(
                      _saat_metni(kalkis), _sure_metni(yol)),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bu defterdeki hangi sayı sonuca dokunmuyor?",
                dogru="{} km'lik mesafe.".format(sy(mesafe)),
                yanlislar=[
                    "Boşaltma süresi.",
                    "Araç başına {} {} kapasite.".format(sy(kapasite), birim),
                    "Konvoydaki araç sayısı.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Yolun kaç km olduğu değil, kaç sürdüğü gerekiyor -- ve o "
                    "zaten yazılı. Mesafe yalnızca hızı doğruluyor "
                    "({} km/s), hesaba girmiyor."
                ).format(sy(hiz)),
                cozum=(
                    "Sorulan şey saat. Elimizde yolun süresi zaten var: {}.\n"
                    "Mesafeyi kullanmak için hıza bölmek gerekirdi ve sonuç "
                    "yine aynı süre çıkardı: {} ÷ {} = {}.\n"
                    "Yani mesafe doğru bir sayı ama fazladan bir sayı.\n\n"
                    "Bir sayının doğru olması, gerekli olduğu anlamına gelmez."
                ).format(_sure_metni(yol), sy(mesafe), sy(hiz),
                         _sure_metni(yol)),
            ),
            sayi_adimi(
                soru="Konvoy kaç sefer yapacak?",
                cevap=sefer,
                birim="sefer",
                aciklama="Bir seferde {} {} taşınıyor; {} ÷ {} = {}".format(
                    sy(kapasite * arac_sayisi), birim, sy(toplam),
                    sy(kapasite * arac_sayisi), sy(sefer)),
                cozum=(
                    "Bir seferde bütün konvoy {} × {} = {} {} taşıyor.\n"
                    "{} ÷ {} = {} sefer.\n\n"
                    "Dikkat: burada bölünen şey YÜK, yol değil. Yolu hıza "
                    "bölmek kaç saat sürdüğünü verir, kaç sefer olduğunu değil."
                ).format(sy(arac_sayisi), sy(kapasite),
                         sy(kapasite * arac_sayisi), birim, sy(toplam),
                         sy(kapasite * arac_sayisi), sy(sefer)),
            ),
            metin_adimi(
                soru="Son yük saat kaçta inmiş olur? (Örnek: 18:30)",
                cevap=[_saat_metni(bitis), _saat_metni(bitis).lstrip("0")],
                aciklama="Çizelge: {} çıkış, {} sefer, son boşaltma {}".format(
                    _saat_metni(kalkis), sy(sefer), _saat_metni(bitis)),
                cozum=(
                    "Bir turun tamamı: gidiş {} + boşaltma {} + dönüş {} + "
                    "yükleme {}.\n"
                    "Son seferde dönüş ve yükleme YOK; iş boşaltmayla bitiyor.\n"
                    "Çıkış {} + {} tam tur + son gidiş + son boşaltma = {}."
                ).format(_sure_metni(yol), _sure_metni(bosaltma),
                         _sure_metni(yol), _sure_metni(yukleme),
                         _saat_metni(kalkis), sy(sefer - 1),
                         _saat_metni(bitis)),
            ),
        ],
        kapanis=(
            "Çizelge panoya asıldı: son yük {}. Mesafe satırı defterde "
            "kaldı; kimse ona bakmadı."
        ).format(_saat_metni(bitis)),
        odul={"erzak": 10, "cevher": 4, "itibar": 4},
    )


# ==========================================================================
# CEVABI "VERİ EKSİK" OLAN GÖREV (kademe 10-13)
# ==========================================================================

@bulmaca(ders="matematik", konu="nakliye", kademeler=(10, 13), agirlik=1.0)
def eksik_cizelge(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Doğru cevap bir sayı değil, bir teşhis: "bu bilgiyle olmaz."

    Yükselen tek eksen: sorunun kendisi. Sayılar kolay, zincir kısa.
    Zor olan tek şey, istenenin verilemeyeceğini FARK ETMEK.

    EKSİKLİK BURADA KASITLIDIR ve adımdan anlaşılıyor: soru "kaç saatte
    biter" değil, "istenen tam saat verilebilir mi". Yoksa öğrenci kendi
    hatası sanırdı. (ICERIK_EKLEME.md §2c)

    Kurgu kullanıcının 9 Eylül'de kendi yazdığı brifingden alındı.
    """
    arac, yuk_adi, birim = rastgele.choice(ARACLAR)
    kapasite = rastgele.choice([12, 12.5, 15, 20])
    arac_sayisi = rastgele.randrange(4, 8)
    sefer = rastgele.choice([2, 3])
    toplam = kapasite * arac_sayisi * sefer
    kalkis = rastgele.choice([5, 6, 7]) * 60
    # Sefer sayısı ile yol birlikte seçiliyor: uzun yol + çok sefer aynı
    # güne sığmıyor ve saat başa dönüyordu (bkz. GUN_SONU).
    if sefer >= 3:
        yol = rastgele.choice([120, 150, 180])
    else:
        yol = rastgele.choice([220, 260, 280])
    varis = kalkis + yol
    # En erken bitiş: bütün yükleme/boşaltma sıfır sayılırsa.
    en_erken = kalkis + (2 * sefer - 1) * yol
    mesafe = int(round(rastgele.choice([65, 70, 75]) * yol / 60.0))

    return Bulmaca(
        kod="nak-eksik-cizelge",
        ders="matematik",
        baslik="Eksik Çizelge",
        kademe=kademe,
        konu="nakliye",
        kazanim="Verilen bilginin sorulan kesinliğe yetip yetmediğini görme.",
        dikkat=6,
        brifing=(
            "Komutanın notu:\n\n"
            "\"Konvoy bu sabah yola çıktı, çıkış saati {}. Gideceği mesafe yaklaşık "
            "{} km ve şoförün dediğine göre {} gibi burada olurlar. "
            "Sipariş ettiğimiz miktar {} {}, ama konvoydaki araçlar {} {} "
            "taşıyabiliyor. Konvoy {} araçtan oluşuyor.\n\n"
            "Üstlerimiz bizden TAM bitiş saatini istiyor.\""
        ).format(_saat_metni(kalkis), sy(mesafe), _saat_metni(varis),
                 sy(toplam), birim, sy(kapasite), birim, sy(arac_sayisi)),
        kanitlar=[
            Kanit("Konvoy listesi",
                  "{} {}, her biri {} {}".format(
                      sy(arac_sayisi), arac, sy(kapasite), birim),
                  bedel=1, kritik=True),
            Kanit("Yol defteri",
                  "Çıkış {}. Girişte görülme {}. Boşaltma ve yükleme "
                  "süreleri KAYDEDİLMEMİŞ.".format(
                      _saat_metni(kalkis), _saat_metni(varis)),
                  bedel=1, kritik=True),
            Kanit("Depo sorumlusunun cevabı",
                  "\"Boşaltmanın ne kadar sürdüğünü kimse tutmuyor. Bugün "
                  "kalabalıksa uzar.\"", bedel=1),
        ],
        adimlar=[
            sayi_adimi(
                soru="Konvoy kaç sefer yapmak zorunda?",
                cevap=sefer,
                birim="sefer",
                aciklama="{} ÷ ({} × {}) = {}".format(
                    sy(toplam), sy(arac_sayisi), sy(kapasite), sy(sefer)),
                cozum=(
                    "Bir seferde {} × {} = {} {} taşınıyor.\n"
                    "{} ÷ {} = {} sefer."
                ).format(sy(arac_sayisi), sy(kapasite),
                         sy(arac_sayisi * kapasite), birim, sy(toplam),
                         sy(arac_sayisi * kapasite), sy(sefer)),
            ),
            model_adimi(
                soru="Üstlerin istediği TAM bitiş saati bu bilgiyle verilebilir mi?",
                dogru="Hayır; boşaltma ve yükleme süreleri yazılmamış.",
                yanlislar=[
                    "Evet; çıkış ve varış saati biliniyor, gerisi hesaplanır.",
                    "Evet; mesafe ve süreden hız bulunur, oradan çıkar.",
                    "Hayır; araç sayısı bilinmiyor.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Yol süresi belli, sefer sayısı belli. Ama her seferin "
                    "arasında boşaltma ve yeniden yükleme var ve ikisi de "
                    "hiçbir yerde yazmıyor. Bilinmeyen bir süreyi tahmin "
                    "edip \"tam saat\" demek, uydurmaktır."
                ),
                cozum=(
                    "Elimizde olanlar: çıkış {}, yol {}, {} sefer.\n"
                    "Eksik olanlar: boşaltma süresi, yeniden yükleme süresi.\n\n"
                    "Bunlar sıfır sayılsa bile en erken {} olur; gerçekte "
                    "daha geç. Yani verilebilecek en kesin cevap bir SAAT "
                    "değil, bir ALT SINIR.\n\n"
                    "Bir de şu var: brifingde \"yaklaşık\" ve \"gibi\" "
                    "yazıyor, istenen ise \"tam\". Sorulan kesinlik, verilen "
                    "kesinlikten büyük olamaz."
                ).format(_saat_metni(kalkis), _sure_metni(yol), sy(sefer),
                         _saat_metni(en_erken)),
            ),
            metin_adimi(
                soru=("Boşaltma ve yükleme hiç sürmeseydi iş en erken saat "
                      "kaçta biterdi? (Örnek: 18:30)"),
                cevap=[_saat_metni(en_erken), _saat_metni(en_erken).lstrip("0")],
                aciklama="{} + {} kez {} = {}".format(
                    _saat_metni(kalkis), sy(2 * sefer - 1), _sure_metni(yol),
                    _saat_metni(en_erken)),
                cozum=(
                    "{} sefer için {} gidiş ve {} dönüş var: toplam {} kez "
                    "yol.\n"
                    "{} + {} × {} = {}.\n\n"
                    "Bu bir cevap değil, bir sınır: iş bundan ÖNCE bitemez."
                ).format(sy(sefer), sy(sefer), sy(sefer - 1),
                         sy(2 * sefer - 1), _saat_metni(kalkis),
                         sy(2 * sefer - 1), _sure_metni(yol),
                         _saat_metni(en_erken)),
            ),
            yorum_adimi(
                soru="Komutana ne yazmalı?",
                dogru="Eksik iki süreyi sorup ondan sonra kesin saat vermeli.",
                yanlislar=[
                    "Ortalama bir boşaltma süresi tahmin edip saati yazmalı.",
                    "En erken saati tam bitiş saati olarak bildirmeli.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Tahmini kesinmiş gibi bildirmek, yanlış saatte kamyon "
                    "bekleyen bir ekip demektir. Eksik bilgiyi söylemek, "
                    "uydurulmuş bir sayıdan daha işe yarar."
                ),
            ),
        ],
        kapanis=(
            "Komutana iki satır yazıldı: \"En erken {}. Kesin saat "
            "için boşaltma ve yükleme sürelerini bildirin.\" Üstlerden "
            "cevap geldi: \"Haklısınız, kimse tutmuyormuş. Bugünden "
            "itibaren tutulacak.\""
        ).format(_saat_metni(en_erken)),
        odul={"itibar": 8, "cevher": 3},
    )


# ==========================================================================
# AKTARMALI KONVOY — darboğaz (kademe 9-13)
# ==========================================================================

@bulmaca(ders="matematik", konu="nakliye", kademeler=(9, 13), agirlik=1.1)
def aktarma_noktasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki ayaklı taşıma: tren aktarma noktasına, oradan karayolu.

    Kullanıcının fikri (9 Eylül 2026): "konvoy aktarma da yapabilir miyiz?
    mesela trenle bir yere kadar gelir sonra kamyon ile geri kalan yolu
    gider."

    YENİ KAVRAM: DARBOĞAZ. Zincirin hızını en dar halka belirler. Tren tek
    seferde çok taşır ama kamyonlar azar azar; toplam süreyi trenin hızı
    değil, kamyonların KAÇ SEFER yapması belirliyor. Bu, nakliyenin
    ötesinde bir düşünme biçimi -- aynı yapı üretim hattında da,
    bilgisayar ağında da var.

    Yükselen tek eksen: bağıntı çeşidi (iki ayrı kapasite hesabı
    birleşiyor). Bu yüzden aldatmaca YOK ve tren yükü tam bölünüyor;
    öğrencinin dikkati aktarmada kalsın diye.

    GÜN TAŞMASI BURADA KASITLI. Kamyon seferleri geceye sarkabilir ve soru
    "hangi gün, saat kaçta" diye soruyor (bkz. `_gun_saat_metni`).
    Kullanıcının itirazı haklıydı: gün değişimi gizlenecek bir şey değil,
    öğretilecek bir şey.
    """
    kapasite_tren = rastgele.choice([120, 150, 180, 240])
    kapasite_kamyon = rastgele.choice([10, 12, 15])
    kamyon_sayisi = rastgele.randrange(3, 7)
    toplam = kapasite_tren                 # tren tek seferde getiriyor
    kamyon_yuku = kapasite_kamyon * kamyon_sayisi
    kamyon_sefer = math.ceil(toplam / kamyon_yuku)

    tren_kalkis = rastgele.choice([4, 5, 6]) * 60
    tren_yol = rastgele.choice([180, 240, 300])
    aktarma = rastgele.choice([45, 60])            # trenden kamyona
    kamyon_yol = rastgele.choice([90, 120, 150])   # aktarma noktası -> üs
    kamyon_bosaltma = rastgele.choice([30, 45])

    varis_aktarma = tren_kalkis + tren_yol
    kamyon_baslangic = varis_aktarma + aktarma
    # Her sefer: gidiş + boşaltma. Son sefer dışında bir de dönüş.
    bitis = (kamyon_baslangic
             + kamyon_sefer * (kamyon_yol + kamyon_bosaltma)
             + (kamyon_sefer - 1) * kamyon_yol)

    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    depo = ad_sec(rastgele, DEPO_ADLARI, 1)[0]

    return Bulmaca(
        kod="nak-aktarma",
        ders="matematik",
        baslik="Aktarma Noktası",
        kademe=kademe,
        konu="nakliye",
        kazanim=("İki ayaklı taşımada darboğazı bulma; zincirin süresini "
                 "en dar halkanın belirlediğini görme."),
        dikkat=6,
        brifing=(
            "{} deposundan gelen {} ton yük üsse doğrudan gelemiyor; "
            "demiryolu {} mevkiinde bitiyor. Yük orada kamyonlara "
            "aktarılıp yolun kalanını karadan gidecek.\n\n"
            "Trenin kalkış saati {}, yol {} sürüyor. Aktarma {} alıyor.\n\n"
            "Aktarma noktasında {} kamyon bekliyor, her biri {} ton "
            "taşıyor. Kamyonların üsse yolu {}, boşaltma {}.\n\n"
            "Komutan son yükün ne zaman ineceğini soruyor."
        ).format(depo, sy(toplam), mevki, _saat_metni(tren_kalkis),
                 _sure_metni(tren_yol), _sure_metni(aktarma),
                 sy(kamyon_sayisi), sy(kapasite_kamyon),
                 _sure_metni(kamyon_yol), _sure_metni(kamyon_bosaltma)),
        kanitlar=[
            Kanit("Tren yük belgesi",
                  "Tek sefer, {} ton. Tren üsse GİRMİYOR; hat {} "
                  "mevkiinde bitiyor.".format(sy(toplam), mevki),
                  bedel=1, kritik=True),
            Kanit("Aktarma noktası çizelgesi",
                  "{} kamyon hazır, kamyon başına {} ton. Aktarma {}.".format(
                      sy(kamyon_sayisi), sy(kapasite_kamyon),
                      _sure_metni(aktarma)),
                  bedel=1, kritik=True),
            Kanit("Karayolu defteri",
                  "Aktarma noktası - üs: {}. Boşaltma {}. Dönüş de aynı "
                  "sürüyor.".format(_sure_metni(kamyon_yol),
                                    _sure_metni(kamyon_bosaltma)),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Toplam süreyi hangi ayak belirliyor?",
                dogru="Kamyon ayağı; kamyonlar birkaç sefer yapıyor.",
                yanlislar=[
                    "Tren ayağı; yolun uzun kısmı orası, en çok zaman orada geçer.",
                    "İkisi de eşit belirliyor, süreler toplanır.",
                    "Aktarma süresi; en yavaş adım o.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Tren {} tonu BİR seferde getiriyor. Kamyonlar bir "
                    "seferde ancak {} ton taşıyor, yani {} sefer gerekiyor. "
                    "Zincirin süresini en dar halka belirler; burada o halka "
                    "kamyon ayağı."
                ).format(sy(toplam), sy(kamyon_yuku), sy(kamyon_sefer)),
                cozum=(
                    "Tren ayağı: {} ton, tek sefer, {}.\n"
                    "Kamyon ayağı: bir seferde {} x {} = {} ton, "
                    "yani {} / {} = {} sefer.\n\n"
                    "Trenin yolu daha uzun olabilir ama BİR kez yapılıyor. "
                    "Kamyon yolu kısa ama {} kez yapılıyor. Bir zincirde "
                    "toplam süreyi belirleyen şey mesafe değil, TEKRAR."
                ).format(sy(toplam), _sure_metni(tren_yol),
                         sy(kamyon_sayisi), sy(kapasite_kamyon),
                         sy(kamyon_yuku), sy(toplam), sy(kamyon_yuku),
                         sy(kamyon_sefer), sy(kamyon_sefer)),
            ),
            sayi_adimi(
                soru="Kamyonlar kaç sefer yapacak?",
                cevap=kamyon_sefer,
                birim="sefer",
                aciklama="{} / ({} x {}) = {}".format(
                    sy(toplam), sy(kamyon_sayisi), sy(kapasite_kamyon),
                    sy(kamyon_sefer)),
                cozum=(
                    "Bütün kamyonlar birlikte {} x {} = {} ton taşıyor.\n"
                    "{} / {} = {} sefer.\n"
                    "Artan yük kalsaydı bir sefer daha eklenirdi; yarım "
                    "sefer diye bir şey yok."
                ).format(sy(kamyon_sayisi), sy(kapasite_kamyon),
                         sy(kamyon_yuku), sy(toplam), sy(kamyon_yuku),
                         sy(kamyon_sefer)),
            ),
            metin_adimi(
                soru=("Son yük hangi gün, saat kaçta iner? "
                      "(Örnek: aynı gün 21:30 / ertesi gün 04:15)"),
                cevap=[_gun_saat_metni(bitis),
                       _gun_saat_metni(bitis).split(" ", 2)[-1]],
                aciklama="Tren {} varır, aktarma {}, {} kamyon seferi".format(
                    _saat_metni(varis_aktarma), _sure_metni(aktarma),
                    sy(kamyon_sefer)),
                cozum=(
                    "Kalkış {}, yol {}: aktarmaya varış {}.\n"
                    "Aktarma {} sürüyor, kamyonlar {} yola çıkar.\n"
                    "Her sefer: {} gidiş + {} boşaltma; son sefer dışında "
                    "bir de {} dönüş.\n"
                    "{} sefer sonunda: {}.\n\n"
                    "GÜN DEĞİŞİMİNE DİKKAT: saat 24:00 geçilince tarih "
                    "değişir. Yalnızca \"06:20\" yazılırsa cevap kalkıştan "
                    "önceymiş gibi görünür."
                ).format(_saat_metni(tren_kalkis), _sure_metni(tren_yol),
                         _saat_metni(varis_aktarma), _sure_metni(aktarma),
                         _saat_metni(kamyon_baslangic),
                         _sure_metni(kamyon_yol),
                         _sure_metni(kamyon_bosaltma),
                         _sure_metni(kamyon_yol), sy(kamyon_sefer),
                         _gun_saat_metni(bitis)),
            ),
            yorum_adimi(
                soru="İşi hızlandırmak için ne yapmak en çok işe yarar?",
                dogru="Aktarmaya daha çok kamyon getirmek.",
                yanlislar=[
                    "Daha hızlı bir tren bulmak; yolun uzun kısmı orada.",
                    "Aktarma süresini kısaltmak.",
                    "Trenin kalkış saatini öne almak.",
                ],
                rastgele=rastgele,
                aciklama=(
                    "Darboğaz kamyon ayağında. Kamyon sayısı artarsa sefer "
                    "sayısı düşer ve toplam süre kısalır. Treni hızlandırmak "
                    "yalnızca başlangıcı öne çeker; {} seferin hepsi yine "
                    "yapılır."
                ).format(sy(kamyon_sefer)),
            ),
        ],
        kapanis=(
            "Son kamyon {} boşaldı. Aktarma noktası defterine \"kamyon "
            "sayısı yetersiz\" notu düşüldü."
        ).format(_gun_saat_metni(bitis)),
        odul={"erzak": 12, "cevher": 5, "itibar": 5},
    )


# ==========================================================================
# DARBOĞAZ: PARALEL Mİ SIRALI MI (B17.x)
#
# Kullanıcı 13 Eylül 2026'da nakliye problemi için ayrıntılı bir eğitim
# belgesi getirdi (`Documents/Codex/.../lojistik_tasima_problemi...md`).
# Belgenin katman tablosuyla bu dosyayı karşılaştırdık: 1-5. katmanlar ve
# "veri eksik" görevi zaten yazılmıştı, 6. katman (SINIRLI RAMPA, paralel
# ve sıralı işlem) yoktu. Bu görev o boşluğu kapatıyor.
#
# YENİ İLİŞKİ, YENİ BÖLME DEĞİL
# Dosyadaki öteki görevlerde tavan fonksiyonu YÜK ÷ KAPASİTE üzerinde
# çalışıyor. Burada araç sayısı ÷ rampa sayısı üzerinde çalışıyor: aynı
# işlem, başka bir yerde. Ayırt edici hata da bu yüzden başka:
#
#     K × U      -> bütün araçların SIRAYLA boşaldığını sanmak
#     U          -> hepsinin AYNI ANDA boşaldığını sanmak
#     (K/P) × U  -> kalanı yok sayıp aşağı yuvarlamak (yarım tur olmaz)
#
# TERS SORU DA VAR
# Belgenin 8.3'ü "ters problem" istiyor: süre sınırı verilip en az kaç
# araç/rampa gerektiğini sormak. Üçüncü adım bu: boşaltma yoldan uzun
# sürmesin diye en az kaç nokta gerekir.
# ==========================================================================

def _rampa_havuzu():
    """Görevin kullanabileceği (araç, süre, nokta, mesafe, hız) birleşimleri.

    Elle sayı seçmek yerine ARANIYOR, çünkü görevin anlamlı olması üç
    koşula bağlı ve bunlar elle tutturulamaz:

      1. Boşaltma yol süresinden UZUN olmalı -- yoksa darboğaz görünmez.
      2. Ama iki katından uzun olmamalı -- yoksa soru karikatüre döner.
      3. Hedefi tutturan en az nokta sayısı, mevcut nokta sayısından FAZLA
         olmalı -- yoksa ters sorunun cevabı "hiçbir şey yapma" olur.
      4. Araç sayısı nokta sayısına TAM BÖLÜNMEMELİ. Bölündüğünde yukarı
         yuvarlama hiç işlemez; görevin asıl öğrettiği şey ölçülmemiş olur
         ve "kalanı attın" çeldiricisi doğru cevabın kendisi çıkar.
         Denetleyici bunu 13. kademede yakaladı (13 Eylül 2026).
    """
    havuz = []
    for arac in range(6, 17):
        for sure in (8, 10, 12, 15, 18, 20):
            for nokta in (2, 3, 4):
                for mesafe in (40, 50, 60, 75, 80, 90, 100, 120):
                    for hiz in (40, 50, 60):
                        if mesafe * 60 % hiz:
                            continue                  # tam dakika olsun
                        yol = mesafe * 60 // hiz
                        if arac % nokta == 0:
                            continue                  # tavan islemeli
                        bosaltma = math.ceil(arac / nokta) * sure
                        if bosaltma <= yol or bosaltma > 2 * yol:
                            continue
                        gerekli = next(
                            (p for p in range(1, arac + 1)
                             if math.ceil(arac / p) * sure <= yol), None)
                        if gerekli and nokta < gerekli <= nokta + 3:
                            havuz.append((arac, sure, nokta, mesafe, hiz,
                                          yol, bosaltma, gerekli))
    return tuple(havuz)


_RAMPA = _rampa_havuzu()


@bulmaca(ders="matematik", konu="nakliye", kademeler=(9, 13), agirlik=1.2)
def rampa_darbogazi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sınırlı boşaltma noktası: paralel mi sıralı mı, ve darboğaz nerede."""
    (arac, sure, nokta, mesafe, hiz,
     yol, bosaltma, gerekli) = rastgele.choice(_RAMPA)
    tur = math.ceil(arac / nokta)
    # Teshis anahtarlari dogru cevaba esit olamaz: "bir nokta eklemek yetmez"
    # hatasi, gerekli sayi zaten nokta+1 ise cevabin kendisi olur.
    yanlis_nokta = {
        arac: "Her araca bir nokta ayırdın. O da yeterdi ama soru EN AZ kaç "
              "nokta gerektiğini istiyor.",
    }
    if gerekli != nokta + 1:
        yanlis_nokta[nokta + 1] = (
            "Bir nokta eklemek yetmiyor; ekledikten sonra tur sayısını "
            "yeniden hesapla.")
    depo = ad_sec(rastgele, DEPO_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="nak-rampa-darbogazi",
        ders="matematik",
        baslik="Rampa Sırası",
        kademe=kademe,
        konu="nakliye",
        kazanim="Paralel ve sıralı işlemi ayırt etme; tavan fonksiyonuyla "
                "darboğaz hesabı.",
        dikkat=7,
        brifing=(
            "{} konvoyu {} araçla yola çıktı: {} km yol, ortalama {} km/sa.\n\n"
            "Üste vardıklarında hepsi birden boşalamıyor. {} boşaltma noktası "
            "var; her araç {} dakika sürüyor. Sıra bekleyen araçlar rampanın "
            "önünde duruyor.\n\n"
            "{} \"yol mu uzun, boşaltma mı\" diye soruyor. Cevaba göre ya "
            "konvoyu ya rampaları değiştireceğiz."
        ).format(depo, arac, mesafe, hiz, nokta, sure, kisi),
        kanitlar=[
            Kanit("Konvoy kaydı",
                  "{} araç. Yol: {} km, ortalama {} km/sa.".format(
                      arac, mesafe, hiz), bedel=1, kritik=True),
            Kanit("Rampa kaydı",
                  "Boşaltma noktası: {}. Araç başına boşaltma: {} dakika. "
                  "Noktalar aynı anda çalışabiliyor.".format(nokta, sure),
                  bedel=2, kritik=True),
            Kanit("Rampa görevlisinin notu",
                  "\"Bir nokta boşalmadan sıradaki araç yaklaşmıyor. {} "
                  "araç birlikte girer, bitince sıradakiler giriyor.\"".format(
                      nokta), bedel=2, kritik=True),
            Kanit("Üs talimatı",
                  "\"Boşaltma, yolun kendisinden uzun sürmeyecek.\"",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Konvoyun tamamının boşaltma süresi nasıl bulunur?",
                dogru=("Tur sayısı araç ÷ nokta (yukarı yuvarlanır), süre tur × {} "
                       "dakika".format(sure)),
                yanlislar={
                    "Her araç sırayla tek tek girdiği için süre {} × {} dakika olur".format(
                        arac, sure):
                        "Bütün araçların SIRAYLA boşaldığını saydın. Kayıt {} "
                        "noktanın aynı anda çalıştığını yazıyor; sıralı hesap "
                        "süreyi {} kat uzun gösterir.".format(nokta, nokta),
                    "Noktalar aynı anda çalışır, hepsi aynı anda boşaldığı için {} "
                    "dakika".format(sure):
                        "Bu, nokta sayısı araç sayısına yetseydi doğru olurdu. "
                        "{} araç, {} noktaya sığmıyor; sıra bekleyen "
                        "var.".format(arac, nokta),
                    "Kalan araç tur etmez: araç sayısı noktaya bölünür, kalan atılır "
                    "ve {} ile çarpılır".format(sure):
                        "Kalanı attın. Artan araçlar da boşalmak zorunda; "
                        "yarım tur olmaz, o tur da tam sayılır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Paralel iş, işi noktalara PAYLAŞTIRIR ama bölmenin "
                    "kalanını yok etmez: son turda tek araç kalsa da o tur "
                    "tam süre tutar. Bu yüzden bölme yukarı yuvarlanır.\n\n"
                    "Bu dosyadaki öteki görevlerde yukarı yuvarlama YÜK ÷ "
                    "KAPASİTE üzerinde çalışıyordu; burada ARAÇ ÷ NOKTA "
                    "üzerinde çalışıyor. Aynı kural, başka bir yer."
                ),
                ipuclari=[
                    "Kaç araç birlikte girebiliyor? Kaç tur gerekiyor?",
                    "Son turda nokta sayısından az araç kalırsa o tur ne kadar sürer?",
                ],
                cozum=(
                    "{} araç ÷ {} nokta = {} tur (yukarı yuvarlanır).\n"
                    "Her tur {} dakika.\n"
                    "Toplam boşaltma = tur × süre."
                ).format(arac, nokta, tur, sure),
            ),
            sayi_adimi(
                soru="Konvoyun tamamı kaç dakikada boşalır?",
                cevap=bosaltma,
                birim="dakika",
                aciklama="{} tur × {} dakika = {} dakika ({}).".format(
                    tur, sure, bosaltma, _sure_metni(bosaltma)),
                yaygin_yanlislar={
                    arac * sure:
                        "Sıralı saydın; noktalar aynı anda çalışıyor.",
                    sure:
                        "Tek tur saydın; {} araç {} noktaya sığmıyor.".format(
                            arac, nokta),
                    (arac // nokta) * sure:
                        "Aşağı yuvarladın; artan araçların turu da tam sayılır.",
                },
                ipuclari=["Önce tur sayısını bul."],
                puan=14,
            ),
            sayi_adimi(
                soru=("Üs talimatı boşaltmanın yoldan uzun sürmesini "
                      "yasaklıyor. En az kaç boşaltma noktası gerekir?"),
                cevap=gerekli,
                birim="nokta",
                aciklama=(
                    "Yol {} dakika ({}). {} nokta ile boşaltma {} dakika -- "
                    "uzun. Nokta sayısını artırıp deneyince tur sayısı düşer; "
                    "{} noktada boşaltma {} dakikaya iner ve talimata "
                    "uyar."
                ).format(yol, _sure_metni(yol), nokta, bosaltma,
                         gerekli, math.ceil(arac / gerekli) * sure),
                yaygin_yanlislar=yanlis_nokta,
                ipuclari=[
                    "Önce yol süresini dakikaya çevir; sınır o.",
                    "Nokta sayısını birer artırıp boşaltma süresini yeniden hesapla.",
                ],
                puan=16,
            ),
            yorum_adimi(
                soru=("Görevli \"nokta sayısını iki katına çıkarsak sefer de "
                      "yarıya iner\" diyor. Neden yanlış?"),
                dogru=("Yanlış: nokta eklemek yalnızca boşaltma turlarını azaltır, "
                       "yol süresi değişmez."),
                yanlislar={
                    "Doğru: toplam süre boşaltmadan oluştuğu için ikiye "
                    "katlanan nokta süreyi yarıya indirir.":
                        "Toplam süre yalnız boşaltma değil. Yol süresi rampa "
                        "sayısından etkilenmiyor; o kısım sabit kalır.",
                    "Yanlış: nokta eklemek boşaltmayı hiç kısaltmaz, yalnız "
                    "sırayı düzenler.":
                        "Kısaltır -- tur sayısı düşer. Yanlış olan şey "
                        "TOPLAM sürenin aynı oranda kısalacağı.",
                    "Yanlış: boşaltma süresi araç sayısına bağlı olmadığı için "
                    "değişmez.":
                        "Araç sayısına bağlı: tur sayısı araç ÷ nokta. İkisi de "
                        "hesaba giriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir zinciri en yavaş halkası belirler. Rampa yavaşken "
                    "rampa eklemek işe yarar; rampa yoldan hızlı olduktan "
                    "sonra eklenen her rampa boşa gider. İyileştirmeyi nereye "
                    "yapacağını bulmak, hesabın kendisinden önce gelir."
                ),
                puan=12,
            ),
        ],
        kapanis=("Rapor: {} dakika boşaltma, {} dakika yol. Talimat için en az "
                 "{} nokta.".format(bosaltma, yol, gerekli)),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )
