# -*- coding: utf-8 -*-
"""
Öğretmen girişi ve öğretmen masası.

Öğretmen araçları bugüne kadar yalnızca komut satırındaydı (`--rapor`,
`--karne`, `--kapsama`, `--denetle`). Okulda bu, öğretmenin terminal açıp
komut yazması demek; pratikte kimse yapmaz. Bu modül aynı araçları oyunun
açılış ekranından erişilebilir bir menüye taşır.

Girişin bir parolası var. Parolanın ne olduğu konusunda net olalım:

    Bu parola, öğrencinin merakla sınıfın tamamının kaydına bakmasını
    engeller. GERÇEK bir güvenlik değildir: parola özeti düz bir JSON
    dosyasında durur ve kayıt klasörüne erişimi olan biri o dosyayı silip
    parolayı sıfırlayabilir. Öğrenci PIN'i için de aynı şey geçerli
    (bkz. TASARIM_NOTLARI.md §7). Gerçek gizlilik sunucu ister.

İlk çalıştırmada parola yoktur; öğretmen ilk girişte kendi belirler. Okul
kurulumunda bunun İLK İŞ olarak yapılması gerekir - yoksa parolayı ilk giren
öğrenci belirler.
"""
from __future__ import annotations

import io
import json
import os
import time
from typing import Any, Dict, List, Optional

from oyun.motor import durum as durum_modulu
from oyun.motor import terminal as ekran
from oyun.motor.durum import Durum, kayitlari_listele, pin_ozetle, yukle

# Parola özeti kayıt klasöründe durur: ağ paylaşımı kullanılıyorsa öğretmen
# hangi makineye otursa aynı parolayla girer.
#
# Yol içe aktarma anında SABİTLENMEZ, her çağrıda okunur: kayıt klasörü
# MERIDYEN_KAYIT ile değiştirilebiliyor ve testler de onu değiştiriyor.
# Sabitlenseydi modül eski klasöre yazmaya devam ederdi.
AYAR_ADI = "ogretmen.json"


def ayar_dosyasi() -> str:
    return os.path.join(durum_modulu.KAYIT_KLASORU, AYAR_ADI)

# Özet tuzu. Öğrenci PIN'leri kimlikle tuzlanıyor; öğretmen parolası tek
# olduğu için sabit bir tuz kullanıyoruz.
TUZ = "ogretmen"

EN_AZ_UZUNLUK = 4


# --------------------------------------------------------------------------
# Parola
# --------------------------------------------------------------------------

def _ayarlari_oku() -> Dict[str, Any]:
    try:
        with io.open(ayar_dosyasi(), encoding="utf-8") as dosya:
            return json.load(dosya)
    except Exception:
        return {}


def _ayarlari_yaz(veri: Dict[str, Any]) -> None:
    os.makedirs(durum_modulu.KAYIT_KLASORU, exist_ok=True)
    hedef = ayar_dosyasi()
    gecici = hedef + ".tmp"
    with io.open(gecici, "w", encoding="utf-8") as dosya:
        json.dump(veri, dosya, ensure_ascii=False, indent=2)
    os.replace(gecici, hedef)


def parola_kurulu_mu() -> bool:
    return bool(_ayarlari_oku().get("parola_ozeti"))


def parola_kur(parola: str) -> bool:
    """Parolayı kaydeder. Çok kısaysa reddeder."""
    parola = (parola or "").strip()
    if len(parola) < EN_AZ_UZUNLUK:
        return False
    veri = _ayarlari_oku()
    veri["parola_ozeti"] = pin_ozetle(parola, TUZ)
    veri["kurulum"] = time.strftime("%d.%m.%Y %H:%M")
    _ayarlari_yaz(veri)
    return True


def parola_dogru_mu(parola: str) -> bool:
    ozet = _ayarlari_oku().get("parola_ozeti")
    if not ozet:
        return False
    return pin_ozetle(parola or "", TUZ) == ozet


# --------------------------------------------------------------------------
# Giriş
# --------------------------------------------------------------------------

def _ilk_kurulum() -> bool:
    """Parola yoksa öğretmenden ilk parolayı ister."""
    ekran.yaz()
    ekran.kutu(
        "Bu bilgisayarda öğretmen parolası henüz belirlenmemiş. Şimdi "
        "belirlersen bundan sonra öğretmen masasına yalnızca bu parolayla "
        "girilir.\n\n"
        "Parola, öğrencinin sınıfın kayıtlarına merakla bakmasını engeller. "
        "Kayıt klasörüne erişimi olan birine karşı koruma sağlamaz; okulun "
        "asıl koruması klasör izinleridir.",
        "İLK KURULUM", "acik_sari")
    if not ekran.onayla("Öğretmen parolası şimdi belirlensin mi?", False):
        return False
    for _ in range(3):
        parola = ekran.sor("Yeni parola (en az {} karakter):".format(EN_AZ_UZUNLUK))
        if not parola:
            return False
        if parola != ekran.sor("Parolayı bir daha yaz:"):
            ekran.hata("İki parola aynı değil.")
            continue
        if parola_kur(parola):
            ekran.basari("Parola kaydedildi: " + ayar_dosyasi())
            return True
        ekran.hata("Parola en az {} karakter olmalı.".format(EN_AZ_UZUNLUK))
    return False


def giris() -> bool:
    """Öğretmen girişi. Başarılıysa True döner."""
    if not parola_kurulu_mu():
        return _ilk_kurulum()
    for kalan in (2, 1, 0):
        if parola_dogru_mu(ekran.sor("Öğretmen parolası:")):
            return True
        if kalan:
            ekran.hata("Parola tutmadı. {} hakkın kaldı.".format(kalan))
    ekran.hata("Parola tutmadı.")
    ekran.bekle()
    return False


# --------------------------------------------------------------------------
# Öğretmen masası
# --------------------------------------------------------------------------

def _ogrenci_listesi() -> None:
    ozetler = kayitlari_listele()
    if not ozetler:
        ekran.bilgi("Henüz kayıtlı öğrenci yok.")
        ekran.bekle()
        return
    ekran.yaz()
    ekran.yaz("ÖĞRENCİ LİSTESİ  ({} kayıt)".format(len(ozetler)),
              "kalin", "acik_cam")
    ekran.yaz()
    ekran.yaz("{:<18}{:<7}{:<8}{:>7}{:>8}   {}".format(
        "ÖĞRENCİ", "NO", "SINIF", "GÖREV", "PIN", "SON OYNAMA"), "gri")
    ekran.ayrac()
    for ozet in ozetler:
        zaman = (time.strftime("%d.%m.%Y %H:%M", time.localtime(ozet["son"]))
                 if ozet["son"] else "-")
        print("  " + "{:<18}{:<7}{:<8}{:>7}{:>8}   {}".format(
            ozet["ad"][:17], (ozet.get("numara") or "-")[:6],
            (ozet.get("sinif") or "-")[:7], ozet["gorev"],
            "var" if ozet.get("pinli") else "-", zaman))
    ekran.yaz()
    ekran.yaz("Kayıt dosyaları: " + durum_modulu.KAYIT_KLASORU, "gri", sar=False,
              girinti="  ")
    ekran.bekle()


def _ogrenci_sec() -> Optional[Durum]:
    """Listeden tek öğrenci seçtirir."""
    ozetler = kayitlari_listele()
    if not ozetler:
        ekran.bilgi("Henüz kayıtlı öğrenci yok.")
        ekran.bekle()
        return None
    secenekler = []
    for ozet in ozetler:
        etiket = ozet["ad"]
        ek = " ".join(p for p in ((ozet.get("sinif") or ""),
                                  (ozet.get("numara") or "")) if p)
        if ek:
            etiket = "{}  ({})".format(etiket, ek)
        secenekler.append((etiket, "{} görev".format(ozet["gorev"])))
    secenekler.append(("Vazgeç", ""))
    secim = ekran.menu("ÖĞRENCİ", secenekler)
    if secim >= len(ozetler):
        return None
    durum = yukle(ozetler[secim]["yol"])
    if durum is None:
        ekran.hata("Kayıt dosyası okunamadı.")
        ekran.bekle()
    return durum


def _karne_ekrani() -> None:
    from araclar.karne import karne_bas, karne_verisi, karne_yaz

    durum = _ogrenci_sec()
    if durum is None:
        return
    ekran.temizle()
    karne_bas(karne_verisi(durum))
    ekran.yaz()
    if ekran.onayla("Bu karneyi yazdırılabilir dosya olarak kaydedeyim mi?",
                    False):
        try:
            ekran.basari("Karne hazır: " + karne_yaz(durum))
        except OSError as sorun:
            ekran.hata("Karne yazılamadı: {}".format(sorun))
    ekran.bekle()


def _parola_degistir() -> None:
    if not parola_dogru_mu(ekran.sor("Mevcut parola:")):
        ekran.hata("Parola tutmadı.")
        ekran.bekle()
        return
    yeni = ekran.sor("Yeni parola (en az {} karakter):".format(EN_AZ_UZUNLUK))
    if yeni != ekran.sor("Yeni parolayı bir daha yaz:"):
        ekran.hata("İki parola aynı değil.")
    elif parola_kur(yeni):
        ekran.basari("Parola değiştirildi.")
    else:
        ekran.hata("Parola en az {} karakter olmalı.".format(EN_AZ_UZUNLUK))
    ekran.bekle()


def _ogrenci_tasi(siniflar) -> None:
    """Öğrenciyi başka sınıfa taşır. KAYIT SİLİNMEZ, yalnızca bağ değişir."""
    from araclar import sinif as sinif_modulu

    durum = _ogrenci_sec()
    if durum is None:
        return
    ozetler = [o for o in kayitlari_listele()
               if o["ad"] == durum.ad and o.get("numara") == durum.numara]
    if not ozetler:
        ekran.hata("Kayıt bulunamadı.")
        ekran.bekle()
        return

    secenekler = [("{}  {}".format(k["kod"], k["ad"]), k.get("okul", ""))
                  for k in siniflar]
    secenekler.append(("Sınıf bağını kaldır", "kayıt ve ilerleme durur"))
    secenekler.append(("Vazgeç", ""))
    secim = ekran.menu("{} hangi sınıfa?".format(durum.ad), secenekler)
    if secim >= len(secenekler) - 1:
        return
    kod = "" if secim == len(siniflar) else siniflar[secim]["kod"]
    if sinif_modulu.ogrenciyi_tasi(ozetler[0]["yol"], kod):
        ekran.bilgi("{} taşındı. İlerlemesi olduğu gibi duruyor.".format(durum.ad))
    else:
        ekran.hata("Taşınamadı.")
    ekran.bekle()


def _siniflar() -> None:
    """Sınıf açma ve kod verme ekranı.

    Kodun işi şu: öğrenci onu girince sınıfı, şubesi ve okulu kendiliğinden
    dolsun. Öğrenciden kimlik numarası ya da başka kişisel veri istenmiyor;
    ad ve kod yetiyor. Kod tahtaya yazılacağı için okunaklı üretiliyor
    (bkz. araclar/sinif.py).
    """
    from araclar import sinif as sinif_modulu

    while True:
        ekran.temizle()
        ekran.baslik("SINIFLAR", "kalin", "acik_cam")
        siniflar = sinif_modulu.siniflari_listele()
        if siniflar:
            ekran.yaz()
            for kayit in siniflar:
                satir = "{}   {}".format(
                    ekran.renkli(kayit["kod"], "acik_sari"), kayit["ad"])
                if kayit.get("okul"):
                    satir += ekran.renkli("  ({})".format(kayit["okul"]), "gri")
                ekran.yaz("  " + satir)
            ekran.yaz()
            ekran.yaz("Kodu tahtaya yazın; öğrenci yeni sefer açarken giriyor.",
                      "gri")
        else:
            ekran.bilgi("Henüz sınıf açılmamış.")
        ekran.ayrac()

        secim = ekran.menu("", [
            ("Yeni sınıf aç", "kod üretilir"),
            ("Öğrenciyi başka sınıfa taşı", "yanlış koda girmiş olabilir"),
            ("Geri dön", ""),
        ])
        if secim == 1:
            _ogrenci_tasi(siniflar)
            continue
        if secim != 0:
            return

        ekran.yaz()
        ad = ekran.sor("Sınıf/şube (örn. 7-A):", "").strip()
        if not ad:
            ekran.hata("Sınıf adı boş olamaz.")
            ekran.bekle()
            continue
        okul = ekran.sor("Okul adı (isteğe bağlı):", "")
        ogretmen_adi = ekran.sor("Öğretmen adı (isteğe bağlı):", "")
        try:
            kayit = sinif_modulu.sinif_olustur(ad, okul, ogretmen_adi)
        except Exception as sorun:  # noqa: BLE001 - kullaniciya soyle, cokme
            ekran.hata("Sınıf açılamadı: {}".format(sorun))
            ekran.bekle()
            continue
        ekran.yaz()
        ekran.kutu(
            kayit["kod"] + "\n\n" +
            "Bu kodu tahtaya yazın. Öğrenci \"Yeni sefer\" sonra \"Okulda\" " +
            "derken bu kodu giriyor; sınıfı ve okulu kendiliğinden doluyor.",
            "SINIF KODU: " + kayit["ad"], "acik_yesil")
        ekran.bekle()


def _bekleyen_ozeti() -> str:
    """Menü satırının yanına "(3)" gibi bir sayı. Yoksa boş dizge.

    Öğretmenin menüye girmeden bekleyen olduğunu görmesi için. Sayı toplam
    BILDIRI değil, bekleyen SORU sayısıdır -- öğretmenin yapacağı iş kadar
    madde görünsün.
    """
    try:
        from araclar import el_kaldirma
        from araclar.sinif import siniflari_listele
        from araclar.sinif import ogretmen_anahtari
        toplam = sum(len(el_kaldirma.bekleyenler(
            s.get("kod", ""), ogretmen_anahtari(s.get("kod", ""))))
            for s in siniflari_listele())
    except Exception:              # noqa: BLE001 - menü asla bu yüzden çökmesin
        return ""
    return "  ({})".format(toplam) if toplam else ""


def masa() -> None:
    """Öğretmen masası menüsü. Giriş yapılmış varsayılır."""
    from araclar.denetim import tumunu_denetle
    from araclar.karne import toplu_karne
    from araclar.rapor import sinif_raporu
    from oyun.motor.oyun import kapsama_yazdir

    while True:
        ekran.temizle()
        ekran.baslik("ÖĞRETMEN MASASI", "kalin", "acik_cam")
        ozetler = kayitlari_listele()
        subeler = sorted(set((o.get("sinif") or "").strip()
                             for o in ozetler if (o.get("sinif") or "").strip()))
        ekran.yaz("{} öğrenci kaydı{}".format(
            len(ozetler),
            "  |  şubeler: " + ", ".join(subeler) if subeler else ""), "gri")
        ekran.ayrac()

        # "El kaldıranlar" en üstte: ders SIRASINDA bakılan tek madde bu,
        # diğerleri ders dışı işler. Öğretmen tahtadan dönüp iki saniyede
        # görebilmeli.
        bekleyen_sayi = _bekleyen_ozeti()
        secim = ekran.menu("", [
            ("El kaldıranlar" + bekleyen_sayi,
             "kim olduğu yazmaz - hangi soruda kaç kişi takıldı"),
            ("Sınıf raporu", "kim nerede takılıyor, sınıfın ortak hataları"),
            ("Öğrenci listesi", "kayıtlar, şubeler ve son oynama zamanları"),
            ("Bir öğrencinin karnesi", "ekranda göster, istersen yazdır"),
            ("Bütün karneleri üret", "karneler/ klasörüne HTML olarak"),
            ("İçerik kapsaması", "hangi öğrenme yolunda hangi zorlukta iş var"),
            ("İçerik denetimi", "bütün görevleri üretip tutarlılık kontrolü"),
            ("Sınıflar ve kodlar", "sınıf aç, kodu öğrencilere ver"),
            ("Parolayı değiştir", ""),
            ("Okul ders programı", "saatler, dersler ve işlenen konular"),
            ("Çıkış", "ana ekrana dön"),
        ])

        if secim == 0:
            _el_kaldiranlar()
        elif secim == 1:
            sube = ekran.sor("Hangi şube? (hepsi için boş bırak):", "")
            ekran.temizle()
            sinif_raporu(sube)
            ekran.bekle()
        elif secim == 2:
            ekran.temizle()
            _ogrenci_listesi()
        elif secim == 3:
            _karne_ekrani()
        elif secim == 4:
            ekran.temizle()
            toplu_karne()
            ekran.bekle()
        elif secim == 5:
            ekran.temizle()
            kapsama_yazdir()
            ekran.bekle()
        elif secim == 6:
            ekran.temizle()
            ekran.bilgi("Bütün görev üreticileri çalıştırılıyor, biraz "
                        "sürebilir...")
            tumunu_denetle()
            ekran.bekle()
        elif secim == 7:
            _siniflar()
        elif secim == 8:
            _parola_degistir()
        elif secim == 9:
            from araclar.program import ogretmen_programi
            ogretmen_programi()
        else:
            return


def ogretmen_girisi() -> None:
    """Açılış ekranından çağrılan giriş + masa akışı."""
    ekran.temizle()
    ekran.baslik("ÖĞRETMEN GİRİŞİ", "kalin", "acik_cam")
    if giris():
        masa()


def _el_kaldiranlar() -> None:
    """Sessiz el kaldırma ekranı. Bkz. araclar/el_kaldirma.py.

    BU EKRANDA İSİM YOKTUR VE OLMAYACAKTIR. Tahtaya yansısa bile kimse
    açığa çıkmamalı; öğrencinin bunu kullanmasının tek şartı bu.
    Kimin nerede zorlandığı sınıf raporunda, ayrı bir yerde duruyor.
    """
    import time as _zaman

    from araclar import el_kaldirma
    from araclar.sinif import siniflari_listele

    siniflar = siniflari_listele()
    if not siniflar:
        ekran.temizle()
        ekran.baslik("EL KALDIRANLAR", "kalin", "acik_cam")
        ekran.bilgi("Henüz sınıf açılmamış. Önce \"Sınıflar ve kodlar\" "
                    "menüsünden bir sınıf aç ve kodu tahtaya yaz.")
        ekran.bekle()
        return

    if len(siniflar) == 1:
        secilen = siniflar[0]
    else:
        ekran.temizle()
        ekran.baslik("EL KALDIRANLAR", "kalin", "acik_cam")
        secim = ekran.menu("Hangi sınıf?",
                           [(s.get("ad", "?"), s.get("kod", "")) for s in siniflar]
                           + [("Geri", "")])
        if secim is None or secim >= len(siniflar):
            return
        secilen = siniflar[secim]

    kod = secilen.get("kod", "")
    # Sunucu uzerinden calisiliyorsa ogretmen isleri anahtar istiyor;
    # sinif kodu tahtada yazili oldugu icin tek basina yetki degil.
    from araclar.sinif import ogretmen_anahtari
    anahtar = ogretmen_anahtari(kod)
    while True:
        ekran.temizle()
        ekran.baslik("EL KALDIRANLAR - {}".format(secilen.get("ad", "?")),
                     "kalin", "acik_cam")
        bekleyen = el_kaldirma.bekleyenler(kod, anahtar)
        if not bekleyen:
            ekran.yaz("Şu an bekleyen yok.", "gri")
            ekran.yaz()
            ekran.yaz("Öğrenci bir soruda takılınca oyunda \"e\" yazar; "
                      "burada görünür.", "gri")
            ekran.bekle()
            return

        # Tek parça veriliyor: satırı ekranın genişliğine göre terminal
        # kırsın. Elle kırılmış satırlar telefonda (50 sütun) ortasından
        # bölünüyordu.
        ekran.yaz("Kimin bildirdiği YAZMIYOR ve yazmayacak; yalnızca kaç "
                  "kişinin takıldığı görünür. Tahtada anlatırken kimseyi "
                  "seçme, sınıfa \"şu soruyu birlikte yapalım\" demek yeter.",
                  "gri")
        ekran.ayrac()

        simdi = _zaman.time()
        satirlar = []
        for sira, kayit in enumerate(bekleyen, 1):
            gecen = max(0, int((simdi - float(kayit.get("son", simdi))) // 60))
            ne_zaman = "az önce" if gecen < 1 else "{} dk önce".format(gecen)
            ekran.yaz("{:>2}. {} kişi  {}  ({})".format(
                sira, kayit.get("sayi", 0), kayit.get("konu", "?"), ne_zaman),
                "acik_sari" if kayit.get("sayi", 0) > 1 else None)
            baslik = (kayit.get("baslik") or "").strip()
            if baslik:
                ekran.yaz("    " + baslik[:200], "gri")
            satirlar.append(kayit)

        ekran.ayrac()
        ekran.yaz("Anlattığın satırın numarasını yaz. "
                  "t = hepsini temizle, Enter = geri.", "gri")
        ham = ekran.sor("Satır no / t / Enter:").strip().lower()
        if not ham:
            return
        if ham == "t":
            if ekran.onayla("Bekleyenlerin hepsi silinsin mi?", False):
                el_kaldirma.temizle(kod, anahtar)
            continue
        if ham.isdecimal():
            sira = int(ham)
            if 1 <= sira <= len(satirlar):
                el_kaldirma.anlatildi(kod, satirlar[sira - 1]["anahtar"],
                                      anahtar)
                continue
        ekran.hata("Anlamadım. Satır numarası, t ya da Enter.")
        ekran.bekle()
