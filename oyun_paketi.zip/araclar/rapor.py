# -*- coding: utf-8 -*-
"""Kayıtlardan öğrenme sürecini özetleyen öğretmen raporu."""
from __future__ import annotations

import time
from typing import Dict, List, Tuple

from oyun.motor import terminal as ekran
from oyun.motor.durum import Durum, kayitlari_listele, yukle
from oyun.motor.kayit_defteri import konular
from oyun.motor.modeller import OGRENME_YOLLARI, secmeli_yol_mu, yol_alanlari


def _konu_ozeti(durum: Durum) -> Tuple[int, int]:
    oturmus = baslanmis = 0
    for alan in durum.aktif_dersler():
        for konu_kodu in konular(alan):
            konu = durum.ders(alan).konu(konu_kodu)
            oturmus += int(konu.tamamlandi)
            baslanmis += int(konu.baslanmis)
    return oturmus, baslanmis


def _model_orani(durum: Durum) -> str:
    toplam = sum(durum.ders(a).model_toplam for a in durum.aktif_dersler())
    dogru = sum(durum.ders(a).model_dogru for a in durum.aktif_dersler())
    return "-" if not toplam else "%{}".format(int(round(100 * dogru / toplam)))


def _numara_sirasi(numara: str):
    """Öğrenci numarasını sayısal sırala; sayı değilse sona at."""
    ham = (numara or "").strip()
    return (0, int(ham)) if ham.isdecimal() else (1, 0)


def sinif_raporu(sinif: str = "") -> int:
    """
    Kayıtlı öğrencilerin özet raporu.

    `sinif` verilirse yalnızca o şubenin öğrencileri listelenir: bir okulda
    kayitlar/ klasörü kısa sürede bütün sınıfların dosyalarıyla dolar ve
    öğretmene lazım olan kendi şubesidir.
    """
    durumlar: List[Durum] = []
    for ozet in kayitlari_listele():
        durum = yukle(ozet["yol"])
        if durum is None:
            continue
        if sinif:
            aranan = sinif.strip().lower()
            # Once KOD ile esles: kod tam eslesir, ad yazim hatasina aciktir.
            # "7-A" ile "7A" ayni sinifi kastedebilir ama dosyada farkli durur.
            kod_esles = (durum.sinif_kodu or "").lower() == aranan
            ad_esles = aranan in (durum.sinif or "").lower()
            if not (kod_esles or ad_esles):
                continue
        durumlar.append(durum)
    if not durumlar:
        ekran.bilgi("Kayıtlı öğrenci bulunamadı"
                    + (" ({} şubesi).".format(sinif) if sinif
                       else " (kayitlar/ klasörü boş)."))
        return 0

    ekran.baslik("ÖĞRENME RAPORU", "kalin", "acik_cam")
    ekran.yaz("{} öğrenci kaydı{}  |  {}".format(
        len(durumlar), "  |  {}".format(sinif) if sinif else "",
        time.strftime("%d.%m.%Y %H:%M")), "gri")
    ekran.yaz()
    ekran.yaz("{:<15}{:<6}{:<7}{:<14}{:>7}{:>9}{:>8}{:>7}".format(
        "ÖĞRENCİ", "NO", "SINIF", "ZORLUK", "GÖREV", "BAŞLANAN", "OTURAN",
        "MODEL"), "kalin", "gri")
    ekran.ayrac()
    # Şube, sonra numara sırası: öğretmenin elindeki yoklama listesiyle aynı.
    for durum in sorted(durumlar, key=lambda d: (
            (d.sinif or "").lower(), _numara_sirasi(d.numara), d.ad)):
        oturmus, baslanmis = _konu_ozeti(durum)
        print("  " + "{:<15}{:<6}{:<7}{:<14}{:>7}{:>9}{:>8}{:>7}".format(
            durum.ad[:14], (durum.numara or "-")[:5], (durum.sinif or "-")[:6],
            "{} - {}".format(durum.zorluk, durum.zorluk_adi),
            durum.oynanan_gorev, baslanmis, oturmus, _model_orani(durum)))

    ekran.yaz()
    ekran.yaz("OTURAN, öğrencinin konuyu kendi başına en az iki kez başarıyla "
              "uyguladığı anlamına gelir. MODEL, olayın içindeki bilinmeyen "
              "ilişkiyi yardımsız kurma oranıdır.", "gri")
    ekran.yaz()
    ekran.yaz("ÖĞRENME YOLLARI", "kalin", "acik_cam")
    ekran.yaz("Yüzde, sınıfın GİRDİĞİ konular üzerinden hesaplanır; henüz "
              "açılmamış konular paydaya girmez.", "gri", girinti="  ")
    for yol, bilgi in OGRENME_YOLLARI.items():
        ele_alinan = oturan = 0
        for durum in durumlar:
            for alan in yol_alanlari(yol):
                for konu in konular(alan):
                    konu_durumu = durum.ders(alan).konu(konu)
                    if not konu_durumu.baslanmis:
                        continue
                    ele_alinan += 1
                    oturan += int(konu_durumu.tamamlandi)
        # Hiç girilmemiş seçmeli yol (meslek dersleri) raporu kalabalıklaştırmaz.
        if not ele_alinan and secmeli_yol_mu(yol):
            continue
        oran = oturan / ele_alinan if ele_alinan else 0
        ekran.yaz("{:<24}{} {:>3}%  {}/{} konu".format(
            bilgi["ad"], ekran.cubuk(oran, 1.0, 14), int(round(oran * 100)),
            oturan, ele_alinan), "acik_cam", sar=False, girinti="  ")

    konu_toplam: Dict[str, List[float]] = {}
    for durum in durumlar:
        for alan in durum.aktif_dersler():
            for konu, puan in durum.ders(alan).konu_puani.items():
                birikim = konu_toplam.setdefault(konu, [0.0, 0])
                birikim[0] += puan
                birikim[1] += 1
    zorlananlar = sorted(
        ((konu, toplam / adet, int(adet))
         for konu, (toplam, adet) in konu_toplam.items()), key=lambda x: x[1])[:8]
    hata_sayaci: Dict[str, int] = {}
    for durum in durumlar:
        for alan in durum.aktif_dersler():
            for metin, adet in durum.ders(alan).hata_turleri.items():
                hata_sayaci[metin] = hata_sayaci.get(metin, 0) + int(adet)
    sik_hatalar = sorted(hata_sayaci.items(), key=lambda i: -i[1])[:5]
    if sik_hatalar:
        ekran.yaz()
        ekran.yaz("SINIFIN EN SIK TAKILDIĞI YERLER", "kalin", "acik_sari")
        for metin, adet in sik_hatalar:
            ekran.madde("({} kez) {}".format(adet, metin), "acik_sari")

    if zorlananlar:
        ekran.yaz()
        ekran.yaz("BİRLİKTE TEKRAR EDİLECEK KONULAR", "kalin", "acik_sari")
        for konu, ortalama, adet in zorlananlar:
            ekran.madde("{:<30} %{}  ({} öğrenci)".format(
                konu.replace("_", " "), int(round(ortalama * 100)), adet),
                "acik_sari")
    ekran.yaz()
    return 0


if __name__ == "__main__":
    raise SystemExit(sinif_raporu())
