# -*- coding: utf-8 -*-
"""
Biyoloji görevleri (lise, 9-13).

Çerçeve: üssün CANLILAR BÖLMESİ. Numune tüpleri, soğutma dolapları, yarım
doldurulmuş saklama fişleri. Buradaki sorular canlının kendisinden çok, onu
ayakta tutan koşullarla ilgilidir: hücre neyi kaldırır, neyi kaldıramaz.

Fen Bilimleri (ortaokul) kaldırılmadı; bu modül onun üstüne biner.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import PERSONEL, ad_sec, model_adimi, sayi_adimi, sy, yorum_adimi


# ==========================================================================
# HÜCRE VE SICAKLIK - donma, buz kristali, kontrollü soğutma
# ==========================================================================

@bulmaca(ders="biyoloji", konu="hucre_ve_sicaklik", kademeler=(9, 13),
         agirlik=1.2)
def numune_dondurma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Donarken genleşen su, buz kristali ve kontrollü soğutma hızı."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    su_ml = rastgele.choice([2.0, 2.5, 4.0, 5.0])
    donmus_ml = round(su_ml * 1.09, 3)

    baslangic = rastgele.choice([18, 20, 22])        # °C
    hedef = rastgele.choice([-70, -80, -90])         # °C
    hiz = rastgele.choice([1, 2])                    # °C/dakika
    fark = baslangic - hedef                         # her zaman çift
    sure = fark // hiz                               # dakika

    yanlis_sure = {
        abs(hedef) // hiz:
            "Yalnızca sıfırın altındaki yolu saydın. Numune sıfırın "
            "ÜSTÜNDEN başlıyor; iki parçayı toplaman gerekiyor.",
    }
    if hiz != 1:
        yanlis_sure[fark] = ("Sıcaklık farkını bulup orada durdun. Bu bir "
                             "sıcaklık, süre değil; farkı dakikadaki soğuma "
                             "hızına bölmelisin.")

    return Bulmaca(
        kod="biyoloji-numune-dondurma",
        ders="biyoloji",
        baslik="Numune Dolabındaki Çatlak",
        kademe=kademe,
        konu="hucre_ve_sicaklik",
        kazanim="Hücre zarının bütünlüğü; suyun donarken genleşmesi ve "
                "kontrollü soğutmanın canlılığı korumadaki rolü.",
        dikkat=6,
        brifing=(
            "Sabah dolabı açan {} kötü bir manzarayla karşılaştı: dün gece "
            "acele dondurulan doku numunelerinin tüpleri çatlamış, "
            "çözüldüklerinde de hiçbiri canlı çıkmamış.\n\n"
            "Oysa aynı türden, protokole göre hazırlanmış karşılaştırma numuneleri iyi "
            "durumda. Sıcaklık kaydında da bir arıza görünmüyor; dolap "
            "istenen sıcaklığa inmiş.\n\n"
            "Yeni sevkiyat bu akşam geliyor. Dün gece neyin yanlış gittiğini "
            "bulmadan aynı işlemi tekrarlamak, elimizdeki son numuneleri de "
            "harcamak olur."
        ).format(kisi),
        kanitlar=[
            Kanit("Numune fişi",
                  "Hacim modeli için tüp başına saf su eşdeğeri: {} mL\nDolaba konulduğu sıcaklık: "
                  "{} °C".format(sy(su_ml), baslangic),
                  bedel=1, kritik=True),
            Kanit("Saklama protokolü",
                  "Bu kurgusal örnekte kontrollü soğutmanın son sıcaklığı: {} °C\n"
                  "Kontrollü soğutma hızı: dakikada {} °C\n"
                  "\"Bu hücre türüne uygun koruyucu ortam ve tüp kullanılır. Numune bu örnekte hedefe belirtilen hızla indirilmeden dolaba "
                  "bırakılmaz.\"".format(hedef, hiz),
                  bedel=2, kritik=True),
            Kanit("Biyoloji el kitabı",
                  "\"Su donarken hacmi yaklaşık %9 ARTAR; buz sudan daha az "
                  "yoğundur. Hücre içinde oluşan buz kristalleri zarı "
                  "zedeleyebilir. Hücre türüne uygun kontrollü soğutmada hücrenin "
                  "suyu bir ölçüde dışarı çıkar; hücre içi buz oluşma riski azalır. Çok yavaş soğutma da zarar verebilir; hız tek başına canlılığı garanti etmez.\"", bedel=2, kritik=True),
            Kanit("Gece vardiya defteri",
                  "\"Sevkiyat geç geldi, numuneleri doğrudan dolaba koydum; "
                  "kontrollü soğutma cihazını beklemeye vaktimiz yoktu.\"",
                  bedel=1, kritik=True),
            Kanit("İnceleme sonucu", "Bu örnekte çözülme sonrası mikroskobik inceleme hücre zarı hasarı saptadı. Tüp çatlağı tek başına hücre ölümünün nedenini kanıtlamaz.", bedel=1, kritik=True),
            Kanit("Bakım kaydı",
                  "Dolabın kompresör filtresi geçen ay değiştirildi; sıcaklık "
                  "kaydında sapma yok.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu örnekteki zar hasarını el kitabındaki hangi mekanizma açıklayabilir?",
                dogru=("Hücre içindeki su donarken genleşiyor ve oluşan buz "
                       "kristalleri zarı zedeleyebiliyor."),
                yanlislar={
                    "Soğuğun kendisi; düşük sıcaklık hücrenin proteinlerini "
                    "doğrudan öldürür.":
                        "Soğuğu tek başına suçladın. Aynı türden, protokole uygun "
                        "hazırlanmış karşılaştırma numuneleri sağlam; bu bulgu tek başına ölüm nedenini kanıtlamaz. Burada incelenen risk "
                        "donma sırasında hücre içi buz oluşmasıdır.",
                    "Hücre soğukta büzülüp çöker; su donarken hacmi küçülür.":
                        "Suyun yönünü ters aldın. Su donarken küçülmez, "
                        "yaklaşık yüzde dokuz BÜYÜR - kışın patlayan su "
                        "borusu da bu yüzden patlar.",
                    "Hücre oksijensiz kaldığı için ölür; soğutma solunumu durdurur.":
                        "Solunumu sebep saydın. Soğuk zaten metabolizmayı "
                        "yavaşlatarak numuneyi KORUYAN şey; tüplerin "
                        "çatlaması da solunumla açıklanamaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çatlayan tüpler hacim artışıyla uyumludur; tek başına hücre ölümünün nedenini kanıtlamaz. Hücre incelemesinde zar hasarı da görülmüş. Su, donarken genleşen ender maddelerden biridir. "
                    "Aynı genleşme hücrenin içinde de olur ve keskin kenarlı buz "
                    "kristalleri zarı zedeleyebilir. Zarı hasarlı hücre çözüldüğünde "
                    "içeriğini dışarı boşaltır; bu, gözlenen kaybı açıklayabilecek mekanizmalardan biridir."
                ),
                ipuclari=[
                    "Tüpler neden çatladı? İçeride büyüyen bir şey olmalı.",
                    "Aynı türden karşılaştırma numuneleri farklı hazırlanmış olabilir mi?",
                ],
                cozum=(
                    "1) Tüp çatlağı, genleşmeyle uyumludur ama tek başına neden kanıtı değildir.\n"
                    "2) Suyun donarken genleştiği el kitabında yazıyor.\n"
                    "3) Aynı genleşme hücre içinde de olur; kristaller zarı yırtar.\n"
                    "4) Hücre incelemesindeki zar hasarı ve el kitabı birlikte okunur. Uygun soğutma hızı ile koruyucu ortam, hücre içi buz hasarı riskini azaltır."
                ),
                puan=18,
            ),
            sayi_adimi(
                soru="Hacmi {} mL olan saf su eşdeğerinin tümüyle donarken %9 genleştiğini varsay. Son hacmi kaç mL "
                     "olur?".format(sy(su_ml)),
                cevap=donmus_ml,
                birim="mL",
                aciklama=(
                    "Donan su hacminin yaklaşık %9'unu kazanır: "
                    "{} mL × 1,09 = {} mL. Tüpün içinde bu kadar boşluk yoksa "
                    "kap hasarı riski doğar. Gerçek numune çözeltisinin genleşmesi bu basit modelle aynı olmak zorunda değildir."
                ).format(sy(su_ml), sy(donmus_ml)),
                yaygin_yanlislar={
                    su_ml: "Genleşmeyi hiç eklemedin; yazdığın sayı donmadan "
                           "önceki hacim. Sorulan, donduktan sonraki hacim.",
                    round(su_ml * 0.91, 3):
                        "Yüzde dokuzu ekleyeceğine çıkardın. Su donarken "
                        "büzülmez; hacmi büyür.",
                },
                ipuclari=[
                    "El kitabındaki genleşme oranını hacme uygula.",
                    "Hacmi 1,09 ile çarp.",
                ],
                tolerans=0.02,
                puan=12,
            ),
            sayi_adimi(
                soru=("Numune {} °C'den {} °C'ye, dakikada {} °C hızla "
                      "indirilecek. Bu kaç dakika sürer?").format(
                          baslangic, hedef, hiz),
                cevap=sure,
                birim="dakika",
                aciklama=(
                    "Önce toplam sıcaklık farkı: {} − ({}) = {} °C. Sonra bu "
                    "fark soğuma hızına bölünür: {} ÷ {} = {} dakika."
                ).format(baslangic, hedef, fark, fark, hiz, sure),
                yaygin_yanlislar=yanlis_sure,
                ipuclari=[
                    "Sıfırın üstündeki ve altındaki yolu ayrı ayrı düşün, sonra topla.",
                    "Toplam farkı dakikadaki soğuma hızına böl.",
                ],
                tolerans=0.5,
                puan=14,
            ),
            yorum_adimi(
                soru="Numuneler neden doğrudan dolaba konmak yerine kontrollü "
                     "ve yavaş soğutuluyor?",
                dogru=("Yavaş soğutmada hücrenin suyu dışarı çıkmaya vakit "
                       "bulur; hücre içi buz hasarı riski azalır."),
                yanlislar={
                    "Yavaş soğutulan hücre soğuğa alışır ve dayanıklılık kazanır.":
                        "Alışma diye bir süreç kurdun; hücrede öyle bir "
                        "öğrenme yok. Kazanılan şey dayanıklılık değil, "
                        "suyun dışarı çıkması için geçen zaman.",
                    "Hızlı soğutma dolabın kompresörünü zorlar; asıl sebep cihazı korumaktır.":
                        "Gerekçeyi cihaza bağladın. Protokol dolabı değil "
                        "hücreyi koruyor; bakım kaydında da bir arıza yok.",
                    "Fark etmez; önemli olan yalnızca varılan son sıcaklıktır.":
                        "Yalnızca hedef sıcaklığa baktın. Eski numunelerle "
                        "yenileri aynı sıcaklıkta duruyor ama sonuçları farklı; "
                        "demek ki oraya NASIL gidildiği belirleyici.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Hücre suyunu içeride tutarak donarsa, o su hücrenin İÇİNDE "
                    "genleşir ve zarı yırtar. Yavaş soğutmada dışarıdaki sıvı önce "
                    "donmaya başlar; hücre suyunun bir kısmı dışarı geçer ve içeride "
                    "buz oluşma riski azalır; tamamen ortadan kalkacağı söylenemez. Gece vardiyasının "
                    "atladığı adım tam olarak buydu: hedefe varmak yetmiyor, o "
                    "hedefe hangi hızla gidildiği, koruyucu ortam ve hücre türü de canlılığı etkiliyor."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Kontrollü soğutma cihazı akşam sevkiyatı için hazırlandı, "
            "protokol de dolabın kapağına asıldı: \"Hedef sıcaklık kadar, "
            "oraya iniş hızı da bağlayıcıdır.\""
        ),
        odul={"erzak": 6, "itibar": 5},
    )
