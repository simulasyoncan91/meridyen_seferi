# -*- coding: utf-8 -*-
"""
Mobilya ve İç Mekân görevleri.

Bu dal, çekirdek mantığının işe yaradığını gösteren yerdir: dört görevin
dördü de başka dallarda zaten yazılmış çekirdeklere oturur. Marangozun kereste
firesi ile elektrikçinin kablo firesi aynı bağıntıdır; kutu ölçüsü ile makine
toleransı aynı hesaptır. Kılıf değişir, iş değişmez.

Ayrıntı: TASARIM_NOTLARI.md §5

Kademe ölçeği: 1-4 ilkokul, 5-8 ortaokul, 9-12 lise, 13 üniversite.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi,
    sy, yorum_adimi,
)

# (fire oranı, ham levha m2, net kullanılabilir m2) - üçü de tam çıksın diye
# hazır seçildi. net = ham x (1 - fire).
FIRE_UCLULERI = [
    (0.20, 25, 20),
    (0.20, 40, 32),
    (0.25, 32, 24),
    (0.25, 48, 36),
    (0.10, 30, 27),
    (0.10, 50, 45),
]


# ==========================================================================
# KERESTE FİRESİ
# ==========================================================================

@bulmaca(ders="mobilya", konu="kereste_firesi", kademeler=(9, 12),
         etiketler=("maliyet_fire",), agirlik=1.2)
def kereste_firesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Fire, alınandan gider; netin üstüne eklenmez.

    Neredeyse herkesin yaptığı hata: net x (1 + fire). Bu sayı YETMEZ ve
    atölye ikinci kez levha almak zorunda kalır. Doğrusu net ÷ (1 - fire).
    """
    fire, ham, net = rastgele.choice(FIRE_UCLULERI)
    yanlis_ekleme = net * (1 + fire)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mob-kereste-firesi",
        ders="mobilya",
        baslik="Yetmeyen Levha",
        kademe=kademe,
        konu="kereste_firesi",
        kazanim="Fire oranı; ham miktar ile net miktar arasındaki bağıntı "
                "(net = ham × (1 - fire)).",
        dikkat=6,
        brifing=(
            "Üssün yemekhanesine raf yapılacak. Çizime göre {} m² kullanılabilir "
            "panel gerekiyor.\n\n"
            "{} depoya levha siparişi verecek ama kesim sırasında kenarların "
            "ve budakların atıldığını biliyor: bu atölyede fire oranı "
            "%{}.\n\n"
            "Geçen sefer sipariş yetmedi ve iş üç gün bekledi. Komutan bu kez "
            "hesabın kâğıtta yapılmasını istiyor."
        ).format(sy(net), kisi, int(round(fire * 100))),
        kanitlar=[
            Kanit("Çizim özeti",
                  "Gereken net panel alanı: {} m².".format(sy(net)),
                  bedel=1, kritik=True),
            Kanit("Atölye kaydı",
                  "Fire oranı %{}. Yani alınan her levhanın %{}'i kesimde "
                  "atılıyor, geriye %{}'i kalıyor.".format(
                      int(round(fire * 100)), int(round(fire * 100)),
                      int(round((1 - fire) * 100))),
                  bedel=2, kritik=True),
            Kanit("Geçen seferin notu",
                  "\"Gerekenin üstüne fire kadar ekledik, yine yetmedi. "
                  "Anlamadık.\"", bedel=2),
            Kanit("Depo",
                  "Levhalar m² olarak satılıyor, istenen ölçüde kesiliyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Sipariş edilecek ham levha alanını hangi bağıntı verir?",
                dogru="Net alanı, kalan orana (1 - fire) böleriz.",
                yanlislar={
                    "Net alanın üstüne fire oranı kadar ekleriz.":
                        "Geçen sefer yapılan hata bu. Fire, ALINAN miktardan "
                        "gider; netin üstüne eklenmez. Netin %{}'i, ham "
                        "levhanın %{}'inden küçüktür - o yüzden yetmiyor."
                        .format(int(round(fire * 100)),
                                int(round(fire * 100))),
                    "Net alanı fire oranıyla çarparız.":
                        "Bu çarpım sana atılacak miktarı verir, alınacak "
                        "miktarı değil. Üstelik sonuç netten küçük çıkar.",
                    "Net alanı fire oranına böleriz.":
                        "Paydayı yanlış aldın. Bölen, atılan oran değil KALAN "
                        "orandır: 1 - fire.",
                    "Net alan yeterlidir; fire zaten çizime dahildir.":
                        "Çizim bitmiş işin ölçüsünü verir. Kesimde atılan "
                        "kısım çizimde görünmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Alınan levhanın %{}'i işe yarıyor. O hâlde net = ham × "
                    "{}; ham = net ÷ {} = {} ÷ {} = {} m².".format(
                        int(round((1 - fire) * 100)), sy(1 - fire), sy(1 - fire),
                        sy(net), sy(1 - fire), sy(ham))),
                ipuclari=[
                    "Fire hangi miktardan gidiyor: aldığından mı, "
                    "kullandığından mı?",
                    "Alınanın yüzde kaçı elinde kalıyor?",
                ],
                cozum=(
                    "1) Kalan oran = 1 - {} = {}\n"
                    "2) Ham = net ÷ kalan oran = {} ÷ {} = {} m²\n"
                    "3) Denetle: {} × {} = {} m² net.".format(
                        sy(fire), sy(1 - fire), sy(net), sy(1 - fire), sy(ham),
                        sy(ham), sy(1 - fire), sy(net))),
            ),
            sayi_adimi(
                soru="Kaç m² ham levha sipariş edilmeli?",
                cevap=ham,
                birim="m²",
                aciklama="{} ÷ {} = {} m²".format(sy(net), sy(1 - fire), sy(ham)),
                yaygin_yanlislar={
                    round(yanlis_ekleme, 4):
                        "Netin üstüne fire kadar ekledin - geçen seferki hata. "
                        "Bu sayı {} m² net verir, gereken {} m².".format(
                            sy(round(yanlis_ekleme * (1 - fire), 2)), sy(net)),
                    net:
                        "Net alanı yazdın; kesimde atılacak kısmı hiç "
                        "hesaba katmadın.",
                    round(net * fire, 4):
                        "Bu, atılacak miktara yakın bir sayı; sipariş "
                        "edilecek toplam değil.",
                },
                ipuclari=["Alınanın yüzde kaçı elde kalıyor? Ona böl."],
                puan=14,
            ),
            yorum_adimi(
                soru="Atölye fireyi %{}'e düşürürse ne olur?".format(
                    max(5, int(round(fire * 100)) - 5)),
                dogru="Aynı iş için daha az levha sipariş edilir.",
                yanlislar={
                    "Aynı iş için daha çok levha gerekir.":
                        "Fire azalınca alınanın daha büyük kısmı işe yarar; "
                        "gereken ham miktar küçülür.",
                    "Sipariş değişmez, yalnızca atık azalır.":
                        "Atık zaten siparişin içinden çıkıyordu. Atık azalınca "
                        "sipariş de küçülür.",
                    "Net panel alanı büyür.":
                        "Net alanı çizim belirliyor; fire oranı onu "
                        "değiştirmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ham = net ÷ (1 - fire). Payda büyüdükçe (fire küçüldükçe) "
                    "sonuç küçülür."),
            ),
        ],
        kapanis=("Sipariş {} m² olarak geçildi ve iş bir seferde bitti. "
                 "Deftere \"fire alınandan gider\" yazıldı.".format(sy(ham))),
        odul={"cevher": 3, "itibar": 2},
    )


# ==========================================================================
# ÇİZİM ÖLÇEĞİ
# ==========================================================================

# (ölçek, kâğıttaki cm, gerçek cm, ikinci ölçek, ikinci kâğıt cm)
OLCEK_KUMELERI = [
    (20, 18, 360, 50, 7.2),
    (20, 15, 300, 50, 6.0),
    (25, 16, 400, 50, 8.0),
    (25, 12, 300, 100, 3.0),
    (50, 8, 400, 100, 4.0),
]


@bulmaca(ders="mobilya", konu="cizim_olcegi", kademeler=(8, 12),
         etiketler=("oran_olcek",), agirlik=1.2)
def cizim_olcegi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Ölçek bir orandır: 1:20, "kâğıttaki 1 cm gerçekte 20 cm" demektir.

    Küçültme yönünü karıştıran öğrenci ölçeğe böler ve dolabı yirmi kat
    küçük yapar.
    """
    olcek, kagit_cm, gercek_cm, olcek2, kagit2 = rastgele.choice(OLCEK_KUMELERI)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="mob-cizim-olcegi",
        ders="mobilya",
        baslik="Küçülen Dolap",
        kademe=kademe,
        konu="cizim_olcegi",
        kazanim="Ölçek kavramı; çizim ölçüsünden gerçek ölçüye geçiş ve "
                "ölçekler arası dönüşüm.",
        dikkat=5,
        brifing=(
            "{} mevkiindeki gözlem kulübesine dolap yapılacak. Elde yalnızca "
            "teknik resim var; dolabın gerçek ölçüsü hiçbir yerde "
            "yazmıyor.\n\n"
            "Resmin köşesinde \"1:{}\" yazıyor. {} cetvelle ölçtü: dolabın "
            "genişliği kâğıtta {} cm.\n\n"
            "Kereste kesilmeden önce gerçek genişliğin bilinmesi gerekiyor. "
            "Yanlış yön, boşa giden bir levha demek."
        ).format(mevki, olcek, ad_sec(rastgele, PERSONEL, 1)[0], sy(kagit_cm)),
        kanitlar=[
            Kanit("Teknik resim",
                  "Köşede ölçek yazıyor: 1:{}".format(olcek),
                  bedel=1, kritik=True),
            Kanit("Cetvel ölçümü",
                  "Kâğıtta ölçülen genişlik: {} cm.".format(sy(kagit_cm)),
                  bedel=1, kritik=True),
            Kanit("Çizim kuralı",
                  "\"1:{} ölçek, kâğıttaki 1 cm'nin gerçekte {} cm olduğunu "
                  "söyler. Çizim gerçeğin KÜÇÜLTÜLMÜŞ hâlidir.\"".format(
                      olcek, olcek),
                  bedel=2, kritik=True),
            Kanit("Kulübe kapısı",
                  "Kapı genişliği 70 cm; dolap içeriden geçirilecek.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Gerçek genişliği hangi işlem verir?",
                dogru="Kâğıttaki ölçüyü ölçek sayısıyla çarparız.",
                yanlislar={
                    "Kâğıttaki ölçüyü ölçek sayısına böleriz.":
                        "Yönü ters aldın. Çizim gerçeğin küçültülmüşü; "
                        "gerçeğe dönerken BÜYÜTMEK gerekir. Bölersen dolap "
                        "avuç içi kadar çıkar.",
                    "Ölçek sayısını kâğıttaki ölçüye böleriz.":
                        "Bu bölme bir uzunluk vermez; ölçek bir orandır, "
                        "bölünen büyüklük değil.",
                    "Kâğıttaki ölçüye ölçek sayısını ekleriz.":
                        "Ölçek bir çarpandır, eklenen bir miktar değil. "
                        "Toplama, iki katı büyük çizimde de aynı sayıyı "
                        "eklerdi.",
                    "Ölçeği yüzde sayıp kâğıttaki ölçünün %{}'ini alırız."
                    .format(olcek):
                        "1:{} bir yüzde değil, bir orandır: kâğıttaki 1 cm "
                        "gerçekte {} cm.".format(olcek, olcek),
                },
                rastgele=rastgele,
                aciklama=(
                    "1:{} ölçekte kâğıttaki her 1 cm gerçekte {} cm'dir. "
                    "{} × {} = {} cm.".format(
                        olcek, olcek, sy(kagit_cm), olcek, sy(gercek_cm))),
                ipuclari=[
                    "Çizim gerçekten büyük mü küçük mü?",
                    "Kâğıttaki 1 cm gerçekte kaç cm ediyor?",
                ],
            ),
            sayi_adimi(
                soru="Dolabın gerçek genişliği kaç cm?",
                cevap=gercek_cm,
                birim="cm",
                aciklama="{} × {} = {} cm".format(
                    sy(kagit_cm), olcek, sy(gercek_cm)),
                yaygin_yanlislar={
                    round(kagit_cm / float(olcek), 4):
                        "Ölçeğe böldün. Çizim zaten küçültülmüş; gerçeğe "
                        "dönerken çarpman gerekir.",
                    kagit_cm:
                        "Kâğıttaki ölçüyü yazdın. Ölçek uygulanmamış.",
                    kagit_cm + olcek:
                        "Ölçeği ekledin. Ölçek bir çarpandır.",
                },
                puan=12,
            ),
            sayi_adimi(
                soru="Aynı dolap 1:{} ölçekle çizilseydi kâğıtta kaç cm "
                     "olurdu?".format(olcek2),
                cevap=kagit2,
                birim="cm",
                aciklama="{} ÷ {} = {} cm".format(
                    sy(gercek_cm), olcek2, sy(kagit2)),
                yaygin_yanlislar={
                    round(gercek_cm * olcek2, 4):
                        "Bu yönde çarpmak gerçeği daha da büyütür. Kâğıda "
                        "geçerken küçültülür: gerçeği ölçeğe böl.",
                    kagit_cm:
                        "Birinci çizimdeki ölçüyü yazdın. Ölçek değişti, "
                        "kâğıttaki boy da değişir.",
                },
                ipuclari=["Kâğıda dönerken bölünür: gerçek ÷ ölçek."],
                puan=12,
            ),
            yorum_adimi(
                soru="Daha büyük ölçek sayısı (1:100 gibi) ne demek?",
                dogru="Çizim daha küçük olur; aynı nesne kâğıtta daha az yer "
                      "kaplar.",
                yanlislar={
                    "Çizim daha büyük olur.":
                        "Ölçek sayısı büyüdükçe küçültme artar: 1:100, "
                        "1:20'den daha çok küçültür.",
                    "Nesnenin gerçek ölçüsü büyür.":
                        "Ölçek yalnızca çizimi ilgilendirir; nesne olduğu "
                        "gibi kalır.",
                    "Çizimin ayrıntısı artar.":
                        "Tam tersi: daha çok küçültülen çizimde ayrıntı "
                        "azalır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ölçek sayısı, gerçeğin kaça bölünerek kâğıda geçtiğini "
                    "söyler. Sayı büyüdükçe çizim küçülür."),
            ),
        ],
        kapanis=("Kereste doğru ölçüde kesildi. Resmin köşesine kırmızıyla "
                 "\"kâğıttan gerçeğe: ÇARP\" yazıldı."),
        odul={"cevher": 2, "itibar": 2},
    )


# ==========================================================================
# MONTAJ BOŞLUĞU VE TOLERANS YIĞILMASI
# ==========================================================================

@bulmaca(ders="mobilya", konu="montaj_boslugu", kademeler=(9, 12),
         etiketler=("tolerans",))
def montaj_boslugu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Toleranslar yığılır.

    Tek çekmeceye bakıp "2 mm sapma önemsiz" demek yanıltır: yan yana beş
    çekmecede aynı sapma 10 mm eder ve gövdeye girmez.
    """
    adet = rastgele.choice([3, 4, 5])
    genislik = rastgele.choice([250, 300, 400])
    tolerans = rastgele.choice([1, 2])
    nominal_toplam = adet * genislik
    en_kotu = nominal_toplam + adet * tolerans
    # Gövde bazen yeter bazen yetmez; cevap ezberlenmesin.
    govde = nominal_toplam + rastgele.choice([adet * tolerans - 2,
                                              adet * tolerans + 4])
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mob-montaj-boslugu",
        ders="mobilya",
        baslik="Sığmayan Çekmece",
        kademe=kademe,
        konu="montaj_boslugu",
        kazanim="Tolerans yığılması; çok parçalı montajda en kötü durum "
                "hesabı.",
        dikkat=6,
        brifing=(
            "Yazı işleri için {} çekmeceli bir dolap yapılıyor. Çekmeceler "
            "yan yana girecek; her birinin genişliği {} mm olarak "
            "çizilmiş.\n\n"
            "{} atölyeden gelen parçaları ölçtü: hiçbiri tam {} mm değil, "
            "her biri {} mm'ye kadar geniş çıkabiliyor. Tek tek bakınca "
            "hepsi kabul sınırında.\n\n"
            "Gövdenin iç genişliği {} mm. Marangoz \"sapma küçük, sorun "
            "olmaz\" diyor."
        ).format(adet, genislik, kisi, genislik, sy(tolerans), govde),
        kanitlar=[
            Kanit("Çizim",
                  "Çekmece sayısı: {}. Her birinin nominal genişliği: {} mm."
                  .format(adet, genislik),
                  bedel=1, kritik=True),
            Kanit("Kabul kaydı",
                  "Her çekmece nominal ölçüsünden en çok {} mm geniş "
                  "çıkabiliyor ve bu tolerans içinde sayılıyor.".format(
                      sy(tolerans)),
                  bedel=2, kritik=True),
            Kanit("Gövde ölçüsü",
                  "Gövdenin iç genişliği: {} mm.".format(govde),
                  bedel=1, kritik=True),
            Kanit("Marangozun sözü",
                  "\"{} mm neyi değiştirir ki?\"".format(sy(tolerans)),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="En kötü durumda çekmecelerin kaplayacağı genişliği nasıl "
                     "buluruz?",
                dogru=("Her çekmecenin en geniş hâlini alıp adet kadar "
                       "toplarız; sapmalar da adet kadar yığılır."),
                yanlislar={
                    "Nominal toplamı alıp üstüne bir tolerans ekleriz.":
                        "Toleransı bir kez saydın. Her çekmece AYRI AYRI "
                        "sapabilir; en kötü durumda sapma adet kadar yığılır.",
                    "Nominal toplamı alırız; tolerans zaten küçük.":
                        "Tek parçada küçük olan sapma, yan yana {} parçada {} "
                        "mm eder. Yığılmayı hesaba katmayan montaj "
                        "tutmaz.".format(adet, sy(adet * tolerans)),
                    "Toleransların ortalamasını alırız, bazıları dar bazıları "
                    "geniş çıkar.":
                        "Ortalama iyimser durumu anlatır. Montaj en kötü "
                        "duruma göre planlanır; hepsi geniş çıkarsa dolap "
                        "kapanmaz.",
                    "Gövde genişliğini adede böleriz.":
                        "Bu, bir çekmeceye düşen payı verir - eldeki "
                        "parçaların gerçekte ne kadar yer kapladığını değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "En kötü durum = adet × (nominal + tolerans) = {} × ({} + "
                    "{}) = {} mm. Nominal toplam {} mm; yığılan sapma {} "
                    "mm.".format(adet, genislik, sy(tolerans), en_kotu,
                                 nominal_toplam, sy(adet * tolerans))),
                ipuclari=[
                    "Kaç parça var ve her biri ayrı ayrı mı sapıyor?",
                    "Hepsi en geniş çıkarsa toplam ne olur?",
                ],
            ),
            sayi_adimi(
                soru="En kötü durumda toplam genişlik kaç mm?",
                cevap=en_kotu,
                birim="mm",
                aciklama="{} × ({} + {}) = {} mm".format(
                    adet, genislik, sy(tolerans), en_kotu),
                yaygin_yanlislar={
                    nominal_toplam:
                        "Toleransı hiç saymadın. Parçalar nominal ölçüde "
                        "çıkmıyor.",
                    nominal_toplam + tolerans:
                        "Toleransı bir kez ekledin. {} parçanın her biri "
                        "sapabilir; sapma {} kez yığılır.".format(adet, adet),
                    genislik + tolerans:
                        "Tek çekmecenin en geniş hâlini yazdın; sorulan "
                        "hepsinin toplamı.",
                },
                puan=14,
            ),
            secim_adimi(
                soru="Çekmeceler gövdeye sığar mı?",
                dogru=("Sığar." if en_kotu <= govde
                       else "Sığmaz; en kötü durumda gövdeyi aşıyor."),
                yanlislar={
                    ("Sığmaz; en kötü durumda gövdeyi aşıyor."
                     if en_kotu <= govde else "Sığar."):
                        ("Karşılaştırmayı ters kurdun: en kötü toplam {} mm, "
                         "gövde {} mm.".format(en_kotu, govde)),
                    "Nominal ölçülere göre sığar, o yeterlidir.":
                        "Nominal ölçüye göre planlanan montaj, parçalar geniş "
                        "çıktığında tutmaz. Karar en kötü duruma göre verilir.",
                    "Ölçüler tekrar alınmadan karar verilemez.":
                        "Kabul kaydı sapmanın üst sınırını zaten veriyor; en "
                        "kötü durum bu sınırdan hesaplanır.",
                },
                rastgele=rastgele,
                aciklama="En kötü toplam {} mm, gövde {} mm: {}.".format(
                    en_kotu, govde, "yeter" if en_kotu <= govde else "yetmez"),
                puan=14,
            ),
            yorum_adimi(
                soru="Marangozun hatası neydi?",
                dogru=("Tek parçaya bakıp sapmanın yan yana yığıldığını "
                       "görmemek."),
                yanlislar={
                    "Toleransı fazla dar tutmak.":
                        "Tolerans dar değil; sorun onun kaç kez tekrar "
                        "ettiğini saymamak.",
                    "Gövdeyi yanlış ölçmek.":
                        "Gövde ölçüsü kayıtta doğru; hata çekmece tarafında.",
                    "Çekmeceleri fazla geniş çizmek.":
                        "Çizim nominal ölçüde doğru; sapma üretimden geliyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tek parçada önemsiz görünen sapma, parça sayısıyla "
                    "çarpılınca montajı bozar. Toleransların yığılması budur."),
            ),
        ],
        kapanis=("Çekmeceler arasına birer milimetre boşluk bırakılarak "
                 "yeniden ölçüldü; dolap ilk denemede kapandı."),
        odul={"cevher": 2, "itibar": 3},
    )


# ==========================================================================
# ALAN BİRİMİ ÇEVİRME
# ==========================================================================

# (en mm, boy mm, alan m2) - alan tam çıksın diye hazır seçildi.
LEVHA_OLCULERI = [
    (1200, 400, 0.48),
    (1500, 600, 0.90),
    (800, 600, 0.48),
    (2000, 500, 1.00),
    (1600, 750, 1.20),
]


@bulmaca(ders="mobilya", konu="levha_alani", kademeler=(8, 12),
         etiketler=("birim_cevirme",), agirlik=1.1)
def levha_alani(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Alan biriminde katsayı KAREdir.

    "1 m = 1000 mm, öyleyse 1 m² = 1000 mm²" en yaygın birim hatasıdır;
    doğrusu 1.000.000. Hata bin katlık bir sipariş farkı yaratır.
    """
    en, boy, alan_m2 = rastgele.choice(LEVHA_OLCULERI)
    adet = rastgele.choice([4, 5, 6, 8])
    alan_mm2 = en * boy
    toplam = round(alan_m2 * adet, 4)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mob-levha-alani",
        ders="mobilya",
        baslik="Bin Katlık Sipariş",
        kademe=kademe,
        konu="levha_alani",
        kazanim="Alan birimlerinde dönüşüm katsayısının kare olması "
                "(1 m² = 1.000.000 mm²).",
        dikkat=5,
        brifing=(
            "Depoya {} adet raf yapılacak. Her rafın ölçüsü {} mm × {} mm.\n\n"
            "{} sipariş formunu dolduruyor ama form m² istiyor; ölçüler ise "
            "milimetre cinsinden.\n\n"
            "Formda yanlış birim yazılırsa depo ya bin kat fazla ya bin kat "
            "az levha gönderir. İkisi de kötü."
        ).format(adet, en, boy, kisi),
        kanitlar=[
            Kanit("Raf ölçüsü",
                  "Bir raf: {} mm × {} mm. Adet: {}.".format(en, boy, adet),
                  bedel=1, kritik=True),
            Kanit("Birim çizelgesi",
                  "\"1 m = 1000 mm. Ama ALAN için katsayı karedir: "
                  "1 m² = 1000 × 1000 = 1.000.000 mm².\"",
                  bedel=2, kritik=True),
            Kanit("Depo formu",
                  "Sipariş birimi: m². Ondalık kabul ediliyor.", bedel=1),
            Kanit("Eski sipariş",
                  "Geçen yıl bir form \"480 m²\" olarak gitmiş; gelen levha "
                  "atölyeye sığmamış.", bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="mm² cinsinden bulunan alanı m²'ye nasıl çeviririz?",
                dogru="1.000.000'a böleriz; çünkü alan katsayısı 1000'in "
                      "karesidir.",
                yanlislar={
                    "1000'e böleriz; 1 m = 1000 mm olduğu için.":
                        "Uzunluk katsayısını alan için kullandın. Alanda iki "
                        "boyut birden küçülür: 1000 × 1000 = 1.000.000. "
                        "Bu hata sonucu bin kat büyük gösterir.",
                    "100'e böleriz.":
                        "100 katsayısı metre ile santimetre arasındadır ve o "
                        "da uzunluk içindir. Buradaki birimler mm ve m.",
                    "1.000.000 ile çarparız.":
                        "Küçük birimden büyük birime geçerken sayı KÜÇÜLÜR. "
                        "Çarpmak ters yön.",
                    "İki kenarı ayrı ayrı 1000'e bölüp çarparız, sonra tekrar "
                    "1000'e böleriz.":
                        "İlk kısmı doğru ama sonrasında fazladan bir bölme "
                        "var; kenarları metreye çevirdikten sonra çarpım "
                        "zaten m² verir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir raf {} × {} = {} mm². 1 m² = 1.000.000 mm² olduğu "
                    "için {} ÷ 1.000.000 = {} m².".format(
                        en, boy, alan_mm2, alan_mm2, sy(alan_m2))),
                ipuclari=[
                    "Alan iki uzunluğun çarpımı. Katsayı kaç kez uygulanır?",
                    "Kenarları önce metreye çevirip çarpmayı dene, sonucu "
                    "karşılaştır.",
                ],
                cozum=(
                    "1) Bir raf = {} × {} = {} mm²\n"
                    "2) {} ÷ 1.000.000 = {} m²\n"
                    "3) {} adet × {} = {} m²".format(
                        en, boy, alan_mm2, alan_mm2, sy(alan_m2),
                        adet, sy(alan_m2), sy(toplam))),
            ),
            sayi_adimi(
                soru="Bir rafın alanı kaç m²?",
                cevap=alan_m2,
                birim="m²",
                aciklama="{} ÷ 1.000.000 = {} m²".format(
                    alan_mm2, sy(alan_m2)),
                yaygin_yanlislar={
                    round(alan_mm2 / 1000.0, 4):
                        "1000'e böldün - uzunluk katsayısı. Alanda katsayı "
                        "karedir: 1.000.000.",
                    alan_mm2:
                        "mm² değerini yazdın; form m² istiyor.",
                    round(alan_mm2 / 10000.0, 4):
                        "10.000 katsayısı m² ile cm² arasındadır. Burada mm² "
                        "ile m² arasında dönüyorsun.",
                },
                puan=14,
            ),
            sayi_adimi(
                soru="{} raf için toplam kaç m² levha gerekir?".format(adet),
                cevap=toplam,
                birim="m²",
                aciklama="{} × {} = {} m²".format(
                    adet, sy(alan_m2), sy(toplam)),
                yaygin_yanlislar={
                    alan_m2:
                        "Tek rafın alanını yazdın; adetle çarpmayı unuttun.",
                    round(alan_mm2 * adet / 1000.0, 4):
                        "Birim çevirmeyi yine 1000 ile yaptın; hata toplama "
                        "da taşındı.",
                },
                puan=12,
            ),
        ],
        kapanis=("Form {} m² olarak gönderildi. Birim çizelgesi atölye "
                 "duvarına asıldı.".format(sy(toplam))),
        odul={"cevher": 2, "erzak": 1, "itibar": 2},
    )
