# -*- coding: utf-8 -*-
"""Öğretmen ve sınıfsız öğrenci için haftalık okul programı ekranı."""
from copy import deepcopy

from oyun.motor import terminal as ekran
from oyun.motor import ders_programi as dp
from oyun.motor.kayit_defteri import konular, uygun_kayitlar
from oyun.motor.modeller import DERS_ADLARI


def _satir_metni(satir, konu_goster=True):
    metin = "{} {}–{} · {}".format(dp.GUNLER[satir["gun"]], satir["baslangic"],
                                   satir["bitis"], satir["ad"])
    if satir["konular"]:
        metin += " · " + (", ".join(k.replace("_", " ") for k in satir["konular"])
                          if konu_goster else "{} konu odağı".format(len(satir["konular"])))
    return metin


def _satir_al(eski=None, sinif_duzeyi=0):
    gun = ekran.menu("Gün:", list(dp.GUNLER) + ["Vazgeç"])
    if gun >= len(dp.GUNLER):
        return None
    bas = ekran.sor("Başlangıç (SS:DD; x = vazgeç):",
                    eski["baslangic"] if eski else "08:30").strip()
    if bas.lower() == "x":
        return None
    bit = ekran.sor("Bitiş (SS:DD; x = vazgeç):",
                    eski["bitis"] if eski else "09:10").strip()
    if bit.lower() == "x":
        return None
    dersler = list(DERS_ADLARI)
    secim = ekran.menu("Okuldaki ders:", [DERS_ADLARI[d] for d in dersler]
                       + ["Başka okul dersi (henüz soru içeriği yok)", "Vazgeç"])
    if secim > len(dersler):
        return None
    ders = dersler[secim] if secim < len(dersler) else ""
    ad = DERS_ADLARI.get(ders) or ekran.sor("Dersin okuldaki adı (boş = vazgeç):", "").strip()
    if not ad:
        return None
    secilen = []
    if ders:
        liste = konular(ders)
        ekran.yaz("İşlenen konuları seçin. Program her hafta tekrar eder; konu değişince bu satırı düzenleyin.", "gri")
        for i, konu in enumerate(liste, 1):
            k = uygun_kayitlar(ders=ders, konu=konu)
            alt, ust = min(s.kademeler[0] for s in k), max(s.kademeler[1] for s in k)
            ekran.yaz("{}) {} (içerik düzeyi {}–{})".format(i, konu.replace("_", " "), alt, ust))
        if not liste:
            ekran.yaz("Bu dersin henüz soru içeriği yok; programda yine de yer alabilir.", "acik_sari")
        else:
            onceki = eski["konular"] if eski and eski["ders"] == ders else []
            varsayilan = ",".join(str(liste.index(k) + 1) for k in onceki if k in liste)
            ham = ekran.sor("Konu numaraları (ör. 1,3; 0 = otomatik odak; x = vazgeç):",
                            varsayilan or "0").strip()
            if ham.lower() == "x":
                return None
            if ham and ham != "0":
                try:
                    sayilar = list(dict.fromkeys(int(n.strip()) for n in ham.split(",")))
                    if any(n < 1 or n > len(liste) for n in sayilar):
                        raise ValueError()
                    secilen = [liste[n - 1] for n in sayilar]
                except ValueError:
                    raise ValueError("Konu numaralarını listedeki sayılarla ve virgülle yazın.")
            if sinif_duzeyi and any(not any(k.kademeler[0] <= sinif_duzeyi
                                           for k in uygun_kayitlar(ders=ders, konu=konu))
                                    for konu in secilen):
                ekran.yaz("Bazı seçili konular sınıf düzeyinin üstünde; o konulardan soru gelmeyecek.", "acik_sari")
    return {"gun": gun, "baslangic": bas, "bitis": bit, "ders": ders,
            "ad": ad, "konular": secilen}


def program_ekrani(durum=None, sinif_kodu=""):
    """Öğrenci sınıf programını okur; öğretmen kendi masasından düzenler."""
    kod = durum.sinif_kodu if durum is not None else sinif_kodu
    duzenleyebilir = durum is None or not kod
    try:
        program = dp.sinif_programini_oku(kod) if kod else dp.ogrenci_programi(durum)
    except (OSError, ValueError) as sorun:
        ekran.hata("Program açılamadı: {}".format(sorun))
        ekran.bekle()
        return
    while True:
        ekran.temizle()
        ekran.baslik("OKUL DERS PROGRAMI", "kalin", "acik_cam")
        ekran.yaz("Saatler Türkiye saatidir. " + ("Sınıf kodu: " + kod if kod else "Kendi okul programın."), "gri")
        ekran.yaz("Sınıf düzeyi: {} · {}".format(program["sinif_duzeyi"] or "belirtilmedi",
                  "Tam konu odağı" if program["tam_odak"] else "Konu odağı + aynı dersten pekiştirme"))
        if not program["dersler"]:
            ekran.bilgi("Henüz ders eklenmemiş.")
        for i, satir in enumerate(program["dersler"], 1):
            ekran.yaz("{}) {}".format(i, _satir_metni(satir, duzenleyebilir)))
        if not duzenleyebilir:
            ekran.yaz("Bu programı öğretmenin düzenler. Konu odağı Komuta Masası'nda uygulanır.", "gri")
            ekran.bekle()
            return
        secim = ekran.menu("", ["Ders ekle", "Dersi / işlenen konuları düzenle",
                                "Dersi kaldır", "Bir günün programını başka güne kopyala",
                                "Sınıf düzeyini seç", "Konu odağını değiştir", "Geri dön"])
        if secim == 6:
            return
        aday = deepcopy(program)
        try:
            if secim == 0:
                satir = _satir_al(sinif_duzeyi=program["sinif_duzeyi"])
                if satir is None:
                    continue
                aday["dersler"].append(satir)
            elif secim in (1, 2):
                if not aday["dersler"]:
                    continue
                i = ekran.menu("Ders:", [_satir_metni(s) for s in aday["dersler"]] + ["Vazgeç"])
                if i >= len(aday["dersler"]):
                    continue
                if secim == 1:
                    satir = _satir_al(aday["dersler"][i], program["sinif_duzeyi"])
                    if satir is None:
                        continue
                    aday["dersler"][i] = satir
                else:
                    del aday["dersler"][i]
            elif secim == 3:
                kaynak = ekran.menu("Hangi günden?", list(dp.GUNLER) + ["Vazgeç"])
                if kaynak >= 7:
                    continue
                hedef = ekran.menu("Hangi güne eklensin?", list(dp.GUNLER) + ["Vazgeç"])
                if hedef >= 7 or hedef == kaynak:
                    continue
                aday["dersler"].extend(dict(s, gun=hedef) for s in program["dersler"] if s["gun"] == kaynak)
            elif secim == 4:
                i = ekran.menu("Sınıf düzeyi:", ["{}. sınıf".format(n) for n in range(1, 13)]
                               + ["Belirtilmedi", "Vazgeç"])
                if i == 13:
                    continue
                aday["sinif_duzeyi"] = i + 1 if i < 12 else 0
            elif secim == 5:
                aday["tam_odak"] = not aday["tam_odak"]
            else:
                return
            aday = dp.programi_dogrula(aday)
            if kod:
                dp.sinif_programini_kaydet(kod, aday)
            else:
                eski = durum.ders_programi
                durum.ders_programi = aday
                try:
                    durum.kaydet()
                except OSError:
                    durum.ders_programi = eski
                    raise
            program = aday
            ekran.basari("Program kaydedildi. Görev panosu güncel programa göre yenilenir.")
        except (OSError, ValueError) as sorun:
            ekran.hata(str(sorun))
        ekran.bekle()


def ogretmen_programi():
    from araclar.sinif import siniflari_listele
    siniflar = siniflari_listele()
    if not siniflar:
        ekran.bilgi("Önce Sınıflar ve kodlar bölümünden sınıf açın.")
        ekran.bekle()
        return
    i = ekran.menu("Hangi sınıfın programı?", ["{} · {}".format(s["ad"], s["kod"])
                                             for s in siniflar] + ["Vazgeç"])
    if i < len(siniflar):
        program_ekrani(sinif_kodu=siniflar[i]["kod"])
