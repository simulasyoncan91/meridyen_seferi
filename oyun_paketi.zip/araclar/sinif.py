# -*- coding: utf-8 -*-
"""
Sınıf tanımı ve sınıf kodu.

NEDEN BÖYLE
-----------
Öğrencinin sınıfını otomatik belirlemek istendi. İlk düşünülen yol okul
sisteminden (e-Okul) çekmekti; mümkün değil — dışarıya açık bir arayüzü
yok. İkinci düşünülen yol öğrenciden kimlik numarası almaktı; bu da
yapılmadı: kimlik numarası hassas veridir, çocuktan toplamak ayrı bir
sorumluluk getirir ve oyunun ona hiçbir işlevsel ihtiyacı yoktur.

Kalan ve çalışan yol bu: öğretmen sınıfı açar, kısa bir kod alır, tahtaya
yazar. Öğrenci kodu girer; sınıfı, şubesi ve okulu kendiliğinden dolar.
Dışarıdan sisteme bağlanmak yok, kimlik numarası yok, tahmin edilebilir
parola yok. Sunucu da gerekmiyor: ortak klasör yeter.

Kod okunaklı olmak zorunda çünkü tahtadan okunup elle yazılıyor. Bu
yüzden karışan karakterler (0/O, 1/I/l) alfabede yok.

Sınıf dosyaları `kayitlar/siniflar/` altında; öğrenci kayıtlarıyla aynı
klasörde değil. Öğrenci listeleyici zaten YAPIYA bakıp eliyor (her öğrenci
kaydında `dersler` vardır), ama ayrı klasör bunu bir kez daha garantiler.
"""
from __future__ import annotations

import io
import json
import os
import random
import time
from typing import Any, Dict, List, Optional

from oyun.motor import ag, durum as durum_modulu
from oyun.motor.terminal import ayni_ad

# Karisan karakterler yok: 0/O, 1/I/L kod tahtadan yanlis okunur.
ALFABE = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
SON_EK_UZUNLUK = 4
AZAMI_DENEME = 50
# Sunucu kodu reddederse (baska okulda ayni kod) kac yeni kodla denenecek.
SUNUCU_DENEME = 5


def sinif_klasoru() -> str:
    return os.path.join(durum_modulu.KAYIT_KLASORU, "siniflar")


def _dosya_yolu(kod: str) -> str:
    return os.path.join(sinif_klasoru(), kod.upper() + ".json")


def _onek(ad: str) -> str:
    """Sınıf adından okunaklı bir ön ek: '7-A' -> '7A', 'Ortak' -> 'ORTA'."""
    temiz = "".join(h for h in (ad or "").upper() if h.isalnum())
    # Türkçe harfleri ASCII'ye indir: kod telefonla, kâğıtla, klavyeyle yazılıyor.
    cevrim = {"Ç": "C", "Ğ": "G", "İ": "I", "Ö": "O", "Ş": "S", "Ü": "U", "I": "I"}
    temiz = "".join(cevrim.get(h, h) for h in temiz)
    temiz = "".join(h for h in temiz if h in ALFABE)
    return temiz[:4] or "SNF"


def kod_uret(ad: str, rastgele: Optional[random.Random] = None) -> str:
    """Boşta olan bir sınıf kodu üretir. Çakışırsa yeniden dener."""
    rnd = rastgele or random.SystemRandom()
    onek = _onek(ad)
    for _ in range(AZAMI_DENEME):
        son = "".join(rnd.choice(ALFABE) for _ in range(SON_EK_UZUNLUK))
        kod = "{}-{}".format(onek, son)
        if not os.path.exists(_dosya_yolu(kod)):
            return kod
    # Bu noktaya gelinmesi icin ayni onekte 50 kod cakismasi gerekir.
    return "{}-{}{}".format(onek, "".join(rnd.choice(ALFABE) for _ in range(SON_EK_UZUNLUK)),
                            int(time.time()) % 1000)


def _anahtar_uret(rastgele: Optional[random.Random] = None) -> str:
    """Ogretmen anahtari. Tahtaya yazilmiyor, elle girilmiyor -- okunakli
    olmasi gerekmedigi icin tam alfabe kullanilabilir ve uzun tutulabilir."""
    kaynak = rastgele or random.SystemRandom()
    harfler = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return "".join(kaynak.choice(harfler) for _ in range(24))


def sinif_olustur(ad: str, okul: str = "", ogretmen: str = "",
                  rastgele: Optional[random.Random] = None) -> Dict[str, Any]:
    """Sınıfı diske yazar ve kaydı döner. `kod` alanı öğrenciye verilecektir."""
    ad = (ad or "").strip()
    if not ad:
        raise ValueError("Sınıf adı boş olamaz.")
    kod = kod_uret(ad, rastgele)
    # OGRETMEN ANAHTARI
    # -----------------
    # Sinif kodu tahtada yazili; sinifin tamami biliyor. Kod tek basina
    # yetki olsaydi her ogrenci el kaldirma listesini okur ve silebilirdi.
    # Bu anahtar yalnizca ogretmenin makinesinde duruyor ve sunucuda
    # ogretmen isleri icin isteniyor. Bir parola DEGIL, bir ders
    # oturumunun kapi kolu: kaybolursa YENI bir sinif acilir -- ayni kod
    # baska anahtarla acilamaz (bkz. sinif_sunucusu.sinif_ac, GOREVLER B36).
    anahtar = _anahtar_uret(rastgele)
    okul = (okul or "").strip()
    # Sunucu varsa sinif ONCE orada acilir. Kod yalnizca YEREL dosyalara
    # karsi benzersiz; sunucuda baska bir okul ayni kodu almis olabilir ve
    # sunucu var olan sinifi devretmez (B36.4). Eskiden cevaba bakilmiyordu:
    # sinif yerelde acilir, sunucuda HIC kaydolmaz, ogrenciler "sinif
    # bulunamadi" alirdi (B36.19). Ret gelirse yeni kodla denenir. Cevap
    # hic gelmezse (None: ag yok) sessizce gecilir -- ayni agda calisan
    # kurulumlarin sunucuya ihtiyaci yok.
    if ag.acik_mi():
        for _ in range(SUNUCU_DENEME):
            yanit = ag.gonder("/sinif", {"kod": kod, "ad": ad,
                                         "okul": okul, "anahtar": anahtar})
            if not (isinstance(yanit, dict) and yanit.get("tamam") is False):
                break
            kod = kod_uret(ad, rastgele)
        else:
            raise RuntimeError(
                "Sunucu sınıfı kabul etmedi (kod çakışması ya da sunucu "
                "dolu). Biraz sonra yeniden deneyin.")
    kayit = {
        "_tur": "sinif",          # yapiya gore ayirt etmek icin
        "kod": kod,
        "ad": ad,
        "okul": okul,
        "ogretmen": (ogretmen or "").strip(),
        "anahtar": anahtar,
        "olusturma": time.time(),
    }
    os.makedirs(sinif_klasoru(), exist_ok=True)
    hedef = _dosya_yolu(kod)
    gecici = hedef + ".tmp"
    with io.open(gecici, "w", encoding="utf-8") as dosya:
        json.dump(kayit, dosya, ensure_ascii=False, indent=2)
    os.replace(gecici, hedef)      # atomik: yarim dosya birakmaz
    return kayit


def ogretmen_anahtari(kod: str) -> str:
    """Sinifin ogretmen anahtari; yalnizca yerel dosyadan okunur.

    Sunucu bu anahtari HIC dondurmez (bkz. sinif_sunucusu.kod_dogrula),
    o yuzden burada ag yolu yok. Ogretmen sinifi hangi makinede actiysa
    anahtar orada.
    """
    try:
        with io.open(_dosya_yolu(kod), encoding="utf-8") as dosya:
            return json.load(dosya).get("anahtar", "") or ""
    except Exception:              # noqa: BLE001
        return ""


def sinif_bul(kod: str) -> Optional[Dict[str, Any]]:
    """Koda karşılık gelen sınıf; yoksa None. Büyük/küçük harf farketmez.

    Sunucu tanımlıysa ÖNCE oraya sorulur. Sebep: telefondan oynayan
    öğrencinin sınıf dosyalarına erişimi yoktur -- kendi cihazında
    öğretmenin klasörü diye bir şey yok. Sınıfı tanıyan tek yer sunucudur.
    Sunucu yoksa ya da cevap vermezse yerel dosyaya bakılır; aynı ağdaki
    kurulumlar böyle çalışıyor.
    """
    kod = (kod or "").strip().upper()
    if not kod:
        return None
    if ag.acik_mi():
        from urllib.parse import quote
        yanit = ag.gonder("/kod?kod=" + quote(kod, safe=""))
        if yanit and yanit.get("kod"):
            # Sunucu öğretmen anahtarını DÖNDÜRMEZ; burada da yok.
            return {"_tur": "sinif", "kod": yanit["kod"],
                    "ad": yanit.get("ad", ""), "okul": yanit.get("okul", ""),
                    "ogretmen": "", "olusturma": 0.0}
    try:
        with io.open(_dosya_yolu(kod), encoding="utf-8") as dosya:
            veri = json.load(dosya)
    except Exception:              # noqa: BLE001 - bozuk dosya yok sayilir
        return None
    return veri if veri.get("_tur") == "sinif" else None


def siniflari_listele() -> List[Dict[str, Any]]:
    """Tanımlı sınıflar, oluşturma sırasına göre."""
    klasor = sinif_klasoru()
    if not os.path.isdir(klasor):
        return []
    bulunan = []
    for dosya_adi in sorted(os.listdir(klasor)):
        if not dosya_adi.endswith(".json"):
            continue
        try:
            with io.open(os.path.join(klasor, dosya_adi), encoding="utf-8") as dosya:
                veri = json.load(dosya)
        except Exception:          # noqa: BLE001
            continue
        if veri.get("_tur") == "sinif":
            bulunan.append(veri)
    return sorted(bulunan, key=lambda k: k.get("olusturma", 0))


def sinif_ogrencileri(kod: str) -> List[Dict[str, Any]]:
    """Bu sınıfa bağlı öğrencilerin özetleri, ADA GÖRE sıralı.

    ADA göre sıralı olması bilinçli. `TASARIM_NOTLARI.md` §0: oyun öğretir,
    ölçmez. Sınıf arkadaşlarını göstermek başarı sıralaması göstermek
    değildir; puana, göreve ya da ilerlemeye göre sıralamak onu bir not
    tablosuna çevirir. Burada dönen özette ilerleme bilgisi YOKTUR.
    """
    kod = (kod or "").strip().upper()
    if not kod:
        return []
    bulunan = []
    for ozet in durum_modulu.kayitlari_listele():
        if (ozet.get("sinif_kodu") or "").strip().upper() == kod:
            bulunan.append({"ad": ozet.get("ad", ""),
                            "numara": ozet.get("numara", "")})
    return sorted(bulunan, key=lambda o: (o["ad"] or "").lower())


def ogrenciyi_tasi(kayit_yolu: str, yeni_kod: str) -> bool:
    """Bir öğrenciyi başka sınıfa taşır ya da sınıf bağını kaldırır.

    KAYIT SİLİNMEZ. Yanlış koda giren, sınıf değiştiren ya da okuldan
    ayrılan öğrenci olur; bunların hiçbiri öğrencinin ilerlemesini
    silmeyi gerektirmez. Değişen yalnızca sınıf bağıdır.

    `yeni_kod` boş verilirse bağ kaldırılır (öğrenci artık hiçbir sınıfta
    görünmez ama kaydı ve ilerlemesi durur).
    """
    durum = durum_modulu.yukle(kayit_yolu)
    if durum is None:
        return False

    # KIMLIGI SABITLE. `Durum.kimlik()` numarali kayitlarda "sinif-numara"
    # uretiyor; sinifi degistirmek kimligi, kimlik de DOSYA ADINI degistirir.
    # Sonuc: eski dosya yerinde kalir, ogrenci iki sinifta birden gorunur ve
    # ilerlemesi ikiye bolunur. Ustelik PIN ozeti kimlikle tuzlandigi icin
    # ogrenci yeni dosyaya kendi PIN'iyle giremez.
    #
    # Cozum silmek degil sabitlemek: `kayit_adi` doluysa kimlik ondan turer
    # (bkz. durum.Durum.kimlik). Tasimadan ONCE mevcut kimligi oraya yaziyoruz,
    # boylece dosya adi da PIN tuzu da degismiyor.
    if not durum.kayit_adi:
        durum.kayit_adi = durum.kimlik()

    yeni_kod = (yeni_kod or "").strip().upper()
    if yeni_kod:
        kayit = sinif_bul(yeni_kod)
        if kayit is None:
            return False
        # GERCEK AD PANOYA DUSMESIN. Evde acilan seferde (B35.14) "Adın ya da
        # takma adın" cevabi takma ad olarak da yaziliyor -- sinif yokken
        # zarari yok, ama cogu zaman ogrencinin gercek adi. Takma ad
        # ekranindaki "Bu senin gercek adin" uyarisi hic gorulmedi. Kayit
        # sinifa ILK kez baglanirken takma ad gercek adla ayniysa silinir
        # (pano takma adsizi gostermez) ve ogrenciye bir sonraki girisinde
        # uyariyla sorulur.
        if (not (durum.sinif_kodu or "").strip()
                and ayni_ad(durum.takma_ad or "", durum.ad or "")):
            durum.takma_ad = ""
            bekleyen = list(durum.ayarlar.get("kurulum_bekliyor") or [])
            if "takma_ad" not in bekleyen:
                bekleyen.append("takma_ad")
            durum.ayarlar["kurulum_bekliyor"] = bekleyen
        durum.sinif_kodu = yeni_kod
        durum.sinif = kayit["ad"]
        durum.okul = kayit.get("okul", "")
    else:
        durum.sinif_kodu = ""
        durum.okul = ""
    durum.kaydet()
    return True
