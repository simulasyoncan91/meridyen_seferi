# -*- coding: utf-8 -*-
"""
İttifak eşleştirmesinin hesabı.

Kural tek cümle: **aynı çekirdeği paylaşan farklı dal.** Bir marangozun fire
hesabıyla bir elektrikçinin kablo firesi aynı bağıntıdır; ikisi birbirine
"nasıl çözdüğünü" anlatabilir. Aynı dalda olan iki öğrenci ise birbirine yeni
bir şey vermez - orada asimetri yoktur.

Bu modül yalnızca HESAP yapar; kimin kiminle eşleşeceğine karar vermez ve ağ
bilmez. Sunucu yazıldığında eşleştirme buradan beslenecek. Bugün ise oyun
içinde "bu masadaki işlerin şu dalla ortak yanı var" satırını üretiyor.

Gerekçesi ve klanın kurulma ölçütü (aynı kademe ± 1, farklı dal):
TASARIM_NOTLARI.md §4-5
"""
from __future__ import annotations

from typing import Dict, List, Tuple

from .kayit_defteri import uygun_kayitlar
from .modeller import (
    DERS_ADLARI, MESLEK_CEKIRDEKLERI, alan_yolu, yol_alanlari,
)

# Klan kurulurken kabul edilen kademe farkı. Sıfır olsaydı eşleşme çok
# zorlaşırdı; büyük olsaydı yardım tek yönlü hâle gelir ve ittifak destek
# hattına dönerdi (bkz. TASARIM_NOTLARI.md §4).
KADEME_TOLERANSI = 1


def meslek_alanlari() -> List[str]:
    return yol_alanlari("meslek_uretim")


def alan_cekirdekleri(alan: str, kademe: int = None) -> List[str]:
    """
    Bir dalda içeriği bulunan çekirdekler.

    `kademe` verilirse yalnızca o kademede oynanabilen görevler sayılır:
    9. sınıftaki bir öğrenciye, ancak 12. sınıfta açılan bir çekirdek
    üzerinden ittifak önermek boşa çıkar.
    """
    bulunan: List[str] = []
    for kayit in uygun_kayitlar(ders=alan, kademe=kademe):
        for etiket in kayit.etiketler:
            if etiket in MESLEK_CEKIRDEKLERI and etiket not in bulunan:
                bulunan.append(etiket)
    return sorted(bulunan)


def ortak_cekirdekler(alan_a: str, alan_b: str, kademe: int = None) -> List[str]:
    """İki dalın paylaştığı çekirdekler."""
    if alan_a == alan_b:
        return []
    ortak = set(alan_cekirdekleri(alan_a, kademe)) & set(
        alan_cekirdekleri(alan_b, kademe))
    return sorted(ortak)


def ittifak_adaylari(alan: str, kademe: int = None) -> List[Tuple[str, List[str]]]:
    """
    Bir dalın ittifak kurabileceği dallar, çok ortak çekirdeği olandan aza.

    (dal_kodu, paylaşılan çekirdekler) çiftleri döner. Aynı dal listeye
    girmez: ittifakı çalıştıran şey asimetridir.
    """
    adaylar = []
    for oteki in meslek_alanlari():
        ortak = ortak_cekirdekler(alan, oteki, kademe)
        if ortak:
            adaylar.append((oteki, ortak))
    adaylar.sort(key=lambda ikili: (-len(ikili[1]), ikili[0]))
    return adaylar


def kademe_uyar_mi(kademe_a: int, kademe_b: int) -> bool:
    """Klan ölçütünün kademe yarısı: aynı seviye ± KADEME_TOLERANSI."""
    return abs(int(kademe_a) - int(kademe_b)) <= KADEME_TOLERANSI


def klan_kurulabilir_mi(alan_a: str, kademe_a: int,
                        alan_b: str, kademe_b: int) -> bool:
    """
    Klan ölçütünün tamamı: farklı dal, yakın kademe, paylaşılan çekirdek.

    Üçü birden sağlanmalı. Farklı dal ama uzak kademe olursa yardım tek yönlü
    olur; yakın kademe ama aynı dal olursa kimse ötekine yeni bir şey vermez.
    """
    if alan_a == alan_b:
        return False
    if not kademe_uyar_mi(kademe_a, kademe_b):
        return False
    ortalama = (int(kademe_a) + int(kademe_b)) // 2
    return bool(ortak_cekirdekler(alan_a, alan_b, ortalama))


def kopru_ozeti(kademe: int = None) -> Dict[str, List[str]]:
    """
    Çekirdek -> o çekirdekte içeriği olan dallar.

    İçerik yazarken hangi çekirdeğin hâlâ tek dalda kaldığını görmek için;
    tek dalda kalan çekirdek hiçbir ittifak köprüsü kurmaz.
    """
    ozet: Dict[str, List[str]] = {}
    for cekirdek in MESLEK_CEKIRDEKLERI:
        dallar = [a for a in meslek_alanlari()
                  if cekirdek in alan_cekirdekleri(a, kademe)]
        if dallar:
            ozet[cekirdek] = dallar
    return ozet


def ortaklik_satiri(alan: str, kademe: int = None) -> str:
    """
    Oyunda gösterilecek tek satırlık ortaklık notu.

    Amaç öğrenciye şunu sezdirmek: bu masadaki iş yalnızca senin dalına ait
    değil, başka bir bölümdeki biri de aynı bağıntıyla uğraşıyor. İttifak
    özelliği açıldığında bu satır tıklanabilir hâle gelecek.
    """
    if alan_yolu(alan) != "meslek_uretim":
        return ""
    adaylar = ittifak_adaylari(alan, kademe)
    if not adaylar:
        return ""
    en_iyi, ortak = adaylar[0]
    # Çekirdek adlarının kendisi virgül ve "ve" içeriyor ("güç, iş ve verim");
    # hepsini yan yana dizmek cümleyi okunmaz yapıyor. En çok ikisini yaz,
    # gerisini sayıyla geç.
    gosterilen = [MESLEK_CEKIRDEKLERI[c].lower() for c in ortak[:2]]
    konu_metni = "; ".join(gosterilen)
    kalan = len(ortak) - len(gosterilen)
    if kalan:
        konu_metni += " ve {} başlık daha".format(kalan)
    return "{} bölümüyle ortak işin var: {}.".format(
        DERS_ADLARI.get(en_iyi, en_iyi), konu_metni)
