# -*- coding: utf-8 -*-
"""Haftalık okul programı ve görev odağı. Saatler Türkiye saatidir.

Program dersin zamanını, öğretmenin seçtiği konular ise işlenen içeriği
belirler. Müfredat/yıllık plan otomatik tahmin edilmez. Python 3.8'de de
ek saat dilimi paketi gerektirmemesi için Türkiye'nin UTC+3 saati kullanılır.
"""
from __future__ import annotations

import json
import math
import os
import re
import tempfile
from datetime import datetime, timedelta, timezone

from . import durum as durum_modulu
from .kayit_defteri import EN_COK_KADEME_SAPMASI, uygun_kayitlar
from .konu_secimi import konu_sec
from .modeller import DERS_ADLARI

GUNLER = ("Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar")
TURKIYE_SAATI = timezone(timedelta(hours=3))


def simdi():
    return datetime.now(TURKIYE_SAATI)


def bos_program():
    return {"surum": 1, "sinif_duzeyi": 0, "tam_odak": False, "dersler": []}


def dakika(saat):
    if not isinstance(saat, str) or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", saat):
        raise ValueError("Saat SS:DD biçiminde olmalı (ör. 09:40).")
    return int(saat[:2]) * 60 + int(saat[3:])


def programi_dogrula(program):
    """Yeni, sıralanmış kopya; hatalı programı kısmen kaydetmeyiz."""
    if not isinstance(program, dict):
        raise ValueError("Ders programı okunamadı.")
    sonuc = bos_program()
    if program.get("surum", 1) != 1:
        raise ValueError("Bu ders programı sürümü desteklenmiyor.")
    duzey = program.get("sinif_duzeyi", 0)
    if type(duzey) is not int or not 0 <= duzey <= 12:
        raise ValueError("Sınıf düzeyi 1–12 olmalı; belirtilmediyse 0 kullanılır.")
    sonuc["sinif_duzeyi"] = duzey
    if type(program.get("tam_odak", False)) is not bool:
        raise ValueError("Konu odağı ayarı geçersiz.")
    sonuc["tam_odak"] = program.get("tam_odak", False)
    satirlar = program.get("dersler", [])
    if not isinstance(satirlar, list):
        raise ValueError("Programın ders satırları okunamadı.")
    for satir in satirlar:
        if not isinstance(satir, dict):
            raise ValueError("Programda geçersiz ders satırı var.")
        gun = satir.get("gun")
        if type(gun) is not int or not 0 <= gun <= 6:
            raise ValueError("Haftanın günü geçersiz.")
        bas, bit = satir.get("baslangic"), satir.get("bitis")
        if dakika(bas) >= dakika(bit):
            raise ValueError("Dersin bitişi başlangıcından sonra olmalı.")
        ders, ad = satir.get("ders", ""), satir.get("ad", "")
        if not isinstance(ders, str) or (ders and ders not in DERS_ADLARI):
            raise ValueError("Ders kodu tanınmıyor. İçeriksiz ders için ders adı girin.")
        if not isinstance(ad, str) or (not ders and not ad.strip()):
            raise ValueError("Ders adı boş olamaz.")
        konular = satir.get("konular", [])
        if (not isinstance(konular, list)
                or any(not isinstance(k, str) or not k.strip() for k in konular)):
            raise ValueError("Konu listesi geçersiz.")
        if not ders and konular:
            raise ValueError("İçeriği olmayan derse konu bağlanamaz.")
        sonuc["dersler"].append({
            "gun": gun, "baslangic": bas, "bitis": bit, "ders": ders,
            "ad": DERS_ADLARI.get(ders, ad.strip()),
            "konular": list(dict.fromkeys(k.strip() for k in konular)),
        })
    sonuc["dersler"].sort(key=lambda s: (s["gun"], s["baslangic"]))
    for onceki, sonraki in zip(sonuc["dersler"], sonuc["dersler"][1:]):
        if onceki["gun"] == sonraki["gun"] and onceki["bitis"] > sonraki["baslangic"]:
            raise ValueError("{} günü {} ve {} derslerinin saatleri çakışıyor.".format(
                GUNLER[onceki["gun"]], onceki["ad"], sonraki["ad"]))
    return sonuc


def _program_yolu(kod):
    kod = (kod or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9]+-[A-Z0-9]+", kod):
        raise ValueError("Sınıf kodu geçersiz.")
    return os.path.join(durum_modulu.KAYIT_KLASORU, "programlar", kod + ".json")


def sinif_programini_oku(kod):
    try:
        with open(_program_yolu(kod), encoding="utf-8") as dosya:
            return programi_dogrula(json.load(dosya))
    except FileNotFoundError:
        return bos_program()


def sinif_programini_kaydet(kod, program):
    from araclar.sinif import sinif_bul
    hedef = _program_yolu(kod)
    if not sinif_bul(kod):
        raise ValueError("Programı kaydetmeden önce sınıf oluşturulmalı.")
    veri = programi_dogrula(program)
    os.makedirs(os.path.dirname(hedef), exist_ok=True)
    gecici = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", suffix=".tmp",
                                         dir=os.path.dirname(hedef), delete=False) as dosya:
            gecici = dosya.name
            json.dump(veri, dosya, ensure_ascii=False, indent=2)
        os.replace(gecici, hedef)
    finally:
        if gecici and os.path.exists(gecici):
            os.unlink(gecici)


def ogrenci_programi(durum):
    # Sınıf değişince eski kişisel program devreye girmez.
    if durum.sinif_kodu:
        return sinif_programini_oku(durum.sinif_kodu)
    return programi_dogrula(durum.ders_programi)


def ders_odagi(program, zaman=None):
    """(ders satırı, açıklama). Başlangıç dahil, bitiş hariçtir.

    Naif datetime testlerde Türkiye yerel saati kabul edilir. Saat dilimli
    değerler Türkiye saatine çevrilir. Tatil takvimi henüz bu modelde yoktur.
    """
    program = programi_dogrula(program)
    zaman = zaman or simdi()
    if zaman.tzinfo is not None:
        zaman = zaman.astimezone(TURKIYE_SAATI)
    bugun = [s for s in program["dersler"] if s["gun"] == zaman.weekday()]
    if not bugun:
        return None, ("Bugün programda ders yok; serbest keşif." if program["dersler"]
                      else "Ders programı eklenmemiş; serbest keşif.")
    an = zaman.hour * 60 + zaman.minute
    for satir in bugun:
        if dakika(satir["baslangic"]) <= an < dakika(satir["bitis"]):
            return satir, "Şimdiki ders"
    gecen = [s for s in bugun if dakika(s["bitis"]) <= an]
    if gecen:
        return gecen[-1], "Son dersten pekiştirme"
    return bugun[0], "İlk derse hazırlık"


def odakli_teklifler(durum, program, satir, rastgele, adet=3):
    """En az 2/3 seçili konu; kalan aynı derste çalışılmış konudan tekrar.

    Adaylar önce ders/konu/kademe ile kesin süzülür. Genel üreticinin
    konu bulunmayınca başka konuya düşen davranışı burada kullanılmaz.
    """
    if adet <= 0:
        return [], ""
    ders = satir["ders"]
    if not ders:
        return [], "{} için henüz oyun içeriği yok.".format(satir["ad"])
    dd = durum.ders(ders)
    tavan = program.get("sinif_duzeyi") or 13
    hedef = min(dd.kademe, tavan)

    def adaylar(konular=None):
        bulunan = []
        for kayit in uygun_kayitlar(ders=ders):
            if konular is not None and kayit.konu not in konular:
                continue
            alt, ust = kayit.kademeler
            ust = min(ust, tavan)
            if alt > ust:
                continue
            kademe = max(alt, min(hedef, ust))
            if abs(kademe - hedef) <= EN_COK_KADEME_SAPMASI:
                bulunan.append((kayit, kademe))
        return bulunan

    secili = satir["konular"]
    odak = adaylar(secili or None)
    if not odak:
        return [], "Bu dersin seçili konuları ve düzeyi için uygun görev yok. Programdaki konu/düzeyi öğretmeninle gözden geçir."
    from .tekrar import zamani_gelen_konular
    hatirlanacak = {k for _, k in zamani_gelen_konular(durum, ders)}
    # Önce tek konu odağı seç. Zorlanma küçük bir olasılık artışıdır;
    # en düşük başarıdaki konuya veya en eski tarihe sürekli kilitlenilmez.
    if not secili:
        konu = konu_sec(durum, ders, [k.konu for k, _ in odak], rastgele, hatirlanacak)
        odak = [(k, n) for k, n in odak if k.konu == konu]
    odak_konulari = {k.konu for k, _ in odak}
    tekrar = adaylar({k for k, v in dd.konular.items()
                      if v.baslanmis and k not in odak_konulari})
    eksik = sorted(set(secili) - odak_konulari)
    uyari = ("Bu düzeyde içeriği bulunmayan seçili konu sayısı: {}. "
             "Uygun olan konularla devam ediliyor.".format(len(eksik)) if eksik else "")
    kota = adet if program.get("tam_odak") else int(math.ceil(adet * 2 / 3))
    teklifler, kullanilan = [], []
    konu_sayilari = {}
    for i in range(adet):
        havuz = odak if len(teklifler) < kota or not tekrar else tekrar
        # Konuyu üreticiden önce seç: çok soru ailesi olan konu sırf bu
        # nedenle baskınlaşmasın. Pano içindeki konu çeşitliliğini koru.
        en_az = min(konu_sayilari.get(k.konu, 0) for k, _ in havuz)
        konular = [k.konu for k, _ in havuz if konu_sayilari.get(k.konu, 0) == en_az]
        konu = konu_sec(durum, ders, konular, rastgele, hatirlanacak)
        havuz = [(k, n) for k, n in havuz if k.konu == konu]
        taze = [(k, n) for k, n in havuz if k.ad not in kullanilan] or havuz
        yeni = [(k, n) for k, n in taze if k.ad not in dd.son_ureticiler] or taze
        k, n = rastgele.choices(yeni, weights=[max(0.01, k.agirlik) for k, _ in yeni])[0]
        b = k.fonksiyon(rastgele, n)
        if b is None or b.konu != k.konu or not 1 <= b.kademe <= tavan:
            uyari = "Bir görev seçili konu/düzeye uygun üretilemedi; öğretmen içerik denetimini çalıştırabilir."
            continue
        b.ders = ders
        setattr(b, "uretici_adi", k.ad)
        teklifler.append(b)
        kullanilan.append(k.ad)
        konu_sayilari[k.konu] = konu_sayilari.get(k.konu, 0) + 1
    return teklifler, uyari
