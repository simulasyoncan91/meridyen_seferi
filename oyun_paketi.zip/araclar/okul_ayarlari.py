# -*- coding: utf-8 -*-
"""
Okul ayarları: saklama süresi (B36.16) ve branş dışı konular (B42.4).

    python main.py --okul-ayarlari      (ya da OKUL_AYARLARI.cmd)

NEDEN AYRI BİR DOSYA
--------------------
Bu iki ayar öğretmenin değil OKULUN kararıdır: kaydın ne kadar saklanacağına
veri sorumlusu (okul) karar verir; öğretmenin kendi branşı dışındaki
derslere konu gönderip gönderemeyeceğine okul yönetimi karar verir. Bu
yüzden öğretmen masasında bu ayarları değiştiren bir düğme yok; masa yalnız
okur ve gösterir.

Dosya `kayitlar/okul_ayarlari.json`. Öğretmen parolası gibi bu da GERÇEK
bir güvenlik sınırı değildir: kayıt klasörüne yazabilen herkes dosyayı
değiştirebilir (bkz. araclar/ogretmen.py başı). Zarar sınırlı tutuldu:
saklama süresi ne yazılırsa yazılsın hiçbir kayıt SESSİZCE silinmez; süre
yalnız öğretmen masasındaki "süresi dolanlar" listesini belirler ve silme
öğretmenin açık onayıyla yapılır.

İLERİYE UYUM (B47.1): dosya okunup değiştirilip geri yazılırken tanınmayan
alanlar olduğu gibi korunur. Dosya yoksa ya da bozuksa varsayılanlar
geçerlidir.
"""
from __future__ import annotations

import io
import json
import os
from typing import Any, Dict, Optional

from oyun.motor import durum as durum_modulu

AYAR_ADI = "okul_ayarlari.json"

# Kullanıcı kararı, 29 Eylül 2026: 12 ay oynanmayan kayıt silinir; süre
# ayarlanabilir. Hukuki uygunluğu okul/hukukçu görüşü bekliyor.
VARSAYILAN_SAKLAMA_AY = 12
# 0 "kapalı" DEMEK DEĞİL. Sıfır ya da eksi yazılırsa en kısa süre geçerli
# olur; saklama kuralını dosyaya bir rakam yazarak kapatmak mümkün olmasın.
EN_AZ_SAKLAMA_AY = 1
# On yıl: ortaokul + lise süresinin üstü. Daha uzunu yazım hatasıdır.
EN_COK_SAKLAMA_AY = 120


def ayar_dosyasi() -> str:
    # Yol her çağrıda okunur: kayıt klasörü MERIDYEN_KAYIT ile ve testlerde
    # değişiyor (bkz. araclar/ogretmen.ayar_dosyasi).
    return os.path.join(durum_modulu.KAYIT_KLASORU, AYAR_ADI)


def oku() -> Dict[str, Any]:
    try:
        with io.open(ayar_dosyasi(), encoding="utf-8") as dosya:
            veri = json.load(dosya)
    except (OSError, ValueError):
        return {}
    return veri if isinstance(veri, dict) else {}


def _yaz(veri: Dict[str, Any]) -> None:
    os.makedirs(durum_modulu.KAYIT_KLASORU, exist_ok=True)
    hedef = ayar_dosyasi()
    gecici = hedef + ".tmp"
    with io.open(gecici, "w", encoding="utf-8") as dosya:
        json.dump(veri, dosya, ensure_ascii=False, indent=2)
    os.replace(gecici, hedef)


def saklama_ayi_coz(deger: Any) -> int:
    """Dosyadaki değeri geçerli bir ay sayısına çevirir.

    Sayı değilse (yok, metin, bozuk) varsayılan 12; sayıysa 1..120 arasına
    çekilir. 0 ya da eksi değer kuralı KAPATMAZ, en kısa süre olur.
    """
    if isinstance(deger, bool):          # JSON true/false sayı sayılmasın
        return VARSAYILAN_SAKLAMA_AY
    try:
        ay = int(float(deger))
    except (TypeError, ValueError, OverflowError):
        return VARSAYILAN_SAKLAMA_AY
    return max(EN_AZ_SAKLAMA_AY, min(EN_COK_SAKLAMA_AY, ay))


def saklama_ayi() -> int:
    """Kaç ay oynanmayan kaydın "süresi dolan" sayılacağı."""
    return saklama_ayi_coz(oku().get("saklama_ay", VARSAYILAN_SAKLAMA_AY))


def brans_disi_acik() -> bool:
    """Okul yönetimi branş dışı dersleri açtı mı? Varsayılan KAPALI.

    Yalnız gerçek JSON `true` açar; "evet", 1 gibi yazımlar açmaz --
    varsayılanı kapalı olan bir izin belirsiz bir yazımla açılmasın.
    """
    return oku().get("brans_disi_acik") is True


def ayarla(saklama_ay: Optional[int] = None,
           brans_disi: Optional[bool] = None) -> Dict[str, Any]:
    """Verilen ayarları yazar; öteki (bilinmeyen dahil) alanlara dokunmaz."""
    veri = oku()
    if saklama_ay is not None:
        veri["saklama_ay"] = saklama_ayi_coz(saklama_ay)
    if brans_disi is not None:
        veri["brans_disi_acik"] = bool(brans_disi)
    _yaz(veri)
    return veri


# --------------------------------------------------------------------------
# Komut satırı ekranı
# --------------------------------------------------------------------------

def _parola_ile_gir() -> bool:
    """Öğretmen parolası kuruluysa ister; kurulu değilse serbest.

    Parola yokken serbest çünkü okul ayarı kurulumun ilk adımlarından biri
    olabilir; zararı da sınırlı (bkz. modül başı).
    """
    from araclar import ogretmen
    from oyun.motor import terminal as ekran

    if not ogretmen.parola_kurulu_mu():
        return True
    for kalan in (2, 1, 0):
        if ogretmen.parola_dogru_mu(ekran.sor("Öğretmen parolası:")):
            return True
        if kalan:
            ekran.hata("Parola tutmadı. {} hakkın kaldı.".format(kalan))
    ekran.hata("Parola tutmadı.")
    return False


def ekran_ac() -> int:
    """`--okul-ayarlari`: okul yönetiminin iki ayarı."""
    from oyun.motor import terminal as ekran

    ekran.temizle()
    ekran.baslik("OKUL AYARLARI", "kalin", "acik_cam")
    ekran.bilgi("Bu ayarlar okul yönetiminin kararıdır; öğretmen masasında "
                "yalnız gösterilir.")
    if not _parola_ile_gir():
        return 1
    while True:
        ekran.yaz()
        ay = saklama_ayi()
        acik = brans_disi_acik()
        secim = ekran.menu("", [
            ("Saklama süresi: {} ay".format(ay),
             "bu süre boyunca oynanmayan kayıtlar öğretmen masasında silinmek "
             "üzere listelenir; onaysız silme yok"),
            ("Branş dışı dersler: " + ("AÇIK" if acik else "kapalı"),
             "açıksa öğretmen branşı dışındaki derslerin konularını da "
             "sınıf programına ekleyebilir"),
            ("Çık", ""),
        ])
        if secim == 0:
            ham = ekran.sor("Kaç ay? ({}-{}):".format(
                EN_AZ_SAKLAMA_AY, EN_COK_SAKLAMA_AY), str(ay)).strip()
            try:
                yeni = int(ham)
            except ValueError:
                ekran.hata("Bir tam sayı yazın.")
                continue
            if not EN_AZ_SAKLAMA_AY <= yeni <= EN_COK_SAKLAMA_AY:
                ekran.hata("Süre {} ile {} ay arasında olmalı. 0 yazmak kuralı "
                           "kapatmaz.".format(EN_AZ_SAKLAMA_AY,
                                              EN_COK_SAKLAMA_AY))
                continue
            ayarla(saklama_ay=yeni)
            ekran.basari("Saklama süresi {} ay oldu.".format(yeni))
        elif secim == 1:
            ayarla(brans_disi=not acik)
            ekran.basari("Branş dışı dersler " +
                         ("kapatıldı." if acik else "açıldı."))
        else:
            return 0
