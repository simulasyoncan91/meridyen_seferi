# -*- coding: utf-8 -*-
"""
Matematik görevleri.

Bu modül aynı zamanda diğer ders modülleri için ÖRNEKTİR. Bir görev yazarken
uyulan kural şu: soru metninde "x'i bul" geçmez. Bir aksaklık anlatılır,
kanıtlar dağıtılır, öğrenci önce hangi bağıntının işlediğini seçer (MODEL
adımı), ancak ondan sonra sayıyı hesaplar.

Kademe ölçeği: 1-4 ilkokul, 5-8 ortaokul, 9-12 lise, 13 üniversite.
"""
from __future__ import annotations

import math
import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    DEPO_ADLARI, MEVKI_ADLARI, PERSONEL, ad_sec, model_adimi, sayi_adimi,
    secim_adimi, sy, yorum_adimi,
)


# ==========================================================================
# İLKOKUL
# ==========================================================================

@bulmaca(ders="matematik", konu="esit_paylar", kademeler=(1, 4), agirlik=1.2)
def sabah_sayimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Eşit sandıklar + tek seferlik eksilme. Bilinmeyen: bir sandığın içi."""
    sandik_sayisi = rastgele.choice([3, 4, 5])
    icerik = rastgele.randrange(6, 13 + 3 * kademe)
    alinan = rastgele.randrange(3, 9)
    toplam = sandik_sayisi * icerik - alinan
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-sabah-sayimi",
        ders="matematik",
        baslik="Sabah Sayımı",
        kademe=kademe,
        konu="esit_paylar",
        kazanim="Eşit gruplara ayırma; toplama-çıkarma ile bilinmeyeni bulma.",
        dikkat=5,
        brifing=(
            "Sabah mutfağa {} sandık ekmek geldi. Hepsi aynı fırından, aynı "
            "şekilde doldurulmuş.\n\n"
            "Öğle olmadan {} sandıklardan birinden {} ekmek alıp gözcü kulesine "
            "götürdü. Şimdi mutfakta toplam {} ekmek sayılıyor.\n\n"
            "Aşçı, sandıkların ilk hâlinde kaçar ekmek olduğunu bilmek istiyor; "
            "yarınki siparişi ona göre verecek."
        ).format(sandik_sayisi, kisi, alinan, toplam),
        kanitlar=[
            Kanit("Mutfak defteri",
                  "Sabah teslimi: {} sandık. Sandık içerikleri ayrı ayrı "
                  "yazılmamış.".format(sandik_sayisi), bedel=1),
            Kanit("Fırıncının notu",
                  "\"Sandıkların hepsini aynı sayıda doldurdum. Eksik ya da "
                  "fazla koymadım.\"", bedel=1, kritik=True),
            Kanit("Kule teslim fişi",
                  "Kuleye çıkarılan: {} ekmek. Tek bir sandıktan "
                  "alınmış.".format(alinan), bedel=1, kritik=True),
            Kanit("Öğle sayımı", "Mutfakta kalan toplam: {}".format(toplam), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Sandıkların ilk hâlini bulmak için hangi yol doğru?",
                dogru=("Kuleye giden {} ekmeği geri eklersek sandıkların ilk toplamı "
                       "çıkar; onu {}'e bölersek bir sandık bulunur.".format(alinan, sandik_sayisi)),
                yanlislar={
                    "Şimdiki toplamı doğrudan {}'e böleriz.".format(sandik_sayisi):
                        "Eksileni geri koymadan böldün. Şu anki sayım eksik: "
                        "kuleye giden {} ekmek de sabah sandıkların "
                        "içindeydi.".format(alinan),
                    "Şimdiki toplamdan {} daha çıkarıp {}'e böleriz.".format(
                        alinan, sandik_sayisi):
                        "Eksilmeyi iki kez saydın. O {} ekmek zaten şimdiki "
                        "sayımdan düşmüş durumda; bir kez daha çıkarmak "
                        "sandıkları olduğundan küçük gösterir.".format(alinan),
                    "Her sandıktan {} ekmek alındığı için {} sayısını {} ile "
                    "çarparız.".format(alinan, alinan, sandik_sayisi):
                        "Eksilmeyi bütün sandıklara yaydın. Kule fişi ekmeğin "
                        "TEK bir sandıktan alındığını yazıyor; çarpmak bu "
                        "eksilmeyi sandık sayısı kadar büyütür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Eksilme yalnızca BİR sandıktan oldu ama sayım toplamda yapıldı. "
                    "Bu yüzden önce eksileni geri koyup bütünü tamamlıyoruz, sonra "
                    "eşit parçalara bölüyoruz. Sıra ters olursa bölme yanlış sayıyı böler."
                ),
                ipuclari=[
                    "Sandıklar eşitti. Şu anda eşit değiller; çünkü birinden alındı.",
                    "Alınanı geri koyarsan yine eşit olurlar.",
                ],
            ),
            sayi_adimi(
                soru="Sandıkların hiç dokunulmamış hâlinde toplam kaç ekmek vardı?",
                cevap=sandik_sayisi * icerik,
                birim="ekmek",
                aciklama="{} + {} = {}. Kuleye giden ekmek de sabah gelen ekmekti.".format(
                    toplam, alinan, sandik_sayisi * icerik),
                yaygin_yanlislar={
                    toplam - alinan:
                        "Eklemek yerine çıkardın. Ekmek sandıklardan ÇIKTI; "
                        "ilk hâline dönmek için geri koymalısın.",
                    toplam:
                        "Şu anki sayımı yazdın. Soru sandıkların hiç "
                        "dokunulmamış hâlini soruyor; kuleye giden ekmek o "
                        "sırada hâlâ içerideydi.",
                },
                ipuclari=["Şu anki sayıma, dışarı çıkan ekmeği geri ekle."],
                puan=10,
            ),
            sayi_adimi(
                soru="Bir sandıkta kaç ekmek vardı?",
                cevap=icerik,
                birim="ekmek",
                aciklama="{} ÷ {} = {}. Sandıklar eşit olduğu için bölme geçerli.".format(
                    sandik_sayisi * icerik, sandik_sayisi, icerik),
                yaygin_yanlislar={
                    toplam / float(sandik_sayisi):
                        "Eksileni geri koymadan böldün. Böldüğün sayı, bir "
                        "sandıktan {} ekmek çıkmış hâli; sandıklar o anda "
                        "eşit değildi.".format(alinan),
                    sandik_sayisi * icerik:
                        "Bütün sandıkların toplamını yazdın. Soru BİR sandığın "
                        "içini soruyor; bölmeyi yapmayı unuttun.",
                },
                ipuclari=["Bütün toplamı sandık sayısına böl."],
                puan=12,
            ),
            yorum_adimi(
                soru="Fırıncının notu olmasaydı bu hesabı yapabilir miydik?",
                dogru="Hayır. Sandıkların eşit olduğunu bilmeden bölme yapılamazdı.",
                yanlislar={
                    "Evet, toplam sayı yeterliydi.":
                        "Toplamı tek başına yeterli saydın. Bir toplam, o "
                        "toplamın sandıklara nasıl dağıldığını söylemez; aynı "
                        "sayıyı veren pek çok dağılım var.",
                    "Evet, çünkü sandık sayısı biliniyordu.":
                        "Sandık sayısı yalnızca kaça böleceğini söyler, "
                        "bölmenin geçerli olup olmadığını değil. Sandıklar "
                        "eşit değilse bölmenin sonucu bir ortalama olurdu.",
                    "Hayır, çünkü kule fişi eksikti.":
                        "Kule fişi elimizde ve alınan miktarı yazıyor. Eksik "
                        "olan o değil; sorunun düğümü bölmenin dayanağında.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir bilinmeyeni bulmak için elimizde her zaman bir 'eşitlik' "
                    "olması gerekir. Burada o eşitliği fırıncının notu verdi: "
                    "sandıklar eşit. Kanıtın işi budur."
                ),
                puan=8,
            ),
        ],
        kapanis=(
            "Aşçı defterine sandık başına {} yazıyor. \"Bir dahaki sefere\" diyor, "
            "\"sandıkları ayrı ayrı da yazarım.\"".format(icerik)
        ),
        odul={"erzak": 6, "itibar": 2},
    )


@bulmaca(ders="matematik", konu="geometri_kesif", kademeler=(3, 6))
def alan_kesfi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Çevre + kenarlar arası ilişki verilmiş, kenarlar bilinmiyor."""
    kisa = rastgele.randrange(4, 9 + kademe)
    fark = rastgele.choice([2, 3, 4, 5])
    uzun = kisa + fark
    cevre = 2 * (kisa + uzun)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="mat-alan-kesfi",
        ders="matematik",
        baslik="Çadır Yeri",
        kademe=kademe,
        konu="geometri_kesif",
        kazanim="Dikdörtgende çevre-alan ilişkisi; sözel bilgiden denklem kurma.",
        dikkat=5,
        brifing=(
            "{} mevkiinde kurulacak depo çadırı için zemin ipi çekilmiş. İpin "
            "tamamı {} metre ve çadırın dört kenarını tam olarak dolanıyor.\n\n"
            "Çadırı kuran ekip ölçüleri yazmayı unutmuş. Yalnızca şunu "
            "hatırlıyorlar: uzun kenar, kısa kenardan {} metre fazlaymış.\n\n"
            "Depoya kaç metrekare yayacağımızı bilmemiz gerekiyor."
        ).format(mevki, cevre, fark),
        kanitlar=[
            Kanit("İp makarası etiketi",
                  "Kullanılan ip: {} m. Artan ip yok.".format(cevre), bedel=1, kritik=True),
            Kanit("Ekip başının ifadesi",
                  "\"Uzun kenarı kısa kenardan {} metre uzun tuttuk. Köşeler "
                  "dik.\"".format(fark), bedel=1, kritik=True),
            Kanit("Zemin fotoğrafı",
                  "Dört köşeli, düzgün bir dikdörtgen. Kenarlardan biri gözle "
                  "görülür şekilde daha uzun.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kısa kenara k dersek, ipin uzunluğunu hangi ifade anlatır?",
                dogru="2 × k + 2 × (k + {}) = {}".format(fark, cevre),
                yanlislar={
                    "k + (k + {}) = {}".format(fark, cevre):
                        "Yalnızca iki kenarı topladın; bu yarım çevredir. İp "
                        "dört kenarı da dolanıyor.",
                    "k × (k + {}) = {}".format(fark, cevre):
                        "Kenarları çarptın. Çarpım alanı verir; oysa {} metre "
                        "bir ip uzunluğu, bir alan değil.".format(cevre),
                    "2 × k + (k + {}) = {}".format(fark, cevre):
                        "Kısa kenarı iki kez, uzun kenarı bir kez saydın. "
                        "Dikdörtgende karşılıklı kenarlar eşittir; uzun "
                        "kenardan da iki tane var.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çevre dört kenarın toplamıdır: iki kısa, iki uzun. Uzun kenar "
                    "'k + {}' olduğu için ifade 2k + 2(k+{}) olur. İki kenarı toplamak "
                    "(yarım çevre) ya da kenarları çarpmak (alan) farklı şeylerdir."
                ).format(fark, fark),
                ipuclari=[
                    "İp dört kenarı da dolanıyor, ikisini değil.",
                    "Karşılıklı kenarlar eşit uzunluktadır.",
                ],
            ),
            sayi_adimi(
                soru="Kısa kenar kaç metre?",
                cevap=kisa,
                birim="m",
                aciklama="4k + {} = {} olur, buradan 4k = {} ve k = {}.".format(
                    2 * fark, cevre, cevre - 2 * fark, kisa),
                yaygin_yanlislar={
                    cevre / 4.0:
                        "Kenarları eşit kabul edip dörde böldün. Bu bir kare "
                        "olurdu; oysa uzun kenar kısadan {} metre "
                        "fazla.".format(fark),
                    (cevre - 2 * fark) / 2.0:
                        "Fazlalığı doğru attın ama ikiye böldün. Geriye kalan "
                        "sayı DÖRT eşit kenarı temsil ediyor, ikisini değil.",
                    uzun:
                        "Uzun kenarı buldun. Fazlalığı çıkarman gerekirken "
                        "eklemişsin; soru kısa kenarı soruyor.",
                },
                ipuclari=["Önce parantezleri aç, sonra sabitleri diğer tarafa at."],
            ),
            sayi_adimi(
                soru="Çadırın taban alanı kaç metrekare?",
                cevap=kisa * uzun,
                birim="m²",
                aciklama="{} × {} = {} m². Alan kenarların çarpımıdır, toplamı değil.".format(
                    kisa, uzun, kisa * uzun),
                yaygin_yanlislar={
                    cevre:
                        "Çevreyi yazdın. Çevre kenarların toplamı, alan ise "
                        "çarpımıdır; ikisi farklı büyüklükler.",
                    kisa + uzun:
                        "Kenarları topladın. Toplam sana yarım çevreyi verir; "
                        "alan için iki kenarı çarpman gerekir.",
                    kisa * kisa:
                        "Kısa kenarı kendisiyle çarptın; bu bir kare olurdu. "
                        "Ekip başı uzun kenarın {} metre fazla olduğunu "
                        "söylüyor.".format(fark),
                },
                ipuclari=["Uzun kenarı da bul, sonra iki kenarı çarp."],
            ),
        ],
        kapanis="Depo çadırı {} m² olarak kayda geçti. Zemin brandası buna göre kesildi.".format(
            kisa * uzun),
        odul={"cevher": 4, "itibar": 3},
    )


# ==========================================================================
# ORTAOKUL
# ==========================================================================

@bulmaca(ders="matematik", konu="denklem_kurma", kademeler=(5, 9), agirlik=1.5)
def depo_sayimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Oyunun tanıtım bulmacası.

    İki depoda eşit miktar vardı; kayıtçı ayrı ayrı yazmak yerine toplamı yazdı.
    Sonra depolardan birine ek kaynak girdi. Elimizde yalnızca son toplam var.
    """
    her_depo = rastgele.randrange(30, 40 + 8 * kademe)
    ek = rastgele.choice([10, 15, 20, 25, 30, 40])
    toplam = 2 * her_depo + ek
    kuzey, guney = ad_sec(rastgele, DEPO_ADLARI, 2)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-depo-sayimi",
        ders="matematik",
        baslik="Depo Sayımı",
        kademe=kademe,
        konu="denklem_kurma",
        kazanim="Sözel durumdan birinci dereceden denklem kurma ve çözme.",
        dikkat=6,
        brifing=(
            "Depo sayımında bir yanlışlık olmuş.\n\n"
            "{} ve {} depoları için ayrı ayrı sayı yazılması gerekirken, kayıtçı "
            "tek bir kaleme iki deponun toplamını yazmış. Aradan zaman geçmiş; "
            "bunu fark ettiğimizde {} deposuna {} kaynak daha eklenmişti.\n\n"
            "Sistemdeki bir hata yüzünden elimizde artık yalnızca son toplam "
            "var: {}.\n\n"
            "Komutan raporu depo depo istiyor. Hangi depoda ne var, bulmamız lazım."
        ).format(kuzey, guney, kuzey, ek, toplam),
        kanitlar=[
            Kanit("Kayıtçının defteri",
                  "İki depo tek satırda yazılmış. Satırın üstü sonradan çizilmiş, "
                  "kenarına \"ayrı yazılacaktı\" notu düşülmüş. Sayı okunmuyor.",
                  bedel=1),
            Kanit("{} ifadesi".format(kisi),
                  "\"Sayımdan önce iki depoyu ben doldurdum. İkisine de aynı "
                  "miktarı koydum, tek bir sandık bile fark etmez.\"",
                  bedel=2, kritik=True),
            Kanit("Sevkiyat fişi",
                  "Ek giriş: {} kaynak. Yalnızca {} deposuna boşaltıldı. Diğer "
                  "depoya dokunulmadı.".format(ek, kuzey),
                  bedel=2, kritik=True),
            Kanit("Sistem çıktısı",
                  "TOPLAM KAYNAK: {}\nDEPO KIRILIMI: (hata: veri yok)".format(toplam),
                  bedel=1, kritik=True),
            Kanit("Nöbetçi kaydı",
                  "Sayımdan bu yana depolardan hiçbir çıkış olmamış. Kapılar "
                  "mühürlü.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru=("Sayımdan önce her iki depoda bulunan miktara d dersek, "
                      "bugünkü toplamı hangi denklem anlatır?"),
                dogru="2d + {} = {}".format(ek, toplam),
                yanlislar={
                    "d + {} = {}".format(ek, toplam):
                        "Bir depoyu hesaba katmadın. İki depoda da d kadar "
                        "vardı; sayımdaki bütün 2d idi.",
                    "2 × (d + {}) = {}".format(ek, toplam):
                        "Ek kaynağı iki depoya birden ekledin. Sevkiyat fişi "
                        "yalnızca {} deposuna boşaltıldığını, diğerine "
                        "dokunulmadığını yazıyor.".format(kuzey),
                    "2d − {} = {}".format(ek, toplam):
                        "İşareti ters çevirdin. Ek kaynak depoya GİRDİ; "
                        "toplamı büyütür, küçültmez.",
                    "d² + {} = {}".format(ek, toplam):
                        "İki depoyu birbiriyle çarptın. 'İki depoda d kadar' "
                        "demek d'yi iki kez toplamak, yani 2d demektir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki depo da d kadardı, yani sayımdaki bütün 2d idi. Ek kaynak "
                    "yalnızca bir depoya girdi; bu yüzden {} bir kez eklenir. İki "
                    "depoya da eklenseydi 2(d+{}) olurdu ve sonuç değişirdi."
                ).format(ek, ek),
                ipuclari=[
                    "Bilinmeyen 'toplam' değil; iki deponun ortak başlangıç miktarı.",
                    "Ek kaynak kaç depoya girdi? Sevkiyat fişine bak.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Sayımdan önce her depoda kaç kaynak vardı?",
                cevap=her_depo,
                birim="kaynak",
                aciklama="2d + {} = {} → 2d = {} → d = {}.".format(
                    ek, toplam, toplam - ek, her_depo),
                yaygin_yanlislar={
                    toplam - ek:
                        "Ek kaynağı düştün ama ikiye bölmedin. Elinde kalan "
                        "sayı İKİ deponun toplamı; tek deponunki değil.",
                    toplam / 2.0:
                        "Ek kaynağı çıkarmadan böldün. O {} kaynak yalnızca "
                        "bir depoya girdi; ikisine birden pay "
                        "edilemez.".format(ek),
                },
                ipuclari=[
                    "Önce eklenen kaynağı toplamdan çıkar; geriye iki eşit deponun "
                    "toplamı kalır.",
                    "Kalan sayıyı ikiye böl.",
                ],
                puan=14,
            ),
            sayi_adimi(
                soru="Şu anda {} deposunda kaç kaynak var?".format(kuzey),
                cevap=her_depo + ek,
                birim="kaynak",
                aciklama="{} + {} = {}. Ek kaynak bu depoya girdiği için fark buradan doğdu.".format(
                    her_depo, ek, her_depo + ek),
                yaygin_yanlislar={
                    her_depo:
                        "Sayımdan ÖNCEKİ miktarı yazdın. Soru bugünü soruyor; "
                        "{} kaynak bu depoya sonradan girdi.".format(ek),
                    toplam / 2.0:
                        "Toplamı ikiye böldün, yani iki depoyu eşit saydın. "
                        "Ek kaynak yalnızca {} deposuna girdiği için depolar "
                        "artık eşit değil.".format(kuzey),
                },
                ipuclari=["Ek kaynak hangi depoya girmişti?"],
                puan=12,
            ),
            yorum_adimi(
                soru=("Komutan soruyor: iki depo eşit değil de biri diğerinin iki "
                      "katı olsaydı, elimizdeki tek sayıyla ({}) yine çözebilir "
                      "miydik?").format(toplam),
                dogru=("Evet, ama yalnızca bu yeni oranı bilseydik; her durumda "
                       "depolar arasında bilinen bir bağıntı gerekir."),
                yanlislar={
                    "Hayır, iki depo eşit olmadan bu tür bir hesap hiç yapılamaz.":
                        "Eşitliği zorunlu sandın. Gereken şey eşitlik değil, "
                        "depolar arasında BİLİNEN bir bağıntı; 'biri "
                        "diğerinin iki katı' da bir bağıntıdır.",
                    "Evet, toplam bilindiği sürece kırılım her zaman bulunabilir.":
                        "Tek bir toplamı yeterli saydın. {} sayısını veren "
                        "birden çok çift vardır; kırılımı kilitleyen şey ikinci "
                        "bağıntıdır.".format(toplam),
                    "Hayır, çünkü toplam tek başına her zaman yetersizdir.":
                        "Cümlenin ilk yarısı doğru ama soruya cevap vermiyor. "
                        "Toplam tek başına yetersizdir; soruda ise ikinci bir "
                        "bilgi -oran- veriliyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tek bir toplam, iki bilinmeyeni tek başına belirlemez; birden çok "
                    "olasılık vardır. Onları tek bir cevaba kilitleyen şey ikinci "
                    "bağıntıdır; burada iki başlangıç miktarının eşit olduğu bilgisi. Bu doğrusal modelde toplam ve eşitlik birlikte tek çözümü verir."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Rapor temize çekildi: {} deposu {}, {} deposu {}. Komutan kâğıda "
            "bakıp başını sallıyor: \"Bu sefer 'yaklaşık' yazmamışsın.\""
        ).format(kuzey, her_depo + ek, guney, her_depo),
        odul={"erzak": 8, "itibar": 5},
    )


@bulmaca(ders="matematik", konu="oran_oranti", kademeler=(5, 9))
def su_hatti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki borudan gelen su tek sayaçta toplanmış; oran bir teknisyen notunda."""
    pay = rastgele.choice([2, 3, 4, 5])
    payda = rastgele.choice([5, 7, 8, 9])
    if pay >= payda:
        pay, payda = 3, 5
    birim = rastgele.randrange(8, 12 + 3 * kademe)
    kucuk = pay * birim
    buyuk = payda * birim
    toplam = kucuk + buyuk
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-su-hatti",
        ders="matematik",
        baslik="Su Hattı",
        kademe=kademe,
        konu="oran_oranti",
        kazanim="Oran-orantı; toplamı bilinen iki büyüklüğü orana göre paylaştırma.",
        dikkat=6,
        brifing=(
            "{} kaynağından üsse iki boru geliyor: biri ince, biri kalın. İkisi "
            "de aynı depoya boşalıyor ve depoda tek bir sayaç var.\n\n"
            "Dün sayaç {} litre yazdı. Bugün ince boruda bir tıkanma şüphesi "
            "var; ama ince borunun tek başına ne kadar getirdiğini kimse "
            "bilmiyor, çünkü ayrı sayaç yok.\n\n"
            "{}, iki borunun eski ölçümlerini hatırlıyor."
        ).format(mevki, toplam, kisi),
        kanitlar=[
            Kanit("Sayaç kaydı", "Günlük toplam: {} litre".format(toplam), bedel=1, kritik=True),
            Kanit("{}'in notu".format(kisi),
                  "\"İnce borudan gelen su, kalın borudan gelenin {}/{}'i "
                  "kadardır. Bu oran yıllardır değişmedi.\"".format(pay, payda),
                  bedel=2, kritik=True),
            Kanit("Boru çapları",
                  "İnce boru: dar kesit. Kalın boru: geniş kesit. Sayısal ölçü "
                  "kaydedilmemiş.", bedel=1),
            Kanit("Depo taban planı",
                  "Her iki boru da aynı depoya, aynı yükseklikten boşalıyor. "
                  "Kaçak yok.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu durumu hangi kurulum doğru anlatır?",
                dogru=("İnce {}p, kalın {}p olsun (p ortak birim). O hâlde "
                       "{}p + {}p = {}".format(pay, payda, pay, payda, toplam)),
                yanlislar={
                    "İnce boru {} litre, kalın boru {} litre getirir.".format(pay, payda):
                        "Oranı doğrudan litre sandın. {}/{} bir MİKTAR değil, "
                        "iki boru arasındaki ilişkidir; gerçek litreler bu "
                        "oranın kaç katı olduğuna bağlı.".format(pay, payda),
                    "İnce boru toplamın {}/{}'i kadardır: ince = {} × {}/{}".format(
                        pay, payda, toplam, pay, payda):
                        "Oranı yanlış bütüne uyguladın. Verilen oran incenin "
                        "KALINA oranı; incenin toplama oranı değil. Toplam {} "
                        "birim pay ediyor.".format(pay + payda),
                    "Toplamı {} ile {} sayılarının farkına böleriz.".format(payda, pay):
                        "Farka böldün. Paylaştırmada bölen, payların TOPLAMIdır; "
                        "fark iki borunun arasındaki açıklığı anlatır, kaç "
                        "parçaya bölündüğünü değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"İncenin kalına oranı {}/{}\" demek, ikisini {} ve {} birimlik "
                    "paylar olarak düşünmek demektir. Dikkat: ince boru toplamın "
                    "{}/{}'i DEĞİL, toplamın {}/{}'idir; çünkü toplam {} birimdir."
                ).format(pay, payda, pay, payda, pay, payda, pay, pay + payda, pay + payda),
                ipuclari=[
                    "Oran verildiğinde ortak bir 'birim pay' tanımlamak işi kolaylaştırır.",
                    "Toplam kaç birim pay eder? İkisini topla.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Bir birim pay kaç litre?",
                cevap=birim,
                birim="litre",
                aciklama="{} + {} = {} birim pay var. {} ÷ {} = {} litre.".format(
                    pay, payda, pay + payda, toplam, pay + payda, birim),
                ipuclari=["Toplam litreyi toplam pay sayısına böl."],
            ),
            sayi_adimi(
                soru="İnce borudan günde kaç litre geliyor?",
                cevap=kucuk,
                birim="litre",
                aciklama="{} × {} = {} litre.".format(pay, birim, kucuk),
                ipuclari=["Birim payı ince borunun pay sayısıyla çarp."],
            ),
            yorum_adimi(
                soru=("Sayaç bugün {} litre gösterse, ince boruda tıkanma olduğunu "
                      "söyleyebilir miyiz?").format(toplam),
                dogru=("Hayır. Tek başına toplam, hangi borunun azaldığını "
                       "söylemez; oranın hâlâ geçerli olup olmadığını bilmiyoruz."),
                yanlislar={
                    "Evet, toplam değişmediğine göre ince boru tıkanmıştır.":
                        "Toplamın aynı kalmasından parçalar hakkında sonuç "
                        "çıkardın. Toplam sabitken içindeki dağılım pekâlâ "
                        "değişmiş olabilir; biri azalıp öteki artmış olabilir.",
                    "Evet, çünkü kalın boru hiç değişmez.":
                        "Kanıtlarda kalın borunun sabit olduğunu söyleyen bir "
                        "şey yok. Elinde olmayan bir varsayımı kanıt yerine "
                        "koydun.",
                    "Hayır, çünkü sayaç bozuktur.":
                        "Sonuca doğru yerden değil, olmayan bir arızadan "
                        "vardın. Sayaç çalışıyor; sorun ölçümde değil, tek bir "
                        "toplamın parçaları söyleyememesinde.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Toplam aynı kalmış olabilir ama içindeki dağılım değişmiş "
                    "olabilir. Tek bir toplu ölçüm, parçalar hakkında ancak "
                    "aralarındaki bağıntıyı bildiğimizde konuşur."
                ),
                puan=10,
            ),
        ],
        kapanis=(
            "İnce boruya ayrı sayaç takılması için talep açıldı. Bir daha kimse "
            "oranla uğraşmak zorunda kalmayacak."
        ),
        odul={"erzak": 5, "enerji": 4},
    )


@bulmaca(ders="matematik", konu="yuzde", kademeler=(6, 10))
def fire_hesabi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yüzde kayıptan sonraki miktar biliniyor; başlangıç bilinmiyor."""
    yuzde = rastgele.choice([10, 12, 15, 20, 25])
    baslangic = rastgele.randrange(20, 60) * 10
    kalan = baslangic * (100 - yuzde) // 100
    while kalan * 100 != baslangic * (100 - yuzde):
        baslangic = rastgele.randrange(20, 60) * 10
        kalan = baslangic * (100 - yuzde) // 100
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="mat-fire-hesabi",
        ders="matematik",
        baslik="Yol Firesi",
        kademe=kademe,
        konu="yuzde",
        kazanim="Yüzde azalma; sonuçtan başlangıç değerine geri gitme.",
        dikkat=5,
        brifing=(
            "{} üzerinden gelen tahıl konvoyu üsse ulaştı. Depoya {} kilo "
            "boşaltıldı.\n\n"
            "Sorun şu: yola çıkarken tartılan miktar kayda geçmemiş. Yalnızca "
            "sevkiyat sorumlusunun standart notu var: bu güzergâhta nem ve "
            "dökülme için ortalama kayıp oranı %{}. Bu hesapta aynı oranı varsayacağız.\n\n"
            "Merkez, bu varsayıma göre yola çıkan miktarı soruyor. Gerçek kaybı "
            "belirlemek için çıkış tartısının ayrıca bulunması gerekiyor."
        ).format(mevki, kalan, yuzde),
        kanitlar=[
            Kanit("Depo giriş fişi", "Boşaltılan: {} kg".format(kalan), bedel=1, kritik=True),
            Kanit("Güzergâh notu",
                  "\"{} hattında ortalama fire: %{}. Hesapta bu sevkiyatın da aynı oranda kayıp verdiğini varsayın. Bu oran yükün tamamı "
                  "üzerinden hesaplanır.\"".format(mevki, yuzde), bedel=2, kritik=True),
            Kanit("Sürücü ifadesi",
                  "\"Yolda hiçbir yere uğramadım, yükten kimseye bir şey "
                  "vermedim.\"", bedel=1),
            Kanit("Tartı fişi", "Çıkış tartısı: (boş - form doldurulmamış)", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yola çıkan miktara Y dersek, hangi bağıntı doğrudur?",
                dogru="Y × (100 − {}) / 100 = {}".format(yuzde, kalan),
                yanlislar={
                    "Y = {} + {} × {} / 100".format(kalan, kalan, yuzde):
                        "Fireyi VARAN yükün üstüne ekledin. Fire çıkan yükten "
                        "gider; varan yük zaten küçülmüş sayıdır ve onun "
                        "yüzdesi eksik kalır.",
                    "Y × {} / 100 = {}".format(yuzde, kalan):
                        "Varan yükü fire oranına eşitledin. Depoya giren kısım "
                        "kaybolan değil KALAN kısımdır: %{} değil %{}.".format(
                            yuzde, 100 - yuzde),
                    "Y = {} × (100 + {}) / 100".format(kalan, yuzde):
                        "Aynı ekleme hatasının başka yazımı. Çarpanın 100'ün "
                        "ÜSTÜNE çıkması, fireyi varan yüke eklediğin anlamına "
                        "gelir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Fire, yola çıkan miktarın yüzdesidir; varan miktarın değil. "
                    "Bu yüzden varan yük, çıkan yükün %{}'idir. Sık yapılan hata "
                    "varan yüke %{} eklemektir - o, daha küçük bir sayının yüzdesini "
                    "eklemek olur ve eksik çıkar."
                ).format(100 - yuzde, yuzde),
                ipuclari=[
                    "Yüzde her zaman bir 'bütün'ün yüzdesidir. Buradaki bütün hangisi?",
                    "Varan yük, çıkan yükün yüzde kaçıdır?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Yola kaç kilo tahıl çıkmıştı?",
                cevap=baslangic,
                birim="kg",
                aciklama="{} ÷ {} = {} kg.".format(kalan, sy((100 - yuzde) / 100.0), baslangic),
                ipuclari=["Varan yükü, kalan yüzdenin ondalık karşılığına böl."],
                tolerans=0.5,
            ),
            sayi_adimi(
                soru="Yolda kaç kilo kaybedilmiş?",
                cevap=baslangic - kalan,
                birim="kg",
                aciklama="{} − {} = {} kg. Bu, çıkan yükün tam %{}'i.".format(
                    baslangic, kalan, baslangic - kalan, yuzde),
                ipuclari=["Çıkan yükten varan yükü çıkar."],
                puan=10,
                tolerans=0.5,
            ),
        ],
        kapanis=(
            "Rapor merkeze gitti: hesap, kabul edilen fire oranına bağlı. Gerçek kayıp "
            "bu verilerle doğrulanamaz; eksik çıkış tartısı istendi."
        ),
        odul={"erzak": 7, "itibar": 4},
    )


@bulmaca(ders="matematik", konu="hiz_zaman", kademeler=(6, 11))
def bulusma_noktasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki ekip birbirine doğru yola çıkıyor; buluşma zamanı ve yeri bilinmiyor."""
    hiz_a = rastgele.choice([4, 5, 6])
    hiz_b = hiz_a + rastgele.choice([1, 2, 3])
    saat = rastgele.choice([2, 3, 4])
    mesafe = (hiz_a + hiz_b) * saat
    kisi_a, kisi_b = ad_sec(rastgele, PERSONEL, 2)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="mat-bulusma",
        ders="matematik",
        baslik="Buluşma Noktası",
        kademe=kademe,
        konu="hiz_zaman",
        kazanim="Sabit hızlı hareket; yaklaşan iki cismin buluşma zamanı.",
        dikkat=6,
        brifing=(
            "Telsiz sabahtan beri sessiz. {} üssünden, {} ise {} ileri "
            "karakolundan yola çıktı; ikisi de birbirine doğru yürüyor ve "
            "aralarındaki yol {} kilometre.\n\n"
            "Yola çıkıştan kaç saat sonra karşılaşacaklarını bilmemiz gerekiyor: "
            "buluşma noktasına sıcak yemek göndereceğiz ve yemeğin orada "
            "onlardan önce olması lazım.\n\n"
            "Kimse ne kadar süredir yürüdüklerini yazmamış."
        ).format(kisi_a, kisi_b, mevki, mesafe),
        kanitlar=[
            Kanit("Yürüyüş kaydı - {}".format(kisi_a),
                  "\"Saatte {} km giderim, yokuş olsa da bozmam.\"".format(hiz_a),
                  bedel=1, kritik=True),
            Kanit("Yürüyüş kaydı - {}".format(kisi_b),
                  "\"Saatte {} km. Yükü hafif olan hızlı gider.\"".format(hiz_b),
                  bedel=1, kritik=True),
            Kanit("Harita ölçümü",
                  "Üs ile {} karakolu arası: {} km. Tek yol var, sapak yok.".format(mevki, mesafe),
                  bedel=1, kritik=True),
            Kanit("Telsiz kaydı",
                  "İkisi de aynı anda, gün doğarken yola çıktığını bildirdi. "
                  "Sonra telsiz sustu.", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Aralarındaki mesafenin nasıl kapandığını hangi ifade anlatır?",
                dogru="Her saat aradaki mesafe ({} + {}) km azalır.".format(hiz_a, hiz_b),
                yanlislar={
                    "Her saat aradaki mesafe ({} − {}) km azalır.".format(hiz_b, hiz_a):
                        "Hızların farkını aldın. Fark, ikisi AYNI yöne giderken "
                        "işe yarar. Burada birbirlerine doğru gidiyorlar; "
                        "yaklaşma hızları toplanır.",
                    "Her saat aradaki mesafe ({} × {}) km azalır.".format(hiz_a, hiz_b):
                        "Hızları çarptın. Çarpım km/saat vermez; iki hızın "
                        "çarpımının anlamlı bir karşılığı yok.",
                    "Mesafe, hızlardan büyük olanına göre azalır: her saat {} km.".format(hiz_b):
                        "Yalnızca birinin hareketini saydın. Öteki de duruyor "
                        "değil; ikisi birden mesafeyi kapatıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İkisi BİRBİRİNE doğru gidiyor: bir saatte biri {} km, diğeri {} km "
                    "yol alıyor ve aradaki boşluk ikisinin toplamı kadar kapanıyor. "
                    "Hız farkı, aynı yönde giderken (biri diğerini kovalarken) kullanılır."
                ).format(hiz_a, hiz_b),
                ipuclari=[
                    "Yönleri aynı mı, zıt mı? Bu, toplayacağını mı çıkaracağını mı belirler.",
                    "Bir saat sonra aralarındaki mesafeden ne kadar eksilmiş olur?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Yola çıktıktan kaç saat sonra karşılaşırlar?",
                cevap=saat,
                birim="saat",
                aciklama="{} ÷ ({} + {}) = {} saat.".format(mesafe, hiz_a, hiz_b, saat),
                ipuclari=["Toplam mesafeyi, saatte kapanan mesafeye böl."],
            ),
            sayi_adimi(
                soru="Buluşma noktası üsten kaç kilometre uzakta olur?",
                cevap=hiz_a * saat,
                birim="km",
                aciklama="{} × {} = {} km. Yemeği bu noktaya göndereceğiz.".format(
                    hiz_a, saat, hiz_a * saat),
                ipuclari=["Üsten çıkan ekibin hızıyla süreyi çarp."],
            ),
        ],
        kapanis=(
            "Buluşma yeri ve yola çıkıştan itibaren geçecek süre yemek ekibine bildirildi. İki ekip de "
            "sıcak çorbaya yetişti; telsizin arızası akşam onarıldı."
        ),
        odul={"erzak": 6, "enerji": 4, "itibar": 3},
    )


# ==========================================================================
# LİSE
# ==========================================================================

@bulmaca(ders="matematik", konu="denklem_sistemi", kademeler=(8, 12), agirlik=1.2)
def kasa_kirilimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki tür kasa; sayıları ayrı yazılmamış, sadece adet ve toplam ağırlık var."""
    agir = rastgele.choice([25, 30, 40])
    hafif = rastgele.choice([8, 10, 12])
    while agir <= hafif:
        agir, hafif = 30, 10
    buyuk = rastgele.randrange(6, 16)
    kucuk = rastgele.randrange(6, 16)
    adet = buyuk + kucuk
    agirlik = buyuk * agir + kucuk * hafif
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-kasa-kirilimi",
        ders="matematik",
        baslik="Kasa Kırılımı",
        kademe=kademe,
        konu="denklem_sistemi",
        kazanim="İki bilinmeyenli denklem sistemi kurma ve yerine koyma yöntemi.",
        dikkat=6,
        brifing=(
            "Sevkiyat geldi ama irsaliye yarım. Toplam {} kasa indirildi ve "
            "kantar toplam {} kilo gösterdi.\n\n"
            "Kasaların bir kısmı büyük, bir kısmı küçük; ama hangisinden kaç "
            "tane olduğu hiçbir yere yazılmamış. Depoyu buna göre "
            "yerleştireceğiz: büyük kasalar alt rafa gidiyor ve alt rafta "
            "sınırlı yer var.\n\n"
            "{} kasa ağırlıklarını biliyor."
        ).format(adet, agirlik, kisi),
        kanitlar=[
            Kanit("Kantar fişi", "Toplam brüt: {} kg".format(agirlik), bedel=1, kritik=True),
            Kanit("İndirme sayımı", "Toplam kasa: {}".format(adet), bedel=1, kritik=True),
            Kanit("{}'in listesi".format(kisi),
                  "\"Büyük kasa dolu hâlde {} kg, küçük kasa {} kg. Standart, "
                  "hepsi aynı.\"".format(agir, hafif), bedel=2, kritik=True),
            Kanit("İrsaliye (yarım)",
                  "Gönderen: Merkez Depo. Kalem dökümü kısmı yırtılmış.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru=("Büyük kasa sayısına b, küçük kasa sayısına k dersek, "
                      "elimizdeki iki bilgiyi hangi çift anlatır?"),
                dogru="b + k = {}   ve   {}b + {}k = {}".format(adet, agir, hafif, agirlik),
                yanlislar={
                    "b + k = {}   ve   b × k = {}".format(adet, agirlik):
                        "Toplam ağırlığı kasa sayılarının çarpımı sandın. "
                        "Ağırlık, her kasanın kendi ağırlığıyla çarpılıp "
                        "toplanarak çıkar; kasa sayıları birbiriyle çarpılmaz.",
                    "{}b + {}k = {}   ve   b − k = {}".format(agir, hafif, agirlik, adet):
                        "İkinci denklemi fark olarak kurdun. Elimizdeki bilgi "
                        "kaç kasa OLDUĞU, kaç fazla olduğu değil.",
                    "b + k = {}   ve   ({} + {}) × (b + k) = {}".format(
                        adet, agir, hafif, agirlik):
                        "İki kasa tipinin ağırlığını toplayıp hepsine "
                        "uyguladın. Bu, her kasanın hem ağır hem hafif "
                        "olduğunu varsaymak olur; her tip kendi sayısıyla "
                        "çarpılmalı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Elimizde iki bağımsız bilgi var: kaç kasa (adet) ve kaç kilo "
                    "(ağırlık). İki bilinmeyen için tam olarak iki bağımsız denklem "
                    "gerekir. Adetler toplanır; ağırlıklar ise her kasanın kendi "
                    "kilosuyla çarpılıp toplanır."
                ),
                ipuclari=[
                    "Kaç bilinmeyen var? O kadar bağımsız bilgiye ihtiyacın olacak.",
                    "Bir bilgi sayıyı, diğeri ağırlığı anlatıyor. İkisini karıştırma.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Kaç tane büyük kasa var?",
                cevap=buyuk,
                birim="kasa",
                aciklama=(
                    "k = {} − b yazıp yerine koyarsak: {}b + {}({} − b) = {} → "
                    "{}b = {} → b = {}."
                ).format(adet, agir, hafif, adet, agirlik,
                         agir - hafif, agirlik - hafif * adet, buyuk),
                ipuclari=[
                    "Birinci denklemden k'yi yalnız bırakıp ikinciye yerleştir.",
                    "Hepsi küçük kasa olsaydı ağırlık ne olurdu? Aradaki fark, "
                    "büyük kasaların yarattığı fazladır.",
                ],
                puan=15,
            ),
            sayi_adimi(
                soru="Kaç tane küçük kasa var?",
                cevap=kucuk,
                birim="kasa",
                aciklama="{} − {} = {}.".format(adet, buyuk, kucuk),
                ipuclari=["Toplam kasa sayısından büyükleri çıkar."],
                puan=10,
            ),
            yorum_adimi(
                soru="Kantar bozuk çıksaydı, elimizde yalnızca kasa sayısı kalırdı. Ne olurdu?",
                dogru="Kırılım tek başına bulunamazdı; toplamı sağlayan birden çok tam sayı çifti olurdu.",
                yanlislar={
                    "Yine bulunurdu, çünkü kasa sayısı tek başına yeterlidir.":
                        "Tek denklemle iki bilinmeyeni çözdüğünü sandın. Kasa "
                        "sayısı yalnızca b + k'yi verir; hangi tipten kaç tane "
                        "olduğunu birden çok biçimde dağıtabilirsin. Kasa sayıları negatif olmayan tam sayılardır; olasılıklar sonludur.",
                    "Ortalama ağırlık alınarak kesin sonuç bulunurdu.":
                        "Ortalama bir tahmindir, kesin sonuç değil. Aynı "
                        "ortalamayı veren çok farklı dağılımlar vardır.",
                    "Büyük kasa sayısı her zaman toplamın yarısıdır, sorun olmazdı.":
                        "Dayanağı olmayan bir kural uydurdun. Kanıtlarda "
                        "tiplerin eşit sayıda olduğunu söyleyen bir şey yok.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki bilinmeyeni tek denklem belirlemez. Bu yüzden bu tür "
                    "görevlerde önce 'kaç bilinmeyenim var, kaç bağımsız bilgim var' "
                    "diye sorulur. Eşit değilse ya eksik veri vardır ya da fazladan "
                    "bir kabul yapılıyordur."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Alt rafa {} büyük kasa yerleşti, üst rafa {} küçük kasa. İrsaliyenin "
            "yırtık kısmı sonradan bulundu: sayılar tutuyor."
        ).format(buyuk, kucuk),
        odul={"cevher": 7, "itibar": 5},
    )


@bulmaca(ders="matematik", konu="dizi", kademeler=(9, 12))
def nobet_dizisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki ayrı günün kaydından aritmetik dizinin ilk terimi ve farkı bulunacak."""
    fark = rastgele.choice([2, 3, 4, 5])
    ilk = rastgele.randrange(4, 15)
    gun_a = rastgele.choice([3, 4, 5])
    gun_b = gun_a + rastgele.choice([6, 8, 10])
    deger_a = ilk + (gun_a - 1) * fark
    deger_b = ilk + (gun_b - 1) * fark
    hedef_gun = gun_b + rastgele.choice([3, 5, 7])
    hedef = ilk + (hedef_gun - 1) * fark

    return Bulmaca(
        kod="mat-nobet-dizisi",
        ders="matematik",
        baslik="Nöbet Çizelgesi",
        kademe=kademe,
        konu="dizi",
        kazanim="Aritmetik dizi; iki terimden ortak fark ve genel terimi çıkarma.",
        dikkat=6,
        brifing=(
            "Kış yaklaşırken nöbetçi sayısı her gün belli bir kural içinde "
            "artırılıyor. Kuralı koyan subay tayin oldu ve çizelgeyi de "
            "götürmüş.\n\n"
            "Elimizde yalnızca iki günün kaydı var: {}. gün {} nöbetçi, {}. gün "
            "{} nöbetçi görev yapmış. Aradaki günler kayıp.\n\n"
            "{}. gün için kaç kişilik yatakhane hazırlayacağımızı bilmemiz "
            "gerekiyor."
        ).format(gun_a, deger_a, gun_b, deger_b, hedef_gun),
        kanitlar=[
            Kanit("Nöbet defteri - {}. gün".format(gun_a),
                  "Görevli sayısı: {}".format(deger_a), bedel=1, kritik=True),
            Kanit("Nöbet defteri - {}. gün".format(gun_b),
                  "Görevli sayısı: {}".format(deger_b), bedel=1, kritik=True),
            Kanit("Subayın not kâğıdı",
                  "\"Her gün öncekine göre SABİT sayıda kişi eklenecek. "
                  "Artış oranı değil, artış miktarı sabit.\"", bedel=2, kritik=True),
            Kanit("Yatakhane kapasitesi", "Toplam 60 yatak mevcut.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Günlük artış miktarını (d) hangi hesap verir?",
                dogru="({} − {}) ÷ ({} − {})".format(deger_b, deger_a, gun_b, gun_a),
                yanlislar={
                    "({} − {}) ÷ {}".format(deger_b, deger_a, gun_b):
                        "Farkı doğru buldun ama yanlış sayıya böldün. Bu fark "
                        "{}. güne kadar değil, İKİ ÖLÇÜM ARASINDA geçen "
                        "günlerde birikti.".format(gun_b),
                    "{} ÷ {}".format(deger_b, deger_a):
                        "İki ölçümü birbirine böldün. Bölme sana kaç KAT "
                        "arttığını söyler; oysa dizide her gün sabit bir "
                        "miktar EKLENİYOR, katlanmıyor.",
                    "({} + {}) ÷ ({} + {})".format(deger_b, deger_a, gun_b, gun_a):
                        "Toplamları böldün; bu bir ortalamadır. Artış miktarı "
                        "için ortalama değil, iki ölçüm arasındaki değişim "
                        "gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Artış sabit olduğu için iki kayıt arasındaki toplam artışı, "
                    "aradan geçen gün sayısına bölmek günlük artışı verir. Gün "
                    "sayısını değil gün FARKINI kullanmak önemli: {}. günden {}. güne "
                    "{} gün geçti."
                ).format(gun_a, gun_b, gun_b - gun_a),
                ipuclari=[
                    "İki kayıt arasında kaç gün var? {}. gün ile {}. gün arası.".format(
                        gun_a, gun_b),
                    "Toplam artışı, geçen gün sayısına böl.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Günlük artış (d) kaç kişi?",
                cevap=fark,
                birim="kişi",
                aciklama="({} − {}) ÷ {} = {}.".format(
                    deger_b, deger_a, gun_b - gun_a, fark),
                ipuclari=["Kayıtlar arasındaki farkı, gün farkına böl."],
            ),
            sayi_adimi(
                soru="Çizelgenin 1. gününde kaç nöbetçi vardı?",
                cevap=ilk,
                birim="kişi",
                aciklama="{}. günden geriye {} gün gidilir: {} − {} × {} = {}.".format(
                    gun_a, gun_a - 1, deger_a, gun_a - 1, fark, ilk),
                ipuclari=["Bilinen bir günden geriye doğru, her gün için d kadar azalt."],
            ),
            sayi_adimi(
                soru="{}. gün kaç nöbetçi görev yapacak?".format(hedef_gun),
                cevap=hedef,
                birim="kişi",
                aciklama="a(n) = {} + (n − 1) × {} → a({}) = {}.".format(
                    ilk, fark, hedef_gun, hedef),
                ipuclari=["Genel terimi kurup n yerine hedef günü yaz."],
                puan=15,
            ),
        ],
        kapanis=(
            "Yatakhane {}. gün için {} kişiye göre hazırlandı. Çizelgenin kuralı "
            "artık duvarda asılı; kimse tayin olsa da kaybolmayacak."
        ).format(hedef_gun, hedef),
        odul={"itibar": 6, "enerji": 4},
    )


@bulmaca(ders="matematik", konu="olasilik", kademeler=(9, 13))
def jenerator_riski(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bağımsız arıza olasılıkları; en az birinin çalışması sorulur."""
    p_a = rastgele.choice([0.1, 0.2, 0.25, 0.3])
    p_b = rastgele.choice([0.1, 0.2, 0.4, 0.5])
    ikisi_de_bozuk = p_a * p_b
    en_az_biri = 1 - ikisi_de_bozuk

    return Bulmaca(
        kod="mat-jenerator-riski",
        ders="matematik",
        baslik="Jeneratör Riski",
        kademe=kademe,
        konu="olasilik",
        kazanim="Bağımsız olaylar; tümleyen olasılık ile 'en az biri' hesabı.",
        dikkat=5,
        brifing=(
            "Üssün iki jeneratörü var ve ikisi de eski. Kış gecesi ısıtma "
            "sisteminin çalışması için EN AZ BİRİNİN çalışması yeterli.\n\n"
            "Teknisyen her ikisinin arıza kayıtlarını tutmuş ama \"gece ısınır "
            "mıyız\" sorusunu yanıtlayacak tek bir sayı yazmamış. Komutan tam "
            "olarak o sayıyı istiyor."
        ),
        kanitlar=[
            Kanit("A jeneratörü kaydı",
                  "Soğuk gecelerde çalışmama olasılığı: {}".format(sy(p_a)),
                  bedel=1, kritik=True),
            Kanit("B jeneratörü kaydı",
                  "Soğuk gecelerde çalışmama olasılığı: {}".format(sy(p_b)),
                  bedel=1, kritik=True),
            Kanit("Teknisyen notu",
                  "\"İki jeneratör ayrı yakıt hattında, ayrı devrede. Bu sorunun modelinde "
                  "iki arıza olayı bağımsız kabul ediliyor; ortak nedenli arızalar hesaba katılmıyor.\"", bedel=2, kritik=True),
            Kanit("Isıtma sistemi el kitabı",
                  "Sistem tek jeneratörle tam kapasite çalışır.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="\"En az biri çalışır\" olasılığını hangi yol doğru verir?",
                dogru="1 − (A bozuk) × (B bozuk)",
                yanlislar={
                    "(A çalışır) + (B çalışır)":
                        "Olasılıkları topladın. Toplama, iki durum aynı anda "
                        "olamıyorsa geçerlidir; burada ikisi birden "
                        "çalışabiliyor ve o durumu iki kez saymış olursun. "
                        "Sonuç 1'i bile aşabilir.",
                    "(A çalışır) × (B çalışır)":
                        "Bu çarpım İKİSİ DE çalışır olasılığıdır. Soru en az "
                        "biri diyor; yalnızca birinin çalıştığı durumlar bu "
                        "hesabın dışında kalır.",
                    "1 − (A bozuk) − (B bozuk)":
                        "Tümleyeni yanlış kurdun. En az biri çalışır ifadesinin "
                        "tersi hiçbiri çalışmaz, yani İKİSİ BİRDEN bozuk. İki "
                        "olasılığı ayrı ayrı çıkarmak, ikisinin birden bozuk "
                        "olduğu durumu iki kez düşer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"En az biri\" ifadesinin tersi \"hiçbiri\"dir; yani ikisinin de "
                    "bozulması. Bağımsız oldukları için bu ortak olasılık çarpımdır. "
                    "İki olasılığı toplamak yanlıştır: 'A çalışır' ve 'B çalışır' "
                    "olayları ayrık değildir, ikisi aynı anda olabilir."
                ),
                ipuclari=[
                    "\"En az biri\" ifadesinin tam tersi nedir?",
                    "Bağımsız iki olayın ikisinin birden olması, olasılıkların çarpımıdır.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="İkisinin de bozuk olma olasılığı kaçtır?",
                cevap=ikisi_de_bozuk,
                aciklama="{} × {} = {}.".format(sy(p_a), sy(p_b), sy(ikisi_de_bozuk)),
                ipuclari=["Bağımsız olayların ortak olasılığı çarpımdır."],
                tolerans=0.001,
            ),
            sayi_adimi(
                soru="Gece ısınma olasılığı kaçtır? (0 ile 1 arasında yaz)",
                cevap=en_az_biri,
                aciklama="1 − {} = {}. Yani yaklaşık %{}.".format(
                    sy(ikisi_de_bozuk), sy(en_az_biri), sy(round(en_az_biri * 100, 1))),
                ipuclari=["Tümleyeni 1'den çıkar."],
                tolerans=0.001,
                puan=15,
            ),
            yorum_adimi(
                soru="Teknisyenin bağımsızlık kabulü neden önemliydi?",
                dogru="Modelde bağımsızlık açıkça kabul edildiği için arıza olasılıklarını doğrudan çarpabiliyoruz.",
                yanlislar={
                    "Önemli değildi; olasılıklar her hâlükârda çarpılır.":
                        "Çarpmayı koşulsuz bir kural sandın. Olasılıklar ancak "
                        "olaylar BİRBİRİNDEN BAĞIMSIZSA çarpılır; aynı devrede "
                        "olsalardı biri diğerini de düşürürdü.",
                    "Yalnızca bakım maliyeti açısından önemliydi.":
                        "Notu teknik bir ayrıntı sandın. Ayrı devrede olmak "
                        "hesabın kendisini değiştiren şart; maliyetle ilgisi "
                        "yok.",
                    "Olasılıkların toplanmasını sağladığı için önemliydi.":
                        "Bağımsızlık toplama izni vermez, ÇARPMA izni verir. "
                        "Toplama ayrı bir durumda, birbirini dışlayan olaylarda "
                        "kullanılır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı yakıt hattına bağlı olsalardı, biri yakıtsızlıktan durunca "
                    "diğeri de dururdu; yani olaylar bağımlı olurdu ve çarpım kuralı "
                    "gerçek riski olduğundan düşük gösterebilirdi. Ayrı devreler tek başına bağımsızlığı garanti etmez; ortak nedenler iki arızayı birlikte etkileyebilir. Bu sorudaki sonuç, açık bağımsızlık kabulüne dayanır."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Komutan sayıyı görünce üçüncü bir jeneratör talebi yazdırdı. "
            "\"Yeterli değil\" dedi, \"kabul edilebilir olması lazım.\""
        ),
        odul={"enerji": 8, "itibar": 4},
    )


@bulmaca(ders="matematik", konu="ustel_logaritma", kademeler=(11, 13))
def sinyal_yarilanmasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki ölçümden yarılanma süresi bulunacak, sonra logaritmayla eşik zamanı."""
    yarilanma = rastgele.choice([2, 3, 4, 5])
    baslangic = rastgele.choice([800, 1000, 1200, 1600])
    olcum_zamani = yarilanma * 2
    olcum_degeri = baslangic / 4.0
    esik = rastgele.choice([50, 60, 75, 100])
    while esik >= baslangic / 4:
        esik = 50
    hedef_zaman = yarilanma * math.log(baslangic / esik, 2)

    return Bulmaca(
        kod="mat-sinyal-yarilanma",
        ders="matematik",
        baslik="Zayıflayan Sinyal",
        kademe=kademe,
        konu="ustel_logaritma",
        kazanim="Üstel azalma modeli; logaritma ile bilinmeyen zamanı çözme.",
        dikkat=6,
        brifing=(
            "İleri karakola bırakılan verici zayıflıyor. Kurulumda gücü {} "
            "birimdi; {} saat sonra yapılan ölçümde {} birim okundu.\n\n"
            "Teknisyen \"pil doğrusal bitmiyor, katlanarak düşüyor\" diyor ama "
            "hangi hızla düştüğünü kimse hesaplamamış.\n\n"
            "Sinyal {} birimin altına inerse karakolla bağlantı kopar. Yedek "
            "pili ne zaman göndereceğimizi bilmemiz gerekiyor."
        ).format(sy(baslangic), olcum_zamani, sy(olcum_degeri), esik),
        kanitlar=[
            Kanit("Kurulum kaydı", "t = 0 saat, güç = {} birim".format(sy(baslangic)),
                  bedel=1, kritik=True),
            Kanit("Ara ölçüm", "t = {} saat, güç = {} birim".format(
                olcum_zamani, sy(olcum_degeri)), bedel=1, kritik=True),
            Kanit("Teknisyen raporu",
                  "\"Bu pil tipi ÜSTEL azalır: eşit sürelerde güç eşit ORANDA "
                  "düşer, eşit miktarda değil.\"", bedel=2, kritik=True),
            Kanit("Bağlantı eşiği",
                  "Alıcı {} birimin altındaki sinyali çözemez.".format(esik), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Ölçümler ışığında hangi model doğru?",
                dogru="G(t) = {} × (1/2)^(t / T), T yarılanma süresi".format(sy(baslangic)),
                yanlislar={
                    "G(t) = {} − k × t (sabit miktarda azalma)".format(sy(baslangic)):
                        "Doğrusal bir model kurdun: her adımda aynı MİKTAR "
                        "gidiyor. Ölçümler ise her adımda aynı ORANda "
                        "azaldığını gösteriyor; bu model bir süre sonra "
                        "sinyali eksiye düşürürdü.",
                    "G(t) = {} / t".format(sy(baslangic)):
                        "Ters orantı kurdun. Bu model başlangıç anında "
                        "tanımsızdır ve azalma hızı ölçümlerle tutmuyor.",
                    "G(t) = {} × (1 − t/{})".format(sy(baslangic), olcum_zamani):
                        "Bu model sinyali belirli bir anda tam olarak "
                        "sıfırlar. Yarılanan bir büyüklük ise hiçbir zaman tam "
                        "sıfıra inmez, hep yarıya düşer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Güç {} saatte dörtte bire inmiş: yani iki kez yarıya inmiş. "
                    "Eşit sürelerde eşit ORANDA düşüş üstel modelin tanımıdır. "
                    "Doğrusal modelde her saat aynı MİKTAR düşerdi. İki ölçüm tek başına doğrusal modeli elemez; "
                    "üstel modeli seçmemizi sağlayan bilgi teknisyenin eşit oranlı azalma notudur."
                ).format(olcum_zamani),
                ipuclari=[
                    "{} birim, {} birimin kaçta kaçı?".format(sy(olcum_degeri), sy(baslangic)),
                    "Dörtte bire inmek, kaç kez yarıya inmek demektir?",
                ],
                puan=20,
            ),
            sayi_adimi(
                soru="Yarılanma süresi T kaç saattir?",
                cevap=yarilanma,
                birim="saat",
                aciklama=(
                    "{} saatte dörtte bire indi, yani iki yarılanma geçti: "
                    "T = {} ÷ 2 = {} saat."
                ).format(olcum_zamani, olcum_zamani, yarilanma),
                ipuclari=["Dörtte bir = yarının yarısı."],
                puan=15,
            ),
            sayi_adimi(
                soru="Sinyal {} birime kaç saatte iner? (bir ondalık basamak yeter)".format(esik),
                cevap=hedef_zaman,
                birim="saat",
                aciklama=(
                    "{} × (1/2)^(t/{}) = {} → (1/2)^(t/{}) = {} → "
                    "t = {} × log₂({}/{}) ≈ {} saat."
                ).format(sy(baslangic), yarilanma, esik, yarilanma,
                         sy(round(esik / baslangic, 4)), yarilanma, sy(baslangic), esik,
                         sy(round(hedef_zaman, 2))),
                ipuclari=[
                    "Önce iki tarafı başlangıç gücüne böl.",
                    "Üsteki bilinmeyeni indirmek için logaritma kullan (taban 2 kolay olur).",
                ],
                tolerans=0.25,
                puan=18,
            ),
        ],
        kapanis=(
            "Hesaplanan eşik süresi ekibe bildirildi. Pil sevkiyatını planlamak için "
            "yolculuk süresinin de ölçülmesi istendi."
        ),
        odul={"enerji": 10, "itibar": 6},
    )


@bulmaca(ders="matematik", konu="optimizasyon", kademeler=(11, 13))
def tel_cit_optimizasyonu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Bir kenarı duvara yaslı dikdörtgen; sabit tel ile en büyük alan."""
    tel = rastgele.choice([80, 100, 120, 160, 200])
    en = tel / 4.0          # duvara dik kenarlar
    boy = tel / 2.0         # duvara paralel kenar
    alan = en * boy

    return Bulmaca(
        kod="mat-cit-optimizasyon",
        ders="matematik",
        baslik="Ağıl Sınırı",
        kademe=kademe,
        konu="optimizasyon",
        kazanim="Kısıt altında en büyük değer; ikinci dereceden ifadenin tepe noktası.",
        dikkat=6,
        brifing=(
            "Üssün taş duvarı boyunca bir hayvan ağılı kurulacak. Depoda tam "
            "{} metre tel var; daha fazlası yok.\n\n"
            "Ağılın bir kenarı duvara yaslanacak, yani o kenara tel "
            "çekilmeyecek. Kalan üç kenar telle kapatılacak.\n\n"
            "Komutan \"en geniş alanı ver\" diyor. Ekip başı ise kenarları "
            "eşit yapmayı öneriyor. İkisinden hangisi haklı, hesapla belli olacak."
        ).format(tel),
        kanitlar=[
            Kanit("Depo kaydı", "Kullanılabilir tel: {} m. Ek tel yok.".format(tel),
                  bedel=1, kritik=True),
            Kanit("Duvar ölçümü",
                  "Taş duvar {} metreden uzun; ağılın duvara yaslanan kenarı "
                  "istenen boyda olabilir.".format(tel), bedel=1, kritik=True),
            Kanit("Ekip başının önerisi",
                  "\"Kare yaparsak en iyisi olur, hep öyle deriz.\"", bedel=1),
            Kanit("Ağıl yönetmeliği",
                  "Ağıl dikdörtgen olmalı, köşeler dik. Duvar kenarına tel "
                  "çekilmez.", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Duvara dik kenara x dersek, telin kısıtını hangi ifade anlatır?",
                dogru="2x + y = {} (y duvara paralel kenar)".format(tel),
                yanlislar={
                    "2x + 2y = {}".format(tel):
                        "Dört kenarı da tellemişsin. Bir kenarda duvar var; "
                        "oraya tel çekilmiyor, o yüzden o kenar kısıtın "
                        "dışında kalır.",
                    "x + y = {}".format(tel):
                        "Yalnızca iki kenarı saydın. Duvara dik kenardan İKİ "
                        "tane var; tel üç kenar boyunca gidiyor.",
                    "x × y = {}".format(tel):
                        "Kenarların çarpımını yazdın; o ALANdır. Telin "
                        "uzunluğu bir çevre, yani kenarların toplamıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Dört kenardan biri duvar olduğu için telle kapanan kenarlar: "
                    "iki tane x (duvara dik) ve bir tane y. Tam çevre formülü "
                    "(2x + 2y) burada geçerli değil; bu, sorunun bütün cevabını "
                    "değiştiren tek ayrıntıdır."
                ),
                ipuclari=[
                    "Kaç kenara tel çekiliyor? Duvara yaslanan kenarı say.",
                    "Karşılıklı kenarlardan yalnızca biri telli.",
                ],
                puan=20,
            ),
            sayi_adimi(
                soru="Alanı en büyük yapan x (duvara dik kenar) kaç metre?",
                cevap=en,
                birim="m",
                aciklama=(
                    "A(x) = x × ({} − 2x) = −2x² + {}x. Bu parabolün tepe noktası "
                    "x = {} ÷ 4 = {} metredir."
                ).format(tel, tel, tel, sy(en)),
                ipuclari=[
                    "y'yi x cinsinden yazıp alanı tek değişkenli hâle getir.",
                    "Elde ettiğin ifade x'in ikinci dereceden bir fonksiyonu; "
                    "tepe noktasını ara (türev ya da −b/2a).",
                ],
                tolerans=0.01,
                puan=18,
            ),
            sayi_adimi(
                soru="Bu durumda en büyük alan kaç metrekare olur?",
                cevap=alan,
                birim="m²",
                aciklama="x = {} iken y = {} olur; alan {} × {} = {} m².".format(
                    sy(en), sy(boy), sy(en), sy(boy), sy(alan)),
                ipuclari=["x'i kısıt denklemine koyup y'yi bul, sonra çarp."],
                tolerans=0.5,
                puan=14,
            ),
            yorum_adimi(
                soru="Ekip başının \"kare yapalım\" önerisi bu ağıl için doğru mu?",
                dogru="Hayır; bir kenar duvar olduğu için en iyi biçim kare değil, "
                      "duvara paralel kenarı iki katı olan dikdörtgendir.",
                yanlislar={
                    "Evet; sabit çevrede en büyük alanı her zaman kare verir.":
                        "Doğru bir kuralı yanlış yere uyguladın. Kare, DÖRT "
                        "kenarın da tellendiği durumda en iyisidir. Burada bir "
                        "kenarı duvar tuttuğu için en iyi biçim değişir.",
                    "Evet; duvarın bir etkisi yoktur.":
                        "Duvar kısıtın tam merkezinde: telin bir kenara hiç "
                        "gitmemesi, o yöne daha çok yer ayırmayı kârlı yapar.",
                    "Hayır; en iyi biçim her zaman duvara dik kenarın uzun olmasıdır.":
                        "Her zaman diyerek yeni bir ezber kural kurdun. En iyi "
                        "ölçü hesapla çıkar; bir yöne uzun demek de kareye "
                        "benzet demek kadar dayanaksız.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"Sabit çevrede en büyük alan karededir\" kuralı, dört kenarın da "
                    "sayıldığı durumda geçerlidir. Kısıt değişince en iyi çözüm de "
                    "değişir: burada y = 2x çıkıyor. Ezberlenen sonuç değil, kurulan "
                    "kısıt yönlendirir."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Ağıl {} × {} metre olarak çekildi. Ekip başı teli ölçüp \"tam "
            "tamına yetti\" diyor."
        ).format(sy(en), sy(boy)),
        odul={"cevher": 8, "erzak": 5},
    )


# ==========================================================================
# ÜNİVERSİTE
# ==========================================================================

@bulmaca(ders="matematik", konu="integral", kademeler=(12, 13))
def birikim_integrali(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Değişken debi; toplam birikim integralle bulunacak."""
    a = rastgele.choice([2, 3, 4, 6])
    b = rastgele.choice([5, 10, 15, 20])
    t1 = 0
    t2 = rastgele.choice([4, 6, 8, 10])
    toplam = a * t2 ** 2 / 2.0 + b * t2
    ortalama_debi = toplam / (t2 - t1)

    return Bulmaca(
        kod="mat-birikim-integral",
        ders="matematik",
        baslik="Değişken Debi",
        kademe=kademe,
        konu="integral",
        kazanim="Belirli integralin birikim anlamı; değişken hızlı süreçte toplam miktar.",
        dikkat=6,
        brifing=(
            "Eriyen kar, dere yatağından üssün sarnıcına akıyor. Debi sabit "
            "değil: gün ısındıkça artıyor.\n\n"
            "Ölçüm ekibi saat başı debiyi kaydetmiş ve verinin düz bir doğruya "
            "oturduğunu görmüş: t saat sonra debi Q(t) = {}t + {} m³/saat.\n\n"
            "Sarnıcın {} saatlik dolum sonunda ne kadar su alacağını bilmemiz "
            "gerekiyor; taşarsa temel su alır."
        ).format(a, b, t2),
        kanitlar=[
            Kanit("Debi ölçüm çizelgesi",
                  "t = 0 → {} m³/sa\nt = 1 → {} m³/sa\nt = 2 → {} m³/sa\n"
                  "Artış düzenli.".format(b, a + b, 2 * a + b), bedel=2, kritik=True),
            Kanit("Ölçüm ekibi notu",
                  "\"Değerler bir DOĞRU üzerinde. Yani debi zamanla doğrusal "
                  "artıyor; ama debinin kendisi bir HIZ, birikim değil.\"",
                  bedel=2, kritik=True),
            Kanit("Sarnıç planı", "Sarnıç hacmi: 600 m³. Başlangıçta boş. Dolum sırasında çıkış, kaçak ve buharlaşma yok; verilen debi modeli dolum boyunca geçerli. Taşma borusu yok.", bedel=1),
            Kanit("Dolum süresi", "Dolum {} saat sürecek.".format(t2), bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="{} saatte biriken toplam su hangi ifadeyle bulunur?".format(t2),
                dogru="∫₀^{} ({}t + {}) dt".format(t2, a, b),
                yanlislar={
                    "Q({}) = {} × {} + {}".format(t2, a, t2, b):
                        "Bu ifade o ANDAKİ debidir, biriken toplam değil. "
                        "Debi her an ne kadar aktığını söyler; toplamı bulmak "
                        "için süre boyunca biriktirmen gerekir.",
                    "({} × {} + {}) × {}".format(a, t2, b, t2):
                        "Son andaki debiyi süreyle çarptın. Bu, debinin baştan "
                        "sona sabit kaldığını varsaymak olur; oysa debi "
                        "zamanla artıyor ve baştaki değerler daha küçüktü.",
                    "d/dt ({}t + {}) alınır".format(a, b):
                        "Türev aldın; o, debinin ne hızla ARTTIĞINI verir. "
                        "Birikim ters yönde bir işlemdir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Q(t) bir ANLIK debidir, birikim değil. Anlık hızdan toplam "
                    "miktara geçmek integral almaktır. Q({}) yalnızca son andaki "
                    "akış hızını verir; onu süreyle çarpmak ise debinin sabit "
                    "olduğunu varsaymak olur ki değil."
                ).format(t2),
                ipuclari=[
                    "Q(t)'nin birimi m³/saat. Sana m³ lazım. Birim nasıl dönüşür?",
                    "Debi sabit olsaydı çarpardın; sabit olmayınca ne yapılır?",
                ],
                puan=20,
            ),
            sayi_adimi(
                soru="{} saatte sarnıca kaç m³ su birikir?".format(t2),
                cevap=toplam,
                birim="m³",
                aciklama=(
                    "∫₀^{} ({}t + {}) dt = [{}t²/2 + {}t]₀^{} = {} + {} = {} m³."
                ).format(t2, a, b, a, b, t2, sy(a * t2 ** 2 / 2.0), sy(b * t2), sy(toplam)),
                ipuclari=["Terim terim integre et, sonra sınırları yerleştir."],
                tolerans=0.5,
                puan=18,
            ),
            sayi_adimi(
                soru="Bu sürede ortalama debi kaç m³/saat olmuştur?",
                cevap=ortalama_debi,
                birim="m³/saat",
                aciklama=(
                    "Ortalama debi = toplam birikim ÷ süre = {} ÷ {} = {} m³/saat. "
                    "Doğrusal artışta bu, başlangıç ve bitiş debisinin ortalamasına eşittir."
                ).format(sy(toplam), t2, sy(ortalama_debi)),
                ipuclari=["Toplam miktarı geçen süreye böl."],
                tolerans=0.1,
                puan=14,
            ),
            yorum_adimi(
                soru="Sarnıç 600 m³ alıyor. Bu dolumda taşma riski var mı?",
                dogru=("Bu dolumda yok; ama debi artmaya devam ettiği için sonraki "
                       "saatlerde birikim hızlanarak büyür."),
                yanlislar={
                    "Var; hesaplanan miktar kapasiteyi aşıyor.":
                        "Karşılaştırmayı ters kurdun. Bulduğun birikim sarnıç "
                        "hacminin altında kalıyor; iki sayıyı yan yana bir "
                        "daha koy.",
                    "Yok; debi arttığı için birikim yavaşlar.":
                        "Doğru sonuca yanlış gerekçeyle vardın. Debi artarken "
                        "birikim HIZLANIR; taşma olmamasının sebebi sürenin "
                        "kısalığı.",
                    "Belirlenemez; integral bu soruya cevap vermez.":
                        "Aracı küçümsedin. Biriken toplamı bulmak zaten "
                        "integralin işi; sonucu kapasiteyle karşılaştırmak "
                        "yeterli.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Toplam birikim {} m³, kapasite 600 m³. Bu dolum güvenli. Ancak "
                    "Q(t) artan bir fonksiyon olduğu için birikim eğrisi giderek "
                    "dikleşir; aynı süre iki katına çıkarsa su iki katından fazla olur."
                ).format(sy(toplam)),
                puan=12,
            ),
        ],
        kapanis=(
            "Sarnıç ölçüldü: hesapla tutuyor. Dolum süresi bir sonraki bahar "
            "için çizelgeye işlendi."
        ),
        odul={"erzak": 6, "enerji": 8, "itibar": 6},
    )


# ==========================================================================
# İLKOKUL - ek görevler
#
# İlkokul kademesinde tek bir görev tipi bırakmak, aynı çocuğa aynı soruyu
# tekrar tekrar vermek demektir. Bu üç görev farklı beceriler üzerine kurulu:
# uzunluk karşılaştırması, zaman hesabı, para. Üçünde de bilinmeyen brifingte
# söylenmez, kanıtlardan çıkar.
# ==========================================================================

@bulmaca(ders="matematik", konu="uzunluk_karsilastirma", kademeler=(1, 4))
def ip_boyu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki ip; biri diğerinden belli miktar uzun, yalnızca toplam biliniyor."""
    kisa = rastgele.randrange(3, 8 + 2 * kademe)
    fark = rastgele.choice([2, 4, 6])
    uzun = kisa + fark
    toplam = kisa + uzun
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-ip-boyu",
        ders="matematik",
        baslik="İki İp",
        kademe=kademe,
        konu="uzunluk_karsilastirma",
        kazanim="Uzunlukları karşılaştırma; toplam ve farktan iki parçayı bulma.",
        dikkat=4,
        brifing=(
            "Çadır bağlamak için iki ip lazım. Depoda tam iki ip var ama "
            "ikisinin de boyu yazılmamış.\n\n"
            "{} ipleri uç uca eklemiş ve toplamın {} karış olduğunu ölçmüş. "
            "Bir de şunu söylüyor: iplerden biri diğerinden {} karış uzunmuş.\n\n"
            "Hangi ipin kaç karış olduğunu bilmemiz gerekiyor; kısa ip ön "
            "direğe, uzun ip arka direğe gidecek."
        ).format(kisi, toplam, fark),
        kanitlar=[
            Kanit("Ölçüm kaydı", "İki ip uç uca: {} karış.".format(toplam),
                  bedel=1, kritik=True),
            Kanit("{} notu".format(kisi),
                  "\"Uzun ip, kısa ipten {} karış fazla. Yan yana koyunca "
                  "farkı gördüm.\"".format(fark), bedel=1, kritik=True),
            Kanit("Depo rafı", "İki ip dışında başka ip yok. İkisi de sağlam, "
                              "kesik değil.", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kısa ipin boyunu bulmak için ne yapmalı?",
                dogru=("Toplamdan fazlalığı ({}) çıkarırsak iki ip eşitlenir; "
                       "kalanı ikiye bölersek kısa ip çıkar.".format(fark)),
                yanlislar={
                    "Toplamı doğrudan ikiye bölersek kısa ip çıkar.":
                        "İki ipi eşit saydın. Biri ötekinden {} metre uzun; "
                        "ikiye bölmek ikisinin ortasını verir, kısa ipi "
                        "değil.".format(fark),
                    "Toplamı {} sayısına bölersek kısa ip çıkar.".format(fark):
                        "Farka böldün. Fark iki ip arasındaki açıklıktır, kaç "
                        "parçaya bölündüğü değil; ip sayısı ikidir.",
                    "Toplama {} ekleyip ikiye bölersek kısa ip çıkar.".format(fark):
                        "Bu işlem UZUN ipi verir. Kısa ipe gitmek için farkı "
                        "eklemek değil çıkarmak gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İpler eşit olsaydı toplamı ikiye bölmek yeterdi. Eşit değiller: "
                    "biri {} karış fazla. Önce o fazlalığı toplamdan çıkarıp ipleri "
                    "eşitliyoruz, sonra ikiye bölüyoruz. Toplama {} ekleyip ikiye "
                    "bölmek ise uzun ipi verir, kısa ipi değil."
                ).format(fark, fark),
                ipuclari=[
                    "İki ip eşit olsaydı iş kolaydı. Eşit yapmak için ne yapmalısın?",
                    "Fazlalığı toplamdan çıkarınca elinde iki EŞİT ip kalır.",
                ],
            ),
            sayi_adimi(
                soru="Kısa ip kaç karış?",
                cevap=kisa,
                birim="karış",
                aciklama="({} − {}) ÷ 2 = {} karış.".format(toplam, fark, kisa),
                ipuclari=["Önce toplamdan farkı çıkar, sonra ikiye böl."],
            ),
            sayi_adimi(
                soru="Uzun ip kaç karış?",
                cevap=uzun,
                birim="karış",
                aciklama="{} + {} = {} karış. İki ip toplandığında {} eder; tutuyor.".format(
                    kisa, fark, uzun, toplam),
                ipuclari=["Kısa ipe farkı ekle."],
                puan=10,
            ),
        ],
        kapanis="Kısa ip ön direğe, uzun ip arka direğe bağlandı. Çadır dik durdu.",
        odul={"cevher": 3, "itibar": 2},
    )


@bulmaca(ders="matematik", konu="zaman_hesabi", kademeler=(2, 5))
def nobet_saati(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Nöbet süresi + ara; başlangıç saati bilinmiyor. Aranın sayılıp sayılmadığı kilit."""
    ayakta = rastgele.choice([5, 6, 7])
    ara = rastgele.choice([1, 2])
    bitis = rastgele.choice([15, 16, 17, 18])
    baslangic = bitis - (ayakta + ara)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-nobet-saati",
        ders="matematik",
        baslik="Nöbet Saati",
        kademe=kademe,
        konu="zaman_hesabi",
        kazanim="Zaman ölçüsü; süre ve bitiş saatinden başlangıç saatini bulma.",
        dikkat=5,
        brifing=(
            "Kule nöbeti bugün saat {}.00 da bitti. {} nöbet defterine bitiş "
            "saatini yazmış ama başlangıcı yazmayı unutmuş.\n\n"
            "Kendisine sorduğumuzda \"{} saat ayakta durdum\" diyor. Bir de "
            "yemek için aşağı indiği bir ara var.\n\n"
            "Yarınki çizelgeyi kurabilmemiz için nöbetin kaçta başladığını "
            "bulmamız lazım."
        ).format(bitis, kisi, ayakta),
        kanitlar=[
            Kanit("Nöbet defteri", "Bitiş: {}.00\nBaşlangıç: (boş)".format(bitis),
                  bedel=1, kritik=True),
            Kanit("{} ifadesi".format(kisi),
                  "\"Kulede tam {} saat ayakta durdum. Yorulmadım desem "
                  "yalan olur.\"".format(ayakta), bedel=1, kritik=True),
            Kanit("Yemekhane kaydı",
                  "Kuleden inip yemek yediği süre: {} saat.".format(ara),
                  bedel=1, kritik=True),
            Kanit("Nöbet yönetmeliği",
                  "\"Yemek arası nöbet süresinden SAYILMAZ. Defterdeki 'ayakta "
                  "geçen süre' yalnızca kulede geçen zamandır.\"", bedel=2, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Nöbetin başlangıç saatini bulmak için hangi hesap doğru?",
                dogru=("Bitişten, ayakta geçen {} saat ile aradaki {} saatin "
                       "TOPLAMI kadar geriye gidilir.".format(ayakta, ara)),
                yanlislar={
                    "Bitişten yalnızca {} saat geriye gidilir.".format(ayakta):
                        "Yalnızca ayakta geçen süreyi saydın. Nöbetçi arada da "
                        "nöbet yerindeydi; başlangıca gitmek için o süre de "
                        "geriye eklenir.",
                    "Bitişten {} saat geriye gidilir; ara zaten içindedir, "
                    "ayrıca düşülür.".format(ayakta - ara):
                        "Arayı iki kez düştün: hem toplamdan çıkardın hem "
                        "zaten içinde saydın. Bir süre bir kez sayılır.",
                    "Bitişten yalnızca {} saat geriye gidilir.".format(ara):
                        "Yalnızca arayı saydın. Ara nöbetin küçük bir parçası; "
                        "ayakta geçen süre de nöbetin içinde.",
                },
                rastgele=rastgele,
                aciklama=(
                    "\"{} saat ayakta durdum\" sözü YALNIZCA kulede geçen zamanı "
                    "anlatıyor; yemek arası buna dahil değil. Ama nöbetçi o sırada "
                    "da üsteydi ve saat işliyordu. Başlangıçtan bitişe kadar geçen "
                    "gerçek süre {} + {} = {} saattir."
                ).format(ayakta, ayakta, ara, ayakta + ara),
                ipuclari=[
                    "Yönetmelik ne diyor: yemek arası ayakta geçen süreye dahil mi?",
                    "Nöbetçi yemek yerken saat durdu mu? Geçen toplam zamanı düşün.",
                ],
            ),
            sayi_adimi(
                soru="Başlangıçtan bitişe kaç saat geçmiş?",
                cevap=ayakta + ara,
                birim="saat",
                aciklama="{} saat kulede + {} saat yemekte = {} saat.".format(
                    ayakta, ara, ayakta + ara),
                ipuclari=["İki süreyi topla."],
                puan=10,
            ),
            sayi_adimi(
                soru="Nöbet saat kaçta başladı? (yalnızca saati yaz, örnek: 9)",
                cevap=baslangic,
                birim="",
                aciklama="{} − {} = {}. Nöbet saat {}.00 da başlamış.".format(
                    bitis, ayakta + ara, baslangic, baslangic),
                ipuclari=["Bitiş saatinden, geçen toplam süreyi çıkar."],
                puan=12,
            ),
        ],
        kapanis=(
            "Defterdeki boşluk dolduruldu: {}.00 - {}.00. Yönetmelik de nöbet "
            "kulesine asıldı; bir daha karışmayacak."
        ).format(baslangic, bitis),
        odul={"itibar": 4, "erzak": 2},
    )


@bulmaca(ders="matematik", konu="para", kademeler=(2, 5))
def kantin_fisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Fişte tutar yok; verilen para ve para üstü var. Ayrıca eşit fiyatlı ürünler."""
    adet = rastgele.choice([3, 4, 5])
    birim_fiyat = rastgele.randrange(6, 12 + 2 * kademe)
    tutar = adet * birim_fiyat
    verilen = ((tutar // 10) + rastgele.choice([2, 3, 4])) * 10
    ustu = verilen - tutar
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="mat-kantin-fisi",
        ders="matematik",
        baslik="Kantin Fişi",
        kademe=kademe,
        konu="para",
        kazanim="Para ile dört işlem; toplam tutardan birim fiyata ulaşma.",
        dikkat=5,
        brifing=(
            "{} kantinden defter almış. Fişi getirmiş ama fişin tutar yazan "
            "yeri silinmiş; okunmuyor.\n\n"
            "Okunan tek şey şu: kasaya {} lira verilmiş, {} lira para üstü "
            "alınmış. Defterlerin hepsi aynı marka, aynı fiyat.\n\n"
            "Depo defterine bir defterin fiyatını yazmamız gerekiyor; gelecek "
            "siparişi buna göre vereceğiz."
        ).format(kisi, verilen, ustu),
        kanitlar=[
            Kanit("Kantin fişi",
                  "Verilen: {} TL\nPara üstü: {} TL\nTutar: (silinmiş)".format(verilen, ustu),
                  bedel=1, kritik=True),
            Kanit("{} çantası".format(kisi),
                  "İçinde {} adet aynı defter var. Başka bir şey yok.".format(adet),
                  bedel=1, kritik=True),
            Kanit("Kantin rafı",
                  "Defterlerin hepsi aynı marka ve aynı fiyat etiketli; etiket "
                  "yazısı solmuş.", bedel=1, kritik=True),
            Kanit("Kantin görevlisi",
                  "\"O gün kasada indirim yoktu, ek ücret de almadım.\"", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir defterin fiyatını bulmak için hangi sıra doğru?",
                dogru=("Önce verilen paradan para üstü çıkarılır (ödenen tutar), "
                       "sonra bu tutar defter sayısına bölünür."),
                yanlislar={
                    "Önce verilen paraya para üstü eklenir, sonra defter sayısına bölünür.":
                        "İşareti ters aldın. Para üstü cepten çıkmadı, GERİ "
                        "geldi; harcanan parayı bulmak için verilenden "
                        "çıkarılır.",
                    "Para üstü, defter sayısına bölünür.":
                        "Para üstünü harcanan para sandın. O, tam tersine "
                        "harcanmayan kısım; defterlere ödenen miktar değil.",
                    "Verilen para doğrudan defter sayısına bölünür.":
                        "Para üstünü hiç düşmedin. Kasaya verilen paranın bir "
                        "kısmı geri geldi; defterlere yalnızca kalanı ödendi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kasaya verilen para, ödenen tutar değildir; içinden para üstü "
                    "geri gelmiştir. Gerçekten harcanan miktar 'verilen − para üstü' "
                    "kadardır. Defterler eşit fiyatlı olduğu için bu tutar defter "
                    "sayısına bölünür."
                ),
                ipuclari=[
                    "Verilen para ile harcanan para aynı şey mi?",
                    "Geri alınan parayı düşersen elinde gerçekten ödenen tutar kalır.",
                ],
            ),
            sayi_adimi(
                soru="Kantinde toplam kaç lira ödenmiş?",
                cevap=tutar,
                birim="TL",
                aciklama="{} − {} = {} TL.".format(verilen, ustu, tutar),
                ipuclari=["Verilen paradan para üstünü çıkar."],
                puan=10,
            ),
            sayi_adimi(
                soru="Bir defter kaç lira?",
                cevap=birim_fiyat,
                birim="TL",
                aciklama="{} ÷ {} = {} TL. Defterler eşit fiyatlı olduğu için bölme geçerli.".format(
                    tutar, adet, birim_fiyat),
                ipuclari=["Ödenen tutarı defter sayısına böl."],
                puan=12,
            ),
            yorum_adimi(
                soru="Defterlerden biri diğerlerinden pahalı olsaydı ne olurdu?",
                dogru="Tek bir defterin fiyatı bulunamazdı; elimizde yalnızca toplam tutar kalırdı.",
                yanlislar={
                    "Yine bulunurdu; ortalama alınır ve bu kesin sonuç verir.":
                        "Ortalamayı kesin sonuç saydın. Ortalama defter başına "
                        "düşeni verir ama TEK BİR defterin fiyatını vermez; "
                        "aynı ortalamayı veren çok farklı fiyat dizisi vardır.",
                    "Hiçbir şey değişmezdi.":
                        "Hesabın dayandığı şart tam olarak defterlerin eşit "
                        "fiyatlı olmasıydı. O şart kalkarsa bölme "
                        "geçerliliğini yitirir.",
                    "En pahalı defterin fiyatı toplamın yarısı olurdu.":
                        "Dayanağı olmayan bir kural uydurdun. Kanıtlarda böyle "
                        "bir oranı söyleyen hiçbir şey yok.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bölme işlemi ancak paylar EŞİTSE tek bir cevap verir. Eşit "
                    "değillerse aynı toplamı veren pek çok farklı fiyat birleşimi "
                    "olur; ortalama bir tahmin verir ama kesin fiyatı vermez."
                ),
                puan=8,
            ),
        ],
        kapanis="Depo defterine defter fiyatı {} TL olarak işlendi.".format(birim_fiyat),
        odul={"itibar": 3, "erzak": 3},
    )
