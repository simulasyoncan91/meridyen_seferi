# -*- coding: utf-8 -*-
"""
Oyunun dış kabuğu: menüler, görev panosu, karne, kayıt.

Buradaki hiçbir şey ders içeriğini bilmez. Ders eklemek için bu dosyaya
dokunmak gerekmez; oyun.icerik altına yeni bir modül koymak yeterlidir.
"""
from __future__ import annotations

import json
import os
import time
from typing import List, Optional, Tuple

from . import durum as durum_modulu
from . import degerlendirme
from . import ilerleme
from . import ittifak
from . import ders_programi
from .anlati import TARZLAR, konu_etiketi, tarz
from . import terminal as ekran
from .kayit_defteri import (
    icerigi_yukle, kademede_acik_mi, kapsama_raporu, konular, sefer_kayitlari,
    sefer_uret, tum_kayitlar, uret, uygun_kayitlar,
)
from .modeller import (
    ANLATIM, ASAMA_ADLARI, BIRLIKTE, Bulmaca, DERS_ADLARI, DERS_KISA,
    DERS_RENGI, DERSLER,
    KADEME_ADLARI, OGRENME_YOLLARI, SERBEST, ZORLUK_ACIKLAMALARI,
    ZORLUK_ADLARI, ZORLUK_KADEME, alan_yolu, kademe_zorlugu, secmeli_yol_mu,
    yol_alanlari,
)
from . import cokme
from .durum import Durum, KAYNAK_ADLARI, KAYNAKLAR
from .oturum import Oturum, sonucu_ozetle
from .terminal import OyunuBirak, S

OYUN_ADI = "MERİDYEN SEFERİ"
ALT_BASLIK = "sefer kayıtları"

# Yıldıza göre ödül çarpanı. ITIBAR DISINDAKI kaynaklara uygulanir (erzak,
# cevher, enerji); itibar icin asagidaki KATILIM_ITIBARI + YILDIZ_EK_ITIBAR.
YILDIZ_CARPANI = {0: 0.2, 1: 0.6, 2: 1.0, 3: 1.4}

# B36.13 (kullanici karari, 29 Eylul 2026): KAPI ACAN ITIBAR YILDIZDAN
# BAGIMSIZ. Itibar zaman seferinin baglayici kaynagi (SEFER_BEDELI 12).
# Eskiden itibar da YILDIZ_CARPANI ile olcekleniyordu: 5 itibarlik gorevde
# 0 yildiz 1, 3 yildiz 7 itibar -- kapi zorlanan ogrenciye 12 gorev, iyi
# ogrenciye 2 gorev uzaktaydi. Zorlanan ogrenci oyunun en ozgun icerigine
# en gec ulasiyordu; §0'in tersi (8 Eylul enerji tabani itibari kapsamiyordu).
#
# Kural: tamamlanan HER gorev sabit katilim itibari verir; yildiz yalniz
# EK itibar getirir (gorevin kendi itibar degerinin bu orani kadar).
# Olculdu (2 Ekim 2026, 290 uretici; testler/test_kaynak.py
# KatilimItibariTesti): 0 yildizla HEPSINDE 3 gorevde, 3 yildizla en cok 2
# gorevde kapi acilir. Once: 0 yildizla 243 ureticide 12 gorev, 12'sinde 6,
# 35'inde HIC (odulunde itibar yoktu, 0 itibar veriyordu); 3 yildizla
# 44'unde 3-4, 2'sinde 12 gorev, 12'sinde hic.
KATILIM_ITIBARI = 4
YILDIZ_EK_ITIBAR = {0: 0.0, 1: 0.25, 2: 0.5, 3: 0.75}
# Yildiz ekinin TABANI: icerik itibar yazmadiysa ya da bundan az yazdiysa
# ek bu degerden hesaplanir. Yoksa itibarsiz gorevde yildiz kapiya hic
# yaklastirmazdi ("3 yildiz daha hizli" her gorevde gecerli olsun).
VARSAYILAN_GOREV_ITIBARI = 3
# Şu an oyundaki TEK kaynak gideri. Koloni döngüsü yazıldığında burası
# tek başına kalmayacak: tesis onarımı, masa açma ve sefer başlatma da
# kaynak harcayacak. Bkz. TASARIM_NOTLARI.md §3
GOREV_BEDELI = {"enerji": 1}

# Zaman seferi baslatma bedeli. TASARIM_NOTLARI §3'un adiyla saydigi
# giderlerden biri: "kaynak yalnizca ogrenerek kazanilir ve yalnizca
# ogrenmeye harcanir: yeni masa acmak, ipucu almak, zaman seferi
# baslatmak, tesis onarmak."
#
# NEDEN BU GEREKLI: olculdu (5 Eylul 2026). Gorev basina kazanc erzak 1,2 /
# itibar 4,2 / cevher 1,0 / enerji 1,3; tek gider gorev basina 1 enerji.
# Yani enerji bile NET ARTIYOR, digerlerinin hic gideri yok. 40 gorev
# sonra itibar 0'dan 168'e cikiyor ve hicbir ise yaramiyor. Ekranda duran
# sayilar dekordu.
#
# Bedel olculerek secildi. Erzak/cevher/enerji baslangic degerlerinin
# (40/20/30) altinda, yani onlar ilk gunden karsilaniyor. Baglayici olan
# ITIBAR: 0'dan basliyor ve gorev basina ~4,2 kazaniliyor, yani ilk sefer
# icin ~3 gorev cozmek gerekiyor.
#
# Bu bilerek boyle: ogrenci once temel donguyu ogrensin, sonra oyunun en
# ozgun icerigi (TASARIM_NOTLARI §9-6) acilsin. Ama pist KISA tutuldu --
# 3 gorev bir angarya degil, bir giris. Oyunun en iyi parcasini uzun bir
# ogutme arkasina kilitlemek kaynak dongusunun amaci degil.
SEFER_BEDELI = {"erzak": 6, "cevher": 5, "enerji": 8, "itibar": 12}

# B36.18: yeni seferde ana menü kademeli açılır. Değer = o yerin açılması
# için raporlanmış görev sayısı (`oynanan_gorev`). Listede olmayan yer
# (Usta Çadırı, Komuta Masası, ayarlar, geri bildirim, nöbeti devret,
# okul programı) baştan açık. Yalnız `_yeni_oyun`un açtığı seferde
# (`ayarlar["kademeli_menu"]`); eski kayıtlarda menü eskisi gibi tam.
KADEMELI_ACILIS = {"kisa": 1, "harita": 2, "gunluk": 2,
                   "iz": 3, "tesis": 3, "kronograf": 4}
# Suren zaman seferinin kayittaki izi (ayarlar anahtari): odenen bedel, bolum
# sayisi, biten bolum. Iade verilince silinir. Bkz. `Oyun._sefer_iadesini_ver`.
YARIM_SEFER = "yarim_sefer"


def os_surumu(oynanan_gorev: int) -> str:
    """Meridyen OS sürümü, rapor sayısından türetilir (kayda alan YOK).

    Kademeli açılışın her eşiği bir küçük sürümdür: 0 görev "1.0", eşik
    sayısı kadar görevde "1.4". Sonra her 10 raporda bir küçük sürüm daha.
    Yalnız yukarı çıkar (görev sayısı azalmaz), eski kayıtta da hesaplanır.
    """
    n = max(0, int(oynanan_gorev or 0))
    esikler = sorted(set(KADEMELI_ACILIS.values()))
    kucuk = sum(1 for e in esikler if e <= n)
    if n > esikler[-1]:
        kucuk += (n - esikler[-1]) // 10
    return "1.{}".format(kucuk)


def yildiz_itibar_eki(odul, yildiz: int) -> int:
    """Yildizin katilim itibarina ekledigi itibar (B36.13).

    Gorevin kendi itibar degerinin (en az VARSAYILAN_GOREV_ITIBARI)
    YILDIZ_EK_ITIBAR orani, YARIM YUKARI yuvarlanir. Python'un round'u
    2,5'i 2'ye indirir; oyle olsa 5 itibarlik gorevde 2 yildizin eki 1
    yildizinkine cok yaklasirdi. Sonuc: 5 itibarlik gorevde 0/1/2/3 yildiz
    -> +0/+1/+3/+4; itibarsiz gorevde +0/+1/+2/+2.
    """
    try:
        deger = int((odul or {}).get("itibar", 0))
    except (TypeError, ValueError):
        deger = 0
    deger = max(deger, VARSAYILAN_GOREV_ITIBARI)
    oran = YILDIZ_EK_ITIBAR.get(yildiz, 0.0)
    return int(deger * oran + 0.5)


def sefer_iadesi(bedel, tamamlanan: int, toplam: int) -> dict:
    """Yarida birakilan zaman seferinin iadesi (B36.14).

    Tamamlanmayan bolumlerin orani kadar, her kaynak AYRI AYRI ve ASAGI
    yuvarlanarak: iade hicbir zaman odenenden fazla olamaz. Ilk bolumde
    birakan tamamini, son bolumde birakan en az payi geri alir. Ornek (bedel
    Erzak 6, Cevher 5, Enerji 8, Itibar 12; 4 bolum; 1 bolum tamamlandi):
    Erzak 4, Cevher 3, Enerji 6, Itibar 9.
    """
    if toplam <= 0:
        return {}
    kalan = max(0, min(toplam, toplam - max(0, tamamlanan)))
    iade = {}
    for anahtar, miktar in (bedel or {}).items():
        pay = (max(0, int(miktar)) * kalan) // toplam
        if pay > 0:
            iade[anahtar] = pay
    return iade


class Oyun:
    def __init__(self, durum: Durum):
        self.durum = durum
        self.teklifler: List[Bulmaca] = []
        # Pano her yenilendiğinde artar. Kayıt tohumuna dokunmadan farklı
        # görevler getirebilmek için ayrı tutuluyor.
        self.pano_sayaci = 0
        self._teklif_baglami = None
        self.odak_uyarisi = ""
        ekran.yazim_hizi_ayarla(float(durum.ayarlar.get("yazim_hizi", 0.0)))
        # Rutbe terfisi HER akista gosterilsin diye: son gosterilen rutbe.
        # Eskiden kutu yalnizca _gorevi_oyna icindeydi; Usta Cadiri, zaman
        # seferi ve kisa sefer gorev sayacini artiriyor ama terfiyi hic
        # gostermiyordu.
        self._gosterilen_rutbe = durum.rutbe
        # Katman sirasi oturum basinda BIR KEZ hesaplanir; her ziyarette
        # yeniden hesaplansa menu ogrencinin elinin altinda kayar.
        from . import oyuncu
        self._katman_sirasi = oyuncu.katman_sirasi(durum)
        self._menu_anahtarlari: List[str] = []
        # B35.14: ilk görevden sonraki kurulum en az bu kadar görevden sonra
        # sorulur. Zorla açılan ilk görev BIRAKILIRSA bir artar: görevden
        # yeni çekilmiş öğrenciye beş anket sorusu sorulmasın; bir sonraki
        # görevden (ya da bir sonraki açılıştan) sonra gelsin.
        self._kurulum_esigi = 1

    # ------------------------------------------------------------------ giriş
    def calistir(self) -> None:
        from oyun.icerik import hikaye
        from . import oyuncu

        from . import arsiv
        arsiv.ac(self.durum)
        hikaye.bolumu_kontrol_et(self.durum, ilk_giris=True)
        self._yarim_seferi_kapat()
        self._bildirimleri_goster()
        # B35.14: yeni seferin ilk görevi menüsüz başlar; tanışma ve tercihler
        # ondan SONRA (döngünün başındaki `_ilk_gorev_sonrasi`).
        self._ilk_gorev()
        while True:
            if self._kurulum_bekliyor_mu():
                self._ilk_gorev_sonrasi()
                self._katman_sirasi = oyuncu.katman_sirasi(self.durum)
            # Menu SIRASI kisiye gore degisiyor (oyuncu.katman_sirasi); bu
            # yuzden dagitim sira numarasiyla degil ANAHTARLA yapiliyor.
            #
            # IKI SATIR OLMAK ZORUNDA. Ilk yazim tek satirdi:
            #     anahtar = self._menu_anahtarlari[self._ana_menu()]
            # Python a[b]'de ONCE a'yi okur: liste, menu cizilip yeniden
            # kurulmadan onceki bos listeydi ve ilk secimde HER ogrencinin
            # oyunu IndexError ile cokuyordu. 686 test geciyordu; hicbiri
            # calistir'i ana menuden gecirmiyordu. Elle oynanis yakaladi.
            # Bkz. testler/test_oyuncu.py AnaDongu.
            secim = self._ana_menu()
            anahtar = self._menu_anahtarlari[secim]
            oyuncu.ziyaret_say(self.durum, anahtar)
            ekran.baglam("uygulama", anahtar=anahtar)
            if anahtar == "usta":
                self._konu_calis()
            elif anahtar == "komuta":
                self._gorev_panosu()
            elif anahtar == "kronograf":
                self._zaman_seferi()
            elif anahtar == "iz":
                self._konu_taramasi()
            elif anahtar == "harita":
                self._karne()
            elif anahtar == "gunluk":
                self._gunluk()
            elif anahtar == "ayar":
                self._ayarlar()
                if getattr(self.durum, "_silindi", False):
                    return          # "Kaydımı sil": sefer bitti, kayıt yok
            elif anahtar == "geri":
                self._geri_bildirim()
            elif anahtar == "program":
                from araclar.program import program_ekrani
                program_ekrani(durum=self.durum)
                self.teklifler = []
            elif anahtar == "kisa":
                from .kisa_oturum import kisa_sefer
                if kisa_sefer(self.durum):
                    self._ilerleme_sonrasi()
                    self.durum.kaydet()
                self.teklifler = []
            elif anahtar == "tesis":
                self._tesisler()
            elif anahtar == "siber":
                self._siber_nobet()
            elif anahtar == "devret":
                yol = self.durum.kaydet()
                ekran.yaz()
                ekran.basari("Kaydedildi: " + yol)
                # Nöbet biterken karne: öğrenci ne yaptığını tek sayfada görsün,
                # isterse öğretmene/veliye götürebileceği bir belge alsın.
                if ekran.onayla("Bu seferin karnesine bakalım mı?", True):
                    from araclar.karne import karne_ekrani
                    karne_ekrani(self.durum)
                else:
                    ekran.bekle()
                return

    # ------------------------------------------------ ilk görev (B35.14)
    def _ilk_gorev(self) -> None:
        """Yeni seferin ilk görevi: ana menü, pano ve görev dosyası OLMADAN.

        Eskiden ilk göreve ana menü -> Komuta Masası -> dosya seçimi ->
        "kabul ediyor musun?" ile varılıyordu; kayıt ve anketle birlikte
        ilk görevden önce 18 durak. Yalnız `_yeni_oyun`un açtığı seferde ve
        BİR KEZ: öğrenci görevi bırakırsa ana menüye düşer, bir daha zorla
        göreve sokulmaz. Eski kayıtlarda bu işaret yok, hiçbir şey değişmez.
        """
        ayarlar = self.durum.ayarlar
        if not ayarlar.get("ilk_gorev_bekliyor"):
            return
        ayarlar.pop("ilk_gorev_bekliyor", None)
        self.durum.kaydet()
        if self.durum.oynanan_gorev or self.durum.tamamlanan_gorevler:
            return
        teklifler = self._teklif_uret(adet=4)
        if not teklifler:
            return                  # program odağında görev yok: menüden devam
        # Girişi en alçak olan dosya (B46.2 duvar ölçüsü): ilk görev bir
        # başarı olmalı, "ben bunu anlayamıyorum" duvarı değil. Ölçülen
        # kazanım aynı: yine panonun önereceği görevlerden biri.
        try:
            from araclar import duvar
            bulmaca = min(teklifler, key=lambda b: duvar.olc(b)["puan"])
        except Exception:  # noqa: BLE001 - olcu yoksa ilk teklif
            bulmaca = teklifler[0]
        sonuc = self._gorevi_oyna(bulmaca)
        self.teklifler = []
        if sonuc is not None and sonuc.birakildi:
            self._kurulum_esigi = self.durum.oynanan_gorev + 1

    def _kurulum_bekliyor_mu(self) -> bool:
        """İlk görevden sonra sorulacak bir şey kaldı mı?

        Tanışma (takma ad + anket) ve ertelenen kurulum ancak öğrenci EN AZ
        BİR görev oynadıktan sonra sorulur; ilk görevden çekildiyse bir
        sonrakinden sonra (`_kurulum_esigi`). Yarıda kesilirse kalan adımlar
        bir sonraki açılışta gelir (her adım bitince kaydediliyor).
        """
        from . import oyuncu
        if self.durum.oynanan_gorev < max(1, self._kurulum_esigi):
            return False
        bekleyen = self.durum.ayarlar.get("kurulum_bekliyor") or []
        return (oyuncu.tanisma_gerekli_mi(self.durum)
                or any(a in BILINEN_KURULUM for a in bekleyen))

    def _ilk_gorev_sonrasi(self) -> None:
        """Kimlik dışındaki her şey: zorluk ayarı, takma ad, anket, nöbet
        çizelgesi, üssün yeri. Eskiden hepsi ilk görevden ÖNCE soruluyordu."""
        from . import oyuncu
        d = self.durum
        # Listede bu sürümün tanımadığı bir adım olabilir (daha yeni bir
        # sürümün kaydı): DOKUNULMAZ, listede kalır (ileriye uyum, B47.1).
        bekleyen = list(d.ayarlar.get("kurulum_bekliyor") or [])

        def bitti(adim):
            while adim in bekleyen:
                bekleyen.remove(adim)
            d.ayarlar["kurulum_bekliyor"] = list(bekleyen)
            d.kaydet()

        if "zorluk" in bekleyen:
            self._zorluk_ayari()
            bitti("zorluk")
        if oyuncu.tanisma_gerekli_mi(d):
            oyuncu.tanisma(d)
            d.kaydet()
        if "takma_ad" in bekleyen:
            # Sınıfa sonradan bağlanan ev kaydı (araclar/sinif.ogrenciyi_tasi):
            # gerçek adla aynı olan takma ad silindi, uyarıyla yeniden sorulur.
            if not (d.takma_ad or "").strip():
                oyuncu.takma_ad_sec(d)
            bitti("takma_ad")
        if "ritim" in bekleyen:
            oyuncu.ritim_yaz(d, oyuncu.ritim_sor(d.tip == "okul"))
            bitti("ritim")
        if "konum" in bekleyen:
            # 5 Kasim 2026: yer artik SORULMUYOR, sistem atiyor (bkz. yer.py).
            # Eski secim ekrani `_us_konumu_sec` ileride "tasinma" icin duruyor.
            _us_yerini_ata(d)
            bitti("konum")
        if not bekleyen:
            d.ayarlar.pop("kurulum_bekliyor", None)
            d.kaydet()

    def _zorluk_ayari(self) -> None:
        """İlk görevden sonra tek soru: nasıl geldi? Bir kademe ayarlar.

        Kayıtta "Nereden başlayalım?" diye beş soyut zorluk soruluyordu;
        öğrenci hiçbir görev görmeden seçiyordu. Şimdi yaşadığı göreve göre
        söylüyor. Zorluk her zaman Teçhizat ve Ayarlar'dan da değişir.
        """
        simdiki = self.durum.zorluk
        ust = min(5, simdiki + 1)
        alt = max(1, simdiki - 1)
        ekran.yaz()
        secim = ekran.menu("İlk görev sana nasıl geldi?", [
            ("Kolay geldi", "bir üst zorluk: {}".format(ZORLUK_ADLARI[ust])
             if ust != simdiki else "zaten en üst zorluktasın"),
            ("Tam kararındaydı", "{} zorlukta devam".format(ZORLUK_ADLARI[simdiki])),
            ("Zor geldi", "bir alt zorluk: {}".format(ZORLUK_ADLARI[alt])
             if alt != simdiki else "zaten en destekli zorluktasın"),
        ], ipucu="Zorlanırsan oyun desteği kendiliğinden de artırır.")
        yeni = {0: ust, 1: simdiki, 2: alt}.get(secim, simdiki)
        if yeni != simdiki:
            self.durum.zorluk_ayarla(yeni)
            self.teklifler = []
            self.durum.gunluk_ekle("Zorluk değişti: {} - {}".format(
                yeni, ZORLUK_ADLARI[yeni]))
        ekran.bilgi("Zorluk: {} - {}. Teçhizat ve Ayarlar'dan her zaman "
                    "değiştirebilirsin.".format(yeni, ZORLUK_ADLARI[yeni]))

    def _ilerleme_sonrasi(self) -> None:
        """Görev sayacı artan HER akıştan sonra: terfiyi göster, bölümü denetle."""
        from oyun.icerik import hikaye
        yeni = self.durum.rutbe
        if yeni != self._gosterilen_rutbe:
            self._rutbe_terfisi()
            self._gosterilen_rutbe = yeni
        hikaye.bolumu_kontrol_et(self.durum)

    def _rutbe_terfisi(self) -> None:
        d = self.durum
        metin = ("Komutan görev raporunu mühürledi. Artık üste daha fazla "
                 "sorumluluk alabilirsin.\n\nYeni rütben: {}".format(d.rutbe))
        sonraki = d.sonraki_rutbe
        if sonraki:
            metin += "\nSıradaki: {} ({} görev sonra)".format(
                sonraki[1], sonraki[0] - d.oynanan_gorev)
        ekran.yaz()
        ekran.kutu(metin, "RÜTBE TERFİSİ", "acik_sari")
        d.gunluk_ekle("Rütbe terfisi: " + d.rutbe)
        from . import arsiv
        arsiv.posta(d, "Komutan", "Rütbe terfisi: " + d.rutbe, metin,
                    "terfi:" + d.rutbe)

    def _bildirimleri_goster(self) -> None:
        """Öğretmenin bıraktığı okunmamış bildirimler. Bkz. bildiri.py"""
        from . import bildiri
        try:
            yeni = bildiri.okunmamislar(self.durum)
        except Exception:  # noqa: BLE001 - bildirim yuzunden oyun acilmamazlik etmesin
            return
        if not yeni:
            return
        ekran.temizle()
        for tek in yeni:
            ekran.kutu("{}\n\n{}".format(tek.get("zaman", ""), tek.get("metin", "")),
                       "BİLDİRİM", "acik_sari")
            from . import arsiv
            arsiv.posta(self.durum, "Öğretmen", "Öğretmen bildirimi",
                        "{}\n\n{}".format(tek.get("zaman", ""), tek.get("metin", "")),
                        "bildiri:" + str(tek.get("no", "")))
            self.durum.gunluk_ekle("Bildirim: " + tek.get("metin", ""))
        ekran.yaz("Takma adını değiştirmek istersen: Teçhizat ve Ayarlar.", "gri")
        bildiri.okundu_isaretle(self.durum, yeni)
        self.durum.kaydet()
        ekran.bekle()

    def _pano_olayi(self) -> None:
        """Meridyen OS durum çubuğu için `pano` bağlamı (bkz. MERIDYEN_OS.md)."""
        from oyun.icerik import hikaye
        from .durum import RUTBELER
        d = self.durum
        if d.ayarlar.get("kademeli_menu"):
            kod_listesi = [a for a in KAYNAKLAR if d.kaynaklar.get(a, 0)]
        else:
            kod_listesi = list(KAYNAKLAR)
        bolum = hikaye.BOLUMLER[min(d.bolum, len(hikaye.BOLUMLER) - 1)]
        sonraki = d.sonraki_rutbe
        try:
            dikkat = [d.dikkat, d.dikkat_tavani()]
        except Exception:  # noqa: BLE001 - pano yuzunden oyun durmasin
            dikkat = []
        ek = self._telsiz_kimligi()
        if ek:
            ek = {"telsiz": ek}
        ekran.baglam(
            "pano", oyuncu=d.goruntu_adi, rutbe=d.rutbe,
            kaynaklar={a: d.kaynaklar.get(a, 0) for a in kod_listesi},
            kaynak_adlari={a: KAYNAK_ADLARI[a] for a in KAYNAKLAR},
            bolum=bolum.baslik, surum=os_surumu(d.oynanan_gorev),
            ilerleme=[d.rutbe_puani, sonraki[0]] if sonraki else [],
            sonraki_rutbe=sonraki[1] if sonraki else "",
            zorluk=d.zorluk, zorluk_adi=d.zorluk_adi,
            sinif=d.sinif if d.sinif_kodu else "", dikkat=dikkat, **ek)

    def _telsiz_kimligi(self) -> dict:
        """Telsiz (OS) icin kimlik: sunucu adresi, sinif kodu, takma ad ve TUZLU
        OZET. Gercek ad ya da kayit kimligi sunucuya gitmez; ozet tek yonludur ve
        sinif koduna baglidir. Sinif ya da sunucu yoksa bos (pano degismez)."""
        import hashlib
        from . import ag
        d = self.durum
        kod = (d.sinif_kodu or "").strip().upper()
        adres = ag.sunucu()
        if not kod or not adres:
            return {}
        ozet = hashlib.sha256("telsiz|{}|{}".format(kod, d.kimlik()).encode("utf-8")).hexdigest()[:32]
        return {"sunucu": adres, "kod": kod, "kimlik": ozet,
                "takma": (d.takma_ad or "").strip()}

    def _ust_pano(self) -> None:
        ekran.temizle()
        if ekran.olayli():
            self._pano_olayi()
        ekran.baslik(OYUN_ADI, "kalin", "acik_cam")
        d = self.durum
        sol = "{}  {}  {}".format(d.goruntu_adi, S["dikey"], d.rutbe)
        # Dar ekranda kaynak satiri kendi satirina iniyor; ayraclari da
        # sikisiyor ("  |  " -> " | ") ki sarmaya gerek kalmasin.
        sag = d.ozet_satiri()
        if len(sol) + len(sag) + 2 > ekran.genislik():
            sag = d.ozet_satiri(dar=True)
        if d.ayarlar.get("kademeli_menu"):
            # B36.18: ilk görevlerde yalnız eldeki kaynaklar; dördü birden
            # sıfırla durunca öğrenciye anlamsız sayaç duvarı gibi geliyor.
            eldeki = [a for a in KAYNAKLAR if d.kaynaklar.get(a, 0)]
            sag = (" | ".join("{} {}".format(KAYNAK_ADLARI[a], d.kaynaklar[a])
                              for a in eldeki)
                   if eldeki else "Kaynak: ilk rapor getirecek")
        ekran.iki_sutun(sol, sag, "kalin", "acik_sari")

        # Kullanici: "seviyeler rutbe olur." Ilerleme cubugu artik bir
        # sonraki BOLUMU degil bir sonraki RUTBEYI gosteriyor; bolum adi
        # hikayenin nerede oldugunu soyleyen etiket olarak kaldi.
        from oyun.icerik import hikaye
        from .durum import RUTBELER
        bolum = hikaye.BOLUMLER[min(d.bolum, len(hikaye.BOLUMLER) - 1)]
        sonraki = d.sonraki_rutbe
        if sonraki:
            taban = RUTBELER[d.rutbe_sirasi][0]
            ilerleme_cubugu = ekran.cubuk(
                max(0, d.rutbe_puani - taban), max(1, sonraki[0] - taban), 12)
            bolum_satiri = "{}  {}  {} {} {}/{}{}".format(
                bolum.baslik, ilerleme_cubugu, S["ok"], sonraki[1],
                d.rutbe_puani, sonraki[0], S["yildiz"])
        else:
            bolum_satiri = "{}  {}  En yüksek rütbe".format(
                bolum.baslik, ekran.cubuk(1, 1, 12))
        ekran.yaz(bolum_satiri, "acik_mor")
        satir = "Zorluk {} - {}  {}  Destek: uyarlanır".format(
            d.zorluk, d.zorluk_adi, S["dikey"])
        # Sinif bagi varsa sinifini goster. Okul adi OGRENCIYE GOSTERILMEZ
        # (B41): kayitta ogretmende durur, raporda kullanilir. §0 geregi
        # burada SIRALAMA YOK: kac kisi oldugu yaziyor, kimin nerede oldugu
        # degil.
        if d.sinif_kodu:
            try:
                from araclar.sinif import sinif_ogrencileri
                adet = len(sinif_ogrencileri(d.sinif_kodu))
            except Exception:  # noqa: BLE001 - pano yuzunden oyun durmasin
                adet = 0
            if adet:
                satir += "  {}  {}: {} kişi".format(S["dikey"], d.sinif, adet)
        ekran.yaz(satir, "gri")
        ekran.ayrac()

    @staticmethod
    def _bedel_metni(bedel) -> str:
        return " ".join("{} {}".format(KAYNAK_ADLARI.get(a, a), m)
                        for a, m in bedel.items() if m)

    def _eksik_kaynaklar(self, bedel) -> dict:
        """Neyin ne kadar eksik oldugu. Bos sozluk = yetiyor."""
        return {a: m - self.durum.kaynaklar.get(a, 0)
                for a, m in (bedel or {}).items()
                if self.durum.kaynaklar.get(a, 0) < m}

    def _ariza_isareti(self) -> str:
        """Menü satırının yanına "(1 arıza)". Öğrenci menüye girmeden görsün."""
        from . import tesis
        sayi = len(tesis.arizali_kodlar(self.durum))
        return "  ({} arıza)".format(sayi) if sayi else ""

    def _tesisler(self) -> None:
        """Tesis ekrani: ne uretiyor, hangisi durdu, onarim/gelistirme ne kadar.

        IKI EYLEM, TEK EKRAN: arizali tesis ONARILIR, calisan tesis
        GELISTIRILIR. Gelistirme bir kapi degil -- hicbir sey almayan
        ogrenci hicbir sey kaybetmez, oyun aynen oynanir. Yalnizca
        hizlandirir. (TASARIM_NOTLARI §3)
        """
        from . import tesis

        while True:
            ekran.temizle()
            ekran.baslik("ÜSSÜN TESİSLERİ", "kalin", "acik_cam")
            ekran.yaz("Her görev bitiminde çalışan tesisler üretir. "
                      "Bekleyerek değil, çalışarak.", "gri")
            self._konum_satiri()
            ekran.ayrac()

            eylemler = []
            for satir in tesis.uretim_ozeti(self.durum):
                durum_metni = "çalışıyor" if satir["calisiyor"] else "DURDU"
                renk = "acik_yesil" if satir["calisiyor"] else "acik_sari"
                ekran.yaz("{}  --  {}   (seviye {})".format(
                    satir["ad"], durum_metni, satir["seviye"]), renk)
                ekran.yaz("   görev başına {} +{}   |   bugüne kadar {}".format(
                    KAYNAK_ADLARI.get(satir["kaynak"], satir["kaynak"]),
                    satir["miktar"], satir["uretilen"]), "gri")
                ekran.yaz("   " + satir["hikaye"], "gri")

                if satir.get("bekleyen"):
                    ekran.yaz("   Genişleme sürüyor: {} görev sonra bitiyor.".format(
                        satir["bekleyen"]), "acik_mor")
                if not satir["calisiyor"]:
                    bedel = tesis.onarim_bedeli(self.durum)
                    ekran.yaz("   Onarım: " + self._bedel_metni(bedel),
                              "acik_sari")
                    eylemler.append(("onar", satir, bedel))
                elif satir["gelistirme"]:
                    ekran.yaz("   Geliştirme: {}  ({} +1 üretim)".format(
                        self._bedel_metni(satir["gelistirme"]),
                        KAYNAK_ADLARI.get(satir["kaynak"], satir["kaynak"])),
                        "gri")
                    eylemler.append(("gelistir", satir, satir["gelistirme"]))
                else:
                    ekran.yaz("   En üst seviyede.", "gri")
                ekran.yaz()

            self._depo_satirlari()
            ekran.yaz()

            if sum(1 for t, _, _ in eylemler if t == "onar") > 1:
                ekran.yaz("Birden çok tesis durduğu için onarım ucuzladı.",
                          "gri")

            secenekler = []
            for tur, satir, bedel in eylemler:
                if tur == "onar":
                    secenekler.append((satir["ad"] + " onar",
                                       self._bedel_metni(bedel)))
                else:
                    secenekler.append((satir["ad"] + " geliştir",
                                       self._bedel_metni(bedel)))
            secenekler.append(("Üretim zinciri", "ham taş > maden > külçe > alaşım"))
            secenekler.append(("Geri dön", ""))

            secim = ekran.menu("", secenekler)
            if secim == len(eylemler):
                self._zincir()
                continue
            if secim > len(eylemler):
                return
            tur, hedef, bedel = eylemler[secim]
            ne_icin = hedef["ad"] + (" onarımı" if tur == "onar"
                                     else " geliştirmesi")
            if not self._bedeli_ode(bedel, ne_icin):
                continue
            if tur == "onar":
                tesis.onar(self.durum, hedef["kod"])
                mesaj = "{} yeniden çalışıyor.".format(hedef["ad"])
            else:
                tesis.gelistir(self.durum, hedef["kod"])
                mesaj = "{} seviye {} oldu; artık görev başına {} +{}.".format(
                    hedef["ad"], tesis.seviye(self.durum, hedef["kod"]),
                    KAYNAK_ADLARI.get(hedef["kaynak"], hedef["kaynak"]),
                    tesis.uretim_miktari(self.durum, hedef["kod"]))
            self.durum.kaydet()
            ekran.yaz()
            ekran.basari(mesaj)
            ekran.bekle()

    # ------------------------------------------------------ üretim zinciri
    def _depo_satirlari(self) -> None:
        """Tesisler ekranında Depo dökümü + zincirin tıkandığı yer (B28.9)."""
        from . import madenler as M
        from . import materyal, tesis, zincir
        ozet = tesis.zincir_ozeti(self.durum)
        baglam = getattr(ekran, "baglam", None)     # Meridyen OS olay katmanı
        if callable(baglam):
            baglam("tesisler", stoklar=ozet["stoklar"], zincir=ozet["zincir"],
                   darbogaz=ozet["darbogaz"], materyal=materyal.ozet(self.durum))
        st = ozet["stoklar"]
        ekran.yaz("DEPO  (ham taş: {} birim = {})".format(
            st["cevher"], zincir.kg_metni(st["ham_tas_gram"])), "kalin")
        bos = True
        for baslik, anahtar in (("Maden", "madenler"), ("Külçe", "kulceler"),
                                ("Alaşım", "alasimlar")):
            parcalar = []
            for kod, gram in st[anahtar].items():
                if gram <= 0:
                    continue
                kayit = M.alasim(kod) if anahtar == "alasimlar" else M.maden(kod)
                if kayit is not None:
                    parcalar.append("{} {}".format(kayit.ad, zincir.kg_metni(gram)))
            if parcalar:
                bos = False
                ekran.yaz("   {}: {}".format(baslik, ", ".join(parcalar)), "gri")
        parcalar = ["{} x{}".format(materyal.materyal(k).ad, n)
                    for k, n in materyal.ozet(self.durum)["stok"].items()]
        if parcalar:
            bos = False
            ekran.yaz("   Materyal: " + ", ".join(parcalar), "gri")
        if bos:
            ekran.yaz("   (maden, külçe, alaşım yok -- Üretim zinciri'nden ham "
                      "taşı işleyebilirsin; zorunlu değil)", "gri")
        if ozet["darbogaz"]:
            ekran.yaz("   Darboğaz: " + ozet["darbogaz"]["neden"], "acik_sari")

    def _sayi_sor(self, istem: str) -> Optional[float]:
        cevap = ekran.sor(istem).strip().replace(",", ".")
        if not cevap:
            return None
        try:
            return float(cevap)
        except ValueError:
            ekran.hata("Sayı yazmalısın.")
            return None

    def _zincir(self) -> None:
        """Ham taş > maden > külçe > alaşım. Uygulama kipi: miktarı sen girersin.

        Zincir bir ödül, kapı değil: buraya hiç girmeyen öğrenci hiçbir şey
        kaybetmez (B28.13, TASARIM_NOTLARI §3).
        """
        from . import madenler as M
        from . import zincir
        kg = zincir.kg_metni
        while True:
            ekran.temizle()
            ekran.baslik("ÜRETİM ZİNCİRİ", "kalin", "acik_cam")
            ekran.yaz("ham taş -> işleme -> maden -> ergitme -> külçe -> alaşım",
                      "gri")
            ekran.yaz("Zorunlu değil: ders içeriğin buna bağlı değil. "
                      "Denemek serbest.", "gri")
            ekran.ayrac()
            self._depo_satirlari()
            ekran.yaz()
            k = zincir.kademe(self.durum)
            secim = ekran.menu("", [
                ("Ham taşı işle", "cevher harcar, maden çıkar"),
                ("Madeni ergit", "külçe; demirde kömür + kireç taşı katkısı"),
                ("Alaşım yap", "külçelerden; oranı kendin girebilirsin"),
                ("Oran dene", "harcamadan: bu oranla ne çıkar?"),
                ("Materyal üret", "külçe/alaşımdan parça; ders köprüsü açar"),
                ("Köprü görevi", "elindeki materyalin dersine bağlı görev"),
                ("Geri dön", ""),
            ])
            if secim == 6:
                return
            if secim == 4:
                self._materyal_uret()
                continue
            if secim == 5:
                self._kopru_gorevi()
                continue
            if secim == 0:
                from . import yer
                aday = M.acik_madenler(k)
                yerel = yer.yerel_madenler(self.durum)
                i = ekran.menu("Hangi maden?", [
                    (m.ad, "taşın %{} kadarı maden{}".format(
                        int(round(zincir.tenor(m.kod, self.durum) * 100)),
                        " (bölgende yatağı var)" if m.kod in yerel else ""))
                     for m in aday]
                    + [("Vazgeç", "")])
                if i >= len(aday):
                    continue
                n = self._sayi_sor("Kaç cevher birimi işlensin? (1 birim = {})".format(
                    kg(zincir.TAS_GRAMI)))
                if n is None:
                    continue
                r = zincir.isle(self.durum, aday[i].kod, int(n))
                if r["ok"]:
                    ekran.basari("{} cevher ({}) işlendi: {} {} çıktı.".format(
                        r["harcanan"], kg(r["tas_gram"]), kg(r["gram"]),
                        aday[i].ad.lower()))
                    self.durum.kaydet()
                else:
                    ekran.hata(r["neden"])
            elif secim == 1:
                aday = [m for m in M.acik_madenler(k) if M.kulceye_donusur(m.kod)]
                i = ekran.menu("Hangi metal?", [
                    (m.ad, "maden elde {}  |  verim %{}".format(
                        kg(zincir.miktar(self.durum, "maden", m.kod)),
                        int(round(zincir.ergitme_verimi(m.kod) * 100))))
                    for m in aday] + [("Vazgeç", "")])
                if i >= len(aday):
                    continue
                kod = aday[i].kod
                if kod in zincir.KATKI_ORANLARI:
                    ekran.yaz("Katkı (1 kg maden için): " + ", ".join(
                        "{} {}".format(M.maden(a).ad.lower(), kg(int(o * 1000)))
                        for a, o in zincir.KATKI_ORANLARI[kod].items()), "gri")
                n = self._sayi_sor("Kaç gram maden ergitilsin?")
                if n is None:
                    continue
                r = zincir.ergit(self.durum, kod, int(n))
                if r["ok"]:
                    ekran.basari("{} külçe elde ettin (verim %{}).".format(
                        kg(r["gram"]), int(round(r["verim"] * 100))))
                    self.durum.kaydet()
                else:
                    ekran.hata(r["neden"])
            elif secim in (2, 3):
                aday = M.acik_alasimlar(k)
                if not aday:
                    ekran.yaz("Bu kademede alaşım henüz açık değil.", "gri")
                    ekran.bekle()
                    continue
                i = ekran.menu("Hangi alaşım?", [
                    (a.ad, ", ".join("{} %{}".format(
                        M.maden(b).ad.lower(), round(o * 100, 1)).replace(".", ",")
                        for b, o in a.bilesim.items())) for a in aday]
                    + [("Vazgeç", "")])
                if i >= len(aday):
                    continue
                a = aday[i]
                oranlar = None
                if ekran.onayla("Oranları kendin girmek ister misin?", False):
                    oranlar = {}
                    for b in a.bilesim:
                        v = self._sayi_sor("{} yüzde kaç? (boş = %{})".format(
                            M.maden(b).ad, round(a.bilesim[b] * 100, 1)))
                        oranlar[b] = a.bilesim[b] if v is None else v / 100.0
                deneme = zincir.alasim_dene(a.kod, oranlar)
                if not deneme["ok"]:
                    ekran.hata(deneme["neden"])
                else:
                    ekran.yaz("Bu oranla: " + deneme["sonuc"],
                              "acik_yesil" if deneme["gecerli"] else "acik_sari")
                if secim == 3 or not deneme["ok"]:
                    ekran.bekle()
                    continue
                n = self._sayi_sor("Kaç gram {} yapılsın?".format(a.ad.lower()))
                if n is None:
                    continue
                r = zincir.alasim_yap(self.durum, a.kod, int(n), oranlar)
                if r["ok"]:
                    ekran.basari("{} {} yapıldı.".format(kg(r["gram"]), a.ad.lower()))
                    self.durum.kaydet()
                else:
                    ekran.hata(r["neden"])
            ekran.bekle()

    def _materyal_uret(self) -> None:
        """Külçe/alaşımdan materyal. Reddedilirse hiçbir şey harcanmaz."""
        from . import materyal, zincir
        kg = zincir.kg_metni
        k = zincir.kademe(self.durum)
        aday = materyal.acik_materyaller(k)
        if not aday:
            ekran.yaz("Bu kademede materyal henüz açık değil.", "gri")
            ekran.bekle()
            return
        i = ekran.menu("Hangi materyal?", [
            (m.ad, "{} {} gerek  |  elde {} adet  |  {}".format(
                materyal.kaynak_adi(m), kg(m.gram),
                materyal.adet(self.durum, m.kod), m.kullanim)) for m in aday]
            + [("Vazgeç", "")])
        if i >= len(aday):
            return
        m = aday[i]
        n = self._sayi_sor("Kaç adet {} yapılsın?".format(m.ad.lower()))
        if n is None:
            return
        r = materyal.uret(self.durum, m.kod, int(n))
        if r["ok"]:
            ekran.basari("{} adet {} yapıldı ({} harcandı). Ders köprüsü: {}.".format(
                r["adet"], m.ad.lower(), kg(r["harcanan"]), m.kopru.baslik))
            self.durum.kaydet()
        else:
            ekran.hata(r["neden"])
        ekran.bekle()

    def _kopru_gorevi(self) -> None:
        """Elindeki materyalin açtığı köprü görevini oynar. Materyal harcanmaz;
        köprü ek görevdir, ders içeriği ondan bağımsızdır (§0)."""
        from . import materyal
        acik = materyal.acik_koprular(self.durum)
        if not acik:
            ekran.yaz("Henüz materyalin yok. Materyal üretince o dersin köprü "
                      "görevi burada açılır; ders içeriğin buna bağlı değil.", "gri")
            ekran.bekle()
            return
        i = ekran.menu("Hangi köprü?", [
            (x["baslik"], "{} ({}) -- {}".format(
                x["materyal_ad"], DERS_ADLARI.get(x["ders"], x["ders"]),
                x["aciklama"])) for x in acik] + [("Vazgeç", "")])
        if i >= len(acik):
            return
        x = acik[i]
        kademe = max(1, int(getattr(self.durum.ders(x["ders"]), "kademe", 1) or 1))
        bulmaca = uret(ders=x["ders"], kademe=kademe, konu=x["konu"],
                       rastgele=self.durum.rastgele("kopru"), etiket=x["etiket"])
        if bulmaca is None:
            ekran.hata("Bu köprünün görevi bulunamadı.")
            ekran.bekle()
            return
        self._gorevi_oyna(bulmaca, serbest=True)

    def _tesis_turu(self) -> None:
        """Görev bitti: tesisler üretsin, sırası geldiyse arıza çıksın.

        ÜRETİM GÖREVE BAĞLI, SAATE DEĞİL. Duvar saati kullansaydık oyunu
        açık bırakan ya da ertesi gün girip hiçbir şey yapmayan öğrenci
        ödüllenirdi; kaynak öğrenmenin değil beklemenin karşılığı olurdu.
        (TASARIM_NOTLARI §3)
        """
        from . import konum, tesis

        kazanc = tesis.uretimi_isle(self.durum)
        if kazanc:
            self.durum.kaynak_ekle(kazanc)
            ekran.yaz()
            ekran.yaz("Üssün tesisleri üretti:", "kalin")
            for anahtar, miktar in kazanc.items():
                ekran.madde("{} +{}".format(
                    KAYNAK_ADLARI.get(anahtar, anahtar), miktar), "acik_yesil")

        # Süren genişleme: kazı bir görev ilerler, biten seviye açılır.
        for kod in tesis.genislemeleri_ilerlet(self.durum):
            ekran.yaz()
            ekran.basari("{} genişlemesi tamamlandı: seviye {}.".format(
                tesis.ad(kod), tesis.seviye(self.durum, kod)))

        self._konum_giderini_isle()

        # 5 Kasim 2026 (oyun turu): tesisler menude acilmadan ariza cikiyor,
        # mesaj "Ussun Tesisleri'nden onarabilirsin" diyordu ama o yer kapaliydi.
        # Ariza ancak tesis yeri acildiktan ARIZA_ACILIS_PAYI gorev sonra gelir.
        bozulan = (tesis.ariza_dene(self.durum, self.durum.rastgele("ariza"))
                   if _ariza_zamani_mi(self.durum) else None)
        if bozulan:
            ekran.yaz()
            # Oyun ogrenciye GELIYOR: menuden gorev secmek yerine uste bir
            # sey oluyor. TASARIM_NOTLARI §3 bunu acikca istiyor.
            olay = konum.tehlike_metni(konum.konum_kodu(self.durum))
            mesaj = (
                "{}{} durdu. Üretimi kesildi; onarılana kadar bir şey "
                "vermeyecek.".format(olay + ". " if olay else "", tesis.ad(bozulan))
                + chr(10) + chr(10)
                + "Komuta Masası > Üssün Tesisleri'nden onarabilirsin."
            )
            ekran.kutu(mesaj, "ARIZA", "acik_sari")

    # ------------------------------------------------ Siber Nöbet (5 Kasım 2026)
    def _siber_olayi(self) -> None:
        """İlk oltalama tatbikatı: Posta'ya sahte ileti, öğrencinin tepkisi."""
        from . import arsiv, siber
        d = self.durum
        if not siber.olta_zamani_mi(d):
            return
        tz = siber.ilk_tuzak(d)
        if tz.kanal == "posta":
            i = siber.ILK_OLTA
            arsiv.posta(d, i.gonderen, i.konu, i.metin, "siber:" + i.kod)
        ekran.yaz()
        ekran.kutu("Kimden: {}\n\n{}".format(tz.kimden, tz.metin), tz.baslik, "beyaz")
        secim = ekran.menu("Ne yaparsın?", list(tz.secenekler))
        sonuc = siber.olta_sonucu(d, ("tikla", "bildir", "sil")[min(secim, 2)])
        ekran.yaz()
        ekran.kutu(sonuc["metin"], sonuc["baslik"], sonuc["ton"])
        ekran.yaz("Bu tuzağı ele veren işaretler:", "kalin")
        for satir in sonuc["isaretler"]:
            ekran.madde(satir, "acik_sari")
        d.gunluk_ekle("Siber Nöbet açıldı (güvenlik tatbikatı)")
        d.kaydet()
        ekran.bekle()

    def _siber_nobet(self) -> None:
        """E-posta duvarını kural bloklarıyla kurma ve sınama."""
        from . import siber
        veri = siber.durum_al(self.durum)
        while True:
            ekran.yaz()
            ekran.baslik("SİBER NÖBET: E-POSTA DUVARI", "kalin", "acik_cam")
            ekran.yaz("Kurallar yukarıdan aşağı denenir; ilk uyan karar verir. "
                      "Hiçbiri uymazsa ileti geçer.", "gri")
            if veri["kurallar"]:
                for no, kural in enumerate(veri["kurallar"], 1):
                    ekran.madde("{}. {}".format(no, siber.kural_metni(kural)), "beyaz")
            else:
                ekran.yaz("Henüz kural yok: duvar her şeyi geçiriyor.", "acik_sari")
            if veri.get("en_iyi"):
                ekran.yaz("En iyi sınama: " + ekran.yildizlar(int(veri["en_iyi"]), 3), "gri")
            secim = ekran.menu("", [
                ("Kural bloğu ekle", "EĞER ... İSE ..."),
                ("Kural sil", ""),
                ("Duvarı sına", "tatbikat iletileriyle"),
                ("Geri dön", ""),
            ])
            if secim == 0:
                kural = self._siber_kural_kur()
                if kural:
                    veri["kurallar"].append(kural)
            elif secim == 1 and veri["kurallar"]:
                i = ekran.menu("Hangisi silinsin?", [
                    siber.kural_metni(k) for k in veri["kurallar"]] + ["Vazgeç"])
                if i < len(veri["kurallar"]):
                    veri["kurallar"].pop(i)
            elif secim == 2:
                self._siber_sina(veri)
            elif secim == 3:
                self.durum.kaydet()
                return

    def _siber_kural_kur(self):
        from . import siber
        alanlar = list(siber.ALANLAR)
        a = ekran.menu("EĞER (alan):", [siber.ALANLAR[k] for k in alanlar] + ["Vazgeç"])
        if a >= len(alanlar):
            return None
        alan = alanlar[a]
        kosullar = list(siber.KARSILASTIRMALAR)
        k = ekran.menu("Karşılaştırma:", [siber.KARSILASTIRMALAR[x] for x in kosullar])
        oneriler = siber.DEGER_ONERILERI[alan]
        v = ekran.menu("Değer:", [o or "(boş)" for o in oneriler] + ["Kendim yazayım"])
        deger = oneriler[v] if v < len(oneriler) else ekran.sor("Değer:").strip().lower()
        eylemler = list(siber.EYLEMLER)
        e = ekran.menu("İSE (eylem):", [siber.EYLEMLER[x] for x in eylemler])
        return {"alan": alan, "kosul": kosullar[min(k, len(kosullar) - 1)],
                "deger": deger, "eylem": eylemler[min(e, len(eylemler) - 1)]}

    def _siber_sina(self, veri) -> None:
        from . import siber
        r = siber.duvari_sina(veri["kurallar"])
        ekran.yaz()
        ekran.yaz("Sınama: {} tatbikat iletisi".format(len(siber.ILETILER)), "kalin")
        ekran.madde("Yakalanan sahte: {}".format(len(r["yakalanan"])), "acik_yesil")
        if r["uyarilan"]:
            ekran.madde("Uyarıyla geçen sahte: {}".format(len(r["uyarilan"])), "acik_sari")
        for i in r["kacan"]:
            ekran.madde("KAÇAN: \"{}\" ({})".format(i.konu, i.adres), "acik_sari")
        for i in r["yanlis_alarm"]:
            ekran.madde("YANLIŞ ALARM: gerçek ileti durduruldu: \"{}\"".format(i.konu),
                        "acik_sari")
        ekran.yaz("Sonuç: {} yıldız".format(r["yildiz"]), "kalin")
        if r["yildiz"] > int(veri.get("en_iyi") or 0):
            veri["en_iyi"] = r["yildiz"]
            self.durum.gunluk_ekle("Siber Nöbet: duvar {} yıldız".format(r["yildiz"]))
        ekran.bekle()

    def _konum_satiri(self) -> None:
        """Tesis ekranının başındaki konum özeti: nerede, neye mal oluyor."""
        from . import konum

        kod = konum.konum_kodu(self.durum)
        parcalar = []
        carpan = konum.genisleme_carpani(kod)
        if abs(carpan - 1.0) > 0.01:
            parcalar.append("genişleme x{:.1f}".format(carpan).replace(".", ","))
        sure = konum.kazi_gorevi(kod)
        if sure:
            parcalar.append("{} görevde biter".format(sure))
        gider = konum.enerji_gideri(kod, konum.toplam_seviye(self.durum))
        if gider:
            parcalar.append("görev başına enerji -{}".format(gider))
        ekran.yaz("Üs: {}{}".format(
            konum.ad(kod), "  (" + ", ".join(parcalar) + ")" if parcalar else ""),
            "acik_cam")
        from . import yer
        o = yer.ozet(self.durum)
        if o:
            ekran.yaz("Yer: {}  ({}, {})".format(o["koordinat"], o["il"], o["iklim"]),
                      "gri")
        uyari = konum.uyari(self.durum)
        if uyari:
            ekran.yaz(uyari, "acik_sari")

    def _konum_giderini_isle(self) -> None:
        """Konumun görev başına enerji giderini düşer ve sonucunu anlatır.

        KİLİT YOK: enerji eksiye inmez. Karşılanamayan görevde gerilim artar,
        üçüncüde üs güvenli biçimde düzlüğe iner; kaynak, tesis ve seviyeler
        olduğu gibi kalır (bkz. oyun/motor/konum.py).
        """
        from . import konum

        rapor = konum.enerji_isle(self.durum)
        if not rapor:
            return
        if rapor.get("odendi"):
            ekran.yaz("Üssün giderleri: enerji -{}".format(rapor["gider"]), "gri")
            return
        if rapor.get("indi"):
            ekran.yaz()
            ekran.kutu(
                rapor.get("inis_metni", "Üs indi.") + chr(10) + chr(10)
                + "Kaynakların, tesislerin ve seviyelerin duruyor. Üs şimdi "
                + konum.ad(rapor["yeni_konum"]) + " konumunda.",
                "ÜS İNDİ", "acik_sari")
            return
        kalan = konum.GERILIM_SINIRI - rapor["gerilim"]
        ekran.yaz()
        ekran.kutu(
            "Üssün enerji gideri {} ama depoda o kadar yok ({} eksik). "
            "Motorlar yedekten çalışıyor.".format(rapor["gider"], rapor["eksik"])
            + chr(10) + chr(10)
            + "{} görev daha karşılanmazsa üs iner. Atölyeyi geliştirmek "
              "gideri karşılamanın en doğrudan yolu.".format(kalan),
            "ENERJİ AÇIĞI", "acik_sari")

    def _bedeli_ode(self, bedel, ne_icin: str) -> bool:
        """Kaynak yeterse duser ve True doner; yetmezse NEYIN eksik oldugunu soyler.

        `durum.kaynak_yeter_mi()` uzun suredir yazili ama hicbir yerden
        cagrilmiyordu (TASARIM_NOTLARI §3 bunu ismen soyluyor). Giris
        noktasi burasi.
        """
        if self.durum.kaynak_yeter_mi(bedel):
            self.durum.kaynak_ekle({a: -m for a, m in bedel.items()})
            return True
        eksik = self._eksik_kaynaklar(bedel)
        ekran.yaz()
        ekran.hata("{} için kaynağın yetmiyor.".format(ne_icin))
        ekran.yaz("Eksik: " + self._bedel_metni(eksik), "acik_sari")
        # §0: engel ceza degil, yon gosterme. Ne yapacagini soyluyoruz.
        ekran.yaz("Görev çözerek kazanılır; birkaç iş sonra yeniden dene.", "gri")
        ekran.bekle()
        return False

    def _yarim_seferi_kapat(self) -> None:
        """Önceki oturum zaman seferinin ortasında bitti (B36.14).

        Zil çalınca öğrenci çoğu zaman "x" yazmaz, pencereyi kapatır ya da
        telefonda sekmeyi kapatır. Süreç öldüğü için o an iade verilemez;
        kayıtta kalan işaretten burada, açılışta verilir.
        """
        if YARIM_SEFER not in self.durum.ayarlar:
            return
        ekran.yaz()
        ekran.yaz("Bir önceki girişinde zaman seferin yarıda kalmıştı.", "acik_sari")
        if not self._sefer_iadesini_ver():
            ekran.yaz("Bütün bölümleri bitirmiştin; geri dönecek pay yok.", "gri")

    def _sefer_iadesini_ver(self) -> dict:
        """Yarida kalan seferin iadesini uygular, KAYDEDER, kisaca soyler.

        Iadenin TEK kaynagi kayittaki `YARIM_SEFER` isareti: sefer baslarken
        bedelle birlikte yazilir, her biten bolumde guncellenir, iade
        verilirken ayni kayitla silinir. Boylece iade bir kez verilir ve
        surec OLDURULSE de kaybolmaz (pencerenin X'i, telefonda sekmenin
        kapanmasi Python'a hicbir istisna gondermez): bir sonraki acilista
        `_yarim_seferi_kapat` verir.

        Once kaynak ve kayit, sonra ekran: pencere kapanirken cagrildiginda
        ekrana yazmak da patlayabilir; iade yine de kayitta olmali.
        """
        isaret = self.durum.ayarlar.pop(YARIM_SEFER, None)
        try:
            toplam_bolum = int(isaret["toplam"])
            tamamlanan = int(isaret["tamamlanan"])
            bedel = {a: int(m) for a, m in isaret["bedel"].items()}
        except (TypeError, KeyError, ValueError, AttributeError):
            toplam_bolum, tamamlanan, bedel = 0, 0, {}
        iade = sefer_iadesi(bedel, tamamlanan, toplam_bolum)
        if not iade:
            if isaret is not None:
                try:
                    self.durum.kaydet()     # isaret silindi; iade yok
                except Exception:  # noqa: BLE001
                    pass
            return {}
        uygulanan = self.durum.kaynak_ekle(iade)
        metin = self._bedel_metni(uygulanan)
        self.durum.gunluk_ekle("Yarıda kalan seferin bedelinden iade: " + metin)
        try:
            self.durum.kaydet()
        except Exception:  # noqa: BLE001 - asil akis (cikis/cokme) surmeli
            pass
        try:
            ekran.yaz("Tamamlanmayan {} bölümün payı üsse geri döndü: {}.".format(
                toplam_bolum - tamamlanan, metin), "acik_sari")
        except Exception:  # noqa: BLE001 - ekran kapanmis olabilir
            pass
        return uygulanan

    def _ana_menu(self) -> int:
        self._ust_pano()
        from oyun.icerik import hikaye
        gorev = hikaye.gunun_hedefi(self.durum)
        if gorev:
            ekran.yaz(gorev, "acik_cam")
        from . import oyuncu, pano
        onumdeki = None
        if oyuncu.baskin_egilim(self.durum) == "rekabet":
            ilk = pano.sinif_panosu(self.durum, 1)
            onumdeki = ilk[0] if ilk else None
        kisisel = oyuncu.acilis_satiri(self.durum, onumdeki, SEFER_BEDELI)
        if kisisel:
            ekran.yaz(S["ok"] + " " + kisisel, "acik_sari")
        haberler = [
            "Kuzey kulesinden duman görülüyor; nöbetçi bunun sis olmadığını söylüyor.",
            "Arşiv görevlisi, üstü çizilmiş yeni bir dosyayı masaya bıraktı.",
            "Kronograf odasından kısa bir metal sesi geldi. Aygıt yeniden etkin.",
            "Depo sayımı yine tutmadı. Komutan gün bitmeden açıklama bekliyor.",
            "Keşif ekibi haritada işaretlenmemiş bir patika buldu.",
        ]
        haber = haberler[self.durum.oynanan_gorev % len(haberler)]
        ekran.yaz()
        ekran.kutu(haber, "ÜSTEN HABER", "beyaz")
        from . import arsiv
        arsiv.posta(self.durum, "Komutan", "ÜSTEN HABER: " + haber[:44].rstrip() + "…", haber,
                    "haber:{}".format(self.durum.oynanan_gorev))
        ogeler = {
            "usta": ("Usta Çadırı", "önce izle, sonra yanında dururum, sonra sen yap"),
            "komuta": ("Komuta Masası", "üssün bekleyen saha görevleri"),
            "kronograf": ("Kronograf Odası",
                          "bir çağın içine gir: çağı çöz, yeri bul, hesapla, raporla"
                          + "  (" + self._bedel_metni(SEFER_BEDELI) + ")"),
            "tesis": ("Üssün Tesisleri" + self._ariza_isareti(),
                      "maden, tarla ve atölye; ne üretiyorlar, hangisi durdu"),
            "gunluk": ("Kâşif Günlüğü", "rütbe merdiveni, önündekiler ve rozetler"),
            "iz": ("İz Sürme Masası", "neyi bildiğini bilmediğin işler için kısa bakış"),
            "harita": ("Harita Odası", "açılan yollar, eline geçen işler ve sıradaki hedef"),
            "kisa": ("Kısa Sefer", "bir dosyayla başla; bitince bırak veya devam et"),
            "ayar": ("Teçhizat ve Ayarlar",
                     "takma ad, oyuncu anketi, zorluk, ipuçları ve yazım hızı"),
            "program": ("Okul Ders Programı", "haftalık saatler ve görevlerin ders odağı"),
            "geri": ("Geri Bildirim Gönder", "not yaz, ilerlemenle birlikte paketle"),
            "devret": ("Nöbeti Devret", "kaydet ve ana ekrana dön"),
            "siber": ("Siber Nöbet", "üssün e-posta duvarı: kuralları sen kurarsın"),
        }
        # Ogrenmenin cekirdegi (ilk iki) ve ayarlar SABIT; yalnizca uc
        # katmanin sirasi kisiye gore degisir. Hicbir madde gizlenmez.
        # Vakti az olan (kayitta soylediyse, B41) icin Kisa Sefer one gelir.
        bas = ["usta", "komuta"]
        orta = ["iz", "harita", "kisa"]
        from . import siber
        if siber.acik_mi(self.durum):
            orta.append("siber")
        if oyuncu.vakti_az(self.durum):
            orta.remove("kisa")
            bas.append("kisa")
        self._menu_anahtarlari = self._kademeli_suz(
            bas + list(self._katman_sirasi) + orta
            + ["ayar", "program", "geri", "devret"], ogeler)
        if ekran.olayli():
            ekran.baglam(
                "ana_menu",
                yerler=[{"anahtar": k, "ad": ogeler[k][0],
                         "aciklama": ogeler[k][1]}
                        for k in self._menu_anahtarlari],
                kilitli=[{"anahtar": k, "ad": ogeler[k][0],
                          "esik": KADEMELI_ACILIS.get(k, 0)}
                         for k in getattr(self, "_kilitli_anahtarlar", [])],
                haber=haber, gunun_hedefi=gorev or "", kisisel=kisisel or "")
        return ekran.menu("ÜSTE NEREYE GİDECEKSİN?",
                          [ogeler[k] for k in self._menu_anahtarlari])

    def _kademeli_suz(self, anahtarlar: List[str], ogeler) -> List[str]:
        """B36.18: yeni seferin ilk görevlerinde menüyü sadeleştirir.

        Çekirdek döngü önce tek başına görünsün: görevi al, kanıtla karar
        ver, rapor üste bir kapı açsın. Her rapor eşiği geçince açılan yer
        bir kez duyurulur; son eşikten sonra işaret silinir ve menü bir
        daha daralmaz. Gizlenen yer sayısı söylenir ki öğrenci ne
        kaçırdığını değil, ne beklediğini bilsin.
        """
        d = self.durum
        if not d.ayarlar.get("kademeli_menu"):
            self._kilitli_anahtarlar = []
            return anahtarlar
        n = d.oynanan_gorev
        acik = [k for k in anahtarlar if KADEMELI_ACILIS.get(k, 0) <= n]
        duyurulan = list(d.ayarlar.get("acilan_yerler") or [])
        yeniler = [k for k in acik
                   if k in KADEMELI_ACILIS and k not in duyurulan]
        for k in yeniler:
            ekran.yaz("{} Raporların üste yeni bir kapı açtı: {} ({})".format(
                S["ok"], ogeler[k][0], ogeler[k][1]), "acik_yesil")
            d.gunluk_ekle("Yeni yer açıldı: " + ogeler[k][0])
            duyurulan.append(k)
        if yeniler:
            # Meridyen OS: yazılım güncellemesi gibi görünür (sürüm = ilerleme).
            from . import arsiv
            surum = os_surumu(n)
            yer_adlari = [ogeler[k][0] for k in yeniler]
            ekran.baglam("guncelleme", surum=surum,
                         yerler=[{"anahtar": k, "ad": ogeler[k][0]}
                                 for k in yeniler])
            arsiv.posta(d, "Üs Bilgisayarı",
                        "Meridyen OS {} güncellemesi".format(surum),
                        "Yüklendi: {}.\n{}".format(
                            ", ".join(yer_adlari),
                            " ".join(ogeler[k][1] + "." for k in yeniler)),
                        "guncelleme:" + surum)
        kapali = len(anahtarlar) - len(acik)
        self._kilitli_anahtarlar = [k for k in anahtarlar if k not in acik]
        if kapali:
            ekran.yaz("Üste {} yer daha var; görev raporladıkça açılacak."
                      .format(kapali), "gri")
            d.ayarlar["acilan_yerler"] = duyurulan
        else:
            d.ayarlar.pop("kademeli_menu", None)
            d.ayarlar.pop("acilan_yerler", None)
        if yeniler or not kapali:
            d.kaydet()
        return acik

    # ------------------------------------------------------------- konu çalış
    def _konu_durum_etiketi(self, konu_durumu) -> Tuple[str, str, str]:
        """(kutu, etiket, renk) - konu haritasındaki durum sütunu."""
        if konu_durumu.tamamlandi:
            return "[{}]".format(S["onay"]), "oturdu", "acik_yesil"
        if not konu_durumu.baslanmis:
            return "[ ]", "yeni", "gri"
        if konu_durumu.asama == ANLATIM:
            return "[1]", "anlatım", "acik_cam"
        if konu_durumu.asama == BIRLIKTE:
            return "[2]", "birlikte", "acik_sari"
        return "[3]", "kendi", "acik_mavi"

    def _onerilen_konu(self, ders: str, konu_listesi) -> str:
        """
        Sıradaki konu: önce yarım kalanlar, sonra hiç başlanmamışlar.

        Amaç öğrenciyi seçim yapmak zorunda bırakmamak; "nereden devam
        edeceğimi bilmiyorum" en sık takılma sebebi.
        """
        ders_durumu = self.durum.ders(ders)
        yarim = [k for k in konu_listesi
                 if ders_durumu.konu(k).baslanmis and not ders_durumu.konu(k).tamamlandi]
        if yarim:
            return min(yarim, key=lambda k: ders_durumu.konu(k).ustalik)
        yeni = [k for k in konu_listesi if not ders_durumu.konu(k).baslanmis]
        if yeni:
            return yeni[0]
        return min(konu_listesi, key=lambda k: ders_durumu.konu(k).ustalik)

    def _acik_yollar(self) -> List[str]:
        """
        Oyuncunun bulunduğu zorlukta gerçekten iş çıkan yollar.

        Kapalı bir masayı listede göstermek öğrenciyi boş bir kapıya yollamak
        olur: Keşif düzeyindeki bir çocuk meslek dersi masasına oturamaz,
        oturursa da eline yaşına uymayan bir dosya geçer.
        """
        merkez = ZORLUK_KADEME[self.durum.zorluk]
        acik = []
        for yol in OGRENME_YOLLARI:
            if any(kademede_acik_mi(alan, merkez) for alan in yol_alanlari(yol)):
                acik.append(yol)
        return acik

    def _acik_konular(self, yol: str,
                      yalniz_alan: str = "") -> List[Tuple[str, str]]:
        """
        Bir yolda, oyuncunun zorluğunda gerçekten üretilebilen (alan, konu)
        çiftleri. Listede görünen her iş açılabilmelidir.

        `yalniz_alan` verilirse yalnızca o alan listelenir; meslek yolunda
        öğrenci kendi dalını seçtiğinde kullanılır.
        """
        merkez = ZORLUK_KADEME[self.durum.zorluk]
        alanlar = [yalniz_alan] if yalniz_alan else yol_alanlari(yol)
        cift: List[Tuple[str, str]] = []
        for alan in alanlar:
            for konu in konular(alan):
                if kademede_acik_mi(alan, merkez, konu=konu):
                    cift.append((alan, konu))
        return cift

    def _acik_dallar(self, yol: str) -> List[str]:
        """Bu yolda, oyuncunun zorluğunda işi olan alanlar."""
        merkez = ZORLUK_KADEME[self.durum.zorluk]
        return [a for a in yol_alanlari(yol) if kademede_acik_mi(a, merkez)]

    def _dal_sec(self, yol: str) -> Optional[str]:
        """
        Meslek yolunda hangi bölümde çalışılacağını sorar ve hatırlar.

        Akademik yollarda ders adı gösterilmez - orada karışık liste bilerek
        böyledir. Ama meslek dalı öğrencinin KENDİ bölümüdür; dört bölümün
        işini tek listede karıştırmak, marangozu bilişim konuları arasında
        gezdirmek olur.
        """
        dallar = self._acik_dallar(yol)
        if len(dallar) <= 1:
            return dallar[0] if dallar else None
        if self.durum.dal in dallar:
            return self.durum.dal

        secenekler = [(DERS_ADLARI[a], "{} iş".format(
            len(self._acik_konular(yol, a)))) for a in dallar]
        secenekler.append(("Geri dön", ""))
        self._ust_pano()
        ekran.yaz("HANGİ BÖLÜMDESİN?", "kalin", "acik_cam")
        ekran.yaz("Bir kez soruyorum; bundan sonra doğrudan kendi masana "
                  "oturacaksın. Ayarlardan değiştirebilirsin.", "gri")
        secim = ekran.menu("", secenekler)
        if secim >= len(dallar):
            return None
        self.durum.dal = dallar[secim]
        self.durum.kaydet()
        return self.durum.dal

    def _konu_calis(self) -> None:
        secenekler = []
        yol_kodlari = self._acik_yollar()
        if not yol_kodlari:
            ekran.hata("Bu zorlukta açık masa yok. Ayarlardan zorluğu "
                       "değiştirebilirsin.")
            ekran.bekle()
            return
        for yol in yol_kodlari:
            bilgi = OGRENME_YOLLARI[yol]
            toplam = oturmus = 0
            for alan, konu in self._acik_konular(yol):
                toplam += 1
                oturmus += int(self.durum.ders(alan).konu(konu).tamamlandi)
            secenekler.append((bilgi["ad"], "{} iş var; {} tanesi elinde".format(
                toplam, oturmus)))
        secenekler.append(("Geri dön", ""))

        self._ust_pano()
        ekran.yaz("USTA ÇADIRI", "kalin", "acik_cam")
        ekran.yaz("Burada bir işi önce izlersin, sonra yanında dururum, en "
                  "sonunda tek başına yaparsın.", "gri")
        secim = ekran.menu("Hangi masaya oturalım?", secenekler)
        if secim >= len(yol_kodlari):
            return
        self._yol_haritasi(yol_kodlari[secim])

    def _yol_haritasi(self, yol: str) -> None:
        """Ders adlarını göstermeden bir öğrenme yolundaki bütün konuları sunar."""
        # Meslek yolu istisnadır: orada dört bölümün işi tek listede
        # karışmasın diye önce dal sorulur. Bkz. _dal_sec.
        if secmeli_yol_mu(yol):
            dal = self._dal_sec(yol)
            if dal is None:
                return
            self._konu_haritasi(dal)
            return

        while True:
            paketler = [(alan, konu, self.durum.ders(alan).konu(konu))
                        for alan, konu in self._acik_konular(yol)]
            if not paketler:
                ekran.hata("Bu masada senin zorluğunda şimdilik iş yok. "
                           "Ayarlardan zorluğu değiştirmeyi deneyebilirsin.")
                ekran.bekle()
                return
            self._ust_pano()
            ekran.yaz("USTA ÇADIRI - {}".format(OGRENME_YOLLARI[yol]["ad"]),
                      "kalin", "acik_cam")
            ekran.yaz(OGRENME_YOLLARI[yol]["aciklama"], "gri")
            ekran.yaz()
            ekran.yaz("{:<12}{:<34}{}".format("DURUM", "İŞ", "ELİN ALIŞTI MI"), "gri")
            for alan, konu, kd in paketler:
                kutu, etiket, renk = self._konu_durum_etiketi(kd)
                ilerleme_metni = ("%{}".format(int(round(kd.ustalik * 100)))
                                  if kd.serbest_toplam else "-")
                satir = "{} {:<9}{:<34}{}".format(
                    kutu, etiket, konu_etiketi(self.durum, alan, konu)[:33], ilerleme_metni)
                ekran.ham_yaz("  " + ekran.renkli(satir, renk))
            yarim = [p for p in paketler if p[2].baslanmis and not p[2].tamamlandi]
            yeni = [p for p in paketler if not p[2].baslanmis]
            aday = (min(yarim, key=lambda p: p[2].ustalik) if yarim else
                    (yeni[0] if yeni else min(paketler, key=lambda p: p[2].ustalik)))
            secim = ekran.menu("", [
                ("Kaldığın yerden devam et", konu_etiketi(self.durum, aday[0], aday[1])),
                ("Listeden seç", ""), ("Geri dön", "")])
            if secim == 0:
                self._konu_akisi(aday[0], aday[1])
            elif secim == 1:
                alt = ekran.menu("İş:", [konu_etiketi(self.durum, p[0], p[1]) for p in paketler]
                                 + ["Vazgeç"])
                if alt < len(paketler):
                    self._konu_akisi(paketler[alt][0], paketler[alt][1])
            else:
                return

    def _konu_haritasi(self, ders: str) -> None:
        """Tek bir alanın konu haritası. Meslek dalları buradan çalışılır."""
        while True:
            # Yalnızca bu zorlukta gerçekten üretilebilen konular listelenir;
            # açılamayacak bir işi listede göstermek öğrenciyi boş kapıya
            # yollamaktır.
            konu_listesi = [k for _a, k in self._acik_konular(
                alan_yolu(ders), yalniz_alan=ders)]
            if not konu_listesi:
                ekran.hata("Bu masada senin zorluğunda şimdilik iş yok. "
                           "Ayarlardan zorluğu değiştirmeyi deneyebilirsin.")
                ekran.bekle()
                return

            ders_durumu = self.durum.ders(ders)
            self._ust_pano()
            ekran.yaz("KONU HARİTASI - {}".format(DERS_ADLARI[ders]),
                      "kalin", DERS_RENGI.get(ders, "acik_cam"))
            ortaklik = ittifak.ortaklik_satiri(ders, ders_durumu.kademe)
            if ortaklik:
                ekran.yaz(ortaklik, "acik_mor")
            ekran.yaz()
            ekran.yaz("{:<12}{:<26}{}".format("DURUM", "İŞ", "ELİN ALIŞTI MI"),
                      "gri")

            for konu_kodu in konu_listesi:
                konu_durumu = ders_durumu.konu(konu_kodu)
                kutu, etiket, renk = self._konu_durum_etiketi(konu_durumu)
                if konu_durumu.serbest_toplam:
                    ilerleme_metni = "{} %{}".format(
                        ekran.cubuk(konu_durumu.ustalik, 1.0, 10),
                        int(round(konu_durumu.ustalik * 100)))
                else:
                    ilerleme_metni = "-"
                satir = "{} {:<9}{:<26}{}".format(
                    kutu, etiket, konu_etiketi(self.durum, ders, konu_kodu)[:25], ilerleme_metni)
                ekran.ham_yaz("  " + ekran.renkli(satir, renk))

            ekran.yaz()
            ekran.yaz("[ ] hiç başlanmadı   [1] anlatım sırası   "
                      "[2] birlikte   [3] kendi başına   [{}] oturdu".format(S["onay"]),
                      "gri")

            onerilen = self._onerilen_konu(ders, konu_listesi)
            meslek_dali = secmeli_yol_mu(alan_yolu(ders))
            secenekler = [
                ("Kaldığın yerden devam et", konu_etiketi(self.durum, ders, onerilen)),
                ("Listeden seç", ""),
            ]
            if meslek_dali:
                secenekler.append(("Başka bölüme geç", ""))
            secenekler.append(("Geri dön", ""))

            secim = ekran.menu("", secenekler)
            if secim == 0:
                self._konu_akisi(ders, onerilen)
            elif secim == 1:
                alt = ekran.menu("İş:", [konu_etiketi(self.durum, ders, k) for k in konu_listesi]
                                 + ["Vazgeç"])
                if alt < len(konu_listesi):
                    self._konu_akisi(ders, konu_listesi[alt])
            elif meslek_dali and secim == 2:
                # Dalı unutup yeniden sorduruyoruz: bölüm değiştiren ya da
                # başka bölümün işine bakmak isteyen öğrenci için.
                self.durum.dal = ""
                return
            else:
                return

    def _konu_akisi(self, ders: str, konu_kodu: str) -> None:
        """
        Bir konuyu, bulunduğu aşamadan başlayarak çalıştırır.

        Aşama ilerlerse aynı oturumda devam teklif edilir: öğrenci anlatımı
        izledikten hemen sonra birlikte çözmeye, onu da geçince tek başına
        denemeye geçebilir. Akış tek oturumda tamamlanabilir ama zorunlu değil.
        """
        ders_durumu = self.durum.ders(ders)

        # Meslek dallarında, bu masadaki işin hangi başka bölümle ortak
        # olduğunu bir kez söylüyoruz. İttifak özelliği açıldığında bu satır
        # eşleşmenin giriş kapısı olacak. Bkz. TASARIM_NOTLARI.md §4
        ortaklik = ittifak.ortaklik_satiri(ders, ders_durumu.kademe)
        if ortaklik:
            ekran.yaz()
            ekran.yaz(ortaklik, "acik_mor", girinti="  ")

        while True:
            konu_durumu = ders_durumu.konu(konu_kodu)
            asama = konu_durumu.asama

            bulmaca = uret(
                ders=ders,
                kademe=ders_durumu.kademe,
                rastgele=self.durum.rastgele("konu-{}-{}".format(konu_kodu, asama)),
                konu=konu_kodu,
            )
            if bulmaca is None:
                ekran.hata("Bu konu için görev üretilemedi.")
                ekran.bekle()
                return

            oturum = Oturum(
                bulmaca,
                oyuncu_adi=self.durum.goruntu_adi,
                ipucu_acik=bool(self.durum.ayarlar.get("ipucu_acik", True)),
                durum=self.durum,
                asama=asama,
            )
            sonuc = oturum.oyna()

            if asama == SERBEST:
                sonucu_ozetle(bulmaca, sonuc)
                self.durum.kaynak_ekle({a: -m for a, m in GOREV_BEDELI.items()})
                if not sonuc.birakildi:
                    self.durum.kaynak_ekle(self._odulu_hesapla(bulmaca, sonuc))

            onceki_asama = asama
            bildirimler = ilerleme.sonucu_isle(
                self.durum, sonuc, uretici_adi=getattr(bulmaca, "uretici_adi", ""))
            if bildirimler:
                ekran.yaz()
                for satir in bildirimler:
                    ekran.yaz(S["ok"] + " " + satir, "acik_mor", "kalin")

            self._ilerleme_sonrasi()
            self.durum.kaydet()

            if sonuc.birakildi:
                ekran.bekle()
                return

            yeni_asama = ders_durumu.konu(konu_kodu).asama
            if yeni_asama != onceki_asama:
                soru = {
                    BIRLIKTE: "Şimdi aynısını birlikte çözelim mi?",
                    SERBEST: "Tek başına denemek ister misin?",
                }.get(yeni_asama, "Devam edelim mi?")
                if not ekran.onayla(soru, True):
                    return
                continue

            # Aşama değişmedi: aynı düzeyde bir tur daha ister mi?
            ekran.yaz()
            if not ekran.onayla("Bu işten bir tane daha ister misin?", False):
                return

    # ------------------------------------------------------------ görev panosu
    def _pano_baglami(self, zaman=None):
        try:
            program = ders_programi.ogrenci_programi(self.durum)
            satir, aciklama = ders_programi.ders_odagi(program, zaman)
            return program, satir, aciklama
        except (OSError, ValueError) as sorun:
            return None, None, "Ders programı okunamadı: {}".format(sorun)

    @staticmethod
    def _baglam_anahtari(baglam):
        return json.dumps(baglam, sort_keys=True, ensure_ascii=False)

    def _teklif_uret(self, adet: int = 3, zaman=None) -> List[Bulmaca]:
        """
        Panoya konacak görevleri seçer.
        Okul programı varsa o ders/konu; yoksa uyarlanır serbest keşif.
        """
        rastgele = self.durum.rastgele("pano-{}".format(self.pano_sayaci))
        baglam = self._pano_baglami(zaman)
        self._teklif_baglami = self._baglam_anahtari(baglam)
        program, satir, aciklama = baglam
        self.odak_uyarisi = ""
        if program is None:
            self.odak_uyarisi = aciklama
            return []
        if satir is not None:
            teklifler, self.odak_uyarisi = ders_programi.odakli_teklifler(
                self.durum, program, satir, rastgele, adet)
            return teklifler
        dersler = self.durum.aktif_dersler()
        if not dersler or adet <= 0:
            return []
        secilenler: List[Bulmaca] = []
        kullanilan_ders: List[str] = []
        denemeler = 0
        while len(secilenler) < adet and denemeler < 40:
            denemeler += 1
            havuz = [d for d in dersler if d not in kullanilan_ders] or dersler
            ders = rastgele.choice(havuz)
            oneriler, _ = ders_programi.odakli_teklifler(
                self.durum, program,
                {"ders": ders, "ad": DERS_ADLARI[ders], "konular": []}, rastgele, 1)
            if not oneriler:
                kullanilan_ders.append(ders)
                continue
            bulmaca = oneriler[0]
            secilenler.append(bulmaca)
            kullanilan_ders.append(ders)
        return secilenler

    def _gorev_panosu(self) -> None:
        while True:
            baglam = self._pano_baglami()
            if self._teklif_baglami != self._baglam_anahtari(baglam):
                self.teklifler = []
            if not self.teklifler:
                self.teklifler = self._teklif_uret()
            self._ust_pano()
            ekran.yaz("KOMUTA MASASI", "kalin", "acik_cam")
            ekran.yaz("Mühürlü görev dosyaları önünde duruyor. Birini seçtiğinde "
                      "dosyanın ayrıntıları açılacak.", "gri")
            program, satir, aciklama = baglam
            if satir:
                ekran.yaz("{}: {} ({}–{})".format(
                    aciklama, satir["ad"], satir["baslangic"], satir["bitis"]), "acik_cam")
                ekran.yaz("Seçili konulardan görevler" + (
                    "; aynı dersten kısa pekiştirme." if not program["tam_odak"]
                    else "; tam konu odağı."), "gri")
            else:
                ekran.yaz(aciklama, "gri")
            if self.odak_uyarisi:
                ekran.yaz(self.odak_uyarisi, "acik_sari")

            if not self.teklifler:
                ekran.bilgi("Bu odak için görev yok. Programı gözden geçirebilir "
                            "veya Usta Çadırı'ndan başka bir çalışmayı kendin seçebilirsin.")
                ekran.bekle()
                return

            secenekler = []
            for bulmaca in self.teklifler:
                renk = DERS_RENGI.get(bulmaca.ders, "beyaz")
                baslik = "{}  {}".format(
                    ekran.renkli(bulmaca.baslik, renk, "kalin"),
                    ekran.renkli("[Zorluk {} - {}]".format(
                        kademe_zorlugu(bulmaca.kademe),
                        ZORLUK_ADLARI[kademe_zorlugu(bulmaca.kademe)]), "gri"))
                odul_metni = self._odul_metni(bulmaca.odul)
                secenekler.append((baslik, "Dikkat {}  {}  Ödül: {}".format(
                    bulmaca.dikkat, S["dikey"], odul_metni)))
            secenekler.append(("Haberciyi geri gönder", "başka görev dosyaları getir"))
            secenekler.append(("Masadan ayrıl", ""))

            secim = ekran.menu("", secenekler)
            if secim == len(self.teklifler):
                self.teklifler = []
                self.pano_sayaci += 1
                continue
            if secim == len(self.teklifler) + 1:
                return

            if self._teklif_baglami != self._baglam_anahtari(self._pano_baglami()):
                self.teklifler = []
                ekran.bilgi("Ders odağı değişti; güncel görev dosyaları getiriliyor.")
                continue

            bulmaca = self.teklifler.pop(secim)
            if not self._gorev_dosyasi(bulmaca):
                continue
            if self._teklif_baglami != self._baglam_anahtari(self._pano_baglami()):
                self.teklifler = []
                ekran.bilgi("Ders odağı değişti; güncel görev dosyaları getiriliyor.")
                continue
            self._gorevi_oyna(bulmaca)
            self.teklifler = []
            return

    def _odul_metni(self, odul) -> str:
        # B36.13: itibar ARALIK olarak yaziliyor. Alt ucu katilim (her
        # tamamlanan gorevde ayni), ust ucu 3 yildizla gelen. Eskiden icerigin
        # yazdigi sayi aynen yaziliyordu; oysa 0 yildizda 1, 3 yildizda 7
        # veriliyordu -- dosyadaki sayi hicbir sonucla tutmuyordu.
        en_cok = KATILIM_ITIBARI + yildiz_itibar_eki(odul, 3)
        parcalar = ["İtibar {}-{}".format(KATILIM_ITIBARI, en_cok)]
        parcalar += ["{} +{}".format(KAYNAK_ADLARI.get(k, k), v)
                     for k, v in (odul or {}).items() if k != "itibar"]
        return ", ".join(parcalar)

    def _gorev_dosyasi(self, bulmaca: Bulmaca) -> bool:
        """Göreve girmeden önce kısa risk/ödül dosyası gösterir."""
        ekran.temizle()
        ekran.baslik("GÖREV DOSYASI: " + ekran.tr_buyuk(bulmaca.baslik),
                      "kalin", "acik_sari")
        zorluk = kademe_zorlugu(bulmaca.kademe)
        ekran.yaz()
        ekran.kutu(
            "Zorluk: {} - {}\n"
            "Elindeki dikkat: {}/{}\n"
            "Operasyon gideri: {} Enerji\n"
            "Tahmini ödül: {}".format(
                zorluk, ZORLUK_ADLARI[zorluk],
                # `bulmaca.dikkat` ESKI: gorev basina dikkatti ve artik
                # kullanilmiyor -- dikkat kalici bir havuz oldu. Burada onu
                # yazmak yalan soyluyordu: dosyada "Dikkat butcesi: 5",
                # oyunda "Dikkat: 100/100" gorunuyordu (8 Eylul testi).
                self.durum.dikkati_hazirla(), self.durum.dikkat_tavani(),
                GOREV_BEDELI.get("enerji", 0),
                self._odul_metni(bulmaca.odul)),
            "KOMUTANIN NOTU", "beyaz")
        ekran.yaz("Dosyanın olay ayrıntıları sahaya çıktığında açılacak.", "gri")
        return ekran.onayla("Görevi kabul ediyor musun?", True)

    def _serbest_calisma(self) -> None:
        self._ust_pano()
        ekran.yaz("SERBEST ÇALIŞMA", "kalin", "acik_cam")
        ekran.yaz("İstediğin dersten, istediğin kademede görev çek. "
                  "Karneye işlenir ama zorluk otomatik değişmez.", "gri")

        dersler = self.durum.aktif_dersler()
        ders_secenekleri = []
        for ders in dersler:
            adet = len(uygun_kayitlar(ders=ders))
            ders_secenekleri.append((DERS_ADLARI[ders], "{} görev tipi".format(adet)))
        ders_secenekleri.append(("Geri dön", ""))
        secim = ekran.menu("Ders:", ders_secenekleri)
        if secim >= len(dersler):
            return
        ders = dersler[secim]

        varsayilan = self.durum.ders(ders).kademe
        ham = ekran.sor("Kademe (1-13, Enter = {}):".format(varsayilan), str(varsayilan))
        try:
            kademe = max(1, min(13, int(ham)))
        except ValueError:
            kademe = varsayilan

        bulmaca = uret(ders=ders, kademe=kademe, rastgele=self.durum.rastgele("serbest"))
        if bulmaca is None:
            ekran.hata("Bu ders için henüz içerik yok.")
            ekran.bekle()
            return
        self._gorevi_oyna(bulmaca, serbest=True)

    # ---------------------------------------------------------------- oynatma
    def _gorevi_oyna(self, bulmaca: Bulmaca, serbest: bool = False):
        # Dikkat tavani ustalikla degisiyor (durum.dikkat_tavani).
        # Ogrenciye SOYLENMEZSE sayi kendiliginden oynuyor gibi durur
        # ve sistem keyfi gorunur. Gorev oncesi/sonrasi karsilastiriyoruz.
        # Meridyen OS: ilk gorev ana menuden ONCE geliyor; ust cubuk bos
        # kalmasin diye pano her gorev basinda da bildirilir.
        if ekran.olayli():
            self._pano_olayi()
        onceki_tavan = self.durum.dikkat_tavani()
        oturum = Oturum(
            bulmaca,
            oyuncu_adi=self.durum.goruntu_adi,
            ipucu_acik=bool(self.durum.ayarlar.get("ipucu_acik", True)),
                durum=self.durum,
        )
        sonuc = oturum.oyna()
        sonucu_ozetle(bulmaca, sonuc)

        self.durum.kaynak_ekle({a: -m for a, m in GOREV_BEDELI.items()})

        if sonuc.birakildi:
            self.durum.gunluk_ekle("{} görevinden çekildi.".format(bulmaca.baslik))
        else:
            # Dikkat dolumu gorevin ZORLUGUNA bagli: zor gorev daha cok geri
            # verir. Gercek zamana degil goreve bagli -- gercek zamana
            # baglanirsa beklemek odullendirilir ve 40 dakikalik ders
            # saatinde ise yaramaz. Bkz. durum.DIKKAT_DOLUM.
            # Zorlandiysa merdiven teklif et. TEKLIF, dayatma degil:
            # ogrenci "hayir" diyebilmeli, yoksa yardim bir cezaya donusur.
            self._merdiven_teklif_et(bulmaca, sonuc)

            kazanilan = self.durum.dikkat_ekle(kademe_zorlugu(bulmaca.kademe))
            yeni_tavan = self.durum.dikkat_tavani()
            if kazanilan:
                ekran.yaz()
                ekran.yaz("Dikkatin {} arttı ({}/{}).".format(
                    kazanilan, self.durum.dikkat, yeni_tavan), "acik_yesil")
            if yeni_tavan > onceki_tavan:
                # Yeni konu acildi: oturmus oran dustu, tavan yukseldi.
                ekran.yaz()
                ekran.yaz("Yeni konular açıldı; dikkat sınırın {} oldu ({} idi). "
                          "Tanımadığın konularda daha çok bakmaya hakkın var.".format(
                              yeni_tavan, onceki_tavan), "acik_cam")
            elif yeni_tavan < onceki_tavan:
                # Konu oturdu: artik daha az desteğe ihtiyaci var (§0'in tersi).
                ekran.yaz()
                ekran.yaz("Bir konu daha oturdu; dikkat sınırın {} oldu ({} idi). "
                          "Artık daha az bakman yetiyor.".format(
                              yeni_tavan, onceki_tavan), "acik_yesil")
            uygulanan = self.durum.kaynak_ekle(self._odulu_hesapla(bulmaca, sonuc))
            self.durum.gunluk_ekle("{} tamamlandı ({}/{} puan).".format(
                bulmaca.baslik, sonuc.puan, sonuc.azami_puan))
            if uygulanan:
                ekran.yaz()
                ekran.yaz("Üsse kazandırdıkların:", "kalin")
                for anahtar, miktar in uygulanan.items():
                    if miktar:
                        ekran.madde("{} {}{}".format(
                            KAYNAK_ADLARI.get(anahtar, anahtar),
                            "+" if miktar > 0 else "", miktar), "acik_sari")
                # B36.13: itibarin hangi kismi gorevi bitirmekten, hangi
                # kismi yildizdan geldi. Ogrenci kapinin (zaman seferi)
                # puana degil katilima bagli oldugunu gorsun.
                ekran.yaz(self._itibar_satiri(bulmaca, sonuc), "gri")
            self._tesis_turu()
            self._siber_olayi()

        onceki_kademe = {d: self.durum.ders(d).kademe for d in DERSLER}
        bildirimler = ilerleme.sonucu_isle(
            self.durum, sonuc, uretici_adi=getattr(bulmaca, "uretici_adi", ""))

        if serbest:
            # Serbest çalışmada kademe otomatik değişmesin: geri al.
            for ders, kademe in onceki_kademe.items():
                self.durum.ders(ders).kademe = kademe
            bildirimler = [b for b in bildirimler if "kademe" not in b.lower()]

        if bildirimler:
            ekran.yaz()
            for satir in bildirimler:
                ekran.yaz(S["ok"] + " " + satir, "acik_mor", "kalin")

        self._ilerleme_sonrasi()

        self.durum.kaydet()
        ekran.bekle()
        return sonuc

    def _geri_bildirim(self) -> None:
        """Oyuncunun notunu ve ilerleme kayitlarini tek zip'e koyar.

        Deneme surumunu birine verip "nasil gitti?" diye sordugunda gelen
        cevap genelde "guzeldi" olur; ise yarayan sey NEREDE takildigini
        gosteren kayit dosyasidir. Ama kimseden "kayitlar klasorunu bul ve
        zip'le" denmesi beklenemez.

        Ne koyulduğu paket OLUSTURULMADAN once ekranda listeleniyor.
        Birinden dosya istiyorsan ne istedigini gostereceksin.
        """
        from araclar import geri_bildirim as gb

        ekran.temizle()
        ekran.baslik("GERİ BİLDİRİM", "kalin", "acik_cam")
        ozet = gb.icerik_ozeti(self.durum.kimlik())
        ekran.yaz()
        ekran.kutu(
            "Ne düşündüğünü yaz; oyun bunu ilerleme kayıtlarınla birlikte "
            "tek bir dosyaya koyar. Dosyayı sen gönderirsin — oyun hiçbir "
            "şeyi kendiliğinden yollamaz.",
            "NASIL ÇALIŞIR", "beyaz")
        ekran.yaz()
        ekran.yaz("PAKETE GİRECEKLER", "kalin")
        ekran.madde("yazdığın not", "acik_cam")
        for satir in ozet["kayitlar"]:
            ekran.madde("ilerleme kaydı: " + satir, "acik_cam")
        if ozet.get("hata_sayisi"):
            ekran.madde("{} hata kaydı: oyunun beklenmeyen bir sorunla "
                        "karşılaştığı anlar. O an yazdığın bir cevabın "
                        "parçasını içerebilir.".format(ozet["hata_sayisi"]),
                        "acik_cam")
        ekran.madde("sürüm bilgisi: " + ozet["ortam"], "acik_cam")
        ekran.yaz()
        ekran.yaz("Başka hiçbir şey: bilgisayarında dosya aranmaz, hiçbir "
                  "şey ağa gönderilmez.", "gri")
        ekran.ayrac()

        ekran.yaz()
        ekran.yaz("Notunu yaz. Bitince BOŞ satırda Enter'a bas.", "acik_sari")
        ekran.yaz("En çok yardımı dokunan şey: nerede takıldığın ve hangi "
                  "soruyu 'ders sorusu' diye hissettiğin.", "gri")
        satirlar = []
        while True:
            satir = ekran.sor("", "")
            if not satir.strip():
                break
            satirlar.append(satir)
        metin = chr(10).join(satirlar)
        if not metin.strip():
            ekran.bilgi("Bir şey yazmadın; paket oluşturulmadı.")
            ekran.bekle()
            return

        yol, mesaj = gb.paket_olustur(metin, self.durum.ad,
                                      yalnizca_kimlik=self.durum.kimlik())
        ekran.yaz()
        if yol is None:
            ekran.hata(mesaj)
        else:
            ekran.basari(mesaj)
            ekran.yaz()
            ekran.kutu(yol, "BU DOSYAYI GÖNDER", "acik_yesil")
        ekran.bekle()

    @staticmethod
    def _odulu_hesapla(bulmaca, sonuc) -> dict:
        """Gorev odulu, yildiz carpaniyla ama BEDEL TABANIYLA.

        §0 IHLALI DUZELTMESI (5 Eylul 2026). `YILDIZ_CARPANI` odulu 0,2x ile
        1,4x arasinda olcekliyor. Harcanacak yer yokken bu zararsizdi; sefer
        bedeli eklenince gercek bir kapiya donustu. Olculdu: gorev basina
        ortalama enerji odulu ~1,3, bedel 1. Yani

            0 yildiz -> net -0,74      1 yildiz -> net -0,22
            2 yildiz -> net +0,30      3 yildiz -> net +0,82

        Zorlanan ogrencinin enerjisi her gorevde AZALIYORDU; yani oyunun en
        ozgun icerigi (zaman seferi) ona kalici olarak kapaliydi. Bu, §0'in
        "zorlanmanin bedeli ceza degil, destegin artmasidir" ilkesinin tam
        tersi -- zorlanan ogrenci cezalandiriliyordu.

        Kural: TAMAMLANAN BIR GOREV EN AZINDAN KENDI BEDELINI ODER. Yildiz
        hala fark yaratiyor (fazlasi icin), ama kimse geriye gitmiyor.

        ITIBAR AYRI (B36.13, 29 Eylul 2026): yildiz carpani itibara
        uygulanmiyor. Itibar = KATILIM_ITIBARI (her tamamlanan gorevde ayni)
        + yildiz eki. Bkz. `itibar_dokumu`.
        """
        carpan = YILDIZ_CARPANI.get(sonuc.yildiz, 1.0)
        odul = {a: int(round(m * carpan))
                for a, m in (bulmaca.odul or {}).items() if a != "itibar"}
        katilim, ek = Oyun.itibar_dokumu(bulmaca, sonuc)
        odul["itibar"] = katilim + ek
        for anahtar, bedel in GOREV_BEDELI.items():
            odul[anahtar] = max(odul.get(anahtar, 0), bedel)
        return odul

    @staticmethod
    def itibar_dokumu(bulmaca, sonuc) -> Tuple[int, int]:
        """(katilim, yildiz_eki): tamamlanan gorevin itibar odulunun iki parcasi.

        Katilim sabit ve yildizdan bagimsiz: zaman seferi kapisini acan kisim
        bu. Yildiz eki icin bkz. `yildiz_itibar_eki`.
        """
        return KATILIM_ITIBARI, yildiz_itibar_eki(bulmaca.odul, sonuc.yildiz)

    @staticmethod
    def _itibar_satiri(bulmaca, sonuc) -> str:
        katilim, ek = Oyun.itibar_dokumu(bulmaca, sonuc)
        # Sayiya ek getirmemek icin iki nokta ile yaziliyor (4'u, 2'si ...).
        if ek:
            return ("İtibar: görevi tamamladığın için {}, yıldızların "
                    "için +{}.".format(katilim, ek))
        return "İtibar: görevi tamamladığın için {}.".format(katilim)

    def _merdiven_teklif_et(self, bulmaca, sonuc) -> None:
        """Zorlanan ogrenciye ayni konudan basamakli alistirma onerir.

        Bugune kadar takilan ogrenciye "bu konuya bir daha bak" deniyordu
        ama NEREYE bakacagi soylenmiyordu. Merdiven o boslugu dolduruyor.
        """
        gb = degerlendirme.gorev_geri_bildirimi(bulmaca, sonuc)
        if not gb.get("zorlandi"):
            return
        # Yalnizca gercekten takildiysa: tek ipucu almak merdiven gerektirmez.
        if gb.get("zorlanan_adim", 0) < 1:
            return
        konu = getattr(bulmaca, "konu", "")
        if not konu:
            return
        ekran.yaz()
        if not ekran.onayla(
                "Bu konuyu basitten başlayarak adım adım çalışalım mı?", True):
            return
        from . import merdiven
        merdiven.merdiveni_oyna(self.durum, bulmaca.ders, konu, bulmaca.kademe)

    # ------------------------------------------------------------ zaman seferi
    def _zaman_seferi(self) -> None:
        """
        Tek kurgunun içinde birden çok dersi dolaştıran görev zinciri.

        Derslerin birbirinden kopuk olmadığını gösteren yer burasıdır: aynı
        olayın tarihi, coğrafyası, hesabı ve anlatımı arka arkaya gelir.
        """
        kayitlar = sefer_kayitlari()
        if not kayitlar:
            ekran.hata("Henüz kayıtlı zaman seferi yok.")
            ekran.bekle()
            return

        gorulen = list(self.durum.ayarlar.get("gorulen_seferler") or [])
        kademe = int(round(self.durum.ortalama_kademe))
        sefer_nesnesi = sefer_uret(
            kademe=kademe,
            rastgele=self.durum.rastgele("sefer-{}".format(len(gorulen))),
            haric=gorulen,
        )
        if sefer_nesnesi is None:
            ekran.hata("Bu zorluk için zaman seferi üretilemedi.")
            ekran.bekle()
            return

        ekran.temizle()
        ekran.baslik(ekran.tr_buyuk(sefer_nesnesi.baslik), "kalin", "acik_mor")
        ekran.yaz()
        ekran.yaz(sefer_nesnesi.donem, "gri")
        ekran.yaz("Bu seferde çağı, yeri, hesabı ve raporu birbirine bağlayacaksın.",
                  "acik_cam")
        ekran.yaz()
        ekran.kutu(sefer_nesnesi.giris, "KRONOGRAF", "beyaz")
        ekran.yaz()
        ekran.yaz("Sefer bedeli: " + self._bedel_metni(SEFER_BEDELI), "acik_sari")
        if not ekran.onayla("Sefere çıkalım mı?", True):
            return
        # Bedel sefer BASLAMADAN once odenir. Yarida birakilirsa TAMAMLANMAYAN
        # bolumlerin payi geri verilir (B36.14, kullanici karari 29 Eylul
        # 2026). Eskiden hicbir sey geri verilmiyordu ("sefer icerigi zaten
        # gorulmus oluyor"); ama 40 dakikalik ders saatinde zil calan ya da
        # bir bolumde takilip birakan ogrenci 12 itibari -- yani 3 gorevlik
        # emegini -- toptan kaybediyordu. Zorlanmanin bedeli ceza olmamali
        # (§0). Istismar yok: iade odenenden fazla olamaz ve ASAGI yuvarlanir
        # (bkz. `sefer_iadesi`); baslat-birak dongusu kaynak uretmez.
        if not self._bedeli_ode(SEFER_BEDELI, "Zaman seferi"):
            return

        tamamlandi = True
        sefer_sonuclari = []
        toplam_bolum = len(sefer_nesnesi.bolumler)
        # Odenen bedel ve ilerleme KAYDA yaziliyor (bkz. `_sefer_iadesini_ver`).
        # Isaret varken iade verilmemis demektir; iki kez iade olmaz.
        isaret = {"bedel": dict(SEFER_BEDELI), "toplam": toplam_bolum,
                  "tamamlanan": 0}
        self.durum.ayarlar[YARIM_SEFER] = isaret
        self.durum.kaydet()
        try:
            for sira, bolum in enumerate(sefer_nesnesi.bolumler):
                if sira > 0 and sira - 1 < len(sefer_nesnesi.baglantilar):
                    ekran.temizle()
                    ekran.yaz()
                    ekran.kutu(sefer_nesnesi.baglantilar[sira - 1], "SEFER", "acik_mor")
                    ekran.bekle()

                ekran.yaz()
                bolum_adlari = ["ÇAĞI ÇÖZ", "YERİ BUL", "HESABI KUR", "RAPORLA"]
                ekran.yaz("SEFER BÖLÜMÜ {}/{}  -  {}".format(
                    sira + 1, toplam_bolum,
                    bolum_adlari[sira] if sira < len(bolum_adlari) else "BAĞLANTIYI KUR"),
                    "kalin", "acik_mor")

                oturum = Oturum(
                    bolum,
                    oyuncu_adi=self.durum.goruntu_adi,
                    ipucu_acik=bool(self.durum.ayarlar.get("ipucu_acik", True)),
                    durum=self.durum,
                    asama=SERBEST,
                )
                sonuc = oturum.oyna()
                sefer_sonuclari.append(sonuc)
                sonucu_ozetle(bolum, sonuc)

                bildirimler = ilerleme.sonucu_isle(self.durum, sonuc)
                if bildirimler:
                    ekran.yaz()
                    for satir in bildirimler:
                        ekran.yaz(S["ok"] + " " + satir, "acik_mor", "kalin")

                if sonuc.birakildi:
                    tamamlandi = False
                    ekran.yaz()
                    ekran.hata("Sefer yarıda kaldı; Kronograf raporsuz açılmıyor.")
                    self._sefer_iadesini_ver()
                    self.durum.kaydet()
                    ekran.bekle()
                    break

                isaret["tamamlanan"] = sum(
                    1 for s in sefer_sonuclari if not s.birakildi)
                self.durum.kaydet()
                ekran.bekle()
        except (OyunuBirak, Exception):
            # Oyun sefer ortasinda kapatildi (Ctrl+C, girdi kapandi) ya da bir
            # bolum coktu: bu da yarida birakmak. Iade verilip kaydedilir,
            # sonra istisna yoluna devam eder (cikis ya da cokme.ele). Surec
            # olduruldugunde buraya hic gelinmez; iade bir sonraki acilista.
            self._sefer_iadesini_ver()
            try:
                self.durum.kaydet()
            except Exception:  # noqa: BLE001 - asil hata gorunsun
                pass
            raise

        # Butun bolumler bitti: iade yok, isaret kalkar (odul asagida
        # kaydedilirken birlikte yazilir).
        self.durum.ayarlar.pop(YARIM_SEFER, None)
        if tamamlandi:
            ekran.temizle()
            ekran.baslik("SEFER TAMAMLANDI", "kalin", "acik_yesil")
            ekran.yaz()
            ekran.kutu(sefer_nesnesi.kapanis, "DÖNÜŞ", "beyaz")

            # Kapanis metni icerikten geliyor ve her zaman ayni: kutlama.
            # Ogrenci birkac hata yapip "mukemmel" duyuyordu. Yanlisi dogru
            # gostermek ogretmemektir. Asagisi ceza degil, sadece gercek:
            # puan yok, siralama yok, basarisizlik damgasi yok.
            olcum = degerlendirme.sefer_degerlendirmesi(sefer_sonuclari)
            ekran.yaz()
            ekran.yaz(olcum["baslik"], "kalin",
                      "acik_yesil" if olcum["kusursuz"] else "acik_sari")
            if olcum["toplam_adim"]:
                ekran.yaz("{} adımın {} tanesini ilk denemede, yardımsız geçtin.".format(
                    olcum["toplam_adim"], olcum["ilk_denemede"]), "gri")
            if olcum["zorlanilan_konular"]:
                ekran.yaz()
                ekran.yaz("Takıldığın konular:", "kalin")
                for konu in olcum["zorlanilan_konular"]:
                    ekran.madde(konu.replace("_", " "), "acik_sari")
            if olcum["tekrarlayan_hatalar"]:
                ekran.yaz()
                ekran.yaz("Aynı hatayı birden çok kez yaptın:", "kalin")
                for hata in olcum["tekrarlayan_hatalar"]:
                    ekran.madde(hata, "acik_sari")
            if not olcum["kusursuz"]:
                ekran.yaz()
                ekran.yaz(olcum["oneri"], "acik_cam")

            uygulanan = self.durum.kaynak_ekle(sefer_nesnesi.odul)
            if uygulanan:
                ekran.yaz()
                ekran.yaz("Seferden kazandıkların:", "kalin")
                for anahtar, miktar in uygulanan.items():
                    if miktar:
                        ekran.madde("{} +{}".format(
                            KAYNAK_ADLARI.get(anahtar, anahtar), miktar), "acik_sari")
            gorulen.append(sefer_nesnesi.kod)
            self.durum.ayarlar["gorulen_seferler"] = gorulen[-10:]
            self.durum.gunluk_ekle("Zaman seferi tamamlandı: " + sefer_nesnesi.baslik)
            self.durum.kaydet()
            ekran.bekle()

        self._ilerleme_sonrasi()

    # ----------------------------------------------------------- konu taraması
    def _konu_taramasi(self) -> None:
        """
        Nerede olduğunu bulup rotayı çizer. Sınav değildir: süre, puan ve net
        yoktur; sonucu tek işe yarar - her konuyu doğru öğretim aşamasına
        yerleştirmeye.
        """
        from . import tarama as tarama_modulu

        secenekler = []
        yol_kodlari = list(OGRENME_YOLLARI)
        for yol in yol_kodlari:
            adet = sum(len(konular(alan)) for alan in yol_alanlari(yol))
            secenekler.append((OGRENME_YOLLARI[yol]["ad"], "{} konu".format(adet)))
        secenekler.append(("Geri dön", ""))

        self._ust_pano()
        ekran.yaz("İZ SÜRME MASASI", "kalin", "acik_cam")
        ekran.yaz("Neyi rahat yaptığını, nerede takıldığını görelim. "
                  "Puan yok, süre yok.", "gri")
        secim = ekran.menu("Hangi masaya oturalım?", secenekler)
        if secim >= len(yol_kodlari):
            return
        yol = yol_kodlari[secim]
        # Tarama kısa kalmalı: bu yoldaki en az çalışılmış iç alanı seçeriz;
        # oyuncu ders adı görmez, yalnızca gerçek konu başlıklarını görür.
        alanlar = yol_alanlari(yol)
        ders = min(alanlar, key=lambda a: sum(
            1 for k in konular(a) if self.durum.ders(a).konu(k).baslanmis))

        sonuc = tarama_modulu.tarama_yap(self.durum, ders)
        if sonuc is None:
            return
        tarama_modulu.sonucu_uygula(self.durum, sonuc)
        secilen_konu = tarama_modulu.sonucu_goster(sonuc)
        if secilen_konu:
            self._konu_akisi(ders, secilen_konu)

    def _zorluk_sec(self) -> None:
        secenekler = [("{} - {}".format(i, ZORLUK_ADLARI[i]),
                       ZORLUK_ACIKLAMALARI[i]) for i in range(1, 6)]
        secenekler.append(("Vazgeç", ""))
        secim = ekran.menu("ZORLUK", secenekler,
                           ipucu="Destek aşamaları her zorlukta açıktır.")
        if secim >= 5:
            return
        yeni = secim + 1
        if yeni == self.durum.zorluk:
            return
        self.durum.zorluk_ayarla(yeni)
        self.teklifler = []
        self.durum.gunluk_ekle("Zorluk değişti: {} - {}".format(
            yeni, ZORLUK_ADLARI[yeni]))
        self.durum.kaydet()
        ekran.yaz()
        ekran.basari("Zorluk {} - {}".format(yeni, ZORLUK_ADLARI[yeni]))
        ekran.bekle()

    # ------------------------------------------------------------------ karne
    def _karne(self) -> None:
        self._ust_pano()
        ekran.yaz("HARİTA ODASI", "kalin", "acik_cam")
        ekran.yaz()
        basliklar = "{:<24}{:<21}{}".format("MASA", "ELİN ALIŞTI MI", "İŞ")
        ekran.yaz(basliklar, "gri")
        for yol, bilgi in OGRENME_YOLLARI.items():
            konular_yol = [(a, k) for a in yol_alanlari(yol) for k in konular(a)]
            baslanan = [(a, k) for a, k in konular_yol
                        if self.durum.ders(a).konu(k).baslanmis]
            oturan = sum(1 for a, k in konular_yol
                         if self.durum.ders(a).konu(k).tamamlandi)
            oran = oturan / len(konular_yol) if konular_yol else 0
            satir = "{:<24}{} {:>3}%  {}/{}".format(
                bilgi["ad"], ekran.cubuk(oran, 1.0, 12),
                int(round(oran * 100)), oturan, len(konular_yol))
            ekran.yaz(satir, "acik_cam", sar=False, girinti="  ")

        ekran.yaz()
        model_toplam = sum(self.durum.ders(d).model_toplam for d in self.durum.aktif_dersler())
        model_dogru = sum(self.durum.ders(d).model_dogru for d in self.durum.aktif_dersler())
        if model_toplam:
            ekran.yaz("Bilinmeyeni ilk denemede doğru kurma: {}/{} görev  (%{})".format(
                model_dogru, model_toplam, int(round(100 * model_dogru / model_toplam))),
                "acik_mor")

        ekran.yaz()
        ekran.kutu(ilerleme.genel_degerlendirme(self.durum), "DEĞERLENDİRME", "beyaz")

        zayif = self._zayif_konular()
        if zayif:
            ekran.yaz()
            ekran.yaz("Tekrar etmen iyi olacak konular:", "kalin")
            for _alan, konu, puan in zayif:
                ekran.madde("{} (%{})".format(konu.replace("_", " "),
                                                   int(round(puan * 100))), "acik_sari")
        ekran.bekle()

    def _zayif_konular(self, esik: float = 0.55) -> List[Tuple[str, str, float]]:
        sonuc = []
        for ders in self.durum.aktif_dersler():
            for konu, puan in self.durum.ders(ders).konu_puani.items():
                if puan < esik:
                    sonuc.append((ders, konu, puan))
        sonuc.sort(key=lambda x: x[2])
        return sonuc[:5]

    # ----------------------------------------------------------------- günlük
    def _gunluk(self) -> None:
        from . import pano
        from .durum import RUTBELER
        d = self.durum
        self._ust_pano()
        ekran.yaz("KÂŞİF GÜNLÜĞÜ", "kalin", "acik_cam")
        ekran.yaz()
        # "Ayrı gün", asla "üst üste": seri kaybedilir, bu sayı yalnızca
        # birikir (TASARIM_NOTLARI §2, B35.11).
        ekran.kutu("Takma ad: {}\nMevcut rütbe: {}\nToplam yıldız: {}"
                   "\nTamamlanan saha görevi: {}"
                   "\nSeferde geçen ayrı gün: {}".format(
                       d.goruntu_adi, d.rutbe, d.rutbe_puani, d.oynanan_gorev,
                       d.ayri_gun),
                   "KİMLİK KARTI", "beyaz")
        sonraki = d.sonraki_rutbe
        if sonraki:
            kalan = max(0, sonraki[0] - d.rutbe_puani)
            ekran.yaz("Sonraki rütbe: {}  {}  {} yıldız kaldı".format(
                sonraki[1], ekran.cubuk(d.rutbe_puani, sonraki[0], 14),
                kalan), "gri")
        else:
            # Ad SABIT YAZILMIYOR: merdiven uzayinca eski sabit metin yalan
            # soyluyordu ("En yuksek rutbedesin: Meridyen Muhafizi").
            ekran.basari("En yüksek rütbedesin: {}".format(RUTBELER[-1][1]))

        ekran.yaz()
        ekran.yaz("RÜTBE MERDİVENİ", "kalin", "acik_sari")
        for sira, (esik, ad) in enumerate(RUTBELER):
            if sira < d.rutbe_sirasi:
                ekran.madde("{}  ({} yıldız)".format(ad, esik), "gri",
                            isaret=S["onay"])
            elif sira == d.rutbe_sirasi:
                ekran.madde("{}  (buradasın)".format(ad), "acik_yesil", "kalin",
                            isaret=S["ok"])
            else:
                ekran.madde("{}  ({} yıldız)".format(ad, esik), "gri", isaret=" ")

        # Yalnizca ONDEKILER. Sira numarasi yok, arkadakiler yok; bkz. pano.py
        onde = pano.sinif_panosu(d)
        if onde:
            ekran.yaz()
            ekran.yaz("ÖNÜNDEKİLER", "kalin", "acik_sari")
            for kisi in onde:
                ekran.madde("{}  ({})  senden {} yıldız önde".format(
                    kisi["takma"], kisi["rutbe"], kisi["fark"]), "beyaz")
        elif d.sinif_kodu and pano.sinif_verisi(d):
            ekran.yaz()
            ekran.yaz("Sınıfında önünde kimse yok.", "acik_yesil")

        if d.rozetler:
            ekran.yaz()
            ekran.yaz("ROZETLER", "kalin", "acik_sari")
            for rozet in d.rozetler:
                ekran.madde(rozet, "acik_sari", isaret=S["yildiz"])
        ekran.yaz()
        ekran.yaz("SON KAYITLAR", "kalin")
        for satir in d.gunluk[-12:]:
            ekran.yaz(satir, "gri", girinti="  ")
        ekran.bekle()

    # ---------------------------------------------------------------- ayarlar
    def _hikaye_tarzi_sec(self) -> None:
        kodlar = list(TARZLAR)
        secim = ekran.menu("BU SEFERİ NASIL YAŞAMAK İSTERSİN?", [
            (TARZLAR[k][0], TARZLAR[k][1]) for k in kodlar] + [("Geri dön", "")])
        if secim < len(kodlar):
            self.durum.ayarlar["hikaye_tarzi"] = kodlar[secim]
            self.durum.kaydet()

    def _ayarlar(self) -> None:
        while True:
            self._ust_pano()
            ayarlar = self.durum.ayarlar
            hiz = float(ayarlar.get("yazim_hizi", 0.0))
            hiz_metni = "kapalı (anında)" if hiz <= 0 else "{:.3f} sn/harf".format(hiz)
            secim = ekran.menu("TEÇHİZAT VE AYARLAR", [
                ("Zorluk {} - {}".format(self.durum.zorluk, self.durum.zorluk_adi),
                 ZORLUK_ACIKLAMALARI[self.durum.zorluk]),
                ("Yazım efekti: " + hiz_metni, "metnin harf harf yazılması"),
                ("Uyarlanır destek: " +
                 ("açık" if ayarlar.get("zorluk", "uyarlanir") == "uyarlanir" else "kapalı"),
                 "zorlanınca birlikte çözme aşamasına geri döner"),
                ("İpuçları: " + ("açık" if ayarlar.get("ipucu_acik", True) else "kapalı"), ""),
                ("Görev dökümü", "hangi masada hangi zorlukta kaç iş var"),
                ("Hikâye tercihi: " + TARZLAR[tarz(self.durum)][0], "istediğin zaman değiştirebilirsin"),
                ("Takma ad: " + (self.durum.takma_ad or "yok"),
                 "sınıf seni bu adla tanır; değiştirmek serbest"),
                ("Oyuncu anketini yeniden yap", "üs sana neyi önce göstersin"),
                ("Sınıf panosunda görün: " +
                 ("açık" if ayarlar.get("panoda_gorun", True) else "kapalı"),
                 "kapalıyken başkalarının panosunda görünmezsin"),
                ("Ne sıklıkla uğrayabilirsin",
                 "vakti az olana kısa seferler öne çıkar"),
                ("Kaydımı sil", "ilerlemen kalıcı olarak silinir; geri alınamaz"),
                ("Geri dön", ""),
            ])
            if secim == 0:
                self._zorluk_sec()
            elif secim == 1:
                yeni = 0.0 if hiz > 0 else 0.012
                ayarlar["yazim_hizi"] = yeni
                ekran.yazim_hizi_ayarla(yeni)
            elif secim == 2:
                ayarlar["zorluk"] = "sabit" if ayarlar.get("zorluk") == "uyarlanir" else "uyarlanir"
            elif secim == 3:
                ayarlar["ipucu_acik"] = not ayarlar.get("ipucu_acik", True)
            elif secim == 4:
                kapsama_yazdir()
                ekran.bekle()
            elif secim == 5:
                self._hikaye_tarzi_sec()
            elif secim == 6:
                from . import oyuncu
                eski = self.durum.takma_ad
                self.durum.takma_ad = ""
                oyuncu.takma_ad_sec(self.durum)
                if not self.durum.takma_ad:
                    self.durum.takma_ad = eski
                self.durum.kaydet()
            elif secim == 7:
                from . import oyuncu
                oyuncu.anket(self.durum)
                self._katman_sirasi = oyuncu.katman_sirasi(self.durum)
                self.durum.kaydet()
            elif secim == 8:
                ayarlar["panoda_gorun"] = not ayarlar.get("panoda_gorun", True)
            elif secim == 9:
                from . import oyuncu
                oyuncu.ritim_yaz(self.durum,
                                 oyuncu.ritim_sor(self.durum.tip == "okul"))
                self.durum.kaydet()
            elif secim == 10:
                if self._kaydimi_sil():
                    return          # kayit yok: "Geri dön"deki kaydet YAPILMAZ
            else:
                self.durum.kaydet()
                return

    def _kaydimi_sil(self) -> bool:
        """Öğrencinin kendi kaydını silmesi (B36.16, KVKK). Silindiyse True.

        Onay: kayıttaki ad AYNEN yazılır; PIN konulduysa PIN de sorulur --
        aynı bilgisayarı kullanan başkası "Kaydımı sil"e basıp bir arkadaşının
        seferini silemesin. Silinen kayıt geri gelmez; bellekteki durum da
        `_silindi` ile işaretlenir, sonradan çalışan bir `kaydet` kaydı
        diriltmesin. Telefonda silme tarayıcının deposuna da işlenir
        (`durum.sil` -> kayıt kancası).
        """
        from araclar import kvkk

        d = self.durum
        ekran.temizle()
        ekran.baslik("KAYDIMI SİL", "kalin", "acik_cam")
        ekran.kutu(
            "Kaydın KALICI olarak silinecek: rütben, görevlerin, kaynakların, "
            "tesislerin, günlüğün ve anket cevapların. Bu cihazdaki karnen, "
            "öğretmeninin bıraktığı bildirimler ve geri bildirim paketlerin "
            "de silinir. Geri alınamaz.\n\n"
            "Daha önce yazdırılmış karneler bundan etkilenmez.\n\n"
            "Kayıttaki adın: {}\n"
            "Onaylamak için adını aynen yaz. Vazgeçmek için boş bırak."
            .format(d.ad), "DİKKAT", "acik_sari")
        ad = (ekran.sor("Adın:", "") or "").strip()
        if not ad or ad != (d.ad or "").strip():
            ekran.bilgi("Ad tutmadı; kaydın silinmedi." if ad
                        else "Vazgeçildi; kaydın duruyor.")
            ekran.bekle()
            return False
        if d.pin_ozeti and not d.pin_dogru_mu(ekran.sor("PIN'in:", "")):
            ekran.bilgi("PIN tutmadı; kaydın silinmedi.")
            ekran.bekle()
            return False
        yollar = [d.dosya_yolu()]
        okunan = getattr(d, "_okunan_yol", "")
        # Kayıt adı kimliğiyle tutmayan bir dosyadan açılmış olabilir (elle
        # kopyalanmış ya da yeniden adlandırılmış). Oyun o zaman kimlik
        # adına yazar; iki dosya da bu öğrencinindir. Yalnız birini silip
        # "silindi" demek yanlış olurdu.
        if okunan and (os.path.normcase(os.path.abspath(okunan))
                       != os.path.normcase(os.path.abspath(yollar[0]))):
            yollar.append(okunan)
        sonuclar = kvkk.toplu_sil(yollar)
        if not all(s.basarili for s in sonuclar):
            ekran.hata("Kaydın silinemedi. Öğretmenine haber ver.")
            ekran.bekle()
            return False
        d._silindi = True
        ekran.basari("Kaydın silindi. Oyun açılış ekranına dönüyor.")
        ekran.bekle()
        return True


# --------------------------------------------------------------------------
# Kapsama raporu (öğretmen / geliştirici için)
# --------------------------------------------------------------------------

def kapsama_yazdir() -> None:
    ekran.yaz()
    ekran.yaz("GÖREV DÖKÜMÜ  (masa x zorluk)", "kalin", "acik_cam")
    ekran.yaz()
    basliklar = "{:<24}".format("") + "".join("{:>10}".format(
        "{} {}".format(z, ZORLUK_ADLARI[z])) for z in range(1, 6))
    ekran.yaz(basliklar, "gri")
    kayitlar = tum_kayitlar()
    araliklar = {1: (1, 3), 2: (4, 6), 3: (7, 9), 4: (10, 12), 5: (13, 13)}
    for yol, bilgi in OGRENME_YOLLARI.items():
        alanlar = set(yol_alanlari(yol))
        satir = "{:<24}".format(bilgi["ad"])
        for z in range(1, 6):
            alt, ust = araliklar[z]
            adet = sum(1 for k in kayitlar if k.ders in alanlar and
                       k.kademeler[0] <= ust and k.kademeler[1] >= alt)
            satir += "{:>10}".format(adet if adet else ".")
        ekran.yaz(satir, "acik_cam", sar=False, girinti="  ")
    ekran.yaz()
    ekran.yaz("Toplam kayıtlı üretici: {}".format(len(uygun_kayitlar())), "gri")


# --------------------------------------------------------------------------
# Açılış ekranı ve kayıt seçimi
# --------------------------------------------------------------------------

def _acilis_ekrani() -> None:
    ekran.temizle()
    ekran.yaz()
    ekran.baslik(OYUN_ADI, "kalin", "acik_cam")
    ekran.yaz(ALT_BASLIK.center(ekran.genislik()), "gri")
    ekran.yaz()
    ekran.kutu(
        "Meridyen Üssü'ne kayıt subayı olarak atandın.\n"
        "Burada kimse sana \"şu denklemi çöz\" demez. Sana bozuk bir defter, "
        "eksik bir ölçüm ya da yanlış yazılmış bir mektup verilir; neyin "
        "bilinmediğini de, nasıl bulunacağını da sen çıkarırsın.",
        "GÖREV EMRİ", "beyaz")


ZORLUK_YILDIZI = {1: "kolay", 2: "orta", 3: "zor", 4: "çok zor", 5: "en zor"}


# Tesis yeri acildiktan kac gorev sonra ilk ariza gelebilir. Ogrenci once
# tesisleri calisirken gorsun, sonra bozulani onarmayi ogrensin.
ARIZA_ACILIS_PAYI = 2


def _ariza_zamani_mi(durum) -> bool:
    """Ariza yalniz ogrencinin tesisleri GOREBILDIGI ve onarabildigi zaman."""
    n = int(durum.oynanan_gorev or 0)
    if n <= 0:
        return False
    if durum.ayarlar.get("kademeli_menu"):
        return n >= KADEMELI_ACILIS["tesis"] + ARIZA_ACILIS_PAYI
    return True


def _us_yerini_ata(durum) -> None:
    """Yeni sefere Türkiye'de bir nokta atar ve öğrenciye anlatır.

    Girdi istemez: ilk dakikalardaki ekran/girdi sınırı (B35.14) korunur.
    Veri okunamazsa eski varsayılana düşer; oyun yine açılır.
    """
    from . import konum, yer
    try:
        yer.yer_ata(durum)
        o = yer.ozet(durum)
    except Exception:  # noqa: BLE001 - veri yoksa varsayilan konum
        durum.konum = konum.VARSAYILAN
        return
    ekran.yaz()
    ekran.yaz("Üs kuruldu: {}  ({} yakınları, {})".format(
        o["koordinat"], o["il"], o["bolge"]), "kalin", "acik_cam")
    ekran.madde("Arazi: {}. {}, rakım yaklaşık {} m.".format(
        konum.ad(durum.konum), o["iklim"], o["rakim"]), "gri")
    if o["maden_notu"]:
        ekran.madde("Bölgedeki yataklar: " + o["maden_notu"], "acik_yesil")
    if o["yerel_madenler"]:
        ekran.madde("Bu madenler burada daha verimli işlenir.", "gri")
    k = o["kapi"]
    if k:
        satir = "En yakın sınır kapısı: {} ({}, yaklaşık {} km).".format(
            k["kapi"], k["ulke"], k["km"])
        if k["gelen"]:
            satir += " Buradan {} gelir.".format(k["gelen"])
        ekran.madde(satir, "gri")
    durum.gunluk_ekle("Üs kuruldu: {}, {}".format(o["koordinat"], o["il"]))


def _us_konumu_sec() -> str:
    """Üssün kurulacağı yeri seçtirir. Vazgeçilirse varsayılan döner.

    İKİ ADIM: önce kuşak (yeryüzü, yeraltı, yüzen şehir, su altı, gökyüzü,
    uzay), sonra -varsa- arazi. Artı ve eksiler seçimden SONRA gösterilip
    onay isteniyor; öğrenci listedeki tek satırla değil, ne aldığını görerek
    karar versin. Onay vermezse liste yeniden gelir.

    Bu bir ZORLUK seçimi değil, bir ekonomi seçimi: hiçbir konum oyunu
    kapatmaz, hepsi oynanır (bkz. oyun/motor/konum.py, KİLİT YOK).
    """
    from . import konum

    while True:
        ekran.yaz()
        ekran.yaz("Üs nereye kurulsun? Her yerin kendi artısı ve eksisi var. "
                  "Seçtiğin yerde kalırsın: kendi isteğinle taşınma henüz "
                  "yok.", "gri")
        adaylar = konum.secenekler()
        secim = ekran.menu("Üssün yeri:", [
            ("{}  ({})".format(k["ad"], ZORLUK_YILDIZI.get(k["zorluk"], "")),
             k["ozet"]) for k in adaylar] + [("Bilmiyorum, sen seç", "yeryüzü düzlük")])
        if secim >= len(adaylar):
            return konum.VARSAYILAN
        kusak = adaylar[secim]

        ekran.yaz()
        ekran.yaz(kusak["ad"], "kalin", "acik_cam")
        for satir in kusak["artilar"]:
            ekran.madde("+ " + satir, "acik_yesil")
        for satir in kusak["eksiler"]:
            ekran.madde("- " + satir, "acik_sari")
        if not ekran.onayla("Üs buraya kurulsun mu?", True):
            continue

        if not kusak["arazili"]:
            return kusak["kod"]

        araziler = konum.araziler(kusak["kod"])
        ekran.yaz()
        arazi_secim = ekran.menu("Hangi araziye?", [
            (a.ad, a.ozet) for a in araziler] + [("Geri dön", "")])
        if arazi_secim >= len(araziler):
            continue
        return konum.kod_yap(kusak["kod"], araziler[arazi_secim].kod)


# B35.14 / B36.17 (kullanici karari, 29 Eylul 2026): ILK GOREVE KADAR EN FAZLA
# 3 EKRAN VE 1 GIRDI (ad/takma ad). Olculdu (testler/test_ilk_on_dakika.py):
# eskiden evde 18 durak / 12 bilgi girdisi, okulda 20 / 14 (sinif koduyla;
# kodsuz 21 / 15) idi -- ad, nerede, sinif kodu, numara, sube, PIN, okuyor
# musun, calisiyor musun, zorluk, us konumu, takma ad ve bes anket sorusu.
# Ogrenci daha tek gorev gormeden on bes soru cevapliyordu. Simdi: evde
# 3 durak / 1 girdi; okulda sinif koduyla 6 / 4 (kod, ad, numara, PIN).
#
# Simdi ilk gorevden ONCE yalnizca kimlik soruluyor; tercihler (zorluk
# ayari, takma ad, anket, nobet cizelgesi, us yeri) ilk gorevden SONRA
# (`Oyun._ilk_gorev_sonrasi`). Okulda ogretmen takibi icin gereken kimlik
# adimlari (sinif kodu, numara, PIN) YERINDE KALDI: sinif-numara kaydin
# kimligi ve dosya adi, sonradan degistirmek kaydi tasimak demek.
VARSAYILAN_ZORLUK = 2
# Ilk gorevden sonra sorulacak kurulum adimlari (ayarlar["kurulum_bekliyor"]).
# Yarida kalirsa kalan adimlar bir sonraki acilista sorulur.
ERTELENEN_KURULUM = ("zorluk", "ritim", "konum")
# Bu surumun sorabildigi butun adimlar. "takma_ad" yeni seferde yok; ev kaydi
# sinifa baglaninca eklenir (araclar/sinif.ogrenciyi_tasi).
BILINEN_KURULUM = ERTELENEN_KURULUM + ("takma_ad",)


def sinif_seviyesi(metin: str) -> Optional[int]:
    """Sinif adindan seviye: "9-A" -> 9, "10/B" -> 10. Okunamazsa None.

    Okulda zorluk artik sorulmuyor: sinifin kendisi soyluyor. Sinif adi
    "Fizik Kulubu" gibi sayisiz ise varsayilan zorluk kullanilir.
    """
    import re
    bulunan = re.match(r"\s*(\d{1,2})(?!\d)", metin or "")
    if not bulunan:
        return None
    seviye = int(bulunan.group(1))
    return seviye if 1 <= seviye <= 12 else None


def _okul_cihazi_mi() -> bool:
    """Bu cihazda okul izi var mi? Yoksa "Nerede oynuyorsun?" SORULMAZ.

    Evde oynayan icin o soru, cevabi hep ayni olan bir girdiydi. Okul izi:
    sinif sunucusu tanimli (telefonlar), bu cihazda acilmis bir sinif,
    ogretmen parolasi kurulmus ya da cihazda numarali (okul) kayit var
    (ortak bilgisayar). Bunlarin hicbiri yoksa sinif kodu zaten
    dogrulanamaz -- okul yolunun ogretmene ulasacagi bir yer yok.
    """
    try:
        from . import ag
        if ag.acik_mi():
            return True
    except Exception:  # noqa: BLE001 - tespit oyunu durdurmasin
        pass
    try:
        from araclar import sinif as sinif_modulu
        if sinif_modulu.siniflari_listele():
            return True
    except Exception:  # noqa: BLE001
        pass
    try:
        from araclar import ogretmen
        if ogretmen.parola_kurulu_mu():
            return True
    except Exception:  # noqa: BLE001
        pass
    return any(k.get("numara") or k.get("sinif_kodu")
               for k in _cihazdaki_kayitlar())


def _sinif_kodu_sor():
    """(kod, sinif kaydi). Kod yoksa ya da bulunamazsa ("", None)."""
    from araclar import sinif as sinif_modulu
    ekran.yaz()
    ekran.yaz("Öğretmenin tahtaya bir sınıf kodu yazdıysa onu gir; "
              "sınıfın kendiliğinden dolar.", "gri")
    for _ in range(3):
        kod = ekran.sor("Sınıf kodu (yoksa boş bırak):", "").strip()
        if not kod:
            return "", None
        sinif_kaydi = sinif_modulu.sinif_bul(kod)
        if sinif_kaydi:
            return kod, sinif_kaydi
        ekran.hata("Bu kodla bir sınıf bulunamadı. Kodu kontrol et ya da "
                   "boş bırakıp devam et.")
    return "", None


def _yeni_oyun() -> Optional[Durum]:
    # Sınıf ve numara ESKİDEN HERKESE soruluyordu; sonra "Nerede
    # oynuyorsun?" sorusunun arkasına alındı. B35.14: o soru da artık yalnız
    # okul izi olan cihazda soruluyor (bkz. `_okul_cihazi_mi`). Sınıf kodu
    # ÖNCE geliyor: geçerli bir kod zaten "okuldayım" demek, ayrıca sormaya
    # gerek yok. Kod yoksa (öğretmeni henüz sınıf açmamış okul) eski yol
    # duruyor -- kimse kilitlenmesin.
    okulda = False
    kod = ""
    sinif_kaydi = None
    if _okul_cihazi_mi():
        kod, sinif_kaydi = _sinif_kodu_sor()
        if sinif_kaydi:
            okulda = True
        else:
            ekran.yaz()
            nerede = ekran.menu("Nerede oynuyorsun?", [
                ("Kendi başıma", "evde, mezun ya da yetişkin — sınıf ve numara sorulmaz"),
                ("Okulda", "öğretmenim ilerlememi takip edecek"),
            ])
            okulda = (nerede == 1)

    ekran.yaz()
    if okulda:
        # Gercek ad: karnede ve ogretmen masasinda. Sinifin gordugu takma
        # ad ilk gorevden sonra soruluyor; o zamana kadar pano bu ogrenciyi
        # hic gostermiyor (pano yalnizca takma adi olanlari listeler).
        ad = ekran.sor("Adın nedir?", "Kâşif")
    else:
        ad = ekran.sor("Adın ya da takma adın:", "Kâşif")

    numara = ""
    sinif = ""
    pin = ""
    kayit_adi = ""
    okul_adi = ""
    if okulda:
        if sinif_kaydi:
            sinif = sinif_kaydi["ad"]
            # Okul adi kayda yazilir (ogretmen raporu icin) ama ogrenciye
            # gosterilmez (B41).
            okul_adi = sinif_kaydi.get("okul", "")
            ekran.bilgi("Sınıfın: {}".format(sinif))

        ekran.yaz()
        numara = ekran.sor("Öğrenci numaran:", "")
        if not sinif_kaydi:
            sinif = ekran.sor("Sınıfın ve şuben:", "")
        if numara:
            # Okul numarasi PAROLA OLAMAZ: siniftaki herkes bilir. Bu yuzden
            # ogrenci kendi PIN'ini koyuyor. Sinif koduyla girildiyse ortak
            # bilgisayar ihtimali yuksek, o yuzden daha gorunur soruluyor.
            # B35.14'te de ILK GOREVDEN ONCE kaldi: PIN'siz gecen bes dakika,
            # ortak bilgisayarda baskasinin acabilecegi bes dakikadir.
            ekran.yaz()
            if sinif_kaydi:
                ekran.kutu(
                    "Sınıf arkadaşların da bu bilgisayarları kullanıyor. "
                    "Dört haneli bir PIN koyarsan seferini başkası açamaz."
                    "\n\n"
                    "PIN'i unutursan öğretmenin yardımcı olabilir.",
                    "PIN KOY", "acik_sari")
            else:
                ekran.yaz("Ortak bilgisayarda oynuyorsan dört haneli bir PIN "
                          "koy; seferini başkası açamaz. İstemiyorsan boş "
                          "bırak.", "gri")
            pin = ekran.sor("PIN (isteğe bağlı):", "")
            if sinif_kaydi and not pin:
                # Israr etmiyoruz ama bir kez daha soruyoruz: okulda PIN'siz
                # kayit, merakli bir sinif arkadasinin acabilecegi kayittir.
                ekran.yaz()
                if ekran.onayla("PIN koymadan devam edilsin mi?", True) is False:
                    pin = ekran.sor("PIN:", "")

    if numara:
        # Aynı kimliğe sahip bir kayıt varsa üstüne yazmayalım: okulda aynı
        # numaralı iki öğrencinin birbirinin ilerlemesini silmesi buradan
        # oluyordu. Numara oyuncunun kendi verdiği bilgi; düzeltmesi gerekir.
        deneme = Durum.yeni(ad, sinif=sinif, numara=numara)
        if os.path.exists(deneme.dosya_yolu()):
            ekran.yaz()
            ekran.hata("Bu kimlikle zaten bir sefer var: {}".format(deneme.kimlik()))
            ekran.yaz("Üstüne yazmıyorum. Kendi seferinse ana ekrandan \"Kayıtlı "
                      "sefere devam et\" ile gir; değilse numaranı kontrol et.", "gri")
            ekran.bekle()
            return None
    else:
        # Numarasız oyuncuda kimlik ADIN kendisiydi; aynı evde iki "Ali"
        # oynarsa ikincisi birincinin dosyasına yazıyordu. Sınıf/numara
        # sorusu kaldırılınca bu durum istisna olmaktan çıktı, o yüzden
        # kimlik burada boşta olan bir ada sabitleniyor: ali, ali-2, ali-3...
        # Sorulacak bir şey yok, kullanıcı bunu hiç görmüyor.
        kayit_adi = durum_modulu.benzersiz_kayit_adi(ad)

    # Zorluk SORULMUYOR (B35.14). Okulda sınıf seviyesi başlangıç kademesi
    # olur ("9-A" -> 9); değilse varsayılan. İlk görevden sonra öğrenciye
    # "nasıl geldi?" diye sorulup bir kademe ayarlanır -- soyut bir listeden
    # seçmek yerine bir görevi yaşamış olarak.
    seviye = sinif_seviyesi(sinif) if okulda else None
    if seviye:
        durum = Durum.yeni(ad, baslangic_kademesi=seviye, sinif=sinif,
                           numara=numara, pin=pin, tip="okul",
                           kayit_adi=kayit_adi)
    else:
        durum = Durum.yeni(ad, baslangic_kademesi=ZORLUK_KADEME[VARSAYILAN_ZORLUK],
                           zorluk=VARSAYILAN_ZORLUK, sinif=sinif, numara=numara,
                           pin=pin, tip="okul" if okulda else "ev",
                           kayit_adi=kayit_adi)
    if not okulda:
        # Evde sinif yok; yazdigi ad zaten kendi sectigi ad. Takma ad
        # denetiminden gecerse takma ad olarak da yazilir ve ilk gorevden
        # sonra ayrica sorulmaz. Gecmezse (kisa, uygunsuz) sonra sorulur.
        from . import oyuncu
        temiz, sorun = oyuncu.takma_ad_denetle(ad)
        if sorun is None:
            durum.takma_ad = temiz
    if okulda and okul_adi:
        durum.okul = okul_adi
    if okulda and kod:
        durum.sinif_kodu = kod.upper()
    durum.ayarlar["kurulum_bekliyor"] = list(ERTELENEN_KURULUM)
    durum.ayarlar["ilk_gorev_bekliyor"] = True
    durum.ayarlar["kademeli_menu"] = True          # B36.18
    durum.kaydet()
    return durum


def _kayit_ac(ozet) -> Optional[Durum]:
    """Bir kaydı PIN denetiminden geçirerek açar."""
    durum = durum_modulu.yukle(ozet["yol"])
    if durum is None:
        ekran.hata("Kayıt dosyası okunamadı.")
        return None
    if durum.pin_ozeti:
        for kalan in (2, 1, 0):
            if durum.pin_dogru_mu(ekran.sor("{} için PIN:".format(durum.ad), "")):
                return durum
            if kalan:
                ekran.hata("PIN tutmadı. {} hakkın kaldı.".format(kalan))
        ekran.hata("PIN tutmadı.")
        ekran.bekle()
        return None
    return durum


def _adla_bul(kayitlar) -> Optional[Durum]:
    """Adi sorup kaydi bulur. LISTE GOSTERMEZ.

    NEDEN LISTE YOK
    ---------------
    Ortak bir telefonda "Kayitli sefere devam et" butun adlari
    listeliyordu. Kim oynamis, kac gorev yapmis, hangi sinifta -- hepsi
    listeye dokunan herkese aciktu. Okulda telefon paylasmak olagan.
    (E08 / B31.4)

    Ad soruldugunda ogrenci YALNIZCA kendi kaydini goruyor. Bulunamazsa
    da elde ne oldugu soylenmiyor: "yanlis ad" cevabi bile, denemeyle
    liste cikarmaya yarar.

    Tek kayit varsa hic sorulmuyor -- kendi telefonunda oynayan ogrenciyi
    her acilista ad yazmaya zorlamanin karsiligi yok.
    """
    if len(kayitlar) == 1:
        return _kayit_ac(kayitlar[0])

    ekran.yaz()
    ad = ekran.sor("Sefer hangi adla kayıtlı?", "").strip()
    if not ad:
        return None
    eslesen = [o for o in kayitlar if ekran.ayni_ad(o.get("ad", ""), ad)]
    if not eslesen:
        ekran.hata("Bu adla kayıtlı sefer yok. Yazımı kontrol et ya da "
                   "ana ekrandan yeni sefer aç.")
        ekran.bekle()
        return None
    if len(eslesen) == 1:
        return _kayit_ac(eslesen[0])
    # Ayni adli birden cok kayit: yalnizca ONLARI gosteriyoruz. Ogrenci
    # zaten adi bildigi icin burada yeni bir bilgi sizmiyor.
    return _listeden_sec(eslesen)


def _listeden_sec(kayitlar) -> Optional[Durum]:
    secenekler = []
    for ozet in kayitlar:
        zaman = time.strftime("%d.%m.%Y %H:%M", time.localtime(ozet["son"])) if ozet["son"] else "-"
        etiket = ozet["ad"]
        if ozet.get("sinif"):
            etiket = "{}  ({})".format(etiket, ozet["sinif"])
        # Gorev sayisi ve bolum BILEREK yok. Sinif panosu takma adi gorev
        # farkiyla gosteriyor; bu ekran gercek adi gorev sayisiyla gosterseydi
        # ikisi yan yana konup takma adin sahibi bulunabilirdi.
        secenekler.append((etiket, "son oynama: {}".format(zaman)))
    secenekler.append(("Geri dön", ""))
    secim = ekran.menu("KAYITLI OYUNLAR", secenekler)
    if secim >= len(kayitlar):
        return None
    return _kayit_ac(kayitlar[secim])


def _kayit_sec() -> Optional[Durum]:
    """
    Kayıtlı sefere dönüş.

    Okulda kayıt klasörü ortak olabilir; orada bütün okulun kayıtlarını
    listelemek hem uzun hem de herkesin herkesin dosyasını açması demek.
    Bu yüzden numaralı kayıt varsa önce numara sorulur. Numarasız (ev)
    kayıtlar eskisi gibi listeden seçilir.
    """
    kayitlar = durum_modulu.kayitlari_listele()
    if not kayitlar:
        ekran.bilgi("Kayıtlı oyun yok.")
        return None

    numarasizlar = [o for o in kayitlar if not o.get("numara")]
    if not any(o.get("numara") for o in kayitlar):
        return _adla_bul(kayitlar)

    ekran.yaz()
    numara = ekran.sor("Öğrenci numaran (numarasız oynuyorsan boş bırak):", "")
    if not numara:
        if not numarasizlar:
            ekran.bilgi("Numarasız kayıt yok. Numaranı yazman gerekiyor.")
            return None
        return _adla_bul(numarasizlar)

    bulunan = durum_modulu.numarayla_bul(numara)
    if not bulunan:
        ekran.hata("{} numarasıyla kayıt bulunamadı. Numaranı kontrol et ya da "
                   "ana ekrandan yeni sefer aç.".format(numara))
        ekran.bekle()
        return None
    if len(bulunan) > 1:
        # Aynı numara birden çok şubede olabilir (okul numaraları sınıf içinde
        # tekrar ediyorsa). Ayrımı öğrenciye yaptıralım.
        return _listeden_sec(bulunan)
    return _kayit_ac(bulunan[0])


def _cihazdaki_kayitlar():
    """Bu cihazdaki öğrenci kayıtları. Okunamıyorsa boş liste."""
    try:
        return durum_modulu.kayitlari_listele()
    except OSError:
        return []


def _yeni_sefer_onayi(kayitlar) -> bool:
    """Kayıt varken yeni sefer açmadan önce sorulur.

    Eski kayıt SİLİNMEZ (üstüne yazma koruması ayrı), ama öğrenci yeni bir
    boş seferde kalır ve eskisine dönmeyi bilemez. Soru bunu önlemek için.
    """
    ekran.yaz()
    if len(kayitlar) == 1:
        ekran.yaz("Bu cihazda kayıtlı bir seferin var: {}".format(
            kayitlar[0].get("ad", "?")), "acik_sari")
    else:
        ekran.yaz("Bu cihazda {} kayıtlı sefer var.".format(len(kayitlar)),
                  "acik_sari")
    ekran.yaz("Yeni sefer açarsan o kayıt silinmez ama sıfırdan başlarsın; "
              "eskisine dönmek için \"Kayıtlı sefere devam et\".", "gri")
    return ekran.onayla("Yine de yeni sefer açılsın mı?", False)


def _oturumu_kosur(durum) -> None:
    """Bir oyun oturumunu çökme koruması altında koşturur.

    HER SEFER AYRI KORUNUYOR. Bir görevin ya da bir menünün patlaması bütün
    oturumu bitirmemeli: öğrenci açılış ekranına döner, ilerlemesi
    kaydedilmiş olur ve oynamaya devam edebilir. Bkz. oyun/motor/cokme.py
    """
    try:
        Oyun(durum).calistir()
    except OyunuBirak:
        raise
    except Exception as sorun:      # noqa: BLE001
        cokme.ele(sorun, durum, nerede="oyun oturumu")


def basla() -> None:
    """Programın giriş noktası."""
    try:
        adet = icerigi_yukle()
    except Exception as sorun:  # içerik modülünde hata varsa oyun hiç açılmasın demeyelim
        adet = 0
        ekran.hata("İçerik yüklenirken sorun: {}".format(sorun))

    ilk_acilis = True
    try:
        while True:
            kayitlar = _cihazdaki_kayitlar()

            # CİHAZDA TEK KAYIT VARSA SORMA, AÇ. (kullanıcı, 12 Eylül 2026)
            # "Oyunu her açtığımızda yeni sefer diye diye sormayalım. Bir
            # öğrenci ilerlemiştir ve yanlışlıkla da olsa ona basmıştır."
            # Yanlışlıkla yeni sefer açan öğrenci eski kaydını SİLMİYOR
            # (üstüne yazma koruması var) ama kendini bomboş bir seferde
            # buluyor ve eskisine nasıl döneceğini bilmiyor. Menü ancak
            # oyundan çıkınca görünür; orada sefer değiştirebilir.
            if ilk_acilis and len(kayitlar) == 1:
                ilk_acilis = False
                _acilis_ekrani()
                ekran.yaz()
                ekran.yaz("Seferin açılıyor. Başka bir sefere geçmek ya da yeni "
                          "sefer açmak için oyundan çıkman yeter.", "gri")
                durum = _kayit_ac(kayitlar[0])
                if durum is None:
                    continue                # PIN tutmadı ya da dosya bozuk
                _oturumu_kosur(durum)
                continue
            ilk_acilis = False

            _acilis_ekrani()
            if adet == 0:
                ekran.hata("Hiç görev içeriği bulunamadı (oyun/icerik klasörü boş?).")
            # Kayıt varsa "devam et" ÜSTTE durur; yeni sefer ilk sırada
            # olduğu için kazara seçilmesin. Seçenek SAYISI değişmiyor:
            # çıkış her durumda 4. sırada kalsın.
            if kayitlar:
                satirlar = [("Kayıtlı sefere devam et", "bıraktığın yerden"),
                            ("Yeni sefer", "baştan başla")]
                devam_secimi, yeni_secimi = 0, 1
            else:
                satirlar = [("Yeni sefer", "baştan başla"),
                            ("Kayıtlı sefere devam et", "")]
                devam_secimi, yeni_secimi = 1, 0
            secim = ekran.menu("", satirlar + [("Nasıl oynanır", ""), ("Çık", "")],
                               gizli=("öğretmen",))
            if secim == yeni_secimi:
                if kayitlar and not _yeni_sefer_onayi(kayitlar):
                    continue
                durum = _yeni_oyun()
            elif secim == devam_secimi:
                durum = _kayit_sec()
            elif secim == 2:
                _nasil_oynanir()
                continue
            elif secim == ekran.GIZLI_SECIM:
                # Öğretmen araçları bugüne kadar yalnızca komut satırındaydı;
                # okulda kimse terminal açmıyor. Bkz. araclar/ogretmen.py
                # Giriş menüde YAZMIYOR (kullanıcı, 11 Eylül 2026): öğrenci
                # öğretmen masasının varlığını görmesin. Seçim satırına
                # "öğretmen" yazılınca açılır. Koruma bu değil, parola.
                from araclar.ogretmen import ogretmen_girisi
                ogretmen_girisi()
                continue
            else:
                return

            if durum is not None:
                _oturumu_kosur(durum)
    except OyunuBirak:
        ekran.yaz()
        ekran.yaz("Görüşürüz, kâşif.", "acik_cam")
    except Exception as sorun:                  # noqa: BLE001
        # Menülerde ya da kayıt seçiminde çıkan hata. Buraya düşmek
        # oyunun kapanması demek; en azından sebebi kaydedilsin.
        cokme.ele(sorun, nerede="ana menü")


def _nasil_oynanir() -> None:
    ekran.temizle()
    ekran.baslik("NASIL OYNANIR", "kalin", "acik_cam")
    ekran.kutu(
        "Her görev bir olayla başlar. Sana \"x'i bul\" denmez; bir aksaklık "
        "anlatılır.\n\n"
        "1. BRİFİNG'i oku. Neyin bilinmediğini kendin fark etmen gerekiyor.\n"
        "2. KAYNAKLARI incele. Her inceleme dikkat harcar, hepsini açmak "
        "zorunda değilsin.\n"
        "3. MODELLEME adımında olayı hangi bağıntının anlattığını seçersin. "
        "Bu adım, çözümün nedenini kurduğun yerdir.\n"
        "4. ÇÖZÜM adımında sayıyı ya da cevabı yazarsın.\n\n"
        "İlk denemede ipucusuz bulmak tam puandır. İpucu ve fazladan deneme "
        "puanı düşürür ama seni durdurmaz - amaç not değil, öğrenmek.",
        "", "beyaz")
    ekran.yaz()
    ekran.yaz("Soru içindeyken kullanabileceğin komutlar:", "kalin")
    for harf, aciklama in [("k", "kanıtları incele"), ("i", "ipucu"),
                           ("b", "brifingi tekrar oku"), ("d", "defterim"),
                           ("x", "görevden çekil")]:
        ekran.madde("{} = {}".format(ekran.renkli(harf, "acik_sari", "kalin"), aciklama))
    ekran.bekle()
