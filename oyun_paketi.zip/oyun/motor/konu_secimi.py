# -*- coding: utf-8 -*-
"""Ödev oluşturmadan, gözlenen ihtiyaca göre küçük bir seçim önceliği.

1.35 tavanı bir ürün başlangıç ayarıdır; öğrenme etkisi pilotta ölçülür.
Bu katsayı olasılığa 35 puan eklemez; diğer adaylarla birlikte normalize edilir.
"""
from .modeller import ANLATIM

AZAMI_KONU_AGIRLIGI = 1.35


def zorlanmayi_guncelle(durum, sonuc):
    # Anlatımı izlemek, ara vermek ve henüz denememek başarısızlık değildir.
    if (sonuc.asama == ANLATIM or sonuc.birakildi or not sonuc.tamamlandi
            or not sonuc.adim_sonuclari):
        return
    kd = durum.ders(sonuc.ders).konu(sonuc.konu)
    oran = sum(not s.dogru or s.deneme > 1 or s.destek_aldi
               for s in sonuc.adim_sonuclari) / len(sonuc.adim_sonuclari)
    kd.zorlanma = 0.65 * kd.zorlanma + 0.35 * oran
    kd.zorlanma_gozlemi += 1


def zorlanma_duzeyi(kd):
    if kd is None:
        return 0.0
    if kd.zorlanma_gozlemi:
        return max(0.0, min(1.0, kd.zorlanma))
    # Eski kayıtta yalnız gerçekten denenmiş bağımsız dosyalardan çıkarım.
    # Başlangıç ustalığı 0 olduğu için ustalik alanını burada kullanmayız.
    if kd.serbest_toplam > 0:
        return max(0.0, min(1.0, 1 - kd.serbest_dogru / kd.serbest_toplam))
    return 0.0


def konu_agirligi(durum, ders, konu, hatirlama=False):
    kd = durum.ders(ders).konular.get(konu)
    return min(AZAMI_KONU_AGIRLIGI,
               1.0 + 0.35 * zorlanma_duzeyi(kd) + (0.10 if hatirlama else 0.0))


def konu_sec(durum, ders, konular, rastgele, hatirlanacak=()):
    adaylar = sorted(set(konular))
    return rastgele.choices(adaylar, weights=[
        konu_agirligi(durum, ders, k, k in hatirlanacak) for k in adaylar])[0]
