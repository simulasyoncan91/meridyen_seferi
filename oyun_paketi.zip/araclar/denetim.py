# -*- coding: utf-8 -*-
"""
İçerik denetimi.

Her görev üreticisini birçok farklı tohumla çalıştırır ve şunları arar:

  * Bulmaca kendi iç tutarlılık denetiminden geçiyor mu (Bulmaca.dogrula)
  * Doğru cevap, cevap değerlendiricisi tarafından gerçekten doğru sayılıyor mu
  * Şıklarda "yanlış" olması gereken bir şık kazara doğruya eşit mi
  * Aynı şık iki kez yazılmış mı
  * Metinlerde biçim yer tutucusu ({}) unutulmuş mu

Yeni soru yazan herkes şunu çalıştırmalı:

    python main.py --denetle
"""
from __future__ import annotations

import random
import math
from itertools import product
import re
import traceback
from typing import List, Tuple

from oyun.motor.degerlendirme import degerlendir, dogru_cevap_metni, sayi_bicimle
from oyun.motor.kayit_defteri import (
    YUKLEME_HATALARI, icerigi_yukle, sefer_kayitlari, tum_kayitlar,
)
from oyun.motor.modeller import (
    Bulmaca, COKLU, ESLESTIR, METIN, OGRENME_YOLLARI, SAYI, SECIM, SIRALA,
    yol_alanlari,
)

TOHUM_SAYISI = 12


def _cevabi_metne_cevir(adim) -> str:
    """Değerlendiriciyi sınamak için doğru cevabı kullanıcı yazımına çevirir."""
    if adim.tur == SAYI:
        return sayi_bicimle(adim.cevap)
    if adim.tur == SECIM:
        return str(int(adim.cevap) + 1)
    if adim.tur in (COKLU, SIRALA):
        if not len(adim.cevap):
            return "yok"
        return ",".join(str(int(i) + 1) for i in adim.cevap)
    if adim.tur == METIN:
        return adim.cevap[0] if isinstance(adim.cevap, (list, tuple)) else str(adim.cevap)
    if adim.tur == ESLESTIR:
        return ",".join("{}{}".format(i + 1, h) for i, h in enumerate(adim.cevap))
    return str(adim.cevap)


def bulmacayi_denetle(bulmaca: Bulmaca, kaynak: str) -> List[str]:
    try:
        sorunlar = ["{} :: {}".format(kaynak, s) for s in bulmaca.dogrula()]
    except (TypeError, ValueError, IndexError, AttributeError) as hata:
        sorunlar = ["{} :: geçersiz görev yapısı: {}".format(kaynak, hata)]

    def metni_kontrol_et(etiket, metin, zorunlu=True):
        if not isinstance(metin, str) or (zorunlu and not metin.strip()):
            sorunlar.append("{} :: {} boş veya metin değil".format(kaynak, etiket))
            return
        if re.search(r"\{(?:\d*|:[^{}]*|\d+:[^{}]*)\}", metin):
            sorunlar.append("{} :: {} içinde doldurulmamış biçim alanı var".format(kaynak, etiket))
        if "\ufffd" in metin:
            sorunlar.append("{} :: {} içinde bozuk karakter var".format(kaynak, etiket))

    for etiket in ("kod", "konu", "baslik", "brifing", "kazanim", "kapanis"):
        metni_kontrol_et(etiket, getattr(bulmaca, etiket))
    for i, kanit in enumerate(bulmaca.kanitlar, 1):
        metni_kontrol_et("kanıt {} etiketi".format(i), kanit.etiket)
        metni_kontrol_et("kanıt {} içeriği".format(i), kanit.icerik)

    for sira, adim in enumerate(bulmaca.adimlar, 1):
        yer = "{} :: adım {}".format(kaynak, sira)

        # 1) Doğru cevap gerçekten doğru sayılıyor mu?
        for etiket in ("soru", "aciklama"):
            metni_kontrol_et("adım {} {}".format(sira, etiket), getattr(adim, etiket))
        metni_kontrol_et("adım {} çözüm".format(sira), adim.cozum, zorunlu=False)
        for metin in adim.secenekler + adim.ipuclari + list(adim.yanlis_teshis.values()):
            metni_kontrol_et("adım {} şık/ipucu/teşhis".format(sira), metin)
        if adim.tur == SAYI:
            try:
                if (not math.isfinite(float(adim.cevap))
                        or not math.isfinite(float(adim.tolerans)) or adim.tolerans < 0):
                    sorunlar.append("{}: sonlu olmayan cevap veya geçersiz tolerans".format(yer))
                    continue
            except (TypeError, ValueError):
                sorunlar.append("{}: sayı cevabı/toleransı geçersiz".format(yer))
                continue
        try:
            yazim = _cevabi_metne_cevir(adim)
            dogru, _ = degerlendir(adim, yazim)
        except (TypeError, ValueError, IndexError, AttributeError, OverflowError) as hata:
            sorunlar.append("{}: cevap denetlenemedi: {}".format(yer, hata))
            continue
        if not dogru:
            sorunlar.append("{}: doğru cevap ('{}') değerlendirici tarafından "
                            "yanlış sayıldı".format(yer, yazim))

        # 2) Şıklar tekrar ediyor mu?
        if adim.secenekler:
            gorulen = set()
            for secenek in adim.secenekler:
                anahtar = " ".join(str(secenek).lower().split())
                if anahtar in gorulen:
                    sorunlar.append("{}: aynı şık iki kez yazılmış -> {}".format(yer, secenek))
                gorulen.add(anahtar)

        # 3) Biçimlendirme yer tutucusu unutulmuş mu?
        for etiket, metin in [("soru", adim.soru), ("açıklama", adim.aciklama)]:
            if "{}" in str(metin) or "{:" in str(metin):
                sorunlar.append("{}: {} içinde doldurulmamış {{}} var".format(yer, etiket))

        # 4) İpuçları cevabı doğrudan söylüyor mu?
        # Alt dize araması yetmez: cevap 10 iken "1000 mikrometre" yazan masum
        # bir ipucu yakalanır. Bu yüzden sayının başında ve sonunda başka rakam
        # olmadığını arıyoruz.
        if adim.tur == SAYI and adim.ipuclari:
            cevap_metni = sayi_bicimle(adim.cevap)
            if cevap_metni:
                kalip = re.compile(r"(?<![\d,.])" + re.escape(cevap_metni) + r"(?![\d,.])")
                for ipucu in adim.ipuclari[:-1]:
                    if kalip.search(ipucu):
                        sorunlar.append("{}: ilk ipuçları cevabı ({}) doğrudan "
                                        "söylüyor".format(yer, cevap_metni))

        # 5) Yanlış teşhisi doğru cevaba yapışmış mı?
        # Bir yanlış teşhisi doğru cevapla eşleşirse öğrenci doğruyu bulduğu
        # hâlde "şunu karıştırdın" cümlesini görür; bu, teşhis mekanizmasının
        # güvenini tek seferde bitirir.
        # Yalnızca yazarak cevaplanan adımlarda anlamlı: şıklı adımda cevap
        # numarayla verilir, teşhis anahtarı ise şık metnidir; ikisi aynı
        # dilde değil. Şıklı adımların denetimi bir alttaki kuralda.
        for anahtar in (adim.yanlis_teshis or {}) if adim.tur in (SAYI, METIN) else ():
            if anahtar == "*":
                continue
            eslesti, _ = degerlendir(adim, str(anahtar))
            if eslesti:
                sorunlar.append("{}: yanlış teşhisi doğru cevabı işaret "
                                "ediyor -> {}".format(yer, anahtar))

        # 6) Şıklı adımda teşhis anahtarı gerçekten bir şık mı?
        if adim.secenekler and adim.yanlis_teshis:
            for anahtar in adim.yanlis_teshis:
                if anahtar != "*" and anahtar not in adim.secenekler:
                    sorunlar.append("{}: teşhis anahtarı şıklar arasında yok "
                                    "-> {}".format(yer, anahtar))

        if adim.tur == SECIM and isinstance(adim.cevap, int) and 0 <= adim.cevap < len(adim.secenekler):
            if adim.secenekler[adim.cevap] in adim.yanlis_teshis:
                sorunlar.append("{}: doğru şık yanlış teşhisiyle işaretlenmiş".format(yer))

        # 7) Metin cevabı boş olmasın
        if adim.tur == METIN:
            cevaplar = adim.cevap if isinstance(adim.cevap, (list, tuple)) else [adim.cevap]
            if not all(str(c).strip() for c in cevaplar):
                sorunlar.append("{}: boş metin cevabı".format(yer))

    if "{}" in bulmaca.brifing:
        sorunlar.append("{} :: brifing içinde doldurulmamış {{}} var".format(kaynak))

    return sorunlar


def tumunu_denetle(tohum_sayisi: int = TOHUM_SAYISI, ayrintili: bool = True,
                   ders: str = "") -> bool:
    icerigi_yukle()
    kayitlar = [k for k in tum_kayitlar() if not ders or k.ders == ders]

    if YUKLEME_HATALARI:
        print()
        print("MODUL YUKLENEMEDI:")
        for modul, mesaj in YUKLEME_HATALARI:
            print("  ! oyun/icerik/{}.py -> {}".format(modul, mesaj))
    if not kayitlar:
        print("Hiç görev üreticisi kayıtlı değil.")
        return False

    toplam_uretim = 0
    tum_sorunlar: List[str] = []
    ders_sayaci = {}

    for kayit in kayitlar:
        ders_sayaci[kayit.ders] = ders_sayaci.get(kayit.ders, 0) + 1
        alt, ust = kayit.kademeler
        kademeler = range(alt, ust + 1)
        for kademe in kademeler:
            for tohum in range(tohum_sayisi):
                kaynak = "{}.{} k{} t{}".format(kayit.ders, kayit.ad, kademe, tohum)
                try:
                    bulmaca = kayit.fonksiyon(random.Random(tohum * 7919 + kademe), kademe)
                except Exception:
                    tum_sorunlar.append("{}: ÜRETİM HATASI\n{}".format(
                        kaynak, traceback.format_exc(limit=3)))
                    continue
                if bulmaca is None:
                    tum_sorunlar.append("{}: üretici None döndü".format(kaynak))
                    continue
                toplam_uretim += 1
                try:
                    tum_sorunlar.extend(bulmacayi_denetle(bulmaca, kaynak))
                except Exception as hata:
                    tum_sorunlar.append("{}: DENETİM HATASI: {}".format(kaynak, hata))

    # ---------------------------------------------------------- seferler
    sefer_sayisi = 0
    if not ders:
        for kayit in sefer_kayitlari():
            for kademe, tohum in product(range(kayit.kademeler[0], kayit.kademeler[1] + 1),
                                          range(max(3, tohum_sayisi // 3))):
                kaynak = "sefer.{} k{} t{}".format(kayit.kod, kademe, tohum)
                try:
                    sefer_nesnesi = kayit.fonksiyon(
                        random.Random(tohum * 6151 + kademe), kademe)
                except Exception:
                    tum_sorunlar.append("{}: ÜRETİM HATASI\n{}".format(
                        kaynak, traceback.format_exc(limit=3)))
                    continue
                if sefer_nesnesi is None:
                    tum_sorunlar.append("{}: üretici None döndü".format(kaynak))
                    continue
                sefer_sayisi += 1
                tum_sorunlar.extend(
                    "{} :: {}".format(kaynak, h) for h in sefer_nesnesi.dogrula())
                for bolum in sefer_nesnesi.bolumler:
                    tum_sorunlar.extend(bulmacayi_denetle(
                        bolum, "{}/{}".format(kaynak, bolum.ders)))

    print()
    print("DENETİM SONUCU")
    print("-" * 60)
    print("Üretici sayısı : {}".format(len(kayitlar)))
    if not ders:
        for yol, bilgi in OGRENME_YOLLARI.items():
            adet = sum(ders_sayaci.get(alan, 0) for alan in yol_alanlari(yol))
            print("   {:<20} {}".format(bilgi["ad"], adet))
    else:
        print("   Seçilen iç alan   {}".format(sum(ders_sayaci.values())))
    print("Üretilen görev : {}".format(toplam_uretim))
    if sefer_sayisi:
        print("Üretilen sefer : {}  ({} tanım)".format(
            sefer_sayisi, len(sefer_kayitlari())))
    print("Bulunan sorun  : {}".format(len(tum_sorunlar)))
    print("-" * 60)

    if tum_sorunlar and ayrintili:
        gosterilen = tum_sorunlar[:60]
        for sorun in gosterilen:
            print("  ! " + sorun)
        if len(tum_sorunlar) > len(gosterilen):
            print("  ... ve {} sorun daha".format(len(tum_sorunlar) - len(gosterilen)))

    if not tum_sorunlar and not YUKLEME_HATALARI:
        print("Üretilen örnekler teknik kontrollerden geçti. Bu sonuç, soru mantığı veya MEB uygunluğu onayı değildir.")
    return not tum_sorunlar and not YUKLEME_HATALARI


if __name__ == "__main__":
    import sys as _sys
    _ders = _sys.argv[1] if len(_sys.argv) > 1 else ""
    raise SystemExit(0 if tumunu_denetle(ders=_ders) else 1)
