# -*- coding: utf-8 -*-
"""
Coğrafya görevleri.

Bu derste coğrafya bilgisi ezber olarak değil, BİR KARARIN GEREKÇESİ olarak
sorulur. Öğrenci "eğim nedir" sorusuna cevap vermez; kampın nereye kurulacağına
karar verir ve o kararı eğimle savunur.

Üssün coğrafya işleri: ikinci kampın yeri, haritanın ölçeği, arazinin eğimi,
suyun ne kadar dayanacağı, saat farkı, yön bulma.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    MEVKI_ADLARI, PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi,
    secim_adimi, sy, yorum_adimi,
)


# ==========================================================================
# YERLEŞME VE ARAZİ
# ==========================================================================

@bulmaca(ders="cografya", konu="yerlesme_secimi", kademeler=(4, 10), agirlik=1.5)
def kamp_yeri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Dört aday mevki, ölçüm kartları ve bir yönetmelik.

    Tuzak şu: en düz ve suya en yakın mevki, dere yatağının içindedir. Öğrenci
    "en iyi sayıyı" değil, "eleyici ölçütü" aramayı öğrenir.
    """
    adlar = ad_sec(rastgele, MEVKI_ADLARI, 4)
    azami_egim = rastgele.choice([12, 15, 18])
    azami_su = rastgele.choice([400, 500, 600])

    # Dört aday: biri uygun, üçü birer kuralı ihlal ediyor.
    dogru = {
        "ad": adlar[0],
        "egim": rastgele.randrange(4, azami_egim - 2),
        "su": rastgele.randrange(120, azami_su - 80),
        "dere": False,
        "kusur": None,
    }
    tuzak = {  # en düz, suya en yakın - ama dere yatağında
        "ad": adlar[1],
        "egim": rastgele.randrange(1, 4),
        "su": rastgele.randrange(20, 80),
        "dere": True,
        "kusur": "dere yatağının içinde",
    }
    dik = {
        "ad": adlar[2],
        "egim": azami_egim + rastgele.randrange(6, 18),
        "su": rastgele.randrange(150, azami_su - 50),
        "dere": False,
        "kusur": "eğim sınırın üstünde",
    }
    uzak = {
        "ad": adlar[3],
        "egim": rastgele.randrange(3, azami_egim - 3),
        "su": azami_su + rastgele.randrange(200, 700),
        "dere": False,
        "kusur": "suya uzaklık sınırın üstünde",
    }

    # Elenen her mevki için, o kusuru gözden kaçıran öğrenciye söylenecek söz.
    kusur_teshisleri = {
        "dere yatağının içinde":
            "Ölçüm sayılarına bakıp zemin notunu atladın. Bu mevki en düz ve "
            "suya en yakın olan; yönetmeliğin üçüncü maddesi ise dere "
            "yatağını sayı tartışmasına hiç sokmadan eliyor.",
        "eğim sınırın üstünde":
            "Bu mevkinin eğimi yönetmeliğin koyduğu tavanın üstünde. Suya "
            "uzaklığı ve zemini uygun olsa da tek bir madde ihlali elemeye "
            "yeter.",
        "suya uzaklık sınırın üstünde":
            "Bu mevkinin zemini ve eğimi uygun, ama en yakın su kaynağı "
            "yönetmeliğin izin verdiğinden daha uzakta. Ölçütler tek tek "
            "uygulanır; birinden kalan mevki listeden çıkar.",
    }

    mevkiler = [dogru, tuzak, dik, uzak]
    rastgele.shuffle(mevkiler)
    secenekler = [m["ad"] for m in mevkiler]
    dogru_indeks = secenekler.index(dogru["ad"])
    elenecekler = sorted(i for i, m in enumerate(mevkiler) if m["kusur"])

    olcum_kartlari = []
    for m in mevkiler:
        olcum_kartlari.append(Kanit(
            "Ölçüm kartı - {}".format(m["ad"]),
            "Ortalama eğim: %{}\nEn yakın suya uzaklık: {} m\nZemin: {}".format(
                m["egim"], m["su"],
                "dere yatağı tabanı, ince kum ve çakıl" if m["dere"]
                else "sıkı toprak, taşlı"),
            bedel=1,
            kritik=True,
        ))

    return Bulmaca(
        kod="cog-kamp-yeri",
        ders="cografya",
        baslik="İkinci Kamp",
        kademe=kademe,
        konu="yerlesme_secimi",
        kazanim="Yerleşme yeri seçiminde doğal etmenler; ölçütleri sıralayarak karar verme.",
        dikkat=7,
        brifing=(
            "Üs küçük geliyor; komutan ikinci bir kamp kurmak istiyor ve yer "
            "seçimini sana bırakıyor.\n\n"
            "Keşif ekibi dört mevki gezmiş: {}. Her mevki için eğim ve suya "
            "uzaklık ölçmüşler, zemin notu düşmüşler. Ama hangisinin uygun "
            "olduğuna karar vermemişler; \"sayılar burada, kararı sen ver\" "
            "demişler.\n\n"
            "Yanlış yer seçilirse bunu ilk yağmurda ya da ilk kışta anlarız."
        ).format(", ".join(secenekler)),
        kanitlar=olcum_kartlari + [
            Kanit("Kamp yönetmeliği",
                  "1) Ortalama eğim %{}'i geçmeyecek.\n"
                  "2) En yakın su kaynağı {} metreden uzak olmayacak.\n"
                  "3) Kamp DERE YATAĞINA kurulmaz. Yatak kuru görünse de "
                  "kurulmaz.".format(azami_egim, azami_su),
                  bedel=2, kritik=True),
            Kanit("Bölge yağış kaydı",
                  "İlkbaharda kar erimesiyle dereler birkaç saat içinde "
                  "kabarır. Kuru yataklar bu saatlerde tamamen dolar.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu dört mevkiyi değerlendirirken hangi yaklaşım doğru?",
                dogru=("Önce yönetmeliği ihlal eden mevkiler elenir; kalanlar "
                       "arasından seçim yapılır."),
                yanlislar={
                    "Eğimi en küçük olan mevki seçilir.":
                        "Tek bir ölçüte bakıp karar verdin. Eğim, "
                        "yönetmeliğin üç maddesinden yalnızca biri; en düz "
                        "yer pekâlâ dere yatağının tabanı olabilir.",
                    "Suya en yakın mevki seçilir.":
                        "Yönetmeliği bir yarışma ölçütü gibi okudun. Madde "
                        "\"en yakını seç\" demiyor, bir ÜST SINIR koyuyor; "
                        "sınırın içinde kalan her mevki bu maddeden geçer.",
                    "Dört mevkinin eğim ve uzaklık ortalaması alınır, ortalamaya "
                    "en yakın mevki seçilir.":
                        "Ortalama, kural çiğneyen mevkileri de hesaba katar "
                        "ve onların kusurunu diğerlerinin içinde eritir. "
                        "Eleyici bir ölçüt ortalamayla yumuşatılamaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yerleşme kararı bir 'en iyi sayıyı bulma' işi değildir. Önce "
                    "ELEYİCİ ölçütler uygulanır: bir mevki tek bir kuralı bile "
                    "çiğniyorsa, diğer özellikleri ne kadar iyi olursa olsun listeden "
                    "çıkar. Ancak kalanlar arasında 'daha iyi/daha kötü' tartışılır."
                ),
                ipuclari=[
                    "Yönetmelikteki maddeler tavsiye mi, şart mı?",
                    "Bir mevki tek bir kuralı çiğniyorsa diğer üstünlükleri onu kurtarır mı?",
                ],
                puan=18,
            ),
            coklu_adimi(
                soru="Hangi mevkiler yönetmeliğe göre elenmeli? (numaraları yaz)",
                secenekler=secenekler,
                dogru_indeksler=elenecekler,
                aciklama=(
                    "Elenenler ve gerekçeleri: " + "; ".join(
                        "{} ({})".format(m["ad"], m["kusur"]) for m in mevkiler if m["kusur"]
                    ) + ". Geriye tek uygun mevki kalır: " + dogru["ad"] + "."
                ),
                ipuclari=[
                    "Üç maddeyi dört karta tek tek uygula.",
                    "Zemin notunu okumayı unutma; sayılar iyi görünse de zemin eleyebilir.",
                ],
                puan=18,
            ),
            secim_adimi(
                soru="Kamp nereye kurulacak?",
                dogru=dogru["ad"],
                yanlislar={m["ad"]: kusur_teshisleri[m["kusur"]]
                           for m in mevkiler if m["kusur"]},
                rastgele=rastgele,
                aciklama=(
                    "{}: eğim %{} (sınır %{}), suya uzaklık {} m (sınır {} m), zemin "
                    "sıkı toprak. Üç maddeyi de sağlayan tek mevki."
                ).format(dogru["ad"], dogru["egim"], azami_egim, dogru["su"], azami_su),
                ipuclari=["Elemeden sonra geriye kaç mevki kaldı?"],
                puan=14,
            ),
            yorum_adimi(
                soru=("{} en düz zemine ve en yakın suya sahipti. Neden "
                      "seçilmedi?").format(tuzak["ad"]),
                dogru=("Dere yatağının içinde olduğu için; kar erimesinde yatak "
                       "birkaç saatte dolar ve kamp sular altında kalır."),
                yanlislar={
                    "Eğimi fazla olduğu için.":
                        "Ölçüm kartlarını karıştırdın. Bu mevkinin eğimi "
                        "tam tersine dördü arasındaki en küçüğüydü; onu "
                        "eleyen şey eğim değil, üstünde durduğu zemin.",
                    "Suya çok yakın olmak her zaman kötüdür, nem yapar.":
                        "Suya yakınlık bir kusur değil, yönetmeliğin aradığı "
                        "şart. Eleyen şey suyun yakın olması değil, kampın "
                        "suyun GEÇTİĞİ yatağa kurulacak olması.",
                    "Ölçümü yapılmadığı için.":
                        "Bu mevkinin ölçüm kartı da var ve okundu. Mevki "
                        "bilgi eksikliğinden değil, okunan zemin notunun "
                        "kendisi yüzünden elendi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Dere yatağı tam da düz ve suya yakın OLDUĞU için caziptir; "
                    "tehlikesi de buradan gelir. Yatağı düzleştiren şey, yıllar "
                    "boyunca oradan geçen sudur. Kuru görünmesi, suyun bir daha "
                    "gelmeyeceği anlamına gelmez."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Kamp {} mevkiine kuruldu. İlkbaharda dere kabardığında {} "
            "mevkiindeki eski ocak taşları suyun altında kaldı; kimse orada değildi."
        ).format(dogru["ad"], tuzak["ad"]),
        odul={"erzak": 6, "cevher": 6, "itibar": 6},
    )


@bulmaca(ders="cografya", konu="harita_olcek", kademeler=(5, 10))
def harita_olcegi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Haritanın ölçeği yazmıyor; bilinen bir mesafeden çıkarılacak."""
    olcek_km = rastgele.choice([2, 4, 5, 10])          # 1 cm kaç km
    bilinen_cm = rastgele.choice([3, 4, 5, 6])
    bilinen_km = bilinen_cm * olcek_km
    olculen_cm = rastgele.choice([7, 8, 9, 11, 12])
    hedef_km = olculen_cm * olcek_km
    payda = olcek_km * 100000
    mevkiler = ad_sec(rastgele, MEVKI_ADLARI, 3)

    return Bulmaca(
        kod="cog-harita-olcek",
        ders="cografya",
        baslik="Ölçeksiz Harita",
        kademe=kademe,
        konu="harita_olcek",
        kazanim="Harita ölçeği; harita uzunluğundan gerçek uzunluğa geçiş.",
        dikkat=5,
        brifing=(
            "Arşivde bulunan bölge haritasının alt kenarı yırtılmış; ölçek "
            "tam oradaymış.\n\n"
            "Harita işe yarar durumda: yollar, dereler, mevkiler okunuyor. "
            "Sefer ekibi {} ile {} arası mesafeyi soruyor ve cetvelle "
            "haritada ölçtükleri {} santimetreden başka bilgileri yok.\n\n"
            "Neyse ki üs ile {} arasındaki gerçek mesafeyi biliyoruz."
        ).format(mevkiler[0], mevkiler[1], olculen_cm, mevkiler[2]),
        kanitlar=[
            Kanit("Eski yol kaydı",
                  "Üs ile {} arası kara yoluyla değil, kuş uçuşu {} "
                  "kilometredir.".format(mevkiler[2], bilinen_km),
                  bedel=2, kritik=True),
            Kanit("Cetvel ölçümü - 1",
                  "Haritada üs ile {} arası: {} cm".format(mevkiler[2], bilinen_cm),
                  bedel=1, kritik=True),
            Kanit("Cetvel ölçümü - 2",
                  "Haritada {} ile {} arası: {} cm".format(
                      mevkiler[0], mevkiler[1], olculen_cm),
                  bedel=1, kritik=True),
            Kanit("Harita kenarı",
                  "Ölçek yazan şerit yırtılmış. Kuzey oku ve lejant sağlam.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Haritanın ölçeğini nasıl buluruz?",
                dogru=("Gerçek mesafeyi, haritadaki uzunluğa böleriz: 1 cm'nin "
                       "karşılığı çıkar."),
                yanlislar={
                    "Haritadaki uzunluğu gerçek mesafeye böleriz.":
                        "Bölmeyi ters kurdun. Bu bölme, gerçekteki 1 "
                        "kilometrenin haritada kaç santimetre olduğunu "
                        "verir; sorulan ise haritadaki 1 santimetrenin "
                        "gerçekte ne kadar ettiği.",
                    "Gerçek mesafe ile haritadaki uzunluğu çarparız.":
                        "Çarpma iki uzunluğu birleştirir, birini diğerine "
                        "oranlamaz. Ölçek bir orandır; oran bölmeyle kurulur.",
                    "İki mesafenin farkını alırız.":
                        "Fark, farklı birimdeki iki sayıyı çıkarmak olurdu: "
                        "kilometreden santimetre. Ölçek, aradaki eksikliği "
                        "değil, birinin diğerinin kaç katı olduğunu söyler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ölçek, 'haritadaki 1 birim gerçekte kaç birimdir' sorusunun "
                    "cevabıdır. Bunu bulmak için gerçek uzunluğu harita uzunluğuna "
                    "böleriz. Ters bölme, gerçekte 1 km'nin haritada kaç cm olduğunu "
                    "verir; bu da kullanılabilir ama sonra ters çevirmeyi unutturur."
                ),
                ipuclari=[
                    "Ölçek bir ORANDIR: harita üzerindeki 1 cm neye karşılık geliyor?",
                    "Bilinen çifti kullan: {} cm kaç km ediyorsa, 1 cm onun "
                    "bölünmüşü eder.".format(bilinen_cm),
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="Haritada 1 santimetre kaç kilometreye karşılık geliyor?",
                cevap=olcek_km,
                birim="km",
                aciklama="{} km ÷ {} cm = {} km/cm.".format(bilinen_km, bilinen_cm, olcek_km),
                yaygin_yanlislar={
                    bilinen_km:
                        "Bilinen gerçek mesafeyi olduğu gibi yazdın. O sayı "
                        "haritadaki {} santimetrenin karşılığı; sorulan ise "
                        "tek bir santimetrenin karşılığı.".format(bilinen_cm),
                    bilinen_cm / float(bilinen_km):
                        "Bölmeyi ters kurdun; haritadaki uzunluğu gerçek "
                        "mesafeye böldün. Bu sana 1 kilometrenin haritada "
                        "kaç santimetre olduğunu verir.",
                },
                ipuclari=["Bilinen gerçek mesafeyi, haritadaki uzunluğuna böl."],
                puan=12,
            ),
            sayi_adimi(
                soru="{} ile {} arası gerçekte kaç kilometre?".format(mevkiler[0], mevkiler[1]),
                cevap=hedef_km,
                birim="km",
                aciklama="{} cm × {} km/cm = {} km.".format(olculen_cm, olcek_km, hedef_km),
                yaygin_yanlislar={
                    olculen_cm:
                        "Haritada ölçülen uzunluğu yazdın. O sayı santimetre "
                        "cinsinden; gerçeğe geçmek için 1 cm'nin karşılığıyla "
                        "çarpman gerekiyor.",
                    olculen_cm / float(olcek_km):
                        "Çarpmak yerine böldün. Harita gerçeği küçültür; "
                        "haritadan gerçeğe giderken sayı büyümeli.",
                },
                ipuclari=["Ölçülen uzunluğu, 1 cm'nin karşılığıyla çarp."],
                puan=12,
            ),
            secim_adimi(
                soru="Bu haritanın kesir ölçeği aşağıdakilerden hangisidir?",
                dogru="1 / {}".format(payda),
                yanlislar={
                    "1 / {}".format(olcek_km * 1000):
                        "Kilometreyi metreye çevirip orada durdun. Kesir "
                        "ölçekte payda santimetre cinsindendir; metrede "
                        "bırakırsan ölçek yüz kat küçük görünür.",
                    "1 / {}".format(olcek_km * 10000):
                        "Çevrimin bir basamağını atladın. 1 metre 100 "
                        "santimetre, 1 kilometre 1.000 metre; ikisini "
                        "birlikte uygularsan sondaki sıfır sayısı değişir.",
                    "1 / {}".format(payda * 10):
                        "Bir sıfır fazla saydın. 1 kilometre 100.000 "
                        "santimetredir; oradaki sıfırları tek tek say.",
                },
                rastgele=rastgele,
                aciklama=(
                    "1 cm = {} km demek, 1 cm = {} cm demektir (1 km = 100.000 cm). "
                    "Kesir ölçek birimsizdir: pay ve payda aynı birimde olmalıdır."
                ).format(olcek_km, payda),
                ipuclari=[
                    "Kesir ölçekte pay ve payda AYNI birimdedir; km'yi cm'ye çevir.",
                    "1 km kaç santimetredir?",
                ],
                puan=12,
            ),
        ],
        kapanis=(
            "Haritanın kenarına ölçek elle yazıldı: 1 / {}. Bir daha kimsenin "
            "cetvelle uğraşması gerekmeyecek."
        ).format(payda),
        odul={"itibar": 5, "enerji": 3},
    )


@bulmaca(ders="cografya", konu="iklim", kademeler=(6, 11))
def yukselti_sicaklik(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İki istasyon arasındaki sıcaklık farkından yükselti farkı çıkarılacak."""
    alt_yukselti = rastgele.choice([200, 300, 400, 500])
    fark_yukselti = rastgele.choice([600, 800, 1000, 1200, 1400])
    ust_yukselti = alt_yukselti + fark_yukselti
    alt_sicaklik = rastgele.choice([18, 20, 22, 24])
    sicaklik_farki = fark_yukselti / 100.0 * 0.5
    ust_sicaklik = alt_sicaklik - sicaklik_farki
    mevkiler = ad_sec(rastgele, MEVKI_ADLARI, 2)

    return Bulmaca(
        kod="cog-yukselti-sicaklik",
        ders="cografya",
        baslik="İki İstasyon",
        kademe=kademe,
        konu="iklim",
        kazanim="Yükseltiye bağlı sıcaklık değişimi; sıcaklık farkından yükselti çıkarma.",
        dikkat=6,
        brifing=(
            "Üssün iki hava istasyonu var: biri {} mevkiinde vadi tabanında, "
            "diğeri {} mevkiinde yamaçta.\n\n"
            "Vadi istasyonunun yükseltisi biliniyor: {} metre. Yamaç "
            "istasyonunun yükseltisi ise kayıtlarda yok - kuran ekip yazmayı "
            "unutmuş.\n\n"
            "Yamaç istasyonuna kışın erzak taşınacak; hangi yükseltide olduğunu "
            "bilmemiz gerekiyor, kar sınırı hesabı buna bağlı."
        ).format(mevkiler[0], mevkiler[1], alt_yukselti),
        kanitlar=[
            Kanit("Vadi istasyonu kaydı",
                  "Yükselti: {} m\nAynı gün, aynı saat sıcaklık: {} °C".format(
                      alt_yukselti, sy(alt_sicaklik)),
                  bedel=1, kritik=True),
            Kanit("Yamaç istasyonu kaydı",
                  "Yükselti: (yazılmamış)\nAynı gün, aynı saat sıcaklık: {} °C".format(
                      sy(ust_sicaklik)),
                  bedel=1, kritik=True),
            Kanit("Meteoroloji el kitabı",
                  "\"Troposferde hava, yükseldikçe her 100 metrede ortalama "
                  "0,5 °C soğur. Hesaplarda bu değer kullanılır.\"",
                  bedel=2, kritik=True),
            Kanit("Gözlem notu",
                  "İki ölçüm aynı gün, aynı saatte alınmış. Hava açık, iki "
                  "istasyon da aynı yamaçta ve aynı bakıda.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Yamaç istasyonunun yükseltisini bulmak için hangi yol doğru?",
                dogru=("Sıcaklık farkı bulunur; her 0,5 °C bir 100 metreye "
                       "karşılık geldiği için fark 0,5'e bölünüp 100 ile çarpılır."),
                yanlislar={
                    "Sıcaklık farkı doğrudan 100 ile çarpılır.":
                        "Bir adımı atladın: her 100 metrede düşen 1 °C değil, "
                        "0,5 °C. Farkı doğrudan 100 ile çarparsan yükseltiyi "
                        "olması gerekenin yarısı bulursun.",
                    "Sıcaklık farkı 0,5 ile çarpılıp 100 ile çarpılır.":
                        "Bölmen gereken yerde çarptın. 0,5 ile çarpmak farkı "
                        "küçültür; oysa her yarım derecelik düşüş için bir "
                        "100 metre saymalısın.",
                    "İki sıcaklığın ortalaması alınıp vadi yükseltisine eklenir.":
                        "Ortalama iki ölçümün ortasını verir, aralarındaki "
                        "farkı değil. Yükseltiyi belirleyen şey sıcaklıkların "
                        "ortası değil, aradaki düşüş miktarı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kural şu: 100 metre çıkınca 0,5 °C düşer. O hâlde 1 °C düşüş "
                    "200 metreye karşılık gelir. Sıcaklık farkını önce 0,5'e bölüp "
                    "kaç tane '100 metrelik basamak' olduğunu buluyoruz, sonra 100 "
                    "ile çarpıyoruz. Doğrudan 100 ile çarpmak sonucu yarıya düşürür."
                ),
                ipuclari=[
                    "1 °C sıcaklık düşüşü kaç metreye karşılık gelir?",
                    "Önce kaç tane 0,5 °C'lik basamak olduğunu bul.",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="İki istasyon arasındaki sıcaklık farkı kaç °C?",
                cevap=sicaklik_farki,
                birim="°C",
                aciklama="{} − {} = {} °C.".format(
                    sy(alt_sicaklik), sy(ust_sicaklik), sy(sicaklik_farki)),
                yaygin_yanlislar={
                    -sicaklik_farki:
                        "Çıkarmayı ters kurdun ve eksi bir fark yazdın. "
                        "Yamaç istasyonu vadiden daha soğuk; büyük olandan "
                        "küçüğü çıkarmalısın.",
                    alt_sicaklik + ust_sicaklik:
                        "İki sıcaklığı topladın. Fark bir toplam değil, iki "
                        "ölçümün arasındaki açıklıktır.",
                },
                ipuclari=["Vadi sıcaklığından yamaç sıcaklığını çıkar."],
                tolerans=0.05,
                puan=10,
            ),
            sayi_adimi(
                soru="Yamaç istasyonu, vadiden kaç metre yüksekte?",
                cevap=fark_yukselti,
                birim="m",
                aciklama="{} ÷ 0,5 = {} basamak; {} × 100 = {} metre.".format(
                    sy(sicaklik_farki), sy(sicaklik_farki / 0.5),
                    sy(sicaklik_farki / 0.5), fark_yukselti),
                yaygin_yanlislar={
                    sicaklik_farki * 100:
                        "0,5'e bölme adımını atladın. Her 100 metrede "
                        "sıcaklık 0,5 °C düşüyor; farkı doğrudan 100 ile "
                        "çarpınca gerçek yükseltinin yarısı çıkar.",
                    sicaklik_farki * 0.5 * 100:
                        "0,5 ile çarptın, oysa ona bölmen gerekiyordu. "
                        "Çarpma basamak sayısını azaltır; sen kaç tane yarım "
                        "derecelik basamak olduğunu arıyorsun.",
                },
                ipuclari=["Farkı 0,5'e böl, çıkanı 100 ile çarp."],
                tolerans=1.0,
                puan=14,
            ),
            sayi_adimi(
                soru="Yamaç istasyonunun deniz seviyesinden yükseltisi kaç metre?",
                cevap=ust_yukselti,
                birim="m",
                aciklama="{} + {} = {} metre.".format(
                    alt_yukselti, fark_yukselti, ust_yukselti),
                yaygin_yanlislar={
                    fark_yukselti:
                        "İki istasyon arasındaki farkı yazdın. Sorulan, "
                        "deniz seviyesinden ölçülen yükselti; vadinin kendi "
                        "yükseltisi de bu sayının içinde olmalı.",
                    alt_yukselti - fark_yukselti:
                        "Farkı çıkardın. Yamaç istasyonu vadiden YÜKSEKTE "
                        "olduğu için bulduğun farkı vadi yükseltisine "
                        "eklemelisin.",
                },
                ipuclari=["Vadi yükseltisine, bulduğun farkı ekle."],
                tolerans=1.0,
                puan=10,
            ),
        ],
        kapanis=(
            "Yamaç istasyonunun künyesine {} metre yazıldı. Kış erzak planı "
            "buna göre yeniden yapıldı."
        ).format(ust_yukselti),
        odul={"enerji": 5, "itibar": 5},
    )


@bulmaca(ders="cografya", konu="yer_sekilleri", kademeler=(7, 12))
def izohips_okuma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Eş yükselti eğrilerinin sıklığından eğim ve akış yönü okunacak."""
    aralik = rastgele.choice([25, 50, 100])
    dar_mesafe = rastgele.choice([100, 150, 200])       # metre, yatayda
    genis_mesafe = dar_mesafe * rastgele.choice([3, 4, 5])
    egri_sayisi = rastgele.choice([4, 5, 6])
    yukselti_farki = aralik * egri_sayisi
    dar_egim = yukselti_farki / (dar_mesafe * egri_sayisi) * 100
    yamaclar = ad_sec(rastgele, MEVKI_ADLARI, 2)

    return Bulmaca(
        kod="cog-izohips",
        ders="cografya",
        baslik="Eğrilerin Dili",
        kademe=kademe,
        konu="yer_sekilleri",
        kazanim="Eş yükselti eğrileri; eğri sıklığından eğimi ve akış yönünü okuma.",
        dikkat=6,
        brifing=(
            "Su borusu hattı için iki yamaçtan biri seçilecek: {} ya da {}.\n\n"
            "Elimizdeki topografya haritasında yamaçlar eş yükselti eğrileriyle "
            "gösterilmiş. Eğriler arasındaki yükselti farkı {} metre. Ama "
            "haritada hiçbir yere \"eğim\" yazmıyor; ekip \"gözle bakınca ikisi "
            "de yamaç işte\" diyor.\n\n"
            "Boru kendi ağırlığıyla akacak, pompa kullanmayacağız. Yanlış yamaç "
            "seçilirse ya su akmaz ya da basınç boruyu patlatır."
        ).format(yamaclar[0], yamaclar[1], aralik),
        kanitlar=[
            Kanit("Harita kesiti - {}".format(yamaclar[0]),
                  "{} eş yükselti eğrisi, yatayda toplam {} metrelik şeride "
                  "sıkışmış.".format(egri_sayisi, dar_mesafe * egri_sayisi),
                  bedel=1, kritik=True),
            Kanit("Harita kesiti - {}".format(yamaclar[1]),
                  "{} eş yükselti eğrisi, yatayda {} metreye yayılmış.".format(
                      egri_sayisi, genis_mesafe * egri_sayisi),
                  bedel=1, kritik=True),
            Kanit("Harita lejantı",
                  "Eş yükselti eğrileri arası fark: {} m. Eğriler aynı "
                  "yükseltideki noktaları birleştirir.".format(aralik),
                  bedel=1, kritik=True),
            Kanit("Mühendis notu",
                  "\"Boru kendi ağırlığıyla akacaksa eğim gerekir, ama fazla "
                  "eğim basıncı aşırı artırır. Orta eğimli yamaç istiyoruz.\"",
                  bedel=2),
        ],
        adimlar=[
            model_adimi(
                soru="Eş yükselti eğrileri arasındaki mesafe neyi gösterir?",
                dogru=("Eğriler birbirine ne kadar yakınsa eğim o kadar diktir; "
                       "aynı yükselti farkı daha kısa yatay mesafede aşılıyordur."),
                yanlislar={
                    "Eğriler birbirine ne kadar yakınsa eğim o kadar azdır.":
                        "İlişkiyi ters kurdun. Eğriler arasındaki yükselti "
                        "farkı her yerde aynı; aynı farkı daha KISA yatay "
                        "mesafede aşmak yamacı dikleştirir.",
                    "Eğriler arası mesafe yükseltiyi gösterir, eğimle ilgisi yoktur.":
                        "Yükseltiyi eğrinin kendi değeri söyler, aralarındaki "
                        "boşluk değil. O boşluk yatayda ölçülür ve dikey "
                        "farkla birlikte eğimi verir.",
                    "Eğri sayısı arttıkça eğim azalır.":
                        "Eğri sayısı tek başına eğimi belirlemez. Aynı sayıda "
                        "eğri geniş bir şeride yayılırsa yamaç yumuşak, dar "
                        "bir şeride sıkışırsa diktir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki eğri arasındaki yükselti farkı sabittir ({} m). Değişen tek "
                    "şey, bu farkı aşmak için gereken YATAY mesafedir. Aynı çıkışı "
                    "daha kısa yolda yapmak, daha dik bir yamaç demektir - tıpkı "
                    "merdiven basamaklarının sıklaşması gibi."
                ).format(aralik),
                ipuclari=[
                    "Eğriler arasındaki yükselti farkı her yerde aynı. Değişen ne?",
                    "Aynı yüksekliğe kısa mesafede çıkmak mı zordur, uzun mesafede mi?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="{} yamacında toplam kaç metre yükselti aşılıyor?".format(yamaclar[0]),
                cevap=yukselti_farki,
                birim="m",
                aciklama="{} eğri × {} m = {} m.".format(egri_sayisi, aralik, yukselti_farki),
                yaygin_yanlislar={
                    aralik:
                        "Tek bir eğri aralığını yazdın. Yamaçta bu aralıktan "
                        "birden çok kez geçiliyor; hepsini saymalısın.",
                    # dar_mesafe ile aralık aynı sayı çıkarsa bu yanlış,
                    # doğru cevapla çakışır; o tohumlarda eklenmiyor.
                    **({dar_mesafe * egri_sayisi:
                        "Yatay mesafeyi yazdın. Sorulan, yamacın yerde "
                        "kapladığı uzunluk değil, tırmanılan DİKEY yükselti."}
                       if dar_mesafe != aralik else {}),
                },
                ipuclari=["Eğri sayısını, eğriler arası farkla çarp."],
                puan=10,
            ),
            sayi_adimi(
                soru=("{} yamacının ortalama eğimi yüzde kaçtır? "
                      "(yükselti farkı ÷ yatay mesafe × 100)").format(yamaclar[0]),
                cevap=dar_egim,
                birim="%",
                aciklama="{} ÷ {} × 100 = %{}.".format(
                    yukselti_farki, dar_mesafe * egri_sayisi, sy(round(dar_egim, 2))),
                yaygin_yanlislar={
                    dar_egim / 100.0:
                        "Yüzle çarpmayı unuttun. Bulduğun oran doğru ama "
                        "ondalık biçimde kaldı; soru eğimi yüzde cinsinden "
                        "istiyor.",
                    # Yatay mesafe ile dikey fark eşitse ters bölme de aynı
                    # sayıyı verir; o tohumlarda bu teşhis eklenmiyor.
                    **({dar_mesafe * egri_sayisi / float(yukselti_farki) * 100:
                        "Bölmeyi ters kurdun: yatay mesafeyi dikey yükseltiye "
                        "böldün. Eğim, dikey yükselmenin yatay mesafeye "
                        "oranıdır."}
                       if dar_mesafe != aralik else {}),
                },
                ipuclari=["Dikey yükselmeyi yatay mesafeye böl, yüzle çarp."],
                tolerans=0.2,
                puan=14,
            ),
            yorum_adimi(
                soru="Boru hattı için hangi yamaç daha uygun?",
                dogru="{}; eğrileri seyrek olduğu için eğimi daha yumuşaktır.".format(yamaclar[1]),
                yanlislar={
                    "{}; eğrileri sık olduğu için su daha hızlı akar.".format(yamaclar[0]):
                        "Sıklığı doğru okudun ama istenen şeyi değil. "
                        "Mühendis en hızlı akışı değil orta eğimi istiyor; "
                        "dik yamaçta hızlanan su boruyu basınçla zorlar.",
                    "İkisi de aynıdır; eğri sıklığı boruyu etkilemez.":
                        "Eğri sıklığı eğimi, eğim de borudaki basıncı "
                        "belirler. İki yamaçta aynı yükselti aşılıyor ama "
                        "aynı diklikte değiller.",
                    "{}; eğriler sıksa yükselti farkı azdır.".format(yamaclar[0]):
                        "Sıklık, aşılan yükselti farkını değiştirmez. İki "
                        "yamaçta da aynı sayıda eğri geçiliyor; değişen tek "
                        "şey bunun kaç metrelik yatay mesafeye yayıldığı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İki yamaçta da aynı yükselti farkı aşılıyor, ama {} bunu çok "
                    "daha uzun yatay mesafede yapıyor; yani eğimi yumuşak. Mühendis "
                    "'orta eğim' istedi: dik yamaçta su hızlanır ve basınç boruyu zorlar."
                ).format(yamaclar[1]),
                puan=12,
            ),
        ],
        kapanis=(
            "Hat {} yamacından geçirildi. Su pompasız aktı, basınç ölçümü "
            "sınırların içinde kaldı."
        ).format(yamaclar[1]),
        odul={"cevher": 6, "enerji": 5},
    )


# ==========================================================================
# KONUM, NÜFUS, KAYNAK
# ==========================================================================

@bulmaca(ders="cografya", konu="koordinat_saat", kademeler=(6, 12))
def boylam_saati(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Telsiz kayıtlarındaki yerel saat farkından boylam farkı çıkarılacak."""
    boylam_farki = rastgele.choice([5, 10, 15, 20, 25, 30])
    dakika_farki = boylam_farki * 4
    us_boylami = rastgele.choice([30, 35, 40, 45])
    dogu_mu = rastgele.choice([True, False])
    karakol_boylami = us_boylami + boylam_farki if dogu_mu else us_boylami - boylam_farki
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="cog-boylam-saat",
        ders="cografya",
        baslik="Telsizdeki Saat",
        kademe=kademe,
        konu="koordinat_saat",
        kazanim="Boylam ve yerel saat ilişkisi; 15 boylam farkı = 1 saat.",
        dikkat=6,
        brifing=(
            "{} karakolu her gün, kendi yerel saatiyle tam öğlen (güneş en "
            "tepedeyken) telsizle bildirim geçiyor.\n\n"
            "Üssümüzde bu bildirim, bizim yerel saatimizle öğlenden {} dakika "
            "{} geliyor. Telsiz anlıktır; gecikme yok.\n\n"
            "Karakolun boylamı haritada okunamıyor - o köşe yanmış. Üssün "
            "boylamı ise {} derece."
        ).format(mevki, dakika_farki, "önce" if dogu_mu else "sonra", us_boylami),
        kanitlar=[
            Kanit("Telsiz kaydı",
                  "Karakol bildirimi, üssün yerel saatiyle öğlenden {} dakika "
                  "{} alınıyor. Her gün aynı.".format(
                      dakika_farki, "önce" if dogu_mu else "sonra"),
                  bedel=1, kritik=True),
            Kanit("Üs künyesi", "Üssün boylamı: {}° {}".format(
                us_boylami, "Doğu"), bedel=1, kritik=True),
            Kanit("Seyir el kitabı",
                  "\"Dünya 24 saatte 360° döner. Buradan: 15 boylam = 1 saat, "
                  "1 boylam = 4 dakika. Doğudaki yer yerel öğleni ÖNCE yaşar.\"",
                  bedel=2, kritik=True),
            Kanit("Telsizci notu",
                  "\"Bildirim karakolun kendi öğleninde gönderiliyor, bizim "
                  "saatimize göre değil. Sinyal gecikmesi ölçülemeyecek kadar az.\"",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bu saat farkı neyi gösteriyor?",
                dogru=("İki yerin yerel öğlenleri farklı anlarda olduğunu, yani "
                       "farklı boylamlarda bulunduklarını."),
                yanlislar={
                    "Karakolun daha yüksek bir enlemde olduğunu.":
                        "Enlemle boylamı karıştırdın. Yerel saat farkını "
                        "yaratan şey kuzey-güney değil, DOĞU-BATI konumudur.",
                    "Telsiz sinyalinin yolda geciktiğini.":
                        "Farkı iletişim gecikmesine bağladın. Telsiz sinyali "
                        "neredeyse anında ulaşır; buradaki fark saatlerle "
                        "ölçülüyor.",
                    "İki yerin farklı saat dilimi seçtiğini; bu coğrafi değil idari bir farktır.":
                        "Saat dilimleri gerçekten idaridir ama burada "
                        "ölçülen şey yerel öğle vakti - yani güneşin "
                        "gerçek konumu.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yerel öğlen, güneşin o boylam için en tepede olduğu andır. "
                    "İki yer aynı anda öğleni yaşamıyorsa, boylamları farklıdır. "
                    "Enlem farkı gündüz UZUNLUĞUNU değiştirir, öğlen ANINI değil."
                ),
                ipuclari=[
                    "Öğlen, güneşin o yer için en tepede olduğu andır. Neye bağlı?",
                    "Enlem mi boylam mı yerel saati belirler?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="İki yer arasında kaç derecelik boylam farkı var?",
                cevap=boylam_farki,
                birim="derece",
                aciklama="{} dakika ÷ 4 dakika/derece = {}°.".format(
                    dakika_farki, boylam_farki),
                ipuclari=[
                    "1 boylam farkı kaç dakika eder?",
                    "Dakika farkını, bir boylamın karşılığı olan dakikaya böl.",
                ],
                puan=14,
            ),
            secim_adimi(
                soru="Karakol üssün doğusunda mı, batısında mı?",
                dogru="Üssün doğusunda" if dogu_mu else "Üssün batısında",
                yanlislar={
                    ("Üssün batısında" if dogu_mu else "Üssün doğusunda"):
                        "Yönü ters aldın. Güneş doğudan doğar: doğudaki yerde "
                        "öğle vakti DAHA ERKEN olur.",
                    "Aynı boylamda; yalnızca enlemi farklı":
                        "Aynı boylamda olsalardı yerel öğle vakitleri de aynı "
                        "olurdu. Saat farkının kendisi boylam farkının kanıtı.",
                    "Belirlenemez; saat farkı yön hakkında bilgi vermez":
                        "Saat farkı tam da yön bilgisi verir: hangi tarafta "
                        "öğlenin daha erken olduğu, o yerin doğuda mı batıda "
                        "mı olduğunu söyler.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Doğudaki yer güneşi önce görür, yerel öğlenini önce yaşar. "
                    "Karakolun bildirimi kendi öğleninde gönderiliyor ve bize bizim "
                    "öğlenimizden {} ulaşıyor; demek ki karakol {}mızdadır."
                ).format("önce" if dogu_mu else "sonra", "doğu" if dogu_mu else "batı"),
                ipuclari=["Güneş hangi yönden doğar? Öğleni önce kim yaşar?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Karakolun boylamı kaç derecedir?",
                cevap=karakol_boylami,
                birim="derece",
                aciklama="{}° {} {}° = {}°.".format(
                    us_boylami, "+" if dogu_mu else "−", boylam_farki, karakol_boylami),
                ipuclari=["Üssün boylamına, bulduğun farkı doğru yönde uygula."],
                puan=12,
            ),
        ],
        kapanis=(
            "Karakolun boylamı {}° olarak haritaya işlendi. Yanmış köşe artık "
            "sorun değil."
        ).format(karakol_boylami),
        odul={"itibar": 6, "enerji": 4},
    )


@bulmaca(ders="cografya", konu="nufus", kademeler=(5, 10))
def nufus_yogunlugu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kalabalık bölge ile yoğun bölge aynı şey değil."""
    a_nufus = rastgele.randrange(24, 60) * 100
    a_alan = rastgele.choice([200, 300, 400])
    b_alan = rastgele.choice([40, 50, 60])
    b_nufus = rastgele.randrange(10, 20) * 100
    a_yogunluk = a_nufus / a_alan
    b_yogunluk = b_nufus / b_alan
    # B daha az nüfuslu ama daha yoğun olsun
    while b_nufus >= a_nufus or b_yogunluk <= a_yogunluk:
        b_nufus = rastgele.randrange(10, 20) * 100
        b_alan = rastgele.choice([30, 40, 50])
        b_yogunluk = b_nufus / b_alan
        a_yogunluk = a_nufus / a_alan
    bolgeler = ad_sec(rastgele, MEVKI_ADLARI, 2)

    return Bulmaca(
        kod="cog-nufus-yogunlugu",
        ders="cografya",
        baslik="Kalabalık mı, Sıkışık mı?",
        kademe=kademe,
        konu="nufus",
        kazanim="Nüfus yoğunluğu kavramı; nüfus ile yoğunluğu ayırt etme.",
        dikkat=5,
        brifing=(
            "Merkez, iki yerleşim bölgesinden birine sağlık ekibi gönderecek. "
            "Ekip, insanların en sıkışık yaşadığı yere gitmeli: bulaşıcı "
            "hastalık riski orada yüksek.\n\n"
            "{} bölgesinde {} kişi, {} bölgesinde {} kişi yaşıyor. Merkez "
            "\"nüfusu fazla olana gönderin\" diye yazmış.\n\n"
            "Ama sen alanları da görüyorsun ve bir şey dikkatini çekiyor."
        ).format(bolgeler[0], a_nufus, bolgeler[1], b_nufus),
        kanitlar=[
            Kanit("{} sayımı".format(bolgeler[0]),
                  "Nüfus: {} kişi\nYüzölçümü: {} km²".format(a_nufus, a_alan),
                  bedel=1, kritik=True),
            Kanit("{} sayımı".format(bolgeler[1]),
                  "Nüfus: {} kişi\nYüzölçümü: {} km²".format(b_nufus, b_alan),
                  bedel=1, kritik=True),
            Kanit("Sağlık ekibi talimatı",
                  "\"Bulaş riski, kişi SAYISIYLA değil, birim alandaki kişi "
                  "sayısıyla artar. Yoğunluğu yüksek yere öncelik verin.\"",
                  bedel=2, kritik=True),
            Kanit("Merkez yazısı",
                  "\"Nüfusu fazla olan bölgeye gidilsin.\" (alan bilgisi "
                  "merkeze ulaşmamış)", bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="\"İnsanların en sıkışık yaşadığı yer\" hangi hesapla bulunur?",
                dogru="Nüfus ÷ yüzölçümü (birim alana düşen kişi sayısı)",
                yanlislar={
                    "Yüzölçümü ÷ nüfus":
                        "Bölmeyi ters kurdun. Bu, kişi başına düşen ALANı "
                        "verir; sıkışıklık ise birim alana düşen KİŞİ "
                        "sayısıdır.",
                    "Nüfus × yüzölçümü":
                        "Çarptın. Çarpım geniş ve kalabalık bölgeyi en üste "
                        "çıkarır; oysa geniş alan sıkışıklığı azaltır.",
                    "En büyük nüfusa sahip bölge doğrudan seçilir":
                        "Yalnızca nüfusa baktın. Kalabalık bir bölge çok "
                        "genişse insanlar sıkışık yaşamıyor olabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Nüfus yoğunluğu = nüfus ÷ alan. Bu, 1 km²'ye kaç kişi düştüğünü "
                    "söyler. Toplam nüfus 'kaç kişi var' sorusunu yanıtlar; sıkışıklığı "
                    "değil. Geniş bir bölgeye yayılmış kalabalık, dar bir alana "
                    "sıkışmış daha küçük bir topluluktan daha seyrek olabilir."
                ),
                ipuclari=[
                    "Sıkışıklık, kişi sayısına mı yoksa kişi başına düşen yere mi bağlı?",
                    "Aynı sayıda insan iki kat geniş alana yayılırsa ne değişir?",
                ],
                puan=18,
            ),
            sayi_adimi(
                soru="{} bölgesinin nüfus yoğunluğu kaç kişi/km²?".format(bolgeler[0]),
                cevap=a_yogunluk,
                birim="kişi/km²",
                aciklama="{} ÷ {} = {} kişi/km².".format(
                    a_nufus, a_alan, sy(round(a_yogunluk, 2))),
                ipuclari=["Nüfusu alana böl."],
                tolerans=0.5,
                puan=10,
            ),
            sayi_adimi(
                soru="{} bölgesinin nüfus yoğunluğu kaç kişi/km²?".format(bolgeler[1]),
                cevap=b_yogunluk,
                birim="kişi/km²",
                aciklama="{} ÷ {} = {} kişi/km².".format(
                    b_nufus, b_alan, sy(round(b_yogunluk, 2))),
                ipuclari=["Aynı işlemi ikinci bölge için yap."],
                tolerans=0.5,
                puan=10,
            ),
            yorum_adimi(
                soru="Sağlık ekibi nereye gitmeli ve merkezin yazısı neden yanılıyor?",
                dogru=("{} bölgesine; nüfusu daha az olsa da birim alana düşen "
                       "kişi sayısı çok daha yüksek.").format(bolgeler[1]),
                yanlislar={
                    "{} bölgesine; nüfusu fazla olduğu için risk oradadır.".format(bolgeler[0]):
                        "Yine yalnızca nüfusa baktın - merkezin yazısını "
                        "yanıltan tam olarak bu. Bulaş riskini belirleyen "
                        "insanların ne kadar SIKIŞIK yaşadığı.",
                    "İki bölgeye de eşit ekip gönderilmeli; yoğunluk fark etmez.":
                        "Yoğunluğu önemsiz saydın. Aynı sayıda insan, dar bir "
                        "alanda çok daha sık temas eder.",
                    "{} bölgesine; geniş alan hastalığı daha hızlı yayar.".format(bolgeler[0]):
                        "İlişkiyi ters kurdun. Geniş alan teması azaltır; "
                        "yayılmayı hızlandıran şey darlık.",
                },
                rastgele=rastgele,
                aciklama=(
                    "{} bölgesi {} kişiyle daha kalabalık ama {} km²'ye yayılmış "
                    "(≈{} kişi/km²). {} ise {} kişiyi {} km²'ye sığdırmış "
                    "(≈{} kişi/km²). Merkez alan bilgisini görmediği için 'kalabalık' "
                    "ile 'yoğun' kavramlarını karıştırmış."
                ).format(bolgeler[0], a_nufus, a_alan, sy(round(a_yogunluk, 1)),
                         bolgeler[1], b_nufus, b_alan, sy(round(b_yogunluk, 1))),
                puan=14,
            ),
        ],
        kapanis=(
            "Ekip {} bölgesine gönderildi. Merkeze de kısa bir not düşüldü: "
            "\"Nüfus verisi alan bilgisi olmadan yorumlanamaz.\""
        ).format(bolgeler[1]),
        odul={"itibar": 6, "erzak": 3},
    )


@bulmaca(ders="cografya", konu="kaynak_yonetimi", kademeler=(8, 13))
def su_butcesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yenilenme hızı ile tüketim hızı; sürdürülebilir sınır."""
    yenilenme = rastgele.choice([120, 150, 180, 200])   # m³/gün
    kisi_basi = rastgele.choice([40, 50, 60])           # litre/gün
    mevcut_kisi = rastgele.randrange(120, 220, 10)
    tuketim = mevcut_kisi * kisi_basi / 1000.0          # m³/gün
    azami_kisi = int(yenilenme * 1000 // kisi_basi)
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]

    return Bulmaca(
        kod="cog-su-butcesi",
        ders="cografya",
        baslik="Su Bütçesi",
        kademe=kademe,
        konu="kaynak_yonetimi",
        kazanim="Yenilenebilir kaynakta yenilenme hızı - tüketim dengesi; taşıma kapasitesi.",
        dikkat=6,
        brifing=(
            "Üssün suyu {} kaynağından geliyor. Kaynak kurumuyor ama sonsuz "
            "da değil: yer altı haznesi belli bir hızda doluyor.\n\n"
            "Komutan üsse yeni personel almak istiyor ve \"kaynak var, su "
            "sorunumuz yok\" diyor. Hidroloji ekibi ise itiraz ediyor ama "
            "itirazlarını sayıya dökmemişler.\n\n"
            "Şu an üste {} kişi var. Üssün su bakımından kaç kişiyi "
            "taşıyabileceğini bulmamız gerekiyor."
        ).format(mevki, mevcut_kisi),
        kanitlar=[
            Kanit("Hidroloji raporu",
                  "Haznenin günlük yenilenme miktarı: {} m³/gün. Bu, yağış ve "
                  "kar erimesiyle hazneye giren ortalama miktardır.".format(yenilenme),
                  bedel=2, kritik=True),
            Kanit("Tüketim kaydı",
                  "Kişi başı günlük su kullanımı: {} litre (içme, yemek, "
                  "temizlik dahil).".format(kisi_basi), bedel=1, kritik=True),
            Kanit("Personel listesi", "Üstteki toplam kişi: {}".format(mevcut_kisi),
                  bedel=1, kritik=True),
            Kanit("Hazne ölçümü",
                  "Haznede şu an yaklaşık 4.000 m³ su birikmiş durumda. "
                  "Seviye son aylarda sabit.", bedel=1),
            Kanit("Birim tablosu", "1 m³ = 1.000 litre", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Üssün su bakımından taşıyabileceği kişi sayısını ne belirler?",
                dogru=("Günlük yenilenme miktarı; çünkü haznedeki birikim "
                       "tükenir, yenilenme ise sürekli devam eder."),
                yanlislar={
                    "Haznede şu an biriken toplam su miktarı.":
                        "Stoğa baktın. Birikmiş su bir kez tüketilir ve "
                        "biter; sürekli kaç kişinin yaşayabileceğini belirleyen "
                        "şey her gün YENİLENEN miktar.",
                    "Haznedeki birikim ile günlük yenilenmenin toplamı.":
                        "Bir kerelik stoğu sürekli gelirle topladın. Toplam "
                        "ilk günler için doğru olabilir ama uzun vadede "
                        "yalnızca yenilenme sayılır.",
                    "Mevcut kişi sayısı; kaynak kendini ona göre ayarlar.":
                        "Kaynağın talebe uyduğunu varsaydın. Yağış ve kaynak "
                        "debisi üssün nüfusuna bakmaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Haznedeki 4.000 m³ bir kerelik stoktur: tüketim yenilenmeyi "
                    "aşarsa er ya da geç biter. Sürekli olarak taşınabilecek nüfusu "
                    "belirleyen şey akış hızıdır - yani günlük yenilenme. Stok yalnızca "
                    "kuraklık gibi geçici dönemlerde tampon görevi görür."
                ),
                ipuclari=[
                    "Bir kaynağın 'sürdürülebilir' sınırı, birikmiş miktara mı yoksa "
                    "yenilenme hızına mı bağlıdır?",
                    "Haznedeki su tüketilirse yerine ne koyacak?",
                ],
                puan=20,
            ),
            sayi_adimi(
                soru="Üssün şu anki günlük su tüketimi kaç m³?",
                cevap=tuketim,
                birim="m³/gün",
                aciklama="{} kişi × {} litre = {} litre = {} m³/gün.".format(
                    mevcut_kisi, kisi_basi, mevcut_kisi * kisi_basi, sy(tuketim)),
                ipuclari=[
                    "Kişi sayısını kişi başı kullanımla çarp.",
                    "Litreyi m³'e çevirmeyi unutma.",
                ],
                tolerans=0.05,
                puan=14,
            ),
            sayi_adimi(
                soru="Üs, su bakımından en fazla kaç kişiyi sürekli taşıyabilir?",
                cevap=azami_kisi,
                birim="kişi",
                aciklama="{} m³ = {} litre; {} ÷ {} = {} kişi.".format(
                    yenilenme, yenilenme * 1000, yenilenme * 1000, kisi_basi, azami_kisi),
                ipuclari=[
                    "Günlük yenilenmeyi litreye çevir.",
                    "Sonra kişi başı kullanıma böl.",
                ],
                tolerans=1.0,
                puan=16,
            ),
            yorum_adimi(
                soru="Komutanın \"su sorunumuz yok\" değerlendirmesi doğru mu?",
                dogru=("Şu an için doğru ama sınırlı: kaynak yalnızca {} kişiye "
                       "kadar dayanır, bu sayı aşılırsa hazne yavaş yavaş "
                       "boşalır.").format(azami_kisi),
                yanlislar={
                    "Tamamen doğru; kaynak kurumadığı sürece sınır yoktur.":
                        "Sınırsızlık varsaydın. Kaynak kurumasa da günlük "
                        "yenilenme belirli; o miktar belirli sayıda kişiyi "
                        "taşır.",
                    "Tamamen yanlış; üs zaten kapasitesinin üzerindedir.":
                        "Ters uca gittin. Hesabı yap: bugünkü nüfus "
                        "yenilenmenin taşıyabileceğinin altında.",
                    "Belirlenemez; yenilenme miktarıyla nüfus ilişkilendirilemez.":
                        "Bağı koparttın. Günlük yenilenmeyi kişi başı günlük "
                        "tüketime bölmek doğrudan taşınabilir nüfusu verir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Bir kaynağın 'bitmemesi' ile 'sınırsız olması' aynı şey değildir. "
                    "Tüketim yenilenmenin altında kaldığı sürece sistem sürdürülebilir; "
                    "üstüne çıktığı gün stok erimeye başlar ve bu genellikle geç fark "
                    "edilir, çünkü ilk aylarda musluktan su akmaya devam eder."
                ),
                puan=14,
            ),
        ],
        kapanis=(
            "Rapor komutana verildi: üssün su tavanı {} kişi. Yeni personel "
            "alımı bu sayıya göre planlandı, ayrıca yağmur suyu toplama "
            "önerisi eklendi."
        ).format(azami_kisi),
        odul={"erzak": 8, "enerji": 6, "itibar": 8},
    )


@bulmaca(ders="cografya", konu="yon_bulma", kademeler=(3, 8))
def golge_yonu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Pusula bozuk; yön gölgeden bulunacak."""
    saat = rastgele.choice(["sabah", "öğlen", "ikindi"])
    golge_yonu_metni = {"sabah": "batıya", "öğlen": "kuzeye", "ikindi": "doğuya"}[saat]
    aciklama_metni = {
        "sabah": "Sabah güneş doğudadır; gölgeler ters yöne, yani batıya uzanır.",
        "öğlen": ("Kuzey yarım kürede öğlen güneş güneydedir; gölgeler kuzeye "
                  "uzanır."),
        "ikindi": "İkindide güneş batıdadır; gölgeler doğuya uzanır.",
    }[saat]
    mevki = ad_sec(rastgele, MEVKI_ADLARI, 1)[0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    yanlis_yonler = [y for y in ["kuzeye", "güneye", "doğuya", "batıya"]
                     if y != golge_yonu_metni]

    return Bulmaca(
        kod="cog-golge-yonu",
        ders="cografya",
        baslik="Pusulasız Keşif",
        kademe=kademe,
        konu="yon_bulma",
        kazanim="Güneşin günlük görünen hareketi ile yön bulma.",
        dikkat=5,
        brifing=(
            "{} keşif ekibinin pusulası düşüp kırılmış. Ekip {} mevkiinde ve "
            "üsse dönmek için kuzeye gitmeleri gerekiyor.\n\n"
            "Telsizden \"yön bulamıyoruz\" diye haber geçtiler. Saat {}; hava "
            "açık, güneş görünüyor ve etrafta uzun direkler var.\n\n"
            "Onlara ne yapacaklarını söylemen gerekiyor."
        ).format(kisi, mevki, saat),
        kanitlar=[
            Kanit("Telsiz konuşması",
                  "\"Pusula kırık. Saat {}. Güneş açık seçik görünüyor, "
                  "direklerin gölgesi net.\"".format(saat), bedel=1, kritik=True),
            Kanit("Seyir el kitabı",
                  "\"Güneş doğudan doğar, batıdan batar. Kuzey yarım kürede "
                  "yerel öğlende güneş güney yönündedir. Gölge, güneşin tam "
                  "ters yönüne uzanır.\"", bedel=2, kritik=True),
            Kanit("Bölge künyesi",
                  "Üs ve çevresi kuzey yarım kürede, orta enlemlerdedir.",
                  bedel=1, kritik=True),
            Kanit("Ekip donanımı",
                  "Yanlarında harita, su ve el feneri var; başka bir yön aleti yok.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Gölgeyle yön bulmanın temel kuralı nedir?",
                dogru="Gölge, güneşin bulunduğu yönün tam tersine uzanır.",
                yanlislar={
                    "Gölge her zaman kuzeye uzanır.":
                        "Ezber bir kural kullandın. Gölgenin yönü gün boyunca "
                        "değişir; sabah ile ikindi gölgesi aynı yönü "
                        "göstermez.",
                    "Gölge, güneşin bulunduğu yöne doğru uzanır.":
                        "Yönü ters aldın. Cisim ışığı keser; gölge güneşin "
                        "TERSİ yöne düşer.",
                    "Gölgenin yönü mevsime göre değişir, günün saatiyle ilgisi yoktur.":
                        "Mevsim gölgenin boyunu etkiler ama yönünü asıl "
                        "belirleyen, güneşin o andaki konumu - yani saat.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Işık düz gider; cisim ışığı keser ve arkasında karanlık bir alan "
                    "bırakır. Bu alan doğal olarak kaynağın ters tarafındadır. "
                    "\"Gölge hep kuzeyi gösterir\" ifadesi yalnızca yerel öğlende ve "
                    "kuzey yarım kürede doğrudur; sabah ve ikindide yanıltır."
                ),
                ipuclari=[
                    "Gölge nasıl oluşur? Işığı kesen cismin hangi tarafında kalır?",
                    "Güneş doğudaysa gölge hangi tarafta olur?",
                ],
            ),
            secim_adimi(
                soru="Saat {} olduğuna göre direklerin gölgesi hangi yöne uzanır?".format(saat),
                dogru=golge_yonu_metni,
                yanlislar=yanlis_yonler,
                rastgele=rastgele,
                aciklama=aciklama_metni,
                ipuclari=["Önce güneşin hangi yönde olduğunu söyle, sonra tersini al."],
                puan=14,
            ),
            yorum_adimi(
                soru="Ekip \"gölge kuzeyi gösterir\" diye ezberleseydi ne olurdu?",
                dogru=("Günün saatine göre yanılırlardı; bu kural yalnızca yerel "
                       "öğlende geçerlidir."),
                yanlislar={
                    "Hiçbir şey değişmezdi, kural her saat geçerlidir.":
                        "Kuralı saatten bağımsız saydın. Gölge sabah bir yöne, "
                        "ikindi başka bir yöne uzanır; ezber sabahleyin "
                        "yanıltır.",
                    "Yalnızca güney yarım kürede yanılırlardı.":
                        "Hatayı coğrafyaya bağladın. Aynı yarım kürede bile "
                        "günün saati değiştikçe gölge yön değiştirir.",
                    "Yalnızca kışın yanılırlardı.":
                        "Mevsimi tek etken saydın. Yaz kış fark etmeksizin "
                        "gölgenin yönü gün içinde döner.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ezberlenen kural, hangi koşulda kurulduğu unutulunca yanıltır. "
                    "\"Gölge kuzeye uzanır\" cümlesinin gizli koşulları var: kuzey "
                    "yarım küre ve yerel öğlen. Koşulu bilen kişi sabah da ikindi de "
                    "yönünü bulur; yalnızca sonucu ezberleyen kişi bulamaz."
                ),
                puan=12,
            ),
        ],
        kapanis=(
            "Ekip gölgeye bakıp yönünü buldu ve gün batmadan üsse döndü. "
            "Yedek pusula talebi de aynı gün yazıldı."
        ),
        odul={"itibar": 4, "erzak": 3},
    )


# ==========================================================================
# İLKOKUL
# ==========================================================================

@bulmaca(ders="cografya", konu="kroki_okuma", kademeler=(1, 5))
def kroki_okuma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """
    Kroki yarım; eksik yapının yeri iki tanığın anlattıklarından çıkacak.

    İlkokul kademesinde de ilke aynı: kimse "kuzey neresi" diye sormaz,
    çocuk iki bilgiyi birleştirip eksik olanı kendisi bulur.
    """
    yapilar = ["mutfak", "revir", "depo", "kule"]
    rastgele.shuffle(yapilar)
    kuzeydeki, guneydeki, dogudaki, batidaki = yapilar
    kayip = rastgele.choice(yapilar)
    yon = {kuzeydeki: "kuzey", guneydeki: "güney",
           dogudaki: "doğu", batidaki: "batı"}[kayip]
    kisi_a, kisi_b = ad_sec(rastgele, PERSONEL, 2)

    return Bulmaca(
        kod="cog-kroki-okuma",
        ders="cografya",
        baslik="Yarım Kroki",
        kademe=kademe,
        konu="kroki_okuma",
        kazanim="Krokide yön bulma; kuzey oku yardımıyla konum belirleme.",
        dikkat=5,
        brifing=(
            "Üssün krokisi çizilmiş ama {} yazılmayı unutulmuş. Kroki kâğıdında "
            "onun yeri boş duruyor.\n\n"
            "Krokinin köşesinde bir kuzey oku var: yukarısı kuzey, aşağısı "
            "güney, sağı doğu, solu batı.\n\n"
            "{} ve {} üste yıllardır çalışıyor; ikisi de yeri biliyor ama tam "
            "olarak söylemek yerine tarif ediyorlar. Krokiyi tamamlamamız gerek."
        ).format(kayip, kisi_a, kisi_b),
        kanitlar=[
            Kanit("Kroki kâğıdı",
                  "Kuzey oku yukarıyı gösteriyor.\n"
                  "Yukarıda: {}\nAşağıda: {}\nSağda: {}\nSolda: {}\n"
                  "(bir yer boş bırakılmış)".format(
                      kuzeydeki if kuzeydeki != kayip else "( ? )",
                      guneydeki if guneydeki != kayip else "( ? )",
                      dogudaki if dogudaki != kayip else "( ? )",
                      batidaki if batidaki != kayip else "( ? )"),
                  bedel=2, kritik=True),
            Kanit("{} anlatıyor".format(kisi_a),
                  "\"Sabah güneş doğduğunda ışık önce {} tarafına vurur.\"".format(
                      dogudaki), bedel=1, kritik=True),
            Kanit("{} anlatıyor".format(kisi_b),
                  "\"{} ile {} tam karşı karşıyadır; biri yukarıda, biri "
                  "aşağıda.\"".format(kuzeydeki, guneydeki), bedel=1, kritik=True),
            Kanit("Yön kartı",
                  "Krokide yukarısı KUZEY, aşağısı GÜNEY, sağı DOĞU, solu BATI "
                  "olarak gösterilir.", bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Krokide bir yerin hangi yönde olduğunu ne belirler?",
                dogru="Kuzey okunun gösterdiği yön; ona göre yukarı kuzey, aşağı güneydir.",
                yanlislar={
                    "Kâğıdı hangi taraftan tuttuğumuz.":
                        "Yönü okuyucuya bağladın. Kroki elde döndürülse bile "
                        "yönler değişmez; onları kuzey oku sabitler.",
                    "Yapının büyüklüğü; büyük yapılar kuzeye çizilir.":
                        "Böyle bir çizim kuralı yok. Yapı krokide gerçekte "
                        "nerede duruyorsa oraya çizilir.",
                    "Yapının adının alfabedeki sırası.":
                        "Alfabe sırası listelerde işe yarar; krokide yer, "
                        "gerçek konuma göre belirlenir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kroki ve haritalarda yön, kuzey okuyla belirlenir. Kâğıdı "
                    "çevirsen bile ok da onunla döner; yönler değişmez. Bu yüzden "
                    "her haritanın bir kuzey oku vardır."
                ),
                ipuclari=[
                    "Kroki kâğıdının köşesinde ne var?",
                    "Ok yukarıyı gösteriyorsa yukarısı hangi yöndür?",
                ],
            ),
            secim_adimi(
                soru="Eksik yazılan {} hangi yöndedir?".format(kayip),
                dogru=yon,
                yanlislar={
                    y: "Krokide {} tarafı zaten dolu. Boş kalan tek yeri "
                       "bulmak için dolu olanları tek tek işaretle.".format(y)
                    for y in ["kuzey", "güney", "doğu", "batı"] if y != yon
                },
                rastgele=rastgele,
                aciklama=(
                    "Krokide dolu olan üç yer zaten yazılı; boş kalan tek yer {} "
                    "tarafı. {} oraya yazılır."
                ).format(yon, kayip),
                ipuclari=[
                    "Krokide dolu olanları işaretle; geriye tek yer kalır.",
                    "Boş kalan yer yukarıda mı, aşağıda mı, sağda mı, solda mı?",
                ],
                puan=14,
            ),
            yorum_adimi(
                soru="Kuzey oku olmasaydı krokiyi okuyabilir miydik?",
                dogru="Yerlerin birbirine göre durumunu görürdük ama yönlerini söyleyemezdik.",
                yanlislar={
                    "Hiçbir şey anlaşılmazdı, kroki tamamen işe yaramazdı.":
                        "Krokiyi tümden işe yaramaz saydın. Yapıların "
                        "birbirine göre yerleri yine okunurdu; belirsizleşen "
                        "tek şey hangi tarafın kuzey olduğu.",
                    "Her şey aynı olurdu; kuzey oku sadece süstür.":
                        "Kuzey okunu süs saydın. O ok olmadan kroki "
                        "araziyle eşleştirilemez; hangi yöne yürüneceği "
                        "bilinmez.",
                    "Yönleri yine bilirdik, çünkü yukarısı her zaman kuzeydir.":
                        "Yaygın ama yanlış bir varsayım. Yukarının kuzey "
                        "olması bir alışkanlıktır, kural değil; bu yüzden "
                        "krokilere ok konur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ok olmadan da \"mutfak, deponun karşısında\" diyebiliriz; ama "
                    "\"mutfak kuzeydedir\" diyemeyiz. Kuzey oku, çizimi gerçek "
                    "dünyaya bağlayan işarettir. \"Yukarısı hep kuzeydir\" ise bir "
                    "alışkanlıktır, kural değil; ok başka yöne de bakabilir."
                ),
                puan=10,
            ),
        ],
        kapanis="Kroki tamamlandı ve nöbetçi odasının duvarına asıldı.",
        odul={"itibar": 4, "erzak": 2},
    )
