# -*- coding: utf-8 -*-
"""
Sefer karnesi.

Oyunun sonunda öğrencinin eline tutuşturulacak tek sayfalık belge. Klasik
karneden iki farkı var:

  1) Not yok. Öğrenci "matematikten 3 aldı" diye özetlenmez; hangi konuyu
     hangi destek düzeyinde yaptığı yazar (izledi / birlikte / kendi başına).
  2) Ölçü, işlem doğruluğu değil MODELLEME oranıdır: olayı doğru bağıntıya
     oturtabildi mi?

Bu dosya bilerek iki katmana ayrıldı:

    karne_verisi()  -> saf sözlük, hiçbir şey yazdırmaz
    karne_html()    -> o sözlüğü basılabilir HTML'e çevirir
    karne_bas()     -> aynı sözlüğü terminale çizer

Oyunun görsel arayüzünü sonra yazacak ekip karne_verisi() çıktısını alıp
istediği arayüzde gösterebilir; hesap kuralları burada tek yerde durur.
"""
from __future__ import annotations

import html
import os
import time
from typing import Any, Dict, List, Optional

from oyun.motor import terminal as ekran
from oyun.motor.durum import (
    Durum, KAYIT_KLASORU, dosya_adi_yap, kayitlari_listele, yukle,
)
from oyun.motor.ilerleme import genel_degerlendirme
from oyun.motor.kayit_defteri import icerigi_yukle, konular
from oyun.motor.modeller import (
    ANLATIM, BIRLIKTE, OGRENME_YOLLARI, SERBEST, ZORLUK_ACIKLAMALARI,
    secmeli_yol_mu, yol_alanlari,
)

KARNE_KLASORU = os.path.join(os.path.dirname(KAYIT_KLASORU), "karneler")

# Terminal karnesinde kullanılan sade ayraç.
AYRAC = "|"

# Aşamanın karnedeki karşılığı. Veli "serbest" ne demek bilmez; "kendi başına
# çözüyor" cümlesi doğrudan anlaşılır.
ASAMA_KARNE = {
    ANLATIM: "İzledi",
    BIRLIKTE: "Birlikte",
    SERBEST: "Kendi başına",
}

# Oturan konu / ele alınan konu oranının sözel karşılığı.
SEVIYELER = [
    (0.75, "Ustalaştı"),
    (0.50, "Oturdu"),
    (0.25, "Gelişiyor"),
    (0.00, "Başladı"),
]


def _seviye(oran: float, ele_alinan: int) -> str:
    if ele_alinan == 0:
        return "Henüz girilmedi"
    for esik, ad in SEVIYELER:
        if oran >= esik:
            return ad
    return "Başladı"


def _yuzde(bolum: float, payda: float) -> int:
    return 0 if not payda else int(round(100.0 * bolum / payda))


def _tarih(damga: float) -> str:
    return time.strftime("%d.%m.%Y", time.localtime(damga)) if damga else "-"


# --------------------------------------------------------------------------
# Veri
# --------------------------------------------------------------------------

def karne_verisi(durum: Durum) -> Dict[str, Any]:
    """Bir öğrencinin karnesini saf veri olarak üretir (ekrana bir şey yazmaz)."""
    icerigi_yukle()

    yollar: List[Dict[str, Any]] = []
    konu_satirlari: List[Dict[str, Any]] = []
    toplam_ele = toplam_oturan = toplam_konu = 0

    for yol_kodu, bilgi in OGRENME_YOLLARI.items():
        yol_ele = yol_oturan = yol_toplam = 0
        for alan in yol_alanlari(yol_kodu):
            ders_durumu = durum.ders(alan)
            for konu_kodu in konular(alan):
                yol_toplam += 1
                konu = ders_durumu.konu(konu_kodu)
                if not konu.baslanmis:
                    continue
                yol_ele += 1
                yol_oturan += int(konu.tamamlandi)
                konu_satirlari.append({
                    "konu": konu_kodu.replace("_", " "),
                    "yol": bilgi["ad"],
                    "alan": alan,
                    "asama": konu.asama,
                    "asama_adi": ASAMA_KARNE.get(konu.asama, "-"),
                    "oturdu": konu.tamamlandi,
                    "ustalik": round(konu.ustalik, 3),
                    "deneme": konu.serbest_toplam,
                    "basarili": konu.serbest_dogru,
                })
        oran = (yol_oturan / yol_ele) if yol_ele else 0.0
        # Meslek dersleri gibi seçmeli yollar, öğrenci hiç girmediyse karnede
        # yer kaplamaz; konuları havuza da sayılmaz. Ortaokul öğrencisinin
        # karnesinde boş bir "Meslek ve Üretim" satırı görünmesin.
        if not yol_ele and secmeli_yol_mu(yol_kodu):
            continue
        yollar.append({
            "kod": yol_kodu,
            "ad": bilgi["ad"],
            "aciklama": bilgi["aciklama"],
            "toplam": yol_toplam,
            "ele_alinan": yol_ele,
            "oturan": yol_oturan,
            "oran": round(oran, 3),
            "yuzde": _yuzde(yol_oturan, yol_ele),
            "kapsam": _yuzde(yol_ele, yol_toplam),
            "seviye": _seviye(oran, yol_ele),
        })
        toplam_ele += yol_ele
        toplam_oturan += yol_oturan
        toplam_konu += yol_toplam

    # Çizelge, en rahat olduğu konudan başlar: karneye bakan kişi önce
    # öğrencinin neyi becerdiğini görsün, eksik listesi altta dursun.
    konu_satirlari.sort(key=lambda s: (-s["ustalik"], s["konu"]))

    model_toplam = sum(durum.ders(a).model_toplam for a in durum.aktif_dersler())
    model_dogru = sum(durum.ders(a).model_dogru for a in durum.aktif_dersler())

    guclu = [s for s in konu_satirlari if s["oturdu"]][:6]
    tekrar = sorted(
        (s for s in konu_satirlari
         if not s["oturdu"] and s["deneme"] > 0 and s["ustalik"] < 0.55),
        key=lambda s: s["ustalik"])[:6]

    genel_oran = (toplam_oturan / toplam_ele) if toplam_ele else 0.0

    return {
        "ad": durum.ad,
        "sinif": durum.sinif,
        "numara": durum.numara,
        "rutbe": durum.rutbe,
        "zorluk": durum.zorluk,
        "zorluk_adi": durum.zorluk_adi,
        "zorluk_aciklamasi": ZORLUK_ACIKLAMALARI.get(durum.zorluk, ""),
        "gorev": durum.oynanan_gorev,
        "baslangic": _tarih(durum.ilk_oynama),
        "son": _tarih(durum.son_oynama),
        "basim": time.strftime("%d.%m.%Y %H:%M"),
        "ele_alinan": toplam_ele,
        "oturan": toplam_oturan,
        "konu_havuzu": toplam_konu,
        "genel_yuzde": _yuzde(toplam_oturan, toplam_ele),
        "genel_seviye": _seviye(genel_oran, toplam_ele),
        "model_dogru": model_dogru,
        "model_toplam": model_toplam,
        "model_yuzde": _yuzde(model_dogru, model_toplam),
        "yollar": yollar,
        "konular": konu_satirlari,
        "guclu": guclu,
        "tekrar": tekrar,
        "rozetler": list(durum.rozetler),
        "hatalar": tekrarlayan_hatalar(durum),
        "degerlendirme": genel_degerlendirme(durum),
        "oneri": _oneri(genel_oran, model_dogru, model_toplam, toplam_ele),
    }


def tekrarlayan_hatalar(durum: Durum, en_az: int = 2,
                        adet: int = 5) -> List[Dict[str, Any]]:
    """
    Öğrencinin birden çok kez düştüğü hataları çoktan aza sıralar.

    Tek seferlik yanlış karneye girmez; öğretmene lazım olan, aynı karışıklığın
    tekrar edip etmediğidir. Bir hata birden çok alanda görülebilir (birim
    çevirmeyi hem fen hem matematik görevinde atlamak gibi), o yüzden sayaçlar
    alanlar üstünde toplanır.
    """
    toplam: Dict[str, int] = {}
    for alan in durum.aktif_dersler():
        for metin, adet_alan in durum.ders(alan).hata_turleri.items():
            toplam[metin] = toplam.get(metin, 0) + int(adet_alan)
    siralanmis = sorted(toplam.items(), key=lambda ikili: (-ikili[1], ikili[0]))
    return [{"metin": metin, "adet": sayi}
            for metin, sayi in siralanmis if sayi >= en_az][:adet]


def _oneri(genel_oran: float, model_dogru: int, model_toplam: int,
           ele_alinan: int) -> str:
    """Karnenin altına yazılan tek paragraflık yönlendirme."""
    if ele_alinan == 0:
        return ("Henüz hiçbir konuya girilmedi. Usta Çadırı'ndan bir masa seçip "
                "önce anlatımı izlemek iyi bir başlangıç olur.")
    parcalar = []
    if genel_oran >= 0.6:
        parcalar.append("Ele aldığı konuların çoğu oturmuş durumda; zorluk bir "
                        "basamak yükseltilebilir.")
    elif genel_oran >= 0.3:
        parcalar.append("Konuların bir kısmı oturdu, bir kısmı hâlâ destekle "
                        "gidiyor. Zorluğu değiştirmeden devam etmek doğru olur.")
    else:
        parcalar.append("Konular henüz oturma aşamasında. Yeni konu açmak yerine "
                        "başlanan konuları birlikte tekrar etmek daha verimli.")
    if model_toplam >= 3:
        oran = model_dogru / model_toplam
        if oran >= 0.7:
            parcalar.append("Olayı doğru bağıntıya oturtmakta güçlü; oyunun asıl "
                            "ölçtüğü beceri budur.")
        elif oran <= 0.4:
            parcalar.append("Hesap tarafı iyi ama modelleme adımında acele ediyor; "
                            "kanıtları okumadan adıma geçmemesi gerekiyor.")
    return " ".join(parcalar)


# --------------------------------------------------------------------------
# HTML
# --------------------------------------------------------------------------

_STIL = """
:root{
  --murekkep:#16212e; --soluk:#5c6b7a; --cizgi:#d8dee6; --kagit:#ffffff;
  --zemin:#eef1f5; --lacivert:#1d3557; --deniz:#2a6f7f; --altin:#9a6f14;
  --yesil:#2f7d4f;
}
*{box-sizing:border-box}
body{margin:0;background:var(--zemin);color:var(--murekkep);
  font-family:"Segoe UI",Candara,"Trebuchet MS",sans-serif;font-size:13px;line-height:1.5}
.sayfa{width:210mm;min-height:297mm;margin:12px auto;background:var(--kagit);
  padding:16mm 15mm 12mm;box-shadow:0 2px 18px rgba(20,30,45,.18)}
.bant{background:var(--lacivert);color:#fff;margin:-16mm -15mm 10mm;padding:11mm 15mm 8mm;
  display:flex;justify-content:space-between;align-items:flex-end;gap:16px}
.bant h1{margin:0;font-size:23px;letter-spacing:.08em;font-weight:600}
.bant .alt{margin:2px 0 0;font-size:11px;letter-spacing:.22em;text-transform:uppercase;opacity:.72}
.bant .sag{text-align:right;font-size:11px;opacity:.82;line-height:1.7}
.kimlik{display:flex;justify-content:space-between;align-items:flex-end;
  border-bottom:2px solid var(--lacivert);padding-bottom:8px;margin-bottom:14px}
.kimlik .ad{font-size:26px;font-weight:600}
.kimlik .rutbe{color:var(--deniz);font-size:13px;font-weight:600;margin-top:2px}
.kimlik .sag{text-align:right;color:var(--soluk);font-size:11.5px;line-height:1.8}
.kunye{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px}
.kutu{border:1px solid var(--cizgi);border-top:3px solid var(--deniz);
  padding:9px 11px;background:#fbfcfd}
.kutu .sayi{font-size:22px;font-weight:600;line-height:1.15}
.kutu .etiket{font-size:10px;letter-spacing:.09em;text-transform:uppercase;
  color:var(--soluk);margin-top:3px}
.kutu .not{font-size:10.5px;color:var(--soluk);margin-top:5px}
h2{font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:var(--lacivert);
  margin:18px 0 8px;padding-bottom:4px;border-bottom:1px solid var(--cizgi)}
.yollar{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.yol{border:1px solid var(--cizgi);padding:9px 11px}
.yol .ust{display:flex;justify-content:space-between;align-items:baseline}
.yol .ad{font-weight:600;font-size:13.5px}
.yol .seviye{font-size:11px;font-weight:600;color:var(--deniz)}
.yol .aciklama{font-size:10.5px;color:var(--soluk);margin:1px 0 7px}
.cubuk{height:7px;background:#e7ebf0;border-radius:4px;overflow:hidden}
.cubuk i{display:block;height:100%;background:var(--deniz)}
.yol .sayilar{font-size:10.5px;color:var(--soluk);margin-top:5px}
table{width:100%;border-collapse:collapse;font-size:11.5px}
th{text-align:left;font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;
  color:var(--soluk);border-bottom:1px solid var(--cizgi);padding:5px 6px;font-weight:600}
td{padding:5px 6px;border-bottom:1px solid #eef1f4;vertical-align:middle}
td.sag,th.sag{text-align:right;white-space:nowrap}
.rozet{display:inline-block;border:1px solid var(--altin);color:var(--altin);
  border-radius:11px;padding:2px 9px;font-size:10.5px;margin:0 5px 5px 0}
.damga{display:inline-block;font-size:10px;font-weight:600;padding:1px 7px;border-radius:3px}
.d-kendi{background:#e6f2ea;color:var(--yesil)}
.d-birlikte{background:#fdf3e0;color:var(--altin)}
.d-izledi{background:#eef1f5;color:var(--soluk)}
.mini{height:5px;width:70px;background:#e7ebf0;border-radius:3px;overflow:hidden;
  display:inline-block;vertical-align:middle}
.mini i{display:block;height:100%;background:var(--deniz)}
.not-kutusu{border-left:3px solid var(--lacivert);background:#f7f9fb;padding:9px 12px;
  font-size:12px}
.ikili{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.liste{margin:0;padding-left:16px}
.liste li{margin-bottom:3px}
.imza{display:grid;grid-template-columns:1fr 1fr;gap:34px;margin-top:26px;
  font-size:11px;color:var(--soluk)}
.imza div{border-top:1px solid var(--cizgi);padding-top:5px;text-align:center}
.dipnot{margin-top:14px;font-size:10px;color:var(--soluk);line-height:1.6;
  border-top:1px solid var(--cizgi);padding-top:7px}
.yazdir{position:fixed;top:14px;right:14px;background:var(--lacivert);color:#fff;
  border:0;border-radius:5px;padding:9px 15px;font-size:13px;cursor:pointer}
@media print{
  body{background:#fff}
  .sayfa{width:auto;margin:0;padding:12mm 14mm;box-shadow:none;min-height:0}
  .bant{margin:-12mm -14mm 8mm;padding:9mm 14mm 6mm}
  .yazdir{display:none}
  h2{break-after:avoid}
  tr{break-inside:avoid}
  *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
@page{size:A4;margin:10mm}
"""


def _kacir(metin: Any) -> str:
    return html.escape(str(metin), quote=True)


def _damga_sinifi(asama: str) -> str:
    return {SERBEST: "d-kendi", BIRLIKTE: "d-birlikte"}.get(asama, "d-izledi")


def karne_html(veri: Dict[str, Any]) -> str:
    """Karne verisini tek dosyalık, basılabilir HTML'e çevirir."""
    parcalar: List[str] = []
    e = parcalar.append

    e("<!DOCTYPE html>")
    e('<html lang="tr"><head><meta charset="utf-8">')
    e('<meta name="viewport" content="width=device-width, initial-scale=1">')
    e("<title>{} - Sefer Karnesi</title>".format(_kacir(veri["ad"])))
    e("<style>{}</style></head><body>".format(_STIL))
    e('<button class="yazdir" onclick="window.print()">Yazdır / PDF</button>')
    e('<div class="sayfa">')

    e('<div class="bant"><div>')
    e("<h1>SEFER KARNESİ</h1>")
    e('<p class="alt">Meridyen Seferi</p>')
    e('</div><div class="sag">Düzenlenme: {}<br>Sefer: {} - {}</div></div>'.format(
        _kacir(veri["basim"]), _kacir(veri["baslangic"]), _kacir(veri["son"])))

    e('<div class="kimlik"><div>')
    e('<div class="ad">{}</div>'.format(_kacir(veri["ad"])))
    kimlik_ekleri = [p for p in (veri["sinif"],
                                 "No {}".format(veri["numara"]) if veri["numara"] else "")
                     if p]
    e('<div class="rutbe">{}{}</div>'.format(
        _kacir(veri["rutbe"]),
        "".join("  ·  " + _kacir(p) for p in kimlik_ekleri)))
    e('</div><div class="sag">Zorluk {} - {}<br>{}</div></div>'.format(
        # `zorluk` da kacirilmali. Kayit dosyasi duz JSON'dur ve elle
        # duzenlenebilir; oraya metin koyan biri ogretmenin actigi karneye
        # kod sokabilir. Bagimsiz oyun testi (8 Eylul 2026) yakaladi.
        # Kural: karneye giren HER alan `_kacir`dan gecer, sayi bile.
        _kacir(veri["zorluk"]), _kacir(veri["zorluk_adi"]),
        _kacir(veri["zorluk_aciklamasi"])))

    kutular = [
        (veri["gorev"], "Tamamlanan görev", "üsse teslim edilen dosya"),
        (veri["ele_alinan"], "Ele alınan konu",
         "{} konuluk havuzdan".format(veri["konu_havuzu"])),
        (veri["oturan"], "Oturan konu", "kendi başına en az iki kez"),
        ("%{}".format(veri["model_yuzde"]) if veri["model_toplam"] else "-",
         "Bilinmeyeni kurma",
         "{}/{} görevde ilk denemede".format(
             veri["model_dogru"], veri["model_toplam"])),
    ]
    e('<div class="kunye">')
    for sayi, etiket, not_metni in kutular:
        e('<div class="kutu"><div class="sayi">{}</div>'
          '<div class="etiket">{}</div><div class="not">{}</div></div>'.format(
              _kacir(sayi), _kacir(etiket), _kacir(not_metni)))
    e("</div>")

    e("<h2>Öğrenme yolları</h2>")
    e('<div class="yollar">')
    for yol in veri["yollar"]:
        e('<div class="yol"><div class="ust"><span class="ad">{}</span>'
          '<span class="seviye">{}</span></div>'.format(
              _kacir(yol["ad"]), _kacir(yol["seviye"])))
        e('<div class="aciklama">{}</div>'.format(_kacir(yol["aciklama"])))
        e('<div class="cubuk"><i style="width:{}%"></i></div>'.format(yol["yuzde"]))
        e('<div class="sayilar">{} konuya girildi, {} tanesi oturdu '
          "(%{})</div></div>".format(
              yol["ele_alinan"], yol["oturan"], yol["yuzde"]))
    e("</div>")

    if veri["konular"]:
        e("<h2>Konu çizelgesi</h2>")
        e("<table><thead><tr><th>Konu</th><th>Öğrenme yolu</th><th>Nerede</th>"
          '<th class="sag">Deneme</th><th class="sag">Rahatlık</th>'
          "</tr></thead><tbody>")
        for satir in veri["konular"]:
            e("<tr><td>{}</td><td>{}</td>".format(
                _kacir(satir["konu"]), _kacir(satir["yol"])))
            e('<td><span class="damga {}">{}</span>{}</td>'.format(
                _damga_sinifi(satir["asama"]), _kacir(satir["asama_adi"]),
                " &#10004;" if satir["oturdu"] else ""))
            e('<td class="sag">{}/{}</td>'.format(
                satir["basarili"], satir["deneme"]))
            e('<td class="sag"><span class="mini"><i style="width:{}%"></i>'
              "</span></td></tr>".format(int(round(satir["ustalik"] * 100))))
        e("</tbody></table>")

    if veri["rozetler"]:
        e("<h2>Rozetler</h2>")
        for rozet in veri["rozetler"]:
            e('<span class="rozet">{}</span>'.format(_kacir(rozet)))

    if veri["hatalar"]:
        e("<h2>Tekrarlayan hatalar</h2>")
        e('<table><thead><tr><th>Aynı yere birden çok kez takıldı</th>'
          '<th class="sag">Kaç kez</th></tr></thead><tbody>')
        for hata in veri["hatalar"]:
            e('<tr><td>{}</td><td class="sag">{}</td></tr>'.format(
                _kacir(hata["metin"]), hata["adet"]))
        e("</tbody></table>")

    e("<h2>Değerlendirme</h2>")
    e('<div class="not-kutusu">{}<br><br>{}</div>'.format(
        _kacir(veri["degerlendirme"]), _kacir(veri["oneri"])))

    if veri["guclu"] or veri["tekrar"]:
        e('<div class="ikili">')
        e('<div><h2>Güçlü olduğu yerler</h2><ul class="liste">')
        for satir in veri["guclu"] or [{"konu": "-"}]:
            e("<li>{}</li>".format(_kacir(satir["konu"])))
        e("</ul></div>")
        e('<div><h2>Birlikte tekrar edilecek</h2><ul class="liste">')
        for satir in veri["tekrar"] or [{"konu": "-"}]:
            e("<li>{}</li>".format(_kacir(satir["konu"])))
        e("</ul></div></div>")

    e('<div class="imza"><div>Öğretmen</div><div>Veli</div></div>')
    e('<div class="dipnot">Bu belge bir sınav sonucu değildir. "Oturan konu", '
      "öğrencinin o konuyu yardım almadan en az iki kez başarıyla çözdüğü "
      'anlamına gelir. "Bilinmeyeni kurma", olayın hangi bağıntıyla '
      "anlatıldığını ilk denemede doğru seçme oranıdır; oyunun asıl ölçtüğü "
      "beceri budur.</div>")

    e("</div></body></html>")
    return "\n".join(parcalar)


def karne_yaz(durum: Durum, klasor: Optional[str] = None) -> str:
    """Karneyi HTML dosyası olarak yazar, dosya yolunu döner."""
    klasor = klasor or KARNE_KLASORU
    os.makedirs(klasor, exist_ok=True)
    yol = os.path.join(klasor, "{}_karne.html".format(dosya_adi_yap(durum.ad)))
    with open(yol, "w", encoding="utf-8") as dosya:
        dosya.write(karne_html(karne_verisi(durum)))
    return yol


# --------------------------------------------------------------------------
# Terminal
# --------------------------------------------------------------------------

def karne_bas(veri: Dict[str, Any]) -> None:
    """Aynı karneyi terminale çizer (tarayıcı açılamayan makineler için)."""
    ekran.baslik("SEFER KARNESİ", "kalin", "acik_cam")
    kimlik = "{}  {}  {}".format(veri["ad"], AYRAC, veri["rutbe"])
    for ek in (veri["sinif"], veri["numara"] and "No " + veri["numara"]):
        if ek:
            kimlik += "  {}  {}".format(AYRAC, ek)
    ekran.yaz(kimlik, "kalin")
    ekran.yaz("Zorluk {} - {}  {}  {} - {}".format(
        veri["zorluk"], veri["zorluk_adi"], AYRAC,
        veri["baslangic"], veri["son"]), "gri")
    ekran.yaz()
    ekran.yaz("Tamamlanan görev: {}   Ele alınan konu: {}   Oturan konu: {}".format(
        veri["gorev"], veri["ele_alinan"], veri["oturan"]), "acik_cam")
    if veri["model_toplam"]:
        ekran.yaz("Bilinmeyeni ilk denemede kurma: {}/{} (%{})".format(
            veri["model_dogru"], veri["model_toplam"],
            veri["model_yuzde"]), "acik_mor")

    ekran.yaz()
    ekran.yaz("ÖĞRENME YOLLARI", "kalin", "acik_cam")
    for yol in veri["yollar"]:
        ekran.yaz("{:<22}{} {:>3}%  {}".format(
            yol["ad"][:21], ekran.cubuk(yol["yuzde"], 100, 12),
            yol["yuzde"], yol["seviye"]), "acik_cam", sar=False, girinti="  ")

    if veri["konular"]:
        ekran.yaz()
        ekran.yaz("KONU ÇİZELGESİ", "kalin", "acik_cam")
        ekran.yaz("{:<26}{:<14}{}".format("KONU", "NEREDE", "DENEME"),
                  "gri", sar=False, girinti="  ")
        for satir in veri["konular"][:14]:
            ekran.yaz("{:<26}{:<14}{}/{}".format(
                satir["konu"][:25], satir["asama_adi"],
                satir["basarili"], satir["deneme"]),
                "acik_yesil" if satir["oturdu"] else "beyaz",
                sar=False, girinti="  ")
        if len(veri["konular"]) > 14:
            ekran.yaz("... ve {} konu daha (HTML karnede tamamı var)".format(
                len(veri["konular"]) - 14), "gri", girinti="  ")

    if veri["hatalar"]:
        ekran.yaz()
        ekran.yaz("TEKRARLAYAN HATALAR", "kalin", "acik_sari")
        for hata in veri["hatalar"]:
            ekran.madde("({} kez) {}".format(hata["adet"], hata["metin"]),
                        "acik_sari")

    if veri["rozetler"]:
        ekran.yaz()
        ekran.yaz("ROZETLER", "kalin", "acik_sari")
        for rozet in veri["rozetler"]:
            ekran.madde(rozet, "acik_sari")

    ekran.yaz()
    ekran.kutu(veri["degerlendirme"] + "\n\n" + veri["oneri"],
               "DEĞERLENDİRME", "beyaz")


def karne_ekrani(durum: Durum) -> None:
    """
    Oyun içinden çağrılır: karneyi gösterir, isterse dosyaya yazıp açar.

    Dosya kendiliğinden açılmaz; öğrenci onaylamadan tarayıcı çalışmaz.
    """
    ekran.temizle()
    veri = karne_verisi(durum)
    karne_bas(veri)
    ekran.yaz()
    if not ekran.onayla("Karneni yazdırılabilir dosya olarak alalım mı?", False):
        return
    try:
        yol = karne_yaz(durum)
    except OSError as sorun:
        ekran.hata("Karne yazılamadı: {}".format(sorun))
        ekran.bekle()
        return
    ekran.basari("Karne hazır: " + yol)
    ekran.yaz("Dosyayı tarayıcıda açıp Yazdır düğmesiyle PDF'e çevirebilir "
              "ya da kâğıda basabilirsin.", "gri")
    if ekran.onayla("Şimdi tarayıcıda açayım mı?", True):
        try:
            import webbrowser
            webbrowser.open("file://" + os.path.abspath(yol))
        except Exception:
            ekran.bilgi("Tarayıcı açılamadı; dosyayı elle açabilirsin.")
    ekran.bekle()


def toplu_karne(ad: str = "") -> int:
    """`python main.py --karne [ad]` girişi: kayıtlı öğrenciler için karne üretir."""
    ozetler = kayitlari_listele()
    if ad:
        aranan = dosya_adi_yap(ad).lower()
        ozetler = [o for o in ozetler if aranan in dosya_adi_yap(o["ad"]).lower()]
    if not ozetler:
        ekran.bilgi("Karne üretilecek kayıt bulunamadı"
                    + (" ({}).".format(ad) if ad else " (kayitlar/ klasörü boş)."))
        return 0

    uretilen = 0
    for ozet in ozetler:
        durum = yukle(ozet["yol"])
        if durum is None:
            ekran.hata("Okunamadı: " + ozet["dosya"])
            continue
        # Yol satırı sarılmasın: kopyalanıp doğrudan açılabilir kalsın.
        ekran.basari(durum.ad)
        ekran.yaz(karne_yaz(durum), "gri", sar=False, girinti="    ")
        uretilen += 1

    ekran.yaz()
    ekran.yaz("{} karne üretildi. Dosyaları tarayıcıda açıp Yazdır düğmesiyle "
              "PDF'e çevirebilirsiniz.".format(uretilen), "gri")
    return 0 if uretilen else 1


if __name__ == "__main__":
    raise SystemExit(toplu_karne())
