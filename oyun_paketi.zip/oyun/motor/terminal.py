# -*- coding: utf-8 -*-
"""
Terminal katmanı.

Tek işi var: metni ekrana *güvenle* basmak. Windows konsolu varsayılan olarak
cp1254 kullanır; kutu çizgileri ve tipografik tire gibi karakterler orada
çökme (UnicodeEncodeError) üretir. Burası önce konsolu UTF-8'e çekmeyi dener,
beceremezse ASCII yedek karakter setine düşer. Böylece oyun her makinede açılır.
"""
from __future__ import annotations

import os
import re
import shutil
import sys
import textwrap
import time

# --------------------------------------------------------------------------
# Konsol hazırlığı
# --------------------------------------------------------------------------

_ANSI_ACIK = False


def _konsolu_hazirla() -> None:
    """Windows'ta UTF-8 kod sayfasını ve ANSI renk desteğini açmayı dener."""
    global _ANSI_ACIK

    if os.name == "nt":
        try:
            import ctypes

            cekirdek = ctypes.windll.kernel32
            cekirdek.SetConsoleOutputCP(65001)
            cekirdek.SetConsoleCP(65001)
            tutamac = cekirdek.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
            kip = ctypes.c_uint32()
            if cekirdek.GetConsoleMode(tutamac, ctypes.byref(kip)):
                # ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
                cekirdek.SetConsoleMode(tutamac, kip.value | 0x0004)
                _ANSI_ACIK = True
        except Exception:
            pass
    else:
        _ANSI_ACIK = True

    # Ne olursa olsun çökmeyelim: errors="replace" son emniyet kemeri.
    for akis in (sys.stdout, sys.stderr):
        try:
            akis.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass

    if os.environ.get("NO_COLOR") is not None:
        _ANSI_ACIK = False
    elif os.environ.get("PYCHARM_HOSTED") == "1":
        _ANSI_ACIK = True
    elif not sys.stdout.isatty():
        _ANSI_ACIK = False


def _kodlanabilir(ornek: str) -> bool:
    kodlama = getattr(sys.stdout, "encoding", None) or "ascii"
    try:
        ornek.encode(kodlama)
        return True
    except Exception:
        return False


_konsolu_hazirla()
ZENGIN = _kodlanabilir("─│┌┐└┘•→✔")

# --------------------------------------------------------------------------
# Karakter setleri
# --------------------------------------------------------------------------

_ZENGIN_SET = {
    "yatay": "─", "dikey": "│",
    "sol_ust": "┌", "sag_ust": "┐", "sol_alt": "└", "sag_alt": "┘",
    "kalin_yatay": "━",
    "madde": "•", "ok": "→", "onay": "✔", "carpi": "✘",
    "dolu": "█", "bos": "░", "yildiz": "★", "bos_yildiz": "☆",
}
_SADE_SET = {
    "yatay": "-", "dikey": "|",
    "sol_ust": "+", "sag_ust": "+", "sol_alt": "+", "sag_alt": "+",
    "kalin_yatay": "=",
    "madde": "*", "ok": ">", "onay": "[+]", "carpi": "[x]",
    "dolu": "#", "bos": ".", "yildiz": "*", "bos_yildiz": "-",
}
S = _ZENGIN_SET if ZENGIN else _SADE_SET

RENKLER = {
    "sifirla": "\033[0m", "kalin": "\033[1m", "soluk": "\033[2m",
    "kirmizi": "\033[31m", "yesil": "\033[32m", "sari": "\033[33m",
    "mavi": "\033[34m", "mor": "\033[35m", "camgobegi": "\033[36m",
    "beyaz": "\033[37m", "gri": "\033[90m",
    "acik_yesil": "\033[92m", "acik_sari": "\033[93m", "acik_mavi": "\033[94m",
    "acik_mor": "\033[95m", "acik_cam": "\033[96m",
}

# Hangi alanın hangi rengi kullandığı burada değil, modeller.ALAN_TANIMLARI
# içindedir: yeni bir ders eklerken tek bir tabloya bakmak yeter. Bu dosya
# yalnızca renklerin kendisini (RENKLER) tanır.


def renkli(metin: str, *renk_adlari: str) -> str:
    if not _ANSI_ACIK or not renk_adlari:
        return metin
    on = "".join(RENKLER.get(ad, "") for ad in renk_adlari)
    if not on:
        return metin
    return on + metin + RENKLER["sifirla"]


def gorunur_uzunluk(metin: str) -> int:
    """ANSI kodlarını saymadan gerçek karakter sayısı."""
    uzunluk, i = 0, 0
    while i < len(metin):
        if metin[i] == "\033":
            while i < len(metin) and metin[i] != "m":
                i += 1
            i += 1
            continue
        uzunluk += 1
        i += 1
    return uzunluk


# --------------------------------------------------------------------------
# Genişlik ve yazım
# --------------------------------------------------------------------------

# Telefon icin dusuruldu. 54 terminal icin secilmis bir tabandi; 375 px
# ekranda 14 px tek aralikli yazi ~41 karakter sigdiriyor, yani 54 istemek
# kutulari tasiriyor ve satirlar sarip cizimi bozuyordu (8 Eylul, gercek
# telefon boyutunda ekran goruntusuyle gorüldü). Kabuk kendi olcusunu
# bildiriyor; taban yalnizca ona guvenilemeyen durumlar icin.
EN_AZ_GENISLIK = 32
EN_COK_GENISLIK = 92


def genislik() -> int:
    """Satir genisligi. Once KABUGA sorulur.

    Eskiden yalnizca `shutil.get_terminal_size()` kullaniliyordu ve
    varsayilani 80 idi. Telefonda bu yanlis: 375 px ekranda 76
    karakterlik bir kutu tasar ve okunmaz hale gelir. Genisligi bilen
    tek yer kabuktur -- terminal kendi boyutunu bilir, tarayici kendi
    ekranini. Bu yuzden once ona soruluyor.
    """
    kabuk_genislik = getattr(_KABUK, "genislik", None)
    if kabuk_genislik:
        try:
            return max(EN_AZ_GENISLIK,
                       min(EN_COK_GENISLIK, int(kabuk_genislik())))
        except Exception:          # noqa: BLE001 - kabuk bozuksa terminale dus
            pass
    try:
        sutun = shutil.get_terminal_size(fallback=(80, 24)).columns
    except Exception:              # noqa: BLE001
        sutun = 80
    return max(EN_AZ_GENISLIK, min(EN_COK_GENISLIK, sutun - 2))


_YAZIM_HIZI = 0.0  # 0 => anında bas. Ayarlardan değiştirilebilir.


def yazim_hizi_ayarla(saniye: float) -> None:
    global _YAZIM_HIZI
    _YAZIM_HIZI = max(0.0, min(0.05, saniye))


def yazim_hizi() -> float:
    return _YAZIM_HIZI


# --------------------------------------------------------------------------
# Kabuk katmani
# --------------------------------------------------------------------------
#
# NEDEN VAR: TASARIM_NOTLARI §8 "motor kalir, kabuk degisir" diyor. Oyunun
# butun cikti ve girdisi bu dosyadan gecer ve disariya acilan yuzey yalnizca
# 16 fonksiyon. Cikti/girdi TEK NOKTADAN (_bas, _oku, temizle) gectigi icin
# oraya takilabilir bir kabuk konursa, oyun kendini terminalde sanmaya devam
# ederken ekran baska bir yere gidebilir.
#
# Mobil icin en ucuz yol bu: oturum.py (998 satir) ve oyun.py (1526 satir)
# HIC DEGISMEDEN telefonda calisabilir. §8 "oturum.py'yi olay tabanliya
# cevir" diyor; o duyarli bir web uygulamasi icin dogru ama "telefondan
# oynanabilsin" icin gerekli degil.
#
# Varsayilan kabuk bugunku davranistir. Kabuk degistirilmezse hicbir sey
# degismez.


class MetinKabugu:
    """Varsayilan kabuk: dogrudan konsola yazar, konsoldan okur."""

    yazim_hizi_destekli = True

    def bas(self, satir):
        print(satir)

    def oku(self, istem):
        return input(istem)

    def temizle(self):
        # Karar KABUGUN. Eskiden `temizle()` icinde `sys.stdout.isatty()`
        # sorulyordu; ozel bir kabukta stdout zaten cikti degil, o yuzden
        # o kontrol yanlis yerdeydi ve mobil kabukta ekran hic
        # temizlenmezdi. Test yakaladi.
        if os.environ.get("OYUN_TEMIZLEME") == "0" or not sys.stdout.isatty():
            return False          # temizlenemedi; cagiran ayrac cizsin
        try:
            os.system("cls" if os.name == "nt" else "clear")
        except Exception:          # noqa: BLE001
            return False
        return True


_KABUK = MetinKabugu()


def kabuk_ata(yeni_kabuk):
    """Cikti/girdi kabugunu degistirir. Mobil kabuk buradan takilir."""
    global _KABUK
    _KABUK = yeni_kabuk


def kabuk():
    return _KABUK


# --------------------------------------------------------------------------
# Olay katmani (Meridyen OS, bkz. MERIDYEN_OS.md)
# --------------------------------------------------------------------------
#
# Kabuk bir `olay(veri: dict)` yontemi tasiyorsa terminal islevleri metin
# satiri basmak YERINE yapisal olay gonderir. Tasimiyorsa asagidaki
# `_olayli()` her yerde False doner ve cikti BIREBIR eskisi gibidir.
# Olaylara ANSI kodu girmez; renkler ad listesi olarak gider.

_ANSI_KALIBI = re.compile(r"\x1b\[[0-9;]*m")


def _duz(metin) -> str:
    return _ANSI_KALIBI.sub("", str(metin))


def _olayli() -> bool:
    return callable(getattr(_KABUK, "olay", None))


def _olay(_t: str, /, **veri) -> None:
    olay = {"t": _t}
    olay.update(veri)
    _KABUK.olay(olay)


def olayli() -> bool:
    """Kabuk olay destekliyor mu? Pahali bağlam verisini hazırlamadan önce sorulur."""
    return _olayli()


def baglam(ad: str, **veri) -> None:
    """Arayuze "simdi su ekrandayiz" der. Olay desteklemeyen kabukta HICBIR sey yapmaz."""
    if _olayli():
        _olay("baglam", ad=ad, **veri)


def _bas(satir: str) -> None:
    if _olayli():
        _olay("satir", metin=_duz(satir))
        return
    if _YAZIM_HIZI > 0 and getattr(_KABUK, "yazim_hizi_destekli", False):
        for harf in satir:
            sys.stdout.write(harf)
            sys.stdout.flush()
            if harf not in " \t":
                time.sleep(_YAZIM_HIZI)
        sys.stdout.write("\n")
        sys.stdout.flush()
    else:
        _KABUK.bas(satir)


def yaz(metin: str = "", *renk_adlari: str, sar: bool = True, girinti: str = "") -> None:
    """Metni satır genişliğine sararak basar."""
    if _olayli():
        _olay("yaz", metin=_duz(metin), renk=list(renk_adlari), girinti=girinti)
        return
    if metin == "":
        _KABUK.bas("")
        return
    if sar:
        satirlar = []
        for parca in metin.split("\n"):
            if not parca.strip():
                satirlar.append("")
                continue
            sarilmis = textwrap.wrap(
                parca,
                width=max(20, genislik() - len(girinti)),
                break_long_words=False,
                break_on_hyphens=False,
            )
            satirlar.extend(sarilmis or [""])
    else:
        satirlar = metin.split("\n")

    for satir in satirlar:
        _bas(girinti + renkli(satir, *renk_adlari))


def ham_yaz(satir: str = "") -> None:
    """Sarmadan, girintisiz, oldugu gibi basar.

    Hizalanmis durum cubuklari icin var (ust pano, kanit listesi): oralarda
    metin elle hizalaniyor ve `yaz()`in satir sarmasi hizayi bozar.
    Dogrudan `print` KULLANILMAMALI -- kabugu atlar ve mobilde ekrana hic
    ulasmaz (bkz. kabuk katmani).
    """
    if _olayli():
        _olay("satir", metin=_duz(satir))
        return
    _KABUK.bas(satir)


def iki_sutun(sol: str, sag: str, sol_renk: str = "", sag_renk: str = "") -> None:
    """Solu sola, sagi saga yaslar. SIGMAZSA ALT ALTA yazar.

    NEDEN VAR
    ---------
    Bu hizalama uc yerde elle yapiliyordu:

        bosluk = max(1, genislik() - len(sol) - len(sag))
        ham_yaz(sol + " " * bosluk + sag)

    `max(1, ...)` ikisi sigmadiginda taşmayi ENGELLEMIYOR, yalnizca eksi
    boslugu 1'e cekiyor -- satir yine ekrandan uzun cikiyor. Masaustunde
    80 sutun var, sigiyordu; telefonda 50 sutun var, sigmiyor.

    9 Eylul 2026'da telefon ekraninda olculdu:
        "Ayse │ Aday Kasif Erzak 40 | Cevher 20 | Enerji 30 | Itibar 0"
        69 karakter / 50 sutun -> ogrenci kaynaklarini gormek icin
        yana kaydirmak zorunda kaliyordu.

    Sigmadiginda alt alta yazmak, kaydirmaktan iyidir: telefonda yatay
    kaydirma cogu kullanici tarafindan fark bile edilmez, satir yok sanilir.
    """
    # Uzunluk HAM metinle olculuyor: renk kacis dizileri ekliyor ve onlar
    # ekranda yer kaplamiyor.
    if _olayli():
        _olay("iki_sutun", sol=_duz(sol), sag=_duz(sag),
              sol_renk=[sol_renk] if sol_renk else [],
              sag_renk=[sag_renk] if sag_renk else [])
        return
    en = genislik()
    solu = renkli(sol, sol_renk) if sol_renk else sol
    sagi = renkli(sag, sag_renk) if sag_renk else sag
    if len(sol) + len(sag) + 2 <= en:
        ham_yaz(solu + " " * (en - len(sol) - len(sag)) + sagi)
        return
    # Sigmiyor: alt alta. `yaz` sarmayi kendi yapiyor.
    yaz(sol, sol_renk) if sol_renk else yaz(sol)
    yaz(sag, sag_renk) if sag_renk else yaz(sag)


def komut_satirlari(parcalar) -> list:
    """Komut listesini ekrana sigacak satirlara boler.

    KIRILMA MADDE SINIRINDA OLMALI. Duz `yaz()` satiri karakter sayisina
    gore sardigi icin telefonda soyle bir sey cikiyordu:

           b brifing  │  d kanitlar  │  x cikis  │  ?
        yardim

    "? yardim" ikiye bolunmus, "yardim" da soldan basliyor -- ogrenci
    bunun bir komut mu yoksa bir cumle mi oldugunu anlayamiyor.
    (9 Eylul 2026, 375 px telefon ekraninda goruldu.)

    Once genis ayracla ("  │  ") tek satir denenir; sigmazsa dar ayracla
    (" │ ") denenir; o da sigmazsa maddeler bozulmadan alt alta paketlenir.
    """
    parcalar = [p for p in parcalar if p]
    if not parcalar:
        return []
    en = genislik() - 3          # bastaki girinti
    for ayrac_metni in ("  " + S["dikey"] + "  ", " " + S["dikey"] + " "):
        satir = ayrac_metni.join(parcalar)
        if len(satir) <= en:
            return ["   " + satir]

    # Paketle: her satir kendi icinde dolana kadar madde alir.
    ayrac_metni = " " + S["dikey"] + " "
    satirlar, simdiki = [], ""
    for parca in parcalar:
        aday = parca if not simdiki else simdiki + ayrac_metni + parca
        if len(aday) > en and simdiki:
            satirlar.append("   " + simdiki)
            simdiki = parca
        else:
            simdiki = aday
    if simdiki:
        satirlar.append("   " + simdiki)
    return satirlar


def ayrac(karakter: str = "", *renk_adlari: str) -> None:
    if _olayli():
        _olay("ayrac")
        return
    karakter = karakter or S["yatay"]
    _KABUK.bas(renkli(karakter * genislik(), *(renk_adlari or ("gri",))))


def baslik(metin: str, *renk_adlari: str) -> None:
    """Üstte çerçeveli başlık."""
    if _olayli():
        _olay("baslik", metin=_duz(metin),
              renk=list(renk_adlari or ("kalin", "acik_cam")))
        return
    g = genislik()
    ic = g - 2
    renk_adlari = renk_adlari or ("kalin", "acik_cam")
    _KABUK.bas(renkli(S["sol_ust"] + S["yatay"] * ic + S["sag_ust"], "gri"))
    for satir in textwrap.wrap(metin, width=ic - 2) or [""]:
        bosluk = ic - 2 - len(satir)
        sol = bosluk // 2
        sag = bosluk - sol
        _KABUK.bas(
            renkli(S["dikey"], "gri") + " " * (sol + 1)
            + renkli(satir, *renk_adlari) + " " * (sag + 1)
            + renkli(S["dikey"], "gri")
        )
    _KABUK.bas(renkli(S["sol_alt"] + S["yatay"] * ic + S["sag_alt"], "gri"))


def kutu(metin: str, etiket: str = "", *renk_adlari: str) -> None:
    """Metni çerçeve içinde basar. Uzun anlatı blokları için."""
    if _olayli():
        _olay("kutu", metin=_duz(metin), etiket=_duz(etiket),
              renk=list(renk_adlari))
        return
    g = genislik()
    ic = g - 4
    if etiket:
        etiketli = S["sol_ust"] + S["yatay"] + " " + etiket + " "
        kalan = g - len(etiketli) - 1
        ust = etiketli + S["yatay"] * max(0, kalan) + S["sag_ust"]
    else:
        ust = S["sol_ust"] + S["yatay"] * (g - 2) + S["sag_ust"]
    _KABUK.bas(renkli(ust, "gri"))
    for ham in metin.split("\n"):
        parcalar = textwrap.wrap(ham, width=ic, break_long_words=False) if ham.strip() else [""]
        for satir in parcalar:
            dolgu = " " * max(0, ic - gorunur_uzunluk(satir))
            _bas(
                renkli(S["dikey"], "gri") + " " + renkli(satir, *renk_adlari)
                + dolgu + " " + renkli(S["dikey"], "gri")
            )
    _KABUK.bas(renkli(S["sol_alt"] + S["yatay"] * (g - 2) + S["sag_alt"], "gri"))


def madde(metin: str, *renk_adlari: str, isaret: str = "") -> None:
    isaret = isaret or S["madde"]
    if _olayli():
        _olay("yaz", metin=_duz(metin), renk=list(renk_adlari), girinti="   ",
              tur="madde", isaret=isaret)
        return
    yaz(isaret + " " + metin, *renk_adlari, girinti="   ")


def asili_yaz(onek: str, metin: str, *renk_adlari: str, onek_renkleri=()) -> None:
    """
    Asılı girintili yazım: ilk satır önekle başlar, devam satırları önek
    genişliği kadar içeriden hizalanır. Uzun şıkların okunaklı kalması için.
    """
    if _olayli():
        _olay("yaz", metin=_duz(onek) + _duz(metin), renk=list(renk_adlari),
              girinti="", tur="asili", onek=_duz(onek))
        return
    onek_uzunlugu = gorunur_uzunluk(onek)
    kalan = max(20, genislik() - onek_uzunlugu)
    satirlar = textwrap.wrap(metin, width=kalan, break_long_words=False,
                             break_on_hyphens=False) or [""]
    boyali_onek = renkli(onek, *onek_renkleri) if onek_renkleri else onek
    _bas(boyali_onek + renkli(satirlar[0], *renk_adlari))
    for satir in satirlar[1:]:
        _bas(" " * onek_uzunlugu + renkli(satir, *renk_adlari))


_TR_KUCUK_BUYUK = str.maketrans({"i": "İ", "ı": "I", "ş": "Ş", "ğ": "Ğ",
                                 "ü": "Ü", "ö": "Ö", "ç": "Ç"})


def tr_kucuk(metin: str) -> str:
    """Turkce kurallarina gore kucuk harfe cevirir.

    Python'un `lower()` metodu "I" harfini "i" yapar; Turkcede dogrusu
    noktasiz "i"dir ve "İ" ise "i" olur. Isim karsilastirmasinda bu fark
    "IREM" ile "İrem"i ayri kisi sayar.
    """
    return metin.replace("I", chr(305)).replace(chr(304), "i").lower()


# Ad ARAMASINDA denk sayilan harfler. Gosterimde degil, YALNIZCA eslestirmede.
#
# Turkce kurali "IREM" ile "İrem"i ayri sayar (I -> i, İ -> i) ve gosterim
# icin bu dogru. Ama burada yapilan is kendi kaydini arayan ogrenciyi
# bulmak. Telefonda buyuk harf kilidi acik kalinca ya da klavyede duzeltme
# calisinca ogrenci kendi adini "yanlis" yaziyor ve kaydini bulamiyor --
# oysa hangi kaydi aradigini bilen tek kisi kendisi.
#
# Serfleri (â î û) de duselyor: "Kâşif" yerine "Kasif" yazmak cok yaygin.
# Ş/S ya da C/Ç BIRLESTIRILMIYOR; onlar ayri harflerdir ve "Askin" ile
# "Askin" farkli isimler olabilir.
_ARAMA_DENKLIGI = {
    ord(chr(305)): "i",   # i (noktasiz) -> i
    ord(chr(304)): "i",   # İ            -> i
    ord("â"): "a", ord("î"): "i", ord("û"): "u",
    ord("Â"): "a", ord("Î"): "i", ord("Û"): "u",
}


def _arama_bicimi(metin: str) -> str:
    sade = " ".join((metin or "").split())
    return tr_kucuk(sade).translate(_ARAMA_DENKLIGI)


def ayni_ad(a: str, b: str) -> bool:
    """Iki ad ayni kisiyi mi gosteriyor?

    Bosluk, buyuk/kucuk, i/i ve serf farklari onemsiz. Bkz. _ARAMA_DENKLIGI.
    """
    return _arama_bicimi(a) == _arama_bicimi(b)


def tr_buyuk(metin: str) -> str:
    """
    Türkçe kurallarına göre büyük harfe çevirir.

    Python'un upper() metodu "i" harfini "I" yapar; Türkçede doğrusu "İ"dir.
    Başlıkta "İki İstasyon" yazan bir görev, upper() ile "İKI İSTASYON" olur.
    """
    return metin.translate(_TR_KUCUK_BUYUK).upper()


def basari(metin: str) -> None:
    if _olayli():
        _olay("bildirim", tur="basari", metin=_duz(metin))
        return
    yaz(S["onay"] + " " + metin, "acik_yesil", "kalin")


def hata(metin: str) -> None:
    if _olayli():
        _olay("bildirim", tur="hata", metin=_duz(metin))
        return
    yaz(S["carpi"] + " " + metin, "kirmizi")


def bilgi(metin: str) -> None:
    if _olayli():
        _olay("bildirim", tur="bilgi", metin=_duz(metin))
        return
    yaz(S["ok"] + " " + metin, "acik_sari")


def cubuk(deger: float, azami: float, uzunluk: int = 18) -> str:
    """Metinsel ilerleme çubuğu."""
    oran = 0.0 if azami <= 0 else max(0.0, min(1.0, float(deger) / float(azami)))
    dolu = int(round(oran * uzunluk))
    return S["dolu"] * dolu + S["bos"] * (uzunluk - dolu)


def yildizlar(sayi: int, azami: int = 3) -> str:
    sayi = max(0, min(azami, int(sayi)))
    return S["yildiz"] * sayi + S["bos_yildiz"] * (azami - sayi)


def temizle() -> None:
    """Ekrani temizler. Temizleyemezse gorsel bir ayrac cizer."""
    if _olayli():
        _olay("temizle")
        return
    if _KABUK.temizle():
        return
    _KABUK.bas("")
    ayrac(S["kalin_yatay"])


# --------------------------------------------------------------------------
# Girdi
# --------------------------------------------------------------------------

class OyunuBirak(Exception):
    """Oyuncu her yerden çıkabilsin diye kullanılan kontrol istisnası."""


def _oku(istem: str) -> str:
    try:
        return _KABUK.oku(istem)
    except (EOFError, KeyboardInterrupt):
        _KABUK.bas("")
        raise OyunuBirak()


# `menu`/`onayla` gibi ust islevler cevabi yine `sor` ile ister (testler `sor`u
# yerine koyabilsin diye imza degismez); girdi olayinin bicimini bu ara
# deger tasir.
_SIRADAKI_GIRDI = None


def _bicimli_sor(istem: str, bicim: str, varsayilan: str = "") -> str:
    global _SIRADAKI_GIRDI
    if not _olayli():
        return sor(istem)
    _SIRADAKI_GIRDI = (bicim, varsayilan)
    try:
        return sor(istem)
    finally:
        _SIRADAKI_GIRDI = None


def sor(istem: str = "", varsayilan: str = "") -> str:
    if _olayli():
        bicim, onayin_varsayilani = _SIRADAKI_GIRDI or ("metin", "")
        _olay("girdi", istem=_duz(istem),
              varsayilan=onayin_varsayilani or varsayilan, bicim=bicim)
    ok = renkli(S["ok"], "acik_cam", "kalin")
    cevap = _oku("\n" + ok + " " + istem + " ").strip()
    if not cevap and varsayilan:
        return varsayilan
    return cevap


def bekle(istem: str = "Devam etmek için Enter...") -> None:
    if _olayli():
        _olay("girdi", istem=_duz(istem), varsayilan="", bicim="bekle")
    _oku("\n" + renkli("   " + istem, "gri"))


def onayla(istem: str, varsayilan: bool = True) -> bool:
    ipucu = "[E/h]" if varsayilan else "[e/H]"
    while True:
        cevap = _bicimli_sor(istem + " " + ipucu, "onay",
                             "e" if varsayilan else "h").lower()
        if not cevap:
            return varsayilan
        if cevap[0] in "ey1":
            return True
        if cevap[0] in "hn0":
            return False


# Menude YAZMAYAN bir secenek secildiginde `menu` bunu dondurur.
GIZLI_SECIM = -1


def _sade(metin: str) -> str:
    """"Öğretmen", "ÖĞRETMEN" ve "ogretmen" aynı sayılsın."""
    return (metin or "").strip().casefold().translate(
        str.maketrans("çğıöşüâîû", "cgiosuaiu"))


def _olay_secenekleri(secenekler) -> list:
    sonuc = []
    for oge in secenekler:
        if isinstance(oge, (tuple, list)):
            metin, aciklama = oge[0], oge[1]
        else:
            metin, aciklama = oge, ""
        sonuc.append({"metin": _duz(metin), "aciklama": _duz(aciklama)})
    return sonuc


def _menu_yaz(baslik_metni, secenekler, ipucu) -> None:
    if baslik_metni:
        yaz()
        yaz(baslik_metni, "kalin", "acik_cam")
    for sira, oge in enumerate(secenekler, start=1):
        if isinstance(oge, (tuple, list)):
            metin, aciklama = oge[0], oge[1]
        else:
            metin, aciklama = oge, ""
        numara = renkli("[{}]".format(sira), "acik_sari", "kalin")
        _KABUK.bas("  " + numara + " " + metin)
        if aciklama:
            yaz(aciklama, "gri", girinti="      ")
    if ipucu:
        yaz(ipucu, "gri", girinti="  ")


def menu(baslik_metni: str, secenekler, ipucu: str = "", gizli=()) -> int:
    """
    Numaralı menü gösterir, seçilen öğenin indeksini döndürür.
    'secenekler' bir dizi metin ya da (metin, açıklama) çiftidir.

    'gizli': listede görünmeyen, yazılınca açılan sözcükler (ör. öğretmen
    girişi). Biri yazılırsa GIZLI_SECIM döner. Hata iletisi onları anmaz.
    """
    gizli = {_sade(g) for g in gizli}
    if _olayli():
        _olay("menu", baslik=_duz(baslik_metni),
              secenekler=_olay_secenekleri(secenekler), ipucu=_duz(ipucu),
              gizli_var=bool(gizli))
    else:
        _menu_yaz(baslik_metni, secenekler, ipucu)
    while True:
        cevap = _bicimli_sor("Seçim:", "menu")
        # isdigit() DEGIL isdecimal(). Fark oldurucu: "²" (ustsimge iki)
        # icin isdigit() True doner ama int() ValueError atar. Bagimsiz bir
        # oyun testi (8 Eylul 2026) bunu buldu -- herhangi bir menude "²"
        # yazmak oyunu cokertiyordu ve BU FONKSIYONU HER MENU KULLANIYOR.
        # Ayni kalip degerlendirme.py, oturum.py ve rapor.py'de de vardi.
        if cevap.isdecimal() and 1 <= int(cevap) <= len(secenekler):
            return int(cevap) - 1
        if gizli and _sade(cevap) in gizli:
            return GIZLI_SECIM
        hata("1 ile {} arasında bir sayı gir.".format(len(secenekler)))


def coklu_sec(baslik_metni: str, secenekler, ipucu: str = "",
              sirali: bool = False) -> list:
    """Birden çok seçim: "1 3" ya da "1,3" yazılır; indeks listesi döner.

    Telefonda ayrı bir arayüz öğesi yok (TASARIM_NOTLARI §8: motor kabuğu
    bilmez), bu yüzden çoklu seçim de düz metin girdisiyle yapılıyor.
    `sirali=True` ise yazılan SIRA korunur: "2 1 4" önce ikinciyi seçmek
    demektir. Aynı numara iki kez yazılırsa bir kez sayılır.

    Dokuzdan az seçenek varsa "13" gibi bitişik yazım da kabul edilir;
    telefonda boşluk tuşuna uzanmak bir sürtünme.
    """
    if _olayli():
        _olay("coklu", baslik=_duz(baslik_metni),
              secenekler=_olay_secenekleri(secenekler), ipucu=_duz(ipucu),
              en_az=1, en_cok=len(secenekler), sirali=bool(sirali))
    else:
        _menu_yaz(baslik_metni, secenekler, ipucu)
    while True:
        parcalar = _bicimli_sor("Seçimlerin:", "coklu").replace(",", " ").split()
        if (len(parcalar) == 1 and len(parcalar[0]) > 1
                and len(secenekler) <= 9 and parcalar[0].isdecimal()):
            parcalar = list(parcalar[0])
        secilen = []
        gecerli = bool(parcalar)
        for parca in parcalar:
            # isdecimal, isdigit DEGIL: bkz. menu() -- "²" oyunu cokertiyordu.
            if not (parca.isdecimal() and 1 <= int(parca) <= len(secenekler)):
                gecerli = False
                break
            indeks = int(parca) - 1
            if indeks not in secilen:
                secilen.append(indeks)
        if gecerli:
            return secilen if sirali else sorted(secilen)
        hata("1 ile {} arasında numaralar yaz; birden çoksa aralarına "
             "boşluk koy (ör. 1 3).".format(len(secenekler)))
