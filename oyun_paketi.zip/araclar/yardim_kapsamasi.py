# -*- coding: utf-8 -*-
"""
Yardım kapsaması: hangi adımda gerçekten yardım var?

    python main.py --yardim-kapsamasi
    python main.py --yardim-kapsamasi matematik

NEDEN VAR
---------
8 Eylül 2026'da bu sayılar ELLE sayıldı ve
`taramalar/oyun_testi_zorlanan.md` içine yazıldı:

    cozum_bedeli>0 ama çözüm metni YOK : 1008 adım (%80,7)
    hiç ipucu olmayan adım             :  307 adım (%24,6)
    basit örnek BULUNAMAYAN bulmaca    :   90 / 384 (%23,4)
    ÜÇ YARDIMIN ÜÇÜ DE BOŞ olan adım   :   70 / 1245 (%5,6)

Elle sayılan bir sayı bir kere doğrudur. İçerik yazıldıkça bu oranların
düşmesi gerekiyor ve düştüğünü GÖRMEK gerekiyor; yoksa "içerik ekledim"
bir his olarak kalır. Bu dosya o ölçümü tekrarlanabilir yapıyor.

`--denetle` ile karıştırma: o TUTARLILIK bakar (cevap doğru mu, üretici
patlıyor mu). Bu ise KAPSAMA bakar -- içerik doğru ama eksik olabilir.

NOT: buradaki "yardım yok" bir hata değil, bir içerik boşluğudur. Hatanın
kendisi (olmayan yardımı ekranda ilan etmek) `oturum.py` içinde
düzeltildi; bkz. `_mevcut_yardimlar`. Bu araç boşluğun BÜYÜKLÜĞÜNÜ
ölçüyor ki nereye içerik yazılacağı bilinsin.
"""
from __future__ import annotations

import random
from typing import Dict, List

from oyun.motor.kayit_defteri import icerigi_yukle, tum_kayitlar

# Kaç tohumla üretilsin. Denetimdeki kadar çok gerekmiyor: burada aranan
# şey nadir bir kırılma değil, genel oran.
TOHUM_SAYISI = 3


def _bos(metin) -> bool:
    return not (metin or "").strip()


def olc(ders: str = "", tohum_sayisi: int = TOHUM_SAYISI) -> Dict[str, object]:
    """Bütün üreticileri koşturup yardım kapsamasını sayar."""
    icerigi_yukle()
    kayitlar = [k for k in tum_kayitlar() if not ders or k.ders == ders]

    sayac = {
        "bulmaca": 0, "adim": 0,
        "cozum_metni_yok": 0, "cozum_bedeli_var_metin_yok": 0,
        "ipucu_yok": 0, "kanit_yok_bulmaca": 0, "hicbiri_yok": 0,
        # `aciklama` hakki bitince gosteriliyor; `cozum` ise ISTEK UZERINE.
        # Ikisi ayri sey: biri "sonunda ogren", digeri "simdi yardim et".
        "aciklama_yok": 0, "cozum_de_aciklama_da_yok": 0,
    }
    ders_bazli: Dict[str, Dict[str, int]] = {}

    for kayit in kayitlar:
        alt, ust = kayit.kademeler
        for kademe in range(alt, ust + 1):
            for tohum in range(tohum_sayisi):
                try:
                    b = kayit.fonksiyon(
                        random.Random(tohum * 7919 + kademe), kademe)
                except Exception:          # noqa: BLE001 - denetimin işi bu değil
                    continue
                if b is None:
                    continue
                sayac["bulmaca"] += 1
                d = ders_bazli.setdefault(
                    kayit.ders, {"adim": 0, "cozum_yok": 0, "ipucu_yok": 0,
                                 "hicbiri_yok": 0})
                kanit_var = bool(getattr(b, "kanitlar", None))
                if not kanit_var:
                    sayac["kanit_yok_bulmaca"] += 1
                for adim in getattr(b, "adimlar", []) or []:
                    sayac["adim"] += 1
                    d["adim"] += 1
                    cozum_yok = _bos(getattr(adim, "cozum", ""))
                    ipucu_yok = not (getattr(adim, "ipuclari", None) or [])
                    if cozum_yok:
                        sayac["cozum_metni_yok"] += 1
                        d["cozum_yok"] += 1
                        if getattr(adim, "cozum_bedeli", 0):
                            sayac["cozum_bedeli_var_metin_yok"] += 1
                    if ipucu_yok:
                        sayac["ipucu_yok"] += 1
                        d["ipucu_yok"] += 1
                    aciklama_yok = _bos(getattr(adim, "aciklama", ""))
                    if aciklama_yok:
                        sayac["aciklama_yok"] += 1
                    if cozum_yok and aciklama_yok:
                        sayac["cozum_de_aciklama_da_yok"] += 1
                    if cozum_yok and ipucu_yok and not kanit_var:
                        sayac["hicbiri_yok"] += 1
                        d["hicbiri_yok"] += 1

    return {"sayac": sayac, "ders_bazli": ders_bazli}


def _yuzde(pay: int, payda: int) -> str:
    return "%{:.1f}".format(100.0 * pay / payda) if payda else "-"


def yazdir(ders: str = "", tohum_sayisi: int = TOHUM_SAYISI) -> int:
    sonuc = olc(ders, tohum_sayisi)
    s = sonuc["sayac"]
    adim, bulmaca = s["adim"], s["bulmaca"]
    if not adim:
        print("Hiç adım üretilemedi.")
        return 1

    print()
    print("YARDIM KAPSAMASI" + (" — " + ders if ders else ""))
    print("=" * 64)
    print("  {} bulmaca, {} adım  ({} tohum)".format(bulmaca, adim, tohum_sayisi))
    print()
    satirlar = [
        ("çözüm metni olmayan adım", s["cozum_metni_yok"], adim),
        ("  bunlardan bedeli tanımlı olan", s["cozum_bedeli_var_metin_yok"], adim),
        ("hiç ipucu olmayan adım", s["ipucu_yok"], adim),
        ("açıklaması olmayan adım", s["aciklama_yok"], adim),
        ("  ne çözüm ne açıklama (GERÇEK boşluk)",
         s["cozum_de_aciklama_da_yok"], adim),
        ("ÜÇ YARDIMIN ÜÇÜ DE BOŞ olan adım", s["hicbiri_yok"], adim),
        ("kaynağı olmayan bulmaca", s["kanit_yok_bulmaca"], bulmaca),
    ]
    for etiket, pay, payda in satirlar:
        print("  {:<38} {:>5} / {:<5} {}".format(
            etiket, pay, payda, _yuzde(pay, payda)))

    print()
    print("  DERS BAZINDA (çözüm metni olmayan adım oranı)")
    for ders_adi, d in sorted(sonuc["ders_bazli"].items(),
                              key=lambda x: -x[1]["cozum_yok"] / max(1, x[1]["adim"])):
        print("    {:<24} {:>6}  (üçü de boş: {})".format(
            ders_adi, _yuzde(d["cozum_yok"], d["adim"]),
            _yuzde(d["hicbiri_yok"], d["adim"])))

    print()
    print("  Not: bu sayılar İÇERİK boşluğudur, hata değil. Oyun artık")
    print("  olmayan yardımı ekranda İLAN ETMİYOR (E01); yukarıdaki oranlar")
    print("  düştükçe öğrencinin eline geçen destek artar.")
    print("=" * 64)
    return 0


def main(ders: str = "") -> int:
    return yazdir(ders)


if __name__ == "__main__":
    import sys
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else ""))
