# -*- coding: utf-8 -*-
"""
Oyunun dış kabuğu: menüler, görev panosu, karne, kayıt.

Buradaki hiçbir şey ders içeriğini bilmez. Ders eklemek için bu dosyaya
dokunmak gerekmez; oyun.icerik altına yeni bir modül koymak yeterlidir.
"""
from __future__ import annotations

import json
import os
import time
from typing import List, Optional, Tuple

from . import durum as durum_modulu
from . import degerlendirme
from . import ilerleme
from . import ittifak
from . import ders_programi
from .anlati import TARZLAR, konu_etiketi, tarz
from . import terminal as ekran
from .kayit_defteri import (
    icerigi_yukle, kademede_acik_mi, kapsama_raporu, konular, sefer_kayitlari,
    sefer_uret, tum_kayitlar, uret, uygun_kayitlar,
)
from .modeller import (
    ANLATIM, ASAMA_ADLARI, BIRLIKTE, Bulmaca, DERS_ADLARI, DERS_KISA,
    DERS_RENGI, DERSLER,
    KADEME_ADLARI, OGRENME_YOLLARI, SERBEST, ZORLUK_ACIKLAMALARI,
    ZORLUK_ADLARI, ZORLUK_KADEME, alan_yolu, kademe_zorlugu, secmeli_yol_mu,
    yol_alanlari,
)
from .durum import Durum, KAYNAK_ADLARI, KAYNAKLAR
from .oturum import Oturum, sonucu_ozetle
from .terminal import OyunuBirak, S

OYUN_ADI = "MERİDYEN SEFERİ"
ALT_BASLIK = "sefer kayıtları"

# Yıldıza göre ödül çarpanı
YILDIZ_CARPANI = {0: 0.2, 1: 0.6, 2: 1.0, 3: 1.4}
# Şu an oyundaki TEK kaynak gideri. Koloni döngüsü yazıldığında burası
# tek başına kalmayacak: tesis onarımı, masa açma ve sefer başlatma da
# kaynak harcayacak. Bkz. TASARIM_NOTLARI.md §3
GOREV_BEDELI = {"enerji": 1}

# Zaman seferi baslatma bedeli. TASARIM_NOTLARI §3'un adiyla saydigi
# giderlerden biri: "kaynak yalnizca ogrenerek kazanilir ve yalnizca
# ogrenmeye harcanir: yeni masa acmak, ipucu almak, zaman seferi
# baslatmak, tesis onarmak."
#
# NEDEN BU GEREKLI: olculdu (5 Eylul 2026). Gorev basina kazanc erzak 1,2 /
# itibar 4,2 / cevher 1,0 / enerji 1,3; tek gider gorev basina 1 enerji.
# Yani enerji bile NET ARTIYOR, digerlerinin hic gideri yok. 40 gorev
# sonra itibar 0'dan 168'e cikiyor ve hicbir ise yaramiyor. Ekranda duran
# sayilar dekordu.
#
# Bedel olculerek secildi. Erzak/cevher/enerji baslangic degerlerinin
# (40/20/30) altinda, yani onlar ilk gunden karsilaniyor. Baglayici olan
# ITIBAR: 0'dan basliyor ve gorev basina ~4,2 kazaniliyor, yani ilk sefer
# icin ~3 gorev cozmek gerekiyor.
#
# Bu bilerek boyle: ogrenci once temel donguyu ogrensin, sonra oyunun en
# ozgun icerigi (TASARIM_NOTLARI §9-6) acilsin. Ama pist KISA tutuldu --
# 3 gorev bir angarya degil, bir giris. Oyunun en iyi parcasini uzun bir
# ogutme arkasina kilitlemek kaynak dongusunun amaci degil.
SEFER_BEDELI = {"erzak": 6, "cevher": 5, "enerji": 8, "itibar": 12}


class Oyun:
    def __init__(self, durum: Durum):
        self.durum = durum
        self.teklifler: List[Bulmaca] = []
        # Pano her yenilendiğinde artar. Kayıt tohumuna dokunmadan farklı
        # görevler getirebilmek için ayrı tutuluyor.
        self.pano_sayaci = 0
        self._teklif_baglami = None
        self.odak_uyarisi = ""
        ekran.yazim_hizi_ayarla(float(durum.ayarlar.get("yazim_hizi", 0.0)))

    # ------------------------------------------------------------------ giriş
    def calistir(self) -> None:
        from oyun.icerik import hikaye

        hikaye.bolumu_kontrol_et(self.durum, ilk_giris=True)
        while True:
            secim = self._ana_menu()
            if secim == 0:
                self._konu_calis()
            elif secim == 1:
                self._gorev_panosu()
            elif secim == 2:
                self._zaman_seferi()
            elif secim == 3:
                self._konu_taramasi()
            elif secim == 4:
                self._karne()
            elif secim == 5:
                self._gunluk()
            elif secim == 6:
                self._ayarlar()
            elif secim == 7:
                self._geri_bildirim()
            elif secim == 8:
                from araclar.program import program_ekrani
                program_ekrani(durum=self.durum)
                self.teklifler = []
            elif secim == 9:
                from .kisa_oturum import kisa_sefer
                if kisa_sefer(self.durum):
                    hikaye.bolumu_kontrol_et(self.durum)
                    self.durum.kaydet()
                self.teklifler = []
            elif secim == 10:
                yol = self.durum.kaydet()
                ekran.yaz()
                ekran.basari("Kaydedildi: " + yol)
                # Nöbet biterken karne: öğrenci ne yaptığını tek sayfada görsün,
                # isterse öğretmene/veliye götürebileceği bir belge alsın.
                if ekran.onayla("Bu seferin karnesine bakalım mı?", True):
                    from araclar.karne import karne_ekrani
                    karne_ekrani(self.durum)
                else:
                    ekran.bekle()
                return

    def _ust_pano(self) -> None:
        ekran.temizle()
        ekran.baslik(OYUN_ADI, "kalin", "acik_cam")
        d = self.durum
        sol = "{}  {}  {}".format(d.ad, S["dikey"], d.rutbe)
        sag = d.ozet_satiri()
        bosluk = max(1, ekran.genislik() - len(sol) - len(sag))
        ekran.ham_yaz(ekran.renkli(sol, "kalin") + " " * bosluk + ekran.renkli(sag, "acik_sari"))

        from oyun.icerik import hikaye
        bolum = hikaye.BOLUMLER[min(d.bolum, len(hikaye.BOLUMLER) - 1)]
        sonraki = hikaye.BOLUMLER[d.bolum + 1] if d.bolum + 1 < len(hikaye.BOLUMLER) else None
        if sonraki:
            ilerleme_cubugu = ekran.cubuk(
                min(d.oynanan_gorev, sonraki.gereken_gorev),
                max(1, sonraki.gereken_gorev), 12)
            bolum_satiri = "{}  {}  Sonraki keşif: {} {}/{}".format(
                bolum.baslik, ilerleme_cubugu, sonraki.baslik,
                min(d.oynanan_gorev, sonraki.gereken_gorev), sonraki.gereken_gorev)
        else:
            bolum_satiri = "{}  {}  Ana sefer tamamlandı".format(
                bolum.baslik, ekran.cubuk(1, 1, 12))
        ekran.yaz(bolum_satiri, "acik_mor")
        satir = "Zorluk {} - {}  {}  Destek: uyarlanır".format(
            d.zorluk, d.zorluk_adi, S["dikey"])
        # Sinif bagi varsa okulunu ve sinifini goster. §0 geregi burada
        # SIRALAMA YOK: kac kisi oldugu yaziyor, kimin nerede oldugu degil.
        if d.sinif_kodu:
            try:
                from araclar.sinif import sinif_ogrencileri
                adet = len(sinif_ogrencileri(d.sinif_kodu))
            except Exception:  # noqa: BLE001 - pano yuzunden oyun durmasin
                adet = 0
            if adet:
                satir += "  {}  {}{}: {} kişi".format(
                    S["dikey"], d.sinif,
                    " / " + d.okul if d.okul else "", adet)
        ekran.yaz(satir, "gri")
        ekran.ayrac()

    @staticmethod
    def _bedel_metni(bedel) -> str:
        return " ".join("{} {}".format(KAYNAK_ADLARI.get(a, a), m)
                        for a, m in bedel.items() if m)

    def _eksik_kaynaklar(self, bedel) -> dict:
        """Neyin ne kadar eksik oldugu. Bos sozluk = yetiyor."""
        return {a: m - self.durum.kaynaklar.get(a, 0)
                for a, m in (bedel or {}).items()
                if self.durum.kaynaklar.get(a, 0) < m}

    def _bedeli_ode(self, bedel, ne_icin: str) -> bool:
        """Kaynak yeterse duser ve True doner; yetmezse NEYIN eksik oldugunu soyler.

        `durum.kaynak_yeter_mi()` uzun suredir yazili ama hicbir yerden
        cagrilmiyordu (TASARIM_NOTLARI §3 bunu ismen soyluyor). Giris
        noktasi burasi.
        """
        if self.durum.kaynak_yeter_mi(bedel):
            self.durum.kaynak_ekle({a: -m for a, m in bedel.items()})
            return True
        eksik = self._eksik_kaynaklar(bedel)
        ekran.yaz()
        ekran.hata("{} için kaynağın yetmiyor.".format(ne_icin))
        ekran.yaz("Eksik: " + self._bedel_metni(eksik), "acik_sari")
        # §0: engel ceza degil, yon gosterme. Ne yapacagini soyluyoruz.
        ekran.yaz("Görev çözerek kazanılır; birkaç iş sonra yeniden dene.", "gri")
        ekran.bekle()
        return False

    def _ana_menu(self) -> int:
        self._ust_pano()
        from oyun.icerik import hikaye
        gorev = hikaye.gunun_hedefi(self.durum)
        if gorev:
            ekran.yaz(gorev, "acik_cam")
        haberler = [
            "Kuzey kulesinden duman görülüyor; nöbetçi bunun sis olmadığını söylüyor.",
            "Arşiv görevlisi, üstü çizilmiş yeni bir dosyayı masaya bıraktı.",
            "Kronograf odasından kısa bir metal sesi geldi. Aygıt yeniden etkin.",
            "Depo sayımı yine tutmadı. Komutan gün bitmeden açıklama bekliyor.",
            "Keşif ekibi haritada işaretlenmemiş bir patika buldu.",
        ]
        ekran.yaz()
        ekran.kutu(haberler[self.durum.oynanan_gorev % len(haberler)],
                   "ÜSTEN HABER", "beyaz")
        return ekran.menu("ÜSTE NEREYE GİDECEKSİN?", [
            ("Usta Çadırı", "önce izle, sonra yanında dururum, sonra sen yap"),
            ("Komuta Masası", "üssün bekleyen saha görevleri"),
            ("Kronograf Odası", "bir çağın içine gir: çağı çöz, yeri bul, hesapla, raporla"
             + "  (" + self._bedel_metni(SEFER_BEDELI) + ")"),
            ("İz Sürme Masası", "neyi bildiğini bilmediğin işler için kısa bakış"),
            ("Harita Odası", "açılan yollar, eline geçen işler ve sıradaki hedef"),
            ("Kâşif Günlüğü", "olaylar, rütbeler ve rozetler"),
            ("Teçhizat ve Ayarlar", "hikâye tercihi, zorluk, ipuçları ve yazım hızı"),
            ("Geri Bildirim Gönder", "not yaz, ilerlemenle birlikte paketle"),
            ("Okul Ders Programı", "haftalık saatler ve görevlerin ders odağı"),
            ("Kısa Sefer", "bir dosyayla başla; bitince bırak veya devam et"),
            ("Nöbeti Devret", "kaydet ve ana ekrana dön"),
        ])

    # ------------------------------------------------------------- konu çalış
    def _konu_durum_etiketi(self, konu_durumu) -> Tuple[str, str, str]:
        """(kutu, etiket, renk) - konu haritasındaki durum sütunu."""
        if konu_durumu.tamamlandi:
            return "[{}]".format(S["onay"]), "oturdu", "acik_yesil"
        if not konu_durumu.baslanmis:
            return "[ ]", "yeni", "gri"
        if konu_durumu.asama == ANLATIM:
            return "[1]", "anlatım", "acik_cam"
        if konu_durumu.asama == BIRLIKTE:
            return "[2]", "birlikte", "acik_sari"
        return "[3]", "kendi", "acik_mavi"

    def _onerilen_konu(self, ders: str, konu_listesi) -> str:
        """
        Sıradaki konu: önce yarım kalanlar, sonra hiç başlanmamışlar.

        Amaç öğrenciyi seçim yapmak zorunda bırakmamak; "nereden devam
        edeceğimi bilmiyorum" en sık takılma sebebi.
        """
        ders_durumu = self.durum.ders(ders)
        yarim = [k for k in konu_listesi
                 if ders_durumu.konu(k).baslanmis and not ders_durumu.konu(k).tamamlandi]
        if yarim:
            return min(yarim, key=lambda k: ders_durumu.konu(k).ustalik)
        yeni = [k for k in konu_listesi if not ders_durumu.konu(k).baslanmis]
        if yeni:
            return yeni[0]
        return min(konu_listesi, key=lambda k: ders_durumu.konu(k).ustalik)

    def _acik_yollar(self) -> List[str]:
        """
        Oyuncunun bulunduğu zorlukta gerçekten iş çıkan yollar.

        Kapalı bir masayı listede göstermek öğrenciyi boş bir kapıya yollamak
        olur: Keşif düzeyindeki bir çocuk meslek dersi masasına oturamaz,
        oturursa da eline yaşına uymayan bir dosya geçer.
        """
        merkez = ZORLUK_KADEME[self.durum.zorluk]
        acik = []
        for yol in OGRENME_YOLLARI:
            if any(kademede_acik_mi(alan, merkez) for alan in yol_alanlari(yol)):
                acik.append(yol)
        return acik

    def _acik_konular(self, yol: str,
                      yalniz_alan: str = "") -> List[Tuple[str, str]]:
        """
        Bir yolda, oyuncunun zorluğunda gerçekten üretilebilen (alan, konu)
        çiftleri. Listede görünen her iş açılabilmelidir.

        `yalniz_alan` verilirse yalnızca o alan listelenir; meslek yolunda
        öğrenci kendi dalını seçtiğinde kullanılır.
        """
        merkez = ZORLUK_KADEME[self.durum.zorluk]
        alanlar = [yalniz_alan] if yalniz_alan else yol_alanlari(yol)
        cift: List[Tuple[str, str]] = []
        for alan in alanlar:
            for konu in konular(alan):
                if kademede_acik_mi(alan, merkez, konu=konu):
                    cift.append((alan, konu))
        return cift

    def _acik_dallar(self, yol: str) -> List[str]:
        """Bu yolda, oyuncunun zorluğunda işi olan alanlar."""
        merkez = ZORLUK_KADEME[self.durum.zorluk]
        return [a for a in yol_alanlari(yol) if kademede_acik_mi(a, merkez)]

    def _dal_sec(self, yol: str) -> Optional[str]:
        """
        Meslek yolunda hangi bölümde çalışılacağını sorar ve hatırlar.

        Akademik yollarda ders adı gösterilmez - orada karışık liste bilerek
        böyledir. Ama meslek dalı öğrencinin KENDİ bölümüdür; dört bölümün
        işini tek listede karıştırmak, marangozu bilişim konuları arasında
        gezdirmek olur.
        """
        dallar = self._acik_dallar(yol)
        if len(dallar) <= 1:
            return dallar[0] if dallar else None
        if self.durum.dal in dallar:
            return self.durum.dal

        secenekler = [(DERS_ADLARI[a], "{} iş".format(
            len(self._acik_konular(yol, a)))) for a in dallar]
        secenekler.append(("Geri dön", ""))
        self._ust_pano()
        ekran.yaz("HANGİ BÖLÜMDESİN?", "kalin", "acik_cam")
        ekran.yaz("Bir kez soruyorum; bundan sonra doğrudan kendi masana "
                  "oturacaksın. Ayarlardan değiştirebilirsin.", "gri")
        secim = ekran.menu("", secenekler)
        if secim >= len(dallar):
            return None
        self.durum.dal = dallar[secim]
        self.durum.kaydet()
        return self.durum.dal

    def _konu_calis(self) -> None:
        secenekler = []
        yol_kodlari = self._acik_yollar()
        if not yol_kodlari:
            ekran.hata("Bu zorlukta açık masa yok. Ayarlardan zorluğu "
                       "değiştirebilirsin.")
            ekran.bekle()
            return
        for yol in yol_kodlari:
            bilgi = OGRENME_YOLLARI[yol]
            toplam = oturmus = 0
            for alan, konu in self._acik_konular(yol):
                toplam += 1
                oturmus += int(self.durum.ders(alan).konu(konu).tamamlandi)
            secenekler.append((bilgi["ad"], "{} iş var; {} tanesi elinde".format(
                toplam, oturmus)))
        secenekler.append(("Geri dön", ""))

        self._ust_pano()
        ekran.yaz("USTA ÇADIRI", "kalin", "acik_cam")
        ekran.yaz("Burada bir işi önce izlersin, sonra yanında dururum, en "
                  "sonunda tek başına yaparsın.", "gri")
        secim = ekran.menu("Hangi masaya oturalım?", secenekler)
        if secim >= len(yol_kodlari):
            return
        self._yol_haritasi(yol_kodlari[secim])

    def _yol_haritasi(self, yol: str) -> None:
        """Ders adlarını göstermeden bir öğrenme yolundaki bütün konuları sunar."""
        # Meslek yolu istisnadır: orada dört bölümün işi tek listede
        # karışmasın diye önce dal sorulur. Bkz. _dal_sec.
        if secmeli_yol_mu(yol):
            dal = self._dal_sec(yol)
            if dal is None:
                return
            self._konu_haritasi(dal)
            return

        while True:
            paketler = [(alan, konu, self.durum.ders(alan).konu(konu))
                        for alan, konu in self._acik_konular(yol)]
            if not paketler:
                ekran.hata("Bu masada senin zorluğunda şimdilik iş yok. "
                           "Ayarlardan zorluğu değiştirmeyi deneyebilirsin.")
                ekran.bekle()
                return
            self._ust_pano()
            ekran.yaz("USTA ÇADIRI - {}".format(OGRENME_YOLLARI[yol]["ad"]),
                      "kalin", "acik_cam")
            ekran.yaz(OGRENME_YOLLARI[yol]["aciklama"], "gri")
            ekran.yaz()
            ekran.yaz("{:<12}{:<34}{}".format("DURUM", "İŞ", "ELİN ALIŞTI MI"), "gri")
            for alan, konu, kd in paketler:
                kutu, etiket, renk = self._konu_durum_etiketi(kd)
                ilerleme_metni = ("%{}".format(int(round(kd.ustalik * 100)))
                                  if kd.serbest_toplam else "-")
                satir = "{} {:<9}{:<34}{}".format(
                    kutu, etiket, konu_etiketi(self.durum, alan, konu)[:33], ilerleme_metni)
                ekran.ham_yaz("  " + ekran.renkli(satir, renk))
            yarim = [p for p in paketler if p[2].baslanmis and not p[2].tamamlandi]
            yeni = [p for p in paketler if not p[2].baslanmis]
            aday = (min(yarim, key=lambda p: p[2].ustalik) if yarim else
                    (yeni[0] if yeni else min(paketler, key=lambda p: p[2].ustalik)))
            secim = ekran.menu("", [
                ("Kaldığın yerden devam et", konu_etiketi(self.durum, aday[0], aday[1])),
                ("Listeden seç", ""), ("Geri dön", "")])
            if secim == 0:
                self._konu_akisi(aday[0], aday[1])
            elif secim == 1:
                alt = ekran.menu("İş:", [konu_etiketi(self.durum, p[0], p[1]) for p in paketler]
                                 + ["Vazgeç"])
                if alt < len(paketler):
                    self._konu_akisi(paketler[alt][0], paketler[alt][1])
            else:
                return

    def _konu_haritasi(self, ders: str) -> None:
        """Tek bir alanın konu haritası. Meslek dalları buradan çalışılır."""
        while True:
            # Yalnızca bu zorlukta gerçekten üretilebilen konular listelenir;
            # açılamayacak bir işi listede göstermek öğrenciyi boş kapıya
            # yollamaktır.
            konu_listesi = [k for _a, k in self._acik_konular(
                alan_yolu(ders), yalniz_alan=ders)]
            if not konu_listesi:
                ekran.hata("Bu masada senin zorluğunda şimdilik iş yok. "
                           "Ayarlardan zorluğu değiştirmeyi deneyebilirsin.")
                ekran.bekle()
                return

            ders_durumu = self.durum.ders(ders)
            self._ust_pano()
            ekran.yaz("KONU HARİTASI - {}".format(DERS_ADLARI[ders]),
                      "kalin", DERS_RENGI.get(ders, "acik_cam"))
            ortaklik = ittifak.ortaklik_satiri(ders, ders_durumu.kademe)
            if ortaklik:
                ekran.yaz(ortaklik, "acik_mor")
            ekran.yaz()
            ekran.yaz("{:<12}{:<26}{}".format("DURUM", "İŞ", "ELİN ALIŞTI MI"),
                      "gri")

            for konu_kodu in konu_listesi:
                konu_durumu = ders_durumu.konu(konu_kodu)
                kutu, etiket, renk = self._konu_durum_etiketi(konu_durumu)
                if konu_durumu.serbest_toplam:
                    ilerleme_metni = "{} %{}".format(
                        ekran.cubuk(konu_durumu.ustalik, 1.0, 10),
                        int(round(konu_durumu.ustalik * 100)))
                else:
                    ilerleme_metni = "-"
                satir = "{} {:<9}{:<26}{}".format(
                    kutu, etiket, konu_etiketi(self.durum, ders, konu_kodu)[:25], ilerleme_metni)
                ekran.ham_yaz("  " + ekran.renkli(satir, renk))

            ekran.yaz()
            ekran.yaz("[ ] hiç başlanmadı   [1] anlatım sırası   "
                      "[2] birlikte   [3] kendi başına   [{}] oturdu".format(S["onay"]),
                      "gri")

            onerilen = self._onerilen_konu(ders, konu_listesi)
            meslek_dali = secmeli_yol_mu(alan_yolu(ders))
            secenekler = [
                ("Kaldığın yerden devam et", konu_etiketi(self.durum, ders, onerilen)),
                ("Listeden seç", ""),
            ]
            if meslek_dali:
                secenekler.append(("Başka bölüme geç", ""))
            secenekler.append(("Geri dön", ""))

            secim = ekran.menu("", secenekler)
            if secim == 0:
                self._konu_akisi(ders, onerilen)
            elif secim == 1:
                alt = ekran.menu("İş:", [konu_etiketi(self.durum, ders, k) for k in konu_listesi]
                                 + ["Vazgeç"])
                if alt < len(konu_listesi):
                    self._konu_akisi(ders, konu_listesi[alt])
            elif meslek_dali and secim == 2:
                # Dalı unutup yeniden sorduruyoruz: bölüm değiştiren ya da
                # başka bölümün işine bakmak isteyen öğrenci için.
                self.durum.dal = ""
                return
            else:
                return

    def _konu_akisi(self, ders: str, konu_kodu: str) -> None:
        """
        Bir konuyu, bulunduğu aşamadan başlayarak çalıştırır.

        Aşama ilerlerse aynı oturumda devam teklif edilir: öğrenci anlatımı
        izledikten hemen sonra birlikte çözmeye, onu da geçince tek başına
        denemeye geçebilir. Akış tek oturumda tamamlanabilir ama zorunlu değil.
        """
        ders_durumu = self.durum.ders(ders)

        # Meslek dallarında, bu masadaki işin hangi başka bölümle ortak
        # olduğunu bir kez söylüyoruz. İttifak özelliği açıldığında bu satır
        # eşleşmenin giriş kapısı olacak. Bkz. TASARIM_NOTLARI.md §4
        ortaklik = ittifak.ortaklik_satiri(ders, ders_durumu.kademe)
        if ortaklik:
            ekran.yaz()
            ekran.yaz(ortaklik, "acik_mor", girinti="  ")

        while True:
            konu_durumu = ders_durumu.konu(konu_kodu)
            asama = konu_durumu.asama

            bulmaca = uret(
                ders=ders,
                kademe=ders_durumu.kademe,
                rastgele=self.durum.rastgele("konu-{}-{}".format(konu_kodu, asama)),
                konu=konu_kodu,
            )
            if bulmaca is None:
                ekran.hata("Bu konu için görev üretilemedi.")
                ekran.bekle()
                return

            oturum = Oturum(
                bulmaca,
                oyuncu_adi=self.durum.ad,
                ipucu_acik=bool(self.durum.ayarlar.get("ipucu_acik", True)),
                durum=self.durum,
                asama=asama,
            )
            sonuc = oturum.oyna()

            if asama == SERBEST:
                sonucu_ozetle(bulmaca, sonuc)
                self.durum.kaynak_ekle({a: -m for a, m in GOREV_BEDELI.items()})
                if not sonuc.birakildi:
                    self.durum.kaynak_ekle(self._odulu_hesapla(bulmaca, sonuc))

            onceki_asama = asama
            bildirimler = ilerleme.sonucu_isle(
                self.durum, sonuc, uretici_adi=getattr(bulmaca, "uretici_adi", ""))
            if bildirimler:
                ekran.yaz()
                for satir in bildirimler:
                    ekran.yaz(S["ok"] + " " + satir, "acik_mor", "kalin")

            from oyun.icerik import hikaye
            hikaye.bolumu_kontrol_et(self.durum)
            self.durum.kaydet()

            if sonuc.birakildi:
                ekran.bekle()
                return

            yeni_asama = ders_durumu.konu(konu_kodu).asama
            if yeni_asama != onceki_asama:
                soru = {
                    BIRLIKTE: "Şimdi aynısını birlikte çözelim mi?",
                    SERBEST: "Tek başına denemek ister misin?",
                }.get(yeni_asama, "Devam edelim mi?")
                if not ekran.onayla(soru, True):
                    return
                continue

            # Aşama değişmedi: aynı düzeyde bir tur daha ister mi?
            ekran.yaz()
            if not ekran.onayla("Bu işten bir tane daha ister misin?", False):
                return

    # ------------------------------------------------------------ görev panosu
    def _pano_baglami(self, zaman=None):
        try:
            program = ders_programi.ogrenci_programi(self.durum)
            satir, aciklama = ders_programi.ders_odagi(program, zaman)
            return program, satir, aciklama
        except (OSError, ValueError) as sorun:
            return None, None, "Ders programı okunamadı: {}".format(sorun)

    @staticmethod
    def _baglam_anahtari(baglam):
        return json.dumps(baglam, sort_keys=True, ensure_ascii=False)

    def _teklif_uret(self, adet: int = 3, zaman=None) -> List[Bulmaca]:
        """
        Panoya konacak görevleri seçer.
        Okul programı varsa o ders/konu; yoksa uyarlanır serbest keşif.
        """
        rastgele = self.durum.rastgele("pano-{}".format(self.pano_sayaci))
        baglam = self._pano_baglami(zaman)
        self._teklif_baglami = self._baglam_anahtari(baglam)
        program, satir, aciklama = baglam
        self.odak_uyarisi = ""
        if program is None:
            self.odak_uyarisi = aciklama
            return []
        if satir is not None:
            teklifler, self.odak_uyarisi = ders_programi.odakli_teklifler(
                self.durum, program, satir, rastgele, adet)
            return teklifler
        dersler = self.durum.aktif_dersler()
        if not dersler or adet <= 0:
            return []
        secilenler: List[Bulmaca] = []
        kullanilan_ders: List[str] = []
        denemeler = 0
        while len(secilenler) < adet and denemeler < 40:
            denemeler += 1
            havuz = [d for d in dersler if d not in kullanilan_ders] or dersler
            ders = rastgele.choice(havuz)
            oneriler, _ = ders_programi.odakli_teklifler(
                self.durum, program,
                {"ders": ders, "ad": DERS_ADLARI[ders], "konular": []}, rastgele, 1)
            if not oneriler:
                kullanilan_ders.append(ders)
                continue
            bulmaca = oneriler[0]
            secilenler.append(bulmaca)
            kullanilan_ders.append(ders)
        return secilenler

    def _gorev_panosu(self) -> None:
        while True:
            baglam = self._pano_baglami()
            if self._teklif_baglami != self._baglam_anahtari(baglam):
                self.teklifler = []
            if not self.teklifler:
                self.teklifler = self._teklif_uret()
            self._ust_pano()
            ekran.yaz("KOMUTA MASASI", "kalin", "acik_cam")
            ekran.yaz("Mühürlü görev dosyaları önünde duruyor. Birini seçtiğinde "
                      "dosyanın ayrıntıları açılacak.", "gri")
            program, satir, aciklama = baglam
            if satir:
                ekran.yaz("{}: {} ({}–{})".format(
                    aciklama, satir["ad"], satir["baslangic"], satir["bitis"]), "acik_cam")
                ekran.yaz("Seçili konulardan görevler" + (
                    "; aynı dersten kısa pekiştirme." if not program["tam_odak"]
                    else "; tam konu odağı."), "gri")
            else:
                ekran.yaz(aciklama, "gri")
            if self.odak_uyarisi:
                ekran.yaz(self.odak_uyarisi, "acik_sari")

            if not self.teklifler:
                ekran.bilgi("Bu odak için görev yok. Programı gözden geçirebilir "
                            "veya Usta Çadırı'ndan başka bir çalışmayı kendin seçebilirsin.")
                ekran.bekle()
                return

            secenekler = []
            for bulmaca in self.teklifler:
                renk = DERS_RENGI.get(bulmaca.ders, "beyaz")
                baslik = "{}  {}".format(
                    ekran.renkli(bulmaca.baslik, renk, "kalin"),
                    ekran.renkli("[Zorluk {} - {}]".format(
                        kademe_zorlugu(bulmaca.kademe),
                        ZORLUK_ADLARI[kademe_zorlugu(bulmaca.kademe)]), "gri"))
                odul_metni = self._odul_metni(bulmaca.odul)
                secenekler.append((baslik, "Dikkat {}  {}  Ödül: {}".format(
                    bulmaca.dikkat, S["dikey"], odul_metni)))
            secenekler.append(("Haberciyi geri gönder", "başka görev dosyaları getir"))
            secenekler.append(("Masadan ayrıl", ""))

            secim = ekran.menu("", secenekler)
            if secim == len(self.teklifler):
                self.teklifler = []
                self.pano_sayaci += 1
                continue
            if secim == len(self.teklifler) + 1:
                return

            if self._teklif_baglami != self._baglam_anahtari(self._pano_baglami()):
                self.teklifler = []
                ekran.bilgi("Ders odağı değişti; güncel görev dosyaları getiriliyor.")
                continue

            bulmaca = self.teklifler.pop(secim)
            if not self._gorev_dosyasi(bulmaca):
                continue
            if self._teklif_baglami != self._baglam_anahtari(self._pano_baglami()):
                self.teklifler = []
                ekran.bilgi("Ders odağı değişti; güncel görev dosyaları getiriliyor.")
                continue
            self._gorevi_oyna(bulmaca)
            self.teklifler = []
            return

    def _odul_metni(self, odul) -> str:
        if not odul:
            return "İtibar"
        return ", ".join("{} +{}".format(KAYNAK_ADLARI.get(k, k), v)
                         for k, v in odul.items())

    def _gorev_dosyasi(self, bulmaca: Bulmaca) -> bool:
        """Göreve girmeden önce kısa risk/ödül dosyası gösterir."""
        ekran.temizle()
        ekran.baslik("GÖREV DOSYASI: " + ekran.tr_buyuk(bulmaca.baslik),
                      "kalin", "acik_sari")
        zorluk = kademe_zorlugu(bulmaca.kademe)
        ekran.yaz()
        ekran.kutu(
            "Zorluk: {} - {}\n"
            "Elindeki dikkat: {}/{}\n"
            "Operasyon gideri: {} Enerji\n"
            "Tahmini ödül: {}".format(
                zorluk, ZORLUK_ADLARI[zorluk],
                # `bulmaca.dikkat` ESKI: gorev basina dikkatti ve artik
                # kullanilmiyor -- dikkat kalici bir havuz oldu. Burada onu
                # yazmak yalan soyluyordu: dosyada "Dikkat butcesi: 5",
                # oyunda "Dikkat: 100/100" gorunuyordu (8 Eylul testi).
                self.durum.dikkati_hazirla(), self.durum.dikkat_tavani(),
                GOREV_BEDELI.get("enerji", 0),
                self._odul_metni(bulmaca.odul)),
            "KOMUTANIN NOTU", "beyaz")
        ekran.yaz("Dosyanın olay ayrıntıları sahaya çıktığında açılacak.", "gri")
        return ekran.onayla("Görevi kabul ediyor musun?", True)

    def _serbest_calisma(self) -> None:
        self._ust_pano()
        ekran.yaz("SERBEST ÇALIŞMA", "kalin", "acik_cam")
        ekran.yaz("İstediğin dersten, istediğin kademede görev çek. "
                  "Karneye işlenir ama zorluk otomatik değişmez.", "gri")

        dersler = self.durum.aktif_dersler()
        ders_secenekleri = []
        for ders in dersler:
            adet = len(uygun_kayitlar(ders=ders))
            ders_secenekleri.append((DERS_ADLARI[ders], "{} görev tipi".format(adet)))
        ders_secenekleri.append(("Geri dön", ""))
        secim = ekran.menu("Ders:", ders_secenekleri)
        if secim >= len(dersler):
            return
        ders = dersler[secim]

        varsayilan = self.durum.ders(ders).kademe
        ham = ekran.sor("Kademe (1-13, Enter = {}):".format(varsayilan), str(varsayilan))
        try:
            kademe = max(1, min(13, int(ham)))
        except ValueError:
            kademe = varsayilan

        bulmaca = uret(ders=ders, kademe=kademe, rastgele=self.durum.rastgele("serbest"))
        if bulmaca is None:
            ekran.hata("Bu ders için henüz içerik yok.")
            ekran.bekle()
            return
        self._gorevi_oyna(bulmaca, serbest=True)

    # ---------------------------------------------------------------- oynatma
    def _gorevi_oyna(self, bulmaca: Bulmaca, serbest: bool = False) -> None:
        onceki_rutbe = self.durum.rutbe
        # Dikkat tavani ustalikla degisiyor (durum.dikkat_tavani).
        # Ogrenciye SOYLENMEZSE sayi kendiliginden oynuyor gibi durur
        # ve sistem keyfi gorunur. Gorev oncesi/sonrasi karsilastiriyoruz.
        onceki_tavan = self.durum.dikkat_tavani()
        oturum = Oturum(
            bulmaca,
            oyuncu_adi=self.durum.ad,
            ipucu_acik=bool(self.durum.ayarlar.get("ipucu_acik", True)),
                durum=self.durum,
        )
        sonuc = oturum.oyna()
        sonucu_ozetle(bulmaca, sonuc)

        self.durum.kaynak_ekle({a: -m for a, m in GOREV_BEDELI.items()})

        if sonuc.birakildi:
            self.durum.gunluk_ekle("{} görevinden çekildi.".format(bulmaca.baslik))
        else:
            # Dikkat dolumu gorevin ZORLUGUNA bagli: zor gorev daha cok geri
            # verir. Gercek zamana degil goreve bagli -- gercek zamana
            # baglanirsa beklemek odullendirilir ve 40 dakikalik ders
            # saatinde ise yaramaz. Bkz. durum.DIKKAT_DOLUM.
            # Zorlandiysa merdiven teklif et. TEKLIF, dayatma degil:
            # ogrenci "hayir" diyebilmeli, yoksa yardim bir cezaya donusur.
            self._merdiven_teklif_et(bulmaca, sonuc)

            kazanilan = self.durum.dikkat_ekle(kademe_zorlugu(bulmaca.kademe))
            yeni_tavan = self.durum.dikkat_tavani()
            if kazanilan:
                ekran.yaz()
                ekran.yaz("Dikkatin {} arttı ({}/{}).".format(
                    kazanilan, self.durum.dikkat, yeni_tavan), "acik_yesil")
            if yeni_tavan > onceki_tavan:
                # Yeni konu acildi: oturmus oran dustu, tavan yukseldi.
                ekran.yaz()
                ekran.yaz("Yeni konular açıldı; dikkat sınırın {} oldu ({} idi). "
                          "Tanımadığın konularda daha çok bakmaya hakkın var.".format(
                              yeni_tavan, onceki_tavan), "acik_cam")
            elif yeni_tavan < onceki_tavan:
                # Konu oturdu: artik daha az desteğe ihtiyaci var (§0'in tersi).
                ekran.yaz()
                ekran.yaz("Bir konu daha oturdu; dikkat sınırın {} oldu ({} idi). "
                          "Artık daha az bakman yetiyor.".format(
                              yeni_tavan, onceki_tavan), "acik_yesil")
            uygulanan = self.durum.kaynak_ekle(self._odulu_hesapla(bulmaca, sonuc))
            self.durum.gunluk_ekle("{} tamamlandı ({}/{} puan).".format(
                bulmaca.baslik, sonuc.puan, sonuc.azami_puan))
            if uygulanan:
                ekran.yaz()
                ekran.yaz("Üsse kazandırdıkların:", "kalin")
                for anahtar, miktar in uygulanan.items():
                    if miktar:
                        ekran.madde("{} {}{}".format(
                            KAYNAK_ADLARI.get(anahtar, anahtar),
                            "+" if miktar > 0 else "", miktar), "acik_sari")

        onceki_kademe = {d: self.durum.ders(d).kademe for d in DERSLER}
        bildirimler = ilerleme.sonucu_isle(
            self.durum, sonuc, uretici_adi=getattr(bulmaca, "uretici_adi", ""))

        if serbest:
            # Serbest çalışmada kademe otomatik değişmesin: geri al.
            for ders, kademe in onceki_kademe.items():
                self.durum.ders(ders).kademe = kademe
            bildirimler = [b for b in bildirimler if "kademe" not in b.lower()]

        if bildirimler:
            ekran.yaz()
            for satir in bildirimler:
                ekran.yaz(S["ok"] + " " + satir, "acik_mor", "kalin")

        if self.durum.rutbe != onceki_rutbe:
            ekran.yaz()
            ekran.kutu(
                "Komutan görev raporunu mühürledi. Artık üste daha fazla "
                "sorumluluk alabilirsin.\n\nYeni rütben: {}".format(self.durum.rutbe),
                "RÜTBE TERFİSİ", "acik_sari")

        from oyun.icerik import hikaye
        hikaye.bolumu_kontrol_et(self.durum)

        self.durum.kaydet()
        ekran.bekle()

    def _geri_bildirim(self) -> None:
        """Oyuncunun notunu ve ilerleme kayitlarini tek zip'e koyar.

        Deneme surumunu birine verip "nasil gitti?" diye sordugunda gelen
        cevap genelde "guzeldi" olur; ise yarayan sey NEREDE takildigini
        gosteren kayit dosyasidir. Ama kimseden "kayitlar klasorunu bul ve
        zip'le" denmesi beklenemez.

        Ne koyulduğu paket OLUSTURULMADAN once ekranda listeleniyor.
        Birinden dosya istiyorsan ne istedigini gostereceksin.
        """
        from araclar import geri_bildirim as gb

        ekran.temizle()
        ekran.baslik("GERİ BİLDİRİM", "kalin", "acik_cam")
        ozet = gb.icerik_ozeti(self.durum.kimlik())
        ekran.yaz()
        ekran.kutu(
            "Ne düşündüğünü yaz; oyun bunu ilerleme kayıtlarınla birlikte "
            "tek bir dosyaya koyar. Dosyayı sen gönderirsin — oyun hiçbir "
            "şeyi kendiliğinden yollamaz.",
            "NASIL ÇALIŞIR", "beyaz")
        ekran.yaz()
        ekran.yaz("PAKETE GİRECEKLER", "kalin")
        ekran.madde("yazdığın not", "acik_cam")
        for satir in ozet["kayitlar"]:
            ekran.madde("ilerleme kaydı: " + satir, "acik_cam")
        ekran.madde("sürüm bilgisi: " + ozet["ortam"], "acik_cam")
        ekran.yaz()
        ekran.yaz("Başka hiçbir şey: bilgisayarında dosya aranmaz, hiçbir "
                  "şey ağa gönderilmez.", "gri")
        ekran.ayrac()

        ekran.yaz()
        ekran.yaz("Notunu yaz. Bitince BOŞ satırda Enter'a bas.", "acik_sari")
        ekran.yaz("En çok yardımı dokunan şey: nerede takıldığın ve hangi "
                  "soruyu 'ders sorusu' diye hissettiğin.", "gri")
        satirlar = []
        while True:
            satir = ekran.sor("", "")
            if not satir.strip():
                break
            satirlar.append(satir)
        metin = chr(10).join(satirlar)
        if not metin.strip():
            ekran.bilgi("Bir şey yazmadın; paket oluşturulmadı.")
            ekran.bekle()
            return

        yol, mesaj = gb.paket_olustur(metin, self.durum.ad,
                                      yalnizca_kimlik=self.durum.kimlik())
        ekran.yaz()
        if yol is None:
            ekran.hata(mesaj)
        else:
            ekran.basari(mesaj)
            ekran.yaz()
            ekran.kutu(yol, "BU DOSYAYI GÖNDER", "acik_yesil")
        ekran.bekle()

    @staticmethod
    def _odulu_hesapla(bulmaca, sonuc) -> dict:
        """Gorev odulu, yildiz carpaniyla ama BEDEL TABANIYLA.

        §0 IHLALI DUZELTMESI (5 Eylul 2026). `YILDIZ_CARPANI` odulu 0,2x ile
        1,4x arasinda olcekliyor. Harcanacak yer yokken bu zararsizdi; sefer
        bedeli eklenince gercek bir kapiya donustu. Olculdu: gorev basina
        ortalama enerji odulu ~1,3, bedel 1. Yani

            0 yildiz -> net -0,74      1 yildiz -> net -0,22
            2 yildiz -> net +0,30      3 yildiz -> net +0,82

        Zorlanan ogrencinin enerjisi her gorevde AZALIYORDU; yani oyunun en
        ozgun icerigi (zaman seferi) ona kalici olarak kapaliydi. Bu, §0'in
        "zorlanmanin bedeli ceza degil, destegin artmasidir" ilkesinin tam
        tersi -- zorlanan ogrenci cezalandiriliyordu.

        Kural: TAMAMLANAN BIR GOREV EN AZINDAN KENDI BEDELINI ODER. Yildiz
        hala fark yaratiyor (fazlasi icin), ama kimse geriye gitmiyor.
        """
        carpan = YILDIZ_CARPANI.get(sonuc.yildiz, 1.0)
        odul = {a: int(round(m * carpan)) for a, m in (bulmaca.odul or {}).items()}
        if not odul:
            odul = {"itibar": int(round(3 * carpan))}
        for anahtar, bedel in GOREV_BEDELI.items():
            odul[anahtar] = max(odul.get(anahtar, 0), bedel)
        return odul

    def _merdiven_teklif_et(self, bulmaca, sonuc) -> None:
        """Zorlanan ogrenciye ayni konudan basamakli alistirma onerir.

        Bugune kadar takilan ogrenciye "bu konuya bir daha bak" deniyordu
        ama NEREYE bakacagi soylenmiyordu. Merdiven o boslugu dolduruyor.
        """
        gb = degerlendirme.gorev_geri_bildirimi(bulmaca, sonuc)
        if not gb.get("zorlandi"):
            return
        # Yalnizca gercekten takildiysa: tek ipucu almak merdiven gerektirmez.
        if gb.get("zorlanan_adim", 0) < 1:
            return
        konu = getattr(bulmaca, "konu", "")
        if not konu:
            return
        ekran.yaz()
        if not ekran.onayla(
                "Bu konuyu basitten başlayarak adım adım çalışalım mı?", True):
            return
        from . import merdiven
        merdiven.merdiveni_oyna(self.durum, bulmaca.ders, konu, bulmaca.kademe)

    # ------------------------------------------------------------ zaman seferi
    def _zaman_seferi(self) -> None:
        """
        Tek kurgunun içinde birden çok dersi dolaştıran görev zinciri.

        Derslerin birbirinden kopuk olmadığını gösteren yer burasıdır: aynı
        olayın tarihi, coğrafyası, hesabı ve anlatımı arka arkaya gelir.
        """
        kayitlar = sefer_kayitlari()
        if not kayitlar:
            ekran.hata("Henüz kayıtlı zaman seferi yok.")
            ekran.bekle()
            return

        gorulen = list(self.durum.ayarlar.get("gorulen_seferler") or [])
        kademe = int(round(self.durum.ortalama_kademe))
        sefer_nesnesi = sefer_uret(
            kademe=kademe,
            rastgele=self.durum.rastgele("sefer-{}".format(len(gorulen))),
            haric=gorulen,
        )
        if sefer_nesnesi is None:
            ekran.hata("Bu zorluk için zaman seferi üretilemedi.")
            ekran.bekle()
            return

        ekran.temizle()
        ekran.baslik(ekran.tr_buyuk(sefer_nesnesi.baslik), "kalin", "acik_mor")
        ekran.yaz()
        ekran.yaz(sefer_nesnesi.donem, "gri")
        ekran.yaz("Bu seferde çağı, yeri, hesabı ve raporu birbirine bağlayacaksın.",
                  "acik_cam")
        ekran.yaz()
        ekran.kutu(sefer_nesnesi.giris, "KRONOGRAF", "beyaz")
        ekran.yaz()
        ekran.yaz("Sefer bedeli: " + self._bedel_metni(SEFER_BEDELI), "acik_sari")
        if not ekran.onayla("Sefere çıkalım mı?", True):
            return
        # Bedel sefer BASLAMADAN once odenir. Yarida birakilirsa geri
        # verilmiyor: sefer icerigi zaten gorulmus oluyor.
        if not self._bedeli_ode(SEFER_BEDELI, "Zaman seferi"):
            return

        tamamlandi = True
        sefer_sonuclari = []
        for sira, bolum in enumerate(sefer_nesnesi.bolumler):
            if sira > 0 and sira - 1 < len(sefer_nesnesi.baglantilar):
                ekran.temizle()
                ekran.yaz()
                ekran.kutu(sefer_nesnesi.baglantilar[sira - 1], "SEFER", "acik_mor")
                ekran.bekle()

            ekran.yaz()
            bolum_adlari = ["ÇAĞI ÇÖZ", "YERİ BUL", "HESABI KUR", "RAPORLA"]
            ekran.yaz("SEFER BÖLÜMÜ {}/{}  -  {}".format(
                sira + 1, len(sefer_nesnesi.bolumler),
                bolum_adlari[sira] if sira < len(bolum_adlari) else "BAĞLANTIYI KUR"),
                "kalin", "acik_mor")

            oturum = Oturum(
                bolum,
                oyuncu_adi=self.durum.ad,
                ipucu_acik=bool(self.durum.ayarlar.get("ipucu_acik", True)),
                durum=self.durum,
                asama=SERBEST,
            )
            sonuc = oturum.oyna()
            sefer_sonuclari.append(sonuc)
            sonucu_ozetle(bolum, sonuc)

            bildirimler = ilerleme.sonucu_isle(self.durum, sonuc)
            if bildirimler:
                ekran.yaz()
                for satir in bildirimler:
                    ekran.yaz(S["ok"] + " " + satir, "acik_mor", "kalin")

            if sonuc.birakildi:
                tamamlandi = False
                ekran.yaz()
                ekran.hata("Sefer yarıda kaldı; Kronograf raporsuz açılmıyor.")
                ekran.bekle()
                break

            self.durum.kaydet()
            ekran.bekle()

        if tamamlandi:
            ekran.temizle()
            ekran.baslik("SEFER TAMAMLANDI", "kalin", "acik_yesil")
            ekran.yaz()
            ekran.kutu(sefer_nesnesi.kapanis, "DÖNÜŞ", "beyaz")

            # Kapanis metni icerikten geliyor ve her zaman ayni: kutlama.
            # Ogrenci birkac hata yapip "mukemmel" duyuyordu. Yanlisi dogru
            # gostermek ogretmemektir. Asagisi ceza degil, sadece gercek:
            # puan yok, siralama yok, basarisizlik damgasi yok.
            olcum = degerlendirme.sefer_degerlendirmesi(sefer_sonuclari)
            ekran.yaz()
            ekran.yaz(olcum["baslik"], "kalin",
                      "acik_yesil" if olcum["kusursuz"] else "acik_sari")
            if olcum["toplam_adim"]:
                ekran.yaz("{} adımın {}'ini ilk denemede, yardımsız geçtin.".format(
                    olcum["toplam_adim"], olcum["ilk_denemede"]), "gri")
            if olcum["zorlanilan_konular"]:
                ekran.yaz()
                ekran.yaz("Takıldığın konular:", "kalin")
                for konu in olcum["zorlanilan_konular"]:
                    ekran.madde(konu.replace("_", " "), "acik_sari")
            if olcum["tekrarlayan_hatalar"]:
                ekran.yaz()
                ekran.yaz("Aynı hatayı birden çok kez yaptın:", "kalin")
                for hata in olcum["tekrarlayan_hatalar"]:
                    ekran.madde(hata, "acik_sari")
            if not olcum["kusursuz"]:
                ekran.yaz()
                ekran.yaz(olcum["oneri"], "acik_cam")

            uygulanan = self.durum.kaynak_ekle(sefer_nesnesi.odul)
            if uygulanan:
                ekran.yaz()
                ekran.yaz("Seferden kazandıkların:", "kalin")
                for anahtar, miktar in uygulanan.items():
                    if miktar:
                        ekran.madde("{} +{}".format(
                            KAYNAK_ADLARI.get(anahtar, anahtar), miktar), "acik_sari")
            gorulen.append(sefer_nesnesi.kod)
            self.durum.ayarlar["gorulen_seferler"] = gorulen[-10:]
            self.durum.gunluk_ekle("Zaman seferi tamamlandı: " + sefer_nesnesi.baslik)
            self.durum.kaydet()
            ekran.bekle()

        from oyun.icerik import hikaye
        hikaye.bolumu_kontrol_et(self.durum)

    # ----------------------------------------------------------- konu taraması
    def _konu_taramasi(self) -> None:
        """
        Nerede olduğunu bulup rotayı çizer. Sınav değildir: süre, puan ve net
        yoktur; sonucu tek işe yarar - her konuyu doğru öğretim aşamasına
        yerleştirmeye.
        """
        from . import tarama as tarama_modulu

        secenekler = []
        yol_kodlari = list(OGRENME_YOLLARI)
        for yol in yol_kodlari:
            adet = sum(len(konular(alan)) for alan in yol_alanlari(yol))
            secenekler.append((OGRENME_YOLLARI[yol]["ad"], "{} konu".format(adet)))
        secenekler.append(("Geri dön", ""))

        self._ust_pano()
        ekran.yaz("İZ SÜRME MASASI", "kalin", "acik_cam")
        ekran.yaz("Neyi rahat yaptığını, nerede takıldığını görelim. "
                  "Puan yok, süre yok.", "gri")
        secim = ekran.menu("Hangi masaya oturalım?", secenekler)
        if secim >= len(yol_kodlari):
            return
        yol = yol_kodlari[secim]
        # Tarama kısa kalmalı: bu yoldaki en az çalışılmış iç alanı seçeriz;
        # oyuncu ders adı görmez, yalnızca gerçek konu başlıklarını görür.
        alanlar = yol_alanlari(yol)
        ders = min(alanlar, key=lambda a: sum(
            1 for k in konular(a) if self.durum.ders(a).konu(k).baslanmis))

        sonuc = tarama_modulu.tarama_yap(self.durum, ders)
        if sonuc is None:
            return
        tarama_modulu.sonucu_uygula(self.durum, sonuc)
        secilen_konu = tarama_modulu.sonucu_goster(sonuc)
        if secilen_konu:
            self._konu_akisi(ders, secilen_konu)

    def _zorluk_sec(self) -> None:
        secenekler = [("{} - {}".format(i, ZORLUK_ADLARI[i]),
                       ZORLUK_ACIKLAMALARI[i]) for i in range(1, 6)]
        secenekler.append(("Vazgeç", ""))
        secim = ekran.menu("ZORLUK", secenekler,
                           ipucu="Destek aşamaları her zorlukta açıktır.")
        if secim >= 5:
            return
        yeni = secim + 1
        if yeni == self.durum.zorluk:
            return
        self.durum.zorluk_ayarla(yeni)
        self.teklifler = []
        self.durum.gunluk_ekle("Zorluk değişti: {} - {}".format(
            yeni, ZORLUK_ADLARI[yeni]))
        self.durum.kaydet()
        ekran.yaz()
        ekran.basari("Zorluk {} - {}".format(yeni, ZORLUK_ADLARI[yeni]))
        ekran.bekle()

    # ------------------------------------------------------------------ karne
    def _karne(self) -> None:
        self._ust_pano()
        ekran.yaz("HARİTA ODASI", "kalin", "acik_cam")
        ekran.yaz()
        basliklar = "{:<24}{:<21}{}".format("MASA", "ELİN ALIŞTI MI", "İŞ")
        ekran.yaz(basliklar, "gri")
        for yol, bilgi in OGRENME_YOLLARI.items():
            konular_yol = [(a, k) for a in yol_alanlari(yol) for k in konular(a)]
            baslanan = [(a, k) for a, k in konular_yol
                        if self.durum.ders(a).konu(k).baslanmis]
            oturan = sum(1 for a, k in konular_yol
                         if self.durum.ders(a).konu(k).tamamlandi)
            oran = oturan / len(konular_yol) if konular_yol else 0
            satir = "{:<24}{} {:>3}%  {}/{}".format(
                bilgi["ad"], ekran.cubuk(oran, 1.0, 12),
                int(round(oran * 100)), oturan, len(konular_yol))
            ekran.yaz(satir, "acik_cam", sar=False, girinti="  ")

        ekran.yaz()
        model_toplam = sum(self.durum.ders(d).model_toplam for d in self.durum.aktif_dersler())
        model_dogru = sum(self.durum.ders(d).model_dogru for d in self.durum.aktif_dersler())
        if model_toplam:
            ekran.yaz("Bilinmeyeni ilk denemede doğru kurma: {}/{} görev  (%{})".format(
                model_dogru, model_toplam, int(round(100 * model_dogru / model_toplam))),
                "acik_mor")

        ekran.yaz()
        ekran.kutu(ilerleme.genel_degerlendirme(self.durum), "DEĞERLENDİRME", "beyaz")

        zayif = self._zayif_konular()
        if zayif:
            ekran.yaz()
            ekran.yaz("Tekrar etmen iyi olacak konular:", "kalin")
            for _alan, konu, puan in zayif:
                ekran.madde("{} (%{})".format(konu.replace("_", " "),
                                                   int(round(puan * 100))), "acik_sari")
        ekran.bekle()

    def _zayif_konular(self, esik: float = 0.55) -> List[Tuple[str, str, float]]:
        sonuc = []
        for ders in self.durum.aktif_dersler():
            for konu, puan in self.durum.ders(ders).konu_puani.items():
                if puan < esik:
                    sonuc.append((ders, konu, puan))
        sonuc.sort(key=lambda x: x[2])
        return sonuc[:5]

    # ----------------------------------------------------------------- günlük
    def _gunluk(self) -> None:
        self._ust_pano()
        ekran.yaz("KÂŞİF GÜNLÜĞÜ", "kalin", "acik_cam")
        ekran.yaz()
        ekran.kutu("Mevcut rütbe: {}\nTamamlanan saha görevi: {}".format(
            self.durum.rutbe, self.durum.oynanan_gorev), "KİMLİK KARTI", "beyaz")
        sonraki = self.durum.sonraki_rutbe
        if sonraki:
            kalan = max(0, sonraki[0] - self.durum.oynanan_gorev)
            ekran.yaz("Sonraki rütbe: {}  {}  {} görev kaldı".format(
                sonraki[1], ekran.cubuk(self.durum.oynanan_gorev,
                                        sonraki[0], 14), kalan), "gri")
        else:
            ekran.basari("En yüksek rütbedesin: Meridyen Muhafızı")
        if self.durum.rozetler:
            ekran.yaz()
            ekran.yaz("ROZETLER", "kalin", "acik_sari")
            for rozet in self.durum.rozetler:
                ekran.madde(rozet, "acik_sari", isaret=S["yildiz"])
        ekran.yaz()
        ekran.yaz("SON KAYITLAR", "kalin")
        for satir in self.durum.gunluk[-12:]:
            ekran.yaz(satir, "gri", girinti="  ")
        ekran.bekle()

    # ---------------------------------------------------------------- ayarlar
    def _hikaye_tarzi_sec(self) -> None:
        kodlar = list(TARZLAR)
        secim = ekran.menu("BU SEFERİ NASIL YAŞAMAK İSTERSİN?", [
            (TARZLAR[k][0], TARZLAR[k][1]) for k in kodlar] + [("Geri dön", "")])
        if secim < len(kodlar):
            self.durum.ayarlar["hikaye_tarzi"] = kodlar[secim]
            self.durum.kaydet()

    def _ayarlar(self) -> None:
        while True:
            self._ust_pano()
            ayarlar = self.durum.ayarlar
            hiz = float(ayarlar.get("yazim_hizi", 0.0))
            hiz_metni = "kapalı (anında)" if hiz <= 0 else "{:.3f} sn/harf".format(hiz)
            secim = ekran.menu("TEÇHİZAT VE AYARLAR", [
                ("Zorluk {} - {}".format(self.durum.zorluk, self.durum.zorluk_adi),
                 ZORLUK_ACIKLAMALARI[self.durum.zorluk]),
                ("Yazım efekti: " + hiz_metni, "metnin harf harf yazılması"),
                ("Uyarlanır destek: " +
                 ("açık" if ayarlar.get("zorluk", "uyarlanir") == "uyarlanir" else "kapalı"),
                 "zorlanınca birlikte çözme aşamasına geri döner"),
                ("İpuçları: " + ("açık" if ayarlar.get("ipucu_acik", True) else "kapalı"), ""),
                ("Görev dökümü", "hangi masada hangi zorlukta kaç iş var"),
                ("Hikâye tercihi: " + TARZLAR[tarz(self.durum)][0], "istediğin zaman değiştirebilirsin"),
                ("Geri dön", ""),
            ])
            if secim == 0:
                self._zorluk_sec()
            elif secim == 1:
                yeni = 0.0 if hiz > 0 else 0.012
                ayarlar["yazim_hizi"] = yeni
                ekran.yazim_hizi_ayarla(yeni)
            elif secim == 2:
                ayarlar["zorluk"] = "sabit" if ayarlar.get("zorluk") == "uyarlanir" else "uyarlanir"
            elif secim == 3:
                ayarlar["ipucu_acik"] = not ayarlar.get("ipucu_acik", True)
            elif secim == 4:
                kapsama_yazdir()
                ekran.bekle()
            elif secim == 5:
                self._hikaye_tarzi_sec()
            else:
                self.durum.kaydet()
                return


# --------------------------------------------------------------------------
# Kapsama raporu (öğretmen / geliştirici için)
# --------------------------------------------------------------------------

def kapsama_yazdir() -> None:
    ekran.yaz()
    ekran.yaz("GÖREV DÖKÜMÜ  (masa x zorluk)", "kalin", "acik_cam")
    ekran.yaz()
    basliklar = "{:<24}".format("") + "".join("{:>10}".format(
        "{} {}".format(z, ZORLUK_ADLARI[z])) for z in range(1, 6))
    ekran.yaz(basliklar, "gri")
    kayitlar = tum_kayitlar()
    araliklar = {1: (1, 3), 2: (4, 6), 3: (7, 9), 4: (10, 12), 5: (13, 13)}
    for yol, bilgi in OGRENME_YOLLARI.items():
        alanlar = set(yol_alanlari(yol))
        satir = "{:<24}".format(bilgi["ad"])
        for z in range(1, 6):
            alt, ust = araliklar[z]
            adet = sum(1 for k in kayitlar if k.ders in alanlar and
                       k.kademeler[0] <= ust and k.kademeler[1] >= alt)
            satir += "{:>10}".format(adet if adet else ".")
        ekran.yaz(satir, "acik_cam", sar=False, girinti="  ")
    ekran.yaz()
    ekran.yaz("Toplam kayıtlı üretici: {}".format(len(uygun_kayitlar())), "gri")


# --------------------------------------------------------------------------
# Açılış ekranı ve kayıt seçimi
# --------------------------------------------------------------------------

def _acilis_ekrani() -> None:
    ekran.temizle()
    ekran.yaz()
    ekran.baslik(OYUN_ADI, "kalin", "acik_cam")
    ekran.yaz(ALT_BASLIK.center(ekran.genislik()), "gri")
    ekran.yaz()
    ekran.kutu(
        "Meridyen Üssü'ne kayıt subayı olarak atandın.\n"
        "Burada kimse sana \"şu denklemi çöz\" demez. Sana bozuk bir defter, "
        "eksik bir ölçüm ya da yanlış yazılmış bir mektup verilir; neyin "
        "bilinmediğini de, nasıl bulunacağını da sen çıkarırsın.",
        "GÖREV EMRİ", "beyaz")


def _yeni_oyun() -> Optional[Durum]:
    ekran.yaz()
    ad = ekran.sor("Adın nedir?", "Kâşif")

    # Sınıf ve numara ESKİDEN HERKESE soruluyordu; üstünde "yalnızca okulda
    # gerekli, Enter'a basıp geç" yazıyordu. Ama bir açıklama soruyu ekrandan
    # kaldırmaz: mezun, yetişkin ya da evde oynayan biri kendisiyle ilgisi
    # olmayan iki soruyu okumak ve geçmek zorunda kalıyordu. Artık tek soru
    # var ve okul dışındakiler o ikisini hiç görmüyor.
    ekran.yaz()
    nerede = ekran.menu("Nerede oynuyorsun?", [
        ("Kendi başıma", "evde, mezun ya da yetişkin — sınıf ve numara sorulmaz"),
        ("Okulda", "öğretmenim ilerlememi takip edecek"),
    ])
    okulda = (nerede == 1)

    numara = ""
    sinif = ""
    pin = ""
    kayit_adi = ""

    okul_adi = ""
    if okulda:
        # Sinif kodu varsa sinif ve okul KENDILIGINDEN doluyor; ogrenci
        # "sinifin ve suben" sorusunu hic gormuyor. Kod yoksa (ogretmeni
        # henuz sinif acmamis okul) eski yol duruyor -- kimse kilitlenmesin.
        from araclar import sinif as sinif_modulu
        ekran.yaz()
        ekran.yaz("Öğretmenin tahtaya bir sınıf kodu yazdıysa onu gir; "
                  "sınıfın kendiliğinden dolar.", "gri")
        kod = ekran.sor("Sınıf kodu (yoksa boş bırak):", "").strip()
        sinif_kaydi = sinif_modulu.sinif_bul(kod) if kod else None
        if kod and sinif_kaydi is None:
            ekran.hata("Bu kodla bir sınıf bulunamadı. Kodu kontrol et ya da "
                       "boş bırakıp devam et.")
            kod = ""
        if sinif_kaydi:
            sinif = sinif_kaydi["ad"]
            okul_adi = sinif_kaydi.get("okul", "")
            ekran.bilgi("Sınıfın: {}{}".format(
                sinif, "  ({})".format(okul_adi) if okul_adi else ""))

        ekran.yaz()
        numara = ekran.sor("Öğrenci numaran:", "")
        if not sinif_kaydi:
            sinif = ekran.sor("Sınıfın ve şuben:", "")
        if numara:
            # Okul numarasi PAROLA OLAMAZ: siniftaki herkes bilir. Bu yuzden
            # ogrenci kendi PIN'ini koyuyor. Sinif koduyla girildiyse ortak
            # bilgisayar ihtimali yuksek, o yuzden daha gorunur soruluyor.
            ekran.yaz()
            if sinif_kaydi:
                ekran.kutu(
                    "Sınıf arkadaşların da bu bilgisayarları kullanıyor. "
                    "Dört haneli bir PIN koyarsan seferini başkası açamaz."
                    "\n\n"
                    "PIN'i unutursan öğretmenin yardımcı olabilir.",
                    "PIN KOY", "acik_sari")
            else:
                ekran.yaz("Ortak bilgisayarda oynuyorsan dört haneli bir PIN "
                          "koy; seferini başkası açamaz. İstemiyorsan boş "
                          "bırak.", "gri")
            pin = ekran.sor("PIN (isteğe bağlı):", "")
            if sinif_kaydi and not pin:
                # Israr etmiyoruz ama bir kez daha soruyoruz: okulda PIN'siz
                # kayit, merakli bir sinif arkadasinin acabilecegi kayittir.
                ekran.yaz()
                if ekran.onayla("PIN koymadan devam edilsin mi?", True) is False:
                    pin = ekran.sor("PIN:", "")

    if numara:
        # Aynı kimliğe sahip bir kayıt varsa üstüne yazmayalım: okulda aynı
        # numaralı iki öğrencinin birbirinin ilerlemesini silmesi buradan
        # oluyordu. Numara oyuncunun kendi verdiği bilgi; düzeltmesi gerekir.
        deneme = Durum.yeni(ad, sinif=sinif, numara=numara)
        if os.path.exists(deneme.dosya_yolu()):
            ekran.yaz()
            ekran.hata("Bu kimlikle zaten bir sefer var: {}".format(deneme.kimlik()))
            ekran.yaz("Üstüne yazmıyorum. Kendi seferinse ana ekrandan \"Kayıtlı "
                      "sefere devam et\" ile gir; değilse numaranı kontrol et.", "gri")
            ekran.bekle()
            return None
    else:
        # Numarasız oyuncuda kimlik ADIN kendisiydi; aynı evde iki "Ali"
        # oynarsa ikincisi birincinin dosyasına yazıyordu. Sınıf/numara
        # sorusu kaldırılınca bu durum istisna olmaktan çıktı, o yüzden
        # kimlik burada boşta olan bir ada sabitleniyor: ali, ali-2, ali-3...
        # Sorulacak bir şey yok, kullanıcı bunu hiç görmüyor.
        kayit_adi = durum_modulu.benzersiz_kayit_adi(ad)

    ekran.yaz()
    secenekler = [("{} - {}".format(i, ZORLUK_ADLARI[i]),
                   ZORLUK_ACIKLAMALARI[i]) for i in range(1, 6)]
    secim = ekran.menu("Nereden başlayalım?", secenekler,
                       ipucu="Bu yalnızca başlangıçtır; zorlanırsan oyun desteği artırır.")
    zorluk = secim + 1
    durum = Durum.yeni(ad, baslangic_kademesi=ZORLUK_KADEME[zorluk],
                       zorluk=zorluk, sinif=sinif, numara=numara, pin=pin,
                       tip="okul" if okulda else "ev", kayit_adi=kayit_adi)
    if okulda and okul_adi:
        durum.okul = okul_adi
    if okulda and kod:
        durum.sinif_kodu = kod.upper()
    durum.kaydet()
    return durum


def _kayit_ac(ozet) -> Optional[Durum]:
    """Bir kaydı PIN denetiminden geçirerek açar."""
    durum = durum_modulu.yukle(ozet["yol"])
    if durum is None:
        ekran.hata("Kayıt dosyası okunamadı.")
        return None
    if durum.pin_ozeti:
        for kalan in (2, 1, 0):
            if durum.pin_dogru_mu(ekran.sor("{} için PIN:".format(durum.ad), "")):
                return durum
            if kalan:
                ekran.hata("PIN tutmadı. {} hakkın kaldı.".format(kalan))
        ekran.hata("PIN tutmadı.")
        ekran.bekle()
        return None
    return durum


def _listeden_sec(kayitlar) -> Optional[Durum]:
    secenekler = []
    for ozet in kayitlar:
        zaman = time.strftime("%d.%m.%Y %H:%M", time.localtime(ozet["son"])) if ozet["son"] else "-"
        etiket = ozet["ad"]
        if ozet.get("sinif"):
            etiket = "{}  ({})".format(etiket, ozet["sinif"])
        secenekler.append((etiket, "{} görev  {} Bölüm {}  {} {}".format(
            ozet["gorev"], S["dikey"], ozet["bolum"] + 1, S["dikey"], zaman)))
    secenekler.append(("Geri dön", ""))
    secim = ekran.menu("KAYITLI OYUNLAR", secenekler)
    if secim >= len(kayitlar):
        return None
    return _kayit_ac(kayitlar[secim])


def _kayit_sec() -> Optional[Durum]:
    """
    Kayıtlı sefere dönüş.

    Okulda kayıt klasörü ortak olabilir; orada bütün okulun kayıtlarını
    listelemek hem uzun hem de herkesin herkesin dosyasını açması demek.
    Bu yüzden numaralı kayıt varsa önce numara sorulur. Numarasız (ev)
    kayıtlar eskisi gibi listeden seçilir.
    """
    kayitlar = durum_modulu.kayitlari_listele()
    if not kayitlar:
        ekran.bilgi("Kayıtlı oyun yok.")
        return None

    numarasizlar = [o for o in kayitlar if not o.get("numara")]
    if not any(o.get("numara") for o in kayitlar):
        return _listeden_sec(kayitlar)

    ekran.yaz()
    numara = ekran.sor("Öğrenci numaran (numarasız oynuyorsan boş bırak):", "")
    if not numara:
        if not numarasizlar:
            ekran.bilgi("Numarasız kayıt yok. Numaranı yazman gerekiyor.")
            return None
        return _listeden_sec(numarasizlar)

    bulunan = durum_modulu.numarayla_bul(numara)
    if not bulunan:
        ekran.hata("{} numarasıyla kayıt bulunamadı. Numaranı kontrol et ya da "
                   "ana ekrandan yeni sefer aç.".format(numara))
        ekran.bekle()
        return None
    if len(bulunan) > 1:
        # Aynı numara birden çok şubede olabilir (okul numaraları sınıf içinde
        # tekrar ediyorsa). Ayrımı öğrenciye yaptıralım.
        return _listeden_sec(bulunan)
    return _kayit_ac(bulunan[0])


def basla() -> None:
    """Programın giriş noktası."""
    try:
        adet = icerigi_yukle()
    except Exception as sorun:  # içerik modülünde hata varsa oyun hiç açılmasın demeyelim
        adet = 0
        ekran.hata("İçerik yüklenirken sorun: {}".format(sorun))

    try:
        while True:
            _acilis_ekrani()
            if adet == 0:
                ekran.hata("Hiç görev içeriği bulunamadı (oyun/icerik klasörü boş?).")
            secim = ekran.menu("", [
                ("Yeni sefer", "baştan başla"),
                ("Kayıtlı sefere devam et", ""),
                ("Nasıl oynanır", ""),
                ("Öğretmen girişi", "sınıf raporu, karneler ve içerik araçları"),
                ("Çık", ""),
            ])
            if secim == 0:
                durum = _yeni_oyun()
            elif secim == 1:
                durum = _kayit_sec()
            elif secim == 2:
                _nasil_oynanir()
                continue
            elif secim == 3:
                # Öğretmen araçları bugüne kadar yalnızca komut satırındaydı;
                # okulda kimse terminal açmıyor. Bkz. araclar/ogretmen.py
                from araclar.ogretmen import ogretmen_girisi
                ogretmen_girisi()
                continue
            else:
                return

            if durum is not None:
                Oyun(durum).calistir()
    except OyunuBirak:
        ekran.yaz()
        ekran.yaz("Görüşürüz, kâşif.", "acik_cam")


def _nasil_oynanir() -> None:
    ekran.temizle()
    ekran.baslik("NASIL OYNANIR", "kalin", "acik_cam")
    ekran.kutu(
        "Her görev bir olayla başlar. Sana \"x'i bul\" denmez; bir aksaklık "
        "anlatılır.\n\n"
        "1. BRİFİNG'i oku. Neyin bilinmediğini kendin fark etmen gerekiyor.\n"
        "2. KAYNAKLARI incele. Her inceleme dikkat harcar, hepsini açmak "
        "zorunda değilsin.\n"
        "3. MODELLEME adımında olayı hangi bağıntının anlattığını seçersin. "
        "Bu adım, çözümün nedenini kurduğun yerdir.\n"
        "4. ÇÖZÜM adımında sayıyı ya da cevabı yazarsın.\n\n"
        "İlk denemede ipucusuz bulmak tam puandır. İpucu ve fazladan deneme "
        "puanı düşürür ama seni durdurmaz - amaç not değil, öğrenmek.",
        "", "beyaz")
    ekran.yaz()
    ekran.yaz("Soru içindeyken kullanabileceğin komutlar:", "kalin")
    for harf, aciklama in [("k", "kanıtları incele"), ("i", "ipucu"),
                           ("b", "brifingi tekrar oku"), ("d", "defterim"),
                           ("x", "görevden çekil")]:
        ekran.madde("{} = {}".format(ekran.renkli(harf, "acik_sari", "kalin"), aciklama))
    ekran.bekle()
