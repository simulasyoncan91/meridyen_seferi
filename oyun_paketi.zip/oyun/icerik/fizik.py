# -*- coding: utf-8 -*-
"""
Fizik görevleri (lise, 9-13).

Çerçeve: üssün KUVVET ATÖLYESİ. Vinçler, palangalar, kaldırma düzenekleri.
Ortaokulun Laboratuvarı ile ayrımı şu: orada "hangi büyüklük işin içinde"
sorulur, burada düzeneğin kendisi bilinmeyendir - kurulum okunur, kazancın
nereden geldiği bulunur, hesap ondan sonra gelir.

Fen Bilimleri (ortaokul) kaldırılmadı; bu modül onun üstüne biner.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import (
    PERSONEL, ad_sec, coklu_adimi, model_adimi, sayi_adimi, secim_adimi, sirala_adimi, sy,
    yorum_adimi,
)


# ==========================================================================
# MEKANİK AVANTAJ - palangada kuvvet ve yol
# ==========================================================================

@bulmaca(ders="fizik", konu="makara", kademeler=(9, 13), agirlik=1.2)
def palanga_kazanci(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Palangada kuvvet kazancı 2n; kuvvetten kazanılan yoldan kaybedilir."""
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    hareketli = rastgele.choice([2, 3])
    kazanc = 2 * hareketli
    # Yükü kazancın katı seç: bölme tam çıksın, hesap değil kurulum sınansın.
    kuvvet = rastgele.choice([45, 60, 75, 90])          # N
    yuk = kazanc * kuvvet                               # N
    yukseklik = rastgele.choice([3, 4, 5, 6])           # m
    ip_yolu = kazanc * yukseklik                        # m
    is_miktari = yuk * yukseklik                        # J

    return Bulmaca(
        kod="fizik-palanga-kazanci",
        ders="fizik",
        baslik="Ambardaki Palanga",
        kademe=kademe,
        konu="makara",
        kazanim="Basit makinelerde mekanik avantaj; kuvvet kazancı ile yol "
                "kaybının işi değiştirmemesi.",
        dikkat=6,
        brifing=(
            "{} ambardaki ağır sandığı üst kata çıkaracak ama tek başına "
            "kaldıramıyor. Duvarda asılı duran palangayı takmış.\n\n"
            "Şimdi tartışma çıktı: biri \"makara taktık, artık iş yarıya "
            "indi\" diyor; bir başkası \"makara ne yapsın, ağırlık ağırlıktır\" "
            "diyor.\n\n"
            "Halatı çekecek olan kişi ise tek bir şey sormuş: kaç newton "
            "asılacağım ve kaç metre halat çekeceğim? Kimse cevap veremedi."
        ).format(kisi),
        kanitlar=[
            Kanit("Palanga etiketi",
                  "Düzenek: {} hareketli, {} sabit makara.\n"
                  "Sabit makaralar tavana, hareketli makaralar yükün "
                  "üzerindeki tek bloğa bağlı. Tek ve esnemeyen ipin bir ucu tavana sabit; ip makaralar arasında sırayla dolaşıyor. Yük bloğunu taşıyan dikey ip kolları her hareketli makaranın iki yanında; serbest uç aşağı çekiliyor.".format(hareketli, hareketli),
                  bedel=2, kritik=True),
            Kanit("Tartı fişi",
                  "Sandığın ağırlığı: {} N".format(yuk), bedel=1, kritik=True),
            Kanit("Vinç çizelgesi",
                  "Sandık zeminden {} metre yukarı çıkacak.".format(yukseklik),
                  bedel=1, kritik=True),
            Kanit("Fizik el kitabı",
                  "\"Palangada yükü taşıyan ip kolu sayısı kadar kuvvetten "
                  "kazanılır. İpin ucu tavana bağlı bu düzende n hareketli makara için kuvvet "
                  "kazancı 2n'dir. Sabit makara kuvveti küçültmez, yalnızca "
                  "çekme yönünü değiştirir. Kuvvetten kazanılan oran kadar "
                  "yoldan kaybedilir; sürtünme ve makara ağırlıkları ihmal "
                  "edilir.\"", bedel=2, kritik=True),
            Kanit("Halat deposu kaydı",
                  "Ambarda bu düzeneğe yetecek uzunlukta halat var; halat ideal modelde kütlesiz ve esnemez kabul ediliyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bu düzeneğin kuvvetten kazancını ne belirler?",
                dogru=("Yükü taşıyan ip kolu sayısı: her hareketli makara iki kol "
                       "ekler, kazanç 2n olur."),
                yanlislar={
                    ("Toplam makara sayısı; sabit makaralar da kuvvetten kazandırır, çünkü "
                     "her makara yükü paylaşır."):
                        "Sabit makarayı da kazanca kattın. Sabit makara hareketli blokta değildir; tek başına kuvvet kazandırmaz ve çekme yönünü "
                        "değiştirir; kuvveti küçültmez.",
                    ("Halatın uzunluğu; uzun halatla daha az kuvvet gerekir, çünkü yük "
                     "halat boyunca dağılır."):
                        "Halat uzunluğunu kuvvetle karıştırdın. Uzunluk çekme "
                        "YOLUNU belirler, gereken kuvveti değil.",
                    "Yükün ağırlığı; ağır yükte kazanç kendiliğinden büyür.":
                        "Kazancı yüke bağladın. Kazanç kurulumdan gelir; aynı "
                        "palanga hafif yükte de ağır yükte de aynı oranda "
                        "kazandırır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sandığı havada tutan şey, hareketli makaralardan geçip yükü "
                    "taşıyan ip kollarıdır. Her hareketli makara yükü iki kola "
                    "paylaştırır; bu kurulumda n hareketli makarada kazanç 2n olur. "
                    "Sabit makaralar kuvveti tavana aktarır; hareketli bloğu doğrudan destekleyen ip kollarına eklenmez. "
                    "İpin serbest ucunu aşağı çekmeyi sağlar; çekme yönünü "
                    "değiştirir."
                ),
                ipuclari=[
                    "Sandığı havada tutan ip kollarını say; tavana bağlı olanı sayma.",
                    "Bir hareketli makara yükü kaç kola paylaştırıyor?",
                ],
                cozum=(
                    "1) Düzenekte hareketli makara sayısı n okunur.\n"
                    "2) Yükü taşıyan ip kolu sayısı 2n'dir; kuvvet kazancı da budur.\n"
                    "3) Sabit makaralar sayıya girmez, yalnızca yön değiştirir.\n"
                    "Bu düzenekte n = {} olduğuna göre kazanç 2 × {} = {} olur."
                ).format(hareketli, hareketli, kazanc),
                puan=18,
            ),
            sayi_adimi(
                soru="Sandığı dengede tutmak için halata kaç newton asılmalı?",
                cevap=kuvvet,
                birim="N",
                aciklama=(
                    "Ağırlık, yükü taşıyan {} ip koluna eşit paylaşılır: "
                    "{} N ÷ {} = {} N."
                ).format(kazanc, yuk, kazanc, kuvvet),
                yaygin_yanlislar={
                    yuk: "Palangayı hiç hesaba katmadın; yazdığın sayı sandığın "
                         "kendi ağırlığı. Düzenek tam da bu sayıyı küçültmek "
                         "için kuruldu.",
                    yuk / float(hareketli):
                        "Hareketli makara sayısına böldün ama her makara yükü "
                        "İKİ kola paylaştırıyor. Bölmen gereken sayı n değil, 2n.",
                },
                ipuclari=[
                    "Ağırlık, yükü taşıyan kollara eşit dağılır.",
                    "Ağırlığı kuvvet kazancına böl.",
                ],
                tolerans=0.5,
                puan=14,
            ),
            sayi_adimi(
                soru="Sandık {} metre yükselecek. Halattan kaç metre çekmek "
                     "gerekir?".format(yukseklik),
                cevap=ip_yolu,
                birim="m",
                aciklama=(
                    "Kuvvetten kazanılan oran kadar yoldan kaybedilir: "
                    "{} × {} m = {} m halat çekilir."
                ).format(kazanc, yukseklik, ip_yolu),
                yaygin_yanlislar={
                    yukseklik: "Halat yolunu yükün yoluyla aynı saydın. Öyle "
                               "olsaydı kuvvet bedavaya küçülürdü; kazandığın "
                               "oranı yoldan geri verirsin.",
                    yukseklik * hareketli:
                        "Yolu n katı aldın ama kuvveti 2n'ye bölmüştün. "
                        "Kuvvette kullandığın oranın aynısı yolda da geçerli.",
                },
                ipuclari=[
                    "Kuvvette kazandığın oranı düşün; yol o oranda uzar.",
                ],
                tolerans=0.05,
                puan=14,
            ),
            yorum_adimi(
                soru="Palanga sayesinde yapılan İŞ de azalıyor mu?",
                dogru="Hayır; kuvvet küçülürken yol aynı oranda uzar, iş değişmez.",
                yanlislar={
                    ("Evet; kuvvet kaç kat küçüldüyse iş de o kat küçülür, iş kuvvetle "
                     "ölçülür."):
                        "Kuvveti işle aynı şey saydın. İş, kuvvetle YOLUN "
                        "çarpımıdır; kuvvet küçülürken yol büyüdüğü için "
                        "çarpım yerinde kalıyor.",
                    "Evet; makara sistemi eksik kalan enerjiyi kendisi üretir.":
                        "Düzeneğe enerji kaynağı yükledin. Makara enerji "
                        "üretmez; var olan enerjiyi daha küçük kuvvetle, daha "
                        "uzun yola yayar.",
                    ("Hayır; iş artar, çünkü halatı çok daha uzun çekiyoruz ve uzun yol "
                     "işi büyütür."):
                        "Yalnızca yolun uzamasına baktın. Yol uzarken kuvvet "
                        "aynı oranda küçüldü; ikisi birbirini götürüyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İş = kuvvet × yol. Palangasız kaldırsaydık: {} N × {} m = {} J. "
                    "Palangayla: {} N × {} m = {} J. İki sayı aynı. Basit makine "
                    "işi azaltmaz, yalnızca aynı işi insanın kaldırabileceği "
                    "büyüklükte parçalara böler."
                ).format(yuk, yukseklik, sy(is_miktari),
                         kuvvet, ip_yolu, sy(kuvvet * ip_yolu)),
                puan=12,
            ),
        ],
        kapanis=(
            "Sandık düzgün bir hızla üst kata çıktı. Palanganın yanına küçük "
            "bir levha asıldı: \"Kuvvetten kazandığını yoldan ödersin.\""
        ),
        odul={"cevher": 5, "enerji": 6},
    )


# ==========================================================================
# HÂL DEĞİŞİMİ VE ENERJİ (B37.13 -- müfredat haritası)
#
# `hal_degisim` kodu hem 2018 hem 2026 programında (9. sınıf) geçiyor; ikisi
# de boştu. Satırın `yaygin_yanlis` alanı:
#
#   "Hâl değişirken sıcaklığın zorunlu artacağını sanmak."
#
# `isi_hesabi` (fen.py) ile KARIŞTIRILMAMALI: o görev tek hâlde ısıtmayı
# (Q = m·c·ΔT) ölçüyor. Bu görev hâl değişimini ve ısıtma eğrisindeki DÜZLÜĞÜ
# ölçüyor.
#
# YANILGININ SAYISAL KARŞILIĞI: erime sırasında ΔT = 0. Q = m·c·ΔT formülünü
# oraya körü körüne uygulayan öğrenci "erimeye enerji gitmez, 0" bulur. O sayı
# doğrudan bir çeldirici -- yanılgının ta kendisi.
#
# DEĞERLER 9. SINIF MÜFREDATINDAKİLER, KANITTA TABLO OLARAK:
#   buzun öz ısısı 0,5 cal/g°C · buzun erime ısısı 80 cal/g · suyun öz ısısı 1
# Kütle kg, enerji kcal: 1 kg için buz 0,5 kcal/°C, erime 80 kcal, su 1 kcal/°C.
# ==========================================================================

_HAL_ISITICI_KATSAYI = 5      # ısıtıcı gücü = kütle(kg) x 5 kcal/dk


def _hal_havuzu():
    """(kutle, buz_sicaklik, su_sicaklik): kg, buzun başlangıç °C (eksi), suyun son °C.

    Aranıyor, çünkü görev ancak şu koşullarda ölçmek istediği şeyi ölçer:

      1. Erime payı, ısıtma paylarının TOPLAMINDAN büyük olmalı. Son adımın
         dersi "düzlük, eğrinin en pahalı kısmı" -- bu koşul tutmazsa ders
         tersine döner. (buz 10-40 °C, su 20-50 °C aralığında hep tutuyor.)
      2. Üç çeldirici birbirinden ve doğru toplamdan FARKLI olmalı. Tek riskli
         çakışma: "erime hiç yok" ile "yalnız erime" ya da "hepsi suymuş gibi"
         hesapları -- 0,5·T1 + T2 = 80 ya da T1 + T2 = 80 olunca.
      3. Isıtma günlüğündeki dakikalar tam sayı olmalı: buz sıcaklığı 10'un,
         su sıcaklığı 5'in katı.
    """
    havuz = []
    for kutle in (1, 2, 3, 4, 5):
        for buz in (10, 20, 30, 40):
            for su in (20, 30, 40, 50):
                q_buz = kutle * buz // 2
                q_erime = kutle * 80
                q_su = kutle * su
                toplam = q_buz + q_erime + q_su
                if q_erime <= q_buz + q_su:
                    continue
                celdiriciler = {q_buz + q_su, kutle * (buz + su), q_erime}
                if len(celdiriciler) != 3 or toplam in celdiriciler:
                    continue
                havuz.append((kutle, buz, su))
    return tuple(havuz)


_HAL = _hal_havuzu()


@bulmaca(ders="fizik", konu="hal_degisim", kademeler=(9, 13), agirlik=1.3)
def buz_eritme(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Hâl değişiminde sıcaklık sabit kalır; verilen enerji hâl değişimine gider."""
    kutle, buz, su = rastgele.choice(_HAL)
    q_buz = kutle * buz // 2
    q_erime = kutle * 80
    q_su = kutle * su
    toplam = q_buz + q_erime + q_su
    guc = kutle * _HAL_ISITICI_KATSAYI
    dk_buz = q_buz // guc
    dk_erime_bitis = dk_buz + q_erime // guc
    dk_son = dk_erime_bitis + q_su // guc
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-buz-eritme",
        ders="fizik",
        baslik="Buz Eritme",
        kademe=kademe,
        konu="hal_degisim",
        kazanim="Hâl değişimi sırasında sıcaklığın sabit kaldığını ısıtma eğrisinden "
                "yorumlama; hâl değişimi için gereken enerjiyi hesaplama.",
        dikkat=7,
        brifing=(
            "Üs, buzuldan kestiği buzu eritip içme suyu elde ediyor. Bugün "
            "{} kg buz kazana kondu ve ısıtıcı açıldı.\n\n"
            "{} ısıtma günlüğünü getirdi ve şikâyet etti: \"Termometre bozuk. "
            "Isıtıcı sürekli çalıştı ama sıcaklık uzun süre hiç yükselmedi. O "
            "sürede yakıt boşa gitmiş olmalı.\"\n\n"
            "Günlüğe bakıp termometrenin gerçekten bozuk olup olmadığını ve "
            "ne kadar enerji harcandığını bulmamız gerekiyor."
        ).format(kutle, kisi),
        kanitlar=[
            Kanit("Isıtma günlüğü",
                  "{}. dakika: -{} °C (buz)\n"
                  "{}. dakika: 0 °C (buz erimeye başladı)\n"
                  "{}. dakika: 0 °C (hâlâ eriyor)\n"
                  "{}. dakika: 0 °C (son buz parçası eridi)\n"
                  "{}. dakika: {} °C (su)".format(
                      0, buz, dk_buz, (dk_buz + dk_erime_bitis) // 2,
                      dk_erime_bitis, dk_son, su),
                  bedel=2, kritik=True),
            Kanit("Isıtıcı kaydı",
                  "Isıtıcı baştan sona aynı güçte çalıştı: dakikada {} kcal."
                  .format(guc),
                  bedel=1, kritik=True),
            Kanit("Madde tablosu",
                  "Buzun öz ısısı: 0,5 kcal/(kg·°C)\n"
                  "Buzun erime ısısı: 80 kcal/kg\n"
                  "Suyun öz ısısı: 1 kcal/(kg·°C)",
                  bedel=1, kritik=True),
            Kanit("Termometre kalibrasyonu",
                  "Termometre dün buzlu suda 0 °C, kaynayan suda 100 °C gösterdi.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru=("Isıtıcı çalışmaya devam ettiği hâlde termometre bir süre "
                      "0 °C'de kaldı. Bunun sebebi nedir?"),
                dogru=("Isı sıcaklığı artırmaya değil buzun erimesine, yani hâl "
                       "değişimine gidiyor"),
                yanlislar={
                    "Termometre bozulmuştur; ısı veriliyorsa sıcaklık yükselmek zorundadır":
                        "Hâl değişirken sıcaklığın zorunlu artacağını sandın. "
                        "Kalibrasyon kaydı termometrenin sağlam olduğunu "
                        "gösteriyor; sabitlik gerçek.",
                    ("Isıtıcının verdiği ısı o sırada tamamen havaya kaçmıştır, buza hiç "
                     "ulaşmıyordur"):
                        "Isıtıcı kaydı gücün baştan sona aynı olduğunu söylüyor; "
                        "kayıp o aralıkta birden artmıyor. Isı buza gidiyor.",
                    "Buz ısıyı biriktirir, eriyince sıcaklığı bir anda yükselir":
                        "Günlükte sıcaklık erime bittikten sonra da bir anda "
                        "sıçramıyor; düzgün artıyor. Isı birikmiyor, erimeye "
                        "harcanıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Saf bir madde hâl değiştirirken sıcaklığı sabit kalır. "
                    "Verilen enerji taneciklerin hızını artırmaya değil, onları "
                    "bir arada tutan etkileşimleri koparmaya gider. Isıtma "
                    "eğrisindeki DÜZLÜK bu yüzden oluşur: ısı veriliyor, ama "
                    "sıcaklık değil HÂL değişiyor."
                ),
                ipuclari=[
                    "Termometre kalibrasyonuna bak: termometre gerçekten bozuk mu?",
                    "Sıcaklık sabitken buzun hâline ne oluyor?",
                ],
                cozum=(
                    "Düzlük = hâl değişimi.\n"
                    "Isı veriliyor ama sıcaklık değişmiyor.\n"
                    "O aşamanın enerjisi Q = m · L (erime ısısı)."
                ),
            ),
            sayi_adimi(
                soru="Buzun tamamen erimesi için kaç kcal enerji harcandı?",
                cevap=q_erime,
                birim="kcal",
                aciklama="Q = m · L = {} kg × 80 kcal/kg = {} kcal.".format(kutle, q_erime),
                yaygin_yanlislar={
                    0:
                        "Q = m·c·ΔT formülünü erime aşamasına uyguladın: ΔT = 0 "
                        "olduğu için 0 buldun. Ama sıcaklık değişmiyor diye enerji "
                        "harcanmıyor değil; hâl değişiminde L kullanılır.",
                    q_buz:
                        "Bu, buzu -{} °C'den 0 °C'ye ısıtmanın enerjisi. Soru "
                        "erimeyi soruyor.".format(buz),
                },
                ipuclari=["Hâl değişiminde öz ısı değil, erime ısısı kullanılır."],
                puan=12,
            ),
            sayi_adimi(
                soru=("-{} °C'deki buzu {} °C'lik suya dönüştürmek için "
                      "TOPLAM kaç kcal enerji harcandı?").format(buz, su),
                cevap=toplam,
                birim="kcal",
                aciklama=(
                    "Üç aşama: buzu ısıtmak {} + eritmek {} + suyu ısıtmak {} "
                    "= {} kcal."
                ).format(q_buz, q_erime, q_su, toplam),
                yaygin_yanlislar={
                    q_buz + q_su:
                        "Isıtma aşamalarını topladın ama erimeyi atladın -- "
                        "sıcaklığın değişmediği aşamayı saymadın.",
                    kutle * (buz + su):
                        "Hepsini tek bir ısıtma gibi hesapladın: suyun öz ısısıyla "
                        "-{} °C'den {} °C'ye. Buzun öz ısısı farklı ve arada "
                        "erime var.".format(buz, su),
                    q_erime:
                        "Yalnız erimeyi saydın; buzu ve suyu ısıtmak da enerji "
                        "istiyor.",
                },
                ipuclari=["Eğriyi üç parçaya böl: buz ısınıyor, buz eriyor, su ısınıyor."],
                puan=14,
            ),
            yorum_adimi(
                soru=("{} \"sıcaklık değişmediğine göre o aşamada yakıt "
                      "harcamadık, onu hesaptan çıkaralım\" diyor. Haklı mı?"
                      ).format(kisi),
                dogru=("Hayır: sabit sıcaklıktaki erime aşaması en çok enerji harcanan "
                       "aşamadır."),
                yanlislar={
                    ("Evet: sıcaklık değişmiyorsa madde enerji almıyordur, ısıtıcı boşa "
                     "çalışmıştır."):
                        "Hâl değişirken sıcaklığın zorunlu artacağını sandın. "
                        "Isıtıcı o sırada da çalışıyordu ve günlükte en uzun "
                        "aşama o.",
                    ("Hayır, ama erime aşaması öteki aşamalar yanında önemsizdir, kısa bir "
                     "geçiştir."):
                        "Tersine: erime ısısı 80 kcal/kg, öz ısılar ise 1 kcal/kg°C "
                        "ve altında. Hesabın en büyük parçası erime.",
                    "Evet, çünkü o aşamada termometre bozuk olduğu için ölçüm güvenilmez.":
                        "Kalibrasyon kaydı termometrenin sağlam olduğunu gösteriyor. "
                        "Sabitlik bir arıza değil, hâl değişiminin kendisi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Günlükte düzlük {} dakika sürdü; öteki iki aşamanın toplamı "
                    "{} dakika. Isıtıcı aynı güçte çalıştığı için süre, enerjinin "
                    "doğrudan ölçüsü: erime en pahalı aşama. Bu yüzden buzu eritmek, "
                    "aynı suyu ısıtmaktan çok daha fazla enerji ister."
                ).format(dk_erime_bitis - dk_buz, dk_buz + (dk_son - dk_erime_bitis)),
                puan=12,
            ),
        ],
        kapanis=("Rapor: termometre sağlam. {} kg buzu -{} °C'den {} °C'lik suya "
                 "çevirmek {} kcal istedi; bunun {} kcal'i sıcaklığın hiç "
                 "değişmediği erime aşamasında harcandı."
                 ).format(kutle, buz, su, toplam, q_erime),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# DALGALARDA KIRILMA: FREKANS SABİT (B37.13 -- müfredat haritası)
#
# Oyunda dalga görevi yoktu. İki satır birbirini tamamlıyor:
#   `dalga_yansima_kirilma` (2018+2026, 10. sınıf) -- yanılgı: "Ortam değişince
#       kaynağın frekansının değiştiğini sanmak"; bağlam: dalga havuzunda
#       derinlik değişimi.
#   `dalga_kavramlari` (2018+2026, 10. sınıf) -- yanılgı: "frekansla sürati
#       karıştırmak".
#
# Dalga derin bölgeden sığ bölgeye geçince HIZ ve DALGA BOYU değişir;
# FREKANS değişmez, çünkü onu kaynak belirler. Bağıntı: v = f · λ.
#
# YANILGININ SAYISAL KARŞILIĞI: hız sorusunda frekansı hız sanan öğrencinin
# bulduğu sayı (f) doğrudan bir çeldirici.
#
# HAVUZDA ÖNCEDEN YAKALANAN İKİ ÇAKIŞMA:
#   f = λ_derin  -> "frekansı hız sanmak" ile "dalga boyunu hız sanmak" aynı
#                   sayıya düşer (5 Hz ve 5 cm gibi), iki hata tek teşhis alır.
#   λ_derin = v_sığ -> sığ bölge sorusunda iki çeldirici çakışır.
# ==========================================================================

def _dalga_havuzu():
    """(frekans, lambda_derin, lambda_sig): Hz, cm, cm. v_sığ = f · λ_sığ.

    Koşullar:
      1. Sığ bölgede dalga boyu KISA olmalı (sığ suda hız düşer).
      2. f != λ_derin ve λ_derin != v_sığ -- çeldiriciler ayrışsın.
      3. Tam sayılar: bütün hızlar f · λ olarak kurulduğu için kendiliğinden.
    """
    havuz = []
    for frekans in (5, 10, 20):
        for lambda_derin in (2, 3, 4, 5, 6):
            if frekans == lambda_derin:
                continue
            for lambda_sig in range(1, lambda_derin):
                v_sig = frekans * lambda_sig
                if lambda_derin == v_sig:
                    continue
                havuz.append((frekans, lambda_derin, lambda_sig))
    return tuple(havuz)


_DALGA = _dalga_havuzu()


@bulmaca(ders="fizik", konu="dalga_yansima_kirilma", kademeler=(9, 13), agirlik=1.3)
def dalga_havuzu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Ortam değişince frekans sabit, hız ve dalga boyu değişir: v = f · λ."""
    frekans, lambda_derin, lambda_sig = rastgele.choice(_DALGA)
    v_derin = frekans * lambda_derin
    v_sig = frekans * lambda_sig
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-dalga-havuzu",
        ders="fizik",
        baslik="Dalga Havuzu",
        kademe=kademe,
        konu="dalga_yansima_kirilma",
        kazanim="Dalganın ortam değiştirirken frekansının sabit kaldığını, hız ve "
                "dalga boyunun değiştiğini açıklama; v = f · λ bağıntısını kullanma.",
        dikkat=7,
        brifing=(
            "Üs laboratuvarı, göl tabanındaki titreşim sensörünü denemek için "
            "bir dalga havuzu kurdu. Havuzun bir yarısı derin, öteki yarısı "
            "sığ. Derin taraftaki bir titreşici su dalgaları üretiyor ve "
            "dalgalar sığ tarafa geçiyor.\n\n"
            "{} sensörün sığ bölgede FARKLI bir frekans ölçeceğini ve bu yüzden "
            "yeniden ayarlanması gerektiğini söylüyor. Ölçümlere bakıp bunun "
            "doğru olup olmadığını bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Titreşici ayarı",
                  "Titreşici saniyede {} kez titreşiyor: frekansı {} Hz."
                  .format(frekans, frekans),
                  bedel=1, kritik=True),
            Kanit("Derin bölge ölçümü",
                  "Derin bölgede ardışık iki tepe arası (dalga boyu): {} cm."
                  .format(lambda_derin),
                  bedel=1, kritik=True),
            Kanit("Sığ bölge ölçümü",
                  "Sığ bölgede dalgaların yayılma hızı: {} cm/s.".format(v_sig),
                  bedel=2, kritik=True),
            Kanit("Bağıntı notu",
                  "Bir dalganın hızı, frekansı ile dalga boyunun çarpımıdır: "
                  "v = f · λ.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Dalga derin bölgeden sığ bölgeye geçerken hangisi DEĞİŞMEZ?",
                dogru="Frekans; onu dalgayı üreten kaynak belirler",
                yanlislar={
                    "Hız; dalga aynı titreşiciden geldiği için hızı da aynı kalır":
                        "Hızı ortam belirler, kaynak değil. Sığ suda dalga "
                        "yavaşlar.",
                    "Dalga boyu; dalga aynı dalga olduğu için boyu da korunur":
                        "Dalga boyu hızla birlikte değişir: hız düşünce, "
                        "frekans sabitken dalga boyu kısalır.",
                    "Hiçbiri; ortam değişince üçü de değişir":
                        "Ortam değişince kaynağın frekansının da değiştiğini "
                        "sandın. Titreşici aynı hızla titreşiyor; saniyede geçen "
                        "tepe sayısı değişmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Frekans, saniyede bir noktadan geçen tepe sayısıdır ve onu "
                    "KAYNAK belirler. Dalga sığ bölgeye geçince tepeler "
                    "yavaşlar ve birbirine yaklaşır -- hız ve dalga boyu düşer --"
                    " ama saniyede geçen tepe sayısı aynı kalır. Yoksa sınırda "
                    "tepeler ya birikir ya kaybolurdu."
                ),
                ipuclari=[
                    "Saniyede kaç tepe üretildiğini ne belirliyor?",
                    "Sınırdan saniyede geçen tepe sayısı sınırın iki yanında farklı olabilir mi?",
                ],
                cozum=(
                    "Frekans -> kaynak belirler, sabit.\n"
                    "Hız -> ortam belirler, değişir.\n"
                    "Dalga boyu = hız / frekans, hızla birlikte değişir."
                ),
            ),
            sayi_adimi(
                soru="Derin bölgede dalgaların yayılma hızı kaç cm/s?",
                cevap=v_derin,
                birim="cm/s",
                aciklama="v = f · λ = {} Hz × {} cm = {} cm/s.".format(
                    frekans, lambda_derin, v_derin),
                yaygin_yanlislar={
                    frekans:
                        "Frekansla sürati karıştırdın. {} Hz saniyedeki titreşim "
                        "sayısı; hız, bir tepenin saniyede aldığı yol."
                        .format(frekans),
                    lambda_derin:
                        "Dalga boyunu hız sandın; dalga boyu iki tepe arası "
                        "mesafe.",
                    frekans + lambda_derin:
                        "Frekans ile dalga boyunu topladın; bağıntı çarpım.",
                },
                ipuclari=["Bağıntı notuna bak."],
                puan=12,
            ),
            sayi_adimi(
                soru="Sığ bölgede dalga boyu kaç cm?",
                cevap=lambda_sig,
                birim="cm",
                aciklama=(
                    "Frekans sığ bölgede de {} Hz. λ = v / f = {} ÷ {} = {} cm. "
                    "Dalga yavaşladığı için dalga boyu {} cm'den {} cm'ye kısaldı."
                ).format(frekans, v_sig, frekans, lambda_sig, lambda_derin, lambda_sig),
                yaygin_yanlislar={
                    lambda_derin:
                        "Dalga boyunun değişmediğini varsaydın. Hız düştüğü hâlde "
                        "frekans sabit kaldığına göre dalga boyu da kısalmalı.",
                    v_sig:
                        "Hızı dalga boyu olarak yazdın; frekansa bölmen gerekiyor.",
                    v_sig * frekans:
                        "Böleceğin yerde çarptın: λ = v / f.",
                },
                ipuclari=["Sığ bölgede de frekans aynı. v = f · λ'dan λ'yı çek."],
                puan=14,
            ),
            yorum_adimi(
                soru="Sensör sığ bölgede farklı bir frekans ölçer mi?",
                dogru="Hayır: frekansı kaynak belirler; değişen hız ve dalga boyudur.",
                yanlislar={
                    ("Evet: dalganın hızı değiştiği için frekansı da değişir, ikisi "
                     "birbirine bağlıdır."):
                        "Ortam değişince kaynağın frekansının değiştiğini sandın. "
                        "Hız değişiyor, ama değişen şey dalga boyu -- frekans "
                        "değil.",
                    ("Evet: dalga boyu kısaldığı için frekans da azalır, sığ suda dalga "
                     "zayıflar."):
                        "Tersine: dalga boyu kısalırken frekans sabit kalıyor, "
                        "azalan şey hız. Üçü birlikte v = f · λ'yı sağlıyor.",
                    "Hayır: çünkü dalganın hızı da değişmez.":
                        "Hüküm doğru ama gerekçe yanlış. Hız değişiyor -- sığ "
                        "bölge ölçümü bunu gösteriyor. Değişmeyen frekans.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Sensörü yeniden ayarlamaya gerek yok: sığ bölgede de {} Hz "
                    "ölçecek. Işık sudan havaya, ses havadan duvara geçerken de "
                    "aynısı olur: hız ve dalga boyu ortama göre değişir, frekans "
                    "kaynakla birlikte kalır."
                ).format(frekans),
                puan=12,
            ),
        ],
        kapanis=("Rapor: frekans iki bölgede de {} Hz. Hız {} cm/s'den {} cm/s'ye, "
                 "dalga boyu {} cm'den {} cm'ye düştü. Sensör ayarı değişmeyecek."
                 ).format(frekans, v_derin, v_sig, lambda_derin, lambda_sig),
        odul={"itibar": 5, "erzak": 1, "enerji": 2},
    )


# ==========================================================================
# ALTERNATİF AKIM VE TRANSFORMATÖR (B37.13 -- müfredat haritası)
#
# `alternatif_akim` (2018+2026, 11. sınıf) boştu; oyunda transformatör
# içeriği hiç yoktu. Bağlam: "Üs enerji aktarım modelinde gerilim ve akımı
# karşılaştırma". `yaygin_yanlis`:
#
#   "Transformatörün ideal modelde güç ürettiğini sanmak."
#
# İdeal transformatörde GÜÇ KORUNUR: V_s / V_p = N_s / N_p ve I_s / I_p =
# N_p / N_s, dolayısıyla V_s · I_s = V_p · I_p. Gerilim k kat artarken akım
# k kat azalır.
#
# YANILGININ İKİ SAYISAL YÜZÜ:
#   * akım sorusunda "akım da gerilim gibi k kat artar" -> I_p · k
#   * güç iddiasında gerilimi yükseltip akımı eskisi gibi bırakmak ->
#     V_s · I_p = k kat "üretilmiş" güç
#
# GERİLİMİ NEDEN YÜKSELTİYORUZ -- gerçek sebep son adımda: güç artmıyor, ama
# akım k kat düştüğü için hat kaybı (I² · R) k² kat azalıyor.
# ==========================================================================

def _trafo_havuzu():
    """(sarim_p, oran, gerilim_p, akim_p): N_p, k = N_s/N_p, V_p (V), I_p (A).

    Koşullar:
      1. Çıkış akımı TAM SAYI olmalı: I_p, k'ya tam bölünmeli.
      2. Ters oranlı gerilim çeldiricisi (V_p / k) de tam sayı olmalı -- yoksa
         o hatayı yapan öğrencinin yazacağı sayı teşhise hiç eşleşmez.
      k > 1 olduğu için geri kalan çeldiriciler kendiliğinden ayrışıyor.
    """
    havuz = []
    for sarim_p in (100, 200):
        for oran in (2, 5, 10, 20):
            for gerilim_p in (100, 200, 400):
                if gerilim_p % oran:
                    continue
                for akim_p in (20, 40, 50, 100):
                    if akim_p % oran:
                        continue
                    havuz.append((sarim_p, oran, gerilim_p, akim_p))
    return tuple(havuz)


_TRAFO = _trafo_havuzu()


@bulmaca(ders="fizik", konu="alternatif_akim", kademeler=(9, 13), agirlik=1.3)
def enerji_hatti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İdeal transformatörde güç korunur: gerilim artarken akım azalır."""
    sarim_p, oran, gerilim_p, akim_p = rastgele.choice(_TRAFO)
    sarim_s = sarim_p * oran
    gerilim_s = gerilim_p * oran
    akim_s = akim_p // oran
    guc = gerilim_p * akim_p
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-enerji-hatti",
        ders="fizik",
        baslik="Enerji Hattı",
        kademe=kademe,
        konu="alternatif_akim",
        kazanim="İdeal transformatörde gerilim ve akımın sarım sayılarıyla "
                "ilişkisini kullanma; transformatörün güç üretmediğini açıklama.",
        dikkat=7,
        brifing=(
            "Üssün jeneratörü uzaktaki gözlem karakoluna uzun bir hatla enerji "
            "gönderiyor. Hattın başına bir transformatör kondu.\n\n"
            "{} rapor verdi: \"Transformatör gerilimi {} kat artırdı. Artık "
            "karakola {} kat daha fazla güç gidiyor; karakola yeni cihazlar "
            "bağlayabiliriz.\"\n\n"
            "Karakola yeni yük bağlanmadan önce bu iddianın doğru olup "
            "olmadığını bulmamız gerekiyor."
        ).format(kisi, oran, oran),
        kanitlar=[
            Kanit("Jeneratör çıkışı",
                  "Transformatöre giren: {} V gerilim, {} A akım."
                  .format(gerilim_p, akim_p),
                  bedel=1, kritik=True),
            Kanit("Transformatör etiketi",
                  "Birincil sarım: {} tur. İkincil sarım: {} tur. İdeal "
                  "(kayıpsız) model.".format(sarim_p, sarim_s),
                  bedel=2, kritik=True),
            Kanit("Bağıntı notu",
                  "Gerilim sarım sayısıyla doğru orantılıdır: V_s / V_p = N_s / N_p.\n"
                  "Güç = gerilim × akım.",
                  bedel=1, kritik=True),
            Kanit("Hat notu",
                  "Hattın direnci akımı ısıya çeviriyor. Hatta ısı olarak kaybolan "
                  "güç: I² × R.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İdeal bir transformatör gerilimi yükseltirken gücü nasıl etkiler?",
                dogru="Güç değişmez: gerilim kaç kat artarsa akım o kat azalır",
                yanlislar={
                    "Gücü de gerilimle aynı oranda artırır, çünkü güç gerilimle orantılıdır":
                        "Transformatörün güç ürettiğini sandın. Transformatörün "
                        "bir enerji kaynağı yok; ancak aldığı gücü aktarabilir.",
                    "Gerilim ve akım birlikte artar, güç çok daha fazla artar":
                        "İkisi birlikte artsaydı transformatör hiçlikten enerji "
                        "üretirdi. Birincil ve ikincil gücün eşitliği bunu engeller.",
                    "Gücü azaltır, çünkü çıkış akımı düşer":
                        "Akım düşüyor ama gerilim aynı oranda artıyor. İdeal "
                        "modelde çarpım, yani güç, aynı kalır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Enerji korunur: transformatör bir enerji kaynağı değil, bir "
                    "dönüştürücü. İdeal modelde birincil güç ikincil güce eşittir "
                    "(V_p · I_p = V_s · I_s). Gerilimi yükselten bir transformatör "
                    "bu yüzden akımı aynı oranda düşürmek ZORUNDADIR."
                ),
                ipuclari=[
                    "Transformatöre dışarıdan başka bir enerji giriyor mu?",
                    "Güç gerilim × akım ise, gerilim artarken güç sabit kalması için akıma ne olmalı?",
                ],
                cozum=(
                    "V_s = V_p × (N_s / N_p)\n"
                    "I_s = I_p × (N_p / N_s)\n"
                    "V_s × I_s = V_p × I_p"
                ),
            ),
            sayi_adimi(
                soru="Transformatörün çıkışındaki gerilim kaç volt?",
                cevap=gerilim_s,
                birim="V",
                aciklama="V_s = {} V × ({} / {}) = {} V.".format(
                    gerilim_p, sarim_s, sarim_p, gerilim_s),
                yaygin_yanlislar={
                    gerilim_p:
                        "Gerilimi değişmemiş saydın; ikincil sarım birincilden "
                        "fazla, gerilim yükseliyor.",
                    gerilim_p // oran:
                        "Oranı ters kurdun: gerilim sarım sayısıyla DOĞRU "
                        "orantılı. Çok sarımlı taraf yüksek gerilimli.",
                },
                ipuclari=["Sarım oranını bul ve gerilimle çarp."],
                puan=12,
            ),
            sayi_adimi(
                soru="Transformatörün çıkışındaki akım kaç amper?",
                cevap=akim_s,
                birim="A",
                aciklama=(
                    "Güç korunduğu için akım, gerilimin tersine değişir: "
                    "I_s = {} A × ({} / {}) = {} A. Kontrol: {} V × {} A = {} W, "
                    "girişteki {} V × {} A ile aynı."
                ).format(akim_p, sarim_p, sarim_s, akim_s,
                         gerilim_s, akim_s, guc, gerilim_p, akim_p),
                yaygin_yanlislar={
                    akim_p:
                        "Akımı değişmemiş saydın. Gerilim {} kat arttı; güç sabit "
                        "kalması için akım {} kat azalmalı.".format(oran, oran),
                    akim_p * oran:
                        "Akımı da gerilim gibi artırdın. İkisi birlikte artsaydı "
                        "transformatör güç üretirdi.",
                },
                ipuclari=["Giriş gücünü hesapla; çıkış gücü de aynı olmalı."],
                puan=14,
            ),
            yorum_adimi(
                soru="Rapordaki \"karakola {} kat güç gidiyor\" iddiası doğru mu?".format(oran),
                dogru=("Hayır: ideal modelde çıkış gücü girişe eşit; gerilim {} kat arttı, "
                       "akım {} kat azaldı.").format(oran, oran),
                yanlislar={
                    ("Evet: gerilim {} kat arttığına göre güç de {} kat artar, çünkü güç "
                     "gerilimle orantılıdır.").format(oran, oran):
                        "Transformatörün güç ürettiğini sandın. Gerilimi yükseltip "
                        "akımı eskisi gibi bırakan hesap ({} V × {} A) gerçekte "
                        "olmayan bir güç verir.".format(gerilim_s, akim_p),
                    "Hayır: transformatör gücü {} kat azaltır, çünkü akım {} kat düşer.".format(oran, oran):
                        "Akım düşüyor ama gerilim aynı oranda artıyor; güç "
                        "azalmıyor, aynı kalıyor.",
                    "Evet, ama yalnız alternatif akımda; doğru akımda güç değişmez.":
                        "Transformatör zaten yalnız alternatif akımla çalışır, ama "
                        "bu gücü artırdığı anlamına gelmez. İdeal modelde güç "
                        "her durumda korunur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Karakola yeni yük bağlanmamalı: giden güç hâlâ {} W. O hâlde "
                    "gerilimi neden yükseltiyoruz? Hat notunda cevap var: hatta "
                    "kaybolan güç akımın KARESİYLE orantılı. Akım {} kat düştüğü "
                    "için hattaki ısı kaybı {} kat azaldı. Transformatör güç "
                    "üretmiyor -- gücün yolda kaybolmasını önlüyor. Şehirler "
                    "arası iletim hatlarının çok yüksek gerilimle çalışmasının "
                    "sebebi budur."
                ).format(guc, oran, oran * oran),
                puan=12,
            ),
        ],
        kapanis=("Rapor: karakola giden güç {} W, değişmedi. Gerilim {} V -> {} V, "
                 "akım {} A -> {} A; hat kaybı {} kat azaldı."
                 ).format(guc, gerilim_p, gerilim_s, akim_p, akim_s, oran * oran),
        odul={"itibar": 5, "erzak": 1, "enerji": 3},
    )


# ==========================================================================
# VERİM VE ENERJİ: GÜÇ ENERJİ DEĞİLDİR (B37.13 -- müfredat haritası)
#
# `verim_enerji` (2018, 9. sınıf) ve `mekanik_verim` (2026, 12. sınıf)
# boştu; ikisinin yanılgısı ve bağlamı kelimesi kelimesine aynı:
#
#   "Verimi yüzde 100'ün üzerinde yorumlamak; gücü toplam enerji sanmak."
#   Bağlam: "Üs enerji seçeneklerini aynı iş için karşılaştırma."
#
# Meslek modüllerindeki verim görevleri (elektrik, makine) yalnız ilk yarıyı
# ölçüyor ve 10. sınıftan başlıyor. Bu görev İKİNCİ yarıyı da ölçer:
#
# AYNI İŞ, İKİ POMPA. B pompası A'dan AZ güç çekiyor ama verimi düşük; kuleyi
# daha uzun sürede doldurur ve toplamda DAHA ÇOK enerji çeker. "Az güç çeken
# az enerji harcar" diyen öğrenci yanlış pompayı seçer. Havuz bunu her
# örnekte garanti ediyor: P_B < P_A ve verim_B < verim_A.
#
# %100 ÜSTÜ VERİM: satıcı broşüründeki C pompası "%120" yazıyor -- aktarılan
# güç çekilenden büyük. Verim sorusunda bölmeyi ters kuran öğrenci de aynı
# imkânsız sayıya ulaşıyor.
#
# BİRİMLER: güç kW, süre dakika, enerji kJ. kW × s = kJ; dakikayla çarpan
# 60 kat küçük bulur ve bu ayrı bir teşhis alır.
# ==========================================================================

def _pompa_havuzu():
    """(is_kj, verim_a, guc_a10, verim_b, guc_b10): verim yüzde, güç kW×10.

    Koşullar:
      1. B daha AZ güç çeker, verimi daha DÜŞÜK (yanılgı her örnekte yanlış
         pompayı seçtirsin).
      2. Suya aktarılan güç tek ondalık; çekilen enerjiler ve dolum süreleri
         (dakika) TAM SAYI -- iki çözüm yolu (iş ÷ verim, güç × süre) aynı
         tam sayıya çıksın.
      3. Dolum 10-240 dakika: gerçekçi.
    """
    havuz = []
    for is_kj in (1800, 3600, 5400, 7200):
        for verim_a in (60, 75, 80, 90):
            for guc_a10 in (20, 30, 40, 50, 60):
                for verim_b in (50, 60, 75, 80):
                    if verim_b >= verim_a:
                        continue
                    for guc_b10 in (10, 12, 15, 20, 25, 30, 40):
                        if guc_b10 >= guc_a10:
                            continue
                        if (guc_a10 * verim_a) % 100:
                            continue
                        if (is_kj * 100) % verim_a or (is_kj * 100) % verim_b:
                            continue
                        # süre (s) = iş ÷ aktarılan güç; dakika tam sayı olsun
                        if (is_kj * 1000) % (guc_a10 * verim_a * 60):
                            continue
                        if (is_kj * 1000) % (guc_b10 * verim_b * 60):
                            continue
                        dk_a = is_kj * 1000 // (guc_a10 * verim_a * 60)
                        dk_b = is_kj * 1000 // (guc_b10 * verim_b * 60)
                        if dk_a < 10 or dk_b > 240:
                            continue
                        havuz.append((is_kj, verim_a, guc_a10, verim_b, guc_b10))
    return tuple(havuz)


_POMPA = _pompa_havuzu()
_BROSUR_GUCLERI10 = (20, 25, 30, 50)      # × 1,2 -> tek ondalık


@bulmaca(ders="fizik", konu="verim_enerji", kademeler=(9, 13), agirlik=1.3)
def pompa_secimi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aynı iş için çekilen enerji = iş ÷ verim; az güç çeken az enerji harcamaz."""
    is_kj, verim_a, guc_a10, verim_b, guc_b10 = rastgele.choice(_POMPA)
    guc_a, guc_b = guc_a10 / 10.0, guc_b10 / 10.0
    aktarilan_a = guc_a10 * verim_a / 1000.0
    enerji_a = is_kj * 100 // verim_a
    enerji_b = is_kj * 100 // verim_b
    dk_a = is_kj * 1000 // (guc_a10 * verim_a * 60)
    dk_b = is_kj * 1000 // (guc_b10 * verim_b * 60)
    guc_c10 = rastgele.choice(_BROSUR_GUCLERI10)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-pompa-secimi",
        ders="fizik",
        baslik="Pompa Seçimi",
        kademe=kademe,
        konu="verim_enerji",
        kazanim="Verimi aktarılan ve çekilen enerji/güç oranı olarak hesaplama; "
                "aynı iş için harcanan enerjiyi güçten ayırt etme; verimin "
                "%100'ü aşamayacağını açıklama.",
        dikkat=7,
        brifing=(
            "Üssün su kulesi her gün bir kez dolduruluyor ve eski pompa "
            "bozuldu. Depoda iki pompa var, bir de satıcının gönderdiği "
            "broşür.\n\n"
            "{} B pompasını öneriyor: \"B, A'dan az güç çekiyor. Onu takarsak "
            "jeneratörün yakıtından tasarruf ederiz.\"\n\n"
            "Pompa takılmadan önce kuleyi bir kez doldurmak için hangisinin "
            "daha az enerji çektiğini bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Dolum hesabı",
                  "Kuleyi bir kez doldurmak için suya aktarılması gereken "
                  "enerji: {} kJ.".format(is_kj),
                  bedel=1, kritik=True),
            Kanit("A pompası -- deney tezgâhı",
                  "Şebekeden çektiği güç: {} kW. Suya aktardığı güç: {} kW. "
                  "Deneme dolumu {} dakika sürdü."
                  .format(sy(guc_a), sy(aktarilan_a), dk_a),
                  bedel=1, kritik=True),
            Kanit("B pompası -- etiket",
                  "Şebekeden çektiği güç: {} kW. Verim: %{}. Deneme dolumu {} "
                  "dakika sürdü.".format(sy(guc_b), verim_b, dk_b),
                  bedel=1, kritik=True),
            Kanit("C pompası -- satıcı broşürü",
                  "Şebekeden çektiği güç: {} kW. Suya aktardığı güç: {} kW. "
                  "\"Sınıfının en verimlisi: %120!\""
                  .format(sy(guc_c10 / 10.0), sy(guc_c10 * 12 / 100.0)),
                  bedel=1),
            Kanit("Bağıntı notu",
                  "Verim = aktarılan ÷ çekilen.\n"
                  "Enerji = güç × süre (kW × saniye = kJ).",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru=("Aynı kuleyi dolduran iki pompadan hangisinin daha az "
                      "enerji çektiğini ne belirler?"),
                dogru=("Verim: çekilen enerji = aktarılan enerji ÷ verim; güç yalnız "
                       "harcama hızıdır"),
                yanlislar={
                    ("Çekilen güç: daha az güç çeken pompa daha az enerji harcar; güç "
                     "enerjinin ölçüsüdür"):
                        "Gücü toplam enerji sandın. Güç, saniyede çekilen "
                        "enerjidir; az güç çeken pompa daha uzun çalışırsa "
                        "toplamda daha çok enerji çekebilir.",
                    "Hiçbiri: aynı kuleyi doldurdukları için aynı enerjiyi çekerler":
                        "Suya aktarılan enerji aynı, ama pompanın ÇEKTİĞİ "
                        "enerji verime bağlı. Aradaki fark ısı ve ses olarak "
                        "kaybolur.",
                    ("Dolum süresi: daha kısa sürede dolduran daha az enerji harcar, çünkü "
                     "daha az çalışır"):
                        "Süre tek başına yetmez: enerji = güç × süre. Kısa "
                        "süren bir dolum çok güç çekiyorsa daha çok enerji "
                        "harcayabilir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Pompa çektiği enerjinin ancak bir kısmını suya aktarır; "
                    "bu kısmın oranı verimdir. Kule için aktarılacak enerji "
                    "sabit olduğuna göre çekilen enerji = aktarılacak ÷ verim. "
                    "Güç ise yalnız hızı anlatır: aynı enerjiyi az güçle "
                    "çekmek, uzun sürede çekmek demektir."
                ),
                ipuclari=[
                    "Güç ile enerji arasındaki bağıntı ne? Süre nereye giriyor?",
                    "İki pompa suya aynı enerjiyi aktarıyor. Farkı ne yaratır?",
                ],
                cozum=(
                    "Aktarılan = çekilen × verim\n"
                    "Çekilen = aktarılan ÷ verim\n"
                    "Güç = enerji ÷ süre"
                ),
            ),
            sayi_adimi(
                soru="A pompasının verimi yüzde kaç?",
                cevap=verim_a,
                birim="%",
                aciklama="{} ÷ {} = {} -> %{}.".format(
                    sy(aktarilan_a), sy(guc_a), sy(verim_a / 100.0), verim_a),
                yaygin_yanlislar={
                    round(10000.0 / verim_a):
                        "Bölmeyi ters kurdun ve %100'ü aşan bir verim çıktı. "
                        "Pompa çektiğinden fazla enerjiyi suya veremez; sonuç "
                        "sana bölmenin ters olduğunu söylüyor.",
                    100 - verim_a:
                        "Bu, kaybolan kısmın oranı. Verim, suya GEÇEN kısmın "
                        "oranıdır.",
                },
                ipuclari=["Aktarılan gücü çekilen güce böl, 100 ile çarp."],
                puan=12,
            ),
            sayi_adimi(
                soru="B pompası kuleyi bir kez doldurana kadar şebekeden kaç kJ enerji çeker?",
                cevap=enerji_b,
                birim="kJ",
                aciklama=(
                    "Çekilen = aktarılan ÷ verim = {} ÷ {} = {} kJ. Aynı sonuç "
                    "tezgâh kaydından: {} kW × {} s = {} kJ."
                ).format(is_kj, sy(verim_b / 100.0), enerji_b,
                         sy(guc_b), dk_b * 60, enerji_b),
                yaygin_yanlislar={
                    is_kj:
                        "Suya aktarılan enerjiyi yazdın. Pompa bunun üstüne "
                        "kaybolan enerjiyi de çekiyor.",
                    is_kj * verim_b // 100:
                        "Verimle çarptın. Çekilen enerji aktarılandan BÜYÜK "
                        "olmalı; verime bölünür.",
                    sy(guc_b10 * dk_b / 10.0).replace(",", "."):
                        "Gücü dakikayla çarptın. kW × saniye = kJ; süreyi "
                        "saniyeye çevir.",
                    sy(guc_b).replace(",", "."):
                        "Gücü enerji sandın. {} kW saniyede çekilen enerji; "
                        "toplam enerji için süreyle çarpmak gerekir."
                        .format(sy(guc_b)),
                },
                ipuclari=["Pompa suya aktardığından fazlasını çeker: verime böl."],
                puan=14,
            ),
            yorum_adimi(
                soru=("{} B pompasını öneriyordu. Kuleyi doldurmak için hangisi "
                      "daha az enerji çeker?").format(kisi),
                dogru=("A: A {} kJ, B {} kJ çeker; B düşük verimle daha uzun "
                       "çalışır").format(enerji_a, enerji_b),
                yanlislar={
                    "B: daha az güç çektiği için daha az enerji harcar, sayacı daha yavaş döner":
                        "Gücü toplam enerji sandın. B saniyede az çekiyor ama "
                        "{} dakika çalışıyor; A ise {} dakikada bitiriyor."
                        .format(dk_b, dk_a),
                    "İkisi aynı: ikisi de kuleye aynı enerjiyi aktarıyor; fark yalnız süredir":
                        "Aktarılan aynı, çekilen değil. Verimi düşük olan "
                        "pompa aynı iş için daha çok enerji çeker.",
                    "C: broşüre göre verimi %120, en az enerjiyi o çeker":
                        "Verim %100'ü geçemez: pompa çektiğinden fazla enerjiyi "
                        "suya veremez. Broşürdeki sayı ölçülmüş bir değer değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "A: {} ÷ {} = {} kJ. B: {} ÷ {} = {} kJ. B'nin çektiği güç "
                    "düşük, ama güç yalnız hızı anlatır: B aynı kuleyi {} "
                    "dakikada, A {} dakikada dolduruyor. Toplam enerjiyi süre "
                    "ve verim birlikte belirler."
                ).format(is_kj, sy(verim_a / 100.0), enerji_a,
                         is_kj, sy(verim_b / 100.0), enerji_b, dk_b, dk_a),
                puan=12,
            ),
        ],
        kapanis=("Rapor: A pompası takıldı. Bir dolum için A {} kJ, B {} kJ "
                 "çekiyor; B'nin düşük gücü yalnız işi yavaş yaptığını "
                 "gösteriyordu. %120 verim yazan broşür satıcıya geri gönderildi."
                 ).format(enerji_a, enerji_b),
        odul={"itibar": 5, "erzak": 1, "enerji": 3},
    )


# ==========================================================================
# MEKANİK ENERJİ: SÜRTÜNMEDE ENERJİ YOK OLMAZ (B37.13 -- müfredat haritası)
#
# `mekanik_enerji` haritada DÖRT satırda boştu (2018: 9 ve 11; 2026: 10 ve
# 12). Bağlam: "Rampadaki yükün enerji hesabını kurma". `yaygin_yanlis`:
#
#   "Sürtünmede enerjinin yok olduğunu sanmak; referans yüksekliği
#    değiştirmek."
#
# DÜZENEK: kasa yükleme rampasının tepesinden durgun hâlde bırakılıyor ve
# yerden yüksekteki bir platforma iniyor. Tepenin de platformun da YERDEN
# yüksekliği verilmiş; rampa sonunda hız ölçülmüş.
#
# YANILGILARIN SAYISAL KARŞILIĞI:
#   * referans değiştirmek: tepede yerden yüksekliği, altta platformu sıfır
#     almak -> potansiyel enerji kaybı m·g·h_tepe çıkar (platform yüksekliği
#     kadar fazla); ısı da o kadar şişer. İkisi de ayrı teşhis alır.
#   * enerjinin yok olduğunu sanmak: termal kamera kaydı rampanın ve kasanın
#     ısındığını gösteriyor; yorum adımı "yok oldu" iddiasını sınar.
# ==========================================================================

def _rampa_havuzu():
    """(kutle, h_tepe, h_platform, hiz): kg, m, m, m/s; g = 10 m/s².

    Koşullar:
      1. Isıya dönüşen enerji, potansiyel enerji kaybının %15-%70'i:
         sürtünme ne ihmal edilebilir ne de hareketi durduracak kadar.
      2. Kinetik enerji tam sayı (kütle çift).
      3. Isı sorusunun çeldiricileri ayrışır: referans hatası (Q + m·g·h_p),
         kinetik enerjiyi düşmemek (Q + KE) ve 0 birbirinden ve Q'dan farklı.
    """
    havuz = []
    for kutle in (20, 40, 50, 80, 100):
        for h_tepe in (3, 4, 5, 6):
            for h_platform in (1, 2):
                if h_tepe - h_platform < 2:
                    continue
                kayip = kutle * 10 * (h_tepe - h_platform)
                for hiz in (2, 4, 5, 6, 8):
                    kinetik = kutle * hiz * hiz // 2
                    isi = kayip - kinetik
                    if not 0.15 * kayip <= isi <= 0.70 * kayip:
                        continue
                    referans_hatasi = isi + kutle * 10 * h_platform
                    if len({isi, referans_hatasi, kayip, 0}) < 4:
                        continue
                    havuz.append((kutle, h_tepe, h_platform, hiz))
    return tuple(havuz)


_RAMPA = _rampa_havuzu()


@bulmaca(ders="fizik", konu="mekanik_enerji", kademeler=(9, 13), agirlik=1.3)
def rampa_yuku(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sürtünmede mekanik enerji ısıya dönüşür; referans hesap boyunca aynı kalır."""
    kutle, h_tepe, h_platform, hiz = rastgele.choice(_RAMPA)
    dusus = h_tepe - h_platform
    kayip = kutle * 10 * dusus
    kinetik = kutle * hiz * hiz // 2
    isi = kayip - kinetik
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-rampa-yuku",
        ders="fizik",
        baslik="Rampa Yükü",
        kademe=kademe,
        konu="mekanik_enerji",
        kazanim="Sürtünmeli harekette enerji korunumunu kurma; potansiyel enerji "
                "değişimini tek referansla hesaplama; mekanik enerji kaybının ısıya "
                "dönüştüğünü açıklama.",
        dikkat=7,
        brifing=(
            "Depo, ağır kasaları yükleme rampasından alttaki platforma "
            "kaydırıyor. Rampanın yüzeyi eskidi ve kasalar beklenenden yavaş "
            "iniyor.\n\n"
            "{} rapor yazdı: \"Rampa sürtünmesi her inişte kasanın enerjisinin "
            "bir kısmını yok ediyor. Bu enerji boşa gidiyor ve geri gelmiyor.\"\n\n"
            "Rampa yenilenmeden önce inişte enerjinin nereye gittiğini "
            "hesaplamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Rampa ölçümleri",
                  "Rampanın tepesi yerden {} m yüksekte. Alttaki platform yerden "
                  "{} m yüksekte.".format(h_tepe, h_platform),
                  bedel=1, kritik=True),
            Kanit("Deneme inişi",
                  "Kasa: {} kg. Tepeden durgun hâlde bırakıldı; rampanın sonunda "
                  "hızı {} m/s ölçüldü. g = 10 m/s².".format(kutle, hiz),
                  bedel=1, kritik=True),
            Kanit("Termal kamera kaydı",
                  "İnişten hemen sonra rampa yüzeyi ve kasanın tabanı, çevreden "
                  "birkaç derece sıcak görünüyor.",
                  bedel=1, kritik=True),
            Kanit("Bağıntı notu",
                  "Potansiyel enerji: m · g · h. Kinetik enerji: ½ · m · v².",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kasanın inişi için enerji hesabını hangi ifade doğru kurar?",
                dogru=("Tek referans seçilir; potansiyel enerji kaybı = son kinetik "
                       "enerji + ısı"),
                yanlislar={
                    ("Sürtünme olduğu için enerji korunmaz; eksilen kısım yok olur, bu "
                     "yüzden kasa yavaşlar"):
                        "Sürtünmede enerjinin yok olduğunu sandın. Enerji yok "
                        "olmaz, biçim değiştirir; termal kamera kaydı nereye "
                        "gittiğini gösteriyor.",
                    "Tepede yerden yükseklik, altta platform sıfır alınır; fark potansiyel enerjiyi verir":
                        "Referans yüksekliğini hesabın ortasında değiştirdin. "
                        "Tepeyi yerden ölçtüysen platformu da yerden ölçmelisin.",
                    "Potansiyel enerji kaybının tamamı kinetik enerjiye dönüşür":
                        "Bu yalnız sürtünmesiz bir rampada doğru olurdu. Ölçülen "
                        "hız, kaybın tamamının harekete geçmediğini gösteriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Referans istenen yere konabilir, ama bütün hesap boyunca AYNI "
                    "kalmalıdır; o zaman potansiyel enerji değişimi referanstan "
                    "bağımsız çıkar. Sürtünmeli inişte kaybedilen potansiyel "
                    "enerjinin bir kısmı harekete, kalanı ısıya dönüşür. Toplam "
                    "enerji korunur."
                ),
                ipuclari=[
                    "Tepe ve platform yükseklikleri hangi seviyeden ölçülmüş?",
                    "Termal kamera kaydı sana ne söylüyor?",
                ],
                cozum=(
                    "ΔEp = m · g · (h_tepe − h_platform)\n"
                    "Ek = ½ · m · v²\n"
                    "Isı = ΔEp − Ek"
                ),
            ),
            sayi_adimi(
                soru="İnişte kasanın potansiyel enerjisi kaç J azaldı?",
                cevap=kayip,
                birim="J",
                aciklama="{} kg × 10 m/s² × ({} m − {} m) = {} J.".format(
                    kutle, h_tepe, h_platform, kayip),
                yaygin_yanlislar={
                    kutle * 10 * h_tepe:
                        "Referansı değiştirdin: tepeyi yerden ölçüp platformu "
                        "sıfır saydın. Kasa yere değil, yerden {} m yüksekteki "
                        "platforma iniyor.".format(h_platform),
                    kutle * dusus:
                        "g'yi unuttun: m · g · h.",
                },
                ipuclari=["Kasa yere kadar mı iniyor, yoksa platforma kadar mı?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Rampanın sonunda kasanın kinetik enerjisi kaç J?",
                cevap=kinetik,
                birim="J",
                aciklama="½ × {} kg × ({} m/s)² = {} J.".format(kutle, hiz, kinetik),
                yaygin_yanlislar={
                    kutle * hiz * hiz: "½ çarpanını unuttun.",
                    kutle * hiz // 2: "Hızın karesini almadın.",
                },
                ipuclari=["Hızın karesini almayı unutma."],
                puan=10,
            ),
            sayi_adimi(
                soru="İnişte sürtünmeyle kaç J enerji ısıya dönüştü?",
                cevap=isi,
                birim="J",
                aciklama=("Isı = potansiyel enerji kaybı − kinetik enerji = {} − {} = "
                          "{} J.").format(kayip, kinetik, isi),
                yaygin_yanlislar={
                    isi + kutle * 10 * h_platform:
                        "Potansiyel enerji kaybını yanlış referansla (platformu "
                        "sıfır sayarak) aldın; ısı, platform yüksekliği kadar "
                        "şişti.",
                    kayip:
                        "Kinetik enerjiyi düşmedin. Kaybın bir kısmı kasayı "
                        "hareket ettiriyor.",
                    0:
                        "Sürtünmenin enerjiyi yok ettiğini, bir yere gitmediğini "
                        "düşündün. Termal kamera ısınmayı gösteriyor.",
                },
                ipuclari=["Kaybedilen potansiyel enerjinin harekete geçmeyen kısmını bul."],
                puan=14,
            ),
            yorum_adimi(
                soru="Rapordaki \"sürtünme enerjiyi yok ediyor\" cümlesi doğru mu?",
                dogru=("Hayır: {} J yok olmadı, ısıya dönüştü; rampa ve kasa ısındı, "
                       "enerji korundu").format(isi),
                yanlislar={
                    "Evet: sürtünme mekanik enerjiyi yok eder, bu yüzden kasa yavaşlıyor":
                        "Sürtünmede enerjinin yok olduğunu sandın. Mekanik enerji "
                        "azalıyor ama yok olmuyor; termal kamera, eksilen {} J "
                        "enerjinin ısıya gittiğini doğruluyor.".format(isi),
                    ("Hayır: hiç enerji kaybı yok; ölçülen hız hatalı, çünkü enerji her "
                     "zaman korunur"):
                        "Kayıp gerçek: potansiyel enerji kaybı kinetik enerjiden "
                        "büyük ve rampa ısınmış. Ölçümü yok saymak için bir sebep "
                        "yok.",
                    "Hayır: eksilen enerji kasada potansiyel enerji olarak depolandı":
                        "Kasa platformda durduğunda yüksekliği azalmış; potansiyel "
                        "enerjisi artmamış, azalmış. Eksilen enerji ısıya gitti.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Mekanik enerji {} J azaldı, ama {} J hareket olarak kasada, "
                    "{} J ısı olarak rampada ve kasada. Enerji yok olmadı. Rampa "
                    "yenilenirse ısıya giden kısım azalır ve kasalar platforma "
                    "daha hızlı iner."
                ).format(kayip, kinetik, isi),
                puan=12,
            ),
        ],
        kapanis=("Rapor düzeltildi: her inişte {} J mekanik enerji kayboluyor; bunun "
                 "{} J kadarı harekete, {} J kadarı ısıya dönüşüyor. \"Yok oluyor\" ifadesi "
                 "silindi, rampa yenileme listesine alındı."
                 ).format(kayip, kinetik, isi),
        odul={"itibar": 5, "erzak": 1, "enerji": 2},
    )


# ==========================================================================
# MOMENTUM: KENETLENEN ARABALARDA KİNETİK ENERJİ KORUNMAZ
# (B37.13 -- müfredat haritası)
#
# `momentum` iki satırda boştu (2018: 11; 2026: 12). Bağlam: "Ray üzerindeki
# iki yük arabasının etkileşimini inceleme". `yaygin_yanlis`:
#
#   "Her çarpışmada kinetik enerjinin de korunduğunu sanmak."
#
# DÜZENEK: hareketli A arabası duran B arabasına çarpıp kenetleniyor
# (tamamen esnek olmayan çarpışma). Momentum korunur, kinetik enerjinin bir
# kısmı tamponu ezer, ısıya ve sese gider.
#
# YANILGININ SAYISAL KARŞILIĞI: kinetik enerjiyi korunmuş sayan öğrenci
# ortak hızı v_A · √(m_A / (m_A + m_B)) bulur. Havuz kütle oranını TAM KARE
# seçiyor (m_A / toplam = p² / q²), böylece bu yanlış hız da temiz bir sayı
# çıkıyor ve kendi teşhisini alıyor: v_KE = v_A · p/q, doğrusu v_A · p²/q².
# ==========================================================================

_KARE_ORANLAR = ((1, 2), (1, 3), (2, 3), (3, 4), (3, 5), (4, 5))


def _carpisma_havuzu():
    """(p, q, m_a, v_a): m_a kg, v_a m/s; m_b = m_a · (q² − p²) / p².

    Koşullar:
      1. m_b 10'un katı ve en çok 2000 kg.
      2. Doğru ortak hız ile kinetik enerjiyi koruyan (yanlış) hız tek
         ondalıklı; doğru hız en az 0,5 m/s.
      3. Önceki ve sonraki kinetik enerji TAM SAYI (kayıp da öyle).
    """
    havuz = []
    for p, q in _KARE_ORANLAR:
        for m_a in range(100, 1100, 100):
            if (m_a * (q * q - p * p)) % (p * p):
                continue
            m_b = m_a * (q * q - p * p) // (p * p)
            if m_b % 10 or m_b > 2000:
                continue
            for v_a in range(2, 11):
                if (10 * v_a * p * p) % (q * q) or (10 * v_a * p) % q:
                    continue
                if 2 * v_a * p * p < q * q:          # doğru hız < 0,5 m/s
                    continue
                # sonraki KE = (m_a + m_b) · (v_a p²/q²)² / 2
                pay = (m_a + m_b) * (v_a * p * p) ** 2
                if pay % (2 * q ** 4) or (m_a * v_a * v_a) % 2:
                    continue
                havuz.append((p, q, m_a, v_a))
    return tuple(havuz)


_CARPISMA = _carpisma_havuzu()


@bulmaca(ders="fizik", konu="momentum", kademeler=(11, 13), agirlik=1.3)
def ray_arabalari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Kenetlenen çarpışmada momentum korunur, kinetik enerji korunmaz."""
    oran = rastgele.choice(sorted({(p, q) for p, q, _, _ in _CARPISMA}))
    p, q, m_a, v_a = rastgele.choice([h for h in _CARPISMA if h[:2] == oran])
    m_b = m_a * (q * q - p * p) // (p * p)
    toplam = m_a + m_b
    v_ortak = v_a * p * p / float(q * q)
    v_yanlis = v_a * p / float(q)
    ke_once = m_a * v_a * v_a // 2
    ke_sonra = (toplam * (v_a * p * p) ** 2) // (2 * q ** 4)
    kayip = ke_once - ke_sonra
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    hiz_yanlislari = {
        sy(v_yanlis).replace(",", "."):
            "Kinetik enerjinin korunduğunu varsaydın. Kenetlenen arabalarda "
            "korunan momentumdur; kinetik enerjinin bir kısmı tamponda ısıya "
            "ve sese gider.",
        v_a:
            "Hızın korunduğunu varsaydın. Aynı momentum artık daha büyük bir "
            "kütleye dağılıyor; hız düşmeli.",
    }
    if (10 * m_a * v_a) % m_b == 0:
        yalniz_b = m_a * v_a / float(m_b)
        if yalniz_b not in (v_ortak, v_yanlis, v_a):
            hiz_yanlislari[sy(yalniz_b).replace(",", ".")] = (
                "Momentumu yalnız B arabasının kütlesine böldün. Kenetlendikten "
                "sonra İKİ araba birlikte hareket ediyor.")

    return Bulmaca(
        kod="fiz-ray-arabalari",
        ders="fizik",
        baslik="Ray Arabaları",
        kademe=kademe,
        konu="momentum",
        kazanim="Esnek olmayan çarpışmada momentum korunumunu kullanma; kinetik "
                "enerjinin korunmadığını hesapla gösterme.",
        dikkat=7,
        brifing=(
            "Maden rayında hareket eden bir yük arabası, rayda bekleyen başka "
            "bir arabaya çarptı ve ikisi kenetlenip birlikte ilerledi.\n\n"
            "{} kenetlenme sonrası hızı kinetik enerjinin korunduğunu varsayarak "
            "hesapladı. Raydaki hız ölçer ise daha düşük bir değer gösterdi. "
            "Hesabı yapan \"hız ölçer bozuk\" diyor ve cihazın değiştirilmesini "
            "istiyor.\n\n"
            "Cihaz sipariş edilmeden önce hangisinin haklı olduğunu bulmamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Ray kaydı",
                  "A arabası: {} kg, {} m/s hızla ilerliyordu.\n"
                  "B arabası: {} kg, rayda duruyordu.".format(m_a, v_a, m_b),
                  bedel=1, kritik=True),
            Kanit("Kenetlenme kaydı",
                  "Çarpışmada otomatik kilit devreye girdi; iki araba çarpışmadan "
                  "sonra birlikte hareket etti. Rayın sürtünmesi bu kısa sürede "
                  "ihmal edilebilir.",
                  bedel=1, kritik=True),
            Kanit("Tampon muayenesi",
                  "Kenetlenme tamponu ezilmiş, kilit mekanizması ısınmış. "
                  "Çarpışma anında yüksek bir ses duyulmuş.",
                  bedel=1),
            Kanit("Bağıntı notu",
                  "Momentum: m · v. Kinetik enerji: ½ · m · v².",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kenetlenen iki arabanın çarpışmasında hangisi korunur?",
                dogru=("Toplam momentum korunur; kinetik enerjinin bir kısmı ısıya ve "
                       "sese gider"),
                yanlislar={
                    ("Hem momentum hem kinetik enerji korunur, çünkü enerji yoktan var "
                     "olmaz, yok da olmaz"):
                        "Her çarpışmada kinetik enerjinin de korunduğunu sandın. "
                        "Bu yalnız esnek çarpışmada olur; ezilen tampon ve duyulan "
                        "ses enerjinin bir kısmının başka biçime geçtiğini gösteriyor.",
                    "Yalnız kinetik enerji korunur; momentum çarpışmada kaybolur":
                        "Tersi: dış kuvvet ihmal edilebilirken momentum HER "
                        "çarpışmada korunur. Kinetik enerji ise yalnız esnek "
                        "çarpışmada korunur.",
                    ("Hiçbiri korunmaz; çarpışmada hareketin bir kısmı kaybolur, arabalar "
                     "yavaşlar"):
                        "Momentum korunur: arabalara dışarıdan yatay bir kuvvet "
                        "etki etmiyor. Kaybolan yalnız kinetik enerjinin bir kısmı, "
                        "o da yok olmuyor, biçim değiştiriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çarpışma sırasında arabalar birbirine eşit ve zıt kuvvet "
                    "uygular; dış kuvvet ihmal edilebildiği için toplam momentum "
                    "korunur. Kinetik enerji için böyle bir güvence yok: "
                    "kenetlenen arabalarda bir kısmı tamponu ezmeye, ısıya ve "
                    "sese harcanır."
                ),
                ipuclari=[
                    "Arabalara dışarıdan yatay bir kuvvet etki ediyor mu?",
                    "Tampon muayenesi enerjinin bir kısmı için ne söylüyor?",
                ],
                cozum=(
                    "m_A · v_A + 0 = (m_A + m_B) · v\n"
                    "v = m_A · v_A ÷ (m_A + m_B)"
                ),
            ),
            sayi_adimi(
                soru="Kenetlenmeden sonra arabaların ortak hızı kaç m/s?",
                cevap=v_ortak,
                birim="m/s",
                aciklama="v = {} kg × {} m/s ÷ ({} kg + {} kg) = {} m/s.".format(
                    m_a, v_a, m_a, m_b, sy(v_ortak)),
                yaygin_yanlislar=hiz_yanlislari,
                ipuclari=["Önceki toplam momentumu, kenetlenmiş iki arabanın toplam kütlesine böl."],
                puan=14,
            ),
            sayi_adimi(
                soru="Çarpışmada kaç J kinetik enerji başka biçimlere dönüştü?",
                cevap=kayip,
                birim="J",
                aciklama=(
                    "Önce: ½ × {} × {}² = {} J. Sonra: ½ × {} × {}² = {} J. "
                    "Fark: {} J."
                ).format(m_a, v_a, ke_once, toplam, sy(v_ortak), ke_sonra, kayip),
                yaygin_yanlislar={
                    0:
                        "Kinetik enerjinin korunduğunu varsaydın. Sonraki kinetik "
                        "enerjiyi ortak hızla hesapla; öncekinden küçük çıkacak.",
                    ke_once:
                        "Önceki kinetik enerjinin tamamını yazdın; arabalar "
                        "durmadı, bir kısmı hâlâ hareket olarak duruyor.",
                    ke_sonra:
                        "Çarpışmadan SONRA kalan kinetik enerjiyi yazdın; soru "
                        "başka biçime geçen farkı soruyor.",
                },
                ipuclari=["Çarpışmadan önceki ve sonraki kinetik enerjiyi ayrı ayrı hesapla."],
                puan=14,
            ),
            yorum_adimi(
                soru="Hız ölçer mi bozuk, yoksa hesap mı yanlış?",
                dogru=("Hesap yanlış: kenetlenmede kinetik enerji korunmaz; {} J ısıya "
                       "ve sese gitti").format(kayip),
                yanlislar={
                    ("Hız ölçer bozuk: kinetik enerji her çarpışmada korunur; hesap bunu "
                     "doğru kullandı"):
                        "Her çarpışmada kinetik enerjinin de korunduğunu sandın. "
                        "Ezilen tampon ve ısınan kilit bunun tersini gösteriyor.",
                    "Hesap yanlış: momentum da korunmaz, hız ölçer ne gösterirse o doğrudur":
                        "Hesabın yanlış olduğu doğru, ama momentum korunur -- doğru "
                        "hızı zaten momentumdan bulduk ve hız ölçerle tutuyor.",
                    ("İkisi de doğru: kenetlenmeden sonra hız zamanla düşer, ölçüm biraz geç "
                     "alınmıştır"):
                        "Kenetlenme kaydına göre sürtünme bu kısa sürede ihmal "
                        "edilebilir; hız kenetlenme ANINDA düştü, zamanla değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Momentum korunumu {} m/s veriyor; kinetik enerjiyi korumak "
                    "{} m/s verirdi. Aradaki fark çarpışmada {} J enerjinin tampon "
                    "ve kilitte başka biçime geçmesi. Hız ölçer sağlam; sipariş "
                    "iptal edilmeli."
                ).format(sy(v_ortak), sy(v_yanlis), kayip),
                puan=12,
            ),
        ],
        kapanis=("Rapor: hız ölçer sağlam, sipariş iptal. Kenetlenme sonrası hız "
                 "{} m/s; çarpışmada {} J kinetik enerji tamponda ısıya, sese ve "
                 "ezilmeye gitti.").format(sy(v_ortak), kayip),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# İŞ, ENERJİ VE GÜÇ: KUVVET HER ZAMAN İŞ YAPMAZ (B37.13 -- müfredat haritası)
#
# `is_enerji_guc` iki satırda boştu (2018: 9; 2026: 10). Bağlam: "Bir yük
# kaldırma işleminin enerji ve süresini karşılaştırma". `yaygin_yanlis`:
#
#   "Kuvvet uygulanan her durumda iş yapıldığını sanmak; enerjiyle gücü
#    karıştırmak."
#
# İKİ İDDİA, İKİ YANILGI:
#   * nöbetçi sinyal kasasını dakikalarca aynı yükseklikte tuttu ve "en çok
#     işi ben yaptım" diyor -> kasa yer değiştirmedi, kasaya yapılan iş 0.
#     Kuvvet × süre ayrı bir teşhis alır.
#   * iki vinç aynı yükü aynı yüksekliğe kaldırıyor, biri daha hızlı ->
#     İŞ AYNI, güç farklı. "Hızlı olan daha çok iş yapar" yorumda sınanır;
#     güç sorusunda işi yazmak ayrı teşhis alır.
# ==========================================================================

def _vinc_havuzu():
    """(kutle, yukseklik, sure_a, sure_b): kg, m, s, s; g = 10 m/s².

    Koşullar:
      1. İki gücün de TAM SAYI; B daha hızlı (en az 1,5 kat).
      2. sure_a listesinde 10 YOK: olsaydı "g'yi unutmak" (m·h) ile "gücü iş sanmak"
         (iş ÷ sure_a) aynı sayıya düşer.
      3. Güç en çok 5000 W.
    """
    havuz = []
    for kutle in (50, 80, 100, 120, 200, 250):
        for yukseklik in (2, 3, 4, 5, 6, 8, 10):
            is_j = kutle * 10 * yukseklik
            for sure_a in (8, 12, 15, 20, 25, 30, 40):
                for sure_b in (4, 5, 6, 8, 10, 12, 15, 20):
                    if 2 * sure_a < 3 * sure_b:
                        continue
                    if is_j % sure_a or is_j % sure_b:
                        continue
                    if is_j // sure_b > 5000:
                        continue
                    havuz.append((kutle, yukseklik, sure_a, sure_b))
    return tuple(havuz)


_VINC = _vinc_havuzu()


@bulmaca(ders="fizik", konu="is_enerji_guc", kademeler=(9, 13), agirlik=1.3)
def vinc_karsilastirma(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yer değiştirmeyen yüke iş yapılmaz; aynı işi kısa sürede yapan daha güçlüdür."""
    kutle, yukseklik, sure_a, sure_b = rastgele.choice(_VINC)
    is_j = kutle * 10 * yukseklik
    guc_a, guc_b = is_j // sure_a, is_j // sure_b
    kasa = rastgele.choice((10, 15, 20))
    tutma = rastgele.choice((60, 90, 120))
    kisi, nobetci = ad_sec(rastgele, PERSONEL, 2)

    return Bulmaca(
        kod="fiz-vinc-karsilastirma",
        ders="fizik",
        baslik="Vinç Karşılaştırması",
        kademe=kademe,
        konu="is_enerji_guc",
        kazanim="İşin kuvvet doğrultusunda yer değiştirme gerektirdiğini açıklama; "
                "iş ve gücü hesaplayıp aynı işi farklı sürede yapan sistemleri "
                "karşılaştırma.",
        dikkat=7,
        brifing=(
            "Depoda iki vinç var ve biri başka bir üsse gönderilecek.\n\n"
            "{} B vincini tutmak istiyor: \"B yükü daha kısa sürede kaldırıyor; "
            "demek ki daha çok iş yapıyor ve daha çok enerji veriyor.\"\n\n"
            "{} de söz aldı: \"Bugün sinyal kasasını dakikalarca havada tuttum. "
            "Kollarım koptu; en çok işi ben yaptım.\"\n\n"
            "Karar vermeden önce kimin ne kadar iş yaptığını bulmamız gerekiyor."
        ).format(kisi, nobetci),
        kanitlar=[
            Kanit("Vinç kayıtları",
                  "İki vinç de aynı {} kg yükü aynı {} m yüksekliğe kaldırdı.\n"
                  "Vinç A: {} saniye.\nVinç B: {} saniye."
                  .format(kutle, yukseklik, sure_a, sure_b),
                  bedel=1, kritik=True),
            Kanit("Nöbet kaydı",
                  "{} kütlesi {} kg olan sinyal kasasını {} saniye boyunca aynı "
                  "yükseklikte tuttu. Kasa bu sürede hiç yer değiştirmedi."
                  .format(nobetci, kasa, tutma),
                  bedel=1, kritik=True),
            Kanit("Bağıntı notu",
                  "İş = kuvvet × kuvvet doğrultusunda alınan yol.\n"
                  "Güç = iş ÷ süre.\nAğırlık = m · g, g = 10 m/s².",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir kuvvet bir cisim üzerinde ne zaman iş yapar?",
                dogru=("Cisim kuvvet doğrultusunda yer değiştirdiğinde: iş = kuvvet "
                       "× o yöndeki yol"),
                yanlislar={
                    "Kuvvet uygulandığı her durumda; kuvveti uygulayan yoruluyorsa iş yapılmıştır":
                        "Kuvvet uygulanan her durumda iş yapıldığını sandın. "
                        "Yorulmak kasların içinde enerji harcandığını gösterir; "
                        "cisme iş yapılması için cismin yer değiştirmesi gerekir.",
                    ("Kuvvet ne kadar uzun süre uygulanırsa o kadar çok iş yapılır, iş "
                     "zamanla birikir"):
                        "Süre işin tanımına girmez. Süre, işin ne kadar HIZLI "
                        "yapıldığını, yani gücü belirler.",
                    "Yalnız cisim hızlandığında; sabit hızla kaldırılan yüke iş yapılmaz":
                        "Sabit hızla kaldırılan yük de kuvvet doğrultusunda "
                        "yükseliyor; kuvvet iş yapıyor ve yükün potansiyel "
                        "enerjisi artıyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İş, kuvvetin cismi kendi doğrultusunda ne kadar yol aldırdığıyla "
                    "ölçülür. Havada tutulan kasa yer değiştirmiyorsa kasaya iş "
                    "yapılmaz -- tutan kişi yorulsa bile. Süre işe değil, güce girer."
                ),
                ipuclari=[
                    "Kasa tutulurken nereye gitti?",
                    "İşin tanımında süre var mı?",
                ],
                cozum=(
                    "İş = F × d (d: kuvvet doğrultusundaki yol)\n"
                    "d = 0 ise iş = 0\n"
                    "Güç = iş ÷ süre"
                ),
            ),
            sayi_adimi(
                soru="Nöbetçinin kasayı havada tutarken kasaya yaptığı iş kaç J?",
                cevap=0,
                birim="J",
                aciklama=(
                    "Kasa yer değiştirmedi: yol 0, iş = {} N × 0 m = 0 J. Kollar "
                    "yoruldu çünkü kaslar kasılı kalmak için enerji harcıyor; bu "
                    "enerji kasaya aktarılmıyor, vücutta ısıya dönüşüyor."
                ).format(kasa * 10),
                yaygin_yanlislar={
                    kasa * 10 * tutma:
                        "Kuvveti süreyle çarptın. İş kuvvet × YOL; süre işin "
                        "tanımına girmez.",
                    kasa * 10:
                        "Kasanın ağırlığını yazdın. Kuvvet vardı, ama iş için "
                        "yer değiştirme de gerekir.",
                },
                ipuclari=["Nöbet kaydına göre kasa kaç metre yer değiştirdi?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Vinç A yükü kaldırırken yüke kaç J iş yaptı?",
                cevap=is_j,
                birim="J",
                aciklama="{} kg × 10 m/s² × {} m = {} J.".format(kutle, yukseklik, is_j),
                yaygin_yanlislar={
                    kutle * yukseklik:
                        "Kütleyi kuvvet gibi kullandın; ağırlık m · g.",
                    guc_a:
                        "İşi süreye böldün; bu gücü verir. Soru işi soruyor.",
                },
                ipuclari=["Önce yükün ağırlığını bul."],
                puan=12,
            ),
            sayi_adimi(
                soru="Vinç B'nin gücü kaç W?",
                cevap=guc_b,
                birim="W",
                aciklama="{} J ÷ {} s = {} W. (Vinç A: {} J ÷ {} s = {} W.)".format(
                    is_j, sure_b, guc_b, is_j, sure_a, guc_a),
                yaygin_yanlislar={
                    is_j:
                        "İşi yazdın; enerjiyle gücü karıştırdın. Güç, işin ne kadar "
                        "sürede yapıldığını da hesaba katar.",
                    guc_a:
                        "Vinç A'nın süresini kullandın. B'nin kaydına bak.",
                },
                ipuclari=["İki vinç aynı işi yaptı; farklı olan ne?"],
                puan=12,
            ),
            yorum_adimi(
                soru="Hangi yorum doğru?",
                dogru=("İki vinç de aynı işi yaptı ({} J), B daha güçlü; nöbetçi "
                       "kasaya iş yapmadı").format(is_j),
                yanlislar={
                    ("B daha hızlı olduğu için daha çok iş yaptı; en çok işi kasayı uzun "
                     "süre tutan nöbetçi yaptı"):
                        "Enerjiyle gücü karıştırdın ve kuvvet uygulanan her durumda "
                        "iş yapıldığını sandın. İş aynı, güç farklı; nöbetçinin "
                        "kasaya yaptığı iş 0.",
                    "A daha çok iş yaptı, çünkü daha uzun çalıştı ve iş süreyle birikir":
                        "Süre işin tanımına girmez. Aynı yük aynı yüksekliğe "
                        "çıktı; iş aynı.",
                    ("B daha çok iş yaptı, çünkü işi daha hızlı bitirdi; nöbetçi kasaya "
                     "iş yapmadı"):
                        "Nöbetçi konusunda haklısın, ama vinçlerin işi aynı. "
                        "B'nin üstünlüğü iş değil, güç.",
                },
                rastgele=rastgele,
                aciklama=(
                    "İş yükün ağırlığına ve çıktığı yüksekliğe bağlı: ikisi de "
                    "aynı, iş aynı ({} J). Güç süreye bağlı: A {} W, B {} W. "
                    "Vinç seçimi bir iş farkına değil, hız ihtiyacına göre "
                    "yapılmalı."
                ).format(is_j, guc_a, guc_b),
                puan=12,
            ),
        ],
        kapanis=("Rapor: iki vinç de yüke {} J iş yapıyor; B'nin gücü {} W, A'nın {} W. "
                 "Nöbetçinin kasaya yaptığı iş 0 J -- kolları yorulsa da kasa yer "
                 "değiştirmedi.").format(is_j, guc_b, guc_a),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# KUVVET VE NEWTON YASALARI (B37.13 -- müfredat haritası)
#
# `kuvvet_newton` ÜÇ satırda boştu (2018: 9, 11; 2026: 11). Bağlam: "Yük
# arabasına etki eden kuvvetleri belirleme". `yaygin_yanlis`:
#
#   "Hareket sürüyorsa net kuvvet vardır sanmak; etki-tepkiyi aynı cisimde
#    aramak."
#
# İKİ YANILGI TEK DÜZENEKTE BİRBİRİNİ BESLİYOR: araba sabit hızla itilirken
# sürtünme itmeye EŞİT ve ZIT. Bu eşitlik öğrenciyi "itmenin tepkisi
# sürtünmedir" demeye çekiyor -- oysa ikisi de ARABAYA etki ediyor; eşitlik
# Newton'un üçüncü değil birinci yasasından (net kuvvet sıfır).
#
# SAYISAL KARŞILIKLAR:
#   * sabit hızda net kuvvete itme kuvvetini yazmak (doğrusu 0);
#   * hızlanma evresinde sürtünmeyi unutup a = F / m bulmak.
# ==========================================================================

def _araba_havuzu():
    """(kutle, itme_sabit, ivme): kg, N, m/s² × 10 (tam sayı saklanır).

    Koşullar:
      1. İkinci evrenin itme kuvveti (F₁ + m·a) TAM SAYI.
      2. "Sürtünmeyi unutmak" (F₂ / m) en çok iki ondalık -- yazılabilir.
      3. Ağırlık (m·g) itme kuvvetinden farklı: net kuvvet sorusunun iki
         çeldiricisi çakışmasın.
    """
    havuz = []
    for kutle in (40, 50, 60, 80, 100, 120):
        for itme in (40, 60, 80, 90, 120):
            for ivme10 in (5, 10, 15, 20):
                if (kutle * ivme10) % 10:
                    continue
                itme2 = itme + kutle * ivme10 // 10
                if (itme2 * 100) % kutle:
                    continue
                if kutle * 10 == itme:
                    continue
                havuz.append((kutle, itme, ivme10))
    return tuple(havuz)


_ARABA = _araba_havuzu()


@bulmaca(ders="fizik", konu="kuvvet_newton", kademeler=(9, 13), agirlik=1.3)
def yuk_arabasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sabit hızda net kuvvet sıfır; etki-tepki çifti farklı cisimlere etki eder."""
    kutle, itme, ivme10 = rastgele.choice(_ARABA)
    ivme = ivme10 / 10.0
    itme2 = itme + kutle * ivme10 // 10
    hiz = rastgele.choice((0.8, 1.2, 1.5))
    kisi, isci = ad_sec(rastgele, PERSONEL, 2)

    return Bulmaca(
        kod="fiz-yuk-arabasi",
        ders="fizik",
        baslik="Yük Arabası",
        kademe=kademe,
        konu="kuvvet_newton",
        kazanim="Sabit hızla hareket eden cisimde net kuvvetin sıfır olduğunu "
                "açıklama; Newton'un ikinci yasasıyla ivme hesaplama; etki-tepki "
                "kuvvetlerinin farklı cisimlere etki ettiğini ayırt etme.",
        dikkat=7,
        brifing=(
            "{} dolu yük arabasını düz ve yatay depo koridorunda itiyor. Bakım "
            "ekibi arabanın koluna bir dinamometre taktı.\n\n"
            "{} ölçümlere bakıp not düştü: \"Araba hareket ettiğine göre itme "
            "kuvveti sürtünmeden büyük olmalı. Zaten itmenin tepki kuvveti de "
            "sürtünme.\"\n\n"
            "Koridora motorlu çekici alınmadan önce arabaya hangi kuvvetlerin "
            "etki ettiğini doğru belirlememiz gerekiyor."
        ).format(isci, kisi),
        kanitlar=[
            Kanit("Birinci ölçüm",
                  "Araba: {} kg.\nHız kaydı -- 0-2 s: {} m/s; 2-4 s: {} m/s; "
                  "4-6 s: {} m/s.\nBu sürede kol dinamometresi {} N gösterdi."
                  .format(kutle, sy(hiz), sy(hiz), sy(hiz), itme),
                  bedel=1, kritik=True),
            Kanit("İkinci ölçüm",
                  "{} itmeyi artırdı; dinamometre {} N gösterirken araba "
                  "hızlanmaya başladı. Zemin ve yük aynı; sürtünme kuvveti "
                  "birinci ölçümdekiyle aynı büyüklükte.".format(isci, itme2),
                  bedel=1, kritik=True),
            Kanit("Yasalar notu",
                  "Net kuvvet = kütle × ivme.\n"
                  "Bir cisim ötekine kuvvet uygularsa, öteki de ona eşit "
                  "büyüklükte ve zıt yönde bir kuvvet uygular.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Araba sabit hızla giderken arabaya etki eden net kuvvet için hangisi doğru?",
                dogru=("Net kuvvet sıfırdır: itme sürtünmeyi dengeler; sabit hız için "
                       "net kuvvet gerekmez"),
                yanlislar={
                    ("Net kuvvet itme yönündedir; hareket sürdüğüne göre bir net kuvvet "
                     "olmalı, yoksa araba dururdu"):
                        "Hareket sürüyorsa net kuvvet vardır sandın. Net kuvvet "
                        "hızı DEĞİŞTİRİR; hız kaydı hiç değişmiyor.",
                    "Net kuvvet sürtünme yönündedir; araba sürekli yavaşlamaya çalışır":
                        "Net kuvvet sürtünme yönünde olsaydı araba yavaşlardı; hız "
                        "kaydı sabit.",
                    "Net kuvvet itme kuvvetine eşittir; sürtünme hareket varken etki etmez":
                        "Sürtünme hareket varken de etki eder; kolu bırakan işçi "
                        "arabanın durduğunu görür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Newton'un birinci yasası: net kuvvet sıfırsa cisim durur ya da "
                    "SABİT hızla gider. Net kuvvet hareketi sürdürmek için değil, "
                    "hızı değiştirmek için gerekir."
                ),
                ipuclari=[
                    "Hız kaydı zamanla değişiyor mu?",
                    "Net kuvvet neyi değiştirir: hızı mı, konumu mu?",
                ],
                cozum=(
                    "Hız sabit -> ivme 0\n"
                    "Net kuvvet = m × 0 = 0\n"
                    "İtme = sürtünme (büyüklükçe)"
                ),
            ),
            sayi_adimi(
                soru="Birinci ölçümde arabaya etki eden net kuvvet kaç N?",
                cevap=0,
                birim="N",
                aciklama=("Hız sabit, ivme 0: net kuvvet = {} kg × 0 = 0 N. Kol "
                          "{} N itiyor, sürtünme de {} N geriye çekiyor."
                          ).format(kutle, itme, itme),
                yaygin_yanlislar={
                    itme:
                        "İtme kuvvetini net kuvvet saydın; hareket sürdüğü için "
                        "net kuvvet olmalı sandın. Sürtünme itmeyi dengeliyor.",
                    kutle * 10:
                        "Arabanın ağırlığını yazdın. Ağırlık düşey; yatay net "
                        "kuvveti hız kaydı belirliyor.",
                },
                ipuclari=["Hız değişmiyorsa ivme kaç?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Arabaya etki eden sürtünme kuvvetinin büyüklüğü kaç N?",
                cevap=itme,
                birim="N",
                aciklama=("Net kuvvet sıfır olduğuna göre sürtünme itmeye eşit: {} N."
                          ).format(itme),
                yaygin_yanlislar={
                    0:
                        "Sürtünme yok saydın. Sürtünme olmasaydı {} N itme "
                        "arabayı sürekli hızlandırırdı.".format(itme),
                    itme2:
                        "İkinci ölçümün itme kuvvetini aldın. O evrede araba "
                        "hızlanıyor; itme sürtünmeden büyük.",
                },
                ipuclari=["Net kuvvet sıfırsa yatay kuvvetler arasında ne ilişki var?"],
                puan=12,
            ),
            sayi_adimi(
                soru="İkinci ölçümde arabanın ivmesi kaç m/s²?",
                cevap=ivme,
                birim="m/s²",
                aciklama=("Net kuvvet = {} − {} = {} N. İvme = {} ÷ {} = {} m/s²."
                          ).format(itme2, itme, itme2 - itme, itme2 - itme,
                                   kutle, sy(ivme)),
                yaygin_yanlislar={
                    sy(itme2 / float(kutle)).replace(",", "."):
                        "Sürtünmeyi unuttun: dinamometrenin gösterdiği kuvvetin "
                        "tamamı net kuvvet değil; sürtünmeyi çıkar.",
                    itme2 - itme:
                        "Net kuvveti buldun ama kütleye bölmedin.",
                },
                ipuclari=["Sürtünme ikinci ölçümde de var."],
                puan=14,
            ),
            secim_adimi(
                soru=("İşçinin arabayı ileri itme kuvvetinin tepki kuvveti "
                      "hangisidir?"),
                dogru="Arabanın işçiyi geriye itmesi; bu kuvvet işçiye etki eder",
                yanlislar={
                    "Zeminin arabaya uyguladığı sürtünme kuvveti":
                        "Etki-tepkiyi aynı cisimde aradın. İtme de sürtünme de "
                        "ARABAYA etki ediyor; tepki kuvveti her zaman öbür cisme "
                        "etki eder. Sabit hızda eşit çıkmaları net kuvvetin sıfır "
                        "olmasından.",
                    ("Arabanın ağırlığı; itmeye karşı koyan, arabanın kendi "
                     "kütlesinden gelen kuvvet"):
                        "Ağırlık Dünya ile araba arasındaki çekim; tepkisi arabanın "
                        "Dünya'yı çekmesi. İşçinin itmesiyle bir çift oluşturmaz.",
                    ("Zeminin işçiye uyguladığı sürtünme kuvveti; işçi itince zemin de "
                     "onu iter"):
                        "Bu kuvvet işçiyi ileri iten kuvvet; tepkisi işçinin zemini "
                        "geriye itmesi. İşçi ile araba arasındaki itmenin tepkisi "
                        "arabadan işçiye gelir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Etki-tepki çifti iki cisim arasındaki TEK bir etkileşimdir: "
                    "işçi arabayı iterse araba da işçiyi iter. Bu iki kuvvet farklı "
                    "cisimlere etki ettiği için birbirini dengelemez. Arabadaki "
                    "dengeyi itme ile sürtünme sağlar; onlar bir çift değildir."
                ),
                ipuclari=["Tepki kuvveti hangi cisme etki eder?"],
                puan=12,
            ),
        ],
        kapanis=("Not düzeltildi: sabit hızda net kuvvet 0, sürtünme {} N; itmenin "
                 "tepkisi sürtünme değil, arabanın işçiyi itmesi. Motorlu çekici "
                 "sabit hız için sürtünmeyi, hızlanmak için fazlasını sağlamalı."
                 ).format(itme),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# BİRİMLER, SKALER VE VEKTÖREL NİCELİKLER (B37.13 -- müfredat haritası)
#
# `nicelik_ve_vektor` ÜÇ satırda boştu (2018: 9, 11; 2026: 9). Bağlam:
# "Haritadaki yer değiştirmeleri ve ölçüm birimlerini birleştirme".
# `yaygin_yanlis`:
#
#   "Büyüklük ile yönü karıştırmak; birimleri dönüştürmeden işlem yapmak."
#
# DÜZENEK: keşif devriyesi birbirine dik iki bacak yürüyor. Bacaklardan biri
# adımsayarla METRE, öbürü harita ölçeğinden KİLOMETRE olarak kaydedilmiş --
# birim uyuşmazlığı kayıtların kendisinde.
#
# YANILGILARIN SAYISAL KARŞILIĞI:
#   * birimi çevirmeden toplamak: 300 + 0,4 = 300,4;
#   * yol ile yer değiştirmeyi karıştırmak: uzunlukları toplamak (vektörün
#     büyüklüğü yönden bağımsız toplanmaz);
#   * yönsüz konum raporu: "500 m uzaktayız" bir konum vermez.
# Bacaklar Pitagoras üçlüsünden: bileşke TAM SAYI metre.
# ==========================================================================

_UCLULER = ((3, 4, 5), (6, 8, 10), (5, 12, 13), (8, 15, 17), (9, 12, 15),
            (12, 16, 20), (7, 24, 25))

# (birinci bacak yönü, ikinci bacak yönü, bileşkenin yönü, dönüş yönü)
_ROTA_YONLERI = (("doğuya", "kuzeye", "doğu ile kuzey arasındaki yönde",
                  "batı ile güney arasındaki yönde"),
                 ("batıya", "kuzeye", "batı ile kuzey arasındaki yönde",
                  "doğu ile güney arasındaki yönde"),
                 ("doğuya", "güneye", "doğu ile güney arasındaki yönde",
                  "batı ile kuzey arasındaki yönde"),
                 ("batıya", "güneye", "batı ile güney arasındaki yönde",
                  "doğu ile kuzey arasındaki yönde"))


def _rota_havuzu():
    """(birinci_m, ikinci_m, bileske_m, km_bacak): km_bacak 0 ya da 1.

    Koşullar:
      1. KM olarak kaydedilen bacak en çok iki ondalıklı km (10 m'nin katı).
      2. Bileşke en çok 3000 m.
      3. Birimi çevirmeden toplama sonucu, yol ve bileşke birbirinden farklı.
    """
    havuz = []
    for a, b, c in _UCLULER:
        for olcek in (20, 50, 100):
            birinci, ikinci, bileske = a * olcek, b * olcek, c * olcek
            if bileske > 3000:
                continue
            for km_bacak in (0, 1):
                km_m = (birinci, ikinci)[km_bacak]
                if km_m % 10:
                    continue
                m_m = (birinci, ikinci)[1 - km_bacak]
                karisik = m_m + km_m / 1000.0
                if len({karisik, float(birinci + ikinci), float(bileske)}) < 3:
                    continue
                havuz.append((birinci, ikinci, bileske, km_bacak))
    return tuple(havuz)


_ROTA = _rota_havuzu()


@bulmaca(ders="fizik", konu="nicelik_ve_vektor", kademeler=(9, 13), agirlik=1.3)
def kesif_rotasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yer değiştirme vektördür: birim çevrilir, dik bileşenler Pitagorasla birleşir, yön yazılır."""
    birinci, ikinci, bileske, km_bacak = rastgele.choice(_ROTA)
    yon1, yon2, bileske_yonu, donus_yonu = rastgele.choice(_ROTA_YONLERI)
    km_m = (birinci, ikinci)[km_bacak]
    m_m = (birinci, ikinci)[1 - km_bacak]
    karisik = m_m + km_m / 1000.0
    yol = birinci + ikinci

    def kayit(sira, metre, yon):
        if sira == km_bacak:
            return ("Harita ölçeğinden: {}. bacak {} {} km."
                    .format(sira + 1, yon, sy(metre / 1000.0)))
        return "Adımsayar kaydı: {}. bacak {} {} m.".format(sira + 1, yon, metre)

    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-kesif-rotasi",
        ders="fizik",
        baslik="Keşif Rotası",
        kademe=kademe,
        konu="nicelik_ve_vektor",
        kazanim="Skaler (yol) ve vektörel (yer değiştirme) nicelikleri ayırt etme; "
                "birimleri dönüştürerek dik vektörlerin bileşkesini bulma; vektörü "
                "büyüklüğü ve yönüyle bildirme.",
        dikkat=7,
        brifing=(
            "Keşif devriyesi kamptan çıkıp iki bacaklık bir rota yürüdü ve bir "
            "kaynağın başında durdu. Su taşıyacak ekip oraya en kısa yoldan, "
            "düz bir hatla gidecek.\n\n"
            "{} konum raporuna iki bacağın kayıtlarındaki sayıları toplayıp "
            "yazdı ve \"bu kadar uzaktayız\" dedi.\n\n"
            "Ekip yola çıkmadan önce devriyenin kamptan gerçekte nerede olduğunu "
            "bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Birinci bacak", kayit(0, birinci, yon1), bedel=1, kritik=True),
            Kanit("İkinci bacak", kayit(1, ikinci, yon2), bedel=1, kritik=True),
            Kanit("Harita notu",
                  "İki bacak birbirine dik. 1 km = 1000 m.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Devriyenin kamptan yer değiştirmesini hangi yol verir?",
                dogru=("Birimler eşitlenir, dik bacaklar Pitagorasla birleştirilir, yön "
                       "de yazılır"),
                yanlislar={
                    "İki bacağın uzunlukları toplanır; devriye o kadar yol yürüyüp uzaklaştı":
                        "Büyüklük ile yönü karıştırdın. Uzunlukların toplamı "
                        "YÜRÜNEN YOLU verir; yer değiştirme bir vektördür ve dik "
                        "bacaklarda toplamdan kısadır.",
                    "Kayıtlardaki sayılar olduğu gibi toplanır, birim sonra yazılır":
                        "Birimleri dönüştürmeden işlem yaptın. Metre ile kilometre "
                        "doğrudan toplanamaz; önce ikisi de aynı birime çevrilir.",
                    ("Uzun olan bacak yer değiştirmeyi verir; kısa bacak yalnız yönü biraz "
                     "değiştirir"):
                        "Kısa bacak da devriyeyi kamptan uzaklaştırdı. İki dik "
                        "bacağın bileşkesi uzun bacaktan büyüktür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yol skalerdir: yürünen uzunlukların toplamı. Yer değiştirme "
                    "vektördür: başlangıçtan bitişe çizilen okun büyüklüğü VE yönü. "
                    "Dik iki bileşenin bileşkesi √(a² + b²). Her iki işlemden önce "
                    "sayılar aynı birimde olmalı."
                ),
                ipuclari=[
                    "Kayıtlardaki iki sayı aynı birimde mi?",
                    "Yürünen uzunluk ile kamptan çizilen düz ok aynı şey mi?",
                ],
                cozum=(
                    "km -> m (× 1000)\n"
                    "Yol = a + b\n"
                    "Yer değiştirme = √(a² + b²), yönüyle birlikte"
                ),
            ),
            sayi_adimi(
                soru="Devriyenin yürüdüğü toplam yol kaç metre?",
                cevap=yol,
                birim="m",
                aciklama=("{} km = {} m. Yol = {} m + {} m = {} m."
                          ).format(sy(km_m / 1000.0), km_m, m_m, km_m, yol),
                yaygin_yanlislar={
                    sy(karisik).replace(",", "."):
                        "Birimleri dönüştürmeden topladın: metre ile kilometreyi "
                        "doğrudan toplayamazsın.",
                    bileske:
                        "Yer değiştirmenin büyüklüğünü yazdın. Yol, yürünen "
                        "uzunlukların toplamı.",
                },
                ipuclari=["Kilometreyi metreye çevir."],
                puan=10,
            ),
            sayi_adimi(
                soru="Devriyenin kamptan yer değiştirmesinin büyüklüğü kaç metre?",
                cevap=bileske,
                birim="m",
                aciklama="√({}² + {}²) = √{} = {} m.".format(
                    birinci, ikinci, birinci ** 2 + ikinci ** 2, bileske),
                yaygin_yanlislar={
                    yol:
                        "Büyüklük ile yönü karıştırdın: uzunlukları toplamak yolu "
                        "verir. Dik bacakların bileşkesi daha kısa.",
                    sy(karisik).replace(",", "."):
                        "Birimleri dönüştürmeden işlem yaptın ve üstüne "
                        "uzunlukları topladın.",
                },
                ipuclari=["İki bacak dik: bir dik üçgenin hipotenüsünü bul."],
                puan=14,
            ),
            secim_adimi(
                soru="Konum raporu, su ekibinin kaynağı bulabilmesi için nasıl yazılmalı?",
                dogru="Kaynak kamptan {} m uzakta, {}".format(bileske, bileske_yonu),
                yanlislar={
                    "Kaynak kamptan {} m uzakta".format(bileske):
                        "Büyüklük tek başına konum vermez: kamptan {} m uzakta "
                        "sonsuz nokta var. Yer değiştirme yönüyle birlikte "
                        "bildirilir.".format(bileske),
                    "Kaynak kamptan {} m uzakta, {}".format(bileske, donus_yonu):
                        "Yönü ters yazdın: bu, kaynaktan KAMPA dönüş yönü.",
                    "Kaynak kamptan {} m uzakta, {}".format(yol, bileske_yonu):
                        "Yön doğru ama büyüklük yürünen yol. Ekip düz hatla "
                        "gidecek; ona yer değiştirmenin büyüklüğü gerekir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Devriye önce {}, sonra {} yürüdü: kaynak kamptan {}. "
                    "Ekip düz hatla {} m yürüyecek -- devriyenin yürüdüğü {} m değil."
                ).format(yon1, yon2, bileske_yonu, bileske, yol),
                ipuclari=["Bir vektör iki bilgiyle tam tanımlanır."],
                puan=12,
            ),
        ],
        kapanis=("Rapor düzeltildi: kaynak kamptan {} m, {}. Su ekibi "
                 "devriyenin {} m yolunu değil, bu düz hattı yürüyecek."
                 ).format(bileske, bileske_yonu, yol),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# KALDIRMA KUVVETİ: BATAN CİSME DE ETKİ EDER (B37.13 -- müfredat haritası)
#
# `kaldirma_kuvveti` iki satırda boştu (2018: 10; 2026: 9). Bağlam: "Numune
# kapsülünün sıvıdaki durumunu inceleme". `yaygin_yanlis`:
#
#   "Batan cisme kaldırma kuvveti etki etmez sanmak."
#
# DÜZENEK: göl tabanına indirilecek ağır bir numune kapsülü dinamometreyle
# önce havada, sonra suyun içinde (tamamen batmış, tabana değmeden) tartılıyor.
# Suda okunan değer küçük: fark kaldırma kuvveti. Kapsül yine de batıyor.
#
# YANILGININ SAYISAL KARŞILIĞI: kaldırma kuvvetine 0 demek ayrı teşhis alır;
# hacim sorusunda kaldırma kuvvetinden taşan suyun kütlesini (kg) hacim
# sanmak da ayrı teşhis alır. Kapsülün yoğunluğu 2,2-3,2 g/cm³ -- batan,
# gerçekçi bir kapsül.
# ==========================================================================

def _kapsul_havuzu():
    """(agirlik, kaldirma): N, N. Suda okunan = agirlik − kaldirma.

    Koşullar:
      1. Yoğunluk (agirlik / kaldirma, g/cm³) 2,2 ile 3,2 arasında: batar.
      2. Suda okunan değer kaldırma kuvvetine eşit değil (agirlik ≠ 2 ×
         kaldirma) -- iki teşhis çakışmasın; zaten 1. koşul bunu dışlar.
    """
    havuz = []
    for agirlik in (12, 15, 16, 18, 20, 24, 25, 30):
        for kaldirma in (4, 5, 6, 8, 10):
            if not 2.2 <= agirlik / float(kaldirma) <= 3.2:
                continue
            havuz.append((agirlik, kaldirma))
    return tuple(havuz)


_KAPSUL = _kapsul_havuzu()


@bulmaca(ders="fizik", konu="kaldirma_kuvveti", kademeler=(9, 13), agirlik=1.3)
def numune_kapsulu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Batan cisme de kaldırma kuvveti etki eder: havadaki ve sudaki tartım farkı."""
    agirlik, kaldirma = rastgele.choice(_KAPSUL)
    suda = agirlik - kaldirma
    hacim_cm3 = kaldirma * 100            # F / (1000 kg/m³ · 10 m/s²) m³
    tasan_kg = kaldirma / 10.0
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-numune-kapsulu",
        ders="fizik",
        baslik="Numune Kapsülü",
        kademe=kademe,
        konu="kaldirma_kuvveti",
        kazanim="Sıvıya batmış cisme etki eden kaldırma kuvvetini tartım farkından "
                "bulma; batan cisme de kaldırma kuvveti etki ettiğini açıklama; "
                "taşırılan sıvının hacmini hesaplama.",
        dikkat=7,
        brifing=(
            "Göl tabanına bir numune kapsülü indirilecek. Halat listesinde iki "
            "satır var: kapsülün sudaki ağırlığı (su altında bekletme için) ve "
            "havadaki ağırlığı (sudan çıkarma için).\n\n"
            "{} iki satıra da havadaki değeri yazdı: \"Kapsül batıyor, demek ki "
            "su onu hiç kaldırmıyor. Suda da havadaki kadar ağır.\"\n\n"
            "Halat sipariş edilmeden önce dinamometre ölçümlerini yorumlamamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Havada tartım", "Dinamometre: {} N.".format(agirlik),
                  bedel=1, kritik=True),
            Kanit("Suda tartım",
                  "Kapsül tamamen suya battı, tabana değmiyor. Dinamometre: {} N. "
                  "Halat bırakılınca kapsül dibe iniyor.".format(suda),
                  bedel=1, kritik=True),
            Kanit("Göl suyu notu",
                  "Suyun yoğunluğu 1000 kg/m³ (1 g/cm³). g = 10 m/s². Kaldırma "
                  "kuvveti, cismin taşırdığı sıvının ağırlığına eşittir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Suda batan kapsüle kaldırma kuvveti etki eder mi?",
                dogru=("Evet: taşırdığı suyun ağırlığı kadar; ağırlığı bundan büyük "
                       "olduğu için batar"),
                yanlislar={
                    ("Hayır: kaldırma kuvveti yalnız yüzen cisimlere etki eder, batan "
                     "cismi su taşıyamaz"):
                        "Batan cisme kaldırma kuvveti etki etmez sandın. Suda "
                        "tartımda dinamometre daha küçük bir değer gösteriyor: su "
                        "kapsülü yukarı itiyor.",
                    ("Evet, ama yalnız yüzeye yakınken; derine inince kaybolur, çünkü "
                     "üstteki su onu bastırır"):
                        "Tamamen batmış bir cisimde kaldırma kuvveti derinlikle "
                        "değişmez; taşırılan su miktarı aynı kalır.",
                    "Hayır: batan cisme su aşağı doğru kuvvet uygular":
                        "Su basıncı cismin altında üstündekinden büyüktür; net "
                        "etki yukarı doğrudur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Suya giren her cisim kendi hacmi kadar suyu yerinden eder ve "
                    "o suyun ağırlığı kadar yukarı itilir. Cismin batıp batmaması "
                    "bu itişin ağırlıktan küçük ya da büyük olmasına bağlıdır; "
                    "kuvvetin var olup olmamasına değil."
                ),
                ipuclari=[
                    "Havada ve suda okunan değerler aynı mı?",
                    "Su kapsülü tutmuyorsa dinamometre neden daha az gösteriyor?",
                ],
                cozum=(
                    "Kaldırma kuvveti = havadaki − sudaki okuma\n"
                    "Hacim = kaldırma kuvveti ÷ (ρ_su · g)"
                ),
            ),
            sayi_adimi(
                soru="Kapsüle etki eden kaldırma kuvveti kaç N?",
                cevap=kaldirma,
                birim="N",
                aciklama="{} N − {} N = {} N.".format(agirlik, suda, kaldirma),
                yaygin_yanlislar={
                    0:
                        "Batan cisme kaldırma kuvveti etki etmez sandın. Suda "
                        "okunan değer havadakinden {} N küçük.".format(kaldirma),
                    agirlik:
                        "Havadaki ağırlığı yazdın; kaldırma kuvveti iki okumanın "
                        "farkı.",
                    suda:
                        "Suda okunan değeri yazdın; bu kapsülün sudaki görünür "
                        "ağırlığı, kaldırma kuvveti değil.",
                },
                ipuclari=["İki tartımı karşılaştır."],
                puan=12,
            ),
            sayi_adimi(
                soru="Kapsülün hacmi kaç cm³?",
                cevap=hacim_cm3,
                birim="cm³",
                aciklama=(
                    "V = F ÷ (ρ · g) = {} ÷ (1000 × 10) = {} m³ = {} cm³."
                ).format(kaldirma, sy(kaldirma / 10000.0), hacim_cm3),
                yaygin_yanlislar={
                    sy(tasan_kg).replace(",", "."):
                        "Taşan suyun kütlesini (kg) buldun; hacim için yoğunluğa "
                        "da böl ve cm³'e çevir.",
                    kaldirma * 1000:
                        "g'yi hesaba katmadın: F ÷ ρ değil, F ÷ (ρ · g).",
                },
                ipuclari=["1 m³ = 1 000 000 cm³."],
                puan=12,
            ),
            yorum_adimi(
                soru="Halat listesinin \"sudaki ağırlık\" satırına ne yazılmalı ve neden?",
                dogru=("Sudaki {} N: su kapsülü {} N yukarı itiyor ama ağırlığı daha "
                       "büyük").format(suda, kaldirma),
                yanlislar={
                    ("Havadaki {} N: batan cisme su hiçbir kuvvet uygulamaz, yoksa kapsül "
                     "batmazdı").format(agirlik):
                        "Batan cisme kaldırma kuvveti etki etmez sandın. Suda tartım "
                        "{} N gösteriyor.".format(suda),
                    ("{} N: kapsül suda kaldırma kuvveti kadar ağırdır, suyun ittiği kadar "
                     "ağırlık kalır").format(kaldirma):
                        "Kaldırma kuvvetini sudaki ağırlık sandın; sudaki ağırlık "
                        "havadakinden kaldırma kuvveti ÇIKARILINCA kalan.",
                    "0 N: kapsül suda ağırlıksızdır":
                        "Kapsül ağırlıksız olsaydı batmazdı; dinamometre {} N "
                        "gösteriyor.".format(suda),
                },
                rastgele=rastgele,
                aciklama=(
                    "Sudaki ağırlık satırı {} N. Havadaki ağırlık satırı ise {} N "
                    "olarak kalıyor: kapsül sudan çıktığında kaldırma kuvveti "
                    "ortadan kalkar."
                ).format(suda, agirlik),
                puan=10,
            ),
        ],
        kapanis=("Halat listesi düzeltildi: suda {} N, sudan çıkarken {} N. Kaldırma "
                 "kuvveti {} N; kapsül batıyor ama su onu yine de itiyor."
                 ).format(suda, agirlik, kaldirma),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# STATİK VE KİNETİK SÜRTÜNME (B37.13 -- müfredat haritası)
#
# `surtunme` iki satırda boştu (2018: 9; 2026: 11). Bağlam: "Atölye kasasının
# harekete başlama ve kayma durumlarını karşılaştırma". `yaygin_yanlis`:
#
#   "Statik sürtünmeyi her zaman en büyük değerinde almak."
#
# DÜZENEK: atölye kasası üç kez itiliyor. (1) Zayıf itme: kasa kımıldamıyor;
# statik sürtünme İTMEYE EŞİT, μs·N değil. (2) Kasanın kaymaya başladığı
# eşik: μs·N. (3) Güçlü itme: kasa kayıyor; sürtünme kinetik, μk·N.
#
# YANILGININ SAYISAL KARŞILIĞI: (1)'de μs·N yazmak; (3)'te ivmeyi statik
# en büyük değerle hesaplamak. İkisi de ayrı teşhis alır.
# ==========================================================================

def _surtunme_havuzu():
    """(kutle, mu_s10, mu_k10, itme1, itme2): kg, μ×10, μ×10, N, N; g = 10.

    Koşullar:
      1. μk < μs; itme1 < μs·N < itme2.
      2. itme1 kinetik sürtünmeye eşit değil.
      3. Üç ivme adayı -- doğru (μk), statik ile (μs), sürtünmesiz -- en çok
         iki ondalıklı ve pozitif.
    """
    havuz = []
    for kutle in (20, 40, 50, 60):
        normal = kutle * 10
        for mu_s10 in (4, 5, 6):
            statik_max = normal * mu_s10 // 10
            for mu_k10 in (2, 3):
                if mu_k10 >= mu_s10:
                    continue
                kinetik = normal * mu_k10 // 10
                for itme1 in range(10, statik_max, 10):
                    if not 0.5 * statik_max <= itme1 <= 0.9 * statik_max:
                        continue
                    if itme1 == kinetik:
                        continue          # "kinetiği kullandın" teşhisi cevaba yapışırdı
                    for fazla in (20, 40, 50, 60, 80, 100):
                        itme2 = statik_max + fazla
                        adaylar = (itme2 - kinetik, itme2 - statik_max, itme2)
                        if any((x * 100) % kutle for x in adaylar):
                            continue
                        havuz.append((kutle, mu_s10, mu_k10, itme1, itme2))
    return tuple(havuz)


_SURTUNME = _surtunme_havuzu()


@bulmaca(ders="fizik", konu="surtunme", kademeler=(9, 13), agirlik=1.3)
def atolye_kasasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Duran cisimde statik sürtünme itmeye eşittir; en büyük değeri yalnız eşikte."""
    kutle, mu_s10, mu_k10, itme1, itme2 = rastgele.choice(_SURTUNME)
    normal = kutle * 10
    statik_max = normal * mu_s10 // 10
    kinetik = normal * mu_k10 // 10
    ivme = (itme2 - kinetik) / float(kutle)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-atolye-kasasi",
        ders="fizik",
        baslik="Atölye Kasası",
        kademe=kademe,
        konu="surtunme",
        kazanim="Statik sürtünmenin uygulanan kuvvete göre değiştiğini, en büyük "
                "değerine yalnız kayma eşiğinde ulaştığını açıklama; kinetik "
                "sürtünmeyle ivme hesaplama.",
        dikkat=7,
        brifing=(
            "Atölyede ağır bir takım kasası yer değiştirecek. Zemine sürtünme "
            "katsayıları ölçüldü ve kasa üç kez itildi.\n\n"
            "{} ilk itmenin raporunu yazdı: \"Kasa kımıldamadı, çünkü statik "
            "sürtünme hep en büyük değerinde: μs × N.\"\n\n"
            "Kasayı taşıyacak ekip kaç kişi olacağına karar vermeden önce üç "
            "itmeyi doğru yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Kasa ve zemin",
                  "Kasa: {} kg. g = 10 m/s². Statik sürtünme katsayısı μs = {}; "
                  "kinetik sürtünme katsayısı μk = {}.".format(
                      kutle, sy(mu_s10 / 10.0), sy(mu_k10 / 10.0)),
                  bedel=1, kritik=True),
            Kanit("İtme kayıtları",
                  "1. itme: {} N, yatay. Kasa kımıldamadı.\n"
                  "2. itme: kuvvet yavaşça artırıldı; kasa belli bir değerde "
                  "kaymaya başladı.\n"
                  "3. itme: {} N, yatay. Kasa kayarak hızlandı.".format(itme1, itme2),
                  bedel=1, kritik=True),
            Kanit("Sürtünme notu",
                  "Statik sürtünme en çok μs × N olabilir. Kayan cisme kinetik "
                  "sürtünme etki eder: μk × N. Yatay zeminde N = m × g.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kasa itildiği hâlde kımıldamıyorsa statik sürtünme kuvveti için hangisi doğru?",
                dogru="İtmeye eşittir; μs × N değerine ancak kayma başlarken ulaşır",
                yanlislar={
                    ("Her zaman en büyük değerindedir: μs × N, çünkü yüzeyler hep aynı "
                     "sıkılıkta tutunur"):
                        "Statik sürtünmeyi her zaman en büyük değerinde aldın. "
                        "Öyle olsaydı zayıf itmede net kuvvet geriye doğru olur, "
                        "kasa itene doğru kayardı.",
                    "Sıfırdır; kasa hareket etmediği için sürtünme yoktur":
                        "Sürtünme olmasaydı en küçük itme bile kasayı kaydırırdı.",
                    ("İtme kuvvetinden büyüktür; kasa bu yüzden kımıldamaz, küçük olsaydı "
                     "kayardı"):
                        "Kasa kımıldamıyorsa net kuvvet sıfır: sürtünme itmeden "
                        "büyük değil, ona eşit.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Statik sürtünme, cismi yerinde tutmaya YETECEK kadardır: "
                    "itme ne kadarsa o kadar. μs × N yalnız bir üst sınırdır; "
                    "itme bu sınırı aşınca kasa kayar ve sürtünme kinetik olur."
                ),
                ipuclari=[
                    "Kasa kımıldamıyorsa yatay net kuvvet kaçtır?",
                    "μs × N bir değer mi, bir üst sınır mı?",
                ],
                cozum=(
                    "Duruyorsa: f_s = itme (≤ μs · N)\n"
                    "Kayma eşiği: itme = μs · N\n"
                    "Kayıyorsa: f_k = μk · N, a = (F − f_k) / m"
                ),
            ),
            sayi_adimi(
                soru="1. itmede kasaya etki eden statik sürtünme kuvveti kaç N?",
                cevap=itme1,
                birim="N",
                aciklama=("Kasa kımıldamadı, net kuvvet 0: sürtünme itmeye eşit, {} N. "
                          "Üst sınıra (μs × N = {} N) henüz ulaşılmadı."
                          ).format(itme1, statik_max),
                yaygin_yanlislar={
                    statik_max:
                        "Statik sürtünmeyi her zaman en büyük değerinde aldın. "
                        "Kasa yerinde kaldığına göre sürtünme itmeye eşit.",
                    0:
                        "Sürtünmeyi sıfır saydın; o zaman kasa kayardı.",
                    kinetik:
                        "Kinetik sürtünmeyi kullandın; kasa kaymıyor.",
                },
                ipuclari=["Kasa kımıldamadıysa kuvvetler dengede."],
                puan=12,
            ),
            sayi_adimi(
                soru="Kasayı kaydırmaya başlamak için en az kaç N itmek gerekir?",
                cevap=statik_max,
                birim="N",
                aciklama="μs × m × g = {} × {} × 10 = {} N.".format(
                    sy(mu_s10 / 10.0), kutle, statik_max),
                yaygin_yanlislar={
                    kinetik:
                        "Kinetik katsayıyı kullandın; harekete başlatmak için "
                        "statik sınırı aşmak gerekir.",
                    itme1:
                        "1. itmenin kuvvetini yazdın; o kuvvetle kasa kımıldamadı.",
                },
                ipuclari=["Statik sürtünmenin üst sınırını hesapla."],
                puan=12,
            ),
            sayi_adimi(
                soru="3. itmede kasanın ivmesi kaç m/s²?",
                cevap=ivme,
                birim="m/s²",
                aciklama=("Kasa kayıyor, sürtünme kinetik: {} × {} × 10 = {} N. "
                          "a = ({} − {}) ÷ {} = {} m/s².").format(
                              sy(mu_k10 / 10.0), kutle, kinetik, itme2, kinetik,
                              kutle, sy(ivme)),
                yaygin_yanlislar={
                    sy((itme2 - statik_max) / float(kutle)).replace(",", "."):
                        "Kayan kasada da statik sürtünmenin en büyük değerini "
                        "kullandın. Kasa kayarken sürtünme kinetik: μk × N.",
                    sy(itme2 / float(kutle)).replace(",", "."):
                        "Sürtünmeyi unuttun; net kuvvet itmeden sürtünme çıkınca "
                        "kalan.",
                },
                ipuclari=["Kayan kasaya hangi sürtünme etki eder?"],
                puan=14,
            ),
        ],
        kapanis=("Rapor düzeltildi: 1. itmede sürtünme {} N (itmeye eşit), kayma "
                 "eşiği {} N, kayarken sürtünme {} N ve ivme {} m/s². Ekip, eşiği "
                 "aşacak sayıda kişiyle kuruldu."
                 ).format(itme1, statik_max, kinetik, sy(ivme)),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# TORK VE DENGE: KUVVET KOLU DİK UZAKLIKTIR (B37.13 -- müfredat haritası)
#
# `tork_denge` iki satırda boştu (2018: 11; 2026: 12). Bağlam: "Atölye
# vincinin dengede kalma koşullarını hesaplama". `yaygin_yanlis`:
#
#   "Kuvvet kolunu dik uzaklık yerine rastgele uzunluk almak."
#
# DÜZENEK: atölye vincinin eğik kolu bir mafsaldan yükseliyor; yük kolun
# ucundan düşey halatla asılı. Ağırlık düşey olduğu için kuvvet kolu, mafsal
# ile halat arasındaki YATAY uzaklıktır -- kolun boyu değil. Arka tarafta
# yatay bir kolda karşı ağırlık var. Kol boyu, yatay ve düşey uzaklık
# Pitagoras üçlüsünden: sayılar temiz.
#
# YANILGININ SAYISAL KARŞILIĞI: torka ve karşı ağırlığa kol boyunu koymak
# (ya da düşey yüksekliği) ayrı teşhis alır; kol dikleşince torkun
# değişmeyeceğini sanmak yorumda sınanır.
# ==========================================================================

# Kol boyları atölye sahası vinci ölçeğinde (5-10 m); yük 200-600 kg.
_VINC_KOLLARI = ((5, 4, 3), (5, 3, 4), (10, 8, 6), (10, 6, 8))


def _tork_havuzu():
    """(kol, yatay, dusey, yuk, arka): m, m, m, N, m.

    Koşullar:
      1. Karşı ağırlık -- doğru (yük·yatay/arka) ve kol boyuyla (yük·kol/arka)
         -- TAM SAYI.
      2. İkisi de yükün kendisine eşit değil (yatay ≠ arka, kol ≠ arka).
    """
    havuz = []
    for kol, yatay, dusey in _VINC_KOLLARI:
        for yuk in (2000, 3000, 4000, 5000, 6000):
            for arka in (2, 3, 4, 5, 6):
                if (yuk * yatay) % arka or (yuk * kol) % arka:
                    continue
                if yatay == arka or kol == arka:
                    continue
                havuz.append((kol, yatay, dusey, yuk, arka))
    return tuple(havuz)


_TORK = _tork_havuzu()


@bulmaca(ders="fizik", konu="tork_denge", kademeler=(11, 13), agirlik=1.3)
def vinc_kolu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Tork = kuvvet × dönme noktasından kuvvet doğrultusuna dik uzaklık."""
    kol, yatay, dusey, yuk, arka = rastgele.choice(_TORK)
    tork = yuk * yatay
    karsi = tork // arka
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-vinc-kolu",
        ders="fizik",
        baslik="Vinç Kolu",
        kademe=kademe,
        konu="tork_denge",
        kazanim="Torku kuvvet ile dönme noktasına dik uzaklığın çarpımı olarak "
                "hesaplama; dönme dengesi için karşı ağırlığı bulma; kolun açısı "
                "değişince kuvvet kolunun değiştiğini açıklama.",
        dikkat=7,
        brifing=(
            "Atölyenin dış sahasındaki vinç, eğik koluyla bir motor bloğunu kaldırıyor. Vinç "
            "devrilmesin diye arka koldaki karşı ağırlık ayarlanacak.\n\n"
            "{} hesabı kolun boyuyla yaptı: \"Kol {} metre, yük {} N; tork "
            "{} N·m. Karşı ağırlığı buna göre koyalım.\"\n\n"
            "Karşı ağırlık yerleştirilmeden önce hesabı denetlememiz gerekiyor."
        ).format(kisi, kol, yuk, yuk * kol),
        kanitlar=[
            Kanit("Vinç ölçümleri",
                  "Eğik kolun boyu (mafsaldan uca): {} m.\n"
                  "Kolun ucu mafsaldan yatayda {} m ileride, düşeyde {} m yukarıda.\n"
                  "Yük uçtan düşey bir halatla asılı; ağırlığı {} N."
                  .format(kol, yatay, dusey, yuk),
                  bedel=1, kritik=True),
            Kanit("Arka kol",
                  "Karşı ağırlık, mafsalın öbür yanında yatay arka kolun "
                  "ucuna, mafsaldan {} m uzağa asılacak.".format(arka),
                  bedel=1, kritik=True),
            Kanit("Tork notu",
                  "Tork = kuvvet × dönme noktasından kuvvetin doğrultusuna olan "
                  "DİK uzaklık. Dönme dengesinde iki yöndeki torklar eşittir.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yükün ağırlığının mafsala göre torkunu hangi uzunluk belirler?",
                dogru="Mafsaldan düşey halata olan dik uzaklık, yani yatay mesafe",
                yanlislar={
                    "Eğik kolun boyu; kuvvet kolun ucundan uygulandığı için":
                        "Kuvvet kolunu dik uzaklık yerine kolun boyu olarak aldın. "
                        "Ağırlık düşey; ona dik uzaklık, mafsal ile halat arasındaki "
                        "yatay mesafe.",
                    ("Kolun ucunun yerden (mafsaldan) yüksekliği; yük yükseldikçe tork "
                     "büyür"):
                        "Düşey uzaklık düşey kuvvete paralel; tork için kuvvete "
                        "DİK uzaklık gerekir.",
                    "Halatın uzunluğu; yük aşağı sarktıkça dönme etkisi artar":
                        "Yük halatın neresinde olursa olsun ağırlığın doğrultusu "
                        "aynı düşey çizgi; halat uzunluğu torku değiştirmez.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Torku kuvvetin doğrultusu ile dönme noktası arasındaki dik "
                    "uzaklık belirler. Yükün ağırlığı düşey bir çizgi boyunca "
                    "etki eder; mafsaldan bu çizgiye dik uzaklık yatay mesafedir. "
                    "Kolun eğik boyu bu durumda kuvvet kolu değildir."
                ),
                ipuclari=[
                    "Ağırlık hangi doğrultuda etki eder?",
                    "Mafsaldan o doğrultuya en kısa (dik) uzaklık hangisi?",
                ],
                cozum=(
                    "Kuvvet kolu = yatay uzaklık\n"
                    "Tork = yük × yatay uzaklık\n"
                    "Karşı ağırlık × arka kol = tork"
                ),
            ),
            sayi_adimi(
                soru="Yükün mafsala göre torku kaç N·m?",
                cevap=tork,
                birim="N·m",
                aciklama="{} N × {} m = {} N·m.".format(yuk, yatay, tork),
                yaygin_yanlislar={
                    yuk * kol:
                        "Kuvvet kolunu dik uzaklık yerine kolun boyu olarak aldın.",
                    yuk * dusey:
                        "Düşey yüksekliği kullandın; ağırlığa dik uzaklık yatay "
                        "mesafe.",
                },
                ipuclari=["Ağırlığa dik uzaklığı vinç ölçümlerinde bul."],
                puan=12,
            ),
            sayi_adimi(
                soru="Dönme dengesi için karşı ağırlık kaç N olmalı?",
                cevap=karsi,
                birim="N",
                aciklama="{} N·m ÷ {} m = {} N.".format(tork, arka, karsi),
                yaygin_yanlislar={
                    yuk * kol // arka:
                        "Kuvvet kolunu kolun boyu aldın; karşı ağırlık fazla çıktı "
                        "ve vinç arkaya devrilebilir.",
                    yuk:
                        "Yükle aynı ağırlığı koydun; kollar eşit uzunlukta değil.",
                },
                ipuclari=["İki yöndeki torklar eşit olmalı."],
                puan=14,
            ),
            yorum_adimi(
                soru="Kol daha dik kaldırılırsa (ucun yatay uzaklığı azalırsa) gereken karşı ağırlık ne olur?",
                dogru="Azalır: ağırlığa dik uzaklık kısalır, yükün torku azalır",
                yanlislar={
                    "Değişmez: kolun boyu değişmediği için tork aynı kalır, ağırlık da aynı":
                        "Kuvvet kolunu dik uzaklık yerine kolun boyu olarak aldın. "
                        "Kol dikleştikçe halat mafsala yaklaşır, tork azalır.",
                    ("Artar: yük daha yükseğe çıktığı için tork büyür, yüksekteki yük daha "
                     "zor tutulur"):
                        "Yükseklik düşey kuvvetin torkunu değiştirmez; önemli olan "
                        "yatay uzaklık.",
                    "Sıfır olur: kol dik durunca hiç tork kalmaz":
                        "Tam dik kolda öyle olur, ama soru biraz daha dik bir kolu "
                        "soruyor; yatay uzaklık sıfıra inmedikçe tork vardır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Tork yatay uzaklıkla orantılı. Kol tamamen düşey olsaydı "
                    "halat mafsalın tam üstünden geçer ve tork sıfır olurdu; "
                    "eğik kolda ise yatay uzaklık kadar tork var."
                ),
                puan=10,
            ),
        ],
        kapanis=("Karşı ağırlık {} N olarak asıldı (kol boyuyla hesaplanan {} N "
                 "vinci arkaya devirirdi). Tork {} N·m; kuvvet kolu yatay {} m."
                 ).format(karsi, yuk * kol // arka, tork, yatay),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# IŞIK ŞİDDETİ VE AYDINLANMA (B37.13 -- müfredat haritası)
#
# `aydinlanma` iki satırda boştu (2018: 10; 2026: 11). Bağlam: "Depo
# ışıklarının yerleşimini ve gölgeleri inceleme". `yaygin_yanlis`:
#
#   "Işık şiddetiyle aydınlanmayı aynı saymak."
#
# DÜZENEK: depodaki çalışma masası için iki lamba. A'nın ışık şiddeti daha
# büyük ama tavana yakın, yüksekte asılı; B daha zayıf ama masaya yakın.
# Noktasal kaynak için masanın tam altındaki aydınlanma E = I / d².
# Havuz her örnekte B'nin masayı DAHA ÇOK aydınlattığını garanti ediyor:
# "şiddeti büyük olan daha çok aydınlatır" diyen öğrenci yanlış lambayı seçer.
#
# YANILGININ SAYISAL KARŞILIĞI: aydınlanmaya ışık şiddetini yazmak; karesini
# almayı unutmak (I / d) ayrı teşhis alır.
# ==========================================================================

def _lamba_havuzu():
    """(siddet_a, yukseklik_a, siddet_b, yukseklik_b): cd, m, cd, m.

    Koşullar:
      1. siddet_a > siddet_b ama E_a < E_b (yanılgı yanlış lambayı seçer).
      2. Aydınlanmalar ve I / d çeldiricileri TAM SAYI.
      3. yükseklikler en az 2 m: d = 1 olsaydı I / d² = I, iki teşhis çakışırdı.
    """
    havuz = []
    for yukseklik_a in (3, 4):
        for siddet_a in (900, 1440, 1600, 1800, 2400, 2700, 3200, 3600):
            if siddet_a % (yukseklik_a * yukseklik_a):
                continue
            e_a = siddet_a // (yukseklik_a * yukseklik_a)
            for yukseklik_b in (2,):
                for siddet_b in (400, 480, 600, 800, 1200):
                    if siddet_b >= siddet_a or siddet_b % (yukseklik_b * yukseklik_b):
                        continue
                    e_b = siddet_b // (yukseklik_b * yukseklik_b)
                    if e_b <= e_a:
                        continue
                    havuz.append((siddet_a, yukseklik_a, siddet_b, yukseklik_b))
    return tuple(havuz)


_LAMBA = _lamba_havuzu()


@bulmaca(ders="fizik", konu="aydinlanma", kademeler=(10, 13), agirlik=1.3)
def depo_lambalari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Aydınlanma kaynağın şiddetine VE uzaklığın karesine bağlıdır: E = I / d²."""
    siddet_a, h_a, siddet_b, h_b = rastgele.choice(_LAMBA)
    e_a = siddet_a // (h_a * h_a)
    e_b = siddet_b // (h_b * h_b)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-depo-lambalari",
        ders="fizik",
        baslik="Depo Lambaları",
        kademe=kademe,
        konu="aydinlanma",
        kazanim="Işık şiddeti ile aydınlanmayı ayırt etme; E = I / d² ile noktasal "
                "kaynağın bir yüzeyde oluşturduğu aydınlanmayı hesaplama ve "
                "karşılaştırma.",
        dikkat=7,
        brifing=(
            "Depodaki ince işçilik masası loş kalıyor. İki lambadan biri masanın "
            "üstünde kalıcı olarak yakılacak.\n\n"
            "{} kutulara bakıp karar verdi: \"A lambasının ışık şiddeti daha "
            "büyük; masayı o daha çok aydınlatır. Nereye asıldığı fark etmez.\"\n\n"
            "Kablo çekilmeden önce hangi lambanın masayı gerçekten daha çok "
            "aydınlattığını bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("A lambası",
                  "Işık şiddeti: {} cd. Tavan rayına asılı; masanın {} m üstünde."
                  .format(siddet_a, h_a),
                  bedel=1, kritik=True),
            Kanit("B lambası",
                  "Işık şiddeti: {} cd. Masanın üstündeki kola asılı; masanın {} m "
                  "üstünde.".format(siddet_b, h_b),
                  bedel=1, kritik=True),
            Kanit("Işık notu",
                  "Işık şiddeti (cd) kaynağın özelliğidir. Aydınlanma (lx) yüzeye "
                  "düşen ışığı anlatır; noktasal kaynağın tam altında E = I ÷ d².",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Işık şiddeti ile aydınlanma arasındaki ilişki için hangisi doğru?",
                dogru=("Işık şiddeti kaynağa aittir; yüzeydeki aydınlanma uzaklığın "
                       "karesiyle azalır"),
                yanlislar={
                    "İkisi aynıdır: şiddeti büyük lamba her yüzeyi daha çok aydınlatır":
                        "Işık şiddetiyle aydınlanmayı aynı saydın. Şiddet lambanın "
                        "kendisine ait; aydınlanma, ışığın yüzeye ne kadar uzaktan "
                        "geldiğine de bağlı.",
                    "Aydınlanma uzaklıkla ters orantılıdır; uzaklık iki katına çıkınca yarıya iner":
                        "Işık her yöne yayıldığı için aynı ışık uzaklığın KARESİYLE "
                        "büyüyen bir alana dağılır: iki kat uzaklıkta dörtte bir.",
                    "Aydınlanma uzaklıkla artar; yüksekteki lamba daha geniş alanı daha çok aydınlatır":
                        "Yüksekteki lamba ışığını daha geniş bir alana yayar; birim "
                        "alana düşen ışık azalır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Lambanın ışık şiddeti değişmez. Ama ışık uzaklaştıkça daha "
                    "büyük bir küre yüzeyine yayılır ve bu yüzey uzaklığın "
                    "karesiyle büyür. Bu yüzden masadaki aydınlanma E = I ÷ d²."
                ),
                ipuclari=[
                    "Işık notu iki büyüklüğü nasıl tanımlıyor?",
                    "Uzaklık iki katına çıkınca ışığın yayıldığı alan kaç katına çıkar?",
                ],
                cozum="E = I ÷ d²",
            ),
            sayi_adimi(
                soru="A lambasının masada oluşturduğu aydınlanma kaç lx?",
                cevap=e_a,
                birim="lx",
                aciklama="{} cd ÷ ({} m)² = {} ÷ {} = {} lx.".format(
                    siddet_a, h_a, siddet_a, h_a * h_a, e_a),
                yaygin_yanlislar={
                    siddet_a:
                        "Işık şiddetiyle aydınlanmayı aynı saydın; uzaklığı hesaba "
                        "katmalısın.",
                    siddet_a // h_a:
                        "Uzaklığın karesini almadın: E = I ÷ d².",
                },
                ipuclari=["Işık notundaki bağıntıyı kullan."],
                puan=12,
            ),
            sayi_adimi(
                soru="B lambasının masada oluşturduğu aydınlanma kaç lx?",
                cevap=e_b,
                birim="lx",
                aciklama="{} cd ÷ ({} m)² = {} ÷ {} = {} lx.".format(
                    siddet_b, h_b, siddet_b, h_b * h_b, e_b),
                yaygin_yanlislar={
                    siddet_b:
                        "Işık şiddetiyle aydınlanmayı aynı saydın.",
                    siddet_b // h_b:
                        "Uzaklığın karesini almadın: E = I ÷ d².",
                },
                ipuclari=["Aynı bağıntı, B'nin değerleriyle."],
                puan=12,
            ),
            secim_adimi(
                soru="Masayı hangi lamba daha çok aydınlatır?",
                dogru="B lambası: masada {} lx, A ise {} lx".format(e_b, e_a),
                yanlislar={
                    "A lambası: ışık şiddeti daha büyük":
                        "Işık şiddetiyle aydınlanmayı aynı saydın. A'nın şiddeti "
                        "büyük ama masadan uzak; masadaki aydınlanması {} lx."
                        .format(e_a),
                    "İkisi eşit aydınlatır: ışık şiddeti uzaklıkla değişmez":
                        "Şiddet değişmez, doğru; ama aydınlanma uzaklığın karesiyle "
                        "azalır.",
                    "A lambası: yüksekte olduğu için ışığı daha geniş alana yayar":
                        "Daha geniş alana yayılan ışık, masanın birim alanına daha "
                        "az düşer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "B'nin şiddeti daha küçük ama masaya çok daha yakın: {} lx > {} lx. "
                    "Uzaklık karesiyle etki ettiği için yarı mesafe dört kat "
                    "aydınlanma demek."
                ).format(e_b, e_a),
                ipuclari=["İki aydınlanmayı karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("B lambası masanın üstüne bağlandı: {} lx (A olsaydı {} lx). "
                 "Kutudaki şiddet değeri değil, masadaki aydınlanma belirleyici."
                 ).format(e_b, e_a),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# KIRILMA: IŞIĞIN SÜRATİ ORTAMA BAĞLIDIR (B37.13 -- müfredat haritası)
#
# `kirilan_isik` iki satırda boştu (2018: 10; 2026: 11). Bağlam: "Fiber
# bağlantı veya su içindeki numunenin görüntüsünü yorumlama". `yaygin_yanlis`:
#
#   "Işığın her ortamda aynı süratle yayıldığını sanmak."
#
# DÜZENEK: iki karakol arasında fiber optik hat. Işık camda v = c / n ile
# yayılır. Sinyal gecikmesi hesabında c kullanan öğrenci gecikmeyi n kat
# küçük bulur. c = 300 000 km/s.
#
# YANILGININ SAYISAL KARŞILIĞI: fiberdeki sürate c yazmak ve gecikmeyi c ile
# hesaplamak ayrı teşhis alır.
# ==========================================================================

_ISIK_HIZI = 300000                     # km/s
_KIRILMA_INDISI = ((12, 10), (5, 4), (3, 2))   # n = pay / payda: 1,2; 1,25; 1,5


def _fiber_havuzu():
    """(n_pay, n_payda, uzunluk_km): gecikme (ms) en çok bir ondalık."""
    havuz = []
    for pay, payda in _KIRILMA_INDISI:
        v = _ISIK_HIZI * payda // pay
        for uzunluk in (300, 600, 900, 1200, 1500, 1800, 2400, 3000):
            if (uzunluk * 10000) % v or (uzunluk * 10000) % _ISIK_HIZI:
                continue
            havuz.append((pay, payda, uzunluk))
    return tuple(havuz)


_FIBER = _fiber_havuzu()


@bulmaca(ders="fizik", konu="kirilan_isik", kademeler=(10, 13), agirlik=1.3)
def fiber_hat(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Işık camda c / n ile yayılır; fiberdeki gecikme boşluktakinden n kat büyüktür."""
    pay, payda, uzunluk = rastgele.choice(_FIBER)
    n = pay / float(payda)
    v = _ISIK_HIZI * payda // pay
    gecikme = uzunluk * 1000.0 / v
    bosluk_gecikme = uzunluk * 1000.0 / _ISIK_HIZI
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-fiber-hat",
        ders="fizik",
        baslik="Fiber Hat",
        kademe=kademe,
        konu="kirilan_isik",
        kazanim="Işığın süratinin ortamın kırılma indisine bağlı olduğunu açıklama; "
                "v = c / n ile fiberdeki sürati ve sinyal gecikmesini hesaplama.",
        dikkat=7,
        brifing=(
            "Uzak gözlem karakolu üsse fiber optik hatla bağlandı. Uyarı "
            "sisteminin zamanlaması hattaki gecikmeye göre ayarlanacak.\n\n"
            "{} ayarı hazırladı: \"Işık her yerde saniyede 300 000 km gider. "
            "Gecikmeyi buna göre hesapladım.\"\n\n"
            "Zamanlama yüklenmeden önce hesabı denetlememiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Hat kaydı",
                  "Fiber hattın uzunluğu: {} km. Çekirdek camının kırılma indisi: "
                  "n = {}.".format(uzunluk, sy(n)),
                  bedel=1, kritik=True),
            Kanit("Işık notu",
                  "Işığın boşluktaki sürati c = 300 000 km/s. Kırılma indisi n "
                  "olan ortamda sürati v = c ÷ n.",
                  bedel=1, kritik=True),
            Kanit("Ölçüm",
                  "Test sinyalinin hattı geçme süresi ölçüldü; hesaplanan "
                  "gecikmeden uzun çıktı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Işığın fiberin camındaki sürati için hangisi doğru?",
                dogru="Boşluktakinden küçüktür: v = c ÷ n, indis büyüdükçe azalır",
                yanlislar={
                    ("Her ortamda aynıdır: 300 000 km/s, çünkü ışığın sürati evrensel bir "
                     "sabittir"):
                        "Işığın her ortamda aynı süratle yayıldığını sandın. "
                        "300 000 km/s boşluktaki sürat; camda ışık yavaşlar.",
                    "Boşluktakinden büyüktür: yoğun ortam ışığı hızlandırır":
                        "Tersi: kırılma indisi 1'den büyük ortamda sürat c ÷ n, "
                        "yani c'den küçük.",
                    ("Işığın rengine bağlıdır, ortama bağlı değildir; her rengin kendi "
                     "sürati vardır"):
                        "Sürat rengine göre biraz değişir ama asıl belirleyen "
                        "ortamın kırılma indisidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kırılma indisi, ışığın o ortamda boşluktakinden kaç kat yavaş "
                    "gittiğini söyler: n = c ÷ v. Işık ortam değiştirince sürati "
                    "değiştiği için kırılır; fiberin camında da yavaşlar."
                ),
                ipuclari=[
                    "Işık notundaki bağıntı hangi ortam için?",
                    "Kırılma indisi 1'den büyükse v, c'den büyük mü küçük mü?",
                ],
                cozum="v = c ÷ n\nt = L ÷ v",
            ),
            sayi_adimi(
                soru="Işığın fiberdeki sürati kaç km/s?",
                cevap=v,
                birim="km/s",
                aciklama="v = 300 000 ÷ {} = {} km/s.".format(sy(n), v),
                yaygin_yanlislar={
                    _ISIK_HIZI:
                        "Işığın her ortamda aynı süratle yayıldığını sandın; camda "
                        "sürat c ÷ n.",
                    _ISIK_HIZI * pay // payda:
                        "Kırılma indisiyle çarptın; bölmen gerekiyor: v = c ÷ n.",
                },
                ipuclari=["Işık notundaki bağıntıyı kullan."],
                puan=12,
            ),
            sayi_adimi(
                soru="Sinyal hattı kaç milisaniyede geçer?",
                cevap=gecikme,
                birim="ms",
                aciklama="t = {} km ÷ {} km/s = {} s = {} ms.".format(
                    uzunluk, v, sy(gecikme / 1000.0), sy(gecikme)),
                yaygin_yanlislar={
                    sy(bosluk_gecikme).replace(",", "."):
                        "Işığın her ortamda aynı süratle yayıldığını sandın: "
                        "gecikmeyi boşluktaki süratle hesapladın. Camda ışık {} "
                        "kat yavaş.".format(sy(n)),
                    sy(gecikme / 1000.0).replace(",", "."):
                        "Saniyeyi buldun ama milisaniyeye çevirmedin.",
                },
                ipuclari=["Önce fiberdeki sürati bul, sonra uzunluğu ona böl."],
                puan=14,
            ),
            secim_adimi(
                soru="Ölçülen gecikme neden hesaptan uzun çıktı?",
                dogru="Hesap ışığın boşluktaki süratini kullandı, oysa ışık camda {} kat yavaş".format(sy(n)),
                yanlislar={
                    ("Hat bozuk: ışık her ortamda aynı süratle gitmeliydi, gecikme ancak "
                     "arızadan gelir"):
                        "Işığın her ortamda aynı süratle yayıldığını sandın; hat "
                        "sağlam, ışık camda yavaşlıyor.",
                    "Işık fiberde hızlanıp yavaşlayarak ilerlediği için":
                        "Işığın camdaki sürati sabit: c ÷ n. Gecikmeyi bu sürat "
                        "belirler.",
                    ("Ölçüm aleti yanlış: fark ölçüm hatası, bu kadar kısa süre doğru "
                     "ölçülemez"):
                        "Fark rastgele değil, tam n kat -- kırılma indisinin izi.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Boşluk süratiyle hesap {} ms verir; camda gerçek gecikme {} ms. "
                    "Oran {}: kırılma indisi."
                ).format(sy(bosluk_gecikme), sy(gecikme), sy(n)),
                ipuclari=["Gecikmenin hesaptan kaç kat uzun olduğuna bak."],
                puan=10,
            ),
        ],
        kapanis=("Zamanlama düzeltildi: fiberde ışık {} km/s, gecikme {} ms (boşluk "
                 "süratiyle hesaplanan {} ms değil)."
                 ).format(v, sy(gecikme), sy(bosluk_gecikme)),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# YATAY ATIŞ: İKİ HAREKET AYNI SÜREYİ PAYLAŞIR (B37.13 -- müfredat haritası)
#
# `atis_hareketi` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Bir numune
# kapsülünün ideal hareket modelini inceleme". `yaygin_yanlis`:
#
#   "Yatay ve düşey hareket sürelerini bağımsız almak."
#
# DÜZENEK: dron sabit yükseklikte yatay uçarken numune kapsülünü bırakıyor
# (hava direnci ihmal, g = 10 m/s²). Kapsülün havada kalma süresini YALNIZ
# düşey hareket belirler: t = √(2h/g). Yatay yol aynı sürede v·t.
#
# YANILGININ SAYISAL KARŞILIĞI: süreyi yatay bilgiden türetmek (h ÷ v gibi)
# ya da "hızlı atılan daha uzun yol aldığı için daha geç düşer" demek ayrı
# teşhis alır. Havuz: t tam sayı (h = 5t²), yatay yol tam sayı.
# ==========================================================================

def _atis_havuzu():
    """(sure, hiz): s, m/s; yükseklik = 5·sure² m.

    Koşullar:
      1. Yatay yol (hız × süre) yüksekliğe eşit değil -- "yüksekliği yatay
         yol sanmak" teşhisi cevaba yapışmasın.
      2. Hız 5 m/s YOK: h = 5t² olduğundan h ÷ 5 = t² ve 5·t² = h -- iki
         teşhis çifti aynı sayıya düşerdi.
      3. "h ÷ v" çeldiricisi en çok iki ondalık ve süreden farklıysa kullanılır
         (koşul üreticide).
    """
    havuz = []
    for sure in (2, 3, 4):
        yukseklik = 5 * sure * sure
        for hiz in (8, 10, 12, 15, 20):
            if hiz * sure == yukseklik:
                continue
            havuz.append((sure, hiz))
    return tuple(havuz)


_ATIS = _atis_havuzu()


@bulmaca(ders="fizik", konu="atis_hareketi", kademeler=(11, 13), agirlik=1.3)
def kapsul_atisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yatay atışta uçuş süresini düşey hareket belirler; yatay yol = v · t."""
    sure, hiz = rastgele.choice(_ATIS)
    yukseklik = 5 * sure * sure
    menzil = hiz * sure
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    sure_yanlislari = {
        sure * sure:
            "√(2h/g) içindeki karekökü almadın.",
    }
    if (yukseklik * 100) % hiz == 0 and yukseklik / float(hiz) != sure:
        sure_yanlislari[sy(yukseklik / float(hiz)).replace(",", ".")] = (
            "Süreyi yatay hızdan türettin. Yatay ve düşey hareket AYNI süreyi "
            "paylaşır ve o süreyi düşey hareket belirler: t = √(2h/g).")

    return Bulmaca(
        kod="fiz-kapsul-atisi",
        ders="fizik",
        baslik="Kapsül Atışı",
        kademe=kademe,
        konu="atis_hareketi",
        kazanim="Yatay atışta yatay ve düşey hareketin aynı süreyi paylaştığını "
                "açıklama; uçuş süresini yükseklikten, yatay yolu bu süreden "
                "hesaplama.",
        dikkat=7,
        brifing=(
            "Keşif dronu, göl kıyısındaki ekibe numune kapsülü bırakacak. Dron "
            "sabit yükseklikte yatay uçuyor; kapsül bırakıldığı an dronun yatay "
            "hızıyla ayrılıyor.\n\n"
            "{} bırakma noktasını hesaplarken şunu yazdı: \"Kapsül yatayda da yol "
            "alacağı için havada, dümdüz düşen bir kapsülden daha uzun kalır. "
            "Hızı ne kadar büyükse o kadar geç yere değer.\"\n\n"
            "Bırakma noktası belirlenmeden önce kapsülün hareketini doğru "
            "modellememiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Uçuş kaydı",
                  "Dronun yerden yüksekliği: {} m. Yatay hızı: {} m/s. Hava direnci "
                  "ihmal edilecek; g = 10 m/s².".format(yukseklik, hiz),
                  bedel=1, kritik=True),
            Kanit("Deneme bırakışı",
                  "Aynı anda aynı yükseklikten iki kapsül: biri dronun hızıyla "
                  "bırakıldı, öbürü durgun bir kuleden dümdüz düşürüldü. İkisi yere "
                  "aynı anda değdi.",
                  bedel=1, kritik=True),
            Kanit("Hareket notu",
                  "Düşeyde: h = ½ · g · t². Yatayda (sabit hızla): x = v · t.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Kapsülün havada kalma süresini ne belirler?",
                dogru=("Yalnız düşey hareket (yükseklik ve g); yatay hız süreyi "
                       "değiştirmez"),
                yanlislar={
                    "Yatay hız: hızlı atılan daha uzun yol aldığı için havada daha uzun kalır":
                        "Yatay ve düşey hareket sürelerini bağımsız aldın. Deneme "
                        "bırakışında iki kapsül aynı anda yere değdi: yatay hız "
                        "düşüş süresini değiştirmiyor.",
                    "Yatay yol ile düşey yolun toplamı; uzun yolu katetmek uzun sürer":
                        "Süre yolların toplamından bulunmaz; düşey yükseklik ve g "
                        "belirler.",
                    "Yatay hız büyüdükçe süre kısalır, hızlı kapsül yere daha çabuk varır":
                        "Yatay hız düşeydeki hareketi etkilemez; süre aynı kalır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yatayda hiçbir kuvvet yok, düşeyde yalnız ağırlık var. İki "
                    "hareket birbirinden bağımsız ilerler ama AYNI saatle: kapsül "
                    "yere değdiği an ikisi birden biter. Bu yüzden süre düşeyden "
                    "bulunur, yatay yol o süreyle hesaplanır."
                ),
                ipuclari=[
                    "Deneme bırakışında iki kapsül ne zaman yere değdi?",
                    "Yatayda kapsüle bir kuvvet etki ediyor mu?",
                ],
                cozum="t = √(2h ÷ g)\nx = v · t",
            ),
            sayi_adimi(
                soru="Kapsül havada kaç saniye kalır?",
                cevap=sure,
                birim="s",
                aciklama="t = √(2 × {} ÷ 10) = √{} = {} s.".format(
                    yukseklik, sure * sure, sure),
                yaygin_yanlislar=sure_yanlislari,
                ipuclari=["Düşeydeki bağıntıyı süre için çöz."],
                puan=12,
            ),
            sayi_adimi(
                soru="Kapsül, bırakıldığı noktanın yatayda kaç metre ilerisine düşer?",
                cevap=menzil,
                birim="m",
                aciklama="x = {} m/s × {} s = {} m.".format(hiz, sure, menzil),
                yaygin_yanlislar={
                    hiz * sure * sure:
                        "Karekökü alınmamış süreyle çarptın; süre {} s.".format(sure),
                    yukseklik:
                        "Yüksekliği yatay yol sandın; yatay yol yatay hız ile "
                        "süreden bulunur.",
                },
                ipuclari=["Yatay hızı, düşey hareketten bulduğun süreyle çarp."],
                puan=12,
            ),
            secim_adimi(
                soru=("Dron aynı yükseklikte iki kat hızla uçarken bırakılan bir "
                      "kapsül için hangisi doğru?"),
                dogru="Yine {} saniyede düşer ama iki kat uzağa, {} m ileriye".format(
                    sure, 2 * menzil),
                yanlislar={
                    "Daha geç düşer, çünkü yatayda daha çok yol alır":
                        "Yatay ve düşey hareket sürelerini bağımsız aldın. Süreyi "
                        "yükseklik belirler; hız iki katına çıkınca yalnız yatay "
                        "yol iki katına çıkar.",
                    "Daha önce düşer ve aynı yere, {} m ileriye düşer".format(menzil):
                        "Süre değişmez; hız iki katına çıkınca aynı sürede iki kat "
                        "yol alınır.",
                    "Yine {} saniyede düşer ve aynı yere, {} m ileriye düşer".format(sure, menzil):
                        "Süre doğru, ama iki kat hızla aynı sürede iki kat yol "
                        "alınır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Düşey hareket değişmedi: t = {} s. Yatayda hız iki katına çıktı: "
                    "x = {} × {} = {} m."
                ).format(sure, 2 * hiz, sure, 2 * menzil),
                ipuclari=["Hangi büyüklük süreyi belirliyordu?"],
                puan=12,
            ),
        ],
        kapanis=("Bırakma noktası hedeften {} m önceye işaretlendi; kapsül {} saniyede "
                 "iner. Dron hızlanırsa yalnız bu mesafe değişir, süre değişmez."
                 ).format(menzil, sure),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# ELEKTRİK ALAN VE TEST YÜKÜNE ETKİ EDEN KUVVET (B37.13 -- müfredat haritası)
#
# `elektrik_alan` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "İdeal
# yüklü parçacık modelinde kuvvet yönünü belirleme". `yaygin_yanlis`:
#
#   "Alanla test yüküne etki eden kuvveti eşitlemek."
#
# DÜZENEK: yüklü bir kürenin yakınındaki P noktasına sonda iki farklı test
# yükü koyuyor. Alan P'nin özelliği: E = F ÷ q, iki ölçümde aynı. Kuvvet ise
# konan yüke bağlı: F = q · E. Negatif yükte kuvvet alanın tersi yönünde.
# Birimler: yük μC, kuvvet mN -> E = (F ÷ q) × 1000 N/C.
#
# YANILGININ SAYISAL KARŞILIĞI: alana kuvveti yazmak; ikinci yükün kuvvetini
# birincininkiyle aynı saymak. İkisi de ayrı teşhis alır.
# ==========================================================================

def _alan_havuzu():
    """(q1, f1, q2): μC, mN, μC.

    Koşullar:
      1. E = 1000·f1/q1 TAM SAYI; f2 = q2·f1/q1 TAM SAYI.
      2. q1 ≥ 2: q1 = 1 olsaydı "birimi çevirmeden f1 ÷ q1" ile f1 çakışırdı.
      3. q2 ≠ q1: yoksa "aynı kuvvet" yanılgısı doğru cevapla çakışır.
    """
    havuz = []
    for q1 in (2, 4, 5):
        for f1 in range(4, 41, 2):
            if f1 % q1:
                continue
            for q2 in (1, 3, 6, 8, 10):
                if q2 == q1 or (q2 * f1) % q1:
                    continue
                havuz.append((q1, f1, q2))
    return tuple(havuz)


_ALAN = _alan_havuzu()


@bulmaca(ders="fizik", konu="elektrik_alan", kademeler=(11, 13), agirlik=1.3)
def yuk_sondasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Alan noktanın özelliğidir (E = F/q); kuvvet konan yüke bağlıdır (F = qE)."""
    q1, f1, q2 = rastgele.choice(_ALAN)
    alan = 1000 * f1 // q1
    f2 = q2 * f1 // q1
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-yuk-sondasi",
        ders="fizik",
        baslik="Yük Sondası",
        kademe=kademe,
        konu="elektrik_alan",
        kazanim="Elektrik alanı test yüküne etki eden kuvvetten ayırt etme; E = F ÷ q "
                "ile alanı, F = q · E ile başka bir yüke etki eden kuvveti bulma; "
                "negatif yükte kuvvetin yönünü belirleme.",
        dikkat=7,
        brifing=(
            "Laboratuvardaki yüklü kürenin çevresi bir sondayla haritalanıyor. "
            "Sonda P noktasına önce bir, sonra başka bir test yükü koydu.\n\n"
            "{} haritaya ilk ölçümün kuvvetini yazdı: \"P'deki alan budur. İkinci "
            "yük de aynı noktada olduğuna göre ona da aynı kuvvet etki eder.\"\n\n"
            "Harita yayımlanmadan önce ölçümleri doğru yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("1. ölçüm",
                  "P noktasına +{} μC test yükü kondu; yüke küreden dışarı doğru "
                  "{} mN kuvvet etki etti.".format(q1, f1),
                  bedel=1, kritik=True),
            Kanit("2. test yükü",
                  "Aynı P noktasına +{} μC yük konacak; kuvveti henüz ölçülmedi."
                  .format(q2),
                  bedel=1, kritik=True),
            Kanit("Alan notu",
                  "Elektrik alan: E = F ÷ q (N/C). 1 mN = 0,001 N; 1 μC = "
                  "0,000001 C. Pozitif yüke kuvvet alan yönünde, negatif yüke "
                  "alanın tersi yönünde etki eder.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="P noktasındaki elektrik alan ile oraya konan yüke etki eden kuvvet için hangisi doğru?",
                dogru=("Alan P noktasının özelliğidir; kuvvet oraya konan yüke "
                       "bağlıdır: F = q · E"),
                yanlislar={
                    "Alan ile kuvvet aynıdır; bir noktada tek bir kuvvet vardır":
                        "Alanla test yüküne etki eden kuvveti eşitledin. Aynı noktaya "
                        "farklı yük konunca kuvvet değişir, alan değişmez.",
                    "Alan test yüküne bağlıdır: büyük test yükü büyük alan oluşturur":
                        "Alanı kaynak yük oluşturur; test yükü alanı yalnız ölçer "
                        "(ve küçük tutulur ki alanı bozmasın).",
                    ("Kuvvet konan yükten bağımsızdır; P noktasındaki kuvveti alanı yaratan "
                     "yük belirler"):
                        "F = q · E: yük iki katına çıkarsa kuvvet de iki katına çıkar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Elektrik alan, bir noktaya BİRİM yük konsa ona etki edecek "
                    "kuvvettir; noktanın özelliğidir. Gerçek bir yük konunca kuvvet "
                    "yükle orantılıdır: F = q · E."
                ),
                ipuclari=[
                    "Aynı noktaya iki kat yük konsa kuvvet ne olur?",
                    "Alan notundaki bağıntı neyi neye bölüyor?",
                ],
                cozum="E = F ÷ q\nF₂ = q₂ · E",
            ),
            sayi_adimi(
                soru="P noktasındaki elektrik alan kaç N/C?",
                cevap=alan,
                birim="N/C",
                aciklama="E = 0,001 × {} N ÷ (0,000001 × {} C) = {} N/C.".format(
                    f1, q1, alan),
                yaygin_yanlislar={
                    f1:
                        "Alanla test yüküne etki eden kuvveti eşitledin; kuvveti "
                        "yüke bölmelisin.",
                    f1 // q1:
                        "Böldün ama birimleri çevirmedin: mN ÷ μC, N/C değil.",
                },
                ipuclari=["Kuvveti N'ye, yükü C'ye çevirip böl."],
                puan=12,
            ),
            sayi_adimi(
                soru="İkinci yüke P noktasında kaç mN kuvvet etki eder?",
                cevap=f2,
                birim="mN",
                aciklama="F₂ = q₂ · E = 0,000001 × {} C × {} N/C = {} mN.".format(
                    q2, alan, f2),
                yaygin_yanlislar={
                    f1:
                        "Alanla kuvveti eşitledin: aynı noktada olduğu için aynı "
                        "kuvvet sandın. Alan aynı, yük farklı; kuvvet yükle orantılı.",
                    alan:
                        "Alanın değerini yazdın; kuvvet için yükle çarpmalısın.",
                },
                ipuclari=["Aynı alan, farklı yük."],
                puan=12,
            ),
            secim_adimi(
                soru="Aynı noktaya −{} μC yük konsaydı kuvvet için hangisi doğru olurdu?".format(q2),
                dogru="{} mN, küreye doğru (alanın tersi yönünde)".format(f2),
                yanlislar={
                    "{} mN, küreden dışarı doğru (alanla aynı yönde)".format(f2):
                        "Negatif yüke kuvvet alanın TERSİ yönünde etki eder.",
                    "{} mN, küreye doğru".format(f1):
                        "Alanla kuvveti eşitledin: büyüklük yüke bağlı, {} mN."
                        .format(f2),
                    "Kuvvet olmaz; negatif yük alanı yok eder":
                        "Test yükü alanı yok etmez; alanı kaynak küre oluşturur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Büyüklük yükün işaretine bağlı değil: {} mN. Yön ise işarete "
                    "bağlı: alan küreden dışarı doğru, negatif yüke kuvvet küreye "
                    "doğru."
                ).format(f2),
                ipuclari=["Alan notunda negatif yük için ne yazıyor?"],
                puan=12,
            ),
        ],
        kapanis=("Haritaya P noktası için alan yazıldı: {} N/C, küreden dışarı. "
                 "+{} μC yüke {} mN, +{} μC yüke {} mN -- alan aynı, kuvvet yükle "
                 "değişiyor.").format(alan, q1, f1, q2, f2),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# İNDÜKLENME: GERİLİMİ AKI DEĞİL, AKININ DEĞİŞİMİ OLUŞTURUR (B37.13)
#
# `induksiyon` iki satırda boştu (2018: 11; 2026: 11). Bağlam: "Jeneratör
# modelinin hareket ve gerilim ilişkisini açıklama". `yaygin_yanlis`:
#
#   "Sabit akıyla değişen akıyı aynı sonuç verir sanmak."
#
# DÜZENEK: bobinli jeneratör modeli üç evreden geçiyor: (1) mıknatıs bobinin
# içinde DURUYOR -- akı büyük ama sabit; (2) mıknatıs Δt sürede çekiliyor --
# akı değişiyor; (3) aynı akı değişimi yarı sürede. Faraday: ε = N · ΔΦ / Δt.
# Birimler: mWb ÷ ms = V.
#
# YANILGININ SAYISAL KARŞILIĞI: duran mıknatısta 2. evrenin gerilimini ya da
# N · Φ'yi yazmak; hızlı çekmede gerilimin aynı kalacağını sanmak. Hepsi ayrı
# teşhis alır.
# ==========================================================================

def _induksiyon_havuzu():
    """(sarim, aki_mwb, sure_ms).

    Koşullar:
      1. ε = N · ΔΦ / Δt TAM SAYI, 2-200 V; yarı sürede 2ε.
      2. "Sarımı unutmak" (ΔΦ / Δt, V) en çok iki ondalık ve ε'dan farklı.
      3. N · ΔΦ (Δt'ye bölmemek) ε'dan farklı.
    """
    havuz = []
    for sarim in (50, 100, 200, 400):
        for aki in (2, 4, 5, 6, 8, 10):
            for sure in (10, 20, 40, 50, 100):
                if (sarim * aki) % sure or (aki * 100) % sure:
                    continue
                emk = sarim * aki // sure
                if not 2 <= emk <= 200 or sarim * aki == emk:
                    continue
                havuz.append((sarim, aki, sure))
    return tuple(havuz)


_INDUKSIYON = _induksiyon_havuzu()


@bulmaca(ders="fizik", konu="induksiyon", kademeler=(11, 13), agirlik=1.3)
def jenerator_modeli(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İndüklenen gerilim akının DEĞİŞİM hızına bağlıdır: ε = N · ΔΦ / Δt."""
    sarim, aki, sure = rastgele.choice(_INDUKSIYON)
    emk = sarim * aki // sure
    emk_hizli = 2 * emk
    sarimsiz = aki / float(sure)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-jenerator-modeli",
        ders="fizik",
        baslik="Jeneratör Modeli",
        kademe=kademe,
        konu="induksiyon",
        kazanim="İndüklenen gerilimin akının kendisine değil değişim hızına bağlı "
                "olduğunu açıklama; ε = N · ΔΦ ÷ Δt ile gerilimi hesaplama.",
        dikkat=7,
        brifing=(
            "Atölyede küçük bir jeneratör modeli kuruldu: bobin ve içine sokulan "
            "güçlü bir mıknatıs. Voltmetre bobinin uçlarına bağlı.\n\n"
            "{} deney planına şunu yazdı: \"Mıknatısı bobinin içine koyup "
            "bekletelim. Akı en büyük olduğu için en yüksek gerilimi o zaman "
            "ölçeriz; mıknatısı çekmek bir şey değiştirmez.\"\n\n"
            "Deneye başlamadan önce üç evrede voltmetrenin ne göstereceğini "
            "bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Bobin kaydı",
                  "Sarım sayısı: {}. Mıknatıs bobinin içindeyken bobinden geçen "
                  "akı {} mWb; mıknatıs çıkınca 0.".format(sarim, aki),
                  bedel=1, kritik=True),
            Kanit("Deney planı",
                  "1. evre: mıknatıs bobinin içinde 5 saniye hareketsiz.\n"
                  "2. evre: mıknatıs dışarı çekiliyor; çekme süresi {} milisaniye.\n"
                  "3. evre: mıknatıs yeniden sokulup bu kez yarı sürede çekiliyor."
                  .format(sure),
                  bedel=1, kritik=True),
            Kanit("Faraday notu",
                  "İndüklenen gerilim: ε = N · ΔΦ ÷ Δt. 1 mWb ÷ 1 ms = 1 V.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bobinde gerilim hangi durumda indüklenir?",
                dogru="Bobinden geçen akı DEĞİŞİRKEN; büyük ama sabit akı gerilim vermez",
                yanlislar={
                    "Akı büyük olduğu sürece; mıknatıs içerideyken en büyük gerilim oluşur":
                        "Sabit akıyla değişen akıyı aynı sonucu verir sandın. "
                        "Faraday bağıntısında akının kendisi değil DEĞİŞİMİ var: "
                        "ΔΦ = 0 ise ε = 0.",
                    "Mıknatıs bobinin içinde olduğu her an; hareket önemsizdir":
                        "Hareket önemli: akıyı değiştiren şey mıknatısın "
                        "hareketi.",
                    ("Yalnız mıknatıs sokulurken; çekerken gerilim oluşmaz, mıknatıs bobini "
                     "terk ediyordur"):
                        "Çekerken de akı değişir (azalır); gerilim ters yönde "
                        "indüklenir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Faraday yasası akının değişim hızını ölçer. Mıknatıs duruyorsa "
                    "akı ne kadar büyük olursa olsun değişmiyor: gerilim sıfır. "
                    "Jeneratör bu yüzden döner; sürekli değişen akı sürekli "
                    "gerilim demek."
                ),
                ipuclari=[
                    "Faraday notunda akının kendisi mi, değişimi mi var?",
                    "1. evrede akı zamanla değişiyor mu?",
                ],
                cozum="ε = N · ΔΦ ÷ Δt\nΔΦ = 0 -> ε = 0",
            ),
            sayi_adimi(
                soru="1. evrede (mıknatıs hareketsiz) voltmetre kaç V gösterir?",
                cevap=0,
                birim="V",
                aciklama="Akı değişmiyor: ΔΦ = 0, dolayısıyla ε = 0 V.",
                yaygin_yanlislar={
                    emk:
                        "Sabit akıyla değişen akıyı aynı sonucu verir sandın; bu, "
                        "mıknatıs çekilirken indüklenen gerilim. Dururken akı "
                        "değişmez.",
                    sarim * aki:
                        "Akıyı sarım sayısıyla çarptın; gerilimi akı değil akının "
                        "değişimi oluşturur.",
                },
                ipuclari=["Bu evrede ΔΦ kaç?"],
                puan=12,
            ),
            sayi_adimi(
                soru="2. evrede (mıknatıs çekilirken) indüklenen gerilim kaç V?",
                cevap=emk,
                birim="V",
                aciklama="ε = {} × {} mWb ÷ {} ms = {} V.".format(sarim, aki, sure, emk),
                yaygin_yanlislar={
                    sarim * aki:
                        "Süreye bölmedin: ε = N · ΔΦ ÷ Δt.",
                    sy(sarimsiz).replace(",", "."):
                        "Sarım sayısını hesaba katmadın; her sarımda aynı gerilim "
                        "indüklenir ve toplanır.",
                },
                ipuclari=["Faraday notundaki bağıntıyı kullan."],
                puan=12,
            ),
            secim_adimi(
                soru="3. evrede (aynı akı değişimi yarı sürede) gerilim için hangisi doğru?",
                dogru="İki katına çıkar: {} V, çünkü akı iki kat hızla değişiyor".format(emk_hizli),
                yanlislar={
                    "Aynı kalır: {} V, çünkü akı değişimi aynı".format(emk):
                        "Gerilimi akı değişiminin miktarı değil HIZI belirler; "
                        "yarı sürede aynı değişim iki kat hız demek.",
                    "Yarıya iner: {} V, çünkü mıknatıs daha kısa süre hareket eder".format(sy(emk / 2.0)):
                        "Süre kısalınca ΔΦ ÷ Δt büyür; gerilim artar.",
                    "Sıfır olur, çünkü mıknatıs sonunda yine dışarıda":
                        "Başta ve sonda akı aynı değil: içeride {} mWb, dışarıda 0."
                        .format(aki),
                },
                rastgele=rastgele,
                aciklama=(
                    "Aynı ΔΦ yarı sürede gerçekleşince ΔΦ ÷ Δt iki katına çıkar: "
                    "ε = {} V. Jeneratörü hızlı çevirmek bu yüzden daha yüksek "
                    "gerilim verir."
                ).format(emk_hizli),
                ipuclari=["Δt yarıya inince ΔΦ ÷ Δt ne olur?"],
                puan=12,
            ),
        ],
        kapanis=("Deney planı düzeltildi: mıknatıs dururken 0 V, {} milisaniyede "
                 "çekilince {} V, yarı sürede {} V. Ölçüm hareket sırasında yapılacak."
                 ).format(sure, emk, emk_hizli),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# İNCE KENARLI MERCEK: GÖRÜNTÜ CİSMİN YERİNE BAĞLIDIR (B37.13)
#
# `mercek` iki satırda boştu (2018: 10; 2026: 11). Bağlam: "Sefer gözlem
# aracındaki merceği seçme". `yaygin_yanlis`:
#
#   "İnce kenarlı merceğin her koşulda büyük gerçek görüntü verdiğini sanmak."
#
# DÜZENEK: gözlem aracının ince kenarlı merceği tezgâhta üç konumla deneniyor:
#   A) cisim f ile 2f arasında -> büyük, ters, gerçek (ekrana düşer);
#   B) cisim 2f'nin ötesinde -> KÜÇÜK, ters, gerçek;
#   C) cisim odak içinde -> büyük, düz, SANAL (ekrana düşmez).
# 1/f = 1/d_c + 1/d_g; sayılar tam (havuz).
#
# YANILGININ SAYISAL KARŞILIĞI: B'de büyütmeyi ters orandan (d_c/d_g > 1)
# bulmak; C'de ekranda büyük gerçek görüntü beklemek. İkisi de teşhisli.
# ==========================================================================

def _mercek_havuzu():
    """(odak, cisim_a, cisim_b): cm. Görüntü uzaklıkları formülden.

    Koşullar:
      1. A ve B'nin görüntü uzaklıkları TAM SAYI; A'nınki en çok 100 cm.
      2. B'nin büyütmesi (d_g/d_c) ve tersi en çok iki ondalık.
    """
    havuz = []
    for odak in (10, 12, 15, 20):
        for cisim_a in range(odak + 1, 2 * odak):
            if (odak * cisim_a) % (cisim_a - odak):
                continue
            if odak * cisim_a // (cisim_a - odak) > 100:
                continue
            for cisim_b in range(2 * odak + 1, 6 * odak + 1):
                if (odak * cisim_b) % (cisim_b - odak):
                    continue
                goruntu_b = odak * cisim_b // (cisim_b - odak)
                if (goruntu_b * 100) % cisim_b or (cisim_b * 100) % goruntu_b:
                    continue
                havuz.append((odak, cisim_a, cisim_b))
    return tuple(havuz)


_MERCEK = _mercek_havuzu()


@bulmaca(ders="fizik", konu="mercek", kademeler=(10, 13), agirlik=1.3)
def gozlem_mercegi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """İnce kenarlı mercekte görüntünün türü ve büyüklüğü cismin konumuna bağlıdır."""
    odak, cisim_a, cisim_b = rastgele.choice(_MERCEK)
    goruntu_a = odak * cisim_a // (cisim_a - odak)
    goruntu_b = odak * cisim_b // (cisim_b - odak)
    buyutme_b = goruntu_b / float(cisim_b)
    cisim_c = odak // 2
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-gozlem-mercegi",
        ders="fizik",
        baslik="Gözlem Merceği",
        kademe=kademe,
        konu="mercek",
        kazanim="İnce kenarlı mercekte cismin odağa göre konumundan görüntünün "
                "gerçek/sanal, büyük/küçük olduğunu belirleme; mercek bağıntısıyla "
                "görüntü uzaklığını ve büyütmeyi hesaplama.",
        dikkat=7,
        brifing=(
            "Sefer gözlem aracına ince kenarlı bir mercek takılacak. Tezgâhta "
            "numune üç farklı uzaklığa kondu, ekran görüntüyü yakalamaya çalıştı.\n\n"
            "{} seçim formuna şunu yazdı: \"İnce kenarlı mercek büyüteçtir; numune "
            "nereye konursa konsun ekranda büyük bir görüntü verir.\"\n\n"
            "Mercek araca takılmadan önce üç denemeyi doğru yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Mercek etiketi", "İnce kenarlı mercek, odak uzaklığı {} cm.".format(odak),
                  bedel=1, kritik=True),
            Kanit("Tezgâh denemeleri",
                  "A) Numune mercekten {} cm uzakta.\nB) Numune mercekten {} cm "
                  "uzakta.\nC) Numune mercekten {} cm uzakta; ekran nereye konsa "
                  "görüntü yakalanamadı.".format(cisim_a, cisim_b, cisim_c),
                  bedel=1, kritik=True),
            Kanit("Mercek notu",
                  "1/f = 1/d_cisim + 1/d_görüntü. Büyütme = d_görüntü ÷ d_cisim. "
                  "Gerçek görüntü ekrana düşer; sanal görüntü düşmez.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İnce kenarlı merceğin verdiği görüntü için hangisi doğru?",
                dogru=("Cismin odağa göre yerine bağlı: odak dışında gerçek ve ters, "
                       "içinde sanal ve düz"),
                yanlislar={
                    ("Her koşulda büyük ve gerçek görüntü verir, çünkü ince kenarlı mercek "
                     "ışığı toplayıp büyütür"):
                        "İnce kenarlı merceğin her koşulda büyük gerçek görüntü "
                        "verdiğini sandın. C denemesinde ekrana görüntü düşmedi; "
                        "B'de görüntü küçük.",
                    "Her koşulda küçük ve gerçek görüntü verir, çünkü ışığı bir noktaya toplar":
                        "Cisim f ile 2f arasındayken görüntü büyür; A denemesi bunu "
                        "gösteriyor.",
                    "Her koşulda sanal görüntü verir; ekrana hiç düşmez":
                        "Cisim odak dışındayken görüntü gerçek ve ekrana düşer.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Görüntünün türünü cismin odağa göre konumu belirler. Odak "
                    "dışında ışınlar mercekten sonra kesişir: gerçek görüntü. Odak "
                    "içinde ışınlar ayrılarak çıkar, uzantıları kesişir: sanal "
                    "görüntü. Büyüklük d_görüntü ÷ d_cisim ile değişir."
                ),
                ipuclari=[
                    "C denemesinde ekran neden görüntü yakalayamadı?",
                    "B'de numune 2f'nin ötesinde mi?",
                ],
                cozum="1/d_g = 1/f − 1/d_c\nBüyütme = d_g ÷ d_c",
            ),
            sayi_adimi(
                soru="A denemesinde net görüntü için ekran mercekten kaç cm uzağa konmalı?",
                cevap=goruntu_a,
                birim="cm",
                aciklama="1/d_g = 1/{} − 1/{} -> d_g = {} × {} ÷ ({} − {}) = {} cm.".format(
                    odak, cisim_a, odak, cisim_a, cisim_a, odak, goruntu_a),
                yaygin_yanlislar={
                    cisim_a:
                        "Cismin uzaklığını yazdın; görüntü uzaklığı mercek "
                        "bağıntısından bulunur.",
                    odak:
                        "Odak uzaklığını yazdın; görüntü odakta yalnız çok uzaktaki "
                        "cisimlerde oluşur.",
                },
                ipuclari=["Mercek notundaki bağıntıyı görüntü uzaklığı için çöz."],
                puan=12,
            ),
            sayi_adimi(
                soru="B denemesinde görüntünün büyütmesi kaçtır?",
                cevap=buyutme_b,
                aciklama=("d_g = {} × {} ÷ ({} − {}) = {} cm. Büyütme = {} ÷ {} = {} "
                          "-- görüntü cisimden KÜÇÜK.").format(
                              odak, cisim_b, cisim_b, odak, goruntu_b,
                              goruntu_b, cisim_b, sy(buyutme_b)),
                yaygin_yanlislar={
                    sy(cisim_b / float(goruntu_b)).replace(",", "."):
                        "Oranı ters kurdun ve görüntüyü büyük buldun. İnce kenarlı "
                        "merceğin her koşulda büyük görüntü verdiğini sanma: cisim "
                        "2f'nin ötesindeyse görüntü küçüktür.",
                    1:
                        "Görüntüyü cisimle aynı boyda saydın; bu yalnız cisim tam "
                        "2f'deyken olur.",
                },
                ipuclari=["Önce B için görüntü uzaklığını bul."],
                puan=14,
            ),
            secim_adimi(
                soru="C denemesinde ekranda neden görüntü yakalanamadı?",
                dogru="Numune odak içinde: görüntü sanal ve düz; ekrana düşmez",
                yanlislar={
                    "Ekran yanlış yerdeydi; büyük gerçek görüntü doğru yerde yakalanırdı":
                        "İnce kenarlı merceğin her koşulda büyük gerçek görüntü "
                        "verdiğini sandın. Odak içindeki cismin görüntüsü sanaldır.",
                    "Görüntü küçük ve ters olduğu için görülemedi":
                        "Odak içinde görüntü küçük ve ters değil, büyük ve düz -- "
                        "ama sanal.",
                    "Odak içinde hiç görüntü oluşmaz; mercekten bakınca da görülmez":
                        "Görüntü oluşur ama sanaldır: mercekten bakınca büyük ve düz "
                        "görülür. Büyüteç böyle çalışır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "C'de numune ({} cm) odağın ({} cm) içinde. Işınlar mercekten "
                    "ayrılarak çıkıyor; ekranda kesişmiyorlar. Göz, uzantıların "
                    "kesiştiği yerde büyük ve düz bir sanal görüntü görür."
                ).format(cisim_c, odak),
                ipuclari=["Numune odağın içinde mi, dışında mı?"],
                puan=12,
            ),
        ],
        kapanis=("Seçim formu düzeltildi: A'da ekran {} cm uzakta, görüntü büyük "
                 "ve ters; B'de büyütme {}, görüntü küçük ve ters; C'de sanal, "
                 "ekrana düşmeyen büyük görüntü. Araçta numune odak dışında tutulacak."
                 ).format(goruntu_a, sy(buyutme_b)),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# IŞIK RENKLERİ VE BOYA RENKLERİ (B37.13 -- müfredat haritası)
#
# `renk` iki satırda boştu (2018: 10; 2026: 12). Bağlam: "Depo uyarı
# levhasının farklı ışıkta görünüşünü açıklama". `yaygin_yanlis`:
#
#   "Işık renkleriyle boya renklerini aynı toplama kuralıyla değerlendirmek."
#
# MODEL: renkler kırmızı (K), yeşil (Y), mavi (M) bileşenlerinin kümesi.
#   * Işıklar karışınca bileşenler BİRLEŞİR (toplamsal): K + Y = sarı.
#   * Boya bazı bileşenleri yansıtır; aydınlatılan cisim YANSITTIĞI ile
#     AYDINLATAN ışığın KESİŞİMİ renginde görünür (kesişim boşsa siyah).
# Yanılgı iki yönlü: ışıkları boya gibi "koyulaştırmak" ya da boyalı cismin
# rengini ışıktan bağımsız sanmak. Her şık bu kümelerden hesaplanır.
# ==========================================================================

_RENK_ADI = {
    frozenset(): "siyah", frozenset("K"): "kırmızı", frozenset("Y"): "yeşil",
    frozenset("M"): "mavi", frozenset("KY"): "sarı", frozenset("YM"): "camgöbeği",
    frozenset("KM"): "magenta", frozenset("KYM"): "beyaz",
}
_ADDAN_RENK = {ad: kume for kume, ad in _RENK_ADI.items()}
_ANA_ISIKLAR = ("kırmızı", "yeşil", "mavi")


def _levha_havuzu():
    """(yazi_boyasi, zemin_boyasi, okunmaz_isik).

    Koşul: üç ana renkli ışıktan TAM OLARAK BİRİNDE yazı ile zemin aynı renkte
    görünür (yazı okunmaz); beyaz ışıkta ise farklıdır.
    """
    boyalar = [ad for ad in _ADDAN_RENK if ad not in ("siyah", "beyaz")]
    havuz = []
    for yazi in boyalar:
        for zemin in boyalar:
            if yazi == zemin:
                continue
            esit = [isik for isik in _ANA_ISIKLAR
                    if _ADDAN_RENK[yazi] & _ADDAN_RENK[isik]
                    == _ADDAN_RENK[zemin] & _ADDAN_RENK[isik]]
            if len(esit) == 1:
                havuz.append((yazi, zemin, esit[0]))
    return tuple(havuz)


_LEVHA = _levha_havuzu()


def _gorunen(boya, isik):
    return _RENK_ADI[frozenset(_ADDAN_RENK[boya] & _ADDAN_RENK[isik])]


@bulmaca(ders="fizik", konu="renk", kademeler=(10, 13), agirlik=1.3)
def uyari_levhasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Işıklar toplanır; boyalı cisim yansıttığı ile aydınlatanın kesişimi renginde görünür."""
    yazi, zemin, okunmaz = rastgele.choice(_LEVHA)
    isik1, isik2 = rastgele.sample(_ANA_ISIKLAR, 2)
    karisim = _RENK_ADI[frozenset(_ADDAN_RENK[isik1] | _ADDAN_RENK[isik2])]
    deneme_isigi = rastgele.choice([i for i in _ANA_ISIKLAR if i != okunmaz])
    zemin_gorunen = _gorunen(zemin, deneme_isigi)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    zemin_yanlislari = {}
    for aday, teshis in (
            (zemin, "Cismin rengini ışıktan bağımsız sandın. Boya yalnız aydınlatan "
                    "ışıkta bulunan bileşenleri yansıtabilir."),
            (deneme_isigi, "Levhanın ışığın rengini aldığını sandın; boya ışığın "
                           "yansıtmadığı bileşenlerini soğurur."),
            ("beyaz", "Beyaz görünmesi için bütün bileşenlerin yansıması gerekir; "
                      "tek renkli ışıkta bu olmaz.")):
        if aday != zemin_gorunen and aday not in zemin_yanlislari:
            zemin_yanlislari[aday] = teshis
    if zemin_gorunen != "siyah" and "siyah" not in zemin_yanlislari:
        zemin_yanlislari["siyah"] = ("Boya bu ışığın bileşenini yansıtıyor; siyah "
                                     "yalnız hiçbir bileşen yansımazsa görünür.")

    return Bulmaca(
        kod="fiz-uyari-levhasi",
        ders="fizik",
        baslik="Uyarı Levhası",
        kademe=kademe,
        konu="renk",
        kazanim="Işık renklerinin toplamsal karışımını boyaların ışığı soğurmasından "
                "ayırt etme; renkli ışık altında boyalı bir yüzeyin rengini ve "
                "okunabilirliğini belirleme.",
        dikkat=7,
        brifing=(
            "Depo girişindeki uyarı levhası gece renkli projektörlerle "
            "aydınlatılacak. Levhanın zemini {} boyalı, yazısı {} boyalı.\n\n"
            "{} ışık planını yazdı: \"Renkler her yerde aynı karışır; boyayı "
            "karıştırınca nasıl koyulaşıyorsa ışıkları karıştırınca da öyle olur. "
            "Levha zaten boyalı, hangi ışığı tutsak rengi değişmez.\"\n\n"
            "Projektörler takılmadan önce levhanın farklı ışıklarda nasıl "
            "görüneceğini bulmamız gerekiyor."
        ).format(zemin, yazi, kisi),
        kanitlar=[
            Kanit("Renk modeli",
                  "Işık bileşenleri: kırmızı (K), yeşil (Y), mavi (M).\n"
                  "Boyaların yansıttığı bileşenler: kırmızı K; yeşil Y; mavi M; "
                  "sarı K+Y; camgöbeği Y+M; magenta K+M.",
                  bedel=1, kritik=True),
            Kanit("Işık karışımı notu",
                  "İki renkli ışık aynı beyaz yüzeye tutulursa bileşenleri "
                  "birleşir: K+Y sarı, Y+M camgöbeği, K+M magenta, K+Y+M beyaz.",
                  bedel=1, kritik=True),
            Kanit("Boya notu",
                  "Boyalı yüzey, aydınlatan ışıkta bulunan bileşenlerden yalnız "
                  "kendi yansıttıklarını geri verir; hiçbirini yansıtmıyorsa siyah "
                  "görünür.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Işıkların karışması ile boyalı bir yüzeyin rengi için hangisi doğru?",
                dogru=("Işıklar karışınca toplanır; boya gelen ışıktan yalnız kendi "
                       "bileşenlerini yansıtır"),
                yanlislar={
                    "Işıklar da boyalar gibi karışır: iki renkli ışık daha koyu bir renk verir":
                        "Işık renkleriyle boya renklerini aynı kurala bağladın. "
                        "Işıklar üst üste gelince bileşenler EKLENİR ve renk açılır; "
                        "boyalar ise ışığı soğurur.",
                    ("Boyalı yüzeyin rengi aydınlatan ışıktan bağımsızdır; kırmızı boya her "
                     "ışıkta kırmızıdır"):
                        "Boya ışık üretmez; yalnız gelen ışıktan bir kısmını yansıtır. "
                        "Gelen ışıkta o bileşen yoksa yansıtamaz.",
                    "Boyalar da ışıklar gibi toplanır: kırmızı ve yeşil boya sarı verir":
                        "Işık kuralını boyaya uyguladın. Boyalar karışınca her biri "
                        "bazı bileşenleri soğurur; sonuç koyulaşır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Işıkta renk bileşenleri eklenir: kırmızı + yeşil ışık sarı "
                    "görünür. Boyalı yüzeyde ise gelen ışığın bir kısmı soğurulur: "
                    "görünen renk, gelen ışıkla boyanın yansıttıklarının ortak "
                    "kısmıdır."
                ),
                ipuclari=[
                    "Işık karışımı notu bileşenlere ne oluyor diyor?",
                    "Boya kendisi ışık üretir mi?",
                ],
                cozum="Işık karışımı: birleşim.\nBoyalı yüzey: ışık ∩ boya.",
            ),
            secim_adimi(
                soru=("Beyaz duvarda {} ve {} projektörler aynı noktaya tutulunca "
                      "nokta hangi renkte görünür?").format(isik1, isik2),
                dogru=karisim,
                yanlislar={
                    "koyu kahverengi":
                        "Işık renkleriyle boya renklerini aynı kurala bağladın; "
                        "ışıklar karışınca koyulaşmaz, bileşenleri birleşir.",
                    isik1: "Yalnız bir projektörün rengini yazdın; iki ışık birleşiyor.",
                    "beyaz": "Beyaz için üç bileşenin de gelmesi gerekir; burada iki var.",
                },
                rastgele=rastgele,
                aciklama="Işık karışımı: {} + {} = {}.".format(isik1, isik2, karisim),
                ipuclari=["İki ışığın bileşenlerini birleştir."],
                puan=12,
            ),
            secim_adimi(
                soru="Levha yalnız {} ışıkla aydınlatılırsa ZEMİN hangi renkte görünür?".format(deneme_isigi),
                dogru=zemin_gorunen,
                yanlislar=zemin_yanlislari,
                rastgele=rastgele,
                aciklama=(
                    "Boya ({}) yansıttığı bileşenler: {}. Işık ({}) bileşeni: {}. "
                    "Ortak kısım: {}."
                ).format(zemin, "+".join(sorted(_ADDAN_RENK[zemin])), deneme_isigi,
                         "+".join(sorted(_ADDAN_RENK[deneme_isigi])), zemin_gorunen),
                ipuclari=["Boyanın yansıttıkları ile ışığın bileşenlerinin ortak kısmı ne?"],
                puan=12,
            ),
            secim_adimi(
                soru="Hangi projektör tek başına yakılırsa levhanın YAZISI okunamaz?",
                dogru="{} ışık: yazı ve zemin aynı renkte görünür".format(okunmaz),
                yanlislar=dict({
                    "{} ışık: yazı ve zemin aynı renkte görünür".format(i):
                        "Bu ışıkta yazı {}, zemin {} görünür; farklılar."
                        .format(_gorunen(yazi, i), _gorunen(zemin, i))
                    for i in _ANA_ISIKLAR if i != okunmaz
                }, **{
                    "Hiçbiri: levha boyalı olduğu için yazı her ışıkta okunur":
                        "Boyalı yüzeyin rengini ışıktan bağımsız sandın. Tek renkli "
                        "ışıkta iki farklı boya aynı renkte görünebilir.",
                }),
                rastgele=rastgele,
                aciklama=(
                    "Işık {}: yazı {}, zemin {} görünür -- aynı renk, yazı kaybolur."
                ).format(okunmaz, _gorunen(yazi, okunmaz), _gorunen(zemin, okunmaz)),
                ipuclari=["Her ışık için yazının ve zeminin görünen rengini bul."],
                puan=14,
            ),
        ],
        kapanis=("Işık planı düzeltildi: {} projektör kullanılmayacak (yazı zeminle "
                 "aynı renge bürünüyor). Işıklar toplanır, boyalar süzer."
                 ).format(okunmaz),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# AYNALAR: SANAL GÖRÜNTÜ EKRANA DÜŞMEZ (B37.13 -- müfredat haritası)
#
# `aynalar` iki satırda boştu (2018: 10; 2026: 11). Bağlam: "Gözlem
# düzeneğindeki aynanın görüntüsünü çizme". `yaygin_yanlis`:
#
#   "Sanal görüntüyü ekrana düşürülebilir sanmak."
#
# DÜZENEK: gözlem düzeneğinde çukur ayna ve düz ayna. Çukur aynada cisim odak
# dışındayken yansıyan ışınlar gerçekten kesişir: gerçek görüntü, ekrana düşer.
# Odak içindeyken ışınlar ayrılır, uzantıları aynanın ARKASINDA kesişir: sanal
# görüntü. Düz aynada görüntü hep sanal, aynanın arkasında cisimle eşit
# uzaklıkta. 1/f = 1/d_c + 1/d_g (sanalda d_g negatif).
#
# YANILGININ SAYISAL KARŞILIĞI: sanal görüntü için "ekranı aynanın arkasına
# |d_g| cm koy" şıkkı; düz aynada görüntüye olan uzaklığı yanlış hesaplamak.
# ==========================================================================

def _ayna_havuzu():
    """(odak, gercek_cisim, sanal_cisim): cm; görüntü uzaklıkları tam sayı."""
    havuz = []
    for odak in (10, 12, 15, 20):
        for gercek in range(odak + 1, 4 * odak + 1):
            if gercek == 2 * odak:
                continue          # d_g = d_c olur, "cisim uzaklığı" teşhisi cevaba yapışır
            if (odak * gercek) % (gercek - odak) or odak * gercek // (gercek - odak) > 120:
                continue
            for sanal in range(2, odak):
                if (odak * sanal) % (odak - sanal):
                    continue
                havuz.append((odak, gercek, sanal))
    return tuple(havuz)


_AYNA = _ayna_havuzu()


@bulmaca(ders="fizik", konu="aynalar", kademeler=(10, 13), agirlik=1.3)
def gozlem_aynasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Gerçek görüntü ekrana düşer; sanal görüntü (düz ayna, odak içi) düşmez."""
    odak, gercek, sanal = rastgele.choice(_AYNA)
    gercek_goruntu = odak * gercek // (gercek - odak)
    sanal_goruntu = odak * sanal // (odak - sanal)       # aynanın arkasında
    duz_mesafe = rastgele.choice((1, 2, 3, 4))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-gozlem-aynasi",
        ders="fizik",
        baslik="Gözlem Aynası",
        kademe=kademe,
        konu="aynalar",
        kazanim="Aynalarda gerçek ve sanal görüntüyü ayırt etme; çukur aynada "
                "görüntü uzaklığını hesaplama; sanal görüntünün ekrana "
                "düşürülemeyeceğini açıklama.",
        dikkat=7,
        brifing=(
            "Gözlem düzeneğinde bir çukur ayna numunenin görüntüsünü ekrana "
            "yansıtıyor; ayrıca kontrol için bir düz ayna var.\n\n"
            "{} ayarları yazdı: \"Görüntü nerede oluşursa ekranı oraya koyarız; "
            "numune odağa yaklaşınca da, düz aynada da görüntüyü ekranda "
            "yakalarız.\"\n\n"
            "Düzenek kurulmadan önce hangi görüntülerin ekrana düşeceğini "
            "bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Ayna etiketi", "Çukur ayna, odak uzaklığı {} cm.".format(odak),
                  bedel=1, kritik=True),
            Kanit("Numune konumları",
                  "1. deneme: numune aynadan {} cm uzakta.\n2. deneme: numune aynadan "
                  "{} cm uzakta.".format(gercek, sanal),
                  bedel=1, kritik=True),
            Kanit("Düz ayna",
                  "Nöbetçi duvardaki düz aynanın {} m önünde duruyor.".format(duz_mesafe),
                  bedel=1, kritik=True),
            Kanit("Ayna notu",
                  "1/f = 1/d_cisim + 1/d_görüntü. d_görüntü negatif çıkarsa görüntü "
                  "aynanın arkasındadır. Gerçek görüntü ekrana düşer; sanal "
                  "görüntü düşmez.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Gerçek ve sanal görüntü için hangisi doğru?",
                dogru=("Gerçek görüntüde ışınlar kesişir, ekrana düşer; sanalda yalnız "
                       "uzantıları kesişir"),
                yanlislar={
                    ("Her görüntü ekrana düşürülebilir; ekranı görüntünün yerine koymak "
                     "yeter, görüntü ışıktan oluşur"):
                        "Sanal görüntüyü ekrana düşürülebilir sandın. Sanal "
                        "görüntünün yerine hiç ışık gitmez; orada kesişen yalnız "
                        "ışınların uzantılarıdır.",
                    "Düz aynanın görüntüsü ekrana düşer, çukur aynanınki hiç düşmez":
                        "Tersi yakın: düz aynanın görüntüsü hep sanaldır; çukur ayna "
                        "cisim odak dışındayken gerçek görüntü verir.",
                    "Sanal görüntü yalnız tümsek aynada oluşur, çünkü yalnız o ışığı dağıtır":
                        "Düz aynada ve çukur aynada (cisim odak içindeyken) de sanal "
                        "görüntü oluşur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Ekrana ancak gerçekten ışık ulaşan bir görüntü düşer. Sanal "
                    "görüntü aynanın arkasındadır: göz, yansıyan ışınları geriye "
                    "uzatıp orada bir cisim varmış gibi görür, ama oraya ışık "
                    "gitmez."
                ),
                ipuclari=[
                    "Aynanın arkasına ışık gider mi?",
                    "Görüntünün yerinde ışınlar mı, uzantıları mı kesişiyor?",
                ],
                cozum="d_g > 0: gerçek, ekrana düşer.\nd_g < 0: sanal, düşmez.",
            ),
            sayi_adimi(
                soru="1. denemede ekran aynadan kaç cm uzağa konmalı?",
                cevap=gercek_goruntu,
                birim="cm",
                aciklama="d_g = {} × {} ÷ ({} − {}) = {} cm; görüntü gerçek.".format(
                    odak, gercek, gercek, odak, gercek_goruntu),
                yaygin_yanlislar={
                    gercek:
                        "Numunenin uzaklığını yazdın; görüntü uzaklığı ayna "
                        "bağıntısından bulunur.",
                    odak:
                        "Odak uzaklığını yazdın; görüntü odakta yalnız çok uzak "
                        "cisimlerde oluşur.",
                },
                ipuclari=["Ayna notundaki bağıntıyı görüntü uzaklığı için çöz."],
                puan=12,
            ),
            sayi_adimi(
                soru="Nöbetçi ile düz aynadaki görüntüsü arasındaki uzaklık kaç m?",
                cevap=2 * duz_mesafe,
                birim="m",
                aciklama=("Görüntü aynanın {} m arkasında: {} + {} = {} m. Bu görüntü "
                          "sanal; aynanın arkasına ekran koysan boş kalır.").format(
                              duz_mesafe, duz_mesafe, duz_mesafe, 2 * duz_mesafe),
                yaygin_yanlislar={
                    duz_mesafe:
                        "Yalnız aynaya olan uzaklığı yazdın; görüntü de aynanın o "
                        "kadar arkasında.",
                    0:
                        "Görüntüyü aynanın yüzeyinde sandın; düz aynada görüntü "
                        "aynanın arkasında oluşur.",
                },
                ipuclari=["Düz aynada görüntü aynanın arkasında nerede oluşur?"],
                puan=10,
            ),
            secim_adimi(
                soru="2. denemede görüntü ekrana düşürülebilir mi?",
                dogru=("Hayır: numune odak içinde; görüntü {} cm arkada, sanal ve "
                       "düz").format(sanal_goruntu),
                yanlislar={
                    "Evet: ekran aynanın {} cm arkasına konursa görüntü düşer".format(sanal_goruntu):
                        "Sanal görüntüyü ekrana düşürülebilir sandın. Aynanın "
                        "arkasına ışık ulaşmaz; orada kesişen ışınların "
                        "uzantılarıdır.",
                    ("Evet: ekran aynanın önüne, {} cm uzağa konursa görüntü düşer; yansıyan "
                     "ışık öne döner").format(sanal_goruntu):
                        "Görüntü aynanın önünde değil arkasında; bağıntıda d_g "
                        "negatif çıkıyor.",
                    "Görüntü hiç oluşmaz; aynaya bakınca da görülmez, çünkü ışınlar kesişmiyor":
                        "Görüntü oluşur ama sanaldır: aynaya bakan kişi onu büyük ve "
                        "düz görür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "1/d_g = 1/{} − 1/{} -> d_g = −{} cm: görüntü aynanın arkasında. "
                    "Sanal görüntü ekrana düşmez; ancak aynaya bakılarak görülür."
                ).format(odak, sanal, sanal_goruntu),
                ipuclari=["2. denemede numune odağın içinde mi?"],
                puan=12,
            ),
        ],
        kapanis=("Ayarlar düzeltildi: 1. denemede ekran {} cm uzağa kondu. 2. deneme "
                 "ve düz ayna sanal görüntü veriyor; bunlar ekranla değil, aynaya "
                 "bakılarak kaydedilecek.").format(gercek_goruntu),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# MANYETİK ALAN: AKIMIN ALANI ELEKTRİK ALANDAN FARKLIDIR (B37.13)
#
# `manyetik_alan` iki satırda boştu (2018: 10; 2026: 11). Bağlam: "Haberleşme
# istasyonundaki bobin modelini yorumlama". `yaygin_yanlis`:
#
#   "Elektrik alan ile manyetik alanı aynı saymak; alan yönünü karıştırmak."
#
# DÜZENEK: istasyonda iki bobin ve bir pusula. Duran yüklü bir küre pusulayı
# saptırmıyor (yalnız elektrik alan), akım geçen tel saptırıyor. Bobinin
# içindeki alan B ∝ N·I / L. Bobinin önüne bakınca akım saat yönünün TERSİNE
# dolanıyorsa ön yüz N kutbudur (sağ el kuralı), saat yönündeyse S.
#
# YANILGININ SAYISAL KARŞILIĞI: yüklü kürede pusulanın da sapacağını sanmak
# (tel kadar sapma yazmak); bobin oranında akımı ya da boyu unutmak; kutbu
# ters vermek.
# ==========================================================================

def _bobin_havuzu():
    """(n_a, i_a, l_a, n_b, i_b, l_b): sarım, A, cm.

    Koşul: B_b / B_a en çok bir ondalık, 0,5-8 arası; "yalnız sarım",
    "yalnız akım" ve "boyu unutmak" oranları doğru orandan ve birbirinden farklı.
    """
    havuz = []
    for n_a in (100, 200):
        for i_a in (1, 2):
            for l_a in (10, 20):
                for n_b in (100, 200, 400):
                    for i_b in (1, 2, 3, 4):
                        for l_b in (10, 20, 40):
                            oran10 = 10 * n_b * i_b * l_a
                            payda = n_a * i_a * l_b
                            if oran10 % payda:
                                continue
                            oran = oran10 / (10.0 * payda)
                            if not 0.5 <= oran <= 8:
                                continue
                            adaylar = {oran, n_b / float(n_a), i_b / float(i_a),
                                       n_b * i_b / float(n_a * i_a)}
                            if len(adaylar) < 4:
                                continue
                            havuz.append((n_a, i_a, l_a, n_b, i_b, l_b))
    return tuple(havuz)


_BOBIN = _bobin_havuzu()


@bulmaca(ders="fizik", konu="manyetik_alan", kademeler=(10, 13), agirlik=1.3)
def istasyon_bobini(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Manyetik alanı akım oluşturur (B ∝ NI/L); duran yük pusulayı saptırmaz; yön sağ el kuralıyla."""
    n_a, i_a, l_a, n_b, i_b, l_b = rastgele.choice(_BOBIN)
    oran = (n_b * i_b * l_a) / float(n_a * i_a * l_b)
    tel_sapma = rastgele.choice((20, 30, 40, 45))
    saat_yonu = rastgele.choice((True, False))
    on_kutup = "S" if saat_yonu else "N"
    ters_kutup = "N" if saat_yonu else "S"
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-istasyon-bobini",
        ders="fizik",
        baslik="İstasyon Bobini",
        kademe=kademe,
        konu="manyetik_alan",
        kazanim="Manyetik alanın akımdan, elektrik alanın yükten kaynaklandığını ayırt "
                "etme; bobin alanını sarım, akım ve boyla karşılaştırma; sağ el "
                "kuralıyla bobinin kutuplarını belirleme.",
        dikkat=7,
        brifing=(
            "Haberleşme istasyonunda anten bobinleri yenileniyor. Bakım ekibi bir "
            "pusulayla ölçüm yaptı.\n\n"
            "{} rapora şunu yazdı: \"Elektrik alan da manyetik alan da aynı şey. "
            "Yüklü kürenin yanında da pusula sapar; bobinin hangi ucu N olur, fark "
            "etmez.\"\n\n"
            "Rapor onaylanmadan önce ölçümleri doğru yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Pusula ölçümü",
                  "Akım geçen düz telin yanında pusula {}° saptı. Akım kesilince "
                  "eski yönüne döndü.".format(tel_sapma),
                  bedel=1, kritik=True),
            Kanit("Yüklü küre",
                  "Elektrik yüklü, duran metal bir kürenin yanına aynı pusula kondu; "
                  "kürenin yanında elektroskop yaprakları açık.",
                  bedel=1, kritik=True),
            Kanit("Bobin kartları",
                  "Bobin A: {} sarım, {} A akım, {} cm boy.\nBobin B: {} sarım, {} A "
                  "akım, {} cm boy.\nBobinin içindeki alan: B ∝ N · I ÷ L."
                  .format(n_a, i_a, l_a, n_b, i_b, l_b),
                  bedel=1, kritik=True),
            Kanit("Bağlantı şeması",
                  "Bobin B'nin önüne bakınca akım sarımlarda saat yönü{} dolanıyor. "
                  "Sağ el kuralı: dört parmak akım yönünde kıvrılınca başparmak N "
                  "kutbunu gösterir.".format("nde" if saat_yonu else "nün tersine"),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Elektrik alan ile manyetik alan için hangisi doğru?",
                dogru=("Elektrik alanı yükler, manyetik alanı hareketli yükler ve "
                       "mıknatıslar oluşturur"),
                yanlislar={
                    ("İkisi aynı alandır; yüklü küre de pusulayı saptırır, çünkü iki alan da "
                     "çekip iten bir etkidir"):
                        "Elektrik alan ile manyetik alanı aynı saydın. Pusula "
                        "manyetik alana tepki verir; duran yükün yalnız elektrik "
                        "alanı vardır.",
                    "Manyetik alan yalnız mıknatısta olur; akım manyetik alan oluşturmaz":
                        "Pusula ölçümü tersini gösteriyor: akım geçen tel pusulayı "
                        "saptırdı.",
                    ("Elektrik alan pusulayı saptırır, manyetik alan saptırmaz; pusula iğnesi "
                     "yüke tepki verir"):
                        "Pusula bir mıknatıstır; manyetik alanda döner.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Duran yük çevresinde elektrik alan oluşturur. Yük hareket "
                    "edince (akım) bir de manyetik alan oluşur. Pusulanın ibresi "
                    "küçük bir mıknatıstır ve yalnız manyetik alanda döner."
                ),
                ipuclari=[
                    "Pusula telde akım kesilince ne yaptı?",
                    "Pusulanın ibresi ne tür bir cisimdir?",
                ],
                cozum="Duran yük: E alanı.\nAkım: B alanı.\nPusula: B'ye tepki verir.",
            ),
            sayi_adimi(
                soru="Duran yüklü kürenin yanındaki pusula kaç derece sapar?",
                cevap=0,
                birim="°",
                aciklama="Duran yükün manyetik alanı yok: sapma 0°.",
                yaygin_yanlislar={
                    tel_sapma:
                        "Elektrik alan ile manyetik alanı aynı saydın; telin "
                        "sapmasını küreye taşıdın. Kürede akım yok.",
                },
                ipuclari=["Kürede hareket eden yük var mı?"],
                puan=10,
            ),
            sayi_adimi(
                soru="Bobin B'nin içindeki manyetik alan, Bobin A'nınkinin kaç katı?",
                cevap=oran,
                aciklama="({} × {} ÷ {}) ÷ ({} × {} ÷ {}) = {}.".format(
                    n_b, i_b, l_b, n_a, i_a, l_a, sy(oran)),
                yaygin_yanlislar={
                    sy(n_b / float(n_a)).replace(",", "."):
                        "Yalnız sarım sayısını karşılaştırdın; akım ve boy da "
                        "alanı etkiler.",
                    sy(i_b / float(i_a)).replace(",", "."):
                        "Yalnız akımı karşılaştırdın; sarım ve boy da alanı etkiler.",
                    sy(n_b * i_b / float(n_a * i_a)).replace(",", "."):
                        "Bobin boyunu unuttun: aynı sarım daha uzun bobine yayılınca "
                        "alan zayıflar.",
                },
                ipuclari=["Bobin kartındaki orantıyı iki bobin için yaz, böl."],
                puan=14,
            ),
            secim_adimi(
                soru="Bobin B'nin size bakan ön yüzü hangi kutup olur?",
                dogru="{} kutbu".format(on_kutup),
                yanlislar={
                    "{} kutbu".format(ters_kutup):
                        "Alan yönünü ters aldın. Dört parmağını akım yönünde kıvır; "
                        "başparmağın N kutbunu gösterir.",
                    "Kutup oluşmaz; bobin yalnız elektrik alan üretir":
                        "Elektrik alan ile manyetik alanı karıştırdın; akım geçen "
                        "bobin bir mıknatıs gibi davranır.",
                    "İki ucu da aynı kutup olur":
                        "Bir mıknatısın iki ucu hep zıt kutuptur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Önden bakınca akım saat yönü{} dolanıyor. Sağ el kuralı: "
                    "başparmak {} gösteriyor, yani ön yüz {} kutbu."
                ).format("nde" if saat_yonu else "nün tersine",
                         "bizden uzağa" if saat_yonu else "bize doğru", on_kutup),
                ipuclari=["Bağlantı şemasındaki sağ el kuralını uygula."],
                puan=12,
            ),
        ],
        kapanis=("Rapor düzeltildi: yüklü kürede sapma 0°, tel yanında {}°. Bobin B'nin "
                 "alanı A'nınkinin {} katı; ön yüzü {} kutbu."
                 ).format(tel_sapma, sy(oran), on_kutup),
        odul={"itibar": 5, "cevher": 1, "enerji": 2},
    )


# ==========================================================================
# FİZİK BİLİMİ: YASA, MODEL VE TEKNOLOJİK ÜRÜN (B37.13 -- müfredat haritası)
#
# `fizik_bilimi` iki satırda boştu (2018: 9; 2026: 9). Bağlam: "Seferde
# kullanılacak ölçüm aracını araştırma alanıyla eşleştirme". `yaygin_yanlis`:
#
#   "Teknolojik ürünü bilimsel yasa sanmak; modeli değişmez gerçek saymak."
#
# DÜZENEK: sefer kütüphanesinin kart dizini karışmış: bilimsel yasalar,
# modeller ve teknolojik ürünler aynı çekmecede. Ayrıca atom modelinin
# tarihçe kartı (Thomson -> Rutherford -> Bohr -> modern) ve seferde
# kullanılacak ölçüm araçları.
# ==========================================================================

_KUTUPHANE_KARTLARI = (
    ("Newton'un hareket yasaları", "yasa"),
    ("Enerjinin korunumu", "yasa"),
    ("Bohr atom modeli", "model"),
    ("Işığın ışın modeli", "model"),
    ("Termometre", "ürün"),
    ("Güneş paneli", "ürün"),
    ("Pusula", "ürün"),
)
# ölçüm aracı -> araştırma alanı (bağımsız eşleşme testte)
_ARAC_ALAN = (
    ("pusula", "manyetizma"),
    ("termometre", "ısı ve sıcaklık"),
    ("dinamometre", "mekanik (kuvvet)"),
    ("spektroskop", "optik ve atom fiziği"),
)


@bulmaca(ders="fizik", konu="fizik_bilimi", kademeler=(9, 13), agirlik=1.2)
def sefer_kutuphanesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yasa, model ve teknolojik ürün ayrı şeylerdir; modeller yeni kanıtla değişir."""
    sira = list(range(len(_KUTUPHANE_KARTLARI)))
    rastgele.shuffle(sira)
    kartlar = [_KUTUPHANE_KARTLARI[i][0] for i in sira]
    urunler = [n for n, i in enumerate(sira) if _KUTUPHANE_KARTLARI[i][1] == "ürün"]
    arac, alan = rastgele.choice(_ARAC_ALAN)
    diger_alanlar = [a for _, a in _ARAC_ALAN if a != alan]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-sefer-kutuphanesi",
        ders="fizik",
        baslik="Sefer Kütüphanesi",
        kademe=kademe,
        konu="fizik_bilimi",
        kazanim="Bilimsel yasa, model ve teknolojik ürünü ayırt etme; bilimsel "
                "modellerin yeni kanıtlarla değişebileceğini açıklama; ölçüm aracını "
                "fiziğin alt alanıyla eşleştirme.",
        dikkat=6,
        brifing=(
            "Sefer kütüphanesinin kart dizini karışmış: yasalar, modeller ve "
            "cihazlar aynı çekmecede.\n\n"
            "{} dizine iki not düşmüş: \"Termometre ve pusula da birer fizik "
            "yasasıdır, çünkü fizikle çalışırlar.\" ve \"Bohr atom modeli atomun "
            "kesin ve son hâlidir; bir daha değişmez.\"\n\n"
            "Dizin yeniden düzenlenmeden önce kartları doğru ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Tanımlar",
                  "Yasa: doğada tekrar tekrar doğrulanmış bir düzenin ifadesi. "
                  "Model: bir olguyu açıklamak için kurulan, sınırları olan "
                  "temsil. Teknolojik ürün: bilimsel bilginin uygulanmasıyla "
                  "yapılmış araç.",
                  bedel=1, kritik=True),
            Kanit("Atom modeli tarihçesi",
                  "Thomson (1904) -> Rutherford (1911, altın levha deneyi) -> Bohr "
                  "(1913, çizgi spektrumları) -> modern kuantum modeli. Her geçişi "
                  "yeni deney sonuçları başlattı.",
                  bedel=1, kritik=True),
            Kanit("Sefer ölçüm listesi",
                  "Seferde {} kullanılacak; hangi araştırma ekibine verileceği "
                  "boş.".format(arac),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yasa, model ve teknolojik ürün için hangisi doğru?",
                dogru=("Teknolojik ürün bir araçtır, yasa değil; modeller yeni kanıtla "
                       "değişebilir"),
                yanlislar={
                    ("Fizikle çalışan her cihaz bir fizik yasasıdır; termometre ısıl genleşme "
                     "yasasının kendisidir"):
                        "Teknolojik ürünü bilimsel yasa sandın. Termometre bir "
                        "yasa değil, ısıl genleşme bilgisini kullanan bir araçtır.",
                    ("Modeller doğanın kesin ve değişmez kopyasıdır, bu yüzden bilimde "
                     "güvenilirler"):
                        "Modeli değişmez gerçek saydın. Atom modeli tarihçesi, "
                        "modellerin yeni deneylerle defalarca değiştiğini gösteriyor.",
                    "Yasalar yalnız laboratuvarda geçerlidir, doğada geçerli değildir":
                        "Yasa zaten doğada tekrar tekrar gözlenen düzeni anlatır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yasa doğadaki bir düzeni ifade eder; model bir olguyu açıklamak "
                    "için kurulur ve kanıt değiştikçe güncellenir; teknolojik ürün bu "
                    "bilgilerin uygulanmasıyla yapılan araçtır. Üçü birbirinden "
                    "farklıdır."
                ),
                ipuclari=[
                    "Tanımlar kartında teknolojik ürün nasıl tanımlanıyor?",
                    "Atom modeli kaç kez değişmiş?",
                ],
                cozum="Yasa: düzen.\nModel: açıklama, değişebilir.\nÜrün: araç.",
            ),
            coklu_adimi(
                soru="Hangi kartlar teknolojik üründür? (numaraları virgülle yaz)",
                secenekler=kartlar,
                dogru_indeksler=urunler,
                aciklama=(
                    "Termometre, güneş paneli ve pusula araçtır. Newton'un yasaları "
                    "ve enerjinin korunumu yasadır; Bohr atom modeli ve ışın modeli "
                    "modeldir."
                ),
                ipuclari=["Elle tutulan, yapılmış araçları seç."],
                puan=12,
            ),
            secim_adimi(
                soru="Atom modelinin tarihçesi hangi sonucu destekler?",
                dogru="Modeller yeni deneylerle değişir; Bohr modeli de geliştirildi",
                yanlislar={
                    "Bohr modeli kesin ve son modeldir; atomun yapısı onunla tamamen çözüldü":
                        "Modeli değişmez gerçek saydın. Tarihçe Bohr'dan sonra da "
                        "yeni bir model geldiğini gösteriyor.",
                    "Eski modeller tamamen yanlıştı, hiçbir işe yaramadı":
                        "Her model kendi zamanındaki kanıtları açıklıyordu; yenisi "
                        "eskisinin açıklayamadıklarını da açıkladı.",
                    ("Atom modelleri deneyle değil, tahminle değişti; atom görülemediği için "
                     "deney yapılamaz"):
                        "Tarihçe kartı her geçişi bir deneyin başlattığını söylüyor.",
                },
                rastgele=rastgele,
                aciklama=("Thomson'dan modern modele her geçişi yeni bir deney "
                          "başlattı. Model bilimin en güncel açıklamasıdır; değişmez "
                          "gerçek değildir."),
                ipuclari=["Tarihçe kartında Bohr'dan sonra ne var?"],
                puan=12,
            ),
            secim_adimi(
                soru="Seferde kullanılacak {} hangi araştırma ekibine verilmeli?".format(arac),
                dogru="{} ekibi".format(alan[:1].upper() + alan[1:]),
                yanlislar={
                    "{} ekibi".format(a[:1].upper() + a[1:]):
                        "Bu alan başka bir ölçüm aracıyla çalışıyor; {} ile ölçülen "
                        "büyüklüğü düşün.".format(arac)
                    for a in diger_alanlar
                },
                rastgele=rastgele,
                aciklama="{} ile ölçülen büyüklük {} alanına girer.".format(
                    arac[:1].upper() + arac[1:], alan),
                ipuclari=["Bu araç hangi büyüklüğü ölçer ya da gösterir?"],
                puan=10,
            ),
        ],
        kapanis=("Dizin düzeltildi: araçlar, yasalar ve modeller ayrı çekmecelerde; "
                 "atom modeli kartına \"yeni kanıtla değişebilir\" notu eklendi. {} "
                 "{} ekibine verildi.").format(arac[:1].upper() + arac[1:], alan),
        odul={"itibar": 4, "cevher": 1, "enerji": 1},
    )


# ==========================================================================
# DÜZGÜN ÇEMBERSEL HAREKET: SABİT SÜRAT SABİT HIZ DEĞİLDİR (B37.13)
#
# `cembersel_hareket` iki satırda boştu (2018: 12; 2026: 11). Bağlam: "Dönen
# tarama sensörünün hareketini modelleme". `yaygin_yanlis`:
#
#   "Sabit sürati sabit hız sanmak; merkezcil kuvveti ek bağımsız kuvvet saymak."
#
# DÜZENEK: yatay düzlemde dönen tarama kolunun ucunda sensör (sürtünmesiz
# tabla; ağırlık ve tepki birbirini dengeler). v = 2πr ÷ T (π = 3), yarım
# turda hız vektörü tam ters döner: |Δv| = 2v. Merkezcil kuvveti kolun çekme
# kuvveti SAĞLAR; ayrı bir kuvvet değildir. Kol koparsa sensör teğet gider.
#
# YANILGILARIN SAYISAL KARŞILIĞI: yarım turda hız değişimini 0 yazmak; kol
# kuvvetinde yarıçapı unutmak (m·v²). Seçim adımlarında "kol kuvveti + ayrıca
# merkezcil kuvvet" ve "dışa doğru merkezkaç kuvveti" şıkları.
# ==========================================================================

_PI_MODEL = 3


def _cembersel_havuzu():
    havuz = []
    for r in (0.5, 1.0, 1.5, 2.0):
        for periyot in (2, 3, 4):
            v = 2 * _PI_MODEL * r / periyot
            a = v * v / r
            if abs(round(v * 100) - v * 100) > 1e-6 or abs(round(a * 100) - a * 100) > 1e-6:
                continue
            havuz.append((r, periyot))
    return tuple(havuz)


_CEMBERSEL = _cembersel_havuzu()


@bulmaca(ders="fizik", konu="cembersel_hareket", kademeler=(11, 13), agirlik=1.3)
def tarama_kolu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Düzgün çembersel harekette sürat sabit, hız değişir; merkezcil kuvvet ayrı bir kuvvet değildir."""
    r, periyot = rastgele.choice(_CEMBERSEL)
    m = rastgele.choice((2, 3, 4))
    v = round(2 * _PI_MODEL * r / periyot, 2)
    a = round(v * v / r, 2)
    kuvvet = round(m * a, 2)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    kuvvet_yanlislari, gorulen = {}, [kuvvet]
    for deger, metin in (
            (round(m * v * v, 2), "Yarıçapı unuttun: F = m·v² ÷ r."),
            (round(m * v, 2), "Momentumu yazdın; kuvvet için m·v² ÷ r gerekir.")):
        if all(abs(deger - g) > 0.01 for g in gorulen):
            kuvvet_yanlislari[sy(deger).replace(",", ".")] = metin
            gorulen.append(deger)

    return Bulmaca(
        kod="fiz-tarama-kolu",
        ders="fizik",
        baslik="Tarama Kolu",
        kademe=kademe,
        konu="cembersel_hareket",
        kazanim="Düzgün çembersel harekette sürat ile hızı ayırt etme; çizgisel "
                "sürat, merkezcil ivmelenme ve merkezcil kuvveti hesaplama; merkezcil "
                "kuvvetin ayrı bir kuvvet değil, net kuvvet olduğunu açıklama.",
        dikkat=8,
        brifing=(
            "Keşif aracının tepesindeki tarama kolu yatay düzlemde dönüyor; ucundaki "
            "sensörün bağlantısı güçlendirilecek.\n\n"
            "{} rapora şunu yazdı: \"Sensörün sürati hep aynı, yani hızı da sabit; "
            "ivmelenmesi yok. Sensöre iki yatay kuvvet çizdim: kolun çekmesi ve "
            "ayrıca merkezcil kuvvet. Kol koparsa sensör dışarı doğru fırlar.\"\n\n"
            "Bağlantı parçası seçilmeden önce hareketi doğru modellememiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Kol kaydı",
                  "Kol boyu (dönme yarıçapı) {} m. Kol bir turu {} s sürede atıyor. "
                  "Sensörün kütlesi {} kg. Tabla sürtünmesiz, hareket yatay düzlemde."
                  .format(sy(r), periyot, m),
                  bedel=1, kritik=True),
            Kanit("Hareket notu",
                  "v = 2πr ÷ T (π = 3 alınız). Merkezcil ivmelenme a = v² ÷ r, merkeze "
                  "doğru. Net kuvvet F = m·a.",
                  bedel=1, kritik=True),
            Kanit("Kopma testi kaydı",
                  "Eski bir kolda bağlantı koptuğunda sensör, koptuğu andaki hareket "
                  "yönünde düz bir çizgi boyunca gitti.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Sabit süratle dönen sensör için hangisi doğrudur?",
                dogru=("Sürati sabit ama hızının yönü sürekli değişir; merkezcil kuvveti "
                       "kol sağlar"),
                yanlislar={
                    "Sürati sabit olduğu için hızı da sabittir; ivmelenmesi yoktur":
                        "Sabit sürati sabit hız sandın. Hız bir vektör: yönü "
                        "değişince hız da değişir.",
                    "Kolun çekme kuvvetine ek olarak ayrıca bir merkezcil kuvvet etki eder":
                        "Merkezcil kuvveti ek bağımsız kuvvet saydın. Merkezcil "
                        "kuvvet, merkeze doğru olan net kuvvetin adıdır; burada onu "
                        "kol sağlıyor.",
                    ("Sensörü dışarı doğru iten bir merkezkaç kuvveti vardır, kol bu yüzden "
                     "gergin durur"):
                        "Yerdeki gözlemciye göre dışa doğru bir kuvvet yok; kol "
                        "koparsa sensör teğet doğrultusunda gider.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Hız hem büyüklük hem yön taşır. Çember boyunca yön değiştiği için "
                    "sensör sürekli merkeze doğru ivmelenir. Bu ivmelenmeyi bir kuvvet "
                    "sağlamalıdır: burada kolun çekme kuvveti. 'Merkezcil kuvvet' o "
                    "kuvvetin görevinin adıdır, yeni bir kuvvet değildir."
                ),
                ipuclari=[
                    "Yarım tur sonra sensör hangi yöne gidiyor?",
                    "Sensöre yatay düzlemde hangi cisim dokunuyor?",
                ],
                cozum="v = 2πr ÷ T\na = v² ÷ r (merkeze)\nF_kol = m·v² ÷ r",
            ),
            sayi_adimi(
                soru="Sensörün çizgisel sürati kaç m/s?",
                cevap=v,
                birim="m/s",
                aciklama="v = 2 × 3 × {} ÷ {} = {} m/s.".format(sy(r), periyot, sy(v)),
                ipuclari=["Bir turda alınan yol çemberin çevresi."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Yarım turda sensörün hız vektöründeki değişimin büyüklüğü kaç m/s?",
                cevap=round(2 * v, 2),
                birim="m/s",
                aciklama=("Yarım tur sonra hız aynı büyüklükte ama ters yönde: "
                          "Δv = {} − (−{}) = {} m/s.").format(sy(v), sy(v), sy(round(2 * v, 2))),
                yaygin_yanlislar={
                    0:
                        "Sabit sürati sabit hız sandın. Sürat değişmedi ama yön tam "
                        "ters döndü; hız vektörü değişti.",
                    sy(v).replace(",", "."):
                        "Yalnız büyüklüğe baktın; ters yöndeki iki vektörün farkı "
                        "büyüklüklerin toplamıdır.",
                },
                ipuclari=["Başlangıçtaki ve yarım tur sonraki hız okları hangi yönde?"],
                puan=12,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Kolun sensörü merkeze doğru çekme kuvveti kaç N?",
                cevap=kuvvet,
                birim="N",
                aciklama="a = {}² ÷ {} = {} m/s². F = {} × {} = {} N.".format(
                    sy(v), sy(r), sy(a), m, sy(a), sy(kuvvet)),
                yaygin_yanlislar=kuvvet_yanlislari,
                ipuclari=["Önce merkezcil ivmelenmeyi bul, sonra kütleyle çarp."],
                puan=14,
                tolerans=0.01,
            ),
            secim_adimi(
                soru="Sensörün yatay düzlemdeki kuvvet çizimi hangisi olmalı?",
                dogru="Yalnız kolun merkeze doğru çekmesi; merkezcil kuvvet odur",
                yanlislar={
                    "Kolun çekme kuvveti ve ayrıca merkeze doğru bir merkezcil kuvvet":
                        "Merkezcil kuvveti ek bağımsız kuvvet saydın; aynı kuvveti iki "
                        "kez çizdin.",
                    "Kolun çekme kuvveti ve dışa doğru bir merkezkaç kuvveti":
                        "Dışa doğru kuvvet olsaydı net kuvvet sıfır olur, sensör düz "
                        "giderdi.",
                    "Hareket yönünde bir itme kuvveti; sensörü çember boyunca o sürükler":
                        "Sürat sabit; hareket yönünde net kuvvet gerekmez.",
                },
                rastgele=rastgele,
                aciklama=("Sensöre yatayda yalnız kol dokunuyor. Kolun çekme kuvveti "
                          "net kuvvettir ve merkeze yönelir: merkezcil kuvvet odur."),
                ipuclari=["Sensöre hangi cisimler dokunuyor? Her kuvvetin bir kaynağı olmalı."],
                puan=10,
            ),
            secim_adimi(
                soru="Kol koparsa sensör nasıl hareket eder?",
                dogru="Koptuğu andaki hız yönünde, çembere teğet bir doğru boyunca",
                yanlislar={
                    "Merkezden dışarı doğru, yarıçap boyunca; onu dışa iten kuvvet serbest kalır":
                        "Dışa doğru bir kuvvet yok; kopma testi kaydı sensörün "
                        "hareket yönünde düz gittiğini söylüyor.",
                    "Çember boyunca dönmeye devam eder":
                        "Merkeze doğru kuvvet kalmayınca yön değişmez; çembersel "
                        "hareket biter.",
                },
                rastgele=rastgele,
                aciklama="Net kuvvet sıfır olunca sensör sabit hızla düz gider: teğet doğrultusunda.",
                ipuclari=["Kopma testi kaydını oku."],
                puan=8,
            ),
        ],
        kapanis=("Model düzeltildi: sürat {} m/s sabit ama hız değişiyor; kol {} N "
                 "çekiyor ve merkezcil kuvvet odur. Bağlantı bu kuvvete göre seçildi."
                 ).format(sy(v), sy(kuvvet)),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# DÖNME: EYLEMSİZLİK MOMENTİ KÜTLE DAĞILIMINA BAĞLIDIR (B37.13)
#
# `donme_momentumu` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Dönen
# atölye tablasındaki yük dağılımını karşılaştırma". `yaygin_yanlis`:
#
#   "Eylemsizlik momentini yalnız kütleye bağlamak."
#
# DÜZENEK: iki hafif dönen tabla; her birinde merkezden eşit uzaklıkta iki eş
# yük. A tablasında toplam kütle DAHA BÜYÜK ama yükler merkeze yakın; B'de
# kütle küçük, yükler uzakta: I = Σ m·r², B'nin eylemsizlik momenti büyük.
# Ardından B dönerken yükler merkeze kaydırılır: L = I·ω korunur, ω artar.
#
# YANILGILARIN SAYISAL KARŞILIĞI: I yerine toplam kütleyi yazmak; r² yerine r
# kullanmak; yükler kayınca kütle değişmedi diye ω'yı aynı saymak.
# ==========================================================================

_YENI_YARICAP = 1.0


def _donme_havuzu():
    havuz = []
    for m_a in (4, 6, 8):
        for r_a in (0.5,):
            for m_b in (2, 3):
                for r_b in (1.5, 2.0):
                    if m_a > m_b and m_a * r_a ** 2 < m_b * r_b ** 2:
                        havuz.append((m_a, r_a, m_b, r_b))
    return tuple(havuz)


_DONME = _donme_havuzu()


@bulmaca(ders="fizik", konu="donme_momentumu", kademeler=(12, 13), agirlik=1.3)
def atolye_tablasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Eylemsizlik momenti kütleye ve kütlenin eksene uzaklığının karesine bağlıdır."""
    m_a, r_a, m_b, r_b = rastgele.choice(_DONME)
    i_a = round(2 * m_a * r_a ** 2, 2)
    i_b = round(2 * m_b * r_b ** 2, 2)
    i_b2 = round(2 * m_b * _YENI_YARICAP ** 2, 2)
    w1 = rastgele.choice((2, 3, 4))
    w2 = round(w1 * i_b / i_b2, 2)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    def i_yanlislari(m, r, i):
        sozluk, gorulen = {}, [i]
        for deger, metin in (
                (2 * m, "Eylemsizlik momentini yalnız kütleye bağladın: toplam kütleyi "
                        "yazdın. Uzaklığın karesi de hesaba girer."),
                (round(2 * m * r, 2), "Uzaklığın karesini değil kendisini kullandın: "
                                      "I = Σ m·r².")):
            if all(abs(deger - g) > 0.01 for g in gorulen):
                sozluk[sy(deger).replace(",", ".")] = metin
                gorulen.append(deger)
        return sozluk

    w_yanlislari, gorulen = {}, [w2]
    for deger, metin in (
            (w1, "Eylemsizlik momentini yalnız kütleye bağladın: kütle değişmedi diye "
                 "açısal hızı aynı saydın."),
            (round(w1 * r_b / _YENI_YARICAP, 2), "Uzaklığın karesini değil kendisini "
                                                  "kullandın.")):
        if all(abs(deger - g) > 0.01 for g in gorulen):
            w_yanlislari[sy(deger).replace(",", ".")] = metin
            gorulen.append(deger)

    return Bulmaca(
        kod="fiz-atolye-tablasi",
        ders="fizik",
        baslik="Atölye Tablası",
        kademe=kademe,
        konu="donme_momentumu",
        kazanim="Eylemsizlik momentinin kütle dağılımına bağlı olduğunu açıklama; "
                "noktasal yükler için I = Σ m·r² hesaplama; açısal momentumun "
                "korunumuyla açısal hız değişimini bulma.",
        dikkat=8,
        brifing=(
            "Atölyede iki dönen tabla var; aynı motorla daha kolay döndürülecek olanı "
            "seçilecek.\n\n"
            "{} karar vermiş: \"A tablasındaki yükler daha ağır, onu döndürmek daha zor. "
            "B'yi kullanalım. Dönerken yükleri merkeze kaydırsak da kütle değişmediği "
            "için dönme hızı aynı kalır.\"\n\n"
            "Motor bağlanmadan önce iki tablayı doğru karşılaştırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Tabla kaydı",
                  "A tablası: iki yük, her biri {} kg, eksenden {} m uzakta.\n"
                  "B tablası: iki yük, her biri {} kg, eksenden {} m uzakta.\n"
                  "Tablaların kendi kütlesi ihmal edilecek kadar küçük.".format(
                      m_a, sy(r_a), m_b, sy(r_b)),
                  bedel=1, kritik=True),
            Kanit("Dönme notu",
                  "Noktasal yükler için I = Σ m·r². Aynı tork, eylemsizlik momenti büyük "
                  "olan tablayı daha yavaş hızlandırır. Dış tork yoksa L = I·ω korunur.",
                  bedel=1, kritik=True),
            Kanit("Deneme kaydı",
                  "B tablası {} rad/s ile dönerken iki yük de eksenden {} m uzağa "
                  "kaydırıldı; motor bağlı değildi.".format(w1, sy(_YENI_YARICAP)),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir tablayı döndürmenin zorluğunu (eylemsizlik momentini) ne belirler?",
                dogru=("Kütle ve kütlenin eksene uzaklığının karesi: uzaktaki kütle "
                       "daha etkilidir"),
                yanlislar={
                    "Yalnız toplam kütle: ağır olan her zaman daha zor döner":
                        "Eylemsizlik momentini yalnız kütleye bağladın. Kütlenin "
                        "nerede durduğu da önemli: I = Σ m·r².",
                    "Yalnız yarıçap: kütle önemli değildir, geniş tabla hep zor döner":
                        "Kütle de formülde var; ikisi birlikte belirler.",
                    ("Dönme hızı: hızlı dönen tablanın eylemsizlik momenti büyüktür, "
                     "durdurmak zordur"):
                        "Eylemsizlik momenti kütle dağılımına bağlıdır, hıza değil.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Dönme hareketinde kütlenin karşılığı eylemsizlik momentidir. "
                    "Eksenden uzaktaki kütle daha büyük çembersel yol alır; katkısı "
                    "uzaklığın karesiyle artar."
                ),
                ipuclari=[
                    "Dönme notundaki formülde hangi büyüklükler var?",
                    "Uzaklık iki katına çıkınca katkı kaç katına çıkar?",
                ],
                cozum="I = Σ m·r²\nL = I·ω korunur (dış tork yoksa)",
            ),
            sayi_adimi(
                soru="A tablasının eylemsizlik momenti kaç kg·m²?",
                cevap=i_a,
                birim="kg·m²",
                aciklama="I = 2 × {} × {}² = {} kg·m².".format(m_a, sy(r_a), sy(i_a)),
                yaygin_yanlislar=i_yanlislari(m_a, r_a, i_a),
                ipuclari=["Her yük için m·r² bul ve topla."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="B tablasının eylemsizlik momenti kaç kg·m²?",
                cevap=i_b,
                birim="kg·m²",
                aciklama="I = 2 × {} × {}² = {} kg·m².".format(m_b, sy(r_b), sy(i_b)),
                yaygin_yanlislar=i_yanlislari(m_b, r_b, i_b),
                ipuclari=["Her yük için m·r² bul ve topla."],
                puan=10,
                tolerans=0.01,
            ),
            secim_adimi(
                soru="Aynı motor torkuyla hangi tabla daha yavaş hızlanır?",
                dogru="B tablası: kütlesi küçük ama eylemsizlik momenti daha büyük",
                yanlislar={
                    "A tablası: yükleri daha ağır, ağır olan her zaman daha zor döner":
                        "Eylemsizlik momentini yalnız kütleye bağladın. A'nın yükleri "
                        "ağır ama eksene yakın; eylemsizlik momenti daha küçük.",
                    "İkisi aynı hızlanır; motor aynı, tork da aynı":
                        "Aynı tork, eylemsizlik momenti farklı tablaları farklı hızlandırır.",
                },
                rastgele=rastgele,
                aciklama="I(A) = {} kg·m², I(B) = {} kg·m²: B daha zor hızlanır.".format(
                    sy(i_a), sy(i_b)),
                ipuclari=["Bulduğun iki eylemsizlik momentini karşılaştır."],
                puan=10,
            ),
            sayi_adimi(
                soru="Yükler {} m uzağa kaydırılınca B tablası kaç rad/s ile döner?".format(
                    sy(_YENI_YARICAP)),
                cevap=w2,
                birim="rad/s",
                aciklama=("Yeni I = 2 × {} × {}² = {} kg·m². L korunur: {} × {} = {} × ω, "
                          "ω = {} rad/s.").format(m_b, sy(_YENI_YARICAP), sy(i_b2),
                                                   sy(i_b), w1, sy(i_b2), sy(w2)),
                yaygin_yanlislar=w_yanlislari,
                ipuclari=["Önce yeni eylemsizlik momentini bul; I·ω çarpımı değişmez."],
                puan=14,
                tolerans=0.01,
            ),
        ],
        kapanis=("Karar düzeltildi: A tablası daha ağır ama daha kolay dönüyor "
                 "(I = {} kg·m² ile {} kg·m²). Yükler merkeze kayınca B tablası {} rad/s "
                 "ile dönmeye başladı.").format(sy(i_a), sy(i_b), sy(w2)),
        odul={"itibar": 5, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# ELEKTROMANYETİK DALGALAR: BOŞLUKTA YAYILIR, SES YAYILMAZ (B37.13)
#
# `elektromanyetik_dalga` iki satırda boştu (2018: 12; 2026: 12). Bağlam:
# "Sefer araçlarının kullandığı dalga türlerini eşleme". `yaygin_yanlis`:
#
#   "Bütün dalgaların maddesel ortam gerektirdiğini sanmak."
#
# DÜZENEK: sefer cihazları vakum odasında sınanacak. Elektromanyetik dalga
# kullananlar (telsiz, radar, kızılötesi kamera, X ışını) boşlukta çalışır;
# mekanik dalga kullananlar (sonar, hoparlör, ultrason, sismik sensör)
# çalışmaz. c = λ·f ve röle uydusuna sinyal süresi t = d ÷ c.
#
# YANILGILARIN SAYISAL KARŞILIĞI: sinyal süresini ses hızıyla hesaplamak;
# megahertzi hertze çevirmemek. Çoklu seçimde mekanik dalgalı cihazları
# vakumda çalışır saymak.
# ==========================================================================

_EM_CIHAZLAR = (("telsiz", "radyo dalgası"), ("radar", "mikrodalga"),
                ("gece görüş kamerası", "kızılötesi ışınım"), ("röntgen cihazı", "X ışını"))
_MEKANIK_CIHAZLAR = (("sonar", "ses dalgası"), ("uyarı hoparlörü", "ses dalgası"),
                     ("ultrason tarayıcı", "ultrases"), ("sismik sensör", "yer içindeki titreşim dalgası"))
_VAKUM_ISIK_HIZI = 3e8      # m/s
_HAVA_SES_HIZI = 340       # m/s, havada


@bulmaca(ders="fizik", konu="elektromanyetik_dalga", kademeler=(12, 13), agirlik=1.3)
def vakum_odasi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Elektromanyetik dalgalar maddesel ortam gerektirmez; mekanik dalgalar gerektirir."""
    em = rastgele.sample(_EM_CIHAZLAR, 3)
    mekanik = rastgele.sample(_MEKANIK_CIHAZLAR, 3)
    cihazlar = [(c, True) for c in em] + [(c, False) for c in mekanik]
    rastgele.shuffle(cihazlar)
    secenekler = ["{} ({})".format(ad[:1].upper() + ad[1:], dalga) for (ad, dalga), _ in cihazlar]
    em_indeksler = [n for n, (_, e) in enumerate(cihazlar) if e]
    frekans = rastgele.choice((100, 150, 300, 600))            # MHz
    dalga_boyu = _VAKUM_ISIK_HIZI / (frekans * 1e6)
    mesafe = rastgele.choice((30000, 36000, 60000, 384000))    # km
    sure = round(mesafe * 1000 / _VAKUM_ISIK_HIZI, 4)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-vakum-odasi",
        ders="fizik",
        baslik="Vakum Odası",
        kademe=kademe,
        konu="elektromanyetik_dalga",
        kazanim="Elektromanyetik dalgaların maddesel ortam olmadan yayıldığını, mekanik "
                "dalgaların ortam gerektirdiğini açıklama; c = λ·f ile dalga boyunu ve "
                "boşlukta sinyal süresini hesaplama.",
        dikkat=7,
        brifing=(
            "Sefer cihazları uzay koşullarına benzeyen vakum odasında sınanacak; röle "
            "uydusuyla haberleşme de planlanıyor.\n\n"
            "{} test listesine şunu yazdı: \"Vakumda hava yok; bütün dalgalar ses gibi "
            "bir ortam ister. Telsiz de radar da orada çalışmaz, uyduyla haberleşme "
            "zaten imkânsız.\"\n\n"
            "Cihazlar odaya konmadan önce hangilerinin çalışacağını doğru bulmamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Cihaz listesi", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Dalga notu",
                  "Ses, ultrases ve yer içindeki titreşimler mekanik dalgadır: "
                  "taneciklerin titreşimiyle taşınır. Radyo, mikrodalga, kızılötesi, "
                  "görünür ışık ve X ışını elektromanyetik dalgadır: elektrik ve manyetik "
                  "alanın titreşimi, boşlukta 3 × 10⁸ m/s hızla yayılır. c = λ·f.",
                  bedel=1, kritik=True),
            Kanit("Haberleşme planı",
                  "Telsiz frekansı {} MHz. Röle uydusu {} km uzakta; arada boşluk var. "
                  "Havada ses hızı 340 m/s.".format(frekans, mesafe),
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Dalgaların yayılması için hangisi doğrudur?",
                dogru="Mekanik dalga ortam ister; elektromanyetik dalga boşlukta da yayılır",
                yanlislar={
                    ("Bütün dalgalar yayılmak için maddesel ortam gerektirir, boşlukta "
                     "titreşecek bir şey yoktur"):
                        "Bütün dalgaların maddesel ortam gerektirdiğini sandın. "
                        "Güneş ışığı Dünya'ya boşluktan geçerek ulaşıyor.",
                    "Hiçbir dalga ortam gerektirmez; ses de boşlukta yayılır":
                        "Ses taneciklerin titreşimidir; tanecik yoksa taşınamaz.",
                    "Elektromanyetik dalgalar yalnız havada yayılır, boşlukta söner":
                        "Elektromanyetik dalga alanların titreşimidir; taşınmak için "
                        "maddeye ihtiyaç duymaz.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Mekanik dalga, maddenin taneciklerini sırayla titreştirerek "
                    "ilerler. Elektromanyetik dalgada titreşen şey elektrik ve manyetik "
                    "alanlardır; bu yüzden boşlukta en yüksek hızla yayılır."
                ),
                ipuclari=[
                    "Güneş ışığı Dünya'ya nasıl ulaşıyor?",
                    "Dalga notunda hangi dalgalar taneciklerle taşınıyor?",
                ],
                cozum="Mekanik: ortam gerekir.\nElektromanyetik: boşlukta 3 × 10⁸ m/s.",
            ),
            coklu_adimi(
                soru="Vakum odasında hangi cihazların dalgası yayılır? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=em_indeksler,
                aciklama="Elektromanyetik dalga kullananlar çalışır; ses ve titreşim kullananlar çalışmaz.",
                ipuclari=["Her cihazın dalgasını dalga notundaki iki gruptan birine koy."],
                puan=12,
            ),
            sayi_adimi(
                soru="Telsiz dalgasının dalga boyu kaç m?",
                cevap=dalga_boyu,
                birim="m",
                aciklama="λ = c ÷ f = 3 × 10⁸ ÷ ({} × 10⁶) = {} m.".format(frekans, sy(dalga_boyu)),
                yaygin_yanlislar={
                    sy(round(_VAKUM_ISIK_HIZI / frekans, 2)).replace(",", "."):
                        "Frekansı megahertzden hertze çevirmedin: 1 MHz = 10⁶ Hz.",
                },
                ipuclari=["c = λ·f; frekansı hertze çevir."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Telsiz sinyali röle uydusuna kaç saniyede ulaşır?",
                cevap=sure,
                birim="s",
                aciklama="t = d ÷ c = {} × 10³ m ÷ 3 × 10⁸ m/s = {} s.".format(mesafe, sy(sure)),
                yaygin_yanlislar={
                    sy(round(mesafe * 1000 / _HAVA_SES_HIZI)).replace(",", "."):
                        "Bütün dalgaların maddesel ortam gerektirdiğini sandın ve ses "
                        "hızını kullandın; arada hava yok, sinyal ışık hızıyla gider.",
                    sy(round(mesafe / _VAKUM_ISIK_HIZI, 7)).replace(",", "."):
                        "Kilometreyi metreye çevirmedin.",
                },
                ipuclari=["Mesafeyi metreye çevir, ışık hızına böl."],
                puan=12,
                tolerans=0.001,
            ),
            yorum_adimi(
                soru="Test listesindeki \"uyduyla haberleşme imkânsız\" notu için hangisi doğru?",
                dogru="Yanlış: radyo dalgası elektromanyetiktir, boşlukta ışık hızıyla gider",
                yanlislar={
                    ("Doğru: arada hava olmadığı için sinyal uyduya ulaşamaz, sesin uzayda "
                     "duyulmaması gibi"):
                        "Bütün dalgaların maddesel ortam gerektirdiğini sandın.",
                    "Doğru, ama yalnız gece: gündüz Güneş ışığı sinyali engeller":
                        "Işık ve radyo dalgası birbirini engellemez; ikisi de boşlukta "
                        "yayılır.",
                },
                rastgele=rastgele,
                aciklama="Sinyal {} saniyede uyduya ulaşır; uzay araçları böyle haberleşir.".format(
                    sy(sure)),
                ipuclari=["Bulduğun sinyal süresine bak."],
                puan=8,
            ),
        ],
        kapanis=("Liste düzeltildi: elektromanyetik dalga kullanan cihazlar vakumda "
                 "çalışıyor, ses kullananlar çalışmıyor. Telsiz sinyali uyduya {} "
                 "saniyede ulaşır.").format(sy(sure)),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# FOTOELEKTRİK OLAY: EŞİĞİ FOTON ENERJİSİ BELİRLER, ŞİDDET DEĞİL (B37.13)
#
# `foton_kuantum` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Işık
# algılayıcısının eşik davranışını açıklama". `yaygin_yanlis`:
#
#   "Şiddeti artırmanın eşik altındaki her ışıkta elektron koparacağını sanmak."
#
# DÜZENEK: algılayıcının katodu bağlanma enerjisi W olan bir metal. Parlak
# ama foton enerjisi W'den küçük bir lamba ile sönük ama foton enerjisi W'den
# büyük bir lamba. E = 1240 ÷ λ (eV, nm). Şiddet foton SAYISINI artırır:
# eşik altında yine hiç elektron kopmaz; eşik üstünde kopan elektron sayısı
# artar ama en büyük kinetik enerji değişmez.
#
# YANILGILARIN SAYISAL KARŞILIĞI: kinetik enerjide bağlanma enerjisini
# çıkarmamak; şiddet iki katına çıkınca kinetik enerjiyi iki katına çıkarmak.
# ==========================================================================

# dalga boyu nm -> foton enerjisi eV (1240 ÷ λ tam çıkan değerler)
_FOTON_DALGALARI = (1240, 775, 620, 496, 400, 310, 248)
_KATOT_METALLERI = ((2.0, "sezyum"), (2.5, "potasyum"), (3.1, "kalsiyum"))


def _foton_havuzu():
    havuz = []
    for w, metal in _KATOT_METALLERI:
        for l1 in _FOTON_DALGALARI:
            for l2 in _FOTON_DALGALARI:
                e1, e2 = 1240.0 / l1, 1240.0 / l2
                if e1 < w < e2 and 0.5 <= e2 - w <= 2.5:
                    havuz.append((w, metal, l1, l2))
    return tuple(havuz)


_FOTON = _foton_havuzu()


@bulmaca(ders="fizik", konu="foton_kuantum", kademeler=(12, 13), agirlik=1.3)
def isik_algilayicisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Fotoelektrik olayda eşiği foton enerjisi belirler; şiddet yalnız foton sayısını değiştirir."""
    w, metal, l1, l2 = rastgele.choice(_FOTON)
    e1 = round(1240.0 / l1, 2)
    e2 = round(1240.0 / l2, 2)
    kinetik = round(e2 - w, 2)
    esik = round(1240.0 / w, 1)
    kat = rastgele.choice((5, 10, 20))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-isik-algilayicisi",
        ders="fizik",
        baslik="Işık Algılayıcısı",
        kademe=kademe,
        konu="foton_kuantum",
        kazanim="Fotoelektrik olayda elektron kopmasının foton enerjisine bağlı "
                "olduğunu, ışık şiddetinin yalnız foton sayısını değiştirdiğini "
                "açıklama; foton enerjisi, en büyük kinetik enerji ve eşik dalga boyunu "
                "hesaplama.",
        dikkat=8,
        brifing=(
            "Kapı güvenlik sisteminin ışık algılayıcısı yalnız bir lambayla çalışıyor; "
            "hangi lambanın kalacağına karar verilecek.\n\n"
            "{} karar vermiş: \"{} nm lamba çok parlak, ama algılayıcı onunla "
            "tepki vermedi. Şiddetini {} katına çıkarırsak mutlaka elektron koparır. "
            "{} nm lamba zaten sönük; onu sökelim.\"\n\n"
            "Lamba sökülmeden önce algılayıcının eşiğini doğru anlamamız gerekiyor."
        ).format(kisi, l1, kat, l2),
        kanitlar=[
            Kanit("Algılayıcı kaydı",
                  "Katot metali {}: bağlanma enerjisi (eşik enerjisi) {} eV (model değeri)."
                  .format(metal, sy(w)),
                  bedel=1, kritik=True),
            Kanit("Lamba kaydı",
                  "Parlak lamba: {} nm. Sönük lamba: {} nm. Sönük lambayla algılayıcıdan "
                  "akım geçiyor.".format(l1, l2),
                  bedel=1, kritik=True),
            Kanit("Foton notu",
                  "Foton enerjisi E = 1240 ÷ λ (E eV, λ nm). En büyük kinetik enerji "
                  "= E − bağlanma enerjisi. Işık şiddeti, saniyede gelen foton sayısıdır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Işık algılayıcısında elektron kopup kopmayacağını ne belirler?",
                dogru=("Tek fotonun enerjisi: bağlanma enerjisinden küçükse şiddet ne "
                       "olursa olsun kopmaz"),
                yanlislar={
                    ("Işığın şiddeti: yeterince parlak her ışık sonunda elektron koparır, "
                     "çünkü çok ışık çok enerji demektir"):
                        "Şiddeti artırmanın eşik altındaki her ışıkta elektron "
                        "koparacağını sandın. Her elektronu tek bir foton koparır; "
                        "foton sayısını artırmak tek fotonun enerjisini artırmaz.",
                    "Işığın algılayıcıya ne kadar süre düştüğü: uzun beklenirse elektron kopar":
                        "Elektron enerji biriktirmez; eşik altındaki fotonlar ne kadar "
                        "beklense de koparamaz.",
                    "Metalin cinsi önemli değildir; her ışık her metalden elektron koparır":
                        "Her metalin bağlanma enerjisi farklıdır; eşik metale bağlıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Işık enerjiyi fotonlar hâlinde taşır; bir elektronu bir foton "
                    "koparır. Foton enerjisi frekansa bağlıdır. Şiddet saniyede gelen "
                    "foton sayısıdır: eşik üstünde daha çok elektron koparır, eşik "
                    "altında hiç koparamaz."
                ),
                ipuclari=[
                    "Foton notunda şiddet neyi anlatıyor?",
                    "Parlak lambanın tek fotonu kaç eV taşıyor?",
                ],
                cozum="E = 1240 ÷ λ\nE < W: kopma yok (şiddet ne olursa olsun)\nK_maks = E − W",
            ),
            sayi_adimi(
                soru="Parlak lambanın ({} nm) bir fotonunun enerjisi kaç eV?".format(l1),
                cevap=e1,
                birim="eV",
                aciklama="E = 1240 ÷ {} = {} eV; bu değer bağlanma enerjisinden ({} eV) küçük.".format(
                    l1, sy(e1), sy(w)),
                ipuclari=["1240'ı dalga boyuna böl."],
                puan=10,
                tolerans=0.01,
            ),
            yorum_adimi(
                soru="Parlak lambanın şiddeti {} katına çıkarılırsa ne olur?".format(kat),
                dogru="Yine hiç elektron kopmaz: her foton yine eşiğin altında",
                yanlislar={
                    "Elektron kopar: şiddet artınca yeterli enerji toplanır, parlak ışık güçlüdür":
                        "Şiddeti artırmanın eşik altındaki her ışıkta elektron "
                        "koparacağını sandın; {} kat daha çok foton gelir ama her biri "
                        "yine {} eV taşır.".format(kat, sy(e1)),
                    "Kopan elektronların hızı {} katına çıkar".format(kat):
                        "Hiç elektron kopmuyor; hız da oluşmaz.",
                    "Birkaç saniye bekleyince elektron kopmaya başlar, enerji yavaş yavaş birikir":
                        "Elektron foton enerjisini biriktiremez; bekleme sonucu değiştirmez.",
                },
                rastgele=rastgele,
                aciklama="{} eV < {} eV: foton sayısı ne olursa olsun kopma yok.".format(
                    sy(e1), sy(w)),
                ipuclari=["Şiddet tek fotonun enerjisini değiştirir mi?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Sönük lambayla ({} nm) kopan elektronların en büyük kinetik enerjisi kaç eV?".format(l2),
                cevap=kinetik,
                birim="eV",
                aciklama="E = 1240 ÷ {} = {} eV. K = {} − {} = {} eV.".format(
                    l2, sy(e2), sy(e2), sy(w), sy(kinetik)),
                yaygin_yanlislar={
                    sy(e2).replace(",", "."):
                        "Bağlanma enerjisini çıkarmadın; fotonun enerjisinin bir kısmı "
                        "elektronu koparmaya harcanır.",
                    sy(round(e2 + w, 2)).replace(",", "."):
                        "Bağlanma enerjisini ekledin; koparmak enerji harcar, çıkarılmalı.",
                },
                ipuclari=["Foton enerjisinden bağlanma enerjisini çıkar."],
                puan=12,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Sönük lambanın şiddeti iki katına çıkarılırsa en büyük kinetik enerji kaç eV olur?",
                cevap=kinetik,
                birim="eV",
                aciklama=("Şiddet foton sayısını iki katına çıkarır: kopan elektron sayısı "
                          "artar, her fotonun enerjisi aynı kalır. K = {} eV.").format(sy(kinetik)),
                yaygin_yanlislar={
                    sy(round(2 * kinetik, 2)).replace(",", "."):
                        "Şiddetin tek fotonun enerjisini artırdığını sandın; artan "
                        "yalnız foton ve elektron sayısı.",
                },
                ipuclari=["Şiddet neyi değiştirir: foton sayısını mı, foton enerjisini mi?"],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Algılayıcının tepki verdiği en uzun dalga boyu (eşik dalga boyu) kaç nm?",
                cevap=esik,
                birim="nm",
                aciklama="λ₀ = 1240 ÷ {} = {} nm; bundan uzun dalga boylu ışık elektron koparamaz.".format(
                    sy(w), sy(esik)),
                ipuclari=["Foton enerjisi bağlanma enerjisine eşit olduğunda dalga boyu kaç olur?"],
                puan=8,
                tolerans=0.5,
            ),
        ],
        kapanis=("Karar düzeltildi: {} nm lamba kalıyor. {} nm lamba ne kadar parlak "
                 "olursa olsun {} eV eşiğini aşamaz; eşik dalga boyu {} nm."
                 ).format(l2, l1, sy(w), sy(esik)),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# MODERN TEKNOLOJİ: SÜPER İLETKEN YARI İLETKEN DEĞİLDİR (B37.13)
#
# `modern_teknoloji` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Sefer
# sensörü ve görüntüleme cihazlarının fizik ilkesini eşleme". `yaygin_yanlis`:
#
#   "Süper iletken ile yarı iletkeni aynı özellikte sanmak."
#
# DÜZENEK: iki numunenin sıcaklık-direnç ölçümü. Yarı iletkende sıcaklık
# düştükçe direnç ARTAR, hiç sıfır olmaz. Süper iletkende kritik sıcaklığın
# altında direnç TAM SIFIR olur: akım ısı kaybı olmadan geçer. Cihaz kartları:
# MR mıknatısı, manyetik raylı taşıyıcı, SQUID manyetometre süper iletken;
# LED, güneş paneli, kamera sensörü, işlemci, termistör yarı iletken.
#
# YANILGILARIN SAYISAL KARŞILIĞI: süper iletken kablodaki kaybı, numuneyi yarı
# iletken sayıp (soğuyunca direnci artar) hesaplamak; oda sıcaklığındaki
# direnci kullanmak.
# ==========================================================================

# (ad, [(T K, R Ω) ...] azalan sıcaklık sırasıyla, kablo deneme sıcaklığı K)
_SUPER_NUMUNELER = (
    ("YBCO seramik", ((300, 0.9), (150, 0.5), (95, 0.4), (90, 0.0), (80, 0.0)), 77),
    ("MgB₂ tel", ((300, 0.6), (100, 0.2), (41, 0.1), (37, 0.0), (30, 0.0)), 20),
)
_YARI_NUMUNELER = (
    ("saf silisyum", ((350, 2.0), (300, 5.0), (250, 12.0))),
    ("saf germanyum", ((350, 1.0), (300, 3.0), (250, 8.0))),
)
_SUPER_CIHAZLAR = ("MR cihazının mıknatısı", "manyetik raylı yük taşıyıcı",
                   "SQUID manyetometre")
_YARI_CIHAZLAR = ("LED lamba", "güneş paneli", "kamera görüntü sensörü",
                  "işlemci transistörleri", "termistör sıcaklık sensörü")


@bulmaca(ders="fizik", konu="modern_teknoloji", kademeler=(12, 13), agirlik=1.3)
def iletken_numuneler(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Süper iletkenin direnci kritik sıcaklık altında sıfırdır; yarı iletkenin direnci soğudukça artar."""
    s_ad, s_tablo, deneme_t = rastgele.choice(_SUPER_NUMUNELER)
    y_ad, y_tablo = rastgele.choice(_YARI_NUMUNELER)
    super_a = rastgele.random() < 0.5
    etiket_s, etiket_y = ("A", "B") if super_a else ("B", "A")
    tc_ust = max(t for t, r in s_tablo if r == 0.0)
    akim = rastgele.choice((20, 50, 100))
    r_oda = s_tablo[0][1]
    r_soguk_yari = y_tablo[-1][1]
    cihazlar = [(c, True) for c in rastgele.sample(_SUPER_CIHAZLAR, 2)] + \
               [(c, False) for c in rastgele.sample(_YARI_CIHAZLAR, 3)]
    rastgele.shuffle(cihazlar)
    cihaz_adlari = [c[:1].replace("i", "İ").upper() + c[1:] for c, _ in cihazlar]
    super_indeksler = [n for n, (_, s) in enumerate(cihazlar) if s]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    def tablo_yazisi(tablo):
        return "; ".join("{} K: {} Ω".format(t, sy(r)) for t, r in tablo)

    olcumler = {etiket_s: tablo_yazisi(s_tablo), etiket_y: tablo_yazisi(y_tablo)}

    return Bulmaca(
        kod="fiz-iletken-numuneler",
        ders="fizik",
        baslik="İletken Numuneler",
        kademe=kademe,
        konu="modern_teknoloji",
        kazanim="Süper iletken ve yarı iletkeni sıcaklık-direnç davranışıyla ayırt etme; "
                "kritik sıcaklığı veriden okuma; süper iletkende ısı kaybının sıfır "
                "olduğunu açıklama; teknolojik cihazları ilgili malzemeyle eşleme.",
        dikkat=8,
        brifing=(
            "Seferin sensör laboratuvarına iki yeni numune geldi; biri güç kablosunda "
            "kullanılacak.\n\n"
            "{} rapora şunu yazdı: \"Süper iletken de yarı iletken de aynı şey: ikisi "
            "de 'özel iletken'. Soğuyunca ikisinin de direnci artar, kablo biraz ısınır. "
            "Görüntüleme cihazlarındaki çipler de süper iletkendir.\"\n\n"
            "Kablo seçilmeden önce numuneleri doğru ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Direnç ölçümü",
                  "A numunesi: {}\nB numunesi: {}".format(olcumler["A"], olcumler["B"]),
                  bedel=1, kritik=True),
            Kanit("Kablo denemesi",
                  "Kablo {} numunesinden yapılacak ve {} K sıcaklıkta tutulacak; "
                  "{} A akım taşıyacak.".format(etiket_s, deneme_t, akim),
                  bedel=1, kritik=True),
            Kanit("Cihaz kartları", "\n".join(cihaz_adlari), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Süper iletken ve yarı iletken için hangisi doğrudur?",
                dogru=("Süper iletkende direnç kritik sıcaklık altında sıfır, yarı "
                       "iletkende soğudukça artar"),
                yanlislar={
                    "İkisi aynı malzemedir; soğuyunca ikisinin de direnci artar":
                        "Süper iletken ile yarı iletkeni aynı özellikte sandın. "
                        "Ölçümde bir numunenin direnci tam sıfıra iniyor.",
                    ("İkisinin de direnci soğuyunca sıfır olur, çünkü soğukta tanecikler "
                     "yavaşlar ve akım kolay geçer"):
                        "Yarı iletkende soğuyunca serbest yük taşıyıcı azalır, direnç "
                        "artar.",
                    ("Yarı iletkenler oda sıcaklığında sıfır dirençle çalışır, bu yüzden "
                     "çipler ısınmaz"):
                        "Sıfır direnç yalnız süper iletkende ve kritik sıcaklığın "
                        "altında görülür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yarı iletkende iletim, ısıyla serbest kalan yük taşıyıcılarına "
                    "bağlıdır: sıcaklık düşünce direnç artar. Süper iletken ise kritik "
                    "sıcaklığın altında direncini tamamen kaybeder; akım enerji "
                    "kaybetmeden akar ve manyetik alanı dışlar."
                ),
                ipuclari=[
                    "Direnç ölçümünde hangi numunenin direnci sıfıra iniyor?",
                    "Hangi numunenin direnci soğudukça büyüyor?",
                ],
                cozum="Süper iletken: T < Tc -> R = 0.\nYarı iletken: T azalınca R artar.",
            ),
            secim_adimi(
                soru="Hangi numune süper iletkendir?",
                dogru="{} numunesi: belli bir sıcaklığın altında direnci tam sıfır".format(etiket_s),
                yanlislar={
                    "{} numunesi: soğudukça direnci artıyor".format(etiket_y):
                        "Süper iletken ile yarı iletkeni aynı özellikte sandın; "
                        "soğudukça direnci artan yarı iletkendir.",
                    ("İkisi de süper iletken: ikisinin de direnci değişiyor, sıcaklığa tepki "
                     "veriyor"):
                        "Direncin değişmesi yetmez; süper iletkenlik direncin tam "
                        "sıfır olmasıdır.",
                },
                rastgele=rastgele,
                aciklama="{} numunesi {} K sıcaklıkta sıfır direnç gösteriyor; {} numunesinin direnci soğudukça artıyor.".format(
                    etiket_s, tc_ust, etiket_y),
                ipuclari=["Tabloda 0 Ω değerini ara."],
                puan=10,
            ),
            sayi_adimi(
                soru="Süper iletken numunenin direncinin sıfır ölçüldüğü en yüksek sıcaklık kaç K?",
                cevap=tc_ust,
                birim="K",
                aciklama="Tabloda sıfır direncin görüldüğü en yüksek sıcaklık {} K; kritik sıcaklık bunun hemen üstünde.".format(tc_ust),
                ipuclari=["0 Ω olan satırlardan en sıcak olanı seç."],
                puan=10,
            ),
            sayi_adimi(
                soru="Kablo {} K sıcaklıkta {} A taşırken ısıya dönüşen güç kaç W olur?".format(deneme_t, akim),
                cevap=0,
                birim="W",
                aciklama=("{} K, kritik sıcaklığın altında: R = 0. P = I²·R = {}² × 0 = 0 W."
                          ).format(deneme_t, akim),
                yaygin_yanlislar={
                    sy(akim * akim * r_soguk_yari).replace(",", "."):
                        "Süper iletken ile yarı iletkeni aynı özellikte sandın: "
                        "soğuyunca direncin arttığını varsayıp yarı iletkenin "
                        "direncini kullandın.",
                    sy(round(akim * akim * r_oda, 2)).replace(",", "."):
                        "Oda sıcaklığındaki direnci kullandın; kablo kritik sıcaklığın "
                        "altında tutuluyor.",
                },
                ipuclari=["Deneme sıcaklığında numunenin direnci kaç?"],
                puan=12,
            ),
            coklu_adimi(
                soru="Cihaz kartlarından hangileri süper iletken kullanır? (numaraları virgülle yaz)",
                secenekler=cihaz_adlari,
                dogru_indeksler=super_indeksler,
                aciklama=("Çok güçlü, kayıpsız akım gereken MR mıknatısı, manyetik raylı "
                          "taşıyıcı ve SQUID süper iletken kullanır. LED, güneş paneli, "
                          "kamera sensörü, işlemci ve termistör yarı iletkendir."),
                ipuclari=["Aşırı soğutma gerektiren, kayıpsız akım isteyen cihazları seç."],
                puan=12,
            ),
        ],
        kapanis=("Rapor düzeltildi: {} numunesi süper iletken ({} K sıcaklıkta sıfır "
                 "direnç), {} numunesi yarı iletken. Kablo {} K sıcaklıkta kayıpsız çalışacak."
                 ).format(etiket_s, tc_ust, etiket_y, deneme_t),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# NÜKLEER FİZİK: IŞINLANMA BULAŞMA DEĞİLDİR (B37.13)
#
# `nukleer_fizik` iki satırda boştu (2018: 12; 2026: 12). Bağlam: "Üs bilim
# arşivinde nükleer olayları kavramsal sınıflandırma". `yaygin_yanlis`:
#
#   "Işınlama ile radyoaktif madde bulaşmasını aynı sanmak."
#
# DÜZENEK: arşiv kartları. Işınlanma: cisim dışarıdaki kaynağın radyasyonuna
# maruz kalır; kaynak kaldırılınca biter, gama ile ışınlanan erzak radyoaktif
# OLMAZ. Bulaşma: radyoaktif maddenin kendisi yüzeye/vücuda geçer, oradan
# yaymayı sürdürür ve yarılanma ömrüyle azalır; temizlenmesi gerekir.
#
# YANILGILARIN SAYISAL KARŞILIĞI: ışınlanmış erzakın aktivitesini kaynağın
# aktivitesi saymak; bulaşmış eldivenin aktivitesini kaynaktan uzaklaşınca 0
# saymak; yarılanmayı doğrusal azalma sanmak.
# ==========================================================================

_ISINLANMA_KARTLARI = (
    "Erzak kolileri gama ışınıyla mikroplardan arındırıldı.",
    "Tıbbi şırıngalar paketlenmiş hâlde gama ışınıyla sterilize edildi.",
    "Kırık kol röntgen cihazıyla görüntülendi.",
    "Kaynak dikişleri gama kaynağıyla tarandı; kaynak kapatılıp kasasına kondu.",
)
_BULASMA_KARTLARI = (
    "Sızdıran kaptan dökülen radyoaktif toz eldivenlere yapıştı.",
    "Laboratuvar botlarının tabanına radyoaktif çamur bulaştı.",
    "Bir çalışan havadaki radyoaktif tozu soludu.",
    "Radyoaktif sıvı damlası tezgâha sıçradı.",
)
_YARILANMA_GUN = 8   # iyot-131


@bulmaca(ders="fizik", konu="nukleer_fizik", kademeler=(12, 13), agirlik=1.2)
def radyasyon_arsivi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Işınlanan cisim radyoaktif olmaz; bulaşan radyoaktif madde yaymayı sürdürür."""
    isinlama = rastgele.sample(_ISINLANMA_KARTLARI, 3)
    bulasma = rastgele.sample(_BULASMA_KARTLARI, 2)
    kartlar = [(k, False) for k in isinlama] + [(k, True) for k in bulasma]
    rastgele.shuffle(kartlar)
    secenekler = [k for k, _ in kartlar]
    bulasma_indeksleri = [n for n, (_, b) in enumerate(kartlar) if b]
    a0 = rastgele.choice((800, 1600, 3200))          # Bq
    gun = rastgele.choice((16, 24, 32))
    kalan = a0 / 2 ** (gun // _YARILANMA_GUN)
    yarilanma = gun // _YARILANMA_GUN
    bolme = round(a0 / yarilanma, 2)
    kaynak_bq = rastgele.choice((2, 5, 10))           # × 10¹⁴ Bq
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-radyasyon-arsivi",
        ders="fizik",
        baslik="Radyasyon Arşivi",
        kademe=kademe,
        konu="nukleer_fizik",
        kazanim="Işınlanma ile radyoaktif bulaşmayı ayırt etme; ışınlanan maddenin "
                "radyoaktif olmadığını açıklama; bulaşan maddenin aktivitesini "
                "yarılanma ömrüyle hesaplama.",
        dikkat=8,
        brifing=(
            "Üs bilim arşivindeki radyasyon olay kartları sınıflandırılacak; depoda da "
            "bir karar bekliyor.\n\n"
            "{} şunu yazdı: \"Gama ışınıyla arındırılan erzak artık radyoaktif; hepsini "
            "atalım. İyot-131 tozu bulaşan eldivenler ise kaynaktan uzaklaşınca "
            "zararsız olur, yıkamaya gerek yok.\"\n\n"
            "Erzak atılmadan önce olayları doğru ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Olay kartları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Depo ölçümü",
                  "Erzak {} × 10¹⁴ Bq aktiviteli kapalı bir gama kaynağıyla ışınlandı; "
                  "işlemden sonra erzakta radyoaktivite ölçülemedi. Eldivenlerde bugün "
                  "{} Bq iyot-131 ölçüldü; iyot-131 yarılanma ömrü {} gün.".format(
                      kaynak_bq, a0, _YARILANMA_GUN),
                  bedel=1, kritik=True),
            Kanit("Radyasyon notu",
                  "Işınlanma: radyasyon dışarıdan gelir, kaynak kaldırılınca biter. "
                  "Bulaşma: radyoaktif maddenin kendisi taşınır; temizlenene ya da "
                  "bozunana kadar radyasyon yayar.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Işınlanma ile radyoaktif bulaşma için hangisi doğrudur?",
                dogru=("Işınlanan cisim radyoaktif olmaz, bulaşan madde ise yaymayı "
                       "sürdürür"),
                yanlislar={
                    ("İkisi aynıdır: radyasyon alan her şey radyoaktif olur, radyasyon cismin "
                     "içine siner"):
                        "Işınlama ile radyoaktif madde bulaşmasını aynı sandın. Gama "
                        "ışını erzaktan geçip gider; erzağa radyoaktif madde eklemez.",
                    "Bulaşan radyoaktif madde, kaynaktan uzaklaşınca yaymayı bırakır":
                        "Bulaşmada kaynak zaten maddenin kendisi; nereye giderse "
                        "radyasyonu da oraya gider.",
                    "Işınlanan cisim kaynak kadar güçlü radyasyon yaymaya başlar":
                        "Işınlanma cismi kaynağa dönüştürmez; ölçümde erzakta "
                        "radyoaktivite yok.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Radyasyon bir ışın ya da parçacık akışıdır; bir cisimden geçmesi o "
                    "cismi radyoaktif yapmaz. Radyoaktif madde ise kararsız çekirdekler "
                    "içerir: toz, sıvı ya da çamur olarak başka yere taşınırsa oradan "
                    "yaymaya devam eder."
                ),
                ipuclari=[
                    "Depo ölçümünde erzakta radyoaktivite var mı?",
                    "Eldivendeki tozun radyasyonu nereden geliyor?",
                ],
                cozum="Işınlanma: dış kaynak, iz bırakmaz.\nBulaşma: madde taşınır, temizlenmeli.",
            ),
            coklu_adimi(
                soru="Hangi olay kartları radyoaktif bulaşmadır? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=bulasma_indeksleri,
                aciklama=("Toz, çamur, sıvı ya da solunan parçacıkta radyoaktif maddenin "
                          "kendisi taşınıyor: bulaşma. Gama ile arındırma, sterilizasyon, "
                          "röntgen ve kapatılan kaynakla tarama ışınlanmadır."),
                ipuclari=["Radyoaktif maddenin kendisi yer değiştiriyor mu?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Işınlanmış erzağın şimdiki aktivitesi kaç Bq?",
                cevap=0,
                birim="Bq",
                aciklama="Işınlanma erzağa radyoaktif madde eklemez; ölçümde aktivite yok: 0 Bq.",
                yaygin_yanlislar={
                    "{} × 10^14".format(kaynak_bq):
                        "Işınlama ile radyoaktif madde bulaşmasını aynı sandın: "
                        "kaynağın aktivitesini erzağa yükledin.",
                },
                ipuclari=["Depo ölçümünde erzak için ne yazıyor?"],
                puan=10,
            ),
            sayi_adimi(
                soru="Eldivenler yıkanmazsa {} gün sonra aktivite kaç Bq olur?".format(gun),
                cevap=kalan,
                birim="Bq",
                aciklama="{} gün = {} yarılanma. {} ÷ 2^{} = {} Bq.".format(
                    gun, gun // _YARILANMA_GUN, a0, gun // _YARILANMA_GUN, sy(kalan)),
                yaygin_yanlislar={
                    0:
                        "Işınlama ile bulaşmayı aynı sandın: kaynaktan uzaklaşınca "
                        "biteceğini düşündün. Bulaşan madde bozunarak yavaşça azalır.",
                    sy(bolme).replace(",", "."):
                        "Yarılanma sayısına böldün; her yarılanmada kalan miktar "
                        "yeniden yarıya iner: 2 üzeri yarılanma sayısına bölünür.",
                },
                ipuclari=["Kaç yarılanma ömrü geçtiğini bul; her birinde yarıya iner."],
                puan=12,
            ),
            yorum_adimi(
                soru="Depo için hangi karar doğru?",
                dogru="Erzak kullanılabilir; eldiven radyoaktif atığa ayrılıp alan temizlenmeli",
                yanlislar={
                    "Erzak atılmalı; eldivenler kaynaktan uzakta bekletilip yeniden kullanılmalı":
                        "Işınlama ile radyoaktif madde bulaşmasını aynı sandın; kararı "
                        "tam tersine kurdun.",
                    "İkisi de atılmalı: ikisi de radyasyonla karşılaştı":
                        "Karşılaşmak yetmez; erzakta radyoaktif madde yok.",
                },
                rastgele=rastgele,
                aciklama=("Erzakta ölçülebilir radyoaktivite yok. Eldivenler {} gün sonra "
                          "bile {} Bq yayıyor; bulaşma temizlenmeli.").format(gun, sy(kalan)),
                ipuclari=["İki ölçümü karşılaştır."],
                puan=10,
            ),
        ],
        kapanis=("Karar düzeltildi: ışınlanan erzak depoda kaldı; bulaşmış eldivenler "
                 "atık kabına alındı ({} gün sonra bile {} Bq)."
                 ).format(gun, sy(kalan)),
        odul={"itibar": 5, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# GİRİŞİM: SÖNÜMLÜ NOKTADA DALGALAR YOK OLMAZ (B37.13)
#
# `giris_kirinim` (2026: 12) ve `giris_kirinim_doppler` (2018: 12) tek
# satırlıktı; ikisinin `yaygin_yanlis` ve bağlamı aynı ("Haberleşme veya dalga
# deneyindeki örüntüleri karşılaştırma"):
#
#   "Girişimde dalgaların kalıcı yok olduğunu sanmak."
#
# DÜZENEK: toplantı salonunda aynı frekansta ses veren iki hoparlör. Yol farkı
# yarım dalga boyunun tek katıysa o noktada ses söner, çift katıysa güçlenir.
# Sönen noktada dalgalar yok olmaz: hoparlörlerden biri kapatılınca öteki
# duyulur; dalgalar kesiştikten sonra yollarına devam eder.
#
# YANILGININ SAYISAL KARŞILIĞI: bir hoparlör kapatılınca sönük noktadaki ses
# şiddetini 0 yazmak.
# ==========================================================================

_SES_HIZI_SALON = 340   # m/s


def _girisim_havuzu():
    havuz = []
    for f in (340, 680, 850):
        lam = _SES_HIZI_SALON / float(f)
        for d1 in (3.0, 3.5, 4.0):
            for k in (1, 2, 3, 4):          # yol farkı = k × λ/2
                d2 = round(d1 + k * lam / 2, 3)
                if abs(d2 * 100 - round(d2 * 100)) < 1e-6:
                    havuz.append((f, d1, d2, k))
    return tuple(havuz)


_GIRISIM = _girisim_havuzu()


@bulmaca(ders="fizik", konu="giris_kirinim", kademeler=(12, 13), agirlik=1.3)
def iki_hoparlor(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yıkıcı girişim bir noktada sönme demektir; dalgalar yok olmaz, yollarına devam eder."""
    f, d1, d2, k = rastgele.choice(_GIRISIM)
    lam = round(_SES_HIZI_SALON / float(f), 3)
    fark = round(d2 - d1, 3)
    sonuk = k % 2 == 1
    tek = rastgele.choice((2, 3, 4))    # bir hoparlörün o noktadaki şiddeti (birim)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-iki-hoparlor",
        ders="fizik",
        baslik="İki Hoparlör",
        kademe=kademe,
        konu="giris_kirinim",
        kazanim="İki kaynaklı girişimde yol farkından sönük ve güçlü noktaları bulma; "
                "yıkıcı girişimde dalgaların yok olmadığını, yalnız o noktada birbirini "
                "söndürdüğünü açıklama.",
        dikkat=8,
        brifing=(
            "Toplantı salonuna aynı sinyali çalan iki hoparlör kuruldu; bazı "
            "koltuklarda ses neredeyse hiç duyulmuyor.\n\n"
            "{} rapora şunu yazdı: \"Sessiz koltuklarda iki hoparlörün dalgaları "
            "çarpışıp yok olmuş. Oradaki ses enerjisi kaybolduğu için salonun "
            "arkasına da ses gitmiyor; hoparlörlerden birini kapatsak da o koltuk "
            "sessiz kalır.\"\n\n"
            "Hoparlörlerin yeri değiştirilmeden önce ölçümleri doğru yorumlamamız "
            "gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Ses kaydı",
                  "İki hoparlör aynı fazda {} Hz ses veriyor. Havada ses hızı {} m/s."
                  .format(f, _SES_HIZI_SALON),
                  bedel=1, kritik=True),
            Kanit("Koltuk ölçümü",
                  "A koltuğu 1. hoparlöre {} m, 2. hoparlöre {} m uzakta. Hoparlörlerden "
                  "yalnız biri çalarken A koltuğunda ölçülen şiddet {} birim.".format(
                      sy(d1), sy(d2), tek),
                  bedel=1, kritik=True),
            Kanit("Girişim notu",
                  "Yol farkı yarım dalga boyunun tek katıysa (λ/2, 3λ/2 ...) dalgalar o "
                  "noktada birbirini söndürür; tam dalga boyunun katıysa (λ, 2λ ...) "
                  "güçlendirir. Dalgalar kesiştikten sonra değişmeden yollarına devam eder.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="İki dalganın birbirini söndürdüğü noktada ne olur?",
                dogru=("Dalgalar o noktada söner ama yok olmaz; kesiştikten sonra "
                       "yollarına devam eder"),
                yanlislar={
                    ("Dalgalar çarpışıp kalıcı olarak yok olur; enerjileri kaybolur, bu "
                     "yüzden o koltuk sessizdir"):
                        "Girişimde dalgaların kalıcı yok olduğunu sandın. Hoparlörlerden "
                        "biri kapatılınca öteki yine duyulur.",
                    "Dalgalar birbirini geri yansıtır; çarpışan iki dalga geldiği yöne döner":
                        "Dalgalar birbirinin içinden geçer; yansıma olmaz.",
                    "Girişim yalnız ışıkta olur, seste olmaz; ses dalgaları birbirini etkilemez":
                        "Girişim bütün dalgalarda olur; salondaki sessiz koltuklar bunu gösteriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Girişim üst üste binmedir: bir noktada tepe ile çukur buluşursa "
                    "toplam sıfıra yaklaşır. Ama her dalga kendi yolunda ilerlemeyi "
                    "sürdürür; sönük noktalardaki enerji güçlü noktalara dağılmıştır."
                ),
                ipuclari=[
                    "Hoparlörlerden biri kapatılınca sönük koltuğa ne olur?",
                    "Girişim notu dalgaların kesiştikten sonraki durumu için ne diyor?",
                ],
                cozum="λ = v ÷ f\nYol farkı = tek × λ/2 -> sönük; tam λ katı -> güçlü",
            ),
            sayi_adimi(
                soru="Sesin dalga boyu kaç m?",
                cevap=lam,
                birim="m",
                aciklama="λ = {} ÷ {} = {} m.".format(_SES_HIZI_SALON, f, sy(lam)),
                ipuclari=["Ses hızını frekansa böl."],
                puan=8,
                tolerans=0.001,
            ),
            sayi_adimi(
                soru="A koltuğuna iki hoparlörden gelen yolların farkı kaç m?",
                cevap=fark,
                birim="m",
                aciklama="{} − {} = {} m; bu {} × (λ/2).".format(sy(d2), sy(d1), sy(fark), k),
                ipuclari=["İki uzaklığın farkını al."],
                puan=8,
                tolerans=0.001,
            ),
            secim_adimi(
                soru="A koltuğunda iki hoparlör birlikte çalarken ses nasıl duyulur?",
                dogru=("Sönük: yol farkı λ/2'nin tek katı" if sonuk
                       else "Güçlü: yol farkı λ/2'nin çift katı"),
                yanlislar={
                    ("Güçlü: yol farkı λ/2'nin çift katı" if sonuk
                     else "Sönük: yol farkı λ/2'nin tek katı"):
                        "Yol farkını dalga boyuyla yanlış karşılaştırdın.",
                    "Tek bir hoparlörün sesiyle aynı; iki ses birbirini etkilemez":
                        "İki dalga üst üste biniyor; sonuç ya güçlenir ya söner.",
                },
                rastgele=rastgele,
                aciklama="Yol farkı {} m = {} × {} m (λ/2): {}.".format(
                    sy(fark), k, sy(round(lam / 2, 3)),
                    "tek kat, sönük" if sonuk else "çift kat, güçlü"),
                ipuclari=["Yol farkını λ/2 değerine böl; tek mi çift mi?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Hoparlörlerden biri kapatılınca A koltuğunda ölçülen şiddet kaç birim olur?",
                cevap=tek,
                birim="birim",
                aciklama=("Tek hoparlörün dalgası girişim yapacak eşi olmadan A koltuğuna "
                          "ulaşır: {} birim.").format(tek),
                yaygin_yanlislar={
                    0:
                        "Girişimde dalgaların kalıcı yok olduğunu sandın; tek başına kalan "
                        "hoparlörün dalgası A koltuğuna ulaşıyor.",
                },
                ipuclari=["Koltuk ölçümünde tek hoparlör için ne yazıyor?"],
                puan=12,
            ),
            yorum_adimi(
                soru="Salonun arka duvarındaki mikrofon için hangisi doğru?",
                dogru="İki hoparlörün sesi de ulaşır; dalgalar kesişip yollarına devam eder",
                yanlislar={
                    "Hiç ses gelmez; dalgalar sessiz koltuklarda yok oldu":
                        "Girişimde dalgaların kalıcı yok olduğunu sandın.",
                    "Yalnız yakındaki hoparlörün sesi gelir; öteki yolda söndü ve arkaya ulaşamadı":
                        "Sönme yalnız belirli noktalarda olur; dalga yoluna devam eder.",
                },
                rastgele=rastgele,
                aciklama="Girişim notu: dalgalar kesiştikten sonra değişmeden ilerler.",
                ipuclari=["Girişim notunun son cümlesini oku."],
                puan=8,
            ),
        ],
        kapanis=("Rapor düzeltildi: A koltuğunda yol farkı {} m ({} × λ/2), ses {}. Dalgalar "
                 "yok olmuyor; biri kapatılınca A koltuğunda {} birim ses duyuluyor."
                 ).format(sy(fark), k, "sönük" if sonuk else "güçlü", tek),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# ATOM MODELLERİ: MODEL GERÇEK BOYUTLU RESİM DEĞİLDİR (B37.13)
#
# `atom_ve_evren` (2018: 12) ve `standart_model_atom` (2026: 12) tek
# satırlıktı; ikisinin `yaygin_yanlis` ve bağlamı aynı ("Bilim arşivindeki
# atom açıklamalarını dönemlerine göre karşılaştırma"):
#
#   "Atom modelini gerçek boyutlu resim sanmak."
#
# DÜZENEK: arşivdeki atom afişinde çekirdek, atomun beşte biri kadar çizilmiş.
# Ölçüm kartı: atom çapı yaklaşık 10⁻¹⁰ m, çekirdek çapı yaklaşık 10⁻¹⁵ m:
# oran 10⁵. Çekirdek bir bilye kadar olsa atom kilometrelerce büyük olurdu.
# Ayrıca modellerin dönem sırası (Dalton -> Thomson -> Rutherford -> Bohr ->
# kuantum -> standart model).
#
# YANILGININ SAYISAL KARŞILIĞI: atom/çekirdek çap oranını afişteki çizimden
# (5) okumak; ölçekli benzetmede afiş oranını kullanmak.
# ==========================================================================

_ATOM_CEKIRDEK_ORANI = 100000     # 10⁻¹⁰ m ÷ 10⁻¹⁵ m
_AFIS_ORANI = 5
_BENZETME_NESNELERI = (("bilye", 1), ("portakal", 8), ("futbol topu", 22))   # cm
_MODEL_DONEMLERI = (
    ("Dalton (1803)", "atom bölünmez, dolu bir küre"),
    ("Thomson (1897)", "pozitif yük içinde gömülü elektronlar"),
    ("Rutherford (1911)", "küçük, yoğun, pozitif çekirdek; atomun çoğu boşluk"),
    ("Bohr (1913)", "elektronlar belirli enerji düzeylerinde"),
    ("Kuantum modeli (1926 sonrası)", "elektronlar olasılık bulutu (orbital) içinde"),
    ("Standart model (1970'ler)", "proton ve nötron kuarklardan oluşur"),
)


@bulmaca(ders="fizik", konu="atom_ve_evren", kademeler=(12, 13), agirlik=1.2)
def atom_afisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Atom modelleri ölçekli resim değil, döneminin kanıtlarına dayanan temsillerdir."""
    nesne, boyut_cm = rastgele.choice(_BENZETME_NESNELERI)
    atom_m = boyut_cm / 100.0 * _ATOM_CEKIRDEK_ORANI
    afis_m = round(boyut_cm / 100.0 * _AFIS_ORANI, 2)
    karisik = list(range(len(_MODEL_DONEMLERI)))
    rastgele.shuffle(karisik)
    kartlar = ["{}: {}".format(*_MODEL_DONEMLERI[i]) for i in karisik]
    dogru_sira = [karisik.index(i) for i in range(len(_MODEL_DONEMLERI))]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-atom-afisi",
        ders="fizik",
        baslik="Atom Afişi",
        kademe=kademe,
        konu="atom_ve_evren",
        kazanim="Atom modellerinin gerçek boyutlu resim değil, döneminin kanıtlarına "
                "dayanan temsiller olduğunu açıklama; atom ve çekirdek boyutlarının "
                "oranını hesaplayıp ölçekli benzetme kurma; modelleri dönem sırasına koyma.",
        dikkat=7,
        brifing=(
            "Bilim arşivindeki atom afişi yeniden basılacak; altına açıklama "
            "yazılacak.\n\n"
            "{} açıklamayı şöyle yazdı: \"Afiş atomun gerçek resmidir: çekirdek "
            "atomun beşte biri büyüklüğünde, elektronlar da çizilen yörüngelerde "
            "döner. Eski modeller yanlış olduğu için arşivden atılabilir.\"\n\n"
            "Afiş basılmadan önce açıklamayı kanıtlara göre düzeltmemiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Ölçüm kartı",
                  "Atom çapı yaklaşık 10⁻¹⁰ m. Çekirdek çapı yaklaşık 10⁻¹⁵ m. Afişte "
                  "çekirdek 1 cm, atom 5 cm çizilmiş.",
                  bedel=1, kritik=True),
            Kanit("Model kartları", "\n".join(kartlar), bedel=1, kritik=True),
            Kanit("Model notu",
                  "Bir model, olguyu açıklamak için kurulan temsildir; ölçekli fotoğraf "
                  "değildir. Her yeni model, önceki modelin açıklayamadığı bir deney "
                  "sonucuyla ortaya çıktı.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Atom modelleri için hangisi doğrudur?",
                dogru=("Modeller ölçekli resim değil temsildir; çekirdek atomun yüz binde "
                       "biri kadardır"),
                yanlislar={
                    ("Afişteki atom gerçek boyutlu bir resimdir; oranlar doğrudur, bilim "
                     "insanları atomu ölçerek çizdi"):
                        "Atom modelini gerçek boyutlu resim sandın. Ölçüm kartına göre "
                        "çekirdek, afişteki gibi atomun beşte biri değil, yüz binde biri.",
                    ("Elektronlar afişteki yörüngelerde kesin yollar izler, gezegenlerin "
                     "Güneş'i dolanması gibi"):
                        "Kuantum modelinde elektronun kesin yolu yoktur; yörünge çizimi "
                        "bir temsil.",
                    "Eski modeller tamamen yanlıştır, hiçbir işe yaramaz":
                        "Her model kendi dönemindeki kanıtları açıkladı; yenisi eksiklerini tamamladı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çekirdeği gerçek ölçekte çizseydik afişte görünmezdi. Modeller "
                    "anlamayı kolaylaştıran temsillerdir ve yeni deneylerle değişir: "
                    "Rutherford çekirdeği, standart model protonun içindeki kuarkları "
                    "ekledi."
                ),
                ipuclari=[
                    "Ölçüm kartında atom ve çekirdek çaplarını karşılaştır.",
                    "Model notu modelin ne olduğunu söylüyor?",
                ],
                cozum="Oran = 10⁻¹⁰ ÷ 10⁻¹⁵ = 10⁵\nModel ≠ ölçekli resim",
            ),
            sayi_adimi(
                soru="Gerçekte atomun çapı çekirdeğin çapının kaç katıdır?",
                cevap=_ATOM_CEKIRDEK_ORANI,
                aciklama="10⁻¹⁰ ÷ 10⁻¹⁵ = 10⁵ = 100000 kat.",
                yaygin_yanlislar={
                    _AFIS_ORANI:
                        "Atom modelini gerçek boyutlu resim sandın: afişteki 5 cm ÷ 1 cm "
                        "oranını kullandın.",
                },
                ipuclari=["Üsleri çıkar: 10⁻¹⁰ ÷ 10⁻¹⁵ = 10^(−10 + 15)."],
                puan=12,
            ),
            sayi_adimi(
                soru="Çekirdek bir {} ({} cm) kadar olsaydı atomun çapı kaç metre olurdu?".format(nesne, boyut_cm),
                cevap=atom_m,
                birim="m",
                aciklama="{} cm = {} m; × 100000 = {} m.".format(
                    boyut_cm, sy(boyut_cm / 100.0), sy(atom_m)),
                yaygin_yanlislar={
                    sy(afis_m).replace(",", "."):
                        "Atom modelini gerçek boyutlu resim sandın; afişteki 5 katını aldın.",
                },
                ipuclari=["Önce santimetreyi metreye çevir, sonra oranla çarp."],
                puan=12,
                tolerans=0.5,
            ),
            sirala_adimi(
                soru="Model kartlarını dönem sırasına koy (numaraları sırayla yaz):",
                secenekler=kartlar,
                dogru_sira=dogru_sira,
                aciklama="Dalton -> Thomson -> Rutherford -> Bohr -> kuantum modeli -> standart model.",
                ipuclari=["Kartlardaki yıllara bak."],
                puan=10,
            ),
        ],
        kapanis=("Açıklama düzeltildi: afiş ölçekli değil; gerçekte atom çekirdekten "
                 "100000 kat büyük. Çekirdek bir {} kadar olsa atomun çapı {} m olurdu. "
                 "Modeller dönem sırasıyla arşivde kaldı."
                 ).format(nesne, sy(atom_m)),
        odul={"itibar": 4, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# REZONANS VE DEPREM: BÜYÜKLÜK ŞİDDET DEĞİL, REZONANS YALNIZ SES DEĞİL (B37.13)
#
# `rezonans_deprem` (2026: 10) ve `ses_rezonans_deprem` (2018: 10) tek
# satırlıktı; bağlamları aynı ("Üs titreşim kayıtlarından rezonans ihtimalini
# tartışma"). `yaygin_yanlis`:
#
#   "Deprem büyüklüğü ile şiddetini karıştırmak; rezonansı yalnız ses olayına
#    özgü sanmak."  /  "Ses yüksekliğiyle frekansı; büyüklükle şiddeti
#    karıştırmak."
#
# DÜZENEK: üs titreşim kaydı. (1) Aynı deprem iki istasyonda: büyüklük tek
# değer, şiddet yere göre değişir. (2) Üç yapının doğal periyodu (T ≈ 0,1 ×
# kat sayısı s); zeminin baskın titreşim frekansına doğal frekansı eşit olan
# yapı rezonansa girer. (3) Siren kısılınca ses yüksekliği azalır, frekansı
# (perdesi) değişmez.
#
# YANILGILARIN SAYISAL KARŞILIĞI: uzak istasyonda büyüklük yerine şiddeti
# yazmak; rezonans riskini en yüksek yapıya vermek; kısılan sirenin
# frekansını düşürmek.
# ==========================================================================

_YAPILAR = (("depo", 5), ("yurt binası", 10), ("gözlem kulesi", 20))   # kat sayısı
_ROMA = {3: "III", 4: "IV", 5: "V", 6: "VI", 7: "VII", 8: "VIII"}


@bulmaca(ders="fizik", konu="rezonans_deprem", kademeler=(10, 13), agirlik=1.3)
def titresim_kaydi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Rezonans her titreşim sisteminde olur; deprem büyüklüğü tek değerdir, şiddet yere göre değişir."""
    buyukluk = rastgele.choice((5.4, 5.8, 6.1, 6.6))
    yakin_siddet = rastgele.choice((7, 8))
    uzak_siddet = rastgele.choice((3, 4))
    riskli_ad, riskli_kat = rastgele.choice(_YAPILAR)
    zemin_f = round(1 / (0.1 * riskli_kat), 2)          # Hz
    sorulan_ad, sorulan_kat = rastgele.choice(_YAPILAR)
    sorulan_f = round(1 / (0.1 * sorulan_kat), 2)
    en_yuksek = _YAPILAR[-1][0]
    siren_f = rastgele.choice((600, 800, 1000))
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-titresim-kaydi",
        ders="fizik",
        baslik="Titreşim Kaydı",
        kademe=kademe,
        konu="rezonans_deprem",
        kazanim="Deprem büyüklüğünü şiddetinden ayırma; rezonansın yapılar gibi her "
                "titreşim sisteminde görüldüğünü açıklayıp doğal frekansla zemin "
                "frekansını karşılaştırma; ses yüksekliğini frekanstan ayırma.",
        dikkat=8,
        brifing=(
            "Dün geceki depremden sonra üssün titreşim kayıtları incelenecek; hangi "
            "yapının güçlendirileceğine karar verilecek.\n\n"
            "{} rapora şunu yazdı: \"Uzak istasyonda deprem daha küçük büyüklükteydi. "
            "Rezonans yalnız ses olayıdır, binalarla ilgisi yok; en çok en yüksek yapı "
            "sallanır. Deprem sireni de kısılınca frekansı düştü.\"\n\n"
            "Karar verilmeden önce kayıtları doğru yorumlamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("İstasyon kaydı",
                  "Deprem büyüklüğü (açığa çıkan enerjiye göre): {}. Üsse yakın istasyonda "
                  "şiddet {}, uzak istasyonda şiddet {}.".format(
                      sy(buyukluk), _ROMA[yakin_siddet], _ROMA[uzak_siddet]),
                  bedel=1, kritik=True),
            Kanit("Yapı kaydı",
                  "Yapıların doğal periyodu yaklaşık T = 0,1 × kat sayısı (s); doğal "
                  "frekans f = 1 ÷ T. Depo {} kat, yurt binası {} kat, gözlem kulesi {} kat. "
                  "Zeminin baskın titreşim frekansı {} Hz.".format(
                      _YAPILAR[0][1], _YAPILAR[1][1], _YAPILAR[2][1], sy(zemin_f)),
                  bedel=1, kritik=True),
            Kanit("Siren kaydı",
                  "Deprem sireni {} Hz çalıyor. Ses düğmesi kısılınca ölçülen genlik "
                  "azaldı; frekans ölçerde değer değişmedi.".format(siren_f),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Deprem ve titreşimler için hangisi doğrudur?",
                dogru=("Büyüklük tektir, şiddet yere göre değişir; doğal frekans "
                       "zemininkine eşitse rezonans olur"),
                yanlislar={
                    ("Uzak istasyonda depremin büyüklüğü de daha küçüktür, çünkü deprem "
                     "uzaklaştıkça zayıflar"):
                        "Deprem büyüklüğü ile şiddeti karıştırdın. Büyüklük depremin "
                        "kaynağındaki enerjiye bağlı tek bir değer; uzakta azalan şiddettir.",
                    ("Rezonans yalnız ses olayıdır; binalar rezonansa girmez, onlar yalnız "
                     "depremin gücüyle sarsılır"):
                        "Rezonansı yalnız ses olayına özgü sandın. Her titreşebilen "
                        "sistemin bir doğal frekansı vardır.",
                    "Sesin yüksekliği azalınca frekansı da düşer":
                        "Ses yüksekliğiyle frekansı karıştırdın; yükseklik genliğe, "
                        "perde frekansa bağlıdır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Büyüklük depremin kaynağını, şiddet bir yerdeki etkisini anlatır. "
                    "Yapılar da salıncak gibi kendi doğal frekanslarında titreşir; zemin "
                    "o frekansta sallanırsa genlik büyür. Seste genlik yüksekliği, "
                    "frekans perdeyi belirler."
                ),
                ipuclari=[
                    "İstasyon kaydında büyüklük kaç kez yazılmış?",
                    "Yapı kaydında zemin frekansı hangi yapının doğal frekansına eşit?",
                ],
                cozum="Büyüklük: tek değer. Şiddet: yere göre.\nRezonans: f_doğal = f_zemin.\nYükseklik: genlik; perde: frekans.",
            ),
            sayi_adimi(
                soru="Uzak istasyona göre depremin büyüklüğü kaçtır?",
                cevap=buyukluk,
                aciklama="Büyüklük tek değerdir: {}. Uzakta azalan şiddettir ({}).".format(
                    sy(buyukluk), _ROMA[uzak_siddet]),
                yaygin_yanlislar={
                    uzak_siddet:
                        "Deprem büyüklüğü ile şiddetini karıştırdın; {} uzak istasyondaki "
                        "şiddet.".format(_ROMA[uzak_siddet]),
                },
                ipuclari=["İstasyon kaydında büyüklük değerini bul."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="{} için doğal frekans kaç Hz?".format(sorulan_ad[:1].upper() + sorulan_ad[1:]),
                cevap=sorulan_f,
                birim="Hz",
                aciklama="T = 0,1 × {} = {} s; f = 1 ÷ {} = {} Hz.".format(
                    sorulan_kat, sy(0.1 * sorulan_kat), sy(0.1 * sorulan_kat), sy(sorulan_f)),
                yaygin_yanlislar=({sy(0.1 * sorulan_kat).replace(",", "."):
                                   "Periyodu yazdın; frekans periyodun tersidir."}
                                  if abs(0.1 * sorulan_kat - sorulan_f) > 0.01 else {}),
                ipuclari=["Önce periyodu bul, sonra tersini al."],
                puan=10,
                tolerans=0.01,
            ),
            secim_adimi(
                soru="Rezonans nedeniyle en çok hangi yapı risk altında?",
                dogru="{}: doğal frekansı zeminin baskın frekansına ({} Hz) eşit".format(
                    riskli_ad[:1].upper() + riskli_ad[1:], sy(zemin_f)),
                yanlislar=dict(
                    [("Hiçbiri: rezonans yalnız seste olur, yapılar yalnız sarsıntının "
                      "gücüyle hasar görür",
                      "Rezonansı yalnız ses olayına özgü sandın.")] +
                    [("{}: en yüksek yapı her zaman en çok sallanır".format(
                        en_yuksek[:1].upper() + en_yuksek[1:]),
                      "Yükseklik tek başına belirleyici değil; zemin frekansıyla eşleşen "
                      "doğal frekans önemli.")] * (riskli_ad != en_yuksek) +
                    [("Hepsi eşit risk altında; aynı zemin üzerindeler",
                      "Doğal frekansları farklı; yalnız eşleşen yapı rezonansa girer.")]),
                rastgele=rastgele,
                aciklama="Zemin {} Hz ile titreşiyor; doğal frekansı buna eşit olan {} rezonansa girer.".format(
                    sy(zemin_f), riskli_ad),
                ipuclari=["Üç yapının doğal frekansını hesapla, zeminle karşılaştır."],
                puan=12,
            ),
            sayi_adimi(
                soru="Siren kısıldıktan sonra sesin frekansı kaç Hz?",
                cevap=siren_f,
                birim="Hz",
                aciklama="Kısmak genliği azaltır; frekans aynı kalır: {} Hz.".format(siren_f),
                yaygin_yanlislar={
                    siren_f // 2:
                        "Ses yüksekliğiyle frekansı karıştırdın; kısılan ses daha pes olmaz.",
                },
                ipuclari=["Siren kaydında frekans ölçer ne gösterdi?"],
                puan=8,
            ),
        ],
        kapanis=("Rapor düzeltildi: depremin büyüklüğü her yerde {}, şiddet uzakta {}. {} "
                 "rezonans riski nedeniyle güçlendirilecek. Siren {} Hz çalmaya devam ediyor."
                 ).format(sy(buyukluk), _ROMA[uzak_siddet],
                          riskli_ad[:1].upper() + riskli_ad[1:], siren_f),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# YAYLI SİSTEM: DENGEDE HIZ EN BÜYÜK; ENERJİ UZAMANIN KARESİYLE (B37.13)
#
# `harmonik_yay` (2018: 12) ve `yay_enerjisi` (2026: 12) tek satırlıktı; ikisi
# aynı düzeneği anlatıyor ("Yaylı ölçüm düzeneğinin hareketini yorumlama" /
# "Atölye yayının kuvvet-uzama kaydını yorumlama"). `yaygin_yanlis`:
#
#   "Denge noktasında hızın da sıfır olduğunu sanmak."
#   "Uzamayı iki katına çıkarmanın enerjiyi yalnız iki kat yaptığını sanmak."
#
# DÜZENEK: sürtünmesiz yatay yüzeyde yaya bağlı ölçüm kızağı. Kuvvet-uzama
# kaydından k; yay A kadar çekilip bırakılıyor. Esneklik enerjisi E = ½kx²;
# uzama iki katına çıkınca enerji DÖRT katı. Denge noktasında kuvvet sıfır ama
# hız en büyük: ½kA² = ½mv².
#
# YANILGILARIN SAYISAL KARŞILIĞI: iki kat uzamada enerjiyi iki kat yazmak;
# denge noktasında hızı 0 yazmak.
# ==========================================================================


def _yay_havuzu():
    havuz = []
    for k in (100, 200, 400):          # N/m
        for a in (0.1, 0.2):          # m
            for m in (1, 2, 4):       # kg
                v2 = k * a * a / m
                v = v2 ** 0.5
                if abs(v * 100 - round(v * 100)) < 1e-6:
                    havuz.append((k, a, m))
    return tuple(havuz)


_YAY = _yay_havuzu()


@bulmaca(ders="fizik", konu="harmonik_yay", kademeler=(12, 13), agirlik=1.3)
def olcum_kizagi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yayda esneklik enerjisi uzamanın karesiyle artar; denge noktasında hız en büyüktür."""
    k, a, m = rastgele.choice(_YAY)
    enerji = round(0.5 * k * a * a, 3)
    enerji_iki = round(0.5 * k * (2 * a) ** 2, 3)
    v_max = round((k * a * a / m) ** 0.5, 2)
    olcumler = [(round(k * x, 1), x) for x in (0.05, 0.1, 0.15)]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-olcum-kizagi",
        ders="fizik",
        baslik="Ölçüm Kızağı",
        kademe=kademe,
        konu="harmonik_yay",
        kazanim="Kuvvet-uzama kaydından yay sabitini bulma; esneklik potansiyel "
                "enerjisinin uzamanın karesiyle arttığını hesaplama; basit harmonik "
                "harekette denge noktasında hızın en büyük olduğunu enerji korunumuyla "
                "açıklama.",
        dikkat=8,
        brifing=(
            "Atölyenin yaylı ölçüm kızağı ayarlanacak: kızak yay çekilip bırakılınca "
            "sürtünmesiz rayda ileri geri gidiyor.\n\n"
            "{} ayar notuna şunu yazdı: \"Yayı iki kat çekersek iki kat enerji depolar. "
            "Kızak denge noktasından geçerken yay kuvvet uygulamıyor; demek ki orada "
            "hız da sıfırdır, sensörü oraya koyalım.\"\n\n"
            "Sensör yerleştirilmeden önce hareketi doğru modellememiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Kuvvet-uzama kaydı",
                  "; ".join("{} N -> {} m".format(sy(f), sy(x)) for f, x in olcumler) + ".",
                  bedel=1, kritik=True),
            Kanit("Kızak kaydı",
                  "Kızağın kütlesi {} kg. Yay dengeden {} m çekilip serbest bırakılıyor; "
                  "ray sürtünmesiz.".format(m, sy(a)),
                  bedel=1, kritik=True),
            Kanit("Enerji notu",
                  "Yay kuvveti F = k·x. Esneklik potansiyel enerjisi E = ½·k·x². "
                  "Sürtünme yoksa esneklik ve kinetik enerjinin toplamı korunur.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yaylı kızağın hareketi için hangisi doğrudur?",
                dogru=("Yayda depolanan enerji uzamanın karesiyle artar, dengede kuvvet "
                       "sıfır ve hız en büyük"),
                yanlislar={
                    ("Denge noktasında kuvvet sıfır olduğu için hız da sıfırdır, kuvvet "
                     "yoksa hareket de olmaz"):
                        "Denge noktasında hızın da sıfır olduğunu sandın. Kuvvet sıfır "
                        "ama kızak oraya en hızlı hâlinde gelir; bütün enerji kinetiktir.",
                    "Uzama iki katına çıkınca depolanan enerji de iki katına çıkar":
                        "Uzamayı iki katına çıkarmanın enerjiyi yalnız iki kat yaptığını "
                        "sandın; E = ½kx², uzamanın karesi.",
                    "Kızak uç noktada en hızlıdır, çünkü kuvvet orada en büyüktür":
                        "Uç noktada kızak bir an durur; kuvvet en büyük, hız sıfır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Uç noktada bütün enerji yayda depolanır ve kızak bir an durur. "
                    "Dengeye doğru yay enerjisi kinetik enerjiye dönüşür; dengede yay "
                    "enerjisi sıfır, hız en büyük. Kuvvet ivmeyi belirler, hızı değil."
                ),
                ipuclari=[
                    "Denge noktasında yay enerjisi kaç? Enerji nereye gitti?",
                    "Enerji notundaki formülde x kaçıncı kuvvette?",
                ],
                cozum="k = F ÷ x\nE = ½kx²\n½kA² = ½mv²_max",
            ),
            sayi_adimi(
                soru="Yay sabiti k kaç N/m?",
                cevap=k,
                birim="N/m",
                aciklama="{} N ÷ {} m = {} N/m.".format(sy(olcumler[1][0]), sy(olcumler[1][1]), k),
                ipuclari=["Kuvveti uzamaya böl."],
                puan=8,
            ),
            sayi_adimi(
                soru="Yay {} m çekildiğinde kaç J esneklik enerjisi depolar?".format(sy(a)),
                cevap=enerji,
                birim="J",
                aciklama="E = ½ × {} × {}² = {} J.".format(k, sy(a), sy(enerji)),
                yaygin_yanlislar={
                    sy(round(0.5 * k * a, 3)).replace(",", "."):
                        "Uzamanın karesini almadın; E = ½kx².",
                    sy(round(k * a * a, 3)).replace(",", "."):
                        "½ çarpanını unuttun.",
                },
                ipuclari=["E = ½·k·x²."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Yay {} m çekilirse kaç J depolar?".format(sy(2 * a)),
                cevap=enerji_iki,
                birim="J",
                aciklama="Uzama iki katı: enerji 2² = 4 katı, {} J.".format(sy(enerji_iki)),
                yaygin_yanlislar={
                    sy(round(2 * enerji, 3)).replace(",", "."):
                        "Uzamayı iki katına çıkarmanın enerjiyi yalnız iki kat yaptığını "
                        "sandın; kare ilişkisi dört kat verir.",
                },
                ipuclari=["Uzama iki katına çıkınca x² kaç katına çıkar?"],
                puan=12,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="{} m çekilip bırakılan kızak denge noktasından kaç m/s hızla geçer?".format(sy(a)),
                cevap=v_max,
                birim="m/s",
                aciklama="½·k·A² = ½·m·v²: v = √({} × {}² ÷ {}) = {} m/s.".format(
                    k, sy(a), m, sy(v_max)),
                yaygin_yanlislar={
                    0:
                        "Denge noktasında hızın da sıfır olduğunu sandın; orada kuvvet "
                        "sıfır, hız en büyük.",
                },
                ipuclari=["Yaydaki bütün enerji dengede kinetik enerjiye dönüşür."],
                puan=12,
                tolerans=0.01,
            ),
        ],
        kapanis=("Ayar düzeltildi: yay {} m çekilince {} J, iki katı çekilince {} J depoluyor. "
                 "Kızak dengeden {} m/s ile geçiyor; hızı ölçen sensör oraya kondu."
                 ).format(sy(a), sy(enerji), sy(enerji_iki), sy(v_max)),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# GENLEŞME: ISINAN LEVHADAKİ DELİK DE BÜYÜR (B37.13)
#
# `genlesme` tek satırlıktı (2018: 9). Bağlam: "Atölye bağlantılarındaki
# genleşme boşluğunu yorumlama". `yaygin_yanlis`:
#
#   "Deliklerin ısınınca küçüleceğini sanmak."
#
# DÜZENEK: atölye rayının genleşme boşluğu (ΔL = L·α·ΔT) ve sıkışmış bir
# mili çıkarmak için ısıtılan delikli çelik levha. Levha ısınınca bütün
# boyutları aynı oranda büyür: delik de ΔD = D·α·ΔT kadar genişler (fotoğrafı
# büyütmek gibi).
#
# YANILGININ SAYISAL KARŞILIĞI: ısınan levhadaki delik çapını küçültmek
# (D − ΔD) ya da değişmez saymak (D).
# ==========================================================================

_CELIK_ALFA = 12e-6   # 1/°C


@bulmaca(ders="fizik", konu="genlesme", kademeler=(9, 13), agirlik=1.3)
def atolye_rayi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Isınan cismin her boyutu, delikleri de dahil, aynı oranda büyür."""
    uzunluk = rastgele.choice((10, 20, 25))          # m
    dt_ray = rastgele.choice((30, 40, 50))           # °C
    uzama_mm = round(uzunluk * 1000 * _CELIK_ALFA * dt_ray, 2)
    delik = rastgele.choice((40, 50, 80))            # mm
    dt_levha = rastgele.choice((100, 150, 200))      # °C
    artis = round(delik * _CELIK_ALFA * dt_levha, 3)
    yeni_delik = round(delik + artis, 3)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-atolye-rayi",
        ders="fizik",
        baslik="Atölye Rayı",
        kademe=kademe,
        konu="genlesme",
        kazanim="Katılarda boyca genleşmeyi hesaplama; ısınan bir cisimdeki deliğin de "
                "aynı oranda büyüdüğünü açıklama; genleşme boşluğunun gerekçesini "
                "yorumlama.",
        dikkat=7,
        brifing=(
            "Atölyede yeni vinç rayı döşenecek; bir makinede de mil, çelik levhanın "
            "deliğine sıkıştı.\n\n"
            "{} şunu önerdi: \"Raylar arasına boşluk bırakmaya gerek yok. Mili "
            "çıkarmak için de levhayı ısıtmayalım: ısınan metal genleşip deliği "
            "daraltır, mil iyice sıkışır. Levhayı soğutursak delik büyür.\"\n\n"
            "İşe başlamadan önce genleşmeyi doğru hesaplamamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Ray kaydı",
                  "Çelik ray parçası {} m. Yazla kış arasındaki sıcaklık farkı {} °C. "
                  "Çelik için α = 12 × 10⁻⁶ 1/°C.".format(uzunluk, dt_ray),
                  bedel=1, kritik=True),
            Kanit("Levha kaydı",
                  "Çelik levhadaki deliğin çapı {} mm. Levha {} °C ısıtılacak.".format(delik, dt_levha),
                  bedel=1, kritik=True),
            Kanit("Genleşme notu",
                  "Katı ısınınca bütün boyutları aynı oranda büyür: ΔL = L·α·ΔT. Delik, "
                  "levhanın bir parçası değil, levhayla aynı oranda büyüyen bir boşluktur; "
                  "levhanın fotoğrafını büyütmek gibi.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Isıtılan delikli levha için hangisi doğrudur?",
                dogru=("Levhanın bütün boyutları aynı oranda büyür; delik de genişler"),
                yanlislar={
                    "Metal genleşip deliğin içine doğru taşar; delik küçülür":
                        "Deliklerin ısınınca küçüleceğini sandın. Metal her yönde aynı "
                        "oranda genleşir; deliğin çevresi de uzar.",
                    "Levha genleşir ama delik aynı kalır, çünkü delikte genleşecek metal yoktur":
                        "Delik levhanın boyutlarından biri; o da aynı oranda büyür.",
                    "Isınan metal yalnız kalınlaşır, eni ve boyu değişmez":
                        "Genleşme her boyutta olur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Isınan levhadaki her atom arası uzaklık aynı oranda artar. Deliğin "
                    "kenarındaki çember de bir metal çizgisi gibi uzar; çapı büyür. "
                    "Bu yüzden sıkışan mil, levha ısıtılınca kolayca çıkar."
                ),
                ipuclari=[
                    "Deliğin kenarındaki metal çember ısınınca uzar mı, kısalır mı?",
                    "Genleşme notundaki fotoğraf benzetmesini düşün.",
                ],
                cozum="ΔL = L·α·ΔT\nDelik de: ΔD = D·α·ΔT (büyür)",
            ),
            sayi_adimi(
                soru="Ray parçası yazla kış arasında kaç mm uzar?",
                cevap=uzama_mm,
                birim="mm",
                aciklama="ΔL = {} m × 12 × 10⁻⁶ × {} = {} m = {} mm.".format(
                    uzunluk, dt_ray, sy(uzama_mm / 1000), sy(uzama_mm)),
                yaygin_yanlislar={
                    sy(round(uzama_mm / 1000, 5)).replace(",", "."):
                        "Sonucu metre olarak bıraktın; milimetreye çevir.",
                },
                ipuclari=["L·α·ΔT hesapla, sonucu milimetreye çevir."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Levha {} °C ısıtılınca deliğin çapı kaç mm olur?".format(dt_levha),
                cevap=yeni_delik,
                birim="mm",
                aciklama="ΔD = {} × 12 × 10⁻⁶ × {} = {} mm. Yeni çap {} mm.".format(
                    delik, dt_levha, sy(artis), sy(yeni_delik)),
                yaygin_yanlislar={
                    sy(round(delik - artis, 3)).replace(",", "."):
                        "Deliklerin ısınınca küçüleceğini sandın; delik de genleşir.",
                    delik:
                        "Deliğin değişmeyeceğini sandın; o da aynı oranda büyür.",
                },
                ipuclari=["Deliği aynı malzemeden bir çubuk gibi düşün."],
                puan=12,
                tolerans=0.001,
            ),
            secim_adimi(
                soru="Sıkışan mili çıkarmak için ne yapılmalı?",
                dogru="Levha ısıtılmalı: delik büyür, mil gevşer",
                yanlislar={
                    "Levha soğutulmalı: soğuyan metal çekilir, delik büyür":
                        "Deliklerin ısınınca küçüleceğini sandın; soğuyan levhanın "
                        "deliği de küçülür, mil daha çok sıkışır.",
                    "Hiçbir şey işe yaramaz; sıcaklık deliği etkilemez":
                        "Delik de genleşir ve büzülür.",
                },
                rastgele=rastgele,
                aciklama="Isınan levhanın deliği {} mm büyür; mil çıkar.".format(sy(artis)),
                ipuclari=["Bulduğun yeni çap eskisinden büyük mü?"],
                puan=10,
            ),
        ],
        kapanis=("Plan düzeltildi: ray parçaları arasına {} mm genleşme boşluğu bırakıldı; "
                 "levha ısıtılınca delik {} mm oldu, mil çıktı."
                 ).format(sy(uzama_mm), sy(yeni_delik)),
        odul={"itibar": 4, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# ADEZYON VE KOHEZYON: YÜZEY GERİLİMİ KILCALLIK DEĞİLDİR (B37.13)
#
# `adezyon_kohezyon` tek satırlıktı (2018: 9). Bağlam: "Seradaki ince
# borularda sıvı davranışını yorumlama". `yaygin_yanlis`:
#
#   "Yüzey gerilimi ile kılcallığı aynı olay saymak."
#
# DÜZENEK: sera gözlem defteri. Yüzey gerilimi: sıvı yüzeyindeki moleküllerin
# birbirini çekmesi (kohezyon) -> küresel damla, yüzen iğne. Kılcallık: ince
# boruda sıvı-yüzey çekimi (adezyon) ile sıvının kendi çekimi (kohezyon)
# yarışı -> su yükselir, cıva alçalır; yükselme boru yarıçapıyla ters orantılı.
#
# YANILGININ SAYISAL KARŞILIĞI: daha ince boruda yükselmeyi aynı saymak;
# kılcal gözlem sayısına yüzey gerilimi gözlemlerini de katmak.
# ==========================================================================

_KILCAL_GOZLEMLER = (
    "İnce cam boruya konan su, borunun içinde dışındaki su yüzeyinden yukarı çıktı.",
    "Kâğıt havlunun ucu suya değince su havlu boyunca yukarı yayıldı.",
    "Kuru toprağın altından verilen su, toprağın üst kısmına doğru çıktı.",
)
_YUZEY_GOZLEMLER = (
    "Yağlı bir iğne su yüzeyine yatay konunca batmadan kaldı.",
    "Musluktan düşen su damlaları küresel biçim aldı.",
    "Su böcekleri gölet yüzeyinde batmadan yürüdü.",
)


@bulmaca(ders="fizik", konu="adezyon_kohezyon", kademeler=(9, 13), agirlik=1.3)
def sera_borulari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yüzey gerilimi kohezyondan, kılcallık adezyon ile kohezyonun yarışından doğar."""
    kilcal = rastgele.sample(_KILCAL_GOZLEMLER, 2)
    yuzey = rastgele.sample(_YUZEY_GOZLEMLER, 2)
    gozlemler = [(g, True) for g in kilcal] + [(g, False) for g in yuzey]
    rastgele.shuffle(gozlemler)
    metinler = [g for g, _ in gozlemler]
    kilcal_indeksler = [n for n, (_, k) in enumerate(gozlemler) if k]
    h1 = rastgele.choice((15, 20, 30))          # mm, 1 mm yarıçaplı boruda
    r2 = rastgele.choice((0.5, 0.25))           # mm
    h2 = round(h1 * 1.0 / r2, 1)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-sera-borulari",
        ders="fizik",
        baslik="Sera Boruları",
        kademe=kademe,
        konu="adezyon_kohezyon",
        kazanim="Yüzey gerilimini (kohezyon) kılcallıktan (adezyon ile kohezyonun "
                "yarışı) ayırt etme; kılcal yükselmenin boru yarıçapıyla ters orantılı "
                "olduğunu yorumlama; suyun yükselip cıvanın alçalmasını açıklama.",
        dikkat=7,
        brifing=(
            "Seranın damla sulama sistemine ince borular eklenecek; gözlem defteri "
            "incelenecek.\n\n"
            "{} deftere şunu yazdı: \"Yüzey gerilimi ile kılcallık aynı olay: su "
            "damlasının küresel olması da ince boruda suyun yükselmesi de aynı şey. "
            "Boru inceldikçe de su aynı yüksekliğe çıkar.\"\n\n"
            "Borular seçilmeden önce gözlemleri doğru ayırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Gözlem defteri", "\n".join(metinler), bedel=1, kritik=True),
            Kanit("Boru deneyi",
                  "1 mm yarıçaplı cam boruda su {} mm yükseldi. Aynı camdan {} mm "
                  "yarıçaplı boru da denenecek. Cıva ise cam boruda dışarıdaki "
                  "yüzeyden aşağıda kaldı.".format(h1, sy(r2)),
                  bedel=1, kritik=True),
            Kanit("Kuvvet notu",
                  "Kohezyon: aynı cins moleküllerin birbirini çekmesi. Adezyon: farklı "
                  "cins moleküllerin (sıvı-cam) birbirini çekmesi. Yüzey gerilimi "
                  "kohezyondan doğar. Kılcallıkta adezyon kohezyondan büyükse sıvı "
                  "yükselir; yükselme boru yarıçapıyla ters orantılıdır.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yüzey gerilimi ve kılcallık için hangisi doğrudur?",
                dogru=("Yüzey gerilimi kohezyondan doğar; kılcallık adezyon-kohezyon "
                       "yarışından"),
                yanlislar={
                    ("Yüzey gerilimi ile kılcallık aynı olaydır; ikisi de sıvının yüzeyinde "
                     "görülür"):
                        "Yüzey gerilimi ile kılcallığı aynı olay saydın. Küresel damla "
                        "için yüzey gerekmez; kılcal yükselme ise ince bir boru ister.",
                    "Kılcallık yalnız kohezyondan doğar; boru malzemesi önemsizdir":
                        "Kılcallıkta sıvı-yüzey çekimi (adezyon) belirleyicidir; cıva "
                        "aynı camda alçalıyor.",
                    ("Yüzey gerilimi yalnız ince borularda görülür; geniş yüzeyde etkisi "
                     "dağılır"):
                        "Yüzey gerilimi açık su yüzeyinde de görülür: yüzen iğne.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Yüzeydeki moleküller yalnız içeriden çekilir; yüzey gergin bir zar "
                    "gibi davranır: yüzey gerilimi. İnce boruda ise su camı sudan daha "
                    "çok çeker (adezyon > kohezyon) ve kenarlardan yukarı tırmanır: "
                    "kılcallık. Cıvada kohezyon baskındır, cıva alçalır."
                ),
                ipuclari=[
                    "Küresel damla oluşmak için bir boru gerekir mi?",
                    "Kuvvet notunda kılcallık hangi iki çekime bağlı?",
                ],
                cozum="Yüzey gerilimi: kohezyon.\nKılcallık: adezyon ↔ kohezyon; h ∝ 1/r.",
            ),
            coklu_adimi(
                soru="Defterdeki gözlemlerden hangileri kılcallıktır? (numaraları virgülle yaz)",
                secenekler=metinler,
                dogru_indeksler=kilcal_indeksler,
                aciklama="Sıvının ince boşluk ya da lif boyunca yükselmesi kılcallıktır; yüzen iğne, küresel damla ve su böceği yüzey gerilimidir.",
                ipuclari=["Sıvı ince bir boşlukta yükseliyor mu?"],
                puan=12,
            ),
            sayi_adimi(
                soru="{} mm yarıçaplı boruda su kaç mm yükselir?".format(sy(r2)),
                cevap=h2,
                birim="mm",
                aciklama="Yükselme yarıçapla ters orantılı: {} × (1 ÷ {}) = {} mm.".format(
                    h1, sy(r2), sy(h2)),
                yaygin_yanlislar={
                    h1:
                        "Boru inceldikçe yükselmenin aynı kalacağını sandın; ince boruda "
                        "su daha yükseğe çıkar.",
                    sy(round(h1 * r2, 2)).replace(",", "."):
                        "Doğru orantı kurdun; ilişki ters orantı.",
                },
                ipuclari=["Yarıçap kaç kat küçüldü? Yükselme o kadar kat artar."],
                puan=12,
                tolerans=0.1,
            ),
            secim_adimi(
                soru="Cıva cam boruda neden alçalır?",
                dogru="Cıvada kohezyon, cama olan çekimden (adezyon) büyük",
                yanlislar={
                    "Cıvanın yüzey gerilimi yoktur; sıvı metal borunun duvarına tutunamaz":
                        "Cıvanın yüzey gerilimi sudan bile büyüktür; alçalmanın nedeni "
                        "kohezyonun adezyondan büyük olması.",
                    "Cıva sudan ağır olduğu için; ağırlık tek nedendir":
                        "Su da ağırlığına rağmen yükseliyor; belirleyici adezyon-kohezyon farkı.",
                },
                rastgele=rastgele,
                aciklama="Kohezyon > adezyon: cıva camdan uzaklaşır, boruda alçalır.",
                ipuclari=["Kuvvet notundaki koşulun tersini düşün."],
                puan=10,
            ),
        ],
        kapanis=("Defter düzeltildi: yüzen iğne ve küresel damla yüzey gerilimi, yükselen "
                 "su kılcallık. {} mm yarıçaplı boruda su {} mm yükselecek."
                 ).format(sy(r2), sy(h2)),
        odul={"itibar": 4, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# AKIŞKANLAR: DAR KESİTTE HIZ ARTAR (SÜREKLİLİK) (B37.13)
#
# `akiskan_akis` tek satırlıktı (2026: 9). Bağlam: "Üs boru hattının geniş ve
# dar bölümlerini karşılaştırma". `yaygin_yanlis`:
#
#   "Dar kesitte süratin azaldığını sanmak; model koşullarını unutmak."
#
# DÜZENEK: üs su hattının geniş bölümü ve daralan bölümü. Sıkıştırılamaz,
# kararlı, sızıntısız akışta debi her kesitte aynı: A1·v1 = A2·v2. Dar kesitte
# hız artar, basınç düşer. Model koşulu bozulursa (sızıntı) hesap geçmez.
#
# YANILGILARIN SAYISAL KARŞILIĞI: dar kesitteki hızı azaltmak (v1·A2/A1);
# sızıntılı hatta süreklilik denklemini yine de uygulamak.
# ==========================================================================


@bulmaca(ders="fizik", konu="akiskan_akis", kademeler=(9, 13), agirlik=1.3)
def su_hatti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Sıkıştırılamaz kararlı akışta debi korunur; dar kesitte hız artar."""
    a1 = rastgele.choice((20, 40, 60))          # cm² (2 ve 4 ile tam bölünür)
    kat = rastgele.choice((2, 4))
    a2 = a1 // kat
    v1 = rastgele.choice((1.0, 1.5, 2.0))       # m/s
    v2 = v1 * kat
    debi = round(a1 * 1e-4 * v1 * 1000, 2)      # L/s
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-su-hatti",
        ders="fizik",
        baslik="Su Hattı",
        kademe=kademe,
        konu="akiskan_akis",
        kazanim="Sıkıştırılamaz kararlı akışta süreklilik denklemiyle (A1·v1 = A2·v2) dar "
                "kesitteki hızı hesaplama; debiyi bulma; modelin koşullarını ve dar "
                "kesitte basıncın düştüğünü açıklama.",
        dikkat=7,
        brifing=(
            "Üssün su hattında geniş borudan dar boruya geçilen bir bölüm var; sayaç "
            "yerleştirilecek.\n\n"
            "{} ölçüm planına şunu yazdı: \"Dar boruda su sıkışır ve yavaşlar; hız "
            "sayacını dar kısma koyarsak düşük değer okuruz. Hattın ortasındaki küçük "
            "sızıntı da hesabı etkilemez.\"\n\n"
            "Sayaç takılmadan önce akışı doğru modellememiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Hat kaydı",
                  "Geniş bölümün kesit alanı {} cm², dar bölümünki {} cm². Geniş bölümde "
                  "su {} m/s hızla akıyor.".format(a1, a2, sy(v1)),
                  bedel=1, kritik=True),
            Kanit("Akış notu",
                  "Model koşulları: su sıkıştırılamaz, akış kararlı, iki kesit arasında "
                  "sızıntı ya da ek giriş yok. Bu koşullarda debi (A·v) her kesitte aynı.",
                  bedel=1, kritik=True),
            Kanit("Basınç ölçümü",
                  "Geniş bölümdeki basınç ölçer dar bölümdekinden daha büyük değer gösteriyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Borunun daralan bölümünde su için hangisi doğrudur?",
                dogru=("Model koşullarında debi aynı kalır, dar kesitte su hızlanır, "
                       "basınç düşer"),
                yanlislar={
                    "Dar kesitte su sıkışır ve yavaşlar, dar yoldan geçmek zordur":
                        "Dar kesitte süratin azaldığını sandın. Aynı sürede aynı miktar "
                        "su geçmesi için dar kesitte daha hızlı akmalı.",
                    "Süreklilik denklemi her boruda, sızıntı olsa da geçerlidir":
                        "Model koşullarını unuttun; sızıntı varsa kesitlerden geçen "
                        "debi aynı olmaz.",
                    ("Dar kesitte basınç artar, çünkü su sıkışır ve duvarlara daha çok "
                     "bastırır"):
                        "Su sıkıştırılamaz; basınç ölçümü dar kısımda basıncın düştüğünü gösteriyor.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Su sıkıştırılamadığı için her saniye geniş kesitten ne kadar su "
                    "geçiyorsa dar kesitten de o kadar geçmelidir: A1·v1 = A2·v2. Kesit "
                    "küçülünce hız aynı oranda büyür. Hızlanan suyun basıncı düşer."
                ),
                ipuclari=[
                    "Aynı sürede iki kesitten geçen su miktarı farklı olabilir mi?",
                    "Akış notunda hangi koşullar yazıyor?",
                ],
                cozum="A1·v1 = A2·v2 (sıkıştırılamaz, kararlı, sızıntısız)",
            ),
            sayi_adimi(
                soru="Dar bölümde suyun hızı kaç m/s?",
                cevap=v2,
                birim="m/s",
                aciklama="v2 = v1 × A1 ÷ A2 = {} × {} ÷ {} = {} m/s.".format(sy(v1), a1, a2, sy(v2)),
                yaygin_yanlislar={
                    sy(round(v1 / kat, 3)).replace(",", "."):
                        "Dar kesitte süratin azaldığını sandın; oranı ters kurdun.",
                    sy(v1).replace(",", "."):
                        "Hızın değişmediğini sandın; kesit küçülünce hız artar.",
                },
                ipuclari=["Kesit kaç kat küçüldü? Hız o kadar kat artar."],
                puan=12,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Hattın debisi kaç L/s?",
                cevap=debi,
                birim="L/s",
                aciklama="{} cm² = {} m². Debi = {} × {} = {} m³/s = {} L/s.".format(
                    a1, sy(a1 * 1e-4), sy(a1 * 1e-4), sy(v1), sy(round(a1 * 1e-4 * v1, 6)), sy(debi)),
                ipuclari=["Alanı metrekareye çevir, hızla çarp, litreye çevir."],
                puan=10,
                tolerans=0.01,
            ),
            secim_adimi(
                soru="Hattın iki bölümü arasında sızıntı olsaydı ne değişirdi?",
                dogru="Süreklilik denklemi uygulanamaz: iki kesitin debisi artık aynı değil",
                yanlislar={
                    "Hiçbir şey: A1·v1 = A2·v2 yine geçerlidir, denklem her boru için yazılır":
                        "Model koşullarını unuttun; denklem sızıntısız hat için kuruldu.",
                    "Dar bölümde hız yine iki katına çıkar, sızıntı hızı artırır":
                        "Sızıntı su kaybettirir; dar bölümden daha az su geçer.",
                },
                rastgele=rastgele,
                aciklama="Model yalnız koşulları sağlanınca geçerlidir; sızıntı debiyi korumaz.",
                ipuclari=["Akış notundaki koşulları oku."],
                puan=10,
            ),
        ],
        kapanis=("Plan düzeltildi: dar bölümde su {} m/s ile akıyor (geniş bölümün {} katı), "
                 "debi {} L/s. Sayaç sızıntı onarıldıktan sonra takılacak."
                 ).format(sy(v2), kat, sy(debi)),
        odul={"itibar": 4, "erzak": 2, "enerji": 1},
    )


# ==========================================================================
# LİMİT HIZ: KUVVETLER YOK OLMAZ, DENGELENİR (B37.13)
#
# `limit_hiz` tek satırlıktı (2026: 11). Bağlam: "Hava direnci olan kapsül
# modelinde kuvvet dengesini yorumlama". `yaygin_yanlis`:
#
#   "Limit hızda kuvvetlerin yok olduğunu sanmak."
#
# DÜZENEK: atmosferde düşen ölçüm kapsülü; hava direnci F = k·v². Kapsül
# hızlandıkça direnç artar; ağırlığa eşit olunca net kuvvet sıfır, hız sabit:
# limit hız. Ağırlık da direnç de hâlâ etkir.
#
# YANILGININ SAYISAL KARŞILIĞI: limit hızdaki hava direncini 0 yazmak; yarı
# hızda net kuvveti ağırlığa eşit saymak (direnci unutmak).
# ==========================================================================

_G = 10
# (kütle kg, k N·s²/m²): m·g/k tam kare
_KAPSULLER = ((5, 0.5), (20, 0.5), (4, 0.1), (9, 0.1), (10, 1.0))


@bulmaca(ders="fizik", konu="limit_hiz", kademeler=(11, 13), agirlik=1.3)
def olcum_kapsulu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Limit hızda ağırlık ile direnç eşittir; kuvvetler yok olmaz, net kuvvet sıfırdır."""
    m, k = rastgele.choice(_KAPSULLER)
    agirlik = m * _G
    v_lim = round((agirlik / k) ** 0.5, 2)
    yari = v_lim / 2
    net_yari = round(agirlik - k * yari * yari, 2)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-olcum-kapsulu",
        ders="fizik",
        baslik="Ölçüm Kapsülü",
        kademe=kademe,
        konu="limit_hiz",
        kazanim="Hava direncinin hızla arttığını ve limit hızda ağırlığa eşit olduğunu "
                "açıklama; limit hızı ve ara hızdaki net kuvveti hesaplama; limit hızda "
                "kuvvetlerin yok olmadığını, dengelendiğini gösterme.",
        dikkat=8,
        brifing=(
            "Atmosfer ölçüm kapsülü yüksekten bırakılacak; bağlantı halatının "
            "dayanımı seçilecek.\n\n"
            "{} rapora şunu yazdı: \"Kapsül limit hıza ulaşınca üstüne hiçbir kuvvet "
            "etkimez; o yüzden sabit hızla gider. Limit hızda hava direnci sıfır, "
            "bağlantıya da yük binmez.\"\n\n"
            "Halat seçilmeden önce kuvvetleri doğru modellememiz gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Kapsül kaydı",
                  "Kapsülün kütlesi {} kg (g = 10 m/s²). Hava direnci F = k·v², k = {} N·s²/m²."
                  .format(m, sy(k)),
                  bedel=1, kritik=True),
            Kanit("Hız kaydı",
                  "Bırakıldıktan sonra hız önce hızla, sonra giderek yavaş arttı; bir süre "
                  "sonra sabitlendi.",
                  bedel=1),
            Kanit("Kuvvet notu",
                  "Net kuvvet = ağırlık − hava direnci. Net kuvvet sıfırsa ivme sıfırdır ve "
                  "hız sabit kalır (Newton'un birinci yasası).",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Limit hızdaki kapsül için hangisi doğrudur?",
                dogru="Ağırlık ve direnç hâlâ etkir; eşit oldukları için net kuvvet sıfırdır",
                yanlislar={
                    "Limit hızda kapsüle hiçbir kuvvet etkimez, kuvvetler hız sabitlenince kaybolur":
                        "Limit hızda kuvvetlerin yok olduğunu sandın. Ağırlık hiç "
                        "kaybolmaz; hava direnci de o hızda ağırlığa eşit büyüklüktedir.",
                    "Limit hızda hava direnci ağırlıktan büyüktür, kapsül yavaşlar":
                        "Direnç büyük olsaydı kapsül yavaşlardı; hız kaydı sabit diyor.",
                    "Sabit hız için sürekli net kuvvet gerekir":
                        "Sabit hızda net kuvvet sıfırdır; kuvvet hız değişimine yol açar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kapsül hızlandıkça hava direnci artar, net kuvvet ve ivme azalır. "
                    "Direnç ağırlığa eşit olduğunda net kuvvet sıfırlanır: iki kuvvet "
                    "birbirini dengeler, hız sabit kalır."
                ),
                ipuclari=[
                    "Kapsülün ağırlığı limit hızda kaybolur mu?",
                    "Kuvvet notunda net kuvvet nasıl tanımlanmış?",
                ],
                cozum="Limit hızda: k·v² = m·g, net kuvvet 0\nv_lim = √(m·g ÷ k)",
            ),
            sayi_adimi(
                soru="Kapsül limit hızdayken hava direnci kaç N?",
                cevap=agirlik,
                birim="N",
                aciklama="Limit hızda direnç ağırlığa eşit: {} × 10 = {} N.".format(m, agirlik),
                yaygin_yanlislar={
                    0:
                        "Limit hızda kuvvetlerin yok olduğunu sandın; direnç ağırlığı "
                        "dengeliyor, sıfır değil.",
                },
                ipuclari=["Net kuvvet sıfırsa direnç neye eşit olmalı?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Limit hız kaç m/s?",
                cevap=v_lim,
                birim="m/s",
                aciklama="k·v² = m·g: v = √({} ÷ {}) = {} m/s.".format(agirlik, sy(k), sy(v_lim)),
                ipuclari=["Direnci ağırlığa eşitle, v için çöz."],
                puan=12,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Kapsül limit hızın yarısıyla düşerken net kuvvet kaç N?",
                cevap=net_yari,
                birim="N",
                aciklama="Direnç = {} × {}² = {} N. Net = {} − {} = {} N (aşağı).".format(
                    sy(k), sy(yari), sy(round(k * yari * yari, 2)), agirlik,
                    sy(round(k * yari * yari, 2)), sy(net_yari)),
                yaygin_yanlislar={
                    agirlik:
                        "Hava direncini unuttun; o hızda da direnç var.",
                    0:
                        "Net kuvvet yalnız limit hızda sıfırdır; yarı hızda kapsül hâlâ hızlanıyor.",
                },
                ipuclari=["Önce o hızdaki direnci hesapla; ağırlıktan çıkar."],
                puan=10,
                tolerans=0.01,
            ),
            yorum_adimi(
                soru="Bağlantı halatı için hangi karar doğru?",
                dogru="Halat en az {} N taşıyabilmeli: kuvvetler dengede ama etkiyor".format(agirlik),
                yanlislar={
                    "Limit hızda kuvvet olmadığından halata yük binmez":
                        "Limit hızda kuvvetlerin yok olduğunu sandın.",
                    ("Halat yalnız bırakılma anında yük taşır, sonra gerekmez; kapsül kendi "
                     "hızıyla iner"):
                        "Hava direnci ve ağırlık bütün iniş boyunca etkiyor.",
                },
                rastgele=rastgele,
                aciklama="Kuvvetler dengelenir ama yok olmaz; yük sürekli taşınır.",
                ipuclari=["Limit hızda hangi kuvvetler etkiyor?"],
                puan=8,
            ),
        ],
        kapanis=("Rapor düzeltildi: limit hız {} m/s; bu hızda hava direnci {} N ve ağırlığa "
                 "eşit. Kuvvetler dengede, yok değil."
                 ).format(sy(v_lim), agirlik),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# KÜTLE ÇEKİM VE YÖRÜNGE: YÖRÜNGEDE ÇEKİM VARDIR (B37.13)
#
# `kutlecekim_yorunge` tek satırlıktı (2018: 12). Bağlam: "Sefer uydusunun
# ideal yörünge modelini inceleme". `yaygin_yanlis`:
#
#   "Yörüngede çekim kuvveti yok sanmak."
#
# DÜZENEK: sefer uydusu h yüksekliğinde dairesel yörüngede. Çekim ivmesi
# g = g0·(R ÷ (R + h))²: azalır ama sıfır olmaz. Uydu sürekli düşer (serbest
# düşme) ve yatay hızı sayesinde Dünya'yı ıskalar: v = √(g·r). İçindekiler
# ağırlıksız görünür çünkü uyduyla birlikte düşerler.
#
# YANILGILARIN SAYISAL KARŞILIĞI: yörüngedeki çekim ivmesini ve kuvvetini 0
# yazmak.
# ==========================================================================

_DUNYA_R = 6400          # km
_G0 = 10                 # m/s²


@bulmaca(ders="fizik", konu="kutlecekim_yorunge", kademeler=(12, 13), agirlik=1.3)
def sefer_uydusu(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yörüngede çekim vardır; uydu serbest düşer ve yatay hızıyla Dünya'yı ıskalar."""
    h = rastgele.choice((400, 1600, 6400))          # km
    m = rastgele.choice((200, 500, 1000))           # kg
    r = _DUNYA_R + h
    g = round(_G0 * (_DUNYA_R / r) ** 2, 2)
    kuvvet = round(m * g)
    v = round((g * r * 1000) ** 0.5 / 1000, 2)      # km/s
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-sefer-uydusu",
        ders="fizik",
        baslik="Sefer Uydusu",
        kademe=kademe,
        konu="kutlecekim_yorunge",
        kazanim="Yörünge yüksekliğinde çekim ivmesini ve kuvvetini hesaplama; yörüngedeki "
                "cismin serbest düştüğünü, ağırlıksızlık hissinin çekimin yokluğundan "
                "değil serbest düşmeden geldiğini açıklama; dairesel yörünge hızını bulma.",
        dikkat=8,
        brifing=(
            "Seferin iletişim uydusu {} km yükseklikteki dairesel yörüngeye "
            "yerleştirilecek.\n\n"
            "{} görev notuna şunu yazdı: \"Yörüngede yer çekimi yoktur; astronotların "
            "havada süzülmesi bunun kanıtı. Uydu çekimsiz ortamda süzülür, motoru "
            "kapatınca olduğu yerde durur.\"\n\n"
            "Uydu fırlatılmadan önce yörüngeyi doğru modellememiz gerekiyor."
        ).format(h, kisi),
        kanitlar=[
            Kanit("Yörünge kaydı",
                  "Dünya yarıçapı {} km. Yüzeyde g = {} m/s². Uydu yüksekliği {} km, "
                  "uydunun kütlesi {} kg.".format(_DUNYA_R, _G0, h, m),
                  bedel=1, kritik=True),
            Kanit("Çekim notu",
                  "Çekim ivmesi merkeze uzaklığın karesiyle ters orantılı: g = g0 × "
                  "(R ÷ r)², r = R + h. Dairesel yörüngede çekim merkezcil kuvveti "
                  "sağlar: v = √(g × r).",
                  bedel=1, kritik=True),
            Kanit("Astronot notu",
                  "Uzay istasyonundaki astronot ve istasyon aynı ivmeyle birlikte düşüyor; "
                  "bu yüzden astronot tabana baskı yapmıyor.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yörüngedeki uydu için hangisi doğrudur?",
                dogru=("Çekim yörüngede de etkir; uydu hep düşer ama yatay hızıyla "
                       "Dünya'yı ıskalar"),
                yanlislar={
                    ("Yörüngede çekim kuvveti yoktur; uydu çekimsiz süzülür, çünkü Dünya'dan "
                     "çok uzaktadır"):
                        "Yörüngede çekim kuvveti yok sandın. Çekim olmasaydı uydu dönmez, "
                        "düz bir çizgide uzaklaşırdı.",
                    "Astronotların süzülmesi çekimin sıfır olduğunu gösterir":
                        "Astronot ve istasyon birlikte düşüyor; süzülme serbest düşmeden.",
                    ("Uydu yörüngede kalmak için sürekli motor çalıştırmalı, motor durursa "
                     "uydu düşer"):
                        "İdeal yörüngede hava direnci yok; çekim tek başına dolanımı sürdürür.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Çekim uzaklığın karesiyle azalır ama birkaç bin kilometre yukarıda "
                    "hâlâ büyüktür. Bu çekim uyduyu merkeze doğru çeker ve yolunu büker: "
                    "dairesel yörünge sürekli bir serbest düşmedir."
                ),
                ipuclari=[
                    "Çekim notuna göre g ne zaman sıfır olur?",
                    "Astronot notunda süzülmenin nedeni ne?",
                ],
                cozum="g = g0 (R ÷ r)²\nF = m·g\nv = √(g·r)",
            ),
            sayi_adimi(
                soru="Uydunun yüksekliğinde çekim ivmesi kaç m/s²?",
                cevap=g,
                birim="m/s²",
                aciklama="r = {} + {} = {} km. g = 10 × ({} ÷ {})² = {} m/s².".format(
                    _DUNYA_R, h, r, _DUNYA_R, r, sy(g)),
                yaygin_yanlislar={
                    0:
                        "Yörüngede çekim kuvveti yok sandın; çekim azalır ama sıfır olmaz.",
                    _G0:
                        "Yüzeydeki değeri yazdın; uzaklık arttıkça çekim azalır.",
                },
                ipuclari=["r = R + h; oranın karesini al."],
                puan=12,
                tolerans=0.02,
            ),
            sayi_adimi(
                soru="Yörüngede uyduya etkiyen çekim kuvveti kaç N?",
                cevap=kuvvet,
                birim="N",
                aciklama="F = {} × {} ≈ {} N.".format(m, sy(g), kuvvet),
                yaygin_yanlislar={
                    0:
                        "Yörüngede çekim kuvveti yok sandın.",
                },
                ipuclari=["Kütleyi o yükseklikteki g ile çarp."],
                puan=10,
                tolerans=5,
            ),
            sayi_adimi(
                soru="Uydunun dairesel yörünge hızı kaç km/s?",
                cevap=v,
                birim="km/s",
                aciklama="v = √({} × {} × 10³) ≈ {} m/s = {} km/s.".format(
                    sy(g), r, round(v * 1000), sy(v)),
                ipuclari=["r'yi metreye çevir; v = √(g·r)."],
                puan=12,
                tolerans=0.05,
            ),
            secim_adimi(
                soru="İdeal yörüngede motor kapatılırsa uydu ne yapar?",
                dogru="Dolanmayı sürdürür: çekim yolunu büker",
                yanlislar={
                    "Olduğu yerde durur; çekimsiz ortamda süzülür":
                        "Yörüngede çekim kuvveti yok sandın; uydunun hızı ve çekim sürüyor.",
                    "Düz bir çizgide uzaya fırlar":
                        "Bu ancak çekim ortadan kalkarsa olurdu.",
                    "Hemen Dünya'ya düşer; onu yukarıda tutan motordu":
                        "Uydu zaten düşüyor ama yatay hızıyla Dünya'yı ıskalıyor; hava "
                        "direnci olmayan ideal yörüngede dolanım sürer.",
                },
                rastgele=rastgele,
                aciklama="Motor yalnız yörüngeye oturtmak için gerekir; ideal yörüngede çekim dolanımı sürdürür.",
                ipuclari=["Yörüngeyi sürdüren kuvvet hangisi?"],
                puan=8,
            ),
        ],
        kapanis=("Not düzeltildi: {} km yükseklikte g = {} m/s², uyduya {} N çekim etkiyor. "
                 "Uydu {} km/s hızla sürekli düşerek dolanıyor."
                 ).format(h, sy(g), kuvvet, sy(v)),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# ÖZEL GÖRELİLİK: ETKİ IŞIK HIZINA YAKLAŞINCA BÜYÜR (B37.13)
#
# `ozel_gorelilik` tek satırlıktı (2018: 12). Bağlam: "İdeal uzay yolculuğu
# modelindeki gözlemci ölçülerini karşılaştırma". `yaygin_yanlis`:
#
#   "Günlük hızlar için ölçülebilir büyük görelilik etkisi beklemek."
#
# DÜZENEK: ideal uzay gemisi v = 0,6c ya da 0,8c ile gidiyor: γ = 1 ÷ √(1 −
# v²/c²) = 1,25 ya da 5/3. Gemideki süreç Dünya'dan γ kat uzun, gemi boyu 1/γ
# kat kısa ölçülür. Aynı formül 30 m/s hızla giden araç için γ − 1 ≈ 5 × 10⁻¹⁵
# verir: bir saatte ~10⁻¹¹ s.
#
# YANILGILARIN SAYISAL KARŞILIĞI: gemide süreyi değişmez saymak; boyu
# uzatmak; araçta ölçülebilir fark beklemek (seçimde).
# ==========================================================================

# (v/c, γ)
_GORELI_HIZLAR = ((0.6, 1.25), (0.8, 5.0 / 3))


@bulmaca(ders="fizik", konu="ozel_gorelilik", kademeler=(12, 13), agirlik=1.2)
def isik_gemisi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Görelilik etkileri ışık hızına yakın hızlarda büyür; günlük hızlarda ölçülemeyecek kadar küçüktür."""
    oran, gama = rastgele.choice(_GORELI_HIZLAR)
    sure_gemi = rastgele.choice((3, 6, 12))          # saat, gemideki saatle
    sure_dunya = round(sure_gemi * gama, 2)
    boy = rastgele.choice((60, 90, 120))              # m, gemi durağanken
    boy_olcum = round(boy / gama, 1)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-isik-gemisi",
        ders="fizik",
        baslik="Işık Gemisi",
        kademe=kademe,
        konu="ozel_gorelilik",
        kazanim="Lorentz çarpanını hesaplayıp zaman genişlemesi ve boy kısalmasını "
                "bulma; görelilik etkilerinin yalnız ışık hızına yakın hızlarda "
                "büyüdüğünü, günlük hızlarda ölçülemeyecek kadar küçük kaldığını açıklama.",
        dikkat=8,
        brifing=(
            "Bilim arşivindeki ideal uzay yolculuğu modeli sınıfta anlatılacak.\n\n"
            "{} anlatım notuna şunu eklemiş: \"Görelilik her hızda büyük fark yaratır: "
            "otoyolda giden bir aracın saati de dakikalarca geri kalır. Işık gemisinde "
            "ise süre ve boy hiç değişmez, çünkü gemidekiler bir şey fark etmez.\"\n\n"
            "Not okunmadan önce ölçüleri doğru karşılaştırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Gemi kaydı",
                  "Gemi Dünya'ya göre {} c hızla gidiyor. Gemideki saatle {} saat süren bir "
                  "deney yapılıyor. Gemi durağanken {} m uzunluğunda.".format(
                      sy(oran), sure_gemi, boy),
                  bedel=1, kritik=True),
            Kanit("Görelilik notu",
                  "γ = 1 ÷ √(1 − v²/c²). Hareketli saatteki süre, duran gözlemciye göre γ kat "
                  "uzun ölçülür; hareketli cismin boyu hareket doğrultusunda γ kat kısa "
                  "ölçülür. Gemideki gözlemci kendi saatini ve boyunu normal ölçer.",
                  bedel=1, kritik=True),
            Kanit("Araç kaydı",
                  "Otoyoldaki araç 30 m/s hızla gidiyor (ışık hızı 3 × 10⁸ m/s). Bu hızda "
                  "γ − 1 ≈ 5 × 10⁻¹⁵.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Özel görelilik etkileri için hangisi doğrudur?",
                dogru=("Işık hızına yaklaştıkça büyür; günlük hızlarda ölçülemeyecek "
                       "kadar küçüktür"),
                yanlislar={
                    "Her hızda büyük ve kolay ölçülür; araç saatleri dakikalarca geri kalır":
                        "Günlük hızlar için ölçülebilir büyük görelilik etkisi bekledin. "
                        "30 m/s hızda γ − 1 yalnız 5 × 10⁻¹⁵.",
                    "Hiçbir hızda etki yoktur; gözlemciler hep aynı ölçer, zaman her yerde aynı akar":
                        "Işık hızına yakın gemide Dünya'daki gözlemci süreyi γ kat uzun ölçer.",
                    "Etkiyi gemidekiler de kendi saatlerinde görür, saatleri yavaş işler":
                        "Gemideki gözlemci kendi saatini normal ölçer; fark gözlemciler arasındadır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "γ, v/c oranına bağlıdır. v, c'nin yanında küçükse γ neredeyse tam 1'dir; "
                    "etki ancak çok hassas atom saatleriyle görülür. v = 0,6c gibi hızlarda "
                    "etki büyür."
                ),
                ipuclari=[
                    "Araç kaydında γ − 1 ne kadar?",
                    "Görelilik notunda hangi gözlemci farkı ölçer?",
                ],
                cozum="γ = 1 ÷ √(1 − v²/c²)\nΔt = γ·Δt0\nL = L0 ÷ γ",
            ),
            sayi_adimi(
                soru="Gemi için Lorentz çarpanı γ kaçtır?",
                cevap=round(gama, 3),
                aciklama="√(1 − {}²) = {}; γ = 1 ÷ {} = {}.".format(
                    sy(oran), sy(round((1 - oran ** 2) ** 0.5, 2)),
                    sy(round((1 - oran ** 2) ** 0.5, 2)), sy(round(gama, 3))),
                yaygin_yanlislar={
                    1:
                        "Görelilik etkisi yok saydın; bu hızda γ belirgin biçimde 1'den büyük.",
                },
                ipuclari=["v/c oranının karesini 1'den çıkar, karekök al, 1'i ona böl."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Gemideki {} saatlik deney Dünya'dan ölçülünce kaç saat sürer?".format(sure_gemi),
                cevap=sure_dunya,
                birim="saat",
                aciklama="Δt = γ × Δt0 = {} × {} = {} saat.".format(sy(round(gama, 3)), sure_gemi, sy(sure_dunya)),
                yaygin_yanlislar={
                    sure_gemi:
                        "Sürenin değişmediğini sandın; hareketli saat Dünya'dan γ kat yavaş görünür.",
                    sy(round(sure_gemi / gama, 2)).replace(",", "."):
                        "Oranı ters kurdun; Dünya'dan ölçülen süre daha uzun.",
                },
                ipuclari=["Gemideki süreyi γ ile çarp."],
                puan=12,
                tolerans=0.02,
            ),
            sayi_adimi(
                soru="Dünya'daki gözlemci geminin boyunu kaç m ölçer?",
                cevap=boy_olcum,
                birim="m",
                aciklama="L = L0 ÷ γ = {} ÷ {} = {} m.".format(boy, sy(round(gama, 3)), sy(boy_olcum)),
                yaygin_yanlislar={
                    boy:
                        "Boyun değişmediğini sandın; hareket doğrultusunda γ kat kısa ölçülür.",
                    sy(round(boy * gama, 1)).replace(",", "."):
                        "Boyu uzattın; hareketli cisim kısa ölçülür.",
                },
                ipuclari=["Durağan boyu γ'ya böl."],
                puan=10,
                tolerans=0.1,
            ),
            secim_adimi(
                soru="Otoyolda 1 saat giden aracın saati, yoldaki saate göre ne kadar geri kalır?",
                dogru="Yaklaşık 10⁻¹¹ saniye: günlük saatle ölçülemez",
                yanlislar={
                    "Birkaç dakika: araç hızlı gittiği için zaman belirgin yavaşlar":
                        "Günlük hızlar için ölçülebilir büyük görelilik etkisi bekledin; "
                        "(γ − 1) × 3600 s ≈ 2 × 10⁻¹¹ s.",
                    "Tam 1 saniye":
                        "Bu, γ − 1 ≈ 3 × 10⁻⁴ olmasını gerektirirdi; araçta 5 × 10⁻¹⁵.",
                },
                rastgele=rastgele,
                aciklama="Fark (γ − 1) × 3600 s ≈ 5 × 10⁻¹⁵ × 3600 ≈ 2 × 10⁻¹¹ s.",
                ipuclari=["Araç kaydındaki γ − 1 değerini 3600 s ile çarp."],
                puan=10,
            ),
        ],
        kapanis=("Not düzeltildi: {} c hızda γ = {}; gemideki {} saat Dünya'dan {} saat, "
                 "gemi {} m ölçülür. Otoyoldaki araçta fark ölçülemeyecek kadar küçük."
                 ).format(sy(oran), sy(round(gama, 3)), sure_gemi, sy(sure_dunya), sy(boy_olcum)),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# DAYANIKLILIK: BOYUT k KAT OLUNCA ALAN k², HACİM k³ (B37.13)
#
# `dayaniklilik` tek satırlıktı (2018: 9). Bağlam: "Atölye destek parçalarının
# ölçek değişimini değerlendirme". `yaygin_yanlis`:
#
#   "Boyut iki kat olunca bütün niceliklerin iki kat olacağını sanmak."
#
# DÜZENEK: küçük model destek ayağı aynı malzemeden k kat büyük yapılacak.
# Taşıma gücü kesit alanıyla (k²), ağırlık hacimle (k³) artar: dayanıklılığın
# kendi ağırlığına oranı k kat AZALIR. Bu yüzden büyük yapılar orantısız
# kalın ayak ister.
#
# YANILGILARIN SAYISAL KARŞILIĞI: alanı, hacmi ve dayanıklılığı da k kat
# saymak; dayanıklılık/ağırlık oranını değişmez saymak.
# ==========================================================================


@bulmaca(ders="fizik", konu="dayaniklilik", kademeler=(9, 13), agirlik=1.3)
def destek_ayagi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Ölçek büyüdükçe alan k², hacim k³ artar; dayanıklılığın ağırlığa oranı 1/k olur."""
    k = rastgele.choice((2, 3, 4))
    model_kutle = rastgele.choice((2, 3, 5))        # kg
    model_yuk = rastgele.choice((600, 800, 1200))   # N, taşıyabileceği en büyük yük
    buyuk_kutle = model_kutle * k ** 3
    buyuk_yuk = model_yuk * k * k
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-destek-ayagi",
        ders="fizik",
        baslik="Destek Ayağı",
        kademe=kademe,
        konu="dayaniklilik",
        kazanim="Boyutlar k kat büyüdüğünde yüzey ve kesit alanının k², hacim ve "
                "kütlenin k³ kat arttığını hesaplama; dayanıklılığın kütleye oranının "
                "küçüldüğünü açıklama.",
        dikkat=8,
        brifing=(
            "Atölyede denenen küçük model destek ayağı çok sağlam çıktı; aynı "
            "malzemeden, her boyutu {} kat büyük gerçek ayak yapılacak.\n\n"
            "{} hesabı kısa tuttu: \"Her boyut {} kat olunca her şey {} kat olur: "
            "ağırlık da, taşıyabileceği yük de. Model ne kadar sağlamsa büyük ayak da "
            "o kadar sağlam olur.\"\n\n"
            "Üretime geçmeden önce ölçek hesabını doğru yapmamız gerekiyor."
        ).format(k, kisi, k, k),
        kanitlar=[
            Kanit("Model kaydı",
                  "Model ayak {} kg; kırılmadan en çok {} N yük taşıdı. Gerçek ayağın her "
                  "boyutu (en, boy, yükseklik) {} kat olacak.".format(model_kutle, model_yuk, k),
                  bedel=1, kritik=True),
            Kanit("Ölçek notu",
                  "Uzunluklar k kat olunca alanlar k², hacimler k³ kat olur. Bir ayağın "
                  "taşıyabileceği yük kesit alanıyla, kütlesi hacmiyle orantılıdır.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Bir cismin her boyutu k kat büyütülürse ne olur?",
                dogru="Alanlar k², hacim ve kütle k³ kat artar; hepsi aynı oranda artmaz",
                yanlislar={
                    "Alan, hacim ve dayanıklılık dahil her nicelik k kat artar":
                        "Boyut iki kat olunca bütün niceliklerin iki kat olacağını sandın. "
                        "Alan iki boyutlu, hacim üç boyutlu büyür.",
                    "Hacim k² kat, alan k kat artar, çünkü alan bir kenar, hacim iki kenarla büyür":
                        "Alan iki uzunluğun, hacim üç uzunluğun çarpımıdır.",
                    "Kütle değişmez; malzeme aynı olduğu için yoğunluk ve kütle korunur":
                        "Malzeme aynı ama miktarı hacimle artar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kenarı iki kat bir küpün yüzü 4, hacmi 8 kat olur. Taşıma gücü kesit "
                    "alanına bağlı olduğu için k² ile, ağırlık k³ ile büyür: büyük yapı "
                    "kendi ağırlığı karşısında daha zayıf kalır."
                ),
                ipuclari=[
                    "Kenarı 2 kat bir küpte kaç küçük küp vardır?",
                    "Ölçek notunda taşıma gücü neye bağlı?",
                ],
                cozum="Alan × k², hacim/kütle × k³\nDayanıklılık ÷ ağırlık × 1/k",
            ),
            sayi_adimi(
                soru="Gerçek ayağın kütlesi kaç kg olur?",
                cevap=buyuk_kutle,
                birim="kg",
                aciklama="Kütle hacimle artar: {} × {}³ = {} kg.".format(model_kutle, k, buyuk_kutle),
                yaygin_yanlislar={
                    model_kutle * k:
                        "Boyut {} kat olunca bütün niceliklerin {} kat olacağını sandın; "
                        "hacim {}³ = {} kat artar.".format(k, k, k, k ** 3),
                    model_kutle * k * k:
                        "Kütle alanla değil hacimle artar: k³.",
                },
                ipuclari=["Kütle hacimle orantılı; hacim kaç kat oldu?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Gerçek ayak kırılmadan en çok kaç N yük taşır?",
                cevap=buyuk_yuk,
                birim="N",
                aciklama="Taşıma gücü kesit alanıyla artar: {} × {}² = {} N.".format(model_yuk, k, buyuk_yuk),
                yaygin_yanlislar={
                    model_yuk * k:
                        "Bütün niceliklerin aynı oranda arttığını sandın; kesit alanı {}² kat.".format(k),
                    model_yuk * k ** 3:
                        "Taşıma gücü hacimle değil kesit alanıyla artar.",
                },
                ipuclari=["Kesit alanı kaç kat oldu?"],
                puan=12,
            ),
            sayi_adimi(
                soru="Taşıyabileceği yükün kendi kütlesine oranı modeldekinin kaç katı olur? (kesir ya da ondalık yazabilirsin)",
                cevap=round(1.0 / k, 4),
                aciklama="k² ÷ k³ = 1/{}: oran {} kat küçülür.".format(k, k),
                yaygin_yanlislar={
                    1:
                        "Bütün niceliklerin aynı oranda arttığını sandın; oran değişmez değil, küçülür.",
                    k:
                        "Oranı ters kurdun; ağırlık dayanıklılıktan hızlı artar.",
                },
                ipuclari=["Yük k² kat, kütle k³ kat: oranları nasıl değişir?"],
                puan=12,
                tolerans=0.01,
            ),
            yorum_adimi(
                soru="Gerçek ayak için hangi karar doğru?",
                dogru="Ayak orantılı büyütülmemeli, kesiti kalınlaşmalı; ağırlık dayanıklılıktan hızlı artar",
                yanlislar={
                    "Model sağlamsa aynı oranlarla büyütülen ayak da aynı ölçüde sağlamdır":
                        "Boyut iki kat olunca bütün niceliklerin iki kat olacağını sandın.",
                    ("Ayak daha ince yapılabilir; büyük olduğu için zaten güçlüdür, kalın "
                     "ayak boşa ağırlık ekler"):
                        "Büyüdükçe kendi ağırlığı karşısında daha zayıf kalır.",
                },
                rastgele=rastgele,
                aciklama="Dayanıklılık/ağırlık oranı 1/{} kat: büyük yapılar orantısız kalın destek ister.".format(k),
                ipuclari=["Bulduğun oranı düşün."],
                puan=8,
            ),
        ],
        kapanis=("Hesap düzeltildi: gerçek ayak {} kg ve en çok {} N taşır; dayanıklılığın "
                 "kütleye oranı 1/{} kat. Ayağın kesiti kalınlaştırıldı."
                 ).format(buyuk_kutle, buyuk_yuk, k),
        odul={"itibar": 4, "cevher": 2, "enerji": 1},
    )


# ==========================================================================
# ELEKTRİK POTANSİYELİ: POTANSİYEL ENERJİ DEĞİLDİR (B37.13)
#
# `elektrik_potansiyel` tek satırlıktı (2018: 11). Bağlam: "Bir kondansatör
# modelinin yük ve gerilim ilişkisini inceleme". `yaygin_yanlis`:
#
#   "Potansiyel ile potansiyel enerjiyi karıştırmak."
#
# DÜZENEK: sensör güç kartındaki kondansatör: C ve V verilir. Q = C·V;
# depolanan enerji E = ½·C·V². Potansiyel farkı birim yük başına enerjidir
# (1 V = 1 J/C): levhalar arasında taşınan q yükünün potansiyel enerji değişimi
# U = q·V. Aynı gerilimde farklı yükün enerjisi farklıdır.
#
# YANILGILARIN SAYISAL KARŞILIĞI: enerjiyi volt değeri yazmak; q yükünün
# enerji değişimini V yazmak; gerilim iki katında enerjiyi iki kat saymak.
# ==========================================================================


@bulmaca(ders="fizik", konu="elektrik_potansiyel", kademeler=(11, 13), agirlik=1.3)
def guc_karti(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Potansiyel (V) birim yük başına enerjidir; potansiyel enerji yüke bağlıdır."""
    c = rastgele.choice((10, 20, 50))       # µF
    v = rastgele.choice((6, 12, 24))        # V
    q_kond = c * v                           # µC
    enerji_mj = round(0.5 * c * v * v / 1000.0, 3)   # mJ
    q = rastgele.choice((2, 5))              # µC
    u = q * v                                 # µJ
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-guc-karti",
        ders="fizik",
        baslik="Güç Kartı",
        kademe=kademe,
        konu="elektrik_potansiyel",
        kazanim="Kondansatörde yük, gerilim ve depolanan enerjiyi hesaplama; elektrik "
                "potansiyelinin birim yük başına enerji olduğunu, potansiyel enerjinin "
                "yüke bağlı olduğunu ayırt etme.",
        dikkat=8,
        brifing=(
            "Sensörün güç kartındaki kondansatör kontrol edilecek; enerji etiketi "
            "yazılacak.\n\n"
            "{} etikete şunu yazdı: \"Kondansatör {} V gösteriyor; yani {} J enerji "
            "depoluyor. Levhalar arasında hangi yük taşınırsa taşınsın enerjisi {} "
            "birim değişir. Gerilimi iki katına çıkarırsak enerji de iki kat olur.\"\n\n"
            "Etiket basılmadan önce potansiyel ile enerjiyi doğru ayırmamız gerekiyor."
        ).format(kisi, v, v, v),
        kanitlar=[
            Kanit("Kondansatör kaydı",
                  "Sığa {} µF, levhalar arası gerilim {} V.".format(c, v),
                  bedel=1, kritik=True),
            Kanit("Potansiyel notu",
                  "Potansiyel farkı, birim yük başına enerjidir: 1 V = 1 J/C. Yükü q olan "
                  "tanecik levhalar arasında taşınınca potansiyel enerjisi U = q·V değişir. "
                  "Kondansatörde Q = C·V ve depolanan enerji E = ½·C·V².",
                  bedel=1, kritik=True),
            Kanit("Deneme kaydı",
                  "Levhalar arasında {} µC yüklü bir test damlacığı taşınacak.".format(q),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Potansiyel ve potansiyel enerji için hangisi doğrudur?",
                dogru=("Potansiyel yük başına enerjidir (J/C); potansiyel enerji yüke de "
                       "bağlıdır"),
                yanlislar={
                    "Potansiyel ile potansiyel enerji aynı şeydir; 12 V, 12 J demektir":
                        "Potansiyel ile potansiyel enerjiyi karıştırdın. Volt, her bir "
                        "coulomb başına jul demektir; toplam enerji yüke bağlı.",
                    ("Potansiyel enerji yükten bağımsızdır; yalnız gerilime bağlıdır, yük "
                     "yalnız taşıyıcıdır"):
                        "U = q·V: aynı gerilimde iki kat yük iki kat enerji değişimi demek.",
                    "Kondansatörün enerjisi gerilimle doğru orantılıdır, tıpkı depoladığı yük gibi":
                        "E = ½·C·V²: enerji gerilimin karesiyle artar.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Potansiyel, bir noktanın 'yük başına' enerji durumudur; potansiyel "
                    "enerji ise belirli bir yükün enerjisidir. Aralarındaki köprü yüktür: "
                    "U = q·V."
                ),
                ipuclari=[
                    "Potansiyel notunda 1 V neye eşit?",
                    "Test damlacığının yükü enerjiyi etkiler mi?",
                ],
                cozum="Q = C·V\nE = ½·C·V²\nU = q·V",
            ),
            sayi_adimi(
                soru="Kondansatördeki yük kaç µC?",
                cevap=q_kond,
                birim="µC",
                aciklama="Q = C·V = {} µF × {} V = {} µC.".format(c, v, q_kond),
                ipuclari=["Sığayı gerilimle çarp."],
                puan=8,
            ),
            sayi_adimi(
                soru="Kondansatörde depolanan enerji kaç mJ?",
                cevap=enerji_mj,
                birim="mJ",
                aciklama="E = ½ × {} × 10⁻⁶ × {}² = {} mJ.".format(c, v, sy(enerji_mj)),
                yaygin_yanlislar={
                    v * 1000:
                        "Potansiyel ile potansiyel enerjiyi karıştırdın: {} V değerini "
                        "{} J sandın.".format(v, v),
                    sy(round(c * v * v / 1000.0, 3)).replace(",", "."):
                        "½ çarpanını unuttun.",
                },
                ipuclari=["E = ½·C·V²; mikrofaradı faradaya çevir, sonucu milijule çevir."],
                puan=12,
                tolerans=0.005,
            ),
            sayi_adimi(
                soru="{} µC yüklü damlacığın levhalar arasında potansiyel enerjisi kaç µJ değişir?".format(q),
                cevap=u,
                birim="µJ",
                aciklama="U = q·V = {} µC × {} V = {} µJ.".format(q, v, u),
                yaygin_yanlislar={
                    v:
                        "Potansiyel ile potansiyel enerjiyi karıştırdın; enerji değişimi "
                        "yükle çarpılarak bulunur.",
                },
                ipuclari=["Yükü potansiyel farkıyla çarp."],
                puan=12,
            ),
            secim_adimi(
                soru="Gerilim iki katına çıkarılırsa depolanan enerji ne olur?",
                dogru="Dört katına çıkar: enerji gerilimin karesiyle artar",
                yanlislar={
                    "İki katına çıkar: enerji gerilimle aynı oranda artar":
                        "Potansiyel ile potansiyel enerjiyi karıştırdın; E = ½CV².",
                    "Değişmez: sığa aynı kaldı":
                        "Sığa aynı ama yük de gerilim de iki kat oldu.",
                },
                rastgele=rastgele,
                aciklama="E = ½·C·V²: V iki kat olunca E dört kat.",
                ipuclari=["Formülde V kaçıncı kuvvette?"],
                puan=8,
            ),
        ],
        kapanis=("Etiket düzeltildi: {} V gerilimde kondansatör {} µC yük ve {} mJ enerji "
                 "depoluyor; {} µC yüklü damlacığın enerjisi {} µJ değişiyor."
                 ).format(v, q_kond, sy(enerji_mj), q, u),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# FARADAY KAFESİ: HER KAFES HER ETKİYİ ENGELLEMEZ (B37.13)
#
# `faraday_kafesi` tek satırlıktı (2026: 11). Bağlam: "Hassas sensörün koruma
# modelini açıklama". `yaygin_yanlis`:
#
#   "Her tür elektromanyetik etkiyi her kafesin tamamen engellediğini sanmak."
#
# DÜZENEK: hassas sensör bakır tel örgü kafese konacak. Kafes statik elektrik
# alanını ve dalga boyu delik boyutunun çok üstünde olan dalgaları durdurur;
# dalga boyu delikten küçük dalgalar geçer. Bakır kafes kalıcı mıknatısın
# (durgun) manyetik alanını da durdurmaz.
#
# YANILGININ SAYISAL KARŞILIĞI: kafesin engellediği sinyal sayısını bütün
# sinyaller saymak; çoklu seçimde kısa dalgaları da işaretlemek.
# ==========================================================================

_ISIK_HIZI_CM = 3e10    # cm/s
# (sinyal adı, frekans Hz)
_KAFES_SINYALLERI = (
    ("FM radyo (100 MHz)", 100e6),
    ("telsiz (900 MHz)", 900e6),
    ("radar (10 GHz)", 10e9),
    ("uydu bağlantısı (30 GHz)", 30e9),
)


@bulmaca(ders="fizik", konu="faraday_kafesi", kademeler=(11, 13), agirlik=1.3)
def sensor_kafesi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Faraday kafesi dalga boyu deliklerden çok büyük dalgaları ve durgun elektrik alanını durdurur."""
    delik = rastgele.choice((2, 3))                   # cm
    sinyaller = list(_KAFES_SINYALLERI)
    rastgele.shuffle(sinyaller)
    secenekler = [ad for ad, _ in sinyaller] + ["kalıcı mıknatısın manyetik alanı"]
    dalga = {ad: round(_ISIK_HIZI_CM / f, 1) for ad, f in sinyaller}
    engellenen = [n for n, (ad, _) in enumerate(sinyaller) if dalga[ad] >= 10 * delik]
    sorulan_ad, sorulan_f = rastgele.choice(_KAFES_SINYALLERI)
    sorulan_l = round(_ISIK_HIZI_CM / sorulan_f, 1)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-sensor-kafesi",
        ders="fizik",
        baslik="Sensör Kafesi",
        kademe=kademe,
        konu="faraday_kafesi",
        kazanim="Faraday kafesinin durgun elektrik alanını ve dalga boyu delik boyutundan "
                "çok büyük elektromanyetik dalgaları durdurduğunu açıklama; dalga boyunu "
                "hesaplayıp hangi sinyallerin geçeceğini belirleme; durgun manyetik "
                "alanın bakır kafesten geçtiğini gösterme.",
        dikkat=8,
        brifing=(
            "Hassas manyetik alan sensörü dış etkilerden korunmak için bakır tel örgü "
            "kafese konacak.\n\n"
            "{} kurulum notuna şunu yazdı: \"Faraday kafesi her türlü elektromanyetik "
            "etkiyi tamamen durdurur. Deliklerin boyutu önemli değil; içerideki sensöre "
            "ne radyo ne radar ne de mıknatıs ulaşır.\"\n\n"
            "Sensör yerleştirilmeden önce kafesin neyi durdurup neyi geçirdiğini "
            "bulmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Kafes kaydı",
                  "Bakır tel örgü; göz (delik) boyutu {} cm. Işık hızı 3 × 10¹⁰ cm/s."
                  .format(delik),
                  bedel=1, kritik=True),
            Kanit("Koruma notu",
                  "İletken kafes durgun elektrik alanını içeri sokmaz. Elektromanyetik "
                  "dalga, dalga boyu delik boyutunun en az 10 katıysa kafeste durur; "
                  "daha kısa dalgalar deliklerden sızar. Bakır mıknatısa çekilmez; "
                  "durgun manyetik alan bakır kafesten geçer.",
                  bedel=1, kritik=True),
            Kanit("Sinyal listesi", "\n".join(secenekler), bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bakır tel örgü kafes için hangisi doğrudur?",
                dogru=("Durgun elektrik alanı ve dalga boyu delikten çok uzun dalgaları keser; "
                       "gerisi geçer"),
                yanlislar={
                    ("Her tür elektromanyetik etkiyi tamamen durdurur, çünkü metal kafes "
                     "içeriyi dış dünyadan yalıtır"):
                        "Her tür elektromanyetik etkiyi her kafesin tamamen engellediğini "
                        "sandın. Dalga boyu deliklere göre kısa olan sinyaller içeri sızar.",
                    "Yalnız mıknatısın manyetik alanını durdurur; bakır, mıknatısın etkisini emer":
                        "Bakır mıknatısa çekilmez; durgun manyetik alanı durduramaz.",
                    "Deliklerin boyutu korumayı etkilemez; önemli olan kafesin metal olmasıdır":
                        "Koruma, dalga boyu ile delik boyutunun karşılaştırmasına bağlı.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Kafesteki serbest elektronlar dış elektrik alanına karşı dağılır ve "
                    "içeride alanı söndürür. Hızla değişen alanlarda bu ancak dalga boyu "
                    "deliklerden çok büyükse işler. Durgun manyetik alan bakırdaki yükleri "
                    "harekete geçirmediği için içeri girer."
                ),
                ipuclari=[
                    "Koruma notunda delik boyutu ile dalga boyu nasıl karşılaştırılıyor?",
                    "Bakır mıknatısa çekilir mi?",
                ],
                cozum="λ = c ÷ f\nλ ≥ 10 × delik: durur\nDurgun manyetik alan: geçer",
            ),
            sayi_adimi(
                soru="{} sinyalinin dalga boyu kaç cm?".format(sorulan_ad),
                cevap=sorulan_l,
                birim="cm",
                aciklama="λ = 3 × 10¹⁰ ÷ {} = {} cm.".format(
                    "{:.0e}".format(sorulan_f).replace("e+0", " × 10^").replace("e+", " × 10^"),
                    sy(sorulan_l)),
                ipuclari=["Işık hızını frekansa böl."],
                puan=10,
                tolerans=0.1,
            ),
            sayi_adimi(
                soru="Listedeki elektromanyetik sinyallerden kaç tanesini kafes durdurur?",
                cevap=len(engellenen),
                aciklama="Dalga boyu en az {} cm olanlar durur: {}.".format(
                    10 * delik, ", ".join(sinyaller[n][0] for n in engellenen)),
                yaygin_yanlislar={
                    len(sinyaller):
                        "Her tür elektromanyetik etkiyi her kafesin tamamen engellediğini "
                        "sandın; kısa dalgalar deliklerden sızar.",
                },
                ipuclari=["Her sinyalin dalga boyunu delik boyutunun 10 katıyla karşılaştır."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangileri kafesten içeri girer? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=[n for n in range(len(secenekler)) if n not in engellenen],
                aciklama="Dalga boyu delik boyutunun 10 katından kısa sinyaller ve durgun manyetik alan içeri girer.",
                ipuclari=["Mıknatısın alanını da unutma."],
                puan=12,
            ),
        ],
        kapanis=("Not düzeltildi: {} cm gözlü kafes uzun dalgalı sinyalleri durduruyor, "
                 "kısa dalgalıları ve mıknatısın alanını durduramıyor. Manyetik sensör "
                 "için ayrı koruma planlandı.").format(delik),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# ENERJİ KAYNAKLARI: YENİLENEBİLİR, ETKİSİZ DEMEK DEĞİL (B37.13)
#
# `enerji_kaynaklari` tek satırlıktı (2026: 10). Bağlam: "Üs enerji
# seçeneklerini aynı iş için karşılaştırma". `yaygin_yanlis`:
#
#   "Yenilenebilir kaynağı çevresel etkisi olmayan kaynak sanmak."
#
# DÜZENEK: üssün aylık 1000 kWh ihtiyacı için yenilenebilir bir seçenek ile
# kömürlü jeneratör. Yaşam döngüsü salımı (g CO₂/kWh, yuvarlak ortanca
# değerler): kömür 820, güneş 45, jeotermal 38, hidroelektrik 24, rüzgâr 11.
# Yenilenebilir kaynak çok daha az salar ama sıfır değil; ayrıca her birinin
# kendine özgü çevresel etkisi var.
#
# YANILGININ SAYISAL KARŞILIĞI: yenilenebilir seçeneğin salımını 0 yazmak.
# ==========================================================================

_KOMUR_SALIM = 820   # g CO₂/kWh
# (seçenek, g CO₂/kWh, özgül çevresel etki)
_YENILENEBILIR = (
    ("güneş paneli", 45, "Geniş arazi kaplar; ömrü biten paneller elektronik atık olur."),
    ("rüzgâr türbini", 11, "Kuşlar ve yarasalar için çarpma riski, gürültü ve görüntü etkisi var."),
    ("barajlı hidroelektrik", 24, "Baraj gölü yaşam alanlarını suya gömer; balık göçünü ve alüvyon taşınmasını keser."),
    ("jeotermal santral", 38, "Yeraltı suyuyla birlikte hidrojen sülfür ve karbon dioksit yüzeye çıkabilir."),
)


@bulmaca(ders="fizik", konu="enerji_kaynaklari", kademeler=(10, 13), agirlik=1.3)
def enerji_secenekleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Yenilenebilir kaynak tükenmez ama çevresel etkisi sıfır değildir; aynı iş için karşılaştırılır."""
    ad, salim, etki = rastgele.choice(_YENILENEBILIR)
    ihtiyac = rastgele.choice((500, 1000, 2000))      # kWh/ay
    yen_kg = round(ihtiyac * salim / 1000.0, 1)
    komur_kg = round(ihtiyac * _KOMUR_SALIM / 1000.0, 1)
    kat = round(_KOMUR_SALIM / float(salim), 1)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    ad_b = ad[:1].upper() + ad[1:]

    return Bulmaca(
        kod="fiz-enerji-secenekleri",
        ders="fizik",
        baslik="Enerji Seçenekleri",
        kademe=kademe,
        konu="enerji_kaynaklari",
        kazanim="Enerji kaynaklarını aynı iş (aynı enerji) için yaşam döngüsü salımıyla "
                "karşılaştırma; yenilenebilir kaynağın tükenmez olduğunu ama çevresel "
                "etkisinin sıfır olmadığını açıklama.",
        dikkat=7,
        brifing=(
            "Üs, ayda {} kWh elektriği kömürlü jeneratör yerine {} ile üretmeyi "
            "planlıyor.\n\n"
            "{} rapora şunu yazdı: \"{} yenilenebilir bir kaynak; yenilenebilir olanın "
            "çevreye hiçbir etkisi olmaz. Salımı sıfır, başka bir değerlendirmeye gerek "
            "yok.\"\n\n"
            "Karar verilmeden önce iki seçeneği aynı iş için karşılaştırmamız gerekiyor."
        ).format(ihtiyac, ad, kisi, ad_b),
        kanitlar=[
            Kanit("Salım tablosu",
                  "Yaşam döngüsü boyunca (yapım, işletme, söküm) üretilen her kWh için: "
                  "kömür {} g CO₂, {} {} g CO₂.".format(_KOMUR_SALIM, ad, salim),
                  bedel=1, kritik=True),
            Kanit("Etki notu", "{}: {}".format(ad_b, etki), bedel=1, kritik=True),
            Kanit("Kaynak notu",
                  "Yenilenebilir: kullanıldıkça tükenmeyen, doğada yenilenen kaynak. Bu, "
                  "çevresel etkisinin olmadığı anlamına gelmez.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Yenilenebilir enerji kaynakları için hangisi doğrudur?",
                dogru="Kaynak tükenmez ama yapım, işletme ve sökümde çevresel etkisi olur",
                yanlislar={
                    ("Yenilenebilir kaynağın hiçbir çevresel etkisi yoktur, çünkü doğadan "
                     "kendiliğinden gelir"):
                        "Yenilenebilir kaynağı çevresel etkisi olmayan kaynak sandın. "
                        "Salım tablosu ve etki notu tersini gösteriyor.",
                    "Yenilenebilir kaynaklar fosil kaynaklardan daha çok CO₂ salar":
                        "Tabloya göre kWh başına salımları çok daha düşük.",
                    "Karşılaştırma yalnız kurulum maliyetiyle yapılır, çevre etkisi hepsinde aynıdır":
                        "Aynı iş için çevresel etki de karşılaştırılır.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Güneş, rüzgâr ya da su tükenmez; ama panel, türbin ve baraj yapılırken "
                    "ve sökülürken salım olur, arazi ve yaşam alanları etkilenir. Doğru "
                    "karşılaştırma aynı miktar enerji için bütün yaşam döngüsüne bakar."
                ),
                ipuclari=[
                    "Salım tablosunda yenilenebilir seçenek sıfır mı?",
                    "Etki notunda ne yazıyor?",
                ],
                cozum="Salım = üretilen enerji × kWh başına salım",
            ),
            sayi_adimi(
                soru="{} ile ayda {} kWh üretmenin yaşam döngüsü salımı kaç kg CO₂?".format(ad_b, ihtiyac),
                cevap=yen_kg,
                birim="kg",
                aciklama="{} kWh × {} g = {} g = {} kg.".format(ihtiyac, salim, ihtiyac * salim, sy(yen_kg)),
                yaygin_yanlislar={
                    0:
                        "Yenilenebilir kaynağı çevresel etkisi olmayan kaynak sandın; "
                        "yaşam döngüsü salımı sıfır değil.",
                },
                ipuclari=["Enerjiyi kWh başına salımla çarp; grama dikkat."],
                puan=12,
                tolerans=0.1,
            ),
            sayi_adimi(
                soru="Aynı iş için kömürlü jeneratör kaç kg CO₂ salar?",
                cevap=komur_kg,
                birim="kg",
                aciklama="{} × {} g = {} kg.".format(ihtiyac, _KOMUR_SALIM, sy(komur_kg)),
                ipuclari=["Aynı enerjiyi kömürün kWh başına salımıyla çarp."],
                puan=8,
                tolerans=0.1,
            ),
            sayi_adimi(
                soru="Kömürün salımı {} seçeneğinin kaç katı? (bir ondalık basamak)".format(ad),
                cevap=kat,
                aciklama="{} ÷ {} ≈ {}.".format(_KOMUR_SALIM, salim, sy(kat)),
                ipuclari=["İki kWh başına salımı birbirine böl."],
                puan=8,
                tolerans=0.1,
            ),
            yorum_adimi(
                soru="Rapor için hangisi doğru?",
                dogru="{} çok daha az salım yapar ama yine de etkisi sıfır değil".format(ad_b),
                yanlislar={
                    "{} yenilenebilir olduğu için hiçbir çevresel etkisi yoktur".format(ad_b):
                        "Yenilenebilir kaynağı çevresel etkisi olmayan kaynak sandın.",
                    "Kömür daha iyidir; yenilenebilir kaynakların etkisi daha büyüktür":
                        "Aynı iş için kömürün salımı {} kat büyük.".format(sy(kat)),
                },
                rastgele=rastgele,
                aciklama="Aynı iş için {} kg ile {} kg; ayrıca {}".format(
                    sy(yen_kg), sy(komur_kg), etki[:1].lower() + etki[1:]),
                ipuclari=["İki salımı ve etki notunu birlikte düşün."],
                puan=10,
            ),
        ],
        kapanis=("Rapor düzeltildi: {} ayda {} kg, kömür {} kg CO₂ salıyor ({} kat). "
                 "Yenilenebilir seçenek seçildi, özgül etkisi için önlem planlandı."
                 ).format(ad, sy(yen_kg), sy(komur_kg), sy(kat)),
        odul={"itibar": 4, "enerji": 3, "cevher": 1},
    )


# ==========================================================================
# COMPTON VE DE BROGLIE: FOTON İLE ELEKTRON AYNI MODEL DEĞİL (B37.13)
#
# `compton_debroglie` tek satırlıktı (2018: 12). Bağlam: "Bilim arşivindeki
# iki deneyin kanıtlarını karşılaştırma". `yaygin_yanlis`:
#
#   "Foton ile maddesel parçacığın modellerini özdeş saymak."
#
# DÜZENEK: arşivde iki deney: Compton saçılması (X ışını fotonları elektrona
# çarpıp momentum aktarır -> ışığın parçacık yönü) ve elektron kırınımı
# (elektron demeti kristalde girişim deseni verir -> maddenin dalga yönü).
# İkisinde de p = h/λ; ama foton kütlesizdir, hep c hızıyla gider, E = hc/λ.
# Elektron kütlelidir; aynı λ için kinetik enerjisi p²/2m, çok daha küçüktür.
#
# YANILGININ SAYISAL KARŞILIĞI: aynı dalga boylu elektronun enerjisini
# fotonunki gibi hc/λ hesaplamak.
# ==========================================================================

_PLANCK = 6.63e-34
_ELEKTRON_KUTLE = 9.1e-31
_EV = 1.6e-19


@bulmaca(ders="fizik", konu="compton_debroglie", kademeler=(12, 13), agirlik=1.2)
def iki_deney(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Foton ve elektron dalga-parçacık ikiliği gösterir ama modelleri özdeş değildir."""
    lam_nm = rastgele.choice((0.1, 0.2))
    lam = lam_nm * 1e-9
    p = _PLANCK / lam
    p_24 = round(p / 1e-24, 3)                      # × 10⁻²⁴ kg·m/s
    foton_ev = round(1240 / lam_nm)                 # eV
    elektron_ev = round(p * p / (2 * _ELEKTRON_KUTLE) / _EV, 1)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-iki-deney",
        ders="fizik",
        baslik="İki Deney",
        kademe=kademe,
        konu="compton_debroglie",
        kazanim="Compton saçılmasını ışığın parçacık, elektron kırınımını maddenin dalga "
                "özelliğine kanıt olarak açıklama; aynı dalga boyundaki foton ve "
                "elektronun momentumlarının eşit, enerjilerinin farklı olduğunu hesaplama.",
        dikkat=8,
        brifing=(
            "Bilim arşivindeki iki deney kaydı aynı klasöre konacak.\n\n"
            "{} klasör notuna şunu yazdı: \"Foton ile elektron artık aynı şey: ikisi de "
            "hem dalga hem parçacık. Dalga boyları aynıysa enerjileri de aynıdır; "
            "elektron da fotonun formülüyle hesaplanır.\"\n\n"
            "Not arşive girmeden önce iki modeli doğru karşılaştırmamız gerekiyor."
        ).format(kisi),
        kanitlar=[
            Kanit("Compton kaydı",
                  "{} nm dalga boylu X ışını elektronlara çarptı; saçılan ışının dalga boyu "
                  "uzadı, elektronlar geri tepti: foton momentum aktardı.".format(sy(lam_nm)),
                  bedel=1, kritik=True),
            Kanit("Kırınım kaydı",
                  "Elektron demeti kristalden geçince ekranda girişim halkaları oluştu. "
                  "Elektronların de Broglie dalga boyu da {} nm.".format(sy(lam_nm)),
                  bedel=1, kritik=True),
            Kanit("Sabitler",
                  "h = 6,63 × 10⁻³⁴ J·s; elektronun kütlesi 9,1 × 10⁻³¹ kg; 1 eV = 1,6 × "
                  "10⁻¹⁹ J. Foton: kütlesiz, hızı c, E = hc/λ (E eV = 1240 ÷ λ nm). Her "
                  "ikisi için p = h/λ. Elektron: E_k = p² ÷ 2m.",
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Foton ve elektron için hangisi doğrudur?",
                dogru=("İkisinde de dalga-parçacık ikiliği (p = h/λ) var; foton kütlesiz, "
                       "elektron kütleli"),
                yanlislar={
                    "Foton ile elektron aynı modelle anlatılır; aynı dalga boyunda enerjileri de aynıdır":
                        "Foton ile maddesel parçacığın modellerini özdeş saydın. Aynı λ "
                        "için momentumları eşit, enerjileri çok farklı.",
                    "Elektron da ışık hızıyla gider, çünkü o da dalga gibi davranır":
                        "Kütleli parçacık ışık hızına ulaşamaz.",
                    "Fotonun kütlesi elektronunkine eşittir; ikisi de aynı momentumu taşıyabiliyor":
                        "Fotonun durgun kütlesi yoktur.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Compton deneyi ışığın momentum taşıyan parçacık gibi davrandığını, "
                    "elektron kırınımı maddenin dalga gibi davrandığını gösterir. Ortak "
                    "bağıntı p = h/λ'dır; enerji ise kütleye bağlı olarak farklı hesaplanır."
                ),
                ipuclari=[
                    "Sabitler kartında foton ve elektron enerjisi nasıl hesaplanıyor?",
                    "Hangi büyüklük ikisi için aynı formülle bulunuyor?",
                ],
                cozum="p = h/λ (ikisi için)\nFoton: E = hc/λ\nElektron: E_k = p²/2m",
            ),
            sayi_adimi(
                soru="{} nm dalga boylu fotonun momentumu kaç × 10⁻²⁴ kg·m/s?".format(sy(lam_nm)),
                cevap=p_24,
                aciklama="p = 6,63 × 10⁻³⁴ ÷ ({} × 10⁻⁹) = {} × 10⁻²⁴ kg·m/s.".format(sy(lam_nm), sy(p_24)),
                ipuclari=["p = h ÷ λ; nanometreyi metreye çevir."],
                puan=10,
                tolerans=0.01,
            ),
            sayi_adimi(
                soru="Bu fotonun enerjisi kaç eV?",
                cevap=foton_ev,
                birim="eV",
                aciklama="E = 1240 ÷ {} = {} eV.".format(sy(lam_nm), foton_ev),
                ipuclari=["E(eV) = 1240 ÷ λ(nm)."],
                puan=8,
                tolerans=1,
            ),
            sayi_adimi(
                soru="Aynı dalga boylu elektronun kinetik enerjisi kaç eV?",
                cevap=elektron_ev,
                birim="eV",
                aciklama=("Momentum aynı: {} × 10⁻²⁴. E_k = p² ÷ 2m = ({} × 10⁻²⁴)² ÷ (2 × "
                          "9,1 × 10⁻³¹) J ≈ {} eV.").format(sy(p_24), sy(p_24), sy(elektron_ev)),
                yaygin_yanlislar={
                    foton_ev:
                        "Foton ile maddesel parçacığın modellerini özdeş saydın: elektronun "
                        "enerjisini fotonun formülüyle hesapladın.",
                },
                ipuclari=["Momentumu fotondan al; elektron için p²/2m kullan, sonucu elektronvolta çevir."],
                puan=14,
                tolerans=1,
            ),
            secim_adimi(
                soru="Arşivdeki iki deney neyi kanıtlıyor?",
                dogru="Compton: ışığın parçacık yönünü; elektron kırınımı: maddenin dalga yönünü",
                yanlislar={
                    ("İkisi de foton ile elektronun aynı şey olduğunu; ikisi de hem dalga hem "
                     "parçacık gibi davranıyor"):
                        "Foton ile maddesel parçacığın modellerini özdeş saydın; ikilik ortak, "
                        "model ayrı.",
                    "Compton: ışığın dalga yönünü; kırınım: elektronun parçacık yönünü":
                        "Tersi: momentum aktarımı parçacık, girişim deseni dalga özelliği.",
                },
                rastgele=rastgele,
                aciklama="Momentum aktarımı parçacık davranışıdır; girişim halkaları dalga davranışıdır.",
                ipuclari=["Geri tepen elektron ile girişim halkası hangi davranışı gösterir?"],
                puan=10,
            ),
        ],
        kapanis=("Not düzeltildi: {} nm dalga boyunda foton ile elektronun momentumu aynı "
                 "({} × 10⁻²⁴), ama foton {} eV, elektron yalnız {} eV. İkilik ortak, model ayrı."
                 ).format(sy(lam_nm), sy(p_24), foton_ev, sy(elektron_ev)),
        odul={"itibar": 5, "enerji": 2, "cevher": 1},
    )


# ==========================================================================
# TEMEL ETKİLEŞİMLER: SÜRTÜNME TEMEL KUVVET DEĞİLDİR (B37.13)
#
# `temel_kuvvetler` tek satırlıktı (2026: 9). Bağlam: "Bilim arşivindeki
# olayları temel etkileşim türleriyle ilişkilendirme". `yaygin_yanlis`:
#
#   "Temel etkileşimlerle sürtünme gibi makroskobik kuvvetleri aynı sınıflamada
#    değerlendirmek."
#
# DÜZENEK: arşiv olay kartları. Dört temel etkileşim: kütle çekim,
# elektromanyetik, güçlü nükleer, zayıf nükleer. Sürtünme, ip gerilmesi, normal
# kuvvet, esneklik kuvveti ayrı temel etkileşimler değil; atomlar arasındaki
# elektromanyetik etkileşimin makroskobik görünümleridir.
#
# YANILGININ SAYISAL KARŞILIĞI: kartlardaki farklı temel etkileşim sayısına
# makroskobik kuvvetleri ayrı tür olarak eklemek.
# ==========================================================================

# (olay, temel etkileşim, makroskobik mi)
_OLAY_KARTLARI = (
    ("Ay'ın Dünya çevresinde dolanması", "kütle çekim", False),
    ("Yağmur damlasının yere düşmesi", "kütle çekim", False),
    ("Pusula iğnesinin kuzeyi göstermesi", "elektromanyetik", False),
    ("Atom çekirdeğindeki protonların bir arada durması", "güçlü nükleer", False),
    ("Radyoaktif bir çekirdeğin beta bozunması", "zayıf nükleer", False),
    ("Kızağın karda sürtünmeyle yavaşlaması", "elektromanyetik", True),
    ("Halatın yükü taşırken gerilmesi", "elektromanyetik", True),
    ("Masanın üstündeki kitabı yukarı itmesi (normal kuvvet)", "elektromanyetik", True),
)


@bulmaca(ders="fizik", konu="temel_kuvvetler", kademeler=(9, 13), agirlik=1.2)
def olay_arsivi(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Dört temel etkileşim vardır; sürtünme ve gerilme elektromanyetik kökenli makroskobik kuvvetlerdir."""
    temel = [k for k in _OLAY_KARTLARI if not k[2]]
    makro = [k for k in _OLAY_KARTLARI if k[2]]
    kartlar = rastgele.sample(temel, 3) + rastgele.sample(makro, 2)
    rastgele.shuffle(kartlar)
    secenekler = [k[0] for k in kartlar]
    em_indeksler = [n for n, k in enumerate(kartlar) if k[1] == "elektromanyetik"]
    farkli = len({k[1] for k in kartlar})
    # Yanılgı: her makroskobik kuvveti ayrı bir temel tür saymak.
    yanilgi = len({k[1] for k in kartlar if not k[2]}) + sum(1 for k in kartlar if k[2])
    surtunme = [k for k in kartlar if k[2]][0]
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="fiz-olay-arsivi",
        ders="fizik",
        baslik="Olay Arşivi",
        kademe=kademe,
        konu="temel_kuvvetler",
        kazanim="Doğadaki dört temel etkileşimi tanıma; sürtünme, gerilme ve normal "
                "kuvvet gibi makroskobik kuvvetlerin elektromanyetik etkileşimden "
                "kaynaklandığını açıklama; olayları temel etkileşimlerle eşleme.",
        dikkat=7,
        brifing=(
            "Bilim arşivindeki olay kartları temel etkileşim türüne göre "
            "dizilecek.\n\n"
            "{} sınıflamayı şöyle yaptı: \"Her kuvvet ayrı bir temel etkileşimdir: "
            "sürtünme kuvveti bir tür, ip gerilmesi bir tür, normal kuvvet bir tür. "
            "Kartlardaki olaylarda {} farklı temel etkileşim var.\"\n\n"
            "Arşiv dizilmeden önce sınıflamayı doğru yapmamız gerekiyor."
        ).format(kisi, yanilgi),
        kanitlar=[
            Kanit("Olay kartları", "\n".join(secenekler), bedel=1, kritik=True),
            Kanit("Etkileşim notu",
                  "Doğada dört temel etkileşim vardır: kütle çekim, elektromanyetik, güçlü "
                  "nükleer ve zayıf nükleer. Sürtünme, gerilme, normal kuvvet ve esneklik "
                  "kuvveti, yüzeylerdeki atomların elektronları arasındaki elektromanyetik "
                  "etkileşimin büyük ölçekteki görünümleridir.",
                  bedel=1, kritik=True),
        ],
        adimlar=[
            model_adimi(
                soru="Sürtünme gibi kuvvetler için hangisi doğrudur?",
                dogru=("Ayrı temel etkileşim değildir; atomlar arası elektromanyetik "
                       "etkileşimden doğar"),
                yanlislar={
                    "Sürtünme, gerilme ve normal kuvvet ayrı temel etkileşimlerdir":
                        "Temel etkileşimlerle makroskobik kuvvetleri aynı sınıflamada "
                        "değerlendirdin. Temel etkileşim yalnız dört tane.",
                    "Sürtünme kütle çekimin bir türüdür; ağır cisim daha çok sürtünür":
                        "Sürtünme yüzey atomları arasındaki elektriksel çekme ve itmeden doğar.",
                    ("Sürtünme güçlü nükleer etkileşimden kaynaklanır, atomlar birbirine "
                     "değince çekirdekler tutunur"):
                        "Güçlü etkileşim çekirdek içinde, çok kısa mesafede etkilidir.",
                },
                rastgele=rastgele,
                aciklama=(
                    "Günlük hayattaki itme, çekme, sürtünme ve gerilme kuvvetleri, "
                    "cisimlerin atomları birbirine yaklaşınca elektron bulutlarının "
                    "etkileşmesinden doğar. Bu yüzden hepsi elektromanyetik etkileşimin "
                    "sonuçlarıdır; temel etkileşim sayısı dörttür."
                ),
                ipuclari=[
                    "Etkileşim notunda kaç temel etkileşim sayılıyor?",
                    "Sürtünme hangi parçacıklar arasındaki etkileşimden doğar?",
                ],
                cozum="Temel: kütle çekim, elektromanyetik, güçlü, zayıf.\nSürtünme/gerilme/normal: elektromanyetik kökenli.",
            ),
            sayi_adimi(
                soru="Kartlardaki olaylarda kaç farklı TEMEL etkileşim rol oynar?",
                cevap=farkli,
                aciklama="Farklı temel etkileşimler: {}.".format(", ".join(sorted({k[1] for k in kartlar}))),
                yaygin_yanlislar={
                    yanilgi:
                        "Temel etkileşimlerle makroskobik kuvvetleri aynı sınıflamada "
                        "değerlendirdin; sürtünme ve gerilme ayrı tür değil.",
                },
                ipuclari=["Her kartı dört temel etkileşimden birine bağla, sonra farklı olanları say."],
                puan=12,
            ),
            coklu_adimi(
                soru="Hangi olaylar elektromanyetik etkileşimden kaynaklanır? (numaraları virgülle yaz)",
                secenekler=secenekler,
                dogru_indeksler=em_indeksler,
                aciklama="Sürtünme, gerilme ve normal kuvvet de elektromanyetik kökenlidir; pusula da.",
                ipuclari=["Makroskobik kuvvetleri de unutma."],
                puan=12,
            ),
            secim_adimi(
                soru="\"{}\" kartı hangi temel etkileşime bağlanır?".format(surtunme[0]),
                dogru="Elektromanyetik: atomlar arası elektriksel etkileşimden doğar",
                yanlislar={
                    "Kendine özgü ayrı bir temel etkileşim":
                        "Temel etkileşimlerle makroskobik kuvvetleri aynı sınıflamada "
                        "değerlendirdin.",
                    "Kütle çekim: cisimler ağır olduğu için, ağırlık da bir çekim kuvvetidir":
                        "Ağırlık yükü sağlayabilir ama bu kuvvetin kendisi atomlar arası "
                        "elektriksel etkileşimdir.",
                    "Zayıf nükleer: atom ölçeğinde olduğu için, atom içi kuvvetler nükleerdir":
                        "Zayıf etkileşim bozunmalarla ilgilidir, temas kuvvetleriyle değil.",
                },
                rastgele=rastgele,
                aciklama="Makroskobik temas kuvvetleri elektromanyetik etkileşimin sonucudur.",
                ipuclari=["Etkileşim notunun son cümlesini oku."],
                puan=10,
            ),
        ],
        kapanis=("Arşiv düzeltildi: kartlarda {} farklı temel etkileşim var; sürtünme ve "
                 "gerilme elektromanyetik rafına kondu.").format(farkli),
        odul={"itibar": 4, "cevher": 2, "enerji": 1},
    )
