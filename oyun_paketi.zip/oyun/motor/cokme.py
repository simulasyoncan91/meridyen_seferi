# -*- coding: utf-8 -*-
"""
Beklenmeyen hata olunca ne yapılır.

NEDEN VAR
---------
`oyun.basla()` yalnızca `OyunuBirak`'ı yakalıyordu. Başka her istisna oyunu
komple öldürüyordu: öğrenci ekranda bir yığın izi görüyor ve oturum
bitiyordu. Telefonda daha kötü -- sayfa "Bir hata oldu" yazıp donuyor,
öğrencinin yapabileceği tek şey yenilemek.

Otuz kişilik bir sınıfta tek bir kenar durum bir öğrencinin dersini
bitirir. Üstelik o öğrenci ne olduğunu anlatamaz; ekranda gördüğü şey
İngilizce bir yığın izidir.

ÜÇ KATMAN, BU SIRAYLA
---------------------
1. **ÖNCE KAYDET.** Her şeyden önce. Hata mesajı göstermek, kaydı
   kurtarmaktan sonra gelir; öğrenci için en pahalı kayıp ilerlemesidir.
2. **SONRA YAZ.** Yığın izi `kayitlar/hatalar/` altına düşer. Öğrenci
   görmez ama geri bildirim paketine girer, yani bize ulaşır.
3. **EN SON SÖYLE.** Öğrenciye sakin ve eyleme dönük tek cümle: ne oldu,
   ilerlemesi duruyor mu, ne yapabilir.

Oyun DURMUYOR: hata görevin içinde olduysa öğrenci üs menüsüne dönüyor,
menüde olduysa açılış ekranına. Bir görevin bozuk olması dersi bitirmemeli.
"""
from __future__ import annotations

import io
import os
import time
import traceback
from typing import Optional

from . import terminal as ekran

# Kaç hata kaydı tutulur. Sınır var çünkü aynı hata tekrarlanırsa klasör
# şişer ve geri bildirim paketi kullanılamaz hâle gelir.
AZAMI_KAYIT = 20


def hata_klasoru() -> str:
    from . import durum as durum_modulu
    return os.path.join(durum_modulu.KAYIT_KLASORU, "hatalar")


def yaz(sorun: BaseException, nerede: str = "",
        kimlik: str = "") -> Optional[str]:
    """Yığın izini dosyaya yazar, yolunu döndürür. Yazamazsa None.

    Öğrenciye gösterilmez; geri bildirim paketine girsin diye var.

    KİMLİK DOSYA ADINDA. Ortak klasörde bütün sınıfın hata kayıtları yan
    yana duruyor; geri bildirim paketi YALNIZCA o öğrencinin kayıtlarını
    almalı (`geri_bildirim._hata_kayitlari`). Eskiden hepsini alıyordu:
    bir öğrencinin paketi başkasının çökme kaydını -- yığın izindeki hata
    mesajında o öğrencinin yazdığı metni -- taşıyabiliyordu (ChatGPT
    incelemesi, 11 Eylül 2026; GOREVLER B36).

    Ev klasörünün yolu "~" ile değiştirilir: Windows'ta o yol kullanıcı
    adını, yani çoğu zaman bir kişinin adını taşır.
    """
    klasor = hata_klasoru()
    try:
        os.makedirs(klasor, exist_ok=True)
        _eskileri_sil(klasor)
        ek = "-" + _dosya_parcasi(kimlik) if _dosya_parcasi(kimlik) else ""
        yol = os.path.join(klasor, "hata-{}{}.txt".format(
            time.strftime("%Y%m%d-%H%M%S"), ek))
        iz = "".join(traceback.format_exception(
            type(sorun), sorun, sorun.__traceback__))
        with io.open(yol, "w", encoding="utf-8") as dosya:
            dosya.write("nerede: {}\n".format(nerede or "bilinmiyor"))
            dosya.write("kimlik: {}\n".format(_dosya_parcasi(kimlik) or "-"))
            dosya.write("zaman : {}\n\n".format(
                time.strftime("%Y-%m-%d %H:%M:%S")))
            dosya.write(ev_yolunu_gizle(iz))
        return yol
    except Exception:              # noqa: BLE001
        # Hata kaydını yazamamak, hatanın kendisinden daha az önemli.
        return None


def _dosya_parcasi(kimlik) -> str:
    """Kimliğin dosya adına girecek güvenli hâli."""
    return "".join(h for h in str(kimlik or "") if h.isalnum() or h in "-_")[:40]


def kimlige_ait_mi(ad: str, kimlik) -> bool:
    """Bu hata kaydı dosyası (adına bakarak) bu öğrencinin mi?

    Ad TAM çözülür: "hata-<gün>-<saat>-<kimlik>.txt". Eskiden yalnız sonu
    karşılaştırılıyordu; "2" kimlikli öğrenci "ali-2"nin hata kayıtlarını da
    sahipleniyordu -- geri bildirim paketine başkasının kaydı giriyor, kayıt
    silinirken başkasının dosyası siliniyordu (B36.16).
    """
    parca = _dosya_parcasi(kimlik)
    if not parca or not ad.startswith("hata-") or not ad.endswith(".txt"):
        return False
    bolumler = ad[len("hata-"):-len(".txt")].split("-", 2)
    return (len(bolumler) == 3 and bolumler[0].isdigit()
            and bolumler[1].isdigit() and bolumler[2] == parca)


def ev_yolunu_gizle(metin: str) -> str:
    """Yığın izindeki ev klasörü yolunu "~" yapar."""
    ev = os.path.expanduser("~")
    if not ev or ev == "~":
        return metin
    for bicim in sorted({ev, ev.replace("\\", "/"), ev.replace("/", "\\")},
                        key=len, reverse=True):
        metin = metin.replace(bicim, "~")
    return metin


def _eskileri_sil(klasor: str) -> None:
    try:
        dosyalar = sorted(a for a in os.listdir(klasor)
                          if a.startswith("hata-"))
    except OSError:
        return
    for ad in dosyalar[:max(0, len(dosyalar) - AZAMI_KAYIT + 1)]:
        try:
            os.remove(os.path.join(klasor, ad))
        except OSError:
            pass


def ele(sorun: BaseException, durum=None, nerede: str = "") -> None:
    """Beklenmeyen hatayı karşılar: kaydet, yaz, söyle.

    SIRA ÖNEMLİ. Kayıt her şeyden önce gelir -- öğrenci için en pahalı
    kayıp ilerlemesidir, hata mesajı değil.
    """
    kaydedildi = False
    if durum is not None:
        try:
            durum.kaydet()
            kaydedildi = True
        except Exception:          # noqa: BLE001
            pass

    kimlik = ""
    if durum is not None:
        try:
            kimlik = durum.kimlik()
        except Exception:          # noqa: BLE001
            kimlik = ""
    yaz(sorun, nerede, kimlik=kimlik)

    ekran.yaz()
    ekran.hata("Beklenmeyen bir sorun çıktı ve buradan devam edemedim.")
    if kaydedildi:
        ekran.yaz("İlerlemen kaydedildi; kaldığın yerden devam edebilirsin.",
                  "acik_yesil")
    else:
        ekran.yaz("Son birkaç dakikan kaydedilmemiş olabilir.", "gri")
    ekran.yaz("Bu sorun bir dosyaya yazıldı. \"Geri Bildirim Gönder\" "
              "menüsünden paket oluşturursan bize ulaşır.", "gri")
    ekran.bekle()
