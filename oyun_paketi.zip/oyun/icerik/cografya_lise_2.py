# -*- coding: utf-8 -*-
"""
Coğrafya lise ikinci dalga (11-12. sınıf konuları).

`cografya_lise.py` ile aynı kurallar: sayılar üssün kurgusundan gelir ve
tohumla değişir; gerçek bir Türkiye verisi yalnız yıl ve kaynakla (ICERIK_EKLEME.md).
Her görevin bir YANILGISI var; yanlış şıklar o yanılgının farklı yüzleridir
ve her biri "sonuç, çünkü gerekçe" biçiminde, doğru şıkla benzer uzunlukta
yazılır (şık sızıntısı: testler/test_sizinti.py).

Üreticiler: gelismislik_olcutleri, dunya_ticaret_aglari, turizm_etkilesim,
nufus_politikalari. MEB satırlarına bağları `oyun/veri/ek_karsilik.csv`
içinde gerekçeleriyle yazılıdır.

ÇELDİRİCİ HİÇBİR TOHUMDA DOĞRU OLAMAZ -- her üreticide kurucu kısıtlar bunu
garanti eder (yorumlarda yazılı) ve testler/test_cografya_lise_2.py çok
tohumla yeniden sınar.
"""
from __future__ import annotations

import random

from oyun.motor.kayit_defteri import bulmaca
from oyun.motor.modeller import Bulmaca, Kanit

from ._ortak import PERSONEL, ad_sec, model_adimi, sayi_adimi, secim_adimi, yorum_adimi

# Ders kitabı üslubu: şık = "sonuç, çünkü gerekçe". Bölünmüş dize yok,
# noktalı virgül yok (şık sızıntısı: kalıp ölçüsü).


# ==========================================================================
# 1. GELİŞMİŞLİK ÖLÇÜTLERİ
#
# Yanılgı: "Ekonomisi (toplam geliri) büyük olan ülke gelişmiştir."
# Büyük ülke: çok nüfus, düşük kişi başı gelir ama TOPLAM geliri büyük.
# Küçük ülke: az nüfus, yüksek kişi başı gelir, yüksek yaşam süresi ve
# okullaşma. Kısıtlar: toplam_buyuk > toplam_kucuk ve kişi_basi_kucuk >=
# 2 x kişi_basi_buyuk; yaşam süresi ve okullaşma küçükte hep yüksek (aralıklar
# ayrık); çalışanların en büyük payı büyük ülkede birincil sektör.
# ==========================================================================

_ULKE_ADLARI = ("Kuzeyova", "Güneyada", "Batıdere", "Doğuyaka", "Ortaova", "Kıyıbeli")


@bulmaca(ders="cografya", konu="gelismislik_olcutleri", kademeler=(10, 13), agirlik=1.3)
def gelismislik_olcutleri(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Gelişmişlik tek göstergeyle okunmaz; toplam gelir ile kişi başı gelir
    ayrıdır; sektör yapısı gelişmişlikle birlikte okunur."""
    buyuk, kucuk = ad_sec(rastgele, _ULKE_ADLARI, 2)
    while True:
        n_b = rastgele.choice((60, 70, 80, 90, 100))      # milyon kişi
        k_b = rastgele.randrange(2, 5)                    # bin birim / kişi
        n_k = rastgele.choice((10, 12, 15, 20))
        k_k = rastgele.randrange(7, 12)
        if n_b * k_b > n_k * k_k and k_k >= 2 * k_b:
            break
    t_b, t_k = n_b * k_b, n_k * k_k                       # milyar birim
    omur_b, omur_k = rastgele.randrange(62, 70), rastgele.randrange(76, 83)
    okul_b, okul_k = rastgele.randrange(55, 75), rastgele.randrange(90, 99)
    us_b = rastgele.randrange(26, 36)
    ik_b = rastgele.randrange(15, 23)
    bir_b = 100 - us_b - ik_b                             # 42..59, hep en büyük
    bir_k = rastgele.randrange(3, 9)
    ik_k = rastgele.randrange(22, 30)
    us_k = 100 - bir_k - ik_k
    yuz_b, yuz_k = rastgele.randrange(800, 1201, 50), rastgele.randrange(80, 201, 10)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]

    return Bulmaca(
        kod="cog-gelismislik-olcutleri",
        ders="cografya",
        baslik="Gelişmişlik Karnesi",
        kademe=kademe,
        konu="gelismislik_olcutleri",
        kazanim="Ülkelerin gelişmişliğini tek göstergeyle değil gelir, sağlık, "
                "eğitim ve ekonomik yapı göstergeleriyle birlikte okuma; toplam "
                "gelir ile kişi başına geliri ayırma.",
        dikkat=7,
        brifing=(
            "Üssün dış ilişkiler masası ortak kalkınma fonu için iki komşu ülkeden "
            "hangisinin gelişmiş ülke sayılacağını yazacak: {} ve {}.\n\n"
            "{} deftere şunu yazdı: \"Toplam geliri büyük olan ülkenin ekonomisi "
            "büyüktür, o hâlde en gelişmiş olan odur. Gelire bakmak yeter, "
            "başka göstergeyle uğraşmayalım.\"\n\n"
            "Karar yazılmadan önce ülke kartlarına bakmamız gerekiyor."
        ).format(buyuk, kucuk, kisi),
        kanitlar=[
            Kanit("Ülke kartları",
                  "\n".join(
                      "{} ülkesi: toplam gelir {} milyar birim. Nüfus {} milyon "
                      "kişi. Doğuşta yaşam süresi {} yıl. Okullaşma oranı %{}."
                      .format(ad, t, n, omur, okul)
                      for ad, t, n, omur, okul in (
                          (buyuk, t_b, n_b, omur_b, okul_b),
                          (kucuk, t_k, n_k, omur_k, okul_k))),
                  bedel=2, kritik=True),
            Kanit("Çalışanların dağılımı",
                  "{} ülkesinde çalışanların %{} birincil (tarım, madencilik), "
                  "%{} ikincil (sanayi), %{} üçüncül (hizmet) sektörde.\n"
                  "{} ülkesinde çalışanların %{} birincil, %{} ikincil, %{} "
                  "üçüncül sektörde.".format(buyuk, bir_b, ik_b, us_b,
                                              kucuk, bir_k, ik_k, us_k),
                  bedel=1, kritik=True),
            Kanit("Gelişmişlik el kitabı",
                  "Gelişmişlik tek bir sayıyla ölçülmez. Gelir (kişi başına düşen "
                  "gelir = toplam gelir / nüfus), sağlık (doğuşta yaşam süresi), "
                  "eğitim (okullaşma oranı) ve ekonomik yapı (çalışanların "
                  "sektörlere dağılışı) birlikte okunur. Toplam gelir ekonominin "
                  "büyüklüğünü, kişi başına gelir ortalama refahı gösterir. "
                  "Birincil sektör payı yüksek ülkelerde kişi başına gelir "
                  "çoğunlukla düşüktür.",
                  bedel=1, kritik=True),
            Kanit("Yüzölçümü notu",
                  "{} ülkesinin yüzölçümü {} bin km², {} ülkesininki {} bin km².".format(
                      buyuk, yuz_b, kucuk, yuz_k),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir ülkenin gelişmişliği nasıl okunur?",
                dogru="Gelir, sağlık ve eğitim göstergeleri birlikte okunur, çünkü "
                      "gelişmişlik tek sayıyla özetlenmez",
                yanlislar={
                    "Toplam gelire bakılır, çünkü büyük ekonomiye sahip ülke "
                    "kendiliğinden gelişmiş ülke sayılır":
                        "Toplam gelir ekonominin büyüklüğünü gösterir; nüfus çoksa "
                        "kişiye düşen pay küçük kalabilir. Kişi başına gelir de "
                        "sağlık ve eğitim göstergeleri de gerekir.",
                    "Yüzölçümüne bakılır, çünkü geniş topraklar daha çok kaynak "
                    "ve dolayısıyla daha çok refah demektir":
                        "Yüzölçümü bir gelişmişlik göstergesi değildir; büyük "
                        "topraklı bir ülkede de yaşam süresi ve okullaşma düşük "
                        "olabilir.",
                    "Nüfusun çokluğuna bakılır, çünkü kalabalık ülke daha çok "
                    "üretir ve bu yüzden daha gelişmiştir":
                        "Nüfusun çokluğu gelirin çok kişiye bölünmesi demektir. "
                        "Gelişmişlik, kişi başına düşen refah göstergeleriyle "
                        "okunur.",
                },
                rastgele=rastgele,
                aciklama=("Gelişmişlik; gelir, sağlık, eğitim ve ekonomik yapı "
                          "göstergelerinin birlikte okunmasıyla anlaşılır. "
                          "Tek bir sayı, özellikle toplam gelir, yanıltır."),
                ipuclari=[
                    "İki öğrenci sınıfa aynı toplam harçlığı getirse, kalabalık "
                    "olan grup kişi başına daha mı çok almış olur?",
                    "El kitabı gelişmişliği hangi göstergelerle okuyor?",
                ],
                cozum="Gelisim = gelir + saglik + egitim + ekonomik yapi; tek sayi degil",
            ),
            sayi_adimi(
                soru="{} ülkesinde kişi başına düşen gelir kaç bin birimdir?".format(kucuk),
                cevap=k_k,
                birim="bin birim",
                aciklama=("Kişi başına gelir = toplam gelir / nüfus. {} milyar / {} "
                          "milyon = {} bin birim. {} ülkesinde bu değer {} bin "
                          "birimdir.").format(t_k, n_k, k_k, buyuk, k_b),
                yaygin_yanlislar={
                    t_k:
                        "Toplam geliri yazdın; kişi başına gelir için bunu nüfusa "
                        "bölmen gerekiyor.",
                    k_b:
                        "{} ülkesinin değerini yazdın; soru {} ülkesini soruyor."
                        .format(buyuk, kucuk),
                },
                ipuclari=["Milyar birimi milyon kişiye böl: sonuç bin birim olur."],
                puan=14,
                cozum="toplam gelir / nufus",
            ),
            secim_adimi(
                soru="Kartlara göre hangi ülke daha gelişmiş sayılır?",
                dogru="{}, çünkü kişi başına geliri, yaşam süresi ve okullaşması "
                      "{} ülkesinden yüksek".format(kucuk, buyuk),
                yanlislar={
                    "{}, çünkü toplam geliri daha büyük olduğu için ekonomisi daha "
                    "güçlü ve daha zengin sayılır".format(buyuk):
                        "Toplam geliri nüfusa bölmeden karşılaştırdın. {} ülkesinde "
                        "gelir {} milyon kişiye bölünüyor ve kişi başı {} bin birim "
                        "kalıyor.".format(buyuk, n_b, k_b),
                    "İkisi de eşit gelişmiştir, çünkü iki ülkenin gelirleri de "
                    "milyarlarca birimle ölçülen büyük sayılardır":
                        "Gelirlerin büyüklüğü eşit gelişmişlik anlamına gelmez. "
                        "Kişi başı gelir, yaşam süresi ve okullaşma {} lehine "
                        "açık biçimde farklı.".format(kucuk),
                    "{}, çünkü yüzölçümü ve nüfusu daha büyük olduğu için "
                    "kaynakları da daha fazladır".format(buyuk):
                        "Yüzölçümü ve nüfus gelişmişlik göstergesi değildir. Nüfus "
                        "çoksa gelir daha çok kişiye bölünür.",
                },
                rastgele=rastgele,
                aciklama=("{}: kişi başı {} bin birim, yaşam süresi {} yıl, "
                          "okullaşma %{}. {}: kişi başı {} bin birim, yaşam süresi "
                          "{} yıl, okullaşma %{}. Gelişmişlik göstergelerin "
                          "birlikte okunmasıyla anlaşılır.").format(
                    kucuk, k_k, omur_k, okul_k, buyuk, k_b, omur_b, okul_b),
                ipuclari=["Ülke kartındaki dört göstergeyi iki ülke için yan yana yaz."],
                puan=12,
            ),
            yorum_adimi(
                soru="{} ülkesinin çalışan dağılımı ekonomik yapı hakkında ne söyler?"
                     .format(buyuk),
                dogru="Ekonomi tarım ve madenciliğe dayanıyor, çünkü çalışanların "
                      "en büyük bölümü birincil sektörde (%{})".format(bir_b),
                yanlislar={
                    "Ekonomi sanayi ağırlıklı, çünkü ikincil sektör çalışan "
                    "sayısında ilk sırada yer alıyor ve en kalabalık grubu oluşturuyor":
                        "İkincil sektör %{} ile en küçük pay; en büyük pay %{} "
                        "ile birincil sektörde.".format(ik_b, bir_b),
                    "Ekonomi hizmet ağırlıklı, çünkü üçüncül sektör çalışanların "
                    "çoğunu barındırıyor":
                        "Üçüncül sektör %{} ile ikinci sırada; birincil sektör "
                        "%{} ile önde. Hizmet payı gelişmiş ülkelerde yüksek "
                        "olur.".format(us_b, bir_b),
                    "Sektör dağılımı gelişmişlikle ilgili değil, çünkü bütün "
                    "ülkelerde çalışanlar aynı oranda dağılır":
                        "Ülkeler arasında çok fark var: {} ülkesinde birincil "
                        "sektör payı yalnız %{}.".format(kucuk, bir_k),
                },
                rastgele=rastgele,
                aciklama=("Çalışanların büyük kısmı birincil sektörde ise ekonomi "
                          "tarım ve madenciliğe dayanır; bu yapı çoğunlukla düşük "
                          "kişi başı gelirle birlikte görülür. {} ülkesinde ise "
                          "çalışanların %{} üçüncül sektörde.").format(kucuk, us_k),
                ipuclari=["Üç sektör payından en büyüğü hangisi?"],
                puan=10,
            ),
        ],
        kapanis=("Fon masasına {} ülkesi gelişmiş ülke olarak yazıldı: kişi başı "
                 "gelir {} bin birim, yaşam süresi {} yıl. {} ülkesinin toplam "
                 "geliri büyük ama kişi başı payı {} bin birim.").format(
            kucuk, k_k, omur_k, buyuk, k_b),
        odul={"itibar": 5, "erzak": 1},
    )


# ==========================================================================
# 2. DÜNYA TİCARET AĞLARI
#
# Yanılgı: "Yükü en büyük liman ağın merkezidir."
# m1: yükü en büyük ama tek mal çeşidi, 2 bağlantı. m2: yükü m1'den hep küçük
# (en çok 61 < en az 86), 5 bağlantı, 6-9 mal çeşidi. m3, m4: 3 ve 2 bağlantı;
# bağlantı sayısı bakımından m2 her tohumda tek başına birinci.
# ==========================================================================

_LIMAN_ADLARI = ("Serinova", "Taşköprü", "Boğazderesi", "Kızılyar", "Yelkaya",
                 "Çamdibi", "Akpınar", "Susuzkuyu")


@bulmaca(ders="cografya", konu="dunya_ticaret_aglari", kademeler=(11, 13), agirlik=1.3)
def dunya_ticaret_aglari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Ticaret ağında merkez rolü yük miktarıyla değil bağlantı sayısı ve
    mal çeşidiyle belirlenir; ham madde ticareti tek yönlü akar."""
    m1, m2, m3, m4 = ad_sec(rastgele, _LIMAN_ADLARI, 4)
    g1, o1 = rastgele.randrange(4, 10), rastgele.randrange(82, 105)
    g2, o2 = rastgele.randrange(28, 35), rastgele.randrange(20, 28)
    g3, o3 = rastgele.randrange(10, 17), rastgele.randrange(8, 15)
    g4, o4 = rastgele.randrange(6, 13), rastgele.randrange(5, 11)
    c2 = rastgele.randrange(6, 10)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    yil = rastgele.randrange(1895, 1960, 5)

    return Bulmaca(
        kod="cog-dunya-ticaret-aglari",
        ders="cografya",
        baslik="Ticaret Ağı Haritası",
        kademe=kademe,
        konu="dunya_ticaret_aglari",
        kazanim="Ticaret ağında merkez rolünü yük miktarıyla değil bağlantı "
                "sayısı ve mal çeşidiyle ilişkilendirme; ham madde ile pazar "
                "arasındaki akış yönünü yorumlama.",
        dikkat=7,
        brifing=(
            "Üssün ticaret masası ağdaki dört merkezden birine aktarma deposu "
            "kuracak: {}, {}, {} ve {}.\n\n"
            "{} kayıt defterine şunu yazdı: \"En çok yük taşıyan liman ağın "
            "merkezidir. Depoyu orada kuralım, çünkü yük nerede çoksa ticaret "
            "oradan geçer.\"\n\n"
            "Depo yeri yazılmadan önce merkez kayıtlarına bakmamız gerekiyor."
        ).format(m1, m2, m3, m4, kisi),
        kanitlar=[
            Kanit("Merkez kayıtları",
                  "\n".join("{}: gelen yük {} milyon ton, giden yük {} milyon "
                            "ton.".format(ad, g, o)
                            for ad, g, o in ((m1, g1, o1), (m2, g2, o2),
                                             (m3, g3, o3), (m4, g4, o4))),
                  bedel=2, kritik=True),
            Kanit("Hat ve mal kaydı",
                  "Ağdaki on iki merkez içinde doğrudan hat sayıları ve taşınan "
                  "mal çeşitleri:\n"
                  "{}: 2 merkezle hat, 1 mal çeşidi (cevher).\n"
                  "{}: 5 merkezle hat, {} mal çeşidi.\n"
                  "{}: 3 merkezle hat, 3 mal çeşidi.\n"
                  "{}: 2 merkezle hat, 2 mal çeşidi."
                  .format(m1, m2, c2, m3, m4),
                  bedel=2, kritik=True),
            Kanit("Ticaret ağı el kitabı",
                  "Ticaret ağı; merkezlerden ve aralarındaki hatlardan oluşur. "
                  "Bir merkezin ağdaki rolü yük miktarıyla değil, kaç merkezle "
                  "doğrudan bağlı olduğu ve kaç farklı malın aktarıldığıyla "
                  "ölçülür. Ham madde üreten bölgelerde giden yük gelen yükten "
                  "çok büyüktür, çünkü ham madde üretildiği yerden uzaktaki "
                  "pazarlara gider.",
                  bedel=1, kritik=True),
            Kanit("Kuruluş kaydı",
                  "{} merkezi {} yılında kuruldu; diğer üç merkez daha geç.".format(m1, yil),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Bir ticaret ağında merkez rolünü ne belirler?",
                dogru="Bağlantı sayısı ve mal çeşitliliği, çünkü aktarma noktasında "
                      "çok sayıda hat ve mal birleşir",
                yanlislar={
                    "Yük miktarı, çünkü en çok yük taşıyan merkez her zaman en "
                    "çok hatla da bağlıdır ve ağı yönetir":
                        "Yük miktarı ile bağlantı sayısı farklı şeylerdir. Tek bir "
                        "malı çok miktarda taşıyan merkezin hat sayısı az "
                        "kalabilir.",
                    "Kuruluş yılı, çünkü ağın en eski merkezi tüm hatları "
                    "kendisinden başlatmış ve büyütmüş olur":
                        "Kuruluş yılı ağdaki rolü belirlemez; belirleyen sonradan "
                        "kurulan hatlar ve aktarılan mallardır.",
                    "Kıyının uzunluğu, çünkü uzun kıyı daha çok gemi demektir "
                    "ve bu yüzden bağlantı sayısı da yüksektir":
                        "Kıyı uzunluğu ağın bir verisi değil. Rol, doğrudan "
                        "bağlantı ve aktarılan mal çeşidiyle ölçülür.",
                },
                rastgele=rastgele,
                aciklama=("Ticaret ağında merkez, çok sayıda merkeze bağlı olan ve "
                          "farklı malları aktaran noktadır. Yük miktarı tek "
                          "başına merkezi göstermez."),
                ipuclari=[
                    "Otogarı düşün: en çok otobüsün durduğu yer mi merkezdir, "
                    "en çok yöne hat bağlayan yer mi?",
                    "El kitabı rolü neyle ölçüyor?",
                ],
                cozum="Merkez = cok baglanti + cok mal cesidi; yuk miktari degil",
            ),
            sayi_adimi(
                soru="{} merkezinden geçen toplam yük kaç milyon tondur? (gelen "
                     "ve giden birlikte)".format(m2),
                cevap=g2 + o2,
                birim="milyon ton",
                aciklama="{} gelen + {} giden = {} milyon ton.".format(g2, o2, g2 + o2),
                yaygin_yanlislar={
                    g2:
                        "Yalnız gelen yükü yazdın; giden yük de merkezden geçer.",
                    o2:
                        "Yalnız giden yükü yazdın; gelen yükü de eklemelisin.",
                    g1 + o1:
                        "{} merkezinin toplamını yazdın; soru {} merkezini "
                        "soruyor.".format(m1, m2),
                },
                ipuclari=["Kayıtta {} satırını bul; iki yükü topla.".format(m2)],
                puan=12,
                cozum="gelen + giden",
            ),
            secim_adimi(
                soru="Aktarma deposu hangi merkeze kurulmalı?",
                dogru="{}, çünkü beş merkezle doğrudan bağlı ve {} farklı malı "
                      "aktaran çok hatlı bir merkez".format(m2, c2),
                yanlislar={
                    "{}, çünkü en çok yük taşıyan merkez olduğu için en işlek "
                    "aktarma noktası da odur".format(m1):
                        "Yük çok ama bağlantı yalnız 2 merkezle ve mal tek "
                        "çeşit (cevher). Yük miktarını merkez rolü saydın.",
                    "{}, çünkü üç merkezle bağlı orta büyüklükte bir merkez "
                    "olduğu için dengeli bir seçimdir".format(m3):
                        "Bağlantısı 3 merkezle sınırlı; {} merkezi 5 merkezle "
                        "bağlı. Ölçüt denge değil, bağlantı ve mal çeşididir."
                        .format(m2),
                    "{}, çünkü en az yük taşıyan merkezde depo kurmak en ucuz "
                    "olur ve ağı daha az yorar".format(m4):
                        "Maliyet burada ölçüt değil. {} yalnız 2 merkezle bağlı; "
                        "depo çok hattın birleştiği yerde işe yarar.".format(m4),
                },
                rastgele=rastgele,
                aciklama=("{}: 5 hat ve {} mal çeşidi, yükü ise {} milyon ton. {}: "
                          "2 hat, 1 mal çeşidi, yükü {} milyon ton. Aktarma noktası "
                          "çok hattın ve çok malın birleştiği yerdir.").format(
                    m2, c2, g2 + o2, m1, g1 + o1),
                ipuclari=["Hat ve mal kaydına bak: en çok hatla bağlı merkez hangisi?"],
                puan=12,
            ),
            yorum_adimi(
                soru="{} merkezinin giden yükü ({} milyon ton) gelen yükünden "
                     "({} milyon ton) çok büyük. Bu ne anlama gelir?".format(m1, o1, g1),
                dogru="Ham madde üretim yeri pazardan ayrı bir konumda, çünkü "
                      "cevher gibi mallar uzak pazarlara gider",
                yanlislar={
                    "Merkez hatalı çalışıyor, çünkü sağlıklı bir ticarette gelen "
                    "ve giden yükün eşit olması gerekir":
                        "Ticaret dengeli olmak zorunda değil. Ham madde üreten "
                        "bölge çıkardığını gönderir, az şey alır.",
                    "Merkez ağın en çok bağlantılı noktası, çünkü giden yükü en "
                    "büyük olan merkez en çok merkezle bağlıdır":
                        "Yük bağlantı sayısı değildir: {} yalnız 2 merkezle hatlı. "
                        "Giden yükün büyüklüğü ham madde ihracatını gösterir."
                        .format(m1),
                    "Gelen yük kayıt dışı kalmıştır, çünkü küçük rakamlar her "
                    "zaman eksik sayımdan kaynaklanır":
                        "Kayıt eksikliği için bir bulgu yok. Ağ el kitabına göre "
                        "ham madde üreten bölgede gelen yükün küçük olması beklenir.",
                },
                rastgele=rastgele,
                aciklama=("Cevher gibi ham maddeler üretildiği yerde tüketilmez; "
                          "pazara gider. Bu yüzden giden yük gelen yükten çok "
                          "büyüktür ve ticaret tek yönlü akar."),
                ipuclari=["Cevher ocağının yakınında bu cevheri kullanan bir pazar var mı?"],
                puan=10,
            ),
        ],
        kapanis=("Aktarma deposu {} merkezine kuruldu: beş hatla bağlı, {} farklı "
                 "mal aktarıyor. {} merkezi büyük yüküyle ham madde ihracatçısı "
                 "olarak kayda geçti.").format(m2, c2, m1),
        odul={"itibar": 5, "erzak": 1},
    )


# ==========================================================================
# 3. TURİZMİN ETKİLEŞİMİ
#
# Yanılgı: "Ziyaretçi başına harcamanın tamamı bölgede kalır; ziyaretçi
# sayısı artarsa bölgenin kazancı aynı oranda artar."
# Yerelde kalan = ziyaretçi x harcama x (100 - kaçak) / 100. Kaçak %20-40 (hep
# 50'den farklı): çeldirici "tamamı" ya da "kaçak miktarı" doğru olamaz.
# Taşıma kapasitesi = ziyaretçinin %60-80'i: ziyaretçi hep kapasitenin üstünde.
# Havuz: etki türünü ayırma (ekonomik, çevresel, sosyal-kültürel, altyapı).
# ==========================================================================

_TURIZM_HAVUZU = [
    {
        "kayit": "Kıyıda yaz mevsiminde günlük su tüketiminin iki katına çıkması",
        "aciklama": ("Su tüketiminin sezonda artması doğal kaynak üzerindeki yükü "
                     "gösterir: çevresel etkidir. Gelir ya da kültür değişimi "
                     "değil, kaynakların kullanımı söz konusu."),
        "sec": [
            ("Çevresel etki", "olay su gibi doğal kaynakların kullanım yükünü gösteriyor", ""),
            ("Ekonomik etki", "olay bölgedeki harcama ve gelirin artmasını gösteriyor",
             "Olayda para, gelir ya da harcama yok; su tüketimi var. Gelir ve "
             "istihdam ekonomik etkidir."),
            ("Sosyal ve kültürel etki", "olay yerel halkın yaşam biçimini ve ilişkilerini etkiliyor",
             "Olayda yaşam biçimi ya da gelenek değişimi anlatılmıyor; doğal "
             "kaynak tüketimi anlatılıyor."),
            ("Altyapı ve ulaşım etkisi", "olay yeni yol ve tesis yapımı gerektiriyor",
             "Olay bir yapım ya da ulaşım düzenlemesinden söz etmiyor. Kaynağın "
             "kendisi, yani su, zorlanıyor."),
        ],
    },
    {
        "kayit": "Pazar esnafının ziyaretçilerin ödemeleriyle gelirini yılda iki katına çıkarması",
        "aciklama": ("Ziyaretçi harcamasının yerel esnafa gelir olarak dönmesi "
                     "ekonomik etkidir. Gelir artışı çevreyi ya da kültürü "
                     "değil, bölgenin kazancını gösterir."),
        "sec": [
            ("Ekonomik etki", "olay ziyaretçi harcamasının esnafa gelir olarak dönmesini gösteriyor", ""),
            ("Çevresel etki", "olay yoğun ziyaretçi akışının doğaya yük bindirmesini gösteriyor",
             "Olayda doğal kaynak ya da kirlilik yok; gelir artışı var. "
             "Kaynakların kullanımı çevresel etkidir."),
            ("Sosyal ve kültürel etki", "olay yerel halkın yaşam biçimindeki bir değişimi gösteriyor",
             "Olay gelenek, dil ya da ilişkilerden söz etmiyor. Esnafın "
             "gelirindeki artış anlatılıyor."),
            ("Altyapı ve ulaşım etkisi", "olay ziyaretçileri taşımak için yapılan yatırımı gösteriyor",
             "Olayda yol, liman ya da tesis yok. Esnaf geliri artıyor; "
             "yatırımdan söz edilmiyor."),
        ],
    },
    {
        "kayit": "Gençlerin ziyaretçilerle konuşabilmek için yabancı dil öğrenmesi ve yeni yemekleri tanıması",
        "aciklama": ("Dil öğrenme ve yeni yemekleri tanıma, ziyaretçilerle "
                     "kültürel etkileşimin sonucudur: sosyal ve kültürel etki. "
                     "Ülkeler arası etkileşimin en görünür yüzlerinden biri."),
        "sec": [
            ("Sosyal ve kültürel etki", "olay dil ve yemek tanımayla kültürel tanışmayı ve etkileşimi gösteriyor", ""),
            ("Ekonomik etki", "olay gençlerin ziyaretçilere hizmet vererek gelir elde etmesini gösteriyor",
             "Dil öğrenmenin gelire dönüşebileceği doğru ama olayda gelir "
             "anlatılmıyor; kültürel tanışma anlatılıyor."),
            ("Çevresel etki", "olay yerel doğanın yeni ziyaretçilere açılıp korunmasını gösteriyor",
             "Olayda doğa ya da kaynak kullanımı yok. Dil ve yemek, kültürel "
             "unsurlardır."),
            ("Altyapı ve ulaşım etkisi", "olay ziyaretçileri karşılamak için eğitim binalarının yapılmasını gösteriyor",
             "Olayda yeni yapı ya da ulaşım hattı yok. Etkileşim, insanların "
             "birbirini tanımasında."),
        ],
    },
    {
        "kayit": "Ziyaretçi akını nedeniyle bölgeye yeni bir havalimanı ve yol hattının yapılması",
        "aciklama": ("Ziyaretçiyi taşımak için yapılan havalimanı ve yol, altyapı "
                     "ve ulaşımın gelişmesidir. Yerel halk da bu ağı kullanır; "
                     "etki yatırım ve ulaşım alanında görülür."),
        "sec": [
            ("Altyapı ve ulaşım etkisi", "olay ziyaretçi için yeni ulaşım yapıları kurulmasını gösteriyor", ""),
            ("Ekonomik etki", "olay yeni yapıların bölgeye iş ve gelir getirmesini, yani kazancı gösteriyor",
             "Yapıların gelir getirmesi olası ama olayın kendisi bir yapım "
             "ve ulaşım yatırımı. Gelir artışı ayrı bir etki."),
            ("Çevresel etki", "olay yeni yapıların doğal alanları daralttığını ve bozduğunu gösteriyor",
             "Doğal alan kaybı olayda anlatılmıyor. Konu, ulaşım yapılarının "
             "kurulması."),
            ("Sosyal ve kültürel etki", "olay yerel halkın ulaşım alışkanlıklarını değiştirdiğini gösteriyor",
             "Olayda yaşam biçimi değişimi yok. Havalimanı ve yol hattı "
             "kuruluyor."),
        ],
    },
]


@bulmaca(ders="cografya", konu="turizm_etkilesim", kademeler=(11, 13), agirlik=1.3)
def turizm_etkilesim(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Turizmin geliri dış kaçakla azalır; etkisi çok yönlüdür; taşıma
    kapasitesi aşıldığında yük gelirle birlikte büyür."""
    durum = rastgele.choice(_TURIZM_HAVUZU)
    bolge = rastgele.choice(("Karataş", "Akpınar", "Yelkaya", "Çamdibi", "Serinova"))
    ziyaretci = rastgele.choice((120, 150, 200, 250))          # bin kişi
    harcama = rastgele.choice((20, 40, 50, 60))                # birim / ziyaretçi
    kacak = rastgele.choice((20, 25, 30, 40))                  # %
    oran = rastgele.choice((60, 70, 80))
    kapasite = ziyaretci * oran // 100                         # bin kişi
    toplam = ziyaretci * harcama                               # bin birim
    kalan = toplam * (100 - kacak) // 100
    kacan = toplam * kacak // 100
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    ilk = durum["kayit"]

    return Bulmaca(
        kod="cog-turizm-etkilesim",
        ders="cografya",
        baslik="Turizm Defteri",
        kademe=kademe,
        konu="turizm_etkilesim",
        kazanim="Turizmin ekonomik, çevresel ve sosyal-kültürel etkilerini ayırma; "
                "turizm gelirinin bölgede kalan payını hesaplama; taşıma "
                "kapasitesini turizm planlamasına bağlama.",
        dikkat=7,
        brifing=(
            "{} kıyı bölgesinde bu yıl {} bin ziyaretçi ağırlandı ve bölge "
            "turizmi daha da büyütmek istiyor.\n\n"
            "{} deftere şunu yazdı: \"Ziyaretçi başına harcamanın tamamı bölgede "
            "kalır; ziyaretçiyi artırırsak kazanç aynı oranda artar. Başka "
            "bir ayrıntıya bakmaya gerek yok.\"\n\n"
            "Plan yazılmadan önce sezon kayıtlarına bakmamız gerekiyor."
        ).format(bolge, ziyaretci, kisi),
        kanitlar=[
            Kanit("Sezon kayıtları",
                  "{} bölgesine gelen ziyaretçi: {} bin kişi. Kişi başı ortalama "
                  "harcama: {} birim.".format(bolge, ziyaretci, harcama),
                  bedel=1, kritik=True),
            Kanit("Harcama dağılımı",
                  "Harcamanın %{} kadarı bölge dışına gidiyor: yabancı tur "
                  "şirketlerinin payı, dışarıdan getirilen mal ve dışarıdan gelen "
                  "çalışanların ücretleri. Kalan pay bölgede kalıyor."
                  .format(kacak),
                  bedel=2, kritik=True),
            Kanit("Taşıma kapasitesi notu",
                  "Bölgenin su, çöp ve konaklama altyapısı yılda en çok {} bin "
                  "ziyaretçiyi sorunsuz ağırlayacak büyüklükte.".format(kapasite),
                  bedel=1, kritik=True),
            Kanit("Turizm el kitabı",
                  "Turizm bir bölgeyi ekonomik (gelir, istihdam), çevresel (su, "
                  "kıyı, atık) ve sosyal-kültürel (dil, gelenek, ilişkiler) "
                  "yönlerden etkiler. Ziyaretçi harcamasının bir bölümü bölge "
                  "dışına çıkar (kaçak); bölgede kalan pay kaçak düşüldükten "
                  "sonraki paydır. Taşıma kapasitesi aşılırsa gelirle birlikte "
                  "çevre ve hizmet yükü de büyür.",
                  bedel=1, kritik=True),
            Kanit("Kayıt notu",
                  "Defterde ayrıca şu olay yazılı: \"{}\".".format(ilk),
                  bedel=1),
        ],
        adimlar=[
            model_adimi(
                soru="Turizm bir bölgeyi nasıl etkiler?",
                dogru="Ekonomik, çevresel ve kültürel yönleriyle birlikte etkiler, "
                      "çünkü akış gelirle birlikte yük de getirir",
                yanlislar={
                    "Yalnız gelir artışıyla etkiler, çünkü gelen her ziyaretçi "
                    "bölgeye kazanç bırakır ve başka etkisi olmaz":
                        "Turizm gelir getirir ama su, kıyı ve atık üzerinde yük "
                        "de oluşturur; dil ve gelenekleri de etkiler.",
                    "Yalnız çevreye zarar vererek etkiler, çünkü ziyaretçi "
                    "bulunduğu yeri her zaman kirletir ve başka etkisi görülmez":
                        "Çevresel yük bir etkidir ama tek değil: gelir, "
                        "istihdam ve kültürel etkileşim de turizmin sonuçları.",
                    "Etkisi yalnız ziyaretçi sayısıyla ölçülür, çünkü sayı "
                    "büyüdükçe her alandaki etki de aynı oranda büyür":
                        "Sayı tek başına etkiyi belirlemez; harcamanın ne kadarı "
                        "kaldığı ve kapasite de belirler.",
                },
                rastgele=rastgele,
                aciklama=("Turizmin etkisi çok yönlüdür: ekonomik (gelir, istihdam), "
                          "çevresel (su, kıyı, atık), sosyal-kültürel (dil, gelenek). "
                          "Yalnız birine bakmak diğerlerini gizler."),
                ipuclari=[
                    "Bir festivalin bir mahalleye getirdiği iyi ve zor yanları "
                    "say: yalnız para mı kalır?",
                    "El kitabı etkileri hangi üç başlıkta topluyor?",
                ],
                cozum="Turizm = ekonomik + cevresel + sosyal-kulturel etki",
            ),
            sayi_adimi(
                soru="Bu yıl {} bölgesinde kalan turizm geliri kaç bin birimdir?"
                     .format(bolge),
                cevap=kalan,
                birim="bin birim",
                aciklama=("Toplam harcama = {} bin kişi x {} birim = {} bin "
                          "birim. Dışarı giden pay %{} = {} bin birim. Bölgede "
                          "kalan = {} - {} = {} bin birim.").format(
                    ziyaretci, harcama, toplam, kacak, kacan, toplam, kacan, kalan),
                yaygin_yanlislar={
                    toplam:
                        "Toplam harcamayı yazdın; dışarı giden payı düşmedin.",
                    kacan:
                        "Dışarı giden payı yazdın; soru bölgede kalan geliri "
                        "soruyor.",
                },
                ipuclari=["Önce toplam harcamayı bul, sonra dışarı giden payı çıkar."],
                puan=14,
                cozum="ziyaretci x harcama x (100 - kacak) / 100",
            ),
            yorum_adimi(
                soru="Bölge ziyaretçi sayısını {} bine çıkarmayı düşünüyor. "
                     "Öneri nasıl olmalı?".format(ziyaretci * 3 // 2),
                dogru="Önce taşıma kapasitesine bakılmalı, çünkü kapasite aşılınca "
                      "gelirle birlikte yük de büyür",
                yanlislar={
                    "Sayı artırılmalı, çünkü her yeni ziyaretçi bölgeye ek gelir "
                    "bırakır ve yük bindirmez":
                        "Bu yıl bile ziyaretçi ({} bin) kapasitenin ({} bin) "
                        "üstünde; her yeni ziyaretçi su, atık ve konaklama "
                        "yükünü de büyütür.".format(ziyaretci, kapasite),
                    "Turizm durdurulmalı, çünkü ziyaretçi bölgeye yalnız zarar "
                    "verir ve gelirden fazla yük getirir":
                        "Turizm gelir de getiriyor: bölgede {} bin birim kaldı. "
                        "Çözüm yok etmek değil, kapasiteye göre planlamak."
                        .format(kalan),
                    "Önce kaçak oranı sıfırlanmalı, çünkü kapasite yalnızca "
                    "geliri düşük bölgelerde sorun olur":
                        "Kapasite aşımı gelirden bağımsız bir yük sorunudur. "
                        "Kaçak payı gelirin bölgede kalmasını etkiler, yükü değil.",
                },
                rastgele=rastgele,
                aciklama=("Ziyaretçi ({} bin) kapasitenin ({} bin) üstünde olduğu için "
                          "sayıyı artırmak gelirle birlikte su, atık ve konaklama "
                          "yükünü de büyütür. Planlama önce kapasiteyi, sonra "
                          "gelirin bölgede kalma payını gözetir.").format(
                    ziyaretci, kapasite),
                ipuclari=["Kapasite notuna bak: bu yılki sayı kapasitenin altında mı üstünde mi?"],
                puan=12,
            ),
            _siniflama_etki(durum, rastgele),
        ],
        kapanis=("Bölge planına işlendi: bu yıl {} bin birim bölgede kaldı, "
                 "ziyaretçi sayısı kapasitenin üstünde ve artırma kararı "
                 "kapasiteye göre verilecek.").format(kalan),
        odul={"itibar": 5, "erzak": 1},
    )


def _siniflama_etki(durum, rastgele):
    """Defterdeki olayı etki türüne ayırtan adım (havuz öğesinin sec listesi)."""
    sec = durum["sec"]
    return secim_adimi(
        soru="Defterdeki olay turizmin hangi etkisini gösterir?",
        dogru="{}, çünkü {}".format(sec[0][0], sec[0][1]),
        yanlislar={"{}, çünkü {}".format(ad, ger): tes for ad, ger, tes in sec[1:]},
        rastgele=rastgele,
        aciklama=durum["aciklama"],
        ipuclari=["Olay para mı, doğal kaynak mı, insanların ilişkisi mi, yoksa "
                  "yapı ve ulaşım mı anlatıyor?"],
        puan=12,
    )


# ==========================================================================
# 4. NÜFUS POLİTİKALARI
#
# Yanılgı: "Nüfus politikası ülkeden ülkeye taklit edilir; toplam nüfusa bakmak
# yeter." Üç dönem durumu (hızlı artış, yaşlanma, dengesiz dağılım); her biri
# kendi göstergeleriyle tek bir politikayı destekler. Bağımlılık oranı =
# çocuk bağımlılığı + yaşlı bağımlılığı (çalışma çağındaki 100 kişiye düşen
# bağımlı sayısı); çeldirici sayılar tek bileşenden ibaret olduğundan toplama
# eşit olamaz (iki bileşen de pozitif).
# ==========================================================================

_NUFUS_UKELERI = ("Gökdere", "Akliman", "Taşocağı", "Demirkapı")

_POLITIKA_DURUMLARI = [
    {
        "ad": "hizli_artis",
        "cr": (60, 75), "yr": (6, 10),
        "goc": "Yıllık nüfus artışı binde {} ve okul, konut, iş ihtiyacı her yıl katlanıyor.",
        "artis": (24, 31),
        "sec": [
            ("Aile planlaması politikası",
             "çocuk bağımlılığı yüksek ve artış okul, konut ve istihdamı zorluyor", ""),
            ("Doğumu teşvik eden politika",
             "nüfus arttıkça ülkenin gücü de aynı oranda artar ve ekonomi güçlenir",
             "Göstergelerde çocuk bağımlılığı zaten yüksek ve artış hızlı. Ek "
             "artış okul, konut ve istihdam yükünü büyütür."),
            ("Dışarıdan göçü yasaklayan politika",
             "göç nüfusu artıran tek önemli etkendir ve engellenince artış durur",
             "Kayıtta göçten kaynaklanan bir sorun yok; artış doğum "
             "kaynaklı. Göçü engellemek bu sorunu çözmez."),
            ("Hiçbir politika uygulamayan yaklaşım",
             "nüfus kendiliğinden dengeye gelir ve müdahale gerekmez",
             "Dengeye kendiliğinden gelmesi beklenirken yük yıllarca "
             "büyür. Göstergeler müdahale gerektiriyor."),
        ],
        "aciklama": ("Çocuk bağımlılığı yüksek, artış hızlı: okul, konut ve iş "
                     "ihtiyacı büyüyor. Gösterge doğum kaynaklı bir yüke işaret "
                     "ettiği için aile planlamasını destekleyen politika uygun."),
    },
    {
        "ad": "yaslanma",
        "cr": (22, 28), "yr": (30, 38),
        "goc": "Yıllık nüfus değişimi binde eksi {} ve çalışma çağındaki nüfus her yıl küçülüyor.",
        "artis": (2, 5),
        "sec": [
            ("Doğumu ve aileyi destekleyen politika",
             "yaşlı bağımlılığı yüksek ve çalışan nüfus küçülüyor", ""),
            ("Aile planlamasını yaygınlaştıran politika",
             "nüfus azalsa da doğum sayısı sınırlı tutulmalıdır",
             "Nüfus zaten azalıyor ve yaşlı bağımlılığı yüksek. Doğumu daha "
             "da kısmak çalışma çağındaki nüfusu daha çok küçültür."),
            ("Çalışan fazlasını dışarıya gönderen politika",
             "çalışma çağındaki nüfusun bir bölümü fazladır",
             "Çalışma çağındaki nüfus fazla değil, küçülüyor. Dışarıya "
             "gönderilirse bağımlı yük çalışana daha çok biner."),
            ("Hiçbir politika uygulamayan yaklaşım",
             "nüfus azalışı ülkenin gücünü etkilemez",
             "Azalan çalışan nüfus vergi, üretim ve bakım hizmetlerini "
             "zorlar. Göstergeler müdahale gerektiriyor."),
        ],
        "aciklama": ("Yaşlı bağımlılığı yüksek, nüfus azalıyor ve çalışma çağındaki "
                     "nüfus küçülüyor: bu tablo doğumu ve aileyi destekleyen bir "
                     "politikayı gerektirir. Sınırlayıcı ya da göçü artıran "
                     "politika durumu ağırlaştırır."),
    },
    {
        "ad": "dengesiz",
        "cr": (30, 36), "yr": (14, 18),
        "goc": "Yıllık nüfus artışı binde {} ve orta düzeyde; sorun artışta değil dağılımda.",
        "artis": (10, 12),
        "sec": [
            ("Yerleşimi dengeleyen bölgesel politika",
             "artış orta ve nüfus kıyıda yığılıp iç bölge boşalıyor", ""),
            ("Doğumu sınırlayan aile planlaması politikası",
             "kıyıdaki yoğunluk doğum sayısından kaynaklanır",
             "Artış orta düzeyde. Yoğunluğun kaynağı doğum değil, nüfusun "
             "kıyıda toplanması; sorun dağılımda."),
            ("Doğumu teşvik eden politika",
             "iç bölgenin boşalması doğumların azlığından gelir ve artırılmalıdır",
             "İç bölgenin boşalması doğum azlığından değil, nüfusun kıyıya "
             "göçünden. Doğumu artırmak dağılım sorununu çözmez."),
            ("Kıyıya göçü hızlandıran politika",
             "yoğunluk arttıkça kıyı kentleri daha güçlü ve zengin olur",
             "Kıyı zaten çok yoğun; göçü hızlandırmak kıyıdaki yükü ve iç "
             "bölgedeki boşalmayı büyütür."),
        ],
        "aciklama": ("Artış orta düzeyde ama nüfus kıyıya yığılıyor, iç bölge "
                     "boşalıyor: sorun artıştan çok dağılımdadır. Yerleşimi ve "
                     "yatırımı bölgelere yayan bölgesel politika uygun."),
    },
]


@bulmaca(ders="cografya", konu="nufus_politikalari", kademeler=(9, 13), agirlik=1.3)
def nufus_politikalari(rastgele: random.Random, kademe: int) -> Bulmaca:
    """Nüfus politikası nüfusun büyüklüğüne değil yaş yapısı, artış hızı ve
    dağılım göstergelerine bakılarak seçilir."""
    durum = rastgele.choice(_POLITIKA_DURUMLARI)
    us = rastgele.choice(_NUFUS_UKELERI)
    w = rastgele.choice((500, 600, 800, 1000))                 # bin kişi (15-64)
    cr = rastgele.randrange(*durum["cr"])
    yr = rastgele.randrange(*durum["yr"])
    c, y = cr * w // 100, yr * w // 100
    toplam = c + w + y
    bagimli = cr + yr
    artis = rastgele.randrange(*durum["artis"])
    goc_notu = durum["goc"].format(artis)
    kisi = ad_sec(rastgele, PERSONEL, 1)[0]
    dengesiz = durum["ad"] == "dengesiz"

    kanitlar = [
        Kanit("Yaş yapısı tablosu",
              "{} üssü nüfusu: toplam {} bin kişi.\n0-14 yaş: {} bin. 15-64 yaş: "
              "{} bin. 65 yaş ve üstü: {} bin.".format(us, toplam, c, w, y),
              bedel=2, kritik=True),
        Kanit("Artış ve dağılım notu", goc_notu +
              (" Kıyı kentinde km² başına 420 kişi, iç bölgede 35 kişi."
               if dengesiz else ""),
              bedel=1, kritik=True),
        Kanit("Nüfus el kitabı",
              "Nüfus politikaları; yaş yapısı, artış hızı ve nüfusun mekânda "
              "dağılışı gibi göstergelere bakılarak belirlenir ve dönemlere "
              "göre değişir. Bağımlılık oranı = (0-14 yaş + 65 yaş ve üstü) / "
              "(15-64 yaş) x 100: çalışma çağındaki 100 kişiye düşen bağımlı "
              "sayısıdır.",
              bedel=1, kritik=True),
        Kanit("Tarihsel not",
              "Türkiye'de 1965'te kabul edilen Nüfus Planlaması Hakkında Kanun, "
              "nüfus artış hızının yüksek olduğu bir dönemde aile planlaması "
              "hizmetlerini yasal çerçeveye aldı (kaynak: TBMM mevzuat kayıtları). "
              "Bu görevdeki sayılar kurgudur.",
              bedel=1),
    ]

    return Bulmaca(
        kod="cog-nufus-politikalari",
        ders="cografya",
        baslik="Nüfus Politikası Dosyası",
        kademe=kademe,
        konu="nufus_politikalari",
        kazanim="Nüfus politikasını yaş yapısı, artış hızı ve dağılım "
                "göstergelerine bağlama; bağımlılık oranını hesaplama; aynı "
                "politikanın her ülkede uygun olmadığını gerekçelendirme.",
        dikkat=7,
        brifing=(
            "{} üssünün yönetimi gelecek on yıl için bir nüfus politikası "
            "seçecek.\n\n"
            "{} deftere şunu yazdı: \"Komşu üs hangi politikayı uyguluyorsa biz "
            "de onu uygulayalım. Üssün toplam nüfusu belli, başka bir ayrıntıya "
            "bakmaya gerek yok.\"\n\n"
            "Politika yazılmadan önce üssün göstergelerine bakmamız gerekiyor."
        ).format(us, kisi),
        kanitlar=kanitlar,
        adimlar=[
            model_adimi(
                soru="Bir ülkenin nüfus politikası neye bakılarak seçilir?",
                dogru="Yaş yapısı, artış hızı ve dağılışa bakılarak seçilir, "
                      "çünkü politika sorunun kaynağına yönelmelidir",
                yanlislar={
                    "Komşu ülkenin politikası taklit edilerek seçilir, çünkü aynı "
                    "politika her ülkede aynı sonucu verir":
                        "Her ülkenin göstergeleri farklıdır. Hızlı artış yaşayan "
                        "ülkeye uyan politika yaşlanan ülkeyi zora sokar.",
                    "Toplam nüfusun büyüklüğüne bakılarak seçilir, çünkü kalabalık "
                    "ülke her durumda doğumu sınırlamalıdır":
                        "Toplam nüfus tek başına sorunu göstermez; yaşlanan "
                        "kalabalık bir ülke de olabilir. Yaş yapısı ve artış "
                        "hızı da gerekir.",
                    "Geçmiş dönemin politikası sürdürülerek seçilir, çünkü "
                    "politikalar bir kez belirlenince değişmez":
                        "Politikalar dönemlere göre değişir. Göstergeler "
                        "değişince uygun politika da değişir.",
                },
                rastgele=rastgele,
                aciklama=("Politika, nüfusun yaş yapısı, artış hızı ve dağılışı "
                          "gibi göstergelerin gösterdiği soruna göre seçilir "
                          "ve dönemlere göre değişir."),
                ipuclari=[
                    "Doktor herkese aynı ilacı yazar mı, yoksa belirtilere mi bakar?",
                    "El kitabı politikayı hangi göstergelere bağlıyor?",
                ],
                cozum="Politika = gostergelere gore; yas yapisi, artis hizi, dagilis",
            ),
            sayi_adimi(
                soru="{} üssünde bağımlılık oranı kaçtır? (çalışma çağındaki 100 "
                     "kişiye düşen bağımlı sayısı)".format(us),
                cevap=bagimli,
                birim="",
                aciklama=("Bağımlı nüfus = 0-14 yaş ({} bin) + 65 yaş ve üstü ({} "
                          "bin) = {} bin. Çalışma çağındaki nüfus {} bin. Oran = "
                          "{} / {} x 100 = {}.").format(c, y, c + y, w, c + y, w,
                                                        bagimli),
                yaygin_yanlislar={
                    cr:
                        "Yalnız çocuk bağımlılığını yazdın; 65 yaş ve üstünü de "
                        "bağımlı nüfusa katmalısın.",
                    yr:
                        "Yalnız yaşlı bağımlılığını yazdın; 0-14 yaş grubunu da "
                        "bağımlı nüfusa katmalısın.",
                },
                ipuclari=["Önce 0-14 ve 65 yaş ve üstünü topla, sonra 15-64 yaş "
                          "grubuna böl."],
                puan=14,
                cozum="(0-14 + 65 ve ustu) / (15-64) x 100",
            ),
            secim_adimi(
                soru="{} üssünün göstergelerine en uygun politika hangisidir?"
                     .format(us),
                dogru="{}, çünkü {}".format(durum["sec"][0][0], durum["sec"][0][1]),
                yanlislar={"{}, çünkü {}".format(ad, ger): tes
                           for ad, ger, tes in durum["sec"][1:]},
                rastgele=rastgele,
                aciklama=durum["aciklama"],
                ipuclari=["Artış hızına, yaş grubu paylarına ve dağılış notuna "
                          "birlikte bak."],
                puan=12,
            ),
        ],
        kapanis=("{} üssünün dosyasına politika yazıldı: bağımlılık oranı {}; "
                 "karar göstergelere göre verildi, komşuyu taklide göre "
                 "değil.").format(us, bagimli),
        odul={"itibar": 5, "erzak": 1},
    )
