# -*- coding: utf-8 -*-
"""
Baştan sona tutarlılık denetimi (B46.4).

    python main.py --tutarlilik            # bütün dersler, lise (9-12)
    python main.py --tutarlilik edebiyat   # tek ders

`--denetle` tek bir görevin teknik kurallarına bakar (ek uyumu, teşhis =
cevap, havuz). Bu araç görevlerin ANLATTIĞI dünyaya bakar:

(a) SAYI-ANLATI ÇELİŞKİSİ -- bu projede en sık yakalanan hata türü (22 Eylül:
    "dün en soğuk gündü" anlatısı tablodaki sayıyla çelişti). Kural: metin bir
    satır için "en yüksek / en soğuk / en az ..." diyorsa ve aynı görevin
    kanıtlarında o satırın sayısı bir tabloda duruyorsa, iddia o tablonun
    gerçekten en büyüğünü (ya da en küçüğünü) göstermeli.
(b) KURGU TUTARLILIĞI -- görevlerin hepsi aynı üssü anlatır. Ödül yalnız
    oyunun kaynaklarından olur (erzak, cevher, enerji, itibar); metin
    "+3 erzak" diyorsa görevin ödülü de 3 erzak vermeli.
(c) OTURUM AKIŞI -- kayıt -> ilk görev -> sefer sonu -> ertesi gün açılış;
    bu bir sınama, araç değil: `testler/test_oturum_akisi.py`.

Kurallar sezgiseldir; yakaladıkları "bak" demektir. Bulunan her satır insan
gözüyle doğrulanmalı. Sıfır bulgu, anlatının doğru olduğu anlamına gelmez.
"""
from __future__ import annotations

import random
import re
import traceback
from typing import Dict, List, Optional, Tuple

from oyun.motor.durum import KAYNAK_ADLARI, KAYNAKLAR
from oyun.motor.kayit_defteri import icerigi_yukle, tum_kayitlar

LISE = (9, 12)
TOHUM_SAYISI = 6

_SAYI = r"-?\d+(?:[.,]\d+)?"
# Tablo satırı: satır başında bir ad, ardından (iki nokta, parantez, çizgi
# ya da birkaç sözcük sonra) İLK sayı. "Ad: 12", "Ad (1069): ...",
# "Vadi deposu (taşkın): tehlike 2, ..." -- çok sütunlu satırda ilk sütun.
_TABLO_SATIRI = re.compile(
    r"^\s*[-*•]?\s*(?:\d+\.\s+)?([A-ZÇĞİÖŞÜ][^\d:\n(|=]{0,40}?)\s*"
    r"[:(|=][^\d\n]{0,25}?(" + _SAYI + r")", re.M)

# sıfat -> en büyüğü mü (True) en küçüğü mü (False) iddia ediyor
_SIFATLAR = {
    "yüksek": True, "büyük": True, "fazla": True, "çok": True, "uzun": True,
    "sıcak": True, "hızlı": True, "ağır": True, "derin": True, "kalabalık": True,
    "pahalı": True, "geniş": True, "güçlü": True,
    "düşük": False, "küçük": False, "az": False, "kısa": False,
    "soğuk": False, "yavaş": False, "hafif": False, "sığ": False, "ucuz": False,
    "dar": False, "zayıf": False,
}
_IDDIA = re.compile(
    r"(?<![\wçğıöşü])([A-ZÇĞİÖŞÜ][\wçğıöşüâîû'’-]+(?: [A-ZÇĞİÖŞÜ][\wçğıöşüâîû'’-]+)?)"
    r"[^.!?\nA-ZÇĞİÖŞÜ]{0,12}?\ben (" + "|".join(_SIFATLAR) + r")(?![\wçğıöşü])")

_KAYNAK_ANMA = re.compile(
    r"\+\s?(\d+)\s+(" + "|".join(a.lower() for a in KAYNAK_ADLARI.values()) + r")\b",
    re.I)


def _sayi(metin: str) -> float:
    return float(metin.replace(",", "."))


def _tablolar(metinler: List[str]) -> List[Dict[str, float]]:
    """Her metindeki tablo: en az üç satırlı ad -> sayı."""
    tablolar = []
    for metin in metinler:
        satirlar: Dict[str, float] = {}
        for ad, sayi in _TABLO_SATIRI.findall(metin or ""):
            ad = ad.strip(" .")
            if ad and ad not in satirlar:
                satirlar[ad] = _sayi(sayi)
        if len(satirlar) >= 3:
            tablolar.append(satirlar)
    return tablolar


def _satir_bul(ad: str, tablo: Dict[str, float]) -> Optional[str]:
    """İddiadaki ad tablodaki hangi satır? Tam ya da baş eşleşme (Türkçe
    ekler: "Kuzey kulesi" / "Kuzey kulesinde")."""
    kucuk = ad.lower()
    for satir in tablo:
        s = satir.lower()
        # Baş eşleşmede kısa satır adı ("H", "A") her sözcüğün başına uyar:
        # "Hem ... en düşük" H satırını sanılıyordu. En az 4 harf.
        if s == kucuk or (min(len(s), len(kucuk)) >= 4
                          and (kucuk.startswith(s) or s.startswith(kucuk))):
            return satir
    return None


def sayi_anlati(bulmaca) -> List[str]:
    """(a) "X en yüksek" iddiası kanıt tablosuyla çelişiyor mu?"""
    kanitlar = [k.icerik for k in bulmaca.kanitlar] + [bulmaca.brifing]
    tablolar = _tablolar(kanitlar)
    if not tablolar:
        return []
    anlatilar = ([("brifing", bulmaca.brifing), ("kapanış", bulmaca.kapanis)]
                 + [("adım {} sorusu".format(i), a.soru)
                    for i, a in enumerate(bulmaca.adimlar, 1)]
                 + [("adım {} açıklaması".format(i), a.aciklama)
                    for i, a in enumerate(bulmaca.adimlar, 1)])
    sorunlar = []
    for yer, metin in anlatilar:
        for ad, sifat in _IDDIA.findall(metin or ""):
            for tablo in tablolar:
                # "Nöbetçiler Liman en soğuk": iki sözcüklü ad tabloda yoksa
                # iddiaya en yakın sözcük denenir.
                satir = (_satir_bul(ad, tablo)
                         or _satir_bul(ad.split()[-1], tablo))
                if satir is None:
                    continue
                hedef = (max if _SIFATLAR[sifat] else min)(tablo.values())
                if tablo[satir] != hedef:
                    sorunlar.append(
                        "{}: '{} ... en {}' diyor ama tabloda {} = {}, "
                        "en {} değer {}".format(
                            yer, ad, sifat, satir, tablo[satir],
                            "büyük" if _SIFATLAR[sifat] else "küçük", hedef))
                break
    return sorunlar


def kurgu(bulmaca) -> List[str]:
    """(b) Ödül oyunun kaynaklarından mı; metindeki "+N kaynak" ödülle aynı mı?"""
    sorunlar = []
    odul = bulmaca.odul or {}
    for anahtar, miktar in odul.items():
        if anahtar not in KAYNAKLAR:
            sorunlar.append("ödülde oyunda olmayan kaynak: {}".format(anahtar))
        elif not isinstance(miktar, int) or miktar < 0:
            sorunlar.append("ödül miktarı geçersiz: {} = {!r}".format(anahtar, miktar))
    adlar = {ad.lower(): kod for kod, ad in KAYNAK_ADLARI.items()}
    for yer, metin in (("brifing", bulmaca.brifing), ("kapanış", bulmaca.kapanis)):
        for miktar, ad in _KAYNAK_ANMA.findall(metin or ""):
            kod = adlar[ad.lower()]
            if odul.get(kod) != int(miktar):
                sorunlar.append("{}: '+{} {}' yazıyor, ödül {} {}".format(
                    yer, miktar, ad, odul.get(kod, 0), KAYNAK_ADLARI[kod]))
    return sorunlar


def tara(ders: str = "", tohum_sayisi: int = TOHUM_SAYISI,
         sinif: Tuple[int, int] = LISE) -> List[Tuple[str, str]]:
    """(kaynak, sorun) listesi. Kaynak = ders.uretici kKADEME tTOHUM."""
    icerigi_yukle()
    bulgular: List[Tuple[str, str]] = []
    for kayit in tum_kayitlar():
        if ders and kayit.ders != ders:
            continue
        alt, ust = kayit.kademeler
        for kademe in range(max(alt, sinif[0]), min(ust, sinif[1]) + 1):
            for tohum in range(tohum_sayisi):
                kaynak = "{}.{} k{} t{}".format(kayit.ders, kayit.ad, kademe, tohum)
                try:
                    bulmaca = kayit.fonksiyon(
                        random.Random(tohum * 7919 + kademe), kademe)
                except Exception:  # noqa: BLE001 - --denetle'nin isi
                    bulgular.append((kaynak, "ÜRETİM HATASI " +
                                     traceback.format_exc(limit=1).splitlines()[-1]))
                    continue
                if bulmaca is None:
                    continue
                for sorun in sayi_anlati(bulmaca) + kurgu(bulmaca):
                    bulgular.append((kaynak, sorun))
    return bulgular


def rapor(ders: str = "") -> bool:
    bulgular = tara(ders)
    print()
    print("TUTARLILIK DENETİMİ (B46.4) -- {}, {}-{}. sınıf, {} tohum".format(
        ders or "bütün dersler", LISE[0], LISE[1], TOHUM_SAYISI))
    print("-" * 60)
    if not bulgular:
        print("Bulgu yok. Kurallar sezgisel: bu, anlatının doğru olduğunu "
              "değil, bilinen çelişki türlerinin görülmediğini söyler.")
        return True
    uretici: Dict[str, List[str]] = {}
    for kaynak, sorun in bulgular:
        uretici.setdefault(kaynak.split(" ")[0], []).append(
            "{}  {}".format(kaynak.split(" ", 1)[1], sorun))
    for ad, satirlar in sorted(uretici.items()):
        print("{} ({} bulgu)".format(ad, len(satirlar)))
        for satir in satirlar[:3]:
            print("   ! " + satir)
    print("-" * 60)
    print("Toplam {} bulgu, {} üretici.".format(len(bulgular), len(uretici)))
    return False


if __name__ == "__main__":
    import sys as _sys
    raise SystemExit(0 if rapor(_sys.argv[1] if len(_sys.argv) > 1 else "") else 1)
