# -*- coding: utf-8 -*-
"""
Ana hikâye: Meridyen Seferi.

Bölümler görev sayısına ve hangi derslerden görev yapıldığına göre açılır.
Amaç öğrenciyi tek bir derste tıkanmaktan çıkarıp beş dersi de dolaştırmak:
bir bölümün açılması için genelde farklı derslerden görev gerekir.

Bu dosya bulmaca kaydetmez; yalnızca anlatıyı taşır.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from oyun.motor import terminal as ekran
from oyun.motor.durum import Durum
from oyun.motor.modeller import DERS_ADLARI


@dataclass
class Bolum:
    kod: str
    baslik: str
    metin: str
    gereken_gorev: int = 0
    gereken_dersler: List[str] = field(default_factory=list)
    odul: Dict[str, int] = field(default_factory=dict)
    hedef_notu: str = ""


BOLUMLER: List[Bolum] = [
    Bolum(
        kod="varis",
        baslik="I. Varış",
        metin=(
            "Meridyen Üssü'ne vardığında ilk fark ettiğin şey sessizlik oluyor.\n\n"
            "Üssün kayıt subayı üç hafta önce ayrılmış ve arkasında yarım "
            "bırakılmış defterler, üstü çizili sayılar, hangi depoya ait olduğu "
            "belli olmayan listeler bırakmış. Komutan sana tek bir şey söylüyor:\n\n"
            "\"Burada kimse sana neyin bilinmediğini söylemeyecek. Onu da sen "
            "bulacaksın. Görev panosu koridorun sonunda.\""
        ),
        hedef_notu="Görev panosundan ilk görevini seç.",
    ),
    Bolum(
        kod="depolar",
        baslik="II. Depolar",
        metin=(
            "Sayım tutmuyor. İki depo -Kuzey ve Güney- aynı görünüyor ama "
            "defterde tek bir sayı var; sanki biri iki depoyu tek kalemde "
            "yazmış.\n\n"
            "Üssün bir haftalık erzağı bu hesabın doğru çıkmasına bağlı. "
            "Komutan raporu bekliyor ve raporda \"yaklaşık\" kelimesini "
            "görmek istemiyor."
        ),
        gereken_gorev=2,
        odul={"erzak": 10},
        hedef_notu="Depo kayıtlarını çöz: Sayılar ve Düzen rotası seni ileri taşır.",
    ),
    Bolum(
        kod="arazi",
        baslik="III. Arazi",
        metin=(
            "Üs küçük geliyor. Komutan ikinci bir kamp kurmak istiyor ve yer "
            "seçimini sana bırakıyor.\n\n"
            "Elinde eksik bir harita, birkaç ölçüm ve birbiriyle çelişen iki "
            "keşif raporu var. Yanlış yamaç seçilirse ilk yağmurda kamp sular "
            "altında kalır; yanlış yön seçilirse kışın rüzgâr çadırları alır."
        ),
        gereken_gorev=5,
        gereken_dersler=["matematik", "cografya"],
        odul={"cevher": 8, "itibar": 5},
        hedef_notu="Arazi raporu için Doğa ve Yaşam rotasını araştır.",
    ),
    Bolum(
        kod="kronograf",
        baslik="IV. Kronograf",
        metin=(
            "Deponun arkasındaki kilitli odada bir alet buldun: kadranı olmayan, "
            "yalnızca tek bir kolu bulunan bir düzenek. Kolu çevirdiğinde oda "
            "değişmiyor - ama pencereden görünen manzara değişiyor.\n\n"
            "Kronograf seni geçmişe götürmüyor; geçmişten *kayıtlar* getiriyor. "
            "Bir çarşı gürültüsü, bir mektup parçası, bir yemin metni. Hangi "
            "çağdan geldiğini söylemiyor. Onu da sen bileceksin."
        ),
        gereken_gorev=9,
        gereken_dersler=["cografya", "tarih"],
        odul={"enerji": 10, "itibar": 5},
        hedef_notu="Kronograf kayıtlarını tarihlendir: İnsan ve Toplum rotası açıldı.",
    ),
    Bolum(
        kod="laboratuvar",
        baslik="V. Laboratuvar",
        metin=(
            "Üssün laboratuvarı yıllardır kilitli. İçerideki not defterleri "
            "yarım kalmış deneylerle dolu: ölçülmüş ama yorumlanmamış sayılar, "
            "adı yazılmamış çözeltiler, sonucu kaydedilmemiş bir çaprazlama.\n\n"
            "Bir deneyi tekrarlamak zaman ister. Kaydı okuyup eksik parçayı "
            "çıkarmak ise yalnızca dikkat."
        ),
        gereken_gorev=14,
        gereken_dersler=["tarih", "fen"],
        odul={"enerji": 12, "cevher": 6},
        hedef_notu="Laboratuvar defterleri seni bekliyor: Doğa ve Yaşam rotası.",
    ),
    Bolum(
        kod="arsiv",
        baslik="VI. Arşiv",
        metin=(
            "Merkez, üssün altı aylık raporunu istiyor. Raporu sen yazacaksın.\n\n"
            "Ama önce arşivi düzeltmek gerek: personelin gönderdiği mektuplar, "
            "aceleyle tutulmuş tutanaklar, yanlış yazılmış yer adları. Merkeze "
            "giden her cümle üssün ciddiye alınıp alınmayacağını belirliyor. "
            "Komutanın deyişiyle: \"Bizi sayılarımız kadar cümlelerimiz de "
            "temsil ediyor.\""
        ),
        gereken_gorev=20,
        gereken_dersler=["fen", "turkce"],
        odul={"itibar": 15},
        hedef_notu="Arşivi düzelt: Dil ve Anlatım rotası.",
    ),
    Bolum(
        kod="sefer",
        baslik="VII. Sefer",
        metin=(
            "Merkez raporu okumuş. Cevap tek satır:\n\n"
            "\"Meridyen Üssü artık bir bekleme noktası değil, bir sefer üssüdür. "
            "Kayıt subayı sefer sorumlusu olarak görevlendirilmiştir.\"\n\n"
            "Defterlerin artık düzenli. Ama asıl değişen şu: bir aksaklık "
            "gördüğünde önce \"burada bilinmeyen ne?\" diye soruyorsun. "
            "Kimse sana öğretmedi; işi yaparak öğrendin."
        ),
        gereken_gorev=28,
        gereken_dersler=["matematik", "cografya", "tarih", "fen", "turkce"],
        odul={"itibar": 25, "erzak": 20, "cevher": 20, "enerji": 20},
        hedef_notu="Sefer hazır. İstediğin masadan devam edebilirsin.",
    ),
]


def _kosul_saglandi(durum: Durum, bolum: Bolum) -> bool:
    if durum.oynanan_gorev < bolum.gereken_gorev:
        return False
    for ders in bolum.gereken_dersler:
        if durum.ders(ders).cozulen < 1:
            return False
    return True


def bolumu_kontrol_et(durum: Durum, ilk_giris: bool = False) -> bool:
    """
    Sıradaki bölümün koşulu sağlandıysa anlatıyı gösterir ve ödülü verir.
    Bölüm açıldıysa True döner.
    """
    if ilk_giris and durum.bolum == 0 and not durum.tamamlanan_gorevler:
        _bolum_goster(BOLUMLER[0], durum, ilk=True)
        return True

    acildi = False
    while durum.bolum + 1 < len(BOLUMLER):
        sonraki = BOLUMLER[durum.bolum + 1]
        if not _kosul_saglandi(durum, sonraki):
            break
        durum.bolum += 1
        durum.kaynak_ekle(sonraki.odul)
        durum.gunluk_ekle("Yeni bölüm: " + sonraki.baslik)
        _bolum_goster(sonraki, durum)
        acildi = True
    return acildi


def _bolum_goster(bolum: Bolum, durum: Durum, ilk: bool = False) -> None:
    ekran.temizle()
    ekran.yaz()
    ekran.baslik(ekran.tr_buyuk(bolum.baslik), "kalin", "acik_cam")
    ekran.yaz()
    ekran.kutu(bolum.metin, "", "beyaz")
    if bolum.odul:
        ekran.yaz()
        ekran.yaz("Üsse gelen kaynaklar:", "kalin")
        from oyun.motor.durum import KAYNAK_ADLARI
        for anahtar, miktar in bolum.odul.items():
            ekran.madde("{} +{}".format(KAYNAK_ADLARI.get(anahtar, anahtar), miktar), "acik_sari")
    ekran.bekle()


def gunun_hedefi(durum: Durum) -> Optional[str]:
    """Ana menüde gösterilen tek satırlık yönlendirme."""
    simdiki = BOLUMLER[min(durum.bolum, len(BOLUMLER) - 1)]
    sonraki_indeks = durum.bolum + 1
    if sonraki_indeks < len(BOLUMLER):
        sonraki = BOLUMLER[sonraki_indeks]
        eksik_alan = sum(1 for d in sonraki.gereken_dersler
                         if durum.ders(d).cozulen < 1)
        kalan_gorev = max(0, sonraki.gereken_gorev - durum.oynanan_gorev)
        if eksik_alan:
            return "{}  |  Sıradaki bölüm için {} farklı görev türü daha gerekiyor.".format(
                simdiki.hedef_notu, eksik_alan)
        if kalan_gorev:
            return "{}  |  Sıradaki bölüme {} görev kaldı.".format(
                simdiki.hedef_notu, kalan_gorev)
    return simdiki.hedef_notu or None
